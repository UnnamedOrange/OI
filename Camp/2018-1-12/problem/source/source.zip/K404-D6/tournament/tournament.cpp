#include<cstdio>
#include<vector>
using namespace std;
vector<int>v[666];
bool vis[666];
int a[666];
typedef long long ll;
int n,k,ans,tot;
ll p;
const int mod=998244353;
inline int fp(int a,ll b){
	int ret=1;
	while(b){
		if(b&1)ret=1ll*ret*a%mod;
		a=1ll*a*a%mod;
		b>>=1;
	}
	return ret;
}
inline int fac(int n){
	int sum=1;
	for(register int i=1;i<=n;++i)
		sum=1ll*i*sum%mod;
	return sum;
}
struct edge{
	int u,v;
}e[6666];
inline bool find(int step,int now,int st){
	if(step==k)
		return now==st;
	vis[now]=1;
	a[step]=now;
	for(register int i=0;i<(int)v[now].size();++i)
		if(find(step+1,v[now][i],st)){
			vis[now]=0;
			return 1;
		}
	vis[now]=0;
	return 0;
}
inline void dfs(int now){
	if(now==tot+1){
		for(register int i=1;i<=n;++i)
			if(find(0,i,i)){
				++ans;
				return ;
			}
		return ;
	}
	v[e[now].u].push_back(e[now].v);
	dfs(now+1);
	v[e[now].u].pop_back();
	v[e[now].v].push_back(e[now].u);
	dfs(now+1);
	v[e[now].v].pop_back();
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(k==3){
		printf("%d\n",(fp(2,1ll*n*(n-1)/2)-fac(n)+mod)%mod);
		return 0;
	}
	for(register int i=1;i<=n;++i)
		for(register int j=i+1;j<=n;++j)
			e[++tot]=(edge){i,j};
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
