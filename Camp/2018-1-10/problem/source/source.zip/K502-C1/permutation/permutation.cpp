#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
using namespace std;

const int MAXN = 1e5 + 200, MOD = 998244353;
int n;
long long ans;
int a[MAXN], b[MAXN], c[14];
long long f[MAXN];
bool visit[MAXN];

namespace Force
{
	int cnt = 0;
	void bfs(int p, int o)
	{
		if (c[p] != 0)
			return;
		++cnt;
		c[p] = o;
		bfs(b[p], o);
	}
	bool check()
	{
		memset(c, 0, sizeof c);
		int kind = 0;
		for (int i = 1; i < n + 1; ++i)
		{
			if (c[i] == 0)
			{
				cnt = 0;
				++kind;
				bfs(i, kind);
				if (cnt % 2 != 0)
					return false;
			}
		}
		return true;
	}
	void dfs(int p)
	{
		if (p == n + 1 && check())
			++ans;
		else if (p < n + 1)
		{
			if (a[p] != 0)
			{
				if (visit[a[p]])
					return;
				b[p] = a[p];
				visit[a[p]] = true;
				dfs(p + 1);
				visit[a[p]] = false;
			}
			else
			{
				for (int i = 1; i < n + 1; ++i)
				{
					if (!visit[i])
					{
						visit[i] = true;
						b[p] = i;
						dfs(p + 1);
						visit[i] = false;
					}
				}
			}
		}
	}
	void main()
	{
		dfs(1);
		printf("%lld\n", ans % MOD);
	}
}

namespace Spe
{
	long long fastpow(long long x, long long y)
	{
		long long ret = 1;
		while (y > 0)
		{
			if (y % 2 == 1)
				ret = ret * x % MOD;
			x = x * x % MOD;
			y /= 2;
		}
		return ret;
	}
	void main()
	{
		//init();
		if (n % 2 == 1)
		{
			printf("0\n");
			return;
		}
		f[0] = 1;
		for (int i = 2; i < n + 1; i += 2)
			f[i] = f[i - 2] * (i - 1) % MOD * (i - 1) % MOD;
		printf("%lld\n", f[n] % MOD);
	}
}

namespace AcDream
{
	bool cir = false, unboud = false;
	int ctr = 0;
	void dfs(int p, int kind)
	{
		b[p] = kind;
		++ctr;
		if (b[p] != 0)
		{
			if (b[p] == kind)
				cir = true;
			else
				unboud = true;
		}
		else if (a[p] != 0)
			dfs(a[p], kind);
	}
	void main()
	{
		int tc = n;
		int kind = 1;
		for (int i = 1; i < n + 1; ++i)
		{
			if (a[i] != 0 && b[i] != 0)
			{
				ctr = 0;
				cir = false;
				dfs(i, kind);
				++kind;
				if (unboud)
				{
					printf("0\n");
					return;
				}
				if (cir)
					tc -= ctr;
			}
		}
		if (tc % 2 == 1)
		{
			printf("0\n");
			return;
		}
		f[0] = 1;
		for (int i = 2; i < tc + 1; i += 2)
			f[i] = f[i - 2] * (i - 1) % MOD * (i - 1) % MOD;
		printf("%lld\n", f[n] % MOD);

	}
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	bool spe = true;
	n = read();
	for (int i = 1; i < n + 1; ++i)
	{
		a[i] = read();
		if (a[i] != 0)
			spe = false;
	}
	if (n <= 8)
		Force::main();
	else if (spe)
		Spe::main();
	else
		AcDream::main();
	fclose(stdin);
	fclose(stdout);
}
