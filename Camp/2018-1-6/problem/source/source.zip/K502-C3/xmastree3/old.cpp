#include<cstdio>
#include<iostream>
#include<vector>
#include<cstring>
#define NN 50+5
#define KK 15+5
#define mod 998244353
using namespace std;
long long dp[NN][KK]={0};
int n,k;
int fa[NN]={0};
int p[NN];
struct node{
	int xt;
	int to;
}e[2*NN];
void dfs(int x,bool fl){
	for(int i=p[x];i;i=e[i].xt){
		if(e[i].to==fa[x])continue;
		int now=e[i].to;
		fa[now]=x;
		dfs(e[i].to,!fl);
	}
	for(int i=0;i<=k;++i){
		dp[x][i]=1;
	}
	for(int i=0;i<=k;++i){
		for(int j=p[x];j;j=e[j].xt){
			if(e[j].to!=fa[x])(dp[x][i]*=dp[e[j].to][i+(fl?0:1)])%=mod;
		}
	}
	if(fl){
		for(int i=k;i>=0;--i){
			(dp[x][i]+=dp[x][i+1])%=mod;
		}
	}
}
long long tree_dp(int x){
	memset(dp,0,sizeof dp);
	memset(fa,0,sizeof fa);
	dfs(x,1);
	return dp[x][1];
}
int cnt=1;
void add_edge(int a,int b){
	e[cnt].to=b;
	e[cnt].xt=p[a];
	p[a]=cnt++;
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	int tp,tp1;
	for(int i=1;i<n;++i){
		scanf("%d%d",&tp,&tp1);
		add_edge(tp,tp1);
		add_edge(tp1,tp);
		
	}
	long long ans=0;
	for(int i=1;i<=n;++i){
		(ans+=tree_dp(i))%=mod;
	}
	printf("%d",ans);
}
