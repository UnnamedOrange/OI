#include<cstdio>
#include<iostream>
#define maxn 21
#define mod 1000000009
using namespace std;
struct intval{
	int l,r;
}q[maxn];
int n,m,sum;
int a[maxn],b[maxn];
int check(){
	for (int i=1;i<=m;i++){
		int f=0;
		for (int j=1;j<=n;j++){
			if (!b[j]) continue;
			int l=q[j].l,r=q[j].r;
			if (a[i]>=l && a[i]<=r){
				f=1;
				break;
			}
		}
		if (!f) return 0;
	}
	return 1;
}
void DFS(int x){
	if (x>n){
		if (check()) sum++;
		sum%=mod;
		return;
	}
	b[x]=0;
	DFS(x+1);
	b[x]=1;
	DFS(x+1);
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++){
		int l,r;
		scanf("%d%d",&l,&r);
		q[i].l=l;
		q[i].r=r;
	}
	for (int i=1;i<=m;i++){
		scanf("%d",&a[i]);
	}
	DFS(1);
	cout<<sum<<endl;
	return 0;
}
