//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const int maxn=300+10;
const ll mod=998244353;
ll n,m,sz,now,ans[10][10]={{2},{40,24},{904,784,544},{32048,31008,28848,22320},{2092112,2082032,2058512,1989968,1677488}};

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

int fir[maxn],nxt[maxn*maxn],to[maxn*maxn],e=0;
void add(int x,int y) {
	to[++e]=y;nxt[e]=fir[x];fir[x]=e;
}

int vis[maxn];
bool s(int pos,int t) {
	if(vis[pos]) return t==(m+1)&&pos==now;
	if(t>m) return 0; vis[pos]=1;
	for(int y=fir[pos];y;y=nxt[y]) if(s(to[y],t+1)) {
		vis[pos]=0;
		return 1;
	} 
	vis[pos]=0;
	return 0;
}

int main() {
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	/*
	for(n=3;n<=10;++n){
		for(m=3;m<=n;++m) {
			sz=n*(n-1)/2; ans=0;
			for(int t=0;t<(1<<sz);++t) {
				tt=t;
				for(int i=1;i<=n;++i) fir[i]=vis[i]=0;e=0;
				for(int i=1;i<n;++i) for(int j=i+1;j<=n;++j) {
					if((tt&1)==0) add(i,j);
					else add(j,i);
					tt>>=1;
				}
				now=1;
				for(int i=1;i<=n;++i,++now) if(s(i,1)) {
					++ans; break;
				}
			}
			printf("%lld,",ans);
		}
		printf("\n");
	} 
	*/
	n=read(); m=read();
	if(n<8) 
		printf("%lld",ans[n-3][m-3]%mod);
	else printf("orz");
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
2
40,24
904,784,544
32048,31008,28848,22320
2092112,2082032,2058512,1989968,1677488
*/
