#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

int n, m;
int status[40];
char str[100][110]; 
int len[10];
long long ans = 0;
void open()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
}

bool com(int k)
{
	for(int i = 1; i <= 2 * m - len[k] + 1; i++) {
		int flag = 1;
		for(int j = 1; j <= len[k]; j++) {
			if((str[k][j] - '0') != status[i + j - 1]) {
				flag = 0;
				break;
			}
		}
		if(flag) {
			return true;
		}
	}
	return false;
}
bool judge()
{
	for(int i = 1; i <= m; i++) {
		status[m + i] = 1 - status[m - i + 1];
	}
	/*for(int i = 1 ; i <= 2 * m; i++) {
		cout<<status[i];
	}
	cout<<endl;*/
	for(int i = 1; i <= n; i++) {
		if(!com(i)) {
			return false;
		}
	}
	return true;
}
void DFS(int k)
{
	if(k == m + 1) {
		if(judge()) {
			ans++;
		}
		return ;
	}
	status[k] = 0;
	DFS(k + 1);
	status[k] = 1;
	DFS(k + 1); 
}
void close()
{
	fclose(stdin);
	fclose(stdout);
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}
int main()
{
	open();
	n = read(), m = read();
	for(int i = 1; i <= n; i++) {
		scanf("%s", str[i] + 1);
		len[i] = strlen(str[i] + 1);
	}
 	if(m <= 15) {
		DFS(1);
		printf("%d\n", ans);
	}
	close();
	return 0;
}
