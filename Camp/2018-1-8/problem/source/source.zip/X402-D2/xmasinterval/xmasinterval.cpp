#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

#define x first
#define y second

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
}

namespace liketobe
{
	typedef long long ll;
	typedef std::pair<int,int> pii;
	const int N=501000,MOD=1000000009;

	inline void inc(int a,int &b){b=(a+b)%MOD;}
	inline int qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}

	int n,m;

	struct seg_T
	{
#define lt (p<<1)
#define rt (lt|1)
#define mid ((L+R)>>1)
#define lcq lt,L,mid
#define rcq rt,mid+1,R
		int w[N*4],tag[N*4];
		void init(int p=1,int L=1,int R=m+1)
		{
			w[p]=0,tag[p]=1;
			if(L!=R)init(lcq),init(rcq);
		}
		inline void down(int p)
		{
			if(tag[p]!=1)
			{
				w[lt]=(ll)w[lt]*tag[p]%MOD;
				w[rt]=(ll)w[rt]*tag[p]%MOD;
				tag[lt]=(ll)tag[lt]*tag[p]%MOD;
				tag[rt]=(ll)tag[rt]*tag[p]%MOD;
				tag[p]=1;
			}
		}
		inline void upd(int p){w[p]=(w[lt]+w[rt])%MOD;}
		void mul(int s,int t,int p=1,int L=1,int R=m+1)
		{
			if(L>=s && R<=t){tag[p]=tag[p]*2ll%MOD,w[p]=w[p]*2ll%MOD;return;}
			down(p);
			if(s<=mid)mul(s,t,lcq);
			if(t>mid)mul(s,t,rcq);
			upd(p);
		}
		void modify(int x,int y,int p=1,int L=1,int R=m+1)
		{
			if(L==R){inc(y,w[p]);return;}
			down(p);
			if(x<=mid)modify(x,y,lcq);
			else modify(x,y,rcq);
			upd(p);
		}
		int query(int s,int t,int p=1,int L=1,int R=m+1)
		{
			if(L>=s && R<=t)return w[p];
			down(p);
			int ret=0;
			if(s<=mid)inc(query(s,t,lcq),ret);
			if(t>mid)inc(query(s,t,rcq),ret);
			return ret;
		}
	}T;

	int mw[N],tot;
	inline int id_l(int x){return std::lower_bound(mw+1,mw+tot+1,x)-mw;}
	inline int id_r(int x){return std::upper_bound(mw+1,mw+tot+1,x)-mw-1;}

	bool cmp(pii A,pii B){return A.y==B.y?A.x<B.x:A.y<B.y;}

	pii s[N];

	void initialize()
	{
		read(n),read(m);
		for(int i=1;i<=n;i++)read(s[i].x),read(s[i].y);
		tot=m;
		for(int i=1;i<=m;i++)read(mw[i]);
		std::sort(mw+1,mw+tot+1);
		tot=std::unique(mw+1,mw+tot+1)-mw-1;
		m=tot;

		for(int i=1;i<=n;i++)
			s[i].x=id_l(s[i].x),s[i].y=id_r(s[i].y);
		std::sort(s+1,s+n+1,cmp);
	}

	int f[N];

	void dp()
	{
		T.init();T.modify(1,1);
		f[1]=1;
		for(int i=1,x,y;i<=n;i++)
		{
			x=s[i].x,y=s[i].y;
			if(x>1)T.mul(1,x-1);T.mul(y+1,m+1);
			if(x<=y)T.modify(y+1,T.query(x,y));
		}
	}

	void solve()
	{
		initialize();
		dp();
		printf("%d\n",T.query(m+1,m+1));
	}
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	liketobe::solve();
	return 0;
}
