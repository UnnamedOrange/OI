#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue> 
#include <stack>
using namespace std;

int n, ans;
int a[30];

void transform(int l, int r)
{
	for (int i = l, j = r; i < j; ++i, --j)
		swap(a[i], a[j]);
}

void dfs(int d)
{
	if (d >= ans)
		return;
	int r = n + 1;
	for (int i = n; i > 0; --i)
	{
		if (a[i] != i)
			break;
		r = i;
	}
	if (r == 1)
	{
		ans = min(ans, d);
		return;
	}
	for (int i = 2; i < r && d + 1 < ans; ++i)
	{
		transform(1, i);
		dfs(d + 1);
		transform(1, i);
	}
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	int T = read();
	while (T--)
	{
		n = read();
		ans = n;
		for (int i = 1; i < n + 1; ++i)
			a[i] = read();
		dfs(0);
		printf("%d\n", ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
