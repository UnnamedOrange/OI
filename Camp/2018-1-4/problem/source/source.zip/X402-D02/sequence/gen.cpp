#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int s[30];

void work()
{
	int n=14;
	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		s[i]=i,std::swap(s[i],s[rand()%i+1]);
	for(int i=1;i<=n;i++)
		printf("%d ",s[i]);
	printf("\n");
}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("sequence.in","w",stdout);//look at here

	int T=5;
	printf("%d\n",T);
	while(T--)work();

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
