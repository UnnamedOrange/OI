#include<cstdio>
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
int n,m;
char S[7][1001];
int s[7][1001];
int a[10001],len[10001];
int flag=0,ans;
inline void check(int j,int i){
	for(register int k=j,l=1;l<=len[i];++l,++k)
		if(s[i][l]!=a[k])
			return;
	flag=1;
}
inline void dfs(int now){
	if(now==m+1){
		int cnt=0;
		FOR(i,1,n){
			flag=0;
			FOR(j,1,2*m-len[i]+1){
				check(j,i);
				if(flag){
					++cnt;
					break;
				}
			}
		}
		if(cnt==n)
			++ans;
		return;
	}
	a[now]=1;
	a[2*m-now+1]=0;
	dfs(now+1);
	a[now]=0;
	a[2*m-now+1]=1;
	dfs(now+1);
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	FOR(i,1,n){
		scanf("%s",S[i]+1);
		for(len[i]=1;S[i][len[i]];++len[i])
			s[i][len[i]]=S[i][len[i]]-48;
		--len[i];
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
