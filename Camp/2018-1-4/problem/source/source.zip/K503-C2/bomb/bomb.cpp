#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define maxn 1000010
int head[maxn]={0},e[maxn][3],d[maxn]={0},n,m,i,x,y,p,t=0,ans=1;
bool mark[5010];
int max(int x,int y)
{
	return x>y ? x : y;
}
void addedge(int x,int y)
{
	e[++t][1]=y;
	e[t][2]=1;
	e[t][0]=head[x];
	head[x]=t;
}
int dfs(int x)
{
	int i,s=0;
	if (n<=5000) mark[x]=false;
	if (d[x]) return d[x];
	for (i=head[x];i>0;i=e[i][0])
		if (n<=5000)
		{
			if (mark[e[i][1]] || d[e[i][1]]) s=max(s,dfs(e[i][1]));
		}
			else s=max(s,dfs(e[i][1]));
	d[x]=s+1;
	return s+1;
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		addedge(x,y);
	}
	for (i=1;i<=n;i++)
	{
		if (n<=5000) memset(mark,true,sizeof(mark));
		ans=max(ans,dfs(i));
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
