#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
//#include<ctime>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
}

typedef long long ll;
const int N=101000,M=N*2,K=505,L=1200,MOD=998244353;
ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}
ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}

int fact[K],ifact[K];
int dg[L];

namespace Math
{
	int dec[L],pow[L];
	inline void getdec(int n)
	{
		for(int i=1;i<n;i++)dec[i]=(dec[i>>1]>>1)+((i&1)?(n>>1):0);
		for(int len=2;len<=n;len<<=1)
			pow[len]=qpow(3,(MOD-1)/len);
	}
	void ntt(int *y,int n,int rag)
	{
		for(int i=0;i<n;i++)
			if(i<dec[i])std::swap(y[i],y[dec[i]]);
		
		int *y0,*y1,ny0,ny1;
		int x,h,delta;

		for(int len=2;len<=n;len<<=1)
		{
			h=len>>1;
			delta=pow[len];

			if(rag<0)delta=inv(delta);

			for(int p=0;p<n;p+=len)
			{
				y0=y+p,y1=y0+h,x=1;
				for(int i=0;i<h;i++,x=(ll)x*delta%MOD)
				{
					ny0=(y0[i]+(ll)x*y1[i])%MOD;
					ny1=(y0[i]-(ll)x*y1[i])%MOD;
					y0[i]=ny0;
					y1[i]=ny1;
				}
			}
		}
	}
	inline void mul(int *A,int n)
	{
		ntt(A,n,1);
		for(int i=0;i<n;i++)A[i]=(ll)A[i]*dg[i]%MOD;
		ntt(A,n,-1);
		int x=inv(n);
		for(int i=0;i<n;i++)A[i]=(ll)A[i]*x%MOD;
	}
}

namespace bf
{
	int f[N][K];


	int begin[N],next[M],to[M];
	int n,m,k,e;

	int lim[N];
	void add(int x,int y)
	{
		lim[y]++;
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
	}
	void initialize()
	{
		read(n),read(m),read(k);
		for(int u,v;m--;)read(u),read(v),add(u,v);

		fact[0]=1;
		for(int i=1;i<K;i++)fact[i]=(ll)fact[i-1]*i%MOD;
		ifact[K-1]=inv(fact[K-1]);
		for(int i=K-1;i;i--)ifact[i-1]=(ll)ifact[i]*i%MOD;
	}
	int seq[N],tot;
	void topsort()
	{
		static std::queue<int> Q;
		while(!Q.empty())Q.pop();
		for(int i=1;i<=n;i++)if(!lim[i])Q.push(i);
		for(int p,q;!Q.empty();)
		{
			p=Q.front();Q.pop();
			seq[++tot]=p;
			for(int i=begin[p];i;i=next[i])
			{
				lim[q=to[i]]--;
				if(!lim[q])Q.push(q);
			}
		}
	}

	void dp()
	{
		static int g[L];

		for(m=1;m<=k*2;m<<=1);
		Math::getdec(m);

		for(int i=0;i<=k;i++)dg[i]=ifact[i];
		for(int i=k+1;i<m;i++)g[i]=dg[i]=0;
		Math::ntt(dg,m,1);

		f[seq[1]][0]=1;
		for(int o=1;o<=n;o++)
		{
//			if(o%10000==0)fprintf(stderr,"o = %d\n",o);
			int p=seq[o],q;

			for(int i=0;i<=k;i++)
				g[i]=(ll)f[p][i]*ifact[i]%MOD;
			for(int i=k+1;i<m;i++)g[i]=0;

			Math::mul(g,m);

			for(int i=0;i<=k;i++)
				g[i]=((ll)g[i]*fact[i]%MOD+MOD)%MOD;

			for(int i=begin[p];i;i=next[i])
			{
				q=to[i];
				for(int j=0;j<=k;j++)
					f[q][j]=(f[q][j]+g[j])%MOD;
			}
		}
	}
	void solve()
	{
		initialize();
		topsort();
		dp();
		for(int i=1;i<=n;i++)
			printf("%d\n",f[i][k]);
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	bf::solve();

//	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
