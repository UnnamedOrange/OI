#include<map>
#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 105
typedef long long ll;

int n;
int a[maxn];
bool flag;

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

map<ll,int> h[2];

ll encode(){
	ll ret=0;
	for (int i=1;i<=n;i++) ret=ret*n+(a[i]-1);
	return ret;
}

void decode(ll x){
	for (int i=n;i;i--) a[i]=x%n+1,x/=n;
}

struct modpps{
	ll q[10000005];
	int head,tail;
	void clear(){head=1,tail=0;}
	void insert(ll x){q[++tail]=x;}
	void extend(int bo){
		int r=tail;
		while (head<=r){
			ll x=q[head++]; decode(x);
			for (int i=2;i<=n;i++){
				reverse(a+1,a+i+1); ll v=encode();
				if (h[bo^1][v]){flag=1; return;}
				reverse(a+1,a+i+1);
				if (h[bo][v]) continue; h[bo][v]=1;
				q[++tail]=v;
			}
		}
	}
}st,ed;

int main(){
	for (int T=read();T;T--){
		n=read(); h[0].clear(),h[1].clear(),st.clear(),ed.clear();
		for (int i=1;i<=n;i++) a[i]=read();
		ll x=encode(); h[0][x]=1,st.insert(x);
		for (int i=1;i<=n;i++) a[i]=i;
		x=encode(); h[1][x]=1,ed.insert(x);
		if (h[0][x]&&h[1][x]){puts("0"); continue;}
		int ans=0; flag=0;
		while (1){
			st.extend(0); ++ans; if (flag) break;
			ed.extend(1); ++ans; if (flag) break;
		}
		cout<<ans<<endl;
	}
	return 0;
}
