#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)1e6+5;
int prime[M],psz,mu[M],summu[M],vis[M];
int ask[M];
void init(){
	mu[1]=1;
	for(int i=2,v;i<M;i++){
		if(vis[i]==0)prime[psz++]=i,mu[i]=-1;
		v=-mu[i];
		for(int j=0,t;j<psz&&((t=prime[j]*i)<M);j++){
			vis[t]=1;
			if(i%prime[j]==0){
				mu[t]=0;
				break;
			}
			mu[t]=v;
		}
	}
	for(int i=1;i<M;i++)summu[i]=summu[i-1]+mu[i];
}
int cas;
struct SHUI{
	long long sumfe[M];
	long long calc(int n){
		long long re=0;
		for(int i=1,a,b;i<=n;i++){
			a=n/i,b=n/a;
			re+=(summu[b]-summu[i-1])*sumfe[a];
			i=b;
		}
		return re;
	}
	void solve(){
		for(int i=1,v,x,c;i<M;i++){
			sumfe[i]=sumfe[i-1];
			v=1;
			x=i;
			for(int j=0;j<psz&&(long long)prime[j]*prime[j]<=x;j++)
				if(x%prime[j]==0){
					c=1;
					while(x%prime[j]==0)x/=prime[j],c++;
					v*=c;
				}
			if(x>1)v*=2;
			sumfe[i]+=v*v;
		}
		for(int i=1;i<=cas;i++)printf("%lld\n",calc(ask[i]));
	}
}P30;

int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	init();
	scanf("%d",&cas);
	bool xiaoyu=true;
	for(int i=1;i<=cas;i++){
		scanf("%d",&ask[i]);
		if(ask[i]>1000000)xiaoyu=false;
	}
	if(xiaoyu)P30.solve();
	
	return 0;
}
