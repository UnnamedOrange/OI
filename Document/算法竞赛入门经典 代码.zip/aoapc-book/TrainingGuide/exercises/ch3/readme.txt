《算法竞赛入门经典——训练指南》代码仓库

第三章习题代码

注意：有些题目并没有在书中出现，但是仍然有一定的启发意义，所以一并放在这里，供读者参考。

基础数据结构（Fundamental Data Structures）

UVa11988 Broken Keyboard (a.k.a. Beiju Text) 陈锋
UVa11136 Hoax or what 陈锋
UVa10895 Matrix Transpose 陈锋
UVa11987 Almost Union-Find 陈锋

区间信息维护（Maintaining Interval Data）

LA2191   Potentiometers 陈锋
UVa12299 RMQ with shifts 刘汝佳
LA4730(UVa1455) – Kingdom 陈锋

字符串算法(String Algorithms)
UVa11488 Hyper Prefix Sets 陈锋
LA3907(UVa1399) Puzzle 陈锋
UVa11855 Buzzwords 使用Hash实现的版本 陈锋
UVa11855 Buzzwords 使用后缀数组实现的版本 陈锋

二叉搜索树(BST)
UVa1264(LA4847) Binary Search Tree 陈锋
UVa10909 Lucky Number 刘汝佳
