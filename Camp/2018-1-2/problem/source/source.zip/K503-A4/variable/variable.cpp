//Brute-force ~30pts
#include <bits/stdc++.h>
#define CLEAR(x) memset((x), 0, sizeof(x))
typedef long long LL;
using namespace std;
const int MAXN = 15;
int T, N, P, Q, Edge[MAXN+10][MAXN+10];
LL X[MAXN+10], Y[MAXN+10], Z[MAXN+10],
   A[MAXN+10], B[MAXN+10], C[MAXN+10], 
   D[MAXN+10], E[MAXN+10], F[MAXN+10], W0;


void Init() {
	memset(Edge, -1, sizeof(Edge)); //-1 for unknown
	int u, v, c;
	scanf("%d%lld%d%d", &N, &W0, &P, &Q);
	for(int i=1; i<=P; i++) 
		scanf("%lld%lld%lld%lld%lld%lld%lld%lld%lld",
			X+i, Y+i, Z+i, A+i, B+i, C+i, D+i, E+i, F+i);
	for(int i=1; i<=Q; i++) {
		scanf("%d%d%d", &u, &v, &c);
		Edge[u][v]=c; //
	}
}

inline LL eval(int S, int p) { return ((S&(1<<(p-1))) ? 1 : -1) * W0; }

void Work() {
	LL Ans = LLONG_MAX, Sum=0, wx, wy, wz;
	for(int S=0; S<(1<<N); S++) {
		for(int t1=1; t1<=N; t1++)
			for(int t2=1; t2<=N; t2++) {
				LL lhs = eval(S, t1), rhs = eval(S, t2);
				switch(Edge[t1][t2]) {
					case 0:
						if(lhs>rhs) goto cycle;
						break;
					case 1:
						if(lhs!=rhs) goto cycle;
						break;
					case 2:
						if(lhs>=rhs) goto cycle;
						break;
				}
				swap(lhs,rhs);
				switch(Edge[t2][t1]) {
					case 0:
						if(lhs>rhs) goto cycle;
						break;
					case 1:
						if(lhs!=rhs) goto cycle;
						break;
					case 2:
						if(lhs>=rhs) goto cycle;
						break;
				}
			}
		
		Sum=0;
		for(int i=1; i<=N; i++) Sum+=eval(S, i);
		for(int i=1; i<=P; i++) {
			wx = eval(S, X[i]); wy = eval(S, Y[i]); wz = eval(S, Z[i]);
			Sum += A[i]*llabs(wx-wy)+B[i]*llabs(wy-wz)+C[i]*llabs(wz-wx)
	+D[i]*(wx-wy)+E[i]*(wy-wz)+F[i]*(wz-wx);
		}
		Ans = min(Ans, Sum);
		cycle: T=T;
	}
	printf("%lld", Ans);
}

void Clear() {
	CLEAR(A); CLEAR(B); CLEAR(C); CLEAR(D); 
	CLEAR(E); CLEAR(F); CLEAR(Edge); 
	CLEAR(X); CLEAR(Y); CLEAR(Z); N=P=Q=0;
}

int main() {
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	scanf("%d", &T);
	while(T--) {
		Init(); Work(); Clear();
	}
	
	return 0;
}
