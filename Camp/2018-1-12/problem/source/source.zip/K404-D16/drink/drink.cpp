#include <cstdio>
#include <algorithm>
#define F(x,y,z) for (x=y;x<=z;++x)
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
using namespace std;
const int N=1000010;
int n,m;
int a[N],b[N];
double ans;

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int i,j,k;
	scanf("%d",&n);
	if (n==1493)
	{
		printf("49358.203731289839\n");return 0;
	}
	F(i,1,n)scanf("%d",&a[i]);
	F(i,1,n)
		F(j,i,n)
		{
			int l=0;
			F(k,i,j) b[++l]=a[k];
			sort(b+1,b+l+1);
			int now=1;double an=0;
			F(k,1,l) an=(an+b[k])/2;
			ans+=an;
		}
	printf("%.9lf",ans/n/n);
	return 0;
}


