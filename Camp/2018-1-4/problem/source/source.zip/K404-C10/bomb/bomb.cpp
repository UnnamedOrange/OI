#include <cstdio>
#include <algorithm>
#include <stack>
#include <queue>
using namespace std;
#define N 1000050
int x[N],y[N],low[N],dfn[N],hd[N],nxt[N],v[N],fa[N],sz[N],id,vis[N],n,m,i,in[N],dep[N];
stack<int> s;
queue<int> q;
inline int rd()
{
	char ch=getchar();int ret=0;
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9') ret=(ret<<3)+(ret<<1)+ch-'0',ch=getchar();
	return ret;
}
void tarjan(int now)
{
	low[now]=dfn[now]=++id;vis[now]++;s.push(now);
	for (int gh=hd[now];gh;gh=nxt[gh]){
		if (vis[v[gh]]==0){
			tarjan(v[gh]);low[now]=min(low[now],low[v[gh]]);
		}else if (vis[v[gh]]==1) low[now]=min(low[now],dfn[v[gh]]);
	}
	if (low[now]==dfn[now]){
		int psz=s.top();s.pop();vis[psz]++;fa[psz]=now;sz[now]++;
		while (psz!=now) psz=s.top(),s.pop(),vis[psz]++,fa[psz]=now,sz[now]++;
	}
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=rd();m=rd();
	for (i=1;i<=m;i++){
		x[i]=rd();y[i]=rd();
		int psz=++id;v[psz]=y[i];nxt[psz]=hd[x[i]];hd[x[i]]=psz;
	}id=0;for (i=1;i<=n;i++) if (!vis[i]) tarjan(i);
	for (i=1;i<=n;i++) hd[i]=0;id=0;
	for (i=1;i<=m;i++) if (fa[x[i]]!=fa[y[i]]){
		int psz=++id;v[psz]=fa[y[i]];nxt[psz]=hd[fa[x[i]]];hd[fa[x[i]]]=psz;in[fa[y[i]]]++;
	}
	for (i=1;i<=n;i++) if (sz[i]&&!in[i]) q.push(i);
	int ans=0;
	while (!q.empty()){
		int psz=q.front();q.pop();dep[psz]+=sz[psz];ans=max(ans,dep[psz]);
		for (int gh=hd[psz];gh;gh=nxt[gh]){
			dep[v[gh]]=max(dep[v[gh]],dep[psz]);
			if (--in[v[gh]]==0) q.push(v[gh]);
		}
	}printf("%d\n",ans);
	return 0;
}
