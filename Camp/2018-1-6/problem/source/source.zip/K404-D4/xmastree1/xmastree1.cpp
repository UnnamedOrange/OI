#include <iostream>
#include <cstdio>
#include <cstring>
#include <bitset>
using namespace std;
int n, q, t;
int c[100010];
int head[100010], to[200010], nxt[200010], cnt;
inline void addedge (int u, int v) { cnt++, to[cnt] = v, nxt[cnt] = head[u], head[u] = cnt; }
int dfn[100010], ind, end[100010];
int cl[100010];
bool hv[100010];
inline void dfs (int u, int p) {
	dfn[u] = ++ind; cl[ind] = c[u];
	for (int e = head[u]; e; e = nxt[e]) {
		int v = to[e];
		if (v == p) continue;
		dfs (v, u);
	}
	end[u] = ind;
}
int lastans;
int main () {
	freopen ("xmastree1.in", "r", stdin);
	freopen ("xmastree1.out", "w", stdout);
	scanf ("%d%d%d", &n, &q, &t);
	for (int i = 1; i <= n; i++) scanf ("%d", &c[i]);
	for (int i = 1; i < n; i++) {
		int u, v;
		scanf ("%d%d", &u, &v);
		addedge (u, v);
		addedge (v, u);
	}
	dfs (1, 0);
	while (q--) {
		int tp;
		scanf ("%d", &tp);
		if (tp == 1) {
			memset (hv, 0, sizeof (hv));
			int u, l, r;
			scanf ("%d%d%d", &u, &l, &r);
			if (t) u ^= lastans, l ^= lastans, r ^= lastans;
			for (int i = dfn[u]; i <= end[u]; i++) hv[cl[i]] = true;
			lastans = 0;
			for (int i = l; i <= r; i++) lastans += hv[i];
			printf ("%d\n", lastans);
		} else {
			int u, c;
			scanf ("%d%d", &u, &c);
			u ^= lastans, c ^= lastans;
			cl[dfn[u]] = c;
		}
	}
	return 0;
}
