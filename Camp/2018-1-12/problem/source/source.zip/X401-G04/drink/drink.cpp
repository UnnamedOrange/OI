/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
#define MAXN 1000000
typedef long double LD;
typedef unsigned long long LL;
int a[MAXN+10];
int b[MAXN+10];
LD mi[50];
const int jd=40;
int n;
namespace x1
{
LD main()
{
    LD ans=0;
    for(int l=1; l<=n; ++l)
    {
        int cnt=0;
        for(int r=l; r<=n; ++r)
        {
            b[++cnt]=a[r];
            for(int now=cnt-1; now>=1; --now)
            {
                if (b[now]<b[now+1])
                {
                    swap(b[now],b[now+1]);
                }
                else break;
            }
            if (cnt>=jd) --cnt;
            LD nowans=0;
            for(int i=1; i<=cnt; ++i)
            {
                nowans+=b[i]*mi[i];
            }
			//cerr<<no
            nowans/=LD(n)*n;
            ans+=nowans;
        }
    }
	cerr<<ans<<endl;
    return ans;
}
}
int main()
{
    freopen("drink.in","r",stdin);
#ifndef MDEBUG
    freopen("drink.out","w",stdout);
#endif
    scanf("%d",&n);
    mi[0]=1;
    for(int i=1; i<=jd; ++i)
    {
        mi[i]=mi[i-1]/2;
    }

    for(int i=1; i<=n; ++i)
    {
        scanf("%d",&a[i]);
    }
    LD ans;
    ans=x1::main();	
	double x=LD(ans);
    printf("%.10lf\n",x);
    return 0;
}
