#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<< " = "<<(x)<<" "
#define debug(x) cerr<<#x<< " = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e6+5;

int head[N],tot_edge,n,m;
pii G[N];
struct P_0{
	int to[20];
	bool mark[1<<10];
	int dp[1<<10];
	void work(){
		rep(i,1,n+1){
			to[i-1]=1<<(i-1);
			for(int j=head[i];j;j=G[j].se)
				to[i-1]|=1<<(G[j].fi-1);
		}
		rep(k,0,n)rep(i,0,n)if(to[i]>>k&1)to[i]|=to[k];
		rep(i,1,1<<n){
			rep(j,0,n)if(i>>j&1)
				mark[i]|=((to[j]&i)!=(1<<j));
		}
		rep(i,1,1<<n){
			dp[i]=n;
			for(int j=i;j;j=(j-1)&i)
				if(!mark[j])Min(dp[i],dp[i^j]+1);
		}
		ptn(dp[(1<<n)-1]);
	}
}P0;
int deg[N],que[N],dis[N];
struct P_1{
	int ans;
	bool judge(){
		int l=0,r=0,x,y,i;
		rep(i,1,n+1)if(!deg[i])que[r++]=i,dis[i]=1;
		while(l<r){
			x=que[l++];
			Max(ans,dis[x]);
			for(i=head[x];i;i=G[i].se){
				y=G[i].fi;
				Max(dis[y],dis[x]+1);
				--deg[y];
				if(!deg[y])que[r++]=y;
			}
		}
		rep(i,1,n+1)if(deg[i])return false;
		return true;
	}
	void work(){
		ptn(ans);
	}
}P1;
struct P_2{
	int scc_cnt,scc_id[N],dfn[N],low[N],dfn_clock;
	int *stk,tp,*mark;
	void Tarjan(int x){
		dfn[x]=low[x]=++dfn_clock;
		stk[++tp]=x;
		mark[x]=true;
		for(int y,i=head[x];i;i=G[i].se){
			y=G[i].fi;
			if(!dfn[y]){
				Tarjan(y);
				Min(low[x],low[y]);
			}else if(mark[y])Min(low[x],dfn[y]);
		}
		if(low[x]==dfn[x]){
			scc_cnt++;
			do mark[stk[tp]]=false,scc_id[stk[tp]]=scc_cnt;
			while(stk[tp--]!=x);
		}
	}
	int lst[N],tot_E,cnt[N];
	pii E[N];
	void work(){
		stk=que;mark=dis;
		rep(i,1,n+1)if(!dfn[i])Tarjan(i);
		memset(deg,0,sizeof deg);
		rep(x,1,n+1){
			++cnt[scc_id[x]];
			for(int y,i=head[x];i;i=G[i].se){
				y=G[i].fi;
				if(scc_id[x]!=scc_id[y]){
					++deg[scc_id[y]];
					E[++tot_E]=pii(scc_id[y],lst[scc_id[x]]);
					lst[scc_id[x]]=tot_E;
				}
			}
		}
		memset(dis,0,sizeof dis);
		int l=0,r=0,x,y,i,ans=0;
		rep(i,1,scc_cnt+1)if(!deg[i])que[r++]=i,dis[i]=0;
		while(l<r){
			x=que[l++];
			dis[x]+=cnt[x];
			Max(ans,dis[x]);
			for(i=lst[x];i;i=E[i].se){
				y=E[i].fi;
				Max(dis[y],dis[x]);
				--deg[y];
				if(!deg[y])que[r++]=y;
			}
		}
		ptn(ans);
	}
}P2;
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	rd(n),rd(m);
	for(int x,y;m--;){
		rd(x),rd(y);
		++deg[y];
		G[++tot_edge]=pii(y,head[x]);
		head[x]=tot_edge;
	}
	if(0);
	else if(n<=10)P0.work();
	else if(P1.judge())P1.work();
	else P2.work();
	return 0;
}
