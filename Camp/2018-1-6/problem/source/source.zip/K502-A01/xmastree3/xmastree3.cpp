#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
	int N, M;
	scanf("%d%d", &N, &M);
	cout<<N * M<<endl;
	return 0;
}
