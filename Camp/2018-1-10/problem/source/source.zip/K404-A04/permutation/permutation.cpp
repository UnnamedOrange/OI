#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
const int maxn=100010;
const int mod=998244353;
int n,a[maxn];
ll ans;
bool vis[maxn],b[15];
void find(int v)
{
	if(v>n)
	{
		memset(b,0,sizeof(b));
		for(int i=1;i<=n;i++)
			if(!b[i])
			{
				int cal=0;
				for(int j=i;!b[j];j=a[j]) b[j]=1,cal++;
				if(cal&1) return ;
			}
		ans++;	
		return ;
	}
	if(a[v]) find(v+1);
	else 
		for(int i=1;i<=n;i++)
			if(!vis[i])
			{
				vis[i]=1;
				a[v]=i;
				find(v+1);
				vis[i]=0;
				a[v]=0;
			}
		
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	if(n<=8)
	{
		for(int i=1;i<=n;i++)
			if(a[i])vis[a[i]]=1;
		find(1);
	}
	else if(!(n&1)) 
	{
		ans=1;
		for(int i=1;i<=(n>>1);i++)
			(ans*=(2*i-1))%=mod;
		ans=ans*ans%mod;
			
	}
	printf("%lld",ans);	
	return 0;	
}
/*100
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 */
