#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0;char ch=getchar();
	while(ch<'0'||'9'<ch)ch=getchar();
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret;
}
#define p 998244353
#define ll long long
int n,m,k;
ll ksm(int num,int tim){
	ll ret=1;
	while(tim){
		if(tim&1)
			ret=ret*num%p;
		num=num*num%p;
		tim=tim>>1;
	}
	return ret;
}
ll a[2333],s[2333];
ll ans=0;
void dfs(int l,int r,int res){
	for(int i=l;i<r;i++)
		++a[i];
	if(res==1){
		for(int i=1;i<=m;i++)
			ans=(ans+s[a[i]])%p;
		for(int i=l;i<r;i++)
			--a[i];
		return;
	}
	for(int L=l+1;L<=m;L++)
		for(int R=max(L,r+1);R<=m;R++)
			dfs(L,R,res-1);
	for(int i=l;i<r;i++)
		--a[i];
	return;
}
void sol1(){
	for(int i=0;i<=m*m;i++)
		s[i]=ksm(i,k);
	memset(a,0,sizeof(a));
	for(int i=1;i<=m;i++)
		for(int j=i;j<=m;j++)
			dfs(i,j,n);
	cout<<ans<<endl;
}
ll f[50][50][50];
bool g[50][50][50];
void sol2(){
	memset(f,0,sizeof(f));
	memset(g,0,sizeof(g));
	for(int i=1;i<=m;i++)
		for(int j=i;j<=m;j++)
			g[0][i][j]=1;
	for(int t=1;t<=n;t++){
		for(int i=1;i<=m;i++)
			for(int j=i;j<=m;j++)
				for(int l=i+1;l<=m;l++)
					for(int r=max(l,j+1);r<=m;r++)
						if(g[t-1][l][r]){
							g[t][i][j]=true;
							f[t][i][j]=(f[t][i][j]+f[t-1][l][r]+r-l)%p;
						}
	}	
	int aans=0;
	for(int i=1;i<=m;i++)
		for(int j=i;j<=m;j++)
			aans=(aans+f[n][i][j])%p;
	cout<<aans<<endl;
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=re(),m=re(),k=re();
	if(n>=m)
		cout<<0<<endl;
	else{
		if(m<=6){
			sol1();
		}else{
			if(n==1){
				ll anz=0;
				for(int len=1;len<m;len++)
					anz=(anz+len*(m-len))%p;
				cout<<anz<<endl;
			}else{
				sol2();
			}
		}
	}
	return 0;
}

