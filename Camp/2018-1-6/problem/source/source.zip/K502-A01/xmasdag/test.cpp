#include <bits/stdc++.h>
using namespace std;
int main()
{
	srand(time(0));
	int n = rand()%2 + 1;
	cout<<n<<endl;
	return 0;
}
