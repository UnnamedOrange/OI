#include <iostream>
using namespace std;
int a[1000100];
double tb[1000100];
inline void read(int &x) {
	x=0; int f=1; char c=getchar();
	while (!isdigit(c)) c=getchar();
	while (isdigit(c)) {
		x=x*10+c-'0';
		c=getchar();
	}
	x=x*f;
}
int main() {
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int n;
	read(n);
	tb[0]=1.0;
	for (int i=1;i<=n;i++) tb[i]=tb[i-1]/2;
	for (int i=1;i<=n;i++) {
		read(a[i]);
	}
	double ans=0;
	for (int i=1;i<=n;i++) {
		int cnt=0;
		double left=0;
		double right=0;
		for (int j=i;j>=1;j--) {
			if (a[j]>a[i]) cnt++;
			left+=tb[cnt];
		}
		if (left==0) left=1;
		cnt=0;
		for (int j=i;j<=n;j++) {
			if (a[j]>=a[i]) cnt++;
			right+=tb[cnt];
		}
		ans+=left*right*a[i];
		cerr << left*right*a[i] << endl; 
	}
	printf("%.12lf\n",ans/n/n);
 	return 0;
}

