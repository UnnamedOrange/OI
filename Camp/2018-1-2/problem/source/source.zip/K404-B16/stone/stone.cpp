#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

typedef long long LL;
const int P = 1e9 + 7;
LL ans;
int n, a, b;
int xian, hou, A, B;

int lp(int a, int b) {
	int c = 1;
	for(; b; b >>= 1, a = (LL)a * a % P)
		if(b & 1) c = (LL)c * a % P;
	return c;
}

int main() {
	freopen("stone.in", "r", stdin); freopen("stone.out", "w", stdout);
	int x, i;
	scanf("%d %d %d", &n, &a, &b);
	rep(i, 1, n) {
		scanf("%d", &x);
		x %= (a + b);
		if(x < a && x < b) ++hou;
		if(x >= a && x >= b) ++xian;
		if(x >= a && x < b) ++A;
		if(x >= b && x < a) ++B;
	}
	ans = (LL)(lp(2, A) - 1ll + P) % P * lp(2, xian+hou) % P;
	printf("%lld ", ans);
	ans = (LL)(lp(2, B) - 1ll + P) % P * lp(2, xian+hou) % P;
	printf("%lld ", ans);
	
	if(xian + hou == 0) puts("0 0"); else {
		if(!xian) {ans = lp(2, hou); printf("0 %lld\n", ans);}
		else {ans = lp(2, xian+hou-1); printf("%lld %lld\n", ans, ans);}
	}
	return 0;
}
