#include <cstdio>
#include <cstring>
#include <algorithm>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

const int N = 1210, mod = 998244353;
int f[510][N][70], g[N], son[N][2], st[N], ca[N], fa[N], wh[N], nxt[N];
int n, m, len, tot, ans;
char s[N];

bool check(int j, int n)
{
	FOR(i, j + 1, n - 1)
		if (j - (i - j) + 1 < 0 || s[i] == s[j - (i - j) + 1]) return 0;
	return 1;
}

void ins(int k)
{
	int i = 0;
	FOR(j, 0, len - 1)
	{
		if (!son[i][s[j] - '0'])
		{
			son[i][s[j] - '0'] = ++tot;
			fa[tot] = i; wh[tot] = s[j] - '0';
		}
		i = son[i][s[j] - '0'];
		if (check(j, len)) ca[i] |= k;
		if (j == len - 1) st[i] |= k; 
	}
}

void build()
{
	g[tot = 1] = 0;
	for(int x = 1, i = g[x];  x <= tot; i = g[++x])
	{
		if (son[i][0]) g[++tot] = son[i][0];
		if (son[i][1]) g[++tot] = son[i][1];
		if (!i) continue;
		int j = nxt[fa[i]];
		for(; j && !son[j][wh[i]]; j = nxt[j]);
		if (son[j][wh[i]] && son[j][wh[i]] != i) nxt[i] = son[j][wh[i]];
		if (!son[i][0]) son[i][0] = son[nxt[i]][0];
		if (!son[i][1]) son[i][1] = son[nxt[i]][1];
		st[i] |= st[nxt[i]];
		ca[i] |= ca[nxt[i]];
	}
}

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d%d", &n, &m);
	FOR(i, 0, n - 1)
	{
		scanf("%s", s); 
		len = strlen(s);
		ins(1 << i);
		for(int j = 0; len - 1 - j > j; ++j) swap(s[j], s[len - 1 - j]);
		FOR(j, 0, len - 1) s[j] = '0' + '1' - s[j];
		ins(1 << i);
	}
	build();
	f[0][0][0] = 1;
	FOR(i, 1, m) FOR(j, 0, tot) FOR(k, 0, (1 << n) - 1) FOR(l, 0, 1)
	{
		int x = son[j][l], y = k | st[x];
		(f[i][x][y] += f[i - 1][j][k]) %= mod;
	}
	FOR(i, 0, tot) FOR(j, 0, (1 << n) - 1)
		if ((j | ca[i]) == (1 << n) - 1)
			(ans += f[m][i][j]) %= mod;
	printf("%d\n", ans);
	return 0;
}
