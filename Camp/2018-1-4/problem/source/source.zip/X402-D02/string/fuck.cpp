#include<iostream>
#include<cstdio>
#include<cstring>

namespace Bu_Neng_Guo_De_Ti
{
	typedef long long ll;
	const int N=5,M=102,L=22,MOD=998244353,I2=(MOD+1)/2;
	inline void inc(int a,int &b){b=(a+b)%MOD;}
	int f[M][1<<N][N][L][N][L];
	bool flag[N][N][L],okl[N][L],okr[N][L];

	char s[N][L];
	int len[N];
	int n,m,S;

	void okjudge(int i,int j)//is ok when i,j
	{
		if(j*2<len[i])okl[i][j]=0;
		else
		{
			okl[i][j]=1;
			for(int x=j+1;x<=len[i];x++)
				if(s[i][x]==s[i][j-(x-j)+1])okl[i][j]=0;
		}
		if(j*2>len[i])okr[i][j]=0;
		else 
		{
			okr[i][j]=1;
			for(int x=j;x;x--)
				if(s[i][x]==s[i][j+(j-x+1)])okr[i][j]=0;
		}
	}
	bool prejudge(int i,int j) //if s[i] is a substring of s[j]
	{
		if(len[i]>len[j])return 0;
		for(int pos=1;pos<=len[j]-len[i]+1;pos++)
		{
			bool flag=1;
			for(int x=1;x<=len[i];x++)
				flag&=(s[i][x]==s[j][pos+x-1]);
			if(flag)return 1;
		}
		return 0;
	}
	bool judge(int i,int j,int k)
	{
		if(len[i]<k)return 0;
		for(int x=1;x<=k;x++)
			if(s[i][len[i]-k+x]!=s[j][x])return 0;
		return 1;
	}
	bool isit(int i)
	{
		if(len[i]%2)return 0;
		for(int x=1;x<=len[i];x++)
			if(s[i][x]==s[i][len[i]-x+1])return 0;
		return 1;
	}
	bool fuck[N];
	void initialize()
	{
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)
			scanf("%s",s[i]+1),len[i]=strlen(s[i]+1);
		int tmp=n;n=0;
		for(int i=1;i<=tmp;i++)
		{
			bool flag=1;
			for(int j=1;j<=tmp;j++)
				if(i!=j && prejudge(i,j))
					flag=0;
			if(flag)
			{
				n++;
				strcpy(s[n]+1,s[i]+1);
				len[n]=len[i];
			}
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				for(int k=0;k<=len[j];k++)
					flag[i][j][k]=judge(i,j,k);
		for(int i=1;i<=n;i++)
		{
			flag[0][i][0]=1;
			flag[i][0][0]=1;
		}
		for(int i=0;i<=n;i++)
			for(int j=0;j<=len[i];j++)
				okjudge(i,j);

		okr[0][0]=1;

		for(int i=1;i<=n;i++)
			fuck[i]=isit(i);

		S=1<<n;
	}

	int dfs(int pos,int k,int il,int pl,int ir,int pr)
	{
		int &v=f[pos][k][il][pl][ir][pr];
		if(v>=0)return v;
		if(pos==m && k==S-1 && okl[il][pl] && okr[ir][pr])
		{
//			printf("?\n");

			v=1;
//			printf("?%d %d , %d %d , %d %d = %d\n",pos,k,il,pl,ir,pr,v);
			return v;
		}
		if(pos>m)return v=0;

		v=0;
		if(il && pl==len[il])
		{
			inc(dfs(pos,k,0,0,ir,pr),v);
			for(int i=1;i<=n;i++)
			{
				if(k&(1<<(i-1)))continue;
				for(int j=1;j<=len[i];j++)
					if(flag[il][i][j])
						inc(dfs(pos,k|(1<<(i-1)),i,j,ir,pr),v);
			}
		}
		else if(ir && !pr)
		{
			inc(dfs(pos,k,il,pl,0,0),v);
		}
		else 
		{
			if(!il)
			{
				for(int i=1;i<=n;i++)
				{
					if(k&(1<<(i-1)))continue;
					inc(dfs(pos,k|(1<<(i-1)),i,0,ir,pr),v);

					if(pos+k+il+pl+ir+pr==0)printf("L ADD %d %d %d %d %d %d ---- %d | v = %d\n",pos,k,il,pl,ir,pr,i,v);
				}
			}
			for(int i=1;i<=n;i++)
			{
				if(k&(1<<(i-1)))continue;
				if(flag[i][ir][pr])
				{
					inc(dfs(pos,k|(1<<(i-1)),il,pl,i,len[i]),v);
					if(pos+k+il+pl+ir+pr==0)printf("R ADD %d %d %d %d %d %d ---- %d | v = %d\n",pos,k,il,pl,ir,pr,i,v);
				}
			}

			if(!il && !ir)
			{
				if(pos+k+il+pl+ir+pr==0)printf("?\n");
				for(int i=1;i<=n;i++)
					for(int j=1;j<=n;j++)
						if(i!=j && !(k&(1<<(i-1))) && !(k&(1<<(j-1))))
						{
							inc(-dfs(pos,k|(1<<(i-1))|(1<<(j-1)),i,0,j,len[j]),v);
						}

				for(int i=1;i<=n;i++)
					if(fuck[i] && !(k&(1<<(i-1))))
					{
						inc(-dfs(pos,k|(1<<(i-1)),i,0,0,0),v);
//						if(pos+k+il+pl+ir+pr==0)printf("DEC %d %d %d %d %d %d ---- %d | v = %d\n",pos,k,il,pl,ir,pr,i,v);
					}
			}
			
			for(int x='0';x<='1';x++)
			{
				bool fl=(!il || s[il][pl+1]==x),fr=(!ir || s[ir][pr]==(x^1));
				if(!fl || !fr)continue;
				inc(dfs(pos+1,k,il,il?pl+1:0,ir,ir?pr-1:0),v);
			}
		}

		if(v)printf(":%d %d , %d %d , %d %d = %d\n",pos,k,il,pl,ir,pr,v);

		return v;
	}

	void solve()
	{
		initialize();
		memset(f,-1,sizeof(f));
		printf("%d\n",dfs(0,0,0,0,0,0));
	}
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	Bu_Neng_Guo_De_Ti::solve();
	return 0;
}
