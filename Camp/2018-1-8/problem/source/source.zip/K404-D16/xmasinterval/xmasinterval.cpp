#include <cstdio>
#include <algorithm>
#define F(x,y,z) for (x=y;x<=z;++x)
#define Min(x,y) x<y?x:y
#define lb(x) x&(-x)
using namespace std;
const int N=500500;					//!!!!!!!!!!!!!!!
const int Mod=1000000009;
int n,m,ans;
int f[N];
int a[N],b[N],s[N],t[N*20];
struct gsqq{
	int l,r;
	bool friend operator <(gsqq a,gsqq b)
		{return a.r==b.r?a.l<b.l:a.r<b.r;}
}d[N];

void Add(int x,int w){
	while (x<=n+1)
	{
		t[x]=(t[x]+w)%Mod;
		x+=lb(x);
	}
}

int Ask(int x){
	int ans=0;
	if (x==-1) return 0;
	while (x)
	{
		ans=(ans+t[x])%Mod;
		x-=lb(x);
	}
	return ans;
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	int i,j,k;
	scanf("%d%d",&n,&m);
	F(i,1,n) scanf("%d%d",&a[i],&b[i]);
	F(i,1,m) scanf("%d",&s[i]);
	sort(s+1,s+1+m);
	F(i,1,n){
		d[i].l=lower_bound(s+1,s+m+1,a[i])-s+1;
		d[i].r=upper_bound(s+1,s+m+1,b[i])-s;
	}
	sort(d+1,d+1+n);
	//F(i,1,n)printf("%d %d\n",d[i].l,d[i].r);
	f[1]++;Add(1,1);
	F(i,1,n) Add(d[i].r,Ask(d[i].r)-Ask(d[i].l-2));
	printf("%d\n",Ask(m+1)-Ask(m));
	return 0;
}


