#include <cstdio>

const int MAXN = 100000 + 10;
const int Mod = 998244353;
int N, cnt;
int A[MAXN], Divisor[MAXN];
bool visited[MAXN];
int used[MAXN];
long long f[MAXN];
long long ans;

inline int fastpow_mod( int a, int b ) {
	int x = 1;
	while( b ) {
		if( b & 1 ) x = ( 1ll * x * a ) % Mod;
		a = ( 1ll * a * a ) % Mod, b >>= 1;
	}
	return x;
}

inline void mark( int x ) {
	if( used[A[x]] ) {
		used[A[x]] = used[x] + 1;
		return;
	}
	used[A[x]] = used[x] + 1;
	mark( A[x] );
}

inline bool check() {
	register int i;
	for( i = 1; i <= N; ++i )
		used[i] = 0;
	for( i = 1; i <= N; ++i )
		if( !used[i] ) {
			used[i] = 1,
			mark( i );
			if( ( used[i] & 1 ) && used[i] != 1 )
				continue;
			return false;
		}
	return true;
}

inline bool check2() {
	register int i;
	for( i = 1; i <= N; ++i )
		used[i] = 0;
	for( i = 1; i <= N; ++i )
		if( A[i] == i )
			return false;
	for( i = 1; i <= N; ++i )
		if( !used[i] ) {
			used[i] = 1;
			mark( i );
			if( !( used[i] & 1 ) )
				return false;
		}
	return true;
}

inline void Dfs( int t ) {
	register int i;
	if( t == N + 1 ) {
		if( check() )
			++ans;
		return;
	}
	if( A[t] )
		return Dfs( t + 1 );
	for( i = 1; i <= N; ++i )
		if( !visited[i] )
			visited[i] = 1,
			A[t] = i,
			Dfs( t + 1 ),
			A[t] = 0,
			visited[i] = 0;
}

int main() {
	freopen( "permutation.in", "r", stdin );
	freopen( "permutation.out", "w", stdout );
	register int i;
	scanf( "%d", &N );
	for( i = 1; i <= N; ++i )
		scanf( "%d", A + i ), visited[A[i]] = 1, cnt += A[i] != 0;
	for( i = 1; i <= N; ++i )
		Divisor[i] = fastpow_mod( i, Mod - 2 );
	if( N <= 10 ) {
		Dfs( 1 );
		printf( "%lld\n", ans );
		return 0;
	}
	if( N & 1 )
		return 0 * puts( "0" );
	if( !check2() )
		return 0 * puts( "0" );
	f[1] = 1;
	for( i = 2; i <= N >> 1; ++i )
		f[i] = 1ll * ( ( i << 1ll ) - 1 ) * f[i - 1] % Mod;
	ans = 1ll * f[N >> 1] * f[N >> 1] % Mod;
	for( i = cnt; i; --i )
		ans = ( 1ll * ans * Divisor[N - i + !( i & 1 )] + Mod ) % Mod;
	printf( "%lld\n", ( ans + Mod ) % Mod );
	return 0;
}
