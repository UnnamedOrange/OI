#include<bits/stdc++.h>
using namespace std;
#define maxn 9007
int a[maxn],b[maxn];
bool vis[4500],ok1,ok2;
int n,m,k;
void readit(){
	cin>>n>>m>>k;
	int cnt=0;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if(vis[a[i]])continue;
		vis[a[i]]=1;cnt++;
	}
	if(cnt<k) ok1=1;
	memset(vis,0,sizeof(vis));
	cnt=0;
	for(int i=1;i<=m;i++){
		scanf("%d",&b[i]);
		if(vis[b[i]])continue;
		vis[b[i]]=1;cnt++;
	}
	if(cnt<k) ok2=1;
}
int dp[maxn][maxn];
void doit(){
	for(int i=n+1;i<=n+k;i++)
	a[i]=i-n;
	for(int i=m+1;i<=m+k;i++)
	b[i]=i-m;
	for(int i=1;i<=m;i++)
	if(b[i]==a[1]) {dp[1][i]=1;break;}
	for(int i=1;i<=n;i++)
	if(a[i]==b[1]) {dp[i][1]=1;break;}
	for(int i=1;i<=n+k;i++)
	for(int j=1;j<=m+k;j++){
		if(dp[i][j]) continue;
		int p=10086;
		for(int k=i-1;k;k--){
			for(int d=j-1;d;d--){
				p=min(p,dp[k][d]);
				if(b[d]==b[j]) break;	
			}
			if(a[i]==a[k]) break;
		}
		dp[i][j]=p+1;
	}
	int ans=10086;
	for(int i=n+1;i<=n+k;i++)
	for(int j=m+1;j<=m+k;j++)
	  ans=min(ans,dp[i][j]);
	cout<<ans<<endl; 
}
int main()
{
	freopen("Subsequence.in","r",stdin);
	freopen("Subsequence.out","w",stdin);
	readit();
	if(ok1&&ok2) cout<<"1"<<endl;
	//printf("no\n");
	doit();
	return 0;
} 
