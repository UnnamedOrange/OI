#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std ;

template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}

int ans,n,W,p,q,x[1001],y[1001],z[1001],a[1001],b[1001],c[1001],d[1001],f[1001],xx[1001],yy[1001],zz[1001];

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","r",stdin);
	int T;
	read(T);
	while(T--){
		read(n),read(W),read(p),read(q);
		for(int i=1;i<=p;i++) read(x[i]),read(y[i]),read(z[i]),read(a[i]),read(b[i]),read(c[i]),read(d[i]),read(f[i]);
		for(int i=1;i<=q;i++){
			read(xx[i]),read(yy[i]),read(zz[i]);
		}
		printf("%d\n",3);
	}
	return 0;
}
