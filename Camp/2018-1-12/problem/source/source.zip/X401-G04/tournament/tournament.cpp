/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
#define MODP 998244353
#define MOD(x) ((x)%MODP)
typedef long long LL;
	int n,k;
LL qpow(LL x,LL n)
{
	if (n==1) return x;
	LL t=qpow(x,n/2);
	t=MOD(t*t);
	if (n%2!=0) t=MOD(t*x);
	return t;
}
namespace bl
{
LL ans;
const int maxn=20;
bool a[maxn][maxn];
bool b[maxn];
bool dfs2(int now,int beg,int len)
{
	b[now]=false;
	for(int i=1; i<=n; ++i)
	{
		if (a[now][i])
		{
			if (i==beg && len==k) return true;
			if (b[i] && dfs2(i,beg,len+1)) return true;
		}
	}
	b[now]=true;
	return false;
}
void check()
{
	for(int i=1; i<=n; ++i)
	{
		memset(b,true,sizeof(a));
		if (dfs2(i,i,1))
		{
			ans++;
			return;
		}
	}
}
void dfs(int x,int y)
{
	if (x>=n)
	{
		return check();
	}
	if (y>n)
	{
		return dfs(x+1,x+2);
	}
	a[x][y]=true;
	a[y][x]=false;
	dfs(x,y+1);
	a[x][y]=false;
	a[y][x]=true;
	dfs(x,y+1);
}
LL main()
{
	ans=0;
	memset(a,false,sizeof(a));
	dfs(1,2);
	return ans;
}
}
namespace p3
{
LL main()
{
	LL ans=qpow(2,n*(n-1)/2);
	LL t=1;
	for(int i=1; i<=n; ++i)
	{
		t=MOD(t*i);
	}
	ans=MOD(ans+MODP-t);
	return ans;
}
}
int main()
{
#ifndef MDEBUG
    freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
#endif
	cin>>n>>k;
	LL ans;
	if (k==3) ans=p3::main();
	else ans=bl::main();
	cout<<ans<<endl;
    return 0;
}
