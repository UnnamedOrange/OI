#include <cstdio>
#include <cstdlib>
#include <process.h>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

int main()
{
    srand(_getpid()^(unsigned long long)new char);
    freopen("stone.in","w",stdout);
    int n=rand(1,8),mx=rand(1,20),a=rand(1,mx),b=rand(1,mx);
//    int n=1e5,mx=1e9,a=rand(1,mx),b=rand(1,mx);
    printf("%d %d %d\n",n,a,b);
    rep(i,1,n)
        printf("%d ",rand(1,mx));
    return 0;
}
