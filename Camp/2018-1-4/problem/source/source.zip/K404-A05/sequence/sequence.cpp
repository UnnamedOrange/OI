//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const ll mod=100000000000031ll;
const int hssz=1<<21;
const int msk=hssz-1;
struct hashtable
{
	ll key[hssz+5];
	int val[hssz+5];
	void init()
	{
		memset(key,-1,sizeof(key));
	}
	int geths(ll x){return (x+(x<<2))&msk;}
	int& get(ll x)
	{
		int p=geths(x);
		while(key[p]!=-1&&key[p]!=x)p=p+1>=hssz?0:p+1;
		if(key[p]==-1)key[p]=x,val[p]=0;
		return val[p];
	}
}hst;
int n;
struct state
{
	int a[25],d;
	void flip(int x)
	{
		for(int i=1;i<=(x>>1);i++)swap(a[i],a[x-i+1]);
	}
	ll geths()
	{
		ll hs=0;
		for(int i=1;i<=n;i++)hs=(hs*233+a[i])%mod;
		return hs;
	}
	int estimate()
	{
		int d=0;
		for(int i=1;i<n;i++)d+=abs(a[i]-a[i+1])!=1;
		return d+(a[n]!=n);
	}
	bool operator<(const state &t)const
	{
		return d<t.d;
	}
};
vector<state> st[105];
int Tn,a[25];
ll ths;
int solve()
{
	hst.init();
	state T;
	for(int i=1;i<=n;i++)T.a[i]=i;
	ths=T.geths();
	
	for(int i=0;i<100;i++)st[i].clear();
	state s;
	for(int i=1;i<=n;i++)s.a[i]=a[i];
	s.d=s.estimate();
	st[s.d].PB(s);
	int mn=0;
	while(mn<100&&st[mn].size()==0)mn++;
	while(st[mn].size())
	{
		state cur=st[mn][int(st[mn].size())-1];
		st[mn].resize(int(st[mn].size())-1);
		int &vs=hst.get(cur.geths());
		if(vs)
		{
			while(mn<100&&st[mn].size()==0)mn++;
			continue;
		}
		int cd=cur.d-cur.estimate();
//		for(int i=1;i<=n;i++)cerr<<cur.a[i]<<" ";cerr<<"d="<<cur.d<<" ";
//		cerr<<"cd="<<cd<<endl;
		if(cur.geths()==ths)return cd;
		vs=1;
		for(int i=2;i<=n;i++)
		{
			cur.flip(i);
			cur.d=cd+1+cur.estimate();
			if(cur.d<mn)
			{
				cerr<<"FUCK"<<endl;
			}
			st[cur.d].PB(cur);
			cur.flip(i);
		}
		while(mn<100&&st[mn].size()==0)mn++;
	}
	return -1;
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>Tn;
	while(Tn--)
	{
		cin>>n;
		for(int i=1;i<=n;i++)cin>>a[i];
		cout<<solve()<<endl;
	}
	return 0;
}
