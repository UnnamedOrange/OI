#include<algorithm>
#include<unistd.h>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<ctime>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
int id[30];

int main()
{
	freopen("sequence.in","w",stdout);
	srand(time(0)+getpid());
	int T=5,n=7;
	printf("%d\n",T);
	rep(i,1,T)
	{
		printf("%d\n",n);
		rep(j,1,n) id[j]=j;
		rep(j,1,100)
		{
			int x=rand()%n+1,y=rand()%n+1;
			swap(id[x],id[y]);
		}
		rep(j,1,n) printf("%d ",id[j]);
		puts("");
	}
}
