#include<bits/stdc++.h>
using namespace std;
const int INF=1e9;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
const int maxn=30010;
int a[21][21];
void putin(int s,int t){
	a[s][t]=1;
}
int dp[1<<20];
int popcnt[1<<20];
int w[maxn],r[maxn];
int n;
int solve(int rt){
	for(int i=0;i<(1<<n);i++)
		dp[i]=-INF;
	for(int i=1;i<(1<<n);i++)
		popcnt[i]=popcnt[i>>1]+(i&1);
	dp[1<<(rt-1)]=w[rt];
	bool bo;
	for(int i=0;i<(1<<n);i++){
		for(int j=0;j<n;j++){
			if(i&(1<<j)) continue;
			bo=0;
			for(int k=0;k<n;k++)
				bo|=(i&(1<<k))&&a[j+1][k+1];
			if(!bo) continue;
			chkmax(dp[i|(1<<j)],dp[i]+w[j+1]*(popcnt[i]+1));
		}
	}
	return dp[(1<<n)-1];
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("baoli.out","w",stdout);
	scanf("%d",&n);
	int s,t;
	for(int i=1;i<n;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	for(int i=1;i<=n;i++)
		scanf("%d%d",&w[i],&r[i]);
	int ans=0,v;
	for(int i=1;i<=n;i++){
		if(!r[i]) continue;
		v=solve(i);
		chkmax(ans,v);
	}
	printf("%d\n",ans);
	cerr<<ans<<endl;
	return 0;
}
