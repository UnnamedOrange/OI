#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#include<stdlib.h>
int all[110];
int main()
{
	int ac=0,wa=0;
	fr(i,1,1000)
	{
		system("./gen");
		system("./string");
		system("./string2");
		freopen("string.out","r",stdin);
		int a=read();
		all[a+2]++;
		freopen("string2.out","r",stdin);
		int b=read();
		if(a==b)
		{
//			printf("Accepted!(Answer: %d)\n",a);
			ac++;
		}
		else
		{
//			printf("Wrong Answer!QAQ(Answer %d,yours: %d)",a,b);
			wa++;
		}
	}
	printf("Accepted: %d\nWrong Answer: %d\n",ac,wa);
	printf("All:\n");
	fr(i,1,102)
		if(all[i])
			printf("%d:%d\n",i-2,all[i]);
	return 0;
}