#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int T,n,W,p,q,w[510],ans;
struct que
{
	int a,b,c,d,e,f,x,y,z;
}ask_[1010];
struct equ
{
	int type,x,y;
}limit_[1010];
bool pd()
{
	for(int i=1;i<=q;i++)
	{
		if(limit_[i].type==0 && w[limit_[i].x]>w[limit_[i].y]) return false;
		if(limit_[i].type==1 && w[limit_[i].x]!=w[limit_[i].y]) return false;
		if(limit_[i].type==2 && w[limit_[i].x]>=w[limit_[i].y]) return false;
	}
	return true;
}
int main()
{              
	
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d%d%d%d",&n,&W,&p,&q);
		memset(ask_,0,sizeof(ask_));
		memset(limit_,0,sizeof(limit_));
		ans=1e8;
		for(int i=1;i<=p;i++) 
		{
			scanf("%d%d%d",&ask_[i].x,&ask_[i].y,&ask_[i].z);
			scanf("%d%d%d",&ask_[i].a,&ask_[i].b,&ask_[i].c);
			scanf("%d%d%d",&ask_[i].d,&ask_[i].e,&ask_[i].f);
		}
		for(int i=1;i<=q;i++) 
		{
			scanf("%d%d%d",&limit_[i].x,&limit_[i].y,&limit_[i].type);
		}
		for(int i=1;i<(1<<n);i++)
		{
			int tmp=0;
			for(int j=1;j<=n;j++)
			{
				if(i&(1<<(j-1))) w[j]=W;
				else w[j]=-W;
				tmp+=w[j];
			}
			if(!pd()) continue;
			for(int j=1;j<=p;j++)
			{
				tmp+=ask_[j].a*abs(w[ask_[j].x]-w[ask_[j].y]);
				tmp+=ask_[j].b*abs(w[ask_[j].y]-w[ask_[j].z]);
				tmp+=ask_[j].c*abs(w[ask_[j].z]-w[ask_[j].x]);
				tmp+=ask_[j].d*(w[ask_[j].x]-w[ask_[j].y]);
				tmp+=ask_[j].e*(w[ask_[j].y]-w[ask_[j].z]);
				tmp+=ask_[j].f*(w[ask_[j].z]-w[ask_[j].x]);
			}
			ans=min(ans,tmp);
		}
		printf("%d\n",ans);
	}
	return 0;
}

