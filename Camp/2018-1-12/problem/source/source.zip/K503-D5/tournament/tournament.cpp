#include <cstdio>
#define ll long long
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=1e5+5,mod=998244353;
int n,k,i,ans,fac[N];
int quickmi(int a,ll n)
{
	int ret=1,bsc=a;
	for (;n>0;n>>=1,bsc=(ll)bsc*bsc%mod)
	  if (n&1) ret=(ll)ret*bsc%mod;
	return ret;
}
void Large_Circle()
{
	ans=(ll)fac[n-1]*quickmi(2,(ll)n*(n-1)/2-n)%mod;
	printf("%d\n",ans);
}
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	fac[1]=1;
	rep(i,2,n) fac[i]=((ll)fac[i-1]*i)%mod;
	if (k==n) Large_Circle();
	else {
		
	}
	return 0;
}
