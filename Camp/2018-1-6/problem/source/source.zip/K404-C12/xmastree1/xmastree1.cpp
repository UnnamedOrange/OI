#include <algorithm>
#include <iostream>
#include <cstring>
#include <utility>
#include <cstdio>
#include <set>
#define mp make_pair
using namespace std;
int lst[100005], to[200005], pre[200005], tot; 
int st[100005], en[100005], fa[100005][25], t; 
int col[100005], seq[100005], dep[100005], n, q, T; 
int t_cnt, rt[100005], lson[40000005], rson[40000005], sum[40000005]; 
set<int> app[100005]; 
inline int getint()
{
	int ch = getchar(), res = 0; 
	for (; ch < 48; ch = getchar()); 
	for (; ch >= 48; ch = getchar())
		res = res * 10 + ch - 48; 
	return res; 
}
inline void add_edge(int u, int v)
{
	to[tot] = v; 
	pre[tot] = lst[u]; 
	lst[u] = tot++; 
}
void dfs(int u, int f = -1)
{
	seq[t] = u; 
	st[u] = t++; 
	fa[u][0] = f; 
	for (int i = 1; i < 20; i++)
		fa[u][i] = fa[u][i - 1] == -1 ? -1 : fa[fa[u][i - 1]][i - 1]; 
	for (int i = lst[u]; ~i; i = pre[i])
	{
		if (to[i] == f)
			continue; 
		dep[to[i]] = dep[u] + 1; 
		dfs(to[i], u); 
	}
	en[u] = t - 1; 
}
inline int lca(int u, int v)
{
	if (dep[u] > dep[v])
		swap(u, v); 
	for (int i = 0; i < 20; i++)
	{
		if (dep[v] - dep[u] & (1 << i))
			v = fa[v][i]; 
	}
	if (u == v)
		return u;
	for (int i = 19; i >= 0; i--)
	{
		if (fa[u][i] != fa[v][i])
		{
			u = fa[u][i]; 
			v = fa[v][i]; 
		}
	}
	return fa[u][0]; 
}
inline void modify(int &u, int l, int r, int pos, int x)
{
	if (!u)
		u = ++t_cnt; 
	if (l == r)
	{
		sum[u] += x; 
		return; 
	}
	int m = l + r >> 1; 
	if (pos <= m)
		modify(lson[u], l, m, pos, x); 
	else
		modify(rson[u], m + 1, r, pos, x); 
	sum[u] = sum[lson[u]] + sum[rson[u]]; 
}
int query(int u, int l, int r, int L, int R)
{
	if (!u)
		return 0; 
	if (L <= l && r <= R)
		return sum[u]; 
	int m = l + r >> 1, res = 0; 
	if (L <= m)
		res += query(lson[u], l, m, L, R); 
	if (m < R)
		res += query(rson[u], m + 1, r, L, R); 
	return res; 
}
inline void modify(int pos, int x, int y)
{
	for (; pos <= n; pos += pos & -pos)
		modify(rt[pos], 0, n - 1, x, y);
}
inline int query(int pos, int l, int r)
{
	int res = 0; 
	for (; pos; pos -= pos & -pos)
		res += query(rt[pos], 0, n - 1, l, r); 
	return res; 
}
inline void del(int u)
{
	int x = col[u]; 
	set<int> &se = app[x]; 
	modify(x, st[u], -1); 
	se.erase(st[u]); 
	set<int>::iterator r = se.lower_bound(st[u]), l = r; 
	if (r != se.end())
		modify(x, st[lca(u, seq[*r])], 1); 
	if (l != se.begin())
	{
		l--; 
		modify(x, st[lca(u, seq[*l])], 1);
		if (r != se.end())
			modify(x, st[lca(seq[*l], seq[*r])], -1);
	}
}
inline void add(int u)
{
	int x = col[u]; 
	set<int> &se = app[x]; 
	modify(x, st[u], 1); 
	set<int>::iterator r = se.lower_bound(st[u]), l = r; 
	if (r != se.end())
		modify(x, st[lca(u, seq[*r])], -1); 
	if (l != se.begin())
	{
		l--; 
		modify(x, st[lca(u, seq[*l])], -1);
		if (r != se.end())
			modify(x, st[lca(seq[*l], seq[*r])], 1);
	}
	se.insert(st[u]); 
}
int main()
{
	freopen("xmastree1.in", "r", stdin); 
	freopen("xmastree1.out", "wt", stdout); 
	n = getint();
	q = getint();
	T = getint(); 
	memset(lst, -1, sizeof(lst)); 
	for (int i = 0; i < n; i++)
		col[i] = getint(); 
	for (int i = 1; i < n; i++)
	{
		int u = getint(), v = getint(); 
		add_edge(--u, --v); 
		add_edge(v, u);
	}
	dfs(0);
	for (int u = 0; u < n; u++)
		add(u); 
	int ans = 0; 
	while (q--)
	{
		int tp = getint(); 
		if (tp - 1)
		{
			int u = getint(), c = getint(); 
			if (T)
			{
				u ^= ans; 
				c ^= ans;
			}
			u--; 
			del(u); 
			col[u] = c; 
			add(u); 
		}
		else
		{
			int u = getint(), l = getint(), r = getint(); 
			if (T)
			{
				u ^= ans; 
				l ^= ans; 
				r ^= ans;
			}
			u--; 
			printf("%d\n", ans = query(r, st[u], en[u]) - query(l - 1, st[u], en[u])); 
		}
	}
	return 0; 
}

