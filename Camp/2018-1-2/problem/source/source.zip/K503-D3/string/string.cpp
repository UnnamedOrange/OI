#include <cstdio>

char s[(int)1e5+10];

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int t; scanf("%d",&t);
	while (t--){
		int n; scanf("%d%s",&n,s);
		bool mark1=true,mark2=true;
		for (int i=0;i<n;i++){
			if (s[i]!=s[n-i-1]) mark1=false;
			if (i>1&&s[i]!=s[i-2]) mark2=false;
		}
		printf("%d\n",mark1?mark2?-1:2:1);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

