#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("string.in","r",stdin);
		freopen("string.out","w",stdout);
	#endif
}
int n,m;
char s[N];
void input()
{
	n=read<int>();
	scanf("%s",s+1);
}
int sum[30];
bool flag;
bool check()
{
	int num=0;
	For(i,0,25)if(sum[i])num++;
	if(num>2)return 0;
	For(i,1,m)if(s[i]==s[i+1])return 0;	
	return 1;
}
void work()
{
	memset(sum,0,sizeof sum);
	m=n/2;flag=0;
	For(i,1,m)if(s[i]!=s[n-i+1]){flag=1;break;}
	if(!flag)
	{
		For(i,1,n)sum[s[i]-'a']++;
		if(sum[s[1]-'a']==n)printf("%d\n",-1);              
		else if(n%2==1&&sum[s[1]-'a']==n-1)printf("%d\n",-1);
		else if(n%2==1&&check())printf("%d\n",-1);
		else printf("%d\n",2);
	}
	else printf("%d\n",1);
}
int main()
{
	file();
	int T=read<int>();
	while(T--)
	{
		input();
		work();
	}
	return 0;
}
