#include <bits/stdc++.h>

namespace {

inline char read() {
    static const int IN_LEN = 1 << 18 | 1;
    static char buf[IN_LEN], *s, *t;
    return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
            s == t ? -1 : *s++;
}

template <typename T>
inline void read(T &x) {
    static char c;
    static bool iosig;
    for (c = read(), iosig = false; !isdigit(c); c = read()) {
        if (c == -1) return;
        iosig |= c == '-';
    }
    for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
    iosig && (x = -x);
}

inline int read(char *buf) {
    register int s = 0;
    register char c;
    while (c = read(), isspace(c) && c != -1)
        ;
    if (c == -1) {
        *buf = 0;
        return -1;
    }
    do
        buf[s++] = c;
    while (c = read(), !isspace(c) && c != -1);
    buf[s] = 0;
    return s;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
    (oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
    *oh++ = c;
}

template <typename T>
inline void print(T x) {
    static int buf[21], cnt;
    if (x != 0) {
        (x < 0) && (print('-'), x = -x);
        for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
        while (cnt) print((char)buf[cnt--]);
    } else {
        print('0');
    }
}

inline void print(const char *s) {
    for (; *s; s++) print(*s);
}

struct InputOutputStream {
    ~InputOutputStream() {
        fwrite(obuf, 1, oh - obuf, stdout);
    }

    template <typename T>
    inline InputOutputStream &operator>>(T &x) {
        read(x);
        return *this;
    }

    template <typename T>
    inline InputOutputStream &operator<<(const T &x) {
        print(x);
        return *this;
    }
} io;

const int MAXN = 1000000 + 9;

struct Graph {
    std::vector<int> edge[MAXN];

    inline void addEdge(const int u, const int v) {
        edge[u].push_back(v);
    }

    inline std::vector<int> &operator[](const int i) {
        return edge[i];
    }
} g, newG;

bool vis[MAXN];

int sz[MAXN], scc[MAXN], low[MAXN], dfn[MAXN];
int idx, n, m, in[MAXN], ans, dep[MAXN], cnt;

void tarjan(const int u) {
    static std::vector<int> st;
    st.push_back(u);
    dfn[u] = low[u] = ++idx;
    vis[u] = true;
    register int v;
    for (register int i = 0; i < (int)g[u].size(); i++) {
        if (!dfn[v = g[u][i]]) {
            tarjan(v);
            low[u] = std::min(low[u], low[v]);
        } else if (vis[v]) {
            low[u] = std::min(low[u], dfn[v]);
        }
    }
    if (low[u] == dfn[u]) {
        cnt++;
        do {
            vis[v = st.back()] = false;
            scc[v] = cnt;
            sz[cnt]++;
            st.pop_back();
        } while (u != v);
    }
}

inline void build() {
    for (register int i = 1; i <= n; i++)
        if (!dfn[i]) tarjan(i);
    for (register int i = 1; i <= n; i++) {
        for (register int j = 0, v; j < (int)g[i].size(); j++) {
            if (scc[i] != scc[v = g[i][j]]) {
                newG.addEdge(scc[i], scc[v]);
                in[scc[v]]++;
            }
        }
    }
}

inline void toposort() {
    static std::vector<int> q;
    q.reserve(n);
    for (register int i = 1; i <= cnt; i++)
        if (in[i] == 0) q.push_back(i);
    for (register int u; !q.empty();) {
        u = q.back();
        q.pop_back();
        dep[u] += sz[u];
        ans = std::max(ans, dep[u]);
        for (register int i = 0, v; i < (int)newG[u].size(); i++) {
            if (--in[v = newG[u][i]] == 0) q.push_back(v);
            dep[v] = std::max(dep[v], dep[u]);
        }
    }
}

inline void solve() {
    io >> n >> m;
    for (register int i = 1, u, v; i <= m; i++) {
        io >> u >> v;
        g.addEdge(u, v);
    }
    build();
    toposort();
    io << ans;
}
}

int main() {
    freopen("bomb.in", "r", stdin);
    freopen("bomb.out", "w", stdout);
    solve();
    return 0;
}