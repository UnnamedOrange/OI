#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
using namespace std;
const int M=(int)3e4+5;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
struct W{
	int to,nx;
}Lis[M*2];
int Head[M],tot;
void Add(int x,int y){
	Lis[++tot]=(W){y,Head[x]};
	Head[x]=tot;
}
int n;
int w[M],r[M];
struct SHUI{
	int ans;
	int S;
	int rS;
	int bin[12],dui[(1<<12)];
	void dfs(int x,int v,int d){
		int SS=S;
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)S|=bin[to];
		if(d>n){
			if(v>ans)ans=v;
			return;
		}
		int SSS=S^rS;
		while(SSS){
			x=SSS&(-SSS);
			SSS^=x;
			x=dui[x];
			rS^=bin[x];
			dfs(x,v+w[x]*d,d+1);
			rS^=bin[x];
		}
		S=SS;
	}
	void solve(){
		for(int i=1;i<=n;i++)dui[bin[i]=(1<<i)]=i;
		for(int i=1;i<=n;i++)if(r[i])S=rS=bin[i],dfs(i,w[i],2);
		printf("%d\n",ans);
	}
}P10;
struct IHSU{
	int ans;
	int a[1005][1005];
	int len[1005];
	int dp[1005][1005];
	int fr[1005][1005];
	int tp[1005];
	void dfs(int x,int f){
		len[x]=0;
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(to!=f){
				dfs(to,x);
				int lx=len[x],lto=len[to];
				for(int j=0;j<=lx;j++)
					for(int k=0;k<=lto;k++)
						dp[j][k]=0;
				for(int j=0,tmp;j<=lx;j++)
					for(int k=0;k<=lto;k++){
						if(j!=lx){
							tmp=dp[j][k]+(j+k+1)*a[x][j+1];
							if(tmp>dp[j+1][k])dp[j+1][k]=tmp,fr[j+1][k]=0;
						}
						if(k!=lto){
							tmp=dp[j][k]+(j+k+1)*a[to][k+1];
							if(tmp>dp[j][k+1])dp[j][k+1]=tmp,fr[j][k+1]=1;
						}
					}
				len[x]+=len[to];
				for(int q=lx,w=lto,t=len[x];q||w;){
					if(fr[q][w])tp[t--]=a[to][w--];
					else tp[t--]=a[x][q--];
				}
				for(int j=1;j<=len[x];j++)a[x][j]=tp[j];
			}
		len[x]++;
		for(int i=len[x];i>1;i--)a[x][i]=a[x][i-1];
		a[x][1]=w[x];
	}
	void solve(){
		for(int i=1;i<=n;i++)
			if(r[i]){
				dfs(i,i);
				int tmpans=0;
				for(int j=1;j<=n;j++)tmpans+=a[i][j]*j;
				if(tmpans>ans)ans=tmpans;
			}
		printf("%d\n",ans);
	}
}P30;
struct HUSI{
	priority_queue<pair<int,int> >q;
	long long ans;
	int fa[M],deg[M];
	void dfs(int x,int f){
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(to!=f){
				dfs(to,x);
				deg[x]++;
			}
	}
	void solve(){
		for(int i=1;i<=n;i++)
			if(r[i]){
				long long tmp=0;
				q.push(pair<int,int>(-w[i],i));
				pair<int,int>tp;
				int x,c=0;
				fa[i]=0;
				while(!q.empty()){
					c++;
					tp=q.top();q.pop();
					x=tp.second;
					tmp+=c*w[x];
					for(int j=Head[x],to;j&&(to=Lis[j].to,1);j=Lis[j].nx)
						if(to!=fa[x])
							fa[to]=x,q.push(pair<int,int>(-w[to],to));
				}
				if(tmp>ans)ans=tmp;
				tmp=0,c=n+1;
				for(int j=1;j<=n;j++)deg[j]=0;
				dfs(i,i);
				for(int j=1;j<=n;j++)if(deg[j]==0)q.push(pair<int,int>(w[j],j));
				while(!q.empty()){
					c--;
					tp=q.top();q.pop();
					x=tp.second;
					tmp+=c*w[x];
					if(deg[fa[x]]--==1)q.push(pair<int,int>(w[fa[x]],fa[x]));
				}
				if(tmp>ans)ans=tmp;
			}
		printf("%lld\n",ans);
	}
}PPP;
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	Rd(n);
	for(int i=1,x,y;i<n;i++)Rd(x),Rd(y),Add(x,y),Add(y,x);
	for(int i=1;i<=n;i++)Rd(w[i]),Rd(r[i]);
//	if(0);
	if(n<=10)P10.solve();
	else if(n<=1000)P30.solve();
	else PPP.solve();
	return 0;
}
