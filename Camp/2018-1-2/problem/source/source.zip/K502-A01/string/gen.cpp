#include <bits/stdc++.h>
using namespace std;
int A[10001];
int main()
{
	freopen("string.in", "w", stdout);
	int T = 20;
	cout<<T<<endl;
	srand(time(0));
	while (T--)
	{
	int N = rand()%15 + 1;
	cout<<N<<endl;
	for (int i = 1; i <= N / 2; ++i)
		A[i] = rand()%3, printf("%c", A[i] + 'a');
	if (N % 2)
		printf("%c", A[1] + 'a');
	for (int i = N / 2; i >= 1; --i)
		printf("%c", A[i] + 'a');
	cout<<endl;
	}
	return 0;
}
