#include<bits/stdc++.h>
using namespace std;
struct node{int x,y,z,a,b,c,d,e,f,h;}f[1000];
int T,n,p,q,W,w[1000],x[1000],y[1000],r[1000],ans;
void calc(int t){
	f[t].h=f[t].a*abs(w[f[t].x]-w[f[t].y])+f[t].b*abs(w[f[t].y]-w[f[t].z])+f[t].c*abs(w[f[t].z]-w[f[t].x])+
		f[t].d*(w[f[t].x]-w[f[t].y])+f[t].e*(w[f[t].y]-w[f[t].z])+f[t].f*(w[f[t].y]-w[f[t].z]);
}
bool check(){
	for (int i=1;i<=q;i++){
		if (r[i]==0) {if (w[x[i]]>w[y[i]]) return false;}
		if (r[i]==1) {if (w[x[i]]!=w[y[i]]) return false;}
		if (r[i]==2) {if (w[x[i]]>=w[y[i]]) return false;}
	}
	return true;
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
scanf("%d",&T);
while (T--){
	scanf("%d %d %d %d",&n,&W,&p,&q);
	ans=0x3f3f3f3f;
	for (int i=1;i<=p;i++)
	scanf("%d %d %d %d %d %d %d %d %d",&f[i].x,&f[i].y,&f[i].z,&f[i].a,&f[i].b,&f[i].c,&f[i].d,&f[i].e,&f[i].f);
	for (int i=1;i<=q;i++)
	scanf("%d %d %d",x+i,y+i,r+i);
	for (int i=0;i<(1<<n);i++){
		int now=0;
		for (int j=1;j<=n;j++)
		if (1<<(j-1)&i) w[j]=-W; else w[j]=W;
		if (!check()) continue;
		for (int j=1;j<=p;j++){calc(j);now+=f[j].h;}
		for (int j=1;j<=n;j++) now+=w[j];
		ans=min(now,ans);
	}
	printf("%d\n",ans);
}
	return 0;
}
