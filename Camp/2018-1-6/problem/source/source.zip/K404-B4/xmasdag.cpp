#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <cstring>
#define getchar() *(pp++)
#define MOD 998244353
using namespace std;
char buf[1000100],*pp=buf;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
struct edge
{
	int v,p;
}e[200010];
int n,m,top,head[100010],k,topo[100010],deg[100010],po[200010],d[2][100010];
long long ret[100010];
inline addedge(int u,int v)
{
	deg[v]++;
	e[++top]=(edge){v,head[u]};
	head[u]=top;
}
void toposort()
{
	int cnt=0;
	queue<int> q;
	q.push(1);
	while(!q.empty())
	{
		int u=q.front();
		topo[++cnt]=u;
		q.pop();
		for(int i=head[u];i;i=e[i].p)
		{
			deg[e[i].v]--;
			if(!deg[e[i].v])
			{
				q.push(e[i].v);
			}
		}
	}
}
inline int qpow(long long x,int y)
{
	long long ans=1;
	while(y)
	{
		if(y&1)ans=ans*x%MOD;
		x=x*x%MOD;
		y>>=1;
	}
	return ans;
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	fread(buf,1000000,1,stdin);
	n=read();
	m=read();
	k=read();
	for(int i=1;i<=m;i++)
	{
		int u=read(),v=read();
		addedge(u,v);
	}
	for(int i=1;i<m;i++)
	{
		po[i]=qpow(i,k);
	}
	toposort();
	d[0][1]=1;
	for(int i=0,cur=0;i<m;i++,cur^=1)
	{
		memset(d[cur^1],0,sizeof(d[cur^1]));
		for(int j=n;j;j--)
		{
			int u=topo[j];
//			cout<<i<<' '<<u<<' '<<d[cur][u]<<endl;
			ret[u]=(ret[u]+1LL*d[cur][u]*po[i])%MOD;
			for(int k=head[u];k;k=e[k].p)
			{
				d[cur^1][e[k].v]=(d[cur^1][e[k].v]+d[cur][u])%MOD;
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		cout<<ret[i]<<endl;
	}
	return 0;
}
