#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
typedef unsigned long long ull;
const int INF=1e9;
const int N=30;
const int base=37;
int a[N],c[N];int vis[N];
int n;int ans;
int totans;
map<ull,int> mp1,mp2;
int lim;

bool check(){
	int i;
	rep(i,1,n)	if(a[i]!=i)	return false;
	return true;
}

void dfs(int now,int last){
	int i;
	if(now==lim+1){
		if(check())	ans=min(ans,lim);
		return;
	}
	for(i=2;i<=n&&ans==INF;i++) if(i!=last){
		reverse(a+1,a+1+i);
		dfs(now+1,i);
		reverse(a+1,a+1+i);
	}
}

void H(int w,int id){
	int i;ull x=0;
	//rep(i,1,n)	printf("%d ",a[i]);printf("\n");
	rep(i,1,n)	x=x*base+a[i];
	if(id==1){
		if(!mp1[x])	mp1[x]=w;
		else mp1[x]=min(mp1[x],w);
	}
	else{
		if(!mp2[x])	mp2[x]=w;
		else mp2[x]=min(mp2[x],w);
	}
}	

void work(int now,int last,int id){
	int i;
	H(now-1,id);
	if(now==lim+1)	return;
	for(i=2;i<=n;i++) if(i!=last){
		reverse(a+1,a+1+i);
		work(now+1,i,id);
		reverse(a+1,a+1+i);
	}
}

int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int i;int T;int k1,k2;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		if(n<=8){						
			ans=n+1;
			rep(i,1,n)	scanf("%d",&a[i]);
			rep(i,0,n) {lim=i;dfs(1,0);if(ans!=INF)	break;}
			printf("%d\n",ans);
		}
		else{
			ans=n+1;
			rep(i,1,n)	scanf("%d",&a[i]);
			rep(i,0,2) {lim=i;dfs(1,0);if(ans!=INF)	break;}
			if(ans!=n+1){printf("%d\n",ans);continue;}
			//printf("%d\n",ans);
			mp1.clear();mp2.clear();
			k1=n/2;k2=n-k1;
			lim=k1;
			work(1,0,1);
			rep(i,1,n)	a[i]=i;
			lim=k2;
			work(1,0,2);
			map<ull,int>::iterator it;
			for(it=mp1.begin();it!=mp1.end();it++)	if(mp2[it->first]){
				//printf("ok ");printf("%llu %d %d\n",it->first,it->second,mp2[it->first]);
				ans=min(ans,it->second+mp2[it->first]);
			}
			printf("%d\n",ans);
		}
	}
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
