#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 100010
using namespace std;
int n,ned[3],w[maxn],v[maxn],cnt,ans[5];
void make(int x){
	int pos=0;
	while(x){
		pos++;
		if(x&1)v[++cnt]=w[pos];
		x>>=1;
	}
}
int dfs1(int who){
	int res=0,flag=0;
	for(int i=1;i<=cnt;i++){
		if(v[i]>=ned[who]){
			v[i]-=ned[who];
			res|=dfs1(!who);//���� 
			flag=1;
			v[i]+=ned[who];
		}
	}
	if(who==1){
		if(flag)return res;
		else return 0;//���� 
	}
	else {
		if(flag)return !res;
		else return 1;//���� 
	}
}
int dfs2(int who){
	int res=0,flag=0;
	for(int i=1;i<=cnt;i++){
		if(v[i]>=ned[who]){
			v[i]-=ned[who];
			res|=dfs1(!who);//���� 
			flag=1;
			v[i]+=ned[who];
		}
	}
	if(who==0){
		if(flag)return res;
		else return 0;//���� 
	}
	else {
		if(flag)return !res;
		else return 1;//���� 
	}
}
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("stone.in","r",stdin);freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&ned[1],&ned[2]);
	for(int i=1;i<=n;i++)scanf("%d",&w[i]);
	for(int i=0;i<(1<<n);i++){
		cnt=0;
		make(i);
		int s1=0,s2=0;
		s1=dfs1(1);//Alice���� 
		s2=dfs2(0);//Bob���� 
		if(s1&&!s2)ans[1]++;//Alice��ʤ 
		if(!s1&&s2)ans[2]++;//Bob��ʤ 
		if(s1&&s2)ans[3]++;//���ֱ�ʤ 
		if(!s1&&!s2)ans[4]++;//���ֱ�ʤ 
	}
	for(int i=1;i<=4;i++)printf("%d ",ans[i]);
	return 0;
}
