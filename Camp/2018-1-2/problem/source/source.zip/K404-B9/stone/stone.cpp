#include<bits/stdc++.h>
#define maxn 1000000007
using namespace std;

int n,x[100010];
long long a,b;
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%lld%lld",&n,&a,&b);
	for (int i=1;i<=n;i++) scanf("%d",&x[i]);
	if (a==b)
	  {
	  	int num[2]={0,0};
		long long ans[2]={1,1};
	  	printf("0 0 ");
	  	for (int i=1;i<=n;i++) num[(x[i]/a)%2]++;
	  	for (int i=1;i<=num[0];i++) 
		  {
		  	ans[0]*=2;
		  	if (ans[0]>maxn) ans[0]=ans[0]%maxn;
		  }
		int all=ans[0];
		for (int i=1;i<=num[1];i++)
		  {
		  	all*=2;
		  	if (all>maxn) all=all%maxn;
		  }
	  	int m=num[1]/2,l=1;
	  	for (int i=0;i<m*2;i+=2)
	  	  {
	  	  	l=(l*(num[1]-i)*(num[1]-(i+1))/(i+1)/(i+2))%maxn;
	  	  	ans[1]+=l;
		  }
		ans[1]=ans[1]%maxn;
		int emm=ans[0]*ans[1]%maxn;
		printf("%d %d",emm,all-emm);
	  }
//	if (a==1)
//	  {
//	  	long long c=a+b;
//	  	long long num[4]={0,0,0,0},ans[3]={0,0,0};
//	  	for (int i=1;i<=n;i++)
//		  {
//		  	if (x[i]%c&&x[i]%c!=b) num[0]++;
//		  	if (x[i]%c==b) num[1]++;
//		  	if (!x[i]%c) num[(x[i]/c)%2+2]++;
//		  } 
//		long long l=1,emm=1,em=num[1],xx=0;
//		for (int i=1;i<num[1];i++)
//		  {
//		  	em=em*(num[1]-i)/(i+1)%maxn;
//		  	xx+=em;
//		  }
//		for (int i=1;i<=n-num[1];i++)
//		  {
//		  	emm*=2;
//		  	if (emm>maxn) emm=emm%maxn;
//		  } 
//		xx=xx*emm%maxn;  
//		emm=1;
//		for (int i=0;i<num[0];i++)
//		  {
//		  	l=l*(num[0]-i)/(i+1)%maxn;
//		  	ans[0]+=l;
//		  }  
//		for (int i=1;i<=n-num[0];i++)
//		  {
//		  	emm*=2;
//		  	if (emm>maxn) emm=emm%maxn;
//		  }
//		ans[0]=(ans[0]*emm+xx)%maxn;   
//		printf("%d 0 ",ans[0]);
//		 
//	  }  
	return 0;
}
