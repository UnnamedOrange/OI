#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=1e5+5,mod=1e9+7;
int a[maxn],b[maxn];
int alice[maxn],bob[maxn],first[maxn],last[maxn];
int cp(int s){
	if(s==0) return 0;
	int ans=1;
	for(int i=1;i<=s;i++) ans=ans*i%mod;
	return ans%mod;
}
int hehe(int x){
	int ans=1;
	for(int i=1;i<=x;i++) ans*=2;
	return ans;
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int n,x,y;
	scanf("%d%d%d",&n,&x,&y);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		int num=a[i]%(x+y);
		if(x<y){
			if(num<x) last[i]++;
			if(num>=y) first[i]++;
			if(num>=x&&num<y) alice[i]++;
		}
		if(x>y){
			if(num<y) last[i]++;
			if(num>=x) first[i]++;
			if(num>=y&&num<x) bob[i]++;
		}
		if(x==y){
			if(num<y) last[i]++;
			if(num>=x) first[i]++;
		}
	}
	int aa,bb,cc,dd;
	aa=bb=cc=dd=0;
	for(int i=1;i<=n;i++){
		aa+=alice[i];
		bb+=bob[i];
		cc+=first[i];
		dd+=last[i];
	}
	int z=cp(aa);
	int xx=cp(bb);
	int c=cp(cc);
	int v=cp(dd);
	int l=0;
	while(z+x+c+v<hehe(n)){
		if(x==y){
			if(c>=v) c++;
			else v++;
		}
		else{
			if(l%4==0) z++;
			if(l%4==1) xx++;
			if(l%4==2) c++;
			if(l%4==3) v++;
		}
		l++;
	}
//	printf("%d %d %d %d\n",aa,bb,cc,dd);
	printf("%d %d %d %d\n",z,xx,c,1+v);
}
