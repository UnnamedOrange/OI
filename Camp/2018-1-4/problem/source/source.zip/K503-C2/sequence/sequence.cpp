#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#define maxn 25
int a[maxn],d[4000000],q[4000000],t,n,i,j,k,l,r,x;
long long num[4000000],s;
bool mark[4000000],b[maxn];
int cmp(const void *a,const void *b)
{
	return *(long long *)a-*(long long *)b;
}
void work(int x)
{
	int i;
	if (x==n)
	{
		long long s=0;
		for (i=0;i<n;i++)
			s=s*10LL+(long long)(a[i]-1);
		num[k++]=s;
		return;
	}
	for (i=1;i<=n;i++)
		if (b[i])
		{
			a[x]=i;
			b[i]=false;
			work(x+1);
			b[i]=true;
		}
}
void swap(int &x,int &y)
{
	int t=x;
	x=y;
	y=t;
}
int find(long long x)
{
	int l=0,r=k-1,m=(l+r)/2;
	for (;l<=r;m=(l+r)/2)
		if (num[m]>x) r=m-1;
			else if (num[m]<x) l=m+1;
				else return m;
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	for (scanf("%d",&t);t>0;t--)
	{
		scanf("%d",&n);
		memset(b,true,sizeof(b));
		k=0;
		work(0);
		memset(mark,true,sizeof(mark));
		s=0;
		for (i=0;i<n;i++)
		{
			scanf("%d",&x);
			s=s*10LL+(long long)(x-1);
		}
		q[0]=find(s);
		d[q[0]]=0;
		memset(mark,true,sizeof(mark));
		mark[q[0]]=false;
		for (l=r=0;l<=r;l++)
		{
			s=num[q[l]];
			for (i=n-1;i>=0;i--)
			{
				a[i]=s%10+1;
				s/=10;
			}
			for (i=1;i<n;i++)
			{
				for (j=0;j<=i/2;j++)
					swap(a[j],a[i-j]);
				s=0;
				for (j=0;j<n;j++)
					s=s*10LL+(long long)(a[j]-1);
				s=find(s);
				if (mark[s])
				{
					q[++r]=s;
					mark[s]=false;
					d[s]=d[q[l]]+1;
				}
				for (j=0;j<=i/2;j++)
					swap(a[j],a[i-j]);
				if (!s) break;
			}
			if (!mark[0]) break;
		}
		printf("%d\n",d[0]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
