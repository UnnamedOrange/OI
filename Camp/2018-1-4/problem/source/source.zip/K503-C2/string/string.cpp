#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define maxn 1010
#define modn 998244353
char str[maxn],s[10][maxn];
int n,m,i;
bool check(char s1[],char s2[])
{
	int i,j,len1=strlen(s1),len2=strlen(s2);
	for (i=0;i<=len1-len2;i++)
	{
		for (j=0;j<len2;j++)
			if (s1[i+j]!=s2[j]) break;
		if (j==len2) return true;
	}
	return false;
}
int work(int x)
{
	int i,ans=0;
	if (x==m)
	{
		for (i=m;i<m*2;i++)
			str[i]='0'+'1'-str[2*m-1-i];
		for (i=0;i<n;i++)
			if (!check(str,s[i])) return 0;
		printf("%s\n",str);
		return 1;
	}
	str[x]='0';
	ans=work(x+1);
	str[x]='1';
	ans=(ans+work(x+1))%modn;
	return ans;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (i=0;i<n;i++)
		scanf("%s",s[i]);
	printf("%d",work(0));
	fclose(stdin);
	fclose(stdout);
	return 0;
}
