#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

const int N = 15;
int n, ans;
struct edge{int ed, ne;} e[N<<1]; int he[N], en;
int h[N];
int f[N][N], cnt, rt[N], w[N];

void ins(int a, int b) {
	e[++en].ed = b; e[en].ne = he[a]; he[a] = en;
}

void dfs(int u, int fa, int o) {
	f[u][o] = fa;
	for(int i = he[u]; i; i = e[i].ne)
	if(e[i].ed != fa) dfs(e[i].ed, u, o);
}

bool check() {
	int i, j; bool fl;
	rep(i, 1, cnt) {
		fl = 1;
		rep(j, 1, n) if(h[f[j][i]] > h[j]) {fl = 0; break;}
		if(fl) return 1;
	}
	return 0;
}

void dfs2(int dep, int now) {
	if(dep > n) {
		if(check()) {ans = max(ans, now);
		//for(int i = 1; i <= n; ++i) printf("%d ", h[i]); puts("");
		//printf("%d\n", now);
		}
		return;
	}
	for(int i = 1; i <= n; ++i)
	if(!h[i]) {
		h[i] = dep;
		dfs2(dep + 1, now + dep * w[i]);
		h[i] = 0;
	}
}

int main() {
	freopen("xmastree2.in", "r", stdin); freopen("xmastree2.out", "w", stdout);
	int i, x, y, r;
	scanf("%d", &n);
	rep(i, 1, n-1) {
		scanf("%d %d", &x, &y);
		ins(x, y); ins(y, x);
	}
	rep(i, 1, n) {
		scanf("%d %d", &w[i], &r);
		if(r) rt[++cnt] = i;
	}
	rep(i, 1, cnt) dfs(rt[i], 0, i);
	/*rep(i, 1, cnt) {
		for(int j = 1; j <= n; ++j) printf("%d ", f[j][i]);
		puts("");
	}*/
	h[0] = 1;
	dfs2(1, 0);
	printf("%d\n", ans);
	return 0;
}
