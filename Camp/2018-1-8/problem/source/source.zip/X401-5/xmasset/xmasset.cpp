#include <bits/stdc++.h>
using namespace std;
#define MAXN 940
#define MAXH 12
int type,n,T;
bool pw[MAXN+10][MAXH+5];
int tab[MAXN+10][MAXN+10];
bool p[MAXH+5];
const int h=12;
void makePW()
{
	for(int i=1; i<=h; ++i)
	{
		p[i]=(i>h/2);
	}
	for(int i=1; i<=n; ++i)
	{
		for(int j=1; j<=h; ++j)
		{
			pw[i][j]=p[j];
		}
		std::next_permutation(p+1,p+1+h);
	}
}
void makeTab()
{
	for(int i=1; i<=n; ++i)
	{
		for(int j=1; j<=n; ++j)
		{
			if (i==j) continue;
			for(int k=1; k<=h; ++k)
			{
				if (pw[i][k] && !pw[j][k])
				{
					tab[i][j]=k;
				}
			}
		}
	}
}
namespace A
{
void main()
{
	makeTab();
	for(int i=1; i<=T; ++i)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		printf("%d\n",tab[x][y]);
	}
}
}
namespace B
{
void main()
{
	for(int i=1; i<=T; ++i)
	{
		int q,h;
		scanf("%d%d",&q,&h);
		if (pw[q][h])
		{
			puts("yes");
		}
		else
		{
			puts("no");
		}
	}
}
}
int main()
{
#ifndef MDEBUG
    //freopen("xmasset.in","r",stdin);
    //freopen("xmasset.out","w",stdout);
#endif
    scanf("%d%d%d",&type,&n,&T);
	makePW();
	if (type==1) A::main();
	else B::main();
    return 0;
}
