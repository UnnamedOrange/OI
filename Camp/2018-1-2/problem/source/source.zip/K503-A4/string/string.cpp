//Brute-force ~30pts
#include <bits/stdc++.h>
#include <string>
using namespace std;

const int INF = 0x3f3f3f3f;
int N, T; string S;

bool isPalindrome(int L, int R, string& str) {
	if(L>=R) return true;
	else return str[L] == str[R] && isPalindrome(L+1, R-1, str);
}

int calc(string str) {
	if(str.empty()) return 0;
	int ret = INF;
	for(int i=0; i<=str.length()-1; i++)
		for(int j=i+1; j<=str.length()-1; j++)
	 		if(!isPalindrome(i, j, str))
	 			ret=min(ret, calc(str.substr(0, i))
				 + 1 + calc(str.substr(j+1, str.length()-j-1)));
	return ret;
}

void Init() { 
	scanf("%d", &N); 
	cin>>S;
}

void Work() {
	int Ans = calc(S);
	printf("%d\n", Ans<INF ? Ans : -1);
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	
	scanf("%d", &T);
	while(T--) {
		Init(); Work();
	}
	return 0;
}
