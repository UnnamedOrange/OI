#include<bits/stdc++.h>
using namespace std;
long long n;
long long k;
long long mo=998244353;
long long ksm(long long base,int loc){
	if(loc==0) return 1;
	else if(loc==1) return base;
	long long ks=ksm(base,loc/2);
	if(loc%2==0) return (ks*ks)%mo;
	return (((ks*ks)%mo)*base)%mo;
}
int main(){
	srand((unsigned long long)new char);
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	printf("%lld\n",rand()%ksm(n,k));
	return 0;
}
