#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;
#define N 1000005
#define M 20000050
#define mid ((l+r)>>1)
#define ls l,mid,t<<1
#define rs mid+1,r,t<<1|1
#define upd tr[t]=tr[t<<1]+tr[t<<1|1]
#define pud if(tag[t].se){tag[t<<1]=tag[t<<1]+tag[t];tag[t<<1|1]=tag[t<<1|1]+tag[t];lwn psz=tag[t];psz.se=1LL*psz.se*(mid-l+1)%Mod;tr[t<<1]=tr[t<<1]+psz;psz=tag[t];psz.se=1LL*psz.se*(r-mid)%Mod;tr[t<<1|1]=tr[t<<1|1]+psz;tag[t].fr=tag[t].se=0;}
#define Mod 1000000007
int st[20][N],c[N],d[N],n,i,j,l[N],r[N],fa[N],ll[N],rr[N],id,nxt[M],hd[N],tl[N];
int gf(int x)
{
	return fa[x]==x?x:fa[x]=gf(fa[x]);
}
struct lwn{
	int fr,se;
	lwn operator + (const lwn &jb)const{
		lwn cll;
		if (fr>jb.fr) cll.fr=fr,cll.se=se;
		else if (fr<jb.fr) cll=jb;
		else cll.fr=fr,cll.se=(se+jb.se)%Mod;
		return cll;
	}
	bool operator < (const lwn &jb)const{
		return fr<jb.fr;
	}
} b[M],tr[N<<2],tag[N<<2],f[N],a[N];
inline int qst(int le,int ri)
{
	int k=floor(log2(ri-le+1));
	return min(st[k][le],st[k][ri-(1<<k)+1]);
}
inline int rd()
{
	char ch=getchar();int ret=0;
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9') ret=(ret<<3)+(ret<<1)+ch-'0',ch=getchar();
	return ret;
}
void cg(int l,int r,int t,int ll,int rr,lwn gh)
{
	if (ll<=l&&rr>=r){
		tag[t]=tag[t]+gh;gh.se=1LL*gh.se*(r-l+1)%Mod;tr[t]=tr[t]+gh;return;
	}pud if (ll<=mid) cg(ls,ll,rr,gh);if (rr>mid) cg(rs,ll,rr,gh);upd;
}
lwn query(int l,int r,int t,int ll,int rr)
{
	if (ll<=l&&rr>=r) return tr[t];
	pud lwn jb;jb.fr=jb.se=0;
	if (ll<=mid) jb=jb+query(ls,ll,rr);
	if (rr>mid) jb=jb+query(rs,ll,rr);
	return jb;
}
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=rd();
	for (i=1;i<=n;i++) c[i]=rd(),d[i]=rd();
	for (i=1;i<=n;i++) st[0][i]=d[i];
	for (j=1;(1<<j)<=n;j++)
	for (i=1;i<=n;i++) if (i+(1<<j)<=n+1) st[j][i]=min(st[j-1][i],st[j-1][i+(1<<j-1)]);
	j=1;
	for (i=1;i<=n;i++){
		while (qst(j,i)<i-j+1) j++;
		l[i]=j;
	}
	j=n;
	for (i=n;i>=1;i--){
		while (qst(i,j)<j-i+1) j--;
		r[i]=j;
	}
	for (i=1;i<=n;i++) a[i].fr=c[i],a[i].se=i;
	sort(a+1,a+n+1);
	for (i=1;i<=n;i++){
		int now=a[i].se,f1=gf(now-1),f2=gf(now+1);
		if (!f1&&!f2){
			fa[now]=ll[now]=rr[now]=now;
			int l1=now+c[now]-1,r1=now;
			if (l1<=r1){
				int psz=++id;b[psz].fr=l1;b[psz].se=r1;
				nxt[psz]=hd[now-1];hd[now-1]=psz;
			}
		}else if (!f1){
			fa[now]=f2;ll[f2]=now;
			int l1=now+c[now]-1,r1=min(r[now],rr[f2]);
			if (l1<=r1){
				int psz=++id;b[psz].fr=l1;b[psz].se=r1;
				nxt[psz]=hd[now-1];hd[now-1]=psz;
			}
		}else if (!f2){
			fa[now]=f1;rr[f1]=now;
			int l1=max(ll[f1],l[now]),r1=now-c[now]+1;l1--;r1--;
			if (l1<=r1){
				int psz=++id;b[psz].fr=l1;b[psz].se=r1;
				nxt[psz]=tl[now];tl[now]=psz;
			}
		}else if (rr[f1]-ll[f1]<rr[f2]-ll[f2]){
			for (j=ll[f1];j<=now;j++){
				int l1=max(now,j+c[now]-1),r1=min(r[j],rr[f2]);
				if (l1<=r1){
					int psz=++id;b[psz].fr=l1;b[psz].se=r1;
					nxt[psz]=hd[j-1];hd[j-1]=psz;
				}
			}
			fa[now]=f2;fa[f1]=f2;ll[f2]=ll[f1];
		}else{
			for (j=now;j<=rr[f2];j++){
				int l1=max(l[j],ll[f1]),r1=min(now,j-c[now]+1);l1--;r1--;
				if (l1<=r1){
					int psz=++id;b[psz].fr=l1;b[psz].se=r1;
					nxt[psz]=tl[j];tl[j]=psz;
				}
			}
			fa[now]=f1;fa[f2]=f1;rr[f1]=rr[f2];
		}
	}
	for (i=0;i<=n;i++){
		f[i]=query(0,n,1,i,i);
		for (int gh=tl[i];gh;gh=nxt[gh]) f[i]=f[i]+query(0,n,1,b[gh].fr,b[gh].se);
		if (i) f[i].fr++;else f[i].se++;
		if (f[i].se){
			cg(0,n,1,i,i,f[i]);
			for (int gh=hd[i];gh;gh=nxt[gh]) cg(0,n,1,b[gh].fr,b[gh].se,f[i]);
		}
	}if (!f[n].se) puts("-1");else printf("%d %d\n",f[n].fr,f[n].se);
	return 0;
}
