#include<bits/stdc++.h>
typedef unsigned long long ull;
using namespace std;
inline int rd(){
	char ch=getchar(); int i=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getchar();}
	return i*f;
}
inline void W(int x){
	static int buf[50];
	if(!x){putchar('0');return;}
	if(x<0){putchar('-');x=-x;}
	while(x){buf[++buf[0]]=x%10;x/=10;}
	while(buf[0]){putchar(buf[buf[0]--]+'0');}
}
const int Mod=998244353;
inline void add(int &x,int y){
	x=(x+y>=Mod?x+y-Mod:x+y);
}
const int N=1e5+50;
const int K=5e2+50;
int n,m,k,C[K][K],f[N][K],deg[N];
vector<int>son[N];
queue<int>q;
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=rd(), m=rd(), k=rd();
	for(int i=0;i<=k;i++)C[i][0]=1;
	for(int i=1;i<=k;i++)
		for(int j=1;j<=i;j++)
			add(C[i][j],C[i-1][j-1]),add(C[i][j],C[i-1][j]);
	for(int i=1;i<=m;i++){
		int x=rd(),y=rd();
		deg[y]++;
		son[x].push_back(y);
	}
	for(int i=1;i<=n;i++)
		if(!deg[i]){
			f[i][0]=1;
			q.push(i);
		}
	while(!q.empty()){
		int u=q.front();q.pop();
		for(int i=son[u].size()-1;i>=0;i--){
			int v=son[u][i];
			for(int j=0;j<=k;++j)
				for(int p=0;p<=j;++p)
					add(f[v][j],(ull)C[j][p]*f[u][p]%Mod);
			if(!(--deg[v]))q.push(v);
		}
	}
	for(int i=1;i<=n;i++)
		W(f[i][k]),putchar('\n');
}
