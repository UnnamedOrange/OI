#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=4005;

int n,m,K,a[N],b[N];
struct P_0{
	void work(){
		int ans=1;
		for(int dp,s0,s1;;++ans){
			rep(i,0,1<<ans){
				s0=s1=0;
				rep(j,0,ans){
					if(i>>j&1)s1|=1<<j;
					else s0|=1<<j;
				}
				s0<<=1;s1<<=1;
				dp=1;
				rep(j,1,n+1){
					if(a[j])dp|=(dp<<1)&s1;
					else dp|=(dp<<1)&s0;
				}
				if(dp>>ans&1)continue;
				dp=1;
				rep(j,1,m+1){
					if(b[j])dp|=(dp<<1)&s1;
					else dp|=(dp<<1)&s0;
				}
				if(!(dp>>ans)&1){
					ptn(ans);
					return ;
				}
			}
		}
		ptn(ans);
	}
}P0;
struct P_1{
	int dpa[N][N],dpb[N][N],dis[N][N];
	pii que[N*N];
	void work(){
		rep(i,1,n+1)dpa[a[i]][i]=i;
		rep(i,1,m+1)dpb[b[i]][i]=i;
		rep(k,0,K){
			dpa[k][n+1]=n+1;dpa[k][n+2]=n+1;
			dpb[k][m+1]=m+1;dpb[k][m+2]=m+1;
			per(i,1,n+1)
				if(!dpa[k][i])dpa[k][i]=dpa[k][i+1];
			per(i,1,m+1)
				if(!dpb[k][i])dpb[k][i]=dpb[k][i+1];
		}
		//pair<int,int>��ʾ��i��j���������·
		int l=0,r=0,x,y,nx,ny;
		que[r++]=pii(0,0);
		dis[0][0]=1;
		while(l<r){
			x=que[l].fi,y=que[l++].se;
			per(i,0,K){
				nx=dpa[i][x+1];ny=dpb[i][y+1];
				if(n<nx&&m<ny){
					ptn(dis[x][y]);
					return ;
				}
				if(!dis[nx][ny])dis[nx][ny]=dis[x][y]+1,que[r++]=pii(nx,ny);
			}
		}
	}
}P1;
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	rd(n),rd(m),rd(K);
	rep(i,1,n+1)rd(a[i]),--a[i];
	rep(i,1,m+1)rd(b[i]),--b[i];
	if(0);
	else if(n<=18&&m<=18&&K<=2)P0.work();
	else P1.work();
	return 0;
}
