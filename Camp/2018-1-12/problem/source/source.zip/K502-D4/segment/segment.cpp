#include<bits/stdc++.h>
using namespace std;
long long mo=998244353;
long long read(){
	long long x=0,f=1;char c; c=getchar();
	while(c<'0'||c>'9') { if(c=='-') f=-1; c=getchar(); }
	while(c>='0'&&c<='9') { x=x*10+c-'0'; c=getchar(); }
	return x*f;
}
long long ksm(long long base,long long u){
	if(u==0) return 1;
	else if(u==1) return base;
	long long ks=ksm(base,u/2);
	if(u%2==0) return (ks*ks)%mo;
	return (((ks*ks)%mo)*base)%mo;
}
long long sum[100005];
long long tot[100005];
long long ans;
long long n,m,k;
void dfs(int tk,int l,int r){
	if(tk>n){
		for(int i=1;i<=m;i++){
			tot[i]=sum[i]+tot[i-1];
			ans=(ans+ksm(tot[i],k))%mo;	
		}
		return;
	}
	for(int i=l+1;i<=m;i++){
		for(int p=max(r+1,i);p<=m;p++){
			sum[i]++;sum[p]--;
			dfs(tk+1,i,p);
			sum[i]--;sum[p]++;
		}
	}
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=read();
	m=read();
	k=read();
	dfs(1,0,0);
	printf("%lld\n",ans);
	return 0;
}
