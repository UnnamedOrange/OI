#include <cstdio>
#include <algorithm>

const int MAXN = 500000 + 10;
int N, M;
int L[MAXN], R[MAXN], A[MAXN];
int str[MAXN];
bool visited[MAXN];
int ans;

inline void Dfs( int t ) {
	if( t == N + 1 ) {
		register int i, j;
		bool flag = 1;
		for( i = 1; i <= N; ++i )
			if( str[i] )
				for( j = 1; j <= M; ++j )
					if( L[i] <= A[j] && A[j] <= R[i] )
						visited[j] = 1;
		for( i = 1; i <= M; ++i ) {
			if( !visited[i] )
				flag = 0;
			visited[i] = 0;
		}
		if( flag )
			++ans;
		return;
	}
	Dfs( t + 1 );
	str[t] = 1;
	Dfs( t + 1 );
	str[t] = 0;
}

int main() {
	freopen( "xmasinterval.in", "r", stdin );
	freopen( "xmasinterval.out", "w", stdout );
	register int i;
	scanf( "%d%d", &N, &M );
	for( i = 1; i <= N; ++i )
		scanf( "%d%d", L + i, R + i );
	for( i = 1; i <= M; ++i )
		scanf( "%d", A + i );
	Dfs( 1 );
	printf( "%d\n", ans );
	return 0;
}
