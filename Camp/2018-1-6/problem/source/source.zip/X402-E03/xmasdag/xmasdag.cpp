#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 1e5+5, maxm = 2e5+5, maxk = 505 ;
int n, m, k ;
int modd = 998244353, g[maxn][maxk], sg[maxn][maxk] ;
int e, Begin[maxn], Next[maxm], To[maxm] ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
int deg[maxn] ;
bool vis[maxn] ;
int C[maxk][maxk] ;
void init() {
	int i, j ;
	C[0][0] = 1 ;
	for ( i = 1 ; i <= k+1 ; i ++ ) {
		C[i][0] = C[i][i] = 1 ;
		for ( j = 1 ; j < i ; j ++ )
			C[i][j] = (C[i - 1][j] + C[i - 1][j - 1])%modd ;
	}
}
void dfs ( int x ) {
	if (vis[x]) return ;
	vis[x] = 1 ;
	register int i, j, l, u ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		dfs(u) ;
		(g[x][0] += g[u][0]) %= modd ;
		for ( j = 1 ; j <= k ; j ++ ) {
			(g[x][j] += g[u][j]) %= modd ;
			(g[x][j] += sg[u][j]) %= modd ;
		}
	}
	sg[x][0] = g[x][0] ;
	for ( l = 0 ; l < k ; l ++ ) {
		for ( j = l+1 ; j <= k ; j ++ )
			(sg[x][j] += (LL)g[x][l]*C[j][l]%modd) %= modd ;
	}
}
int main() {
	freopen ( "xmasdag.in", "r", stdin ) ;
	freopen ( "xmasdag.out", "w", stdout ) ;

	register int i, u, x ;
	Read(n) ; Read(m) ; Read(k) ;
	init() ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(u) ; Read(x) ;
		add(x, u) ;
		++ deg[u] ;
	}
	vis[1] = 1 ;
	sg[1][0] = g[1][0] = 1 ;
	for ( i = 1 ; i <= k ; i ++ )
		sg[1][i] = 1 ;
	for ( i = 2 ; i <= n ; i ++ )
		if (!deg[i]) dfs(i) ;
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%d\n", g[i][k] ) ;
	return 0 ;
}
