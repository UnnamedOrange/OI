#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n;
	freopen("gen.in","r",stdin);
	int rand_num=read();
	srand(time(0)+rand_num);
	freopen("bomb.in","w",stdout);
	n=1000000;m=1000000;
	printf("%d %d\n",n,m);
	for(i=1;i<=m;i++){
		int x=rand()%n+1,y=rand()%n+1;
		while(x==y)y=rand()%n+1;
		printf("%d %d\n",x,y);
	}
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	return 0;
}
