#include <cstdio>
#include <cstdlib>

int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	srand(20180110);
	int t; scanf("%d",&t);
	while (t--)
		printf("%d\n",rand()*rand());
	fclose(stdin);
	fclose(stdout);
	return 0;
}

