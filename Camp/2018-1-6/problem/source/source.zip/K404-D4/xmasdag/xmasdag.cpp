#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
const int MOD = 998244353;
int n, m, k;
int in[100010];
struct Graph {
	int head[100010], to[200010], nxt[200010], cnt;
	inline void addedge (int u, int v) { cnt++, to[cnt] = v, nxt[cnt] = head[u], head[u] = cnt; }
} g, fg;
int tp[100010], ind, C[510][510];
int f[100010][510], ff[2010][2010], mi[2010];
queue <int> q;
inline int ksm (int a, int p) {
	if (p == 0) return 1;
	if (p == 1) return a;
	int l = ksm (a, p >> 1);
	l = 1ll * l * l % MOD;
	if (p & 1) l = 1ll * l * a % MOD;
	return l;
}
inline void solve () {
	ff[1][0] = 1;
	for (int i = 1; i <= n; i++) {
		int u = tp[i];
		for (int e = fg.head[u]; e; e = fg.nxt[e]) {
			int v = fg.to[e];
			for (int j = 0; j < n; j++) ff[u][j + 1] = (ff[u][j + 1] + ff[v][j]);
		}
	}
	for (int i = 1; i <= n; i++) mi[i] = ksm (i, k);
	for (int i = 1; i <= n; i++) {
		int ansi = 0;
		for (int j = 0; j <= n; j++)
			ansi = (ansi + 1ll * mi[j] * ff[i][j] % MOD) % MOD;
		printf ("%d\n", ansi);
	}
}
int main () {
	freopen ("xmasdag.in", "r", stdin);
	freopen ("xmasdag.out", "w", stdout);
	scanf ("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= m; i++) {
		int u, v;
		scanf ("%d%d", &u, &v);
		g.addedge (u, v);
		in[v]++;
		fg.addedge (v, u);
	}
	for (int i = 1; i <= n; i++) if (!in[i]) q.push (i);
	while (!q.empty ()) {
		int u = q.front (); q.pop ();
		tp[++ind] = u;
		for (int e = g.head[u]; e; e = g.nxt[e]) {
			int v = g.to[e];
			in[v]--;
			if (!in[v]) q.push (v);
		}
	}
	if (n <= 2000 && m <= 5000) { solve (); return 0; }
	C[0][0] = 1;
	for (int i = 1; i <= k; i++) {
		C[i][0] = C[i][i] = 1;
		for (int j = 1; j < i; j++)
			C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % MOD;
	}
	f[1][0] = 1;
	for (int i = 1; i <= n; i++) {
		int u = tp[i];
		for (int e = fg.head[u]; e; e = fg.nxt[e]) {
			int v = fg.to[e];
			for (int p = 0; p <= k; p++)
				for (int q = 0; q <= p; q++) {
					f[u][p] = (f[u][p] + 1ll * C[p][q] * f[v][q] % MOD) % MOD;
				}
		}
	}
	for (int i = 1; i <= n; i++) printf ("%d\n", f[i][k]);
	return 0;
}
