#include<bits/stdc++.h>
#define maxn 1000
#define mod 1000000007
using namespace std;
int f[maxn][maxn];
int main()
{
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	int s, t, n, m;
	scanf("%d%d%d%d", &s, &t, &n, &m);
	f[0][0] = 1;
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= s; j++)
		{
			int mx = j;
			if (i <= n) mx = min(t, mx);
			for (int k = 1; k <= mx; k++)
				f[i][j] = (f[i][j] + f[i - 1][j - k]) % mod;
		}
	int ans = 0;
	for (int i = 1; i <= s; i++)
		ans = (ans + f[m][i]) % mod;
	printf("%d\n", ans);
	return 0;
}
