#include<bits/stdc++.h>
#define maxn 998244353
using namespace std;
int n,m,a[110000];
long long k,mi[110000],ans;

long long cf(int x)
{
	int hh=1,em=1,fk=k;
	long long emm[40]={1},anss=1;
	emm[1]=x,emm[0]=1;
	while (hh<=fk)
	  {
	  	hh=hh*2,em++,emm[em]=emm[em-1]*emm[em-1];
	  	if (emm[em]>maxn) emm[em]=emm[em]%maxn;
	  }  
	while (fk)
	  {
	  	if (fk-hh>=0) fk=fk-hh,anss*=emm[em];
	  	if (anss>maxn) anss=anss%maxn;
	  	hh=hh/2,em--;
	  }  
	return (anss%maxn);  
}

void dfs(int l,int r,int x)
{
	if (!x) 
	  {
	  	for (int i=1;i<=m;i++)
	  	  {
	  	  	ans+=mi[a[i]];
		  }
		return;  
	  }
	for (int i=1;i<=m-x-l+1;i++)
	  {
	  	for (int j=1;j<=m-x-r+1;j++)
	  	  {
	  	  	if (r+j<l+i) continue;
	  	  	for (int k=l+i;k<=r+j-1;k++) a[k]++;
	  	  	dfs(l+i,r+j,x-1);
	  	  	for (int k=l+i;k<=r+j-1;k++) a[k]--;
		  }
	  }
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if (n>=m) 
	  {
	  	printf("0");
	  	return 0;
	  }
	for (int i=1;i<=n;i++) mi[i]=cf(i);
//	for (int i=1;i<=n;i++) printf("%d\n",mi[i]);
	if (n==1)
	  {
	  	for (int i=1;i<=m-1;i++) ans+=i*(m-i);
	  	printf("%d",ans);
	  	return 0;
	  }
	if (m<=6||n==2)
	  {
	  	dfs(0,0,n);
	  	printf("%d",ans);
	  	return 0;
	  }  
}
