#include<cstdio>
int main(){
	freopen("tournament.out","w",stdout);
	printf("1");
	return 0;
}
