#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int n,ty=0,p[100010];
long long ans=0;
bool vis[100010]={0},ed[110];

bool dfs_j(int t,int d){
	if(ed[t])return d%2==0;
	ed[t]=1;
	dfs_j(p[t],d+1);
}

int judge(){
	memset(ed,0,sizeof(ed));
	for(int i=1;i<=n;i++)
	  if(!ed[i]&&!dfs_j(i,0))
	    return 0;
	return 1;
}

void dfs(int d){
	if(d>n){
		ans=(ans+judge())%998244353;
		return;
	}
	int nxt=d+1;
	while(p[nxt]&&nxt<=n)nxt++;
	for(int i=1;i<=n;i++)
	  if(!vis[i]){
	  	vis[i]=1;p[d]=i;
	  	dfs(nxt);
	  	vis[i]=p[d]=0;
	  }
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&p[i]);
		if(p[i])ty=1,vis[p[i]]=1;
	}
	if(n%2)printf("0");
	else if(n==8||ty){
		int s=1;
		while(p[s]&&s<=n)s++;
		dfs(s);
		printf("%lld",ans);
	}
	else{
		ans=1;
		for(long long i=1;i<=n;i+=2)
		  ans=(ans*i)%998244353;
		printf("%lld",(ans*ans)%998244353);
	}
	return 0;
}
