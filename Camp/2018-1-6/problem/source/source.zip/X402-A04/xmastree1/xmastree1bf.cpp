#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void addedge(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
int n,col[N],siz[N],ans[N],dfn[N],dfs_clk=0,rnk[N],f[N];
bool vis[2050];

void dfs(int u,int fa)
{
	f[u]=fa;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,u);
	}
}
void dfs2(int u,int fa)
{
	vis[col[u]]=1;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs2(v,u);
	}
}

void wj()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
//	freopen("5.in","r",stdin); freopen("5.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T,typ;
	//seg::sz=0; seg::sum[0]=0;
	n=read(); T=read(); typ=read();
	for(i=1;i<=n;++i) col[i]=read();
	for(i=1;i<n;++i)
	{
		int x=read(),y=read();
		addedge(x,y);
	}
	dfs(1,0);
	int lastans=0;
	for(int cas=1;cas<=T;++cas)
	{
		opt=read();
		if(opt==1)
		{
			int u=read(),l=read(),r=read();
			if(typ) u^=lastans,l^=lastans,r^=lastans;
			dfs2(u,f[u]);
			lastans=0;
			for(i=l;i<=r;++i) lastans+=vis[i];
			for(i=1;i<=n;++i) vis[i]=0;
			printf("%d\n",lastans);
		}
		else
		{
			int u=read(),c=read();
			if(typ) u^=lastans,c^=lastans;
			col[u]=c;
		}
	}
	return 0;
}
