#include <cctype>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)
#define repe(i,x) for (edge *i=fst[x]; i; i=i->nxt)

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;
}

typedef long long ll;
using namespace std;
const int N=3e4+10;
int n,tot,root[11],fa[N],w[N],a[N];
ll ans;
struct edge
{
    int v;
    edge *nxt;
} pool[N*2],*tp=pool,*fst[N];

void dfs(int x)
{
    int v;
    repe(i,x)
        if ((v=i->v)!=fa[x])
            fa[v]=x,dfs(v);
}

ll calc()
{
    int flag=1;
    ll ans=0;
    rep(i,1,n)
        if (!((flag>>fa[a[i]])&1))
            return 0;
        else
            ans+=w[a[i]]*i,flag|=1<<a[i];
    return ans;
}

ll work(int root)
{
    a[1]=root;
    rep(i,1,root-1)
        a[i+1]=i;
    rep(i,root+1,n)
        a[i]=i;
    fa[root]=0,dfs(root);
    ll ans=0;
    do
        ans=max(ans,calc());
    while (next_permutation(a+2,a+1+n));
    return ans;
}

int main()
{
    freopen("xmastree2.in","r",stdin);
    freopen("force.out","w",stdout);
    n=get();
    rep(i,2,n)
    {
        int u=get(),v=get();
        *tp=(edge){v,fst[u]},fst[u]=tp++;
        *tp=(edge){u,fst[v]},fst[v]=tp++;
    }
    rep(i,1,n)
        if (w[i]=get(),get())
            root[++tot]=i;
    rep(x,1,tot)
        ans=max(ans,work(root[x]));
    printf("%lld",ans);
    return 0;
}
