#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n,a[30],b[30],S;
bool dfs(int k,int m){
	if(!m) return 1;
	if(k>S){
		for(int i=1;i<=n;i++) if(a[i]!=n) return 0;
		return 1;
	}
	for(int i=2;i<=m;i++){
		for(int j=1;j+j<=i;j++) swap(a[j],a[i-j+1]);
		int mm=m;
		while(a[mm]==mm) mm--;
		if(dfs(k+1,mm)) return 1;
		for(int j=1;j+j<=i;j++) swap(a[j],a[i-j+1]);
	}
	return 0;
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&a[i]),b[i]=a[i];
		int l=0,r=0,mid,ans;
		for(int i=n;i;i--){
			for(int p=1;p<=i;p++) if(b[p]==i){
				if(p==i) break;
				if(p!=1){
					r++;
					for(int j=1;j<=p/2;j++) swap(b[j],b[p-j+1]);
				}
				for(int j=1;j<=i/2;j++) swap(b[j],b[i-j+1]);
				r++;
			}
		}
		ans=r;r--;
		if(r>=9){
			printf("%d\n",r);
			continue;
		}
		while(l<=r){
			mid=l+r>>1;S=mid;
			if(dfs(1,n)) ans=mid,r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",ans);
	}
	return 0;
}
