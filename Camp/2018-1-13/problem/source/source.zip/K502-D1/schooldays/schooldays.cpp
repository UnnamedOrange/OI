#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

long long mod = 1000000007;
const int MAXN = 3000;
int N;
long long f[MAXN];
long long g[MAXN];
int c[MAXN], d[MAXN];
void open()
{
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}
int main()
{
	open();
	N = read();
	for(int i = 1; i <= N; i++) {
		c[i] = read(), d[i] = read();
	}
	f[0] = 0;
	g[0] = 1;
	for(int i = 1; i <= N; i++) {
		int maxn = 1e9, minn = 0;
		for(int j = i; j >= 1; j--) {
			maxn = min(maxn, d[j]), minn = max(minn, c[j]);
			if(maxn < i - j + 1) {
				break;
			}
			if(i - j + 1 >= minn) {
				if(f[i] == f[j - 1] + 1) {
					g[i] = (g[i] + g[j - 1]) % mod;
				}
				if(f[j - 1] + 1 > f[i]) {
					f[i] = (f[j - 1] + 1) % mod;
					g[i] = g[j - 1];
				}
			}
		}
	}
/*	cout<<endl;
	for(int i = 1; i <= N; i++) {
		cout<<f[i]<<" "<<g[i]<<endl; 
	}
	cout<<endl;
	cout<<f[N]<<" "<<g[N]<<endl;
	*/
	if(f[N] == 0) {
		printf("-1\n");
	} else {
		printf("%lld %lld\n", f[N], g[N]);
	}
	close();
	return 0;
}
