#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar(); 
	return ret;
}


//youxianduilie dagendui

int ll,LL,Ll,lL;



int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	n=read();
	for(int i=1; i<n; ++i)
	{
		u=read(); v=read();
		c[++tot][0]=v; c[tot][1]=a[u]; a[u]=++tot;
		c[++tot][0]=u; c[tot][1]=a[v]; a[v]=++tot;
	}
	//climits
	for(int i=1; i<=n; ++i){
		w[i]=read();
		r[i]=read();
	}
	//set  empty ?  //erase?  empty  
	//huafenshu
	for(int i=1; i<=n; ++i)if(r[i])
	{
		s.clear(); //id pos
		for(int j=1; j<=n; ++j)f[j]=j,hh[j]=w[j],num[j]=1;
		dfs(i,0);
		for(int j=1; j<=n; ++j)if(i!=j)s.insert((node){w[j],1,j});
		for(int j=1; j<n; ++j)  // i i j
		{
			it=s.begin();
			u=(*it).w;
			v=(*it).n;
			id=(*it).id;
			fa_=fid(fa[id]);  //anshzihebing lujingyasuo
			u_=hh[fa_];
			v_=num[fa_]; //.._...
			
		}
	}
}

