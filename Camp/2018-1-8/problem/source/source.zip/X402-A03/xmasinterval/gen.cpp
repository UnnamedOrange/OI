/*******************************************
	File:gen.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-8 09:51:04
*******************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
int n,m;
#include<stdlib.h>
#define R (rand()%(n)+1)
int main()
{
	freopen("xmasinterval.in","w",stdout);
	n=20;
	m=20;
	printf("%d %d\n",n,m);
	srand((unsigned long long)new char);
	fr(i,1,n)
	{
		int l=R,r=R;
		while(l>r)
		{
			l=R;
			r=R;
		}
		printf("%d %d\n",l,r);
	}
	fr(i,1,m)
		printf("%d\n",R);
	return 0;
}