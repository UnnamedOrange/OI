#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long double real;
typedef long long ll;
const int lit=1e5;
const real eps=1e-12;
const int maxn=1e6+6;
const int maxtree=maxn<<2|1;
int n,ai[maxn],L[maxtree],R[maxtree],val1[maxtree],mid[maxtree];
int bi[maxn],num,pos[maxtree],vi[maxtree],mid_[maxtree],L_[maxtree];
int R_[maxtree];
real val2[maxtree],ans,bit[105];
inline void read(int &now)
{
	char Cget;
	now=0;
	while(!isdigit(Cget=getchar()));
	while(isdigit(Cget))
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
void build(int now,int l,int r)
{
	L[now]=l;
	R[now]=r;
	val1[now]=0;
	val2[now]=0;
	if(l==r)
		return;
	mid[now]=l+r>>1;
	build(now<<1,l,mid[now]);
	build(now<<1|1,mid[now]+1,r);
}
void updata(int now,int to)
{
	if(L[now]==R[now])
	{
		val1[now]++;
		val2[now]=(val2[now]+bi[to])*0.5;
		return;
	}
	if(to<=mid[now])
		updata(now<<1,to);
	else
		updata(now<<1|1,to);
	if(val1[now<<1|1]<=60)
		val2[now]=val2[now<<1]*bit[val1[now<<1|1]]+val2[now<<1|1];
	else
		val2[now]=val2[now<<1|1];
	val1[now]=val1[now<<1]+val1[now<<1|1];
}
void Build(int now,int l,int r)
{
	L_[now]=l;
	R_[now]=r;
	pos[now]=0;
	vi[now]=0;
	if(l==r)
		return;
	mid_[now]=l+r>>1;
	Build(now<<1,l,mid_[now]);
	Build(now<<1|1,mid_[now]+1,r);
}
inline void add(int now,int to)
{
	if(L_[now]==R_[now])
	{
		pos[now]=to;
		vi[now]=ai[to];
		return;
	}
	if(to<=mid_[now])
		add(now<<1,to);
	else
		add(now<<1|1,to);
	if(vi[now<<1]&&vi[now<<1|1])
		if(vi[now<<1]<=vi[now<<1|1])
		{
			vi[now]=vi[now<<1];
			pos[now]=pos[now<<1];
		}
		else
		{
			vi[now]=vi[now<<1|1];
			pos[now]=pos[now<<1|1];
		}
	else if(vi[now<<1])
	{
		vi[now]=vi[now<<1];
		pos[now]=pos[now<<1];
	}
	else if(vi[now<<1|1])
	{
		vi[now]=vi[now<<1|1];
		pos[now]=pos[now<<1|1];
	}
	else
	{
		vi[now]=0;
		pos[now]=0;
	}
}
inline void del(int now,int to)
{
	if(L_[now]==R_[now])
	{
		pos[now]=0;
		vi[now]=0;
		return;
	}
	if(to<=mid_[now])
		del(now<<1,to);
	else
		del(now<<1|1,to);
	if(vi[now<<1]&&vi[now<<1|1])
		if(vi[now<<1]<=vi[now<<1|1])
		{
			vi[now]=vi[now<<1];
			pos[now]=pos[now<<1];
		}
		else
		{
			vi[now]=vi[now<<1|1];
			pos[now]=pos[now<<1|1];
		}
	else if(vi[now<<1])
	{
		vi[now]=vi[now<<1];
		pos[now]=pos[now<<1];
	}
	else if(vi[now<<1|1])
	{
		vi[now]=vi[now<<1|1];
		pos[now]=pos[now<1|1];
	}
	else
	{
		vi[now]=0;
		pos[now]=0;
	}
}
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	read(n);
	bit[0]=1;
	bit[1]=0.5;
	for(int i=2;i<=60;i++)
		bit[i]=bit[i-1]*0.5;
	if(n<=1500)
	{
		for(int i=1;i<=n;i++)
		{
			read(ai[i]);
			bi[++num]=ai[i];
		}
		std::sort(bi+1,bi+num+1);
		num=std::unique(bi+1,bi+num+1)-bi-1;
		for(int i=1;i<=n;i++)
			ai[i]=std::lower_bound(bi+1,bi+num+1,ai[i])-bi;
		for(int i=1;i<=n;i++)
		{
			build(1,1,num);
			for(int v=i,len=1,t;v<=n;v++,len++)
			{
				updata(1,ai[v]);
				ans+=val2[1];
			}
		}
		double tmp_ans=ans/(1LL*n*n);
		printf("%.10lf\n",tmp_ans);
	}
	else
	{
		for(int i=1;i<=n;i++)
			read(ai[i]);
		int last=1,llast=0;
		for(int i=1;i<=lit;i++)
			bi[i]=i;
		while(last<=n)
		{
			build(1,1,lit);
			Build(1,1,n);
			for(int i=last,size=0;i<=n;i++)
			{
				size++;
				updata(1,ai[i]);
				add(1,i);
				if(size>60)
				{
					del(1,pos[1]);
					--size;
				}
				last=pos[1];
				ans+=(last-llast)*val2[1];
			}
			llast=last++;
		}
		double tmp_ans=ans/(1LL*n*n);
		printf("%.10lf\n",tmp_ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
