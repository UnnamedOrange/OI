#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
#define N 100010
int ans=0,k,n,a[N],m;
int ksm(int a,int b) {
	if(a==0) return 0;
	if(b==0) return 1;
	if(b==1) return a;
	int rec=1;
	if(b%2) rec=a;
	rec=(unsigned long long)rec*ksm((unsigned long long)a*a%mod,b/2)%mod;
	return rec;
}
void dfs(int L,int R,int last) {
	if(last==0) {
		for(int i=1;i<=m;i++) {
			ans=(ans+ksm(a[i],k))%mod;
		}
		return;
	}
	for(int i=L;i<=m;i++) {
		for(int j=max(R,i);j<=m;j++) {
			for(int z=i;z<j;z++) a[z]++;
			dfs(i+1,j+1,last-1);
			for(int z=i;z<j;z++) a[z]--;
		}
	}
}
int f[50][50][50];
int main() {
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(n<=6) {
		dfs(1,1,n);
		printf("%d",ans);
		return 0;
	}
	for(int i=1;i<=n;i++) {
		for(int j=0;j<=m;j++) {
			for(int z=j;z<=m;z++) {
				for(int t1=j+1;t1<=m;t1++) {
					for(int t2=max(z+1,t1);t2<=m;t2++) {
						f[i-1][t1][t2]+=f[i][i][j]+t2-t1;
						f[i-1][t1][t2]%=mod;
					}
				}
			}
		}
	}
	printf("%d",f[n][m][m]);
}
