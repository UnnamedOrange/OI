#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=500005,mod=1000000009;
void add_mod(int &a,int b){if((a+=b)>=mod)a-=mod;}
int n,m,a[N];
pii arr[N];
struct P_0{
	int dp[5005];
	void work(){
		dp[0]=1;
		rep(i,1,n+1){
			int l=lower_bound(a+1,a+1+m,arr[i].fi)-a,r=upper_bound(a+1,a+1+m,arr[i].se)-a-1,sum=0;
			rep(j,l-1,r+1)add_mod(sum,dp[j]);
//			ptk(i),ptn(sum);
			add_mod(dp[r],sum);
//			bug(l),bug(r),debug(sum);
			rep(j,r+1,m+1)add_mod(dp[j],dp[j]);
//			ptk(l),ptn(r);
		}
		ptn(dp[m]);
	}
}P0;
struct P_1{
	int tr[N<<2],cnt[N<<2],add[N<<2],pow2[N];
	#define ls (p<<1)
	#define rs (p<<1|1)
	void push_down(int p){
		if(cnt[p]){
			tr[ls]=(ll)tr[ls]*pow2[cnt[p]]%mod;
			add[ls]=(ll)add[ls]*pow2[cnt[p]]%mod;
			cnt[ls]+=cnt[p];
			tr[rs]=(ll)tr[rs]*pow2[cnt[p]]%mod;
			add[rs]=(ll)add[rs]*pow2[cnt[p]]%mod;
			cnt[p]=0;
		}
		if(add[p]){
			add_mod(tr[ls],add[p]);
			add_mod(add[ls],add[p]);
			add_mod(tr[rs],add[p]);
			add_mod(add[rs],add[p]);
			add[p]=0;
		}
	}
	void push_up(int p){
		add_mod(tr[p]=tr[ls],tr[rs]);
	}
	void update_add(int l,int r,int p,int pos,int v){
		if(l==r){
			add_mod(tr[p],v);
			add_mod(add[p],v);
			return ;
		}
		int mid=(l+r)>>1;
		push_down(p);
		if(pos<=mid)update_add(l,mid,ls,pos,v);
		else update_add(mid+1,r,rs,pos,v);
		push_up(p);
	}
	int query(int l,int r,int L,int R,int p){
		if(l==L&&r==R)return tr[p];
		push_down(p);
		int mid=(L+R)>>1;
		if(r<=mid)return query(l,r,L,mid,ls);
		if(mid<l)return query(l,r,mid+1,R,rs);
		int res=query(l,mid,L,mid,ls)+query(mid+1,r,mid+1,R,rs);
		if(res>=mod)res-=mod;
		return res;
	}
	void update_mul(int L,int R,int p,int pos){
		if(!tr[p]||R<pos)return ;
		if(pos<=L){
			add_mod(tr[p],tr[p]);
			add_mod(add[p],add[p]);
			++cnt[p];
			return ;
		}
		push_down(p);
		int mid=(L+R)>>1;
		update_mul(L,mid,ls,pos);
		update_mul(mid+1,R,rs,pos);
		push_up(p);
	}
	#undef ls
	#undef rs
	int lb(int v){
		static int l,r,res,mid;
		for(l=0,r=m;l<=r;){
			mid=(l+r)>>1;
			if(a[mid]<=v)res=mid,l=mid+1;
			else r=mid-1;
		}
		return res;
	}
	void work(){
		pow2[0]=1;
		rep(i,1,m+1)add_mod(pow2[i]=pow2[i-1],pow2[i-1]);
		update_add(0,m,1,0,1);
		int l=0,sum,r;
		arr[m+1].fi=(int)2e9;
		rep(i,1,n+1){
			//�ҵ���һ����l��� 
			while(a[l+1]<arr[i].fi)++l;
			r=lb(arr[i].se);
			sum=query(l,r,0,m,1);
			update_add(0,m,1,r,sum);
			if(r<n)update_mul(0,m,1,r+1);
		}
		ptn(query(m,m,0,m,1));
	}
}P1;
int main(){
//	freopen("data.in","r",stdin);
//	freopen("chk.out","w",stdout);
	rd(n),rd(m);
	rep(i,1,n+1)rd(arr[i].fi),rd(arr[i].se);
	rep(i,1,m+1)rd(a[i]);
	sort(arr+1,arr+1+n);sort(a+1,a+1+m);
	P0.work();
//	else P1.work();
	return 0;
}
