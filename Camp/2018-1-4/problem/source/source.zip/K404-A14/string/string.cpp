#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int mod=998244353;
const int N=1210,M=510,K=(1<<6)+5;
int dp[M][N][K];
char s[N];int L;
int a[N],b[N][N];
int tot;int rt[2];int ch[N][2],fail[N],tag[N],col[N],f[N],dep[N];
int q[N],h,t;
int n,m,totS;
int ans;

void insert(int x,int id){
	int i;
	rep(i,1,L){
		if(!ch[x][s[i]-'0']){ch[x][s[i]-'0']=++tot;dep[tot]=dep[x]+1;}
		x=ch[x][s[i]-'0'];
	}
	tag[x]|=1<<id;
}

void build(int x){
	int i;
	fail[x]=x;
	h=t=0;
	rep(i,0,1){
		if(ch[x][i]){fail[ch[x][i]]=x;q[++t]=ch[x][i];}
		else ch[x][i]=x;
	}
	while(h<t){
		x=q[++h];tag[x]|=tag[fail[x]];
		rep(i,0,1){
			if(ch[x][i]){fail[ch[x][i]]=ch[fail[x]][i];q[++t]=ch[x][i];}
			else ch[x][i]=ch[fail[x]][i];
		}
	}
}

int match(int x){
	int i;
	rep(i,1,L)	x=ch[x][a[i]];
	return x;
}
	
void dfs(int x,int id){
	int i;
	rep(i,1,dep[x])	b[x][i]=a[i]^1;
	col[x]=id;
	f[x]=match(rt[3-id]);
	rep(i,0,1)	if(dep[ch[x][i]]==dep[x]+1){
		a[++L]=i^1;dfs(ch[x][i],id);L--;
	}
}

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	register int i,j,k,S,x,y,tx,ty,now;
	scanf("%d%d",&n,&m);totS=(1<<n)-1;
	tot=2;rt[1]=1;rt[2]=2;
	rep(i,1,n){
		scanf("%s",s+1);L=strlen(s+1);
		insert(rt[1],i-1);
		reverse(s+1,s+1+L);
		insert(rt[2],i-1);
	}
	build(rt[1]);build(rt[2]);
	L=0;dfs(rt[1],1);
	L=0;dfs(rt[2],2);
	//rep(i,1,tot)	printf("f[%d]=%d\n",i,f[i]);
	//dp[m][n][S]
	dp[0][1][0]=1;
	rep(i,0,m-1) rep(j,1,tot) rep(S,0,totS) if(dp[i][j][S]){
		//printf("dp[%d][%d][%d]=%d\n",i,j,S,dp[i][j][S]);
		x=j;y=f[j];if(col[j]==2)	swap(x,y);
		rep(k,0,1){
			tx=ch[x][k];ty=ch[y][k^1];
			now=dep[tx]<dep[ty]?ty:tx;	
			(dp[i+1][now][S|tag[tx]|tag[ty]]+=dp[i][j][S])%=mod;
		}
	}
	rep(i,1,tot){
		x=i;y=f[i];if(col[i]==2)	swap(x,y);
		now=0;now|=tag[x];
		for(j=dep[y];j;j--){x=ch[x][b[y][j]];now|=tag[x];}
		//printf("%d %d\n",i,now);
		rep(S,0,totS) if(dp[m][i][S]){
			//printf("dp[%d][%d][%d]=%d\n",m,i,S,dp[m][i][S]);	
			if((S|now)==totS)	(ans+=dp[m][i][S])%=mod;
		}
	}
	printf("%d\n",ans);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
