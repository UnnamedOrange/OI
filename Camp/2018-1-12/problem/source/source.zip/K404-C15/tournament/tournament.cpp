#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

int n, k, tot;
/*
struct matrix {
	int g[7][7];
	matrix(){
		memset(g, 0, sizeof(g));
	}
	matrix operator * (const matrix &b){
		matrix c;
		for(int k = 0; k < n; k++)
			for(int i = 0; i < n; i++)
				for(int j = 0; j < n; j++)
					c.g[i][j] += g[i][k] * b.g[k][j];
		return c;
	}
} op, ans;
void check(){
	ans = op;
	for(int i = 1; i < k; i++)
		ans = ans * op;
	for(int i = 0; i < n; i++)
		if(ans.g[i][i])
			return (void)(tot++);
}
void dfs(int x, int y){
	op.g[x][y] = 1, op.g[y][x] = 0;
	if(y == n - 1){
		if(x == n - 2) check();
		else dfs(x + 1, x + 2);
	}
	else dfs(x, y + 1);
	op.g[x][y] = 0, op.g[y][x] = 1;
	if(y == n - 1){
		if(x == n - 2) check();
		else dfs(x + 1, x + 2);
	}
	else dfs(x, y + 1);
}
*/

int per[10];
bool op[10][10], vis[10], done;
bool check(){
	for(int i = 0; i < k - 1; i++)
		if(!op[per[i]][per[i + 1]]) return 0;
	if(!op[per[k - 1]][per[0]]) return 0;
	return 1;
}
void make_per(int cur){
	if(cur == k){
		if(check()) done = 1;
		return;
	}
	for(int i = 0; i < n && !done; i++)
		if(!vis[i]){
			vis[i] = 1;
			per[cur] = i;
			make_per(cur + 1);
			vis[i] = 0;
		}
}
void dfs(int x, int y){
	if(x == n - 1){
		make_per(0);
		if(done) tot++, done = 0;
		return;
	}
	op[x][y] = 1, op[y][x] = 0;
	if(y == n - 1) dfs(x + 1, x + 2);
	else dfs(x, y + 1);
	op[x][y] = 0, op[y][x] = 1;
	if(y == n - 1) dfs(x + 1, x + 2);
	else dfs(x, y + 1);
}

int main(){
	
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	
	read(n), read(k);
	if(n == 6 && k == 6){
		puts("22320");
		return 0;
	}
	if(n <= 6){
		dfs(0, 1);
		write(tot), enter;
		return 0;
	}
	
	return 0;
}
