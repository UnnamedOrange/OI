#include<bits/stdc++.h>
using namespace std;
struct Info{
	int x,y,z,a,b,c,d,e,f;
}a[1010];
struct pp{
	int x,y,z;
}b[1010];
int n,w,p,q,t,x,y,z,an[1010],num,ansn;
void dfs(int x){
	if (x>n){
		num=0;
		for (int i=1;i<=q;i++){
			if (b[i].z==0) if (an[b[i].x]>an[b[i].y]) return ;
			if (b[i].z==1) if (an[b[i].x]!=an[b[i].y]) return ;
			if (b[i].z==2) if (an[b[i].x]>=an[b[i].y]) return ;			
		}
		for (int i=1;i<=n;i++){
			num+=an[i];
		}
		for (int i=1;i<=p;i++)
			num+=a[i].a*abs(an[a[i].x]-an[a[i].y])+a[i].b*abs(an[a[i].y]-an[a[i].z])+a[i].c*abs(an[a[i].z]-an[a[i].x])+a[i].d*(an[a[i].x]-an[a[i].y])+a[i].e*(an[a[i].y]-an[a[i].z])+a[i].f*(an[a[i].z]-an[a[i].x]);
		ansn=min(ansn,num);
	}else{
		an[x]=-1;
		dfs(x+1);
		an[x]=1;
		dfs(x+1);
	}
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&t);
	while (t--){
		ansn=2147483647;
		memset(an,0,sizeof(an));
		scanf("%d %d %d %d",&n,&w,&p,&q);
		for (int i=1;i<=p;i++){
			scanf("%d %d %d %d %d %d %d %d %d",&a[i].x,&a[i].y,&a[i].z,&a[i].a,&a[i].b,&a[i].c,&a[i].d,&a[i].e,&a[i].f);
		}
		for (int i=1;i<=q;i++){
			scanf("%d %d %d",&b[i].x,&b[i].y,&b[i].z);
		}
		dfs(1);
		cout<<ansn*w<<endl;
	}
	return 0;
}
