#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int T,t,n;

int readit()
{
	int a=0;
	char x;
	x=getchar();
	while(x<'0'||x>'9')
	  x=getchar();
	while(x>='0'&&x<='9')
	{
		a=a*10+x-'0';
		x=getchar();
	}
	return a;
}

int A()
{
	int x,y,p,ret;
	x=readit();
	y=readit();
	for(p=0;p<=8;p++)
	  if((x>>p)%2!=(y>>p)%2)break;
	if((x>>p)%2==1)
	  return p+1;
	else
	  return p+1+9;
}

void B()
{
	int q,h;
	q=readit();
	h=readit();
	if(h>9)
	{
		h-=9;
		h-=1;
		if((q>>h)%2==0)
		  printf("yes\n");
		else
		  printf("no\n");
	}
	else
	{
		h-=1;
		if((q>>h)%2==1)
		  printf("yes\n");
		else
		  printf("no\n");
	}
}

int main()
{
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	scanf("%d%d%d",&t,&n,&T);
	while(T--)
	{
		if(t==1)
		  printf("%d\n",A());
		else
		  B();
	}
}
