#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int Begin[maxn], to[maxn], e, Next[maxn], n, K;

void add(int x,int y){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get(){
	n = read(), K = read();
}

struct edge{
	int Left, Right;
}Edge[maxn];

int ToT, flag;

void pre_work(){
	For(i, 1, n){
		For(j, i+1, n){
			Edge[++ToT].Left = i, Edge[ToT].Right = j;
		}
	}
}

int link[10][10], a[maxn];

void solve_bf(){
	pre_work(); 

	int tmp = (1 << ToT) - 1, Ans = 0;
	For(i, 0, tmp){

		flag = 0;

		For(j, 1, ToT){
			if(i & (1 << j-1)){
				link[Edge[j].Left][Edge[j].Right] = 1;
				link[Edge[j].Right][Edge[j].Left] = 0;
			}
			else{
				link[Edge[j].Left][Edge[j].Right] = 0;
				link[Edge[j].Right][Edge[j].Left] = 1;
			}
		}

		if(K == 3){
			For(i, 1, n){
				For(j, 1, n){
					For(k, 1, n){
						if(i == j || i == k || j == k) continue;
						if(link[i][j] && link[j][k] && link[k][i]){
							flag = 1;
							break;
						}
					}
					if(flag) break;
				}
				if(flag) break;
			}
		}

		else{
			For(i, 1, n){
				a[i] = i;
			}
			do{
				bool pd = 0;
				For(i, 1, n-1){
					if(!link[a[i]][a[i+1]]){
						pd = 1;break;
					}
				}
				if(pd) continue;
				if(!link[a[n]][a[1]]) continue;
				flag = 1; break;

			}while(next_permutation(a+1, a+n+1));
		}

		if(flag) ++ Ans;
	}

	printf("%d\n", Ans);
}

const int mod = 998244353;

int ksm(int x,int k){
	int s = 1;
	while(k){
		if(k&1) s = 1ll * s * x % mod;
		x = 1ll * x * x % mod;
		k >>= 1;
	}

	return s;
}

int jie[maxn];

void solve_spe(){
	jie[0] = 1;
	For(i, 1, n * n) jie[i] = 1ll * jie[i-1] * i % mod;
	printf("%lld\n", 1ll * jie[n-1] * ksm(2, n * (n-1) / 2 - n) % mod * jie[n * (n-1) / 2 - n] % mod);
}

int main(){
	
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);

	Get();
	if(n <= 6) solve_bf();
	else solve_spe();

	return 0;
}
