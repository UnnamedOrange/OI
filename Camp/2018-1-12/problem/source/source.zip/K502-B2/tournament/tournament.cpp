#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int n,K;
struct SHUI{
	struct W{
		int to,nx;
	}Lis[26];
	int Head[15],TTT;
	void Add(int x,int y){
		Lis[++TTT]=(W){y,Head[x]};
		Head[x]=TTT;
	}
	int x[26],y[26],tot;
	int mark[15],xx;
	bool f;
	void dfs(int x,int d){
		if(d>K)return;
		mark[x]=1;
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(mark[to]==0){
				dfs(to,d+1);
				if(f){
					mark[x]=0;
					return;
				}
			}else if(mark[to]==1){
				if(to==xx&&d==K){
					f=true;
					mark[x]=0;
					return;
				}
			}
		mark[x]=0;
	}
	bool check(int S){
		TTT=0;
		for(int i=0;i<n;i++)Head[i]=0;
		for(int i=0;i<tot;i++,S>>=1)
			if(S&1)Add(x[i],y[i]);
			else Add(y[i],x[i]);
		f=false;
		for(int i=0;i<n;i++){
			xx=i;
			dfs(i,1);
			if(f)return true;
		}
		return false;
	}
	void solve(){
		for(int i=0;i<n;i++)
			for(int j=i+1;j<n;j++)
				x[tot]=i,y[tot]=j,tot++;
		int ans=0;
		for(int i=0,up=(1<<tot);i<up;i++)ans+=check(i);
		printf("%d\n",ans);
	}
}P20;

int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d %d",&n,&K);
	if(n<=6)P20.solve();
	
	return 0;
}
