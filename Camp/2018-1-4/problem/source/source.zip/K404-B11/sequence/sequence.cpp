#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int t,n,no,ans,pos,a[300],b[300];

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		no=n;ans=0;
		while(no>0){
			while(a[no]==no)no--;
			if(no<=0)break;
			for(int i=1;i<=no;i++)
			  if(a[i]==no)
			  {
			  	pos=i==1?no:i;
				break;
			  }
			for(int i=1;i<=pos;i++)b[i]=a[i];
			for(int i=1;i<=pos;i++)a[i]=b[pos-i+1];
			ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}
