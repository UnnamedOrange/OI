《算法竞赛入门经典》代码仓库

热身代码

注意：有些题目并没有在书中出现，但是仍然有一定的启发意义，所以一并放在这里，供读者参考。

UVa10055 Hashmat the brave warrior
UVa10071 Back to High School Physics
UVa10300 Ecological Premium
UVa458   The Decoder
UVa494   Kindergarten Counting Game 
UVa414   Machined Surfaces
UVa490   Rotating Sentences
UVa445   Marvelous Mazes
UVa488   Triangle Wave
UVa489   Hangman Judge
UVa694   The Collatz Sequence
UVa457   Linear Cellular Automata
