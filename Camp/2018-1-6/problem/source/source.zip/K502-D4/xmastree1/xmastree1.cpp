#include<bits/stdc++.h>
#define N 100005
using namespace std;
int n,q,t;
int c[N];
int lastans;
int tot,head[N];
int T[N];
int ntot;
int stot;
int size[N],dep[N],fa[N],son[N],rank[N],newid[N];
int ans;
bool vis[N];
struct E{
	int to,next;
}e[N*2];
void addedge(int t1,int t2){
	tot++;
	e[tot].to=t2;
	e[tot].next=head[t1];
	head[t1]=tot;
}
void dfs1(int u,int fau){
	fa[u]=fau;
	size[u]=1;
	dep[u]=dep[fau]+1;
	for(int i=head[u];i;i=e[i].next){
		int v=e[i].to;
		if(v!=fa[u]){
			dfs1(v,u);
			size[u]+=size[v];
			if(!son[u]||size[v]>size[son[u]])
				son[u]=v;
		}
	}
}
void dfs2(int u){
	ntot++;
	rank[ntot]=u;
	newid[u]=ntot;
	if(son[u])
		dfs2(son[u]);
	for(int i=head[u];i;i=e[i].next){
		int v=e[i].to;
		if(v!=son[u]&&v!=fa[u])
			dfs2(v);
	}
}
int cur;
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]);
	for(int i=1;i<n;i++){
		int t1,t2;
		scanf("%d%d",&t1,&t2);
		addedge(t1,t2);
		addedge(t2,t1);
	}
	dfs1(1,1);
	dfs2(1);
	while(q--){
		int t1,t2,t3,t4=0;
		scanf("%d%d%d",&t1,&t2,&t3);
		if(t1==1) scanf("%d",&t4);
		if(t) t2^=lastans,t3^=lastans,t4^=lastans;
		if(t1==1){
			ans=0;
			for(int i=1;i<=n;i++) vis[i]=0;
			for(int i=t2;i<t2+size[t2];i++){
			if(c[rank[i]]<=t4&&c[rank[i]]>=t3&&vis[c[rank[i]]]==0)
					ans++,vis[c[rank[i]]]=1;
			}
			printf("%d\n",ans);
			lastans=ans;
		}
		else{
			c[t2]=t3;
		}
	}
	return 0;
}
