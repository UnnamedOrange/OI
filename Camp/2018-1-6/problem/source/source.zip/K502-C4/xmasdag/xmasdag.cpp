#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#define mod 998244353
using namespace std;

int n,m,k,u,v,head[100005],top;
long long ans[100005];

struct edge
{
	int v,next;
} s[200005];

long long fastpow(long long a,int p)
{
	long long sum=1;
	while(p)
	{
		if(p&1==1) sum*=a, sum%=mod;
		p=p>>1;
		a*=a;
		a%=mod;
	}
	return sum;
}

void dfs(int now,long long len)
{
	ans[now]+=fastpow(len,k);
	ans[now]%=mod;
	for(int i=head[now];i!=0;i=s[i].next)
	{
		int to=s[i].v;
		dfs(to,len+1);
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		s[++top].v=v; s[top].next=head[u]; head[u]=top;
	}
	dfs(1,0);
	for(int i=1;i<=n;i++)
		printf("%lld\n",ans[i]);
	return 0;
}
