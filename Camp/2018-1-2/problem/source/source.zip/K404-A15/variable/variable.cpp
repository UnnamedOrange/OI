#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,w,p,q;
int x[160],y[160],z[160],a[160],b[160],c[160],d[160],e[160],f[160],xx[160],yy[160],r[160];
int ans,sum,now[16];
int T;
int abs(int x)
{
	return x>0?x:-x;
}
void check(int t)
{
	for(int i=1;i<=n;t>>=1,i++)
		if(t&1) now[i]=w;
		else now[i]=-w;
	for(int i=1;i<=q;i++)
	{
		if(r[i]==0&&now[xx[i]]>now[yy[i]]) return;
		if(r[i]==1&&now[xx[i]]!=now[yy[i]]) return;
		if(r[i]==2&&now[xx[i]]>=now[yy[i]]) return;
	}
	sum=0;
	for(int i=1;i<=n;i++)
	sum+=now[i];
	for(int i=1;i<=p;i++)
	{
		sum+=a[i]*abs(now[x[i]]-now[y[i]])+b[i]*abs(now[y[i]]-now[z[i]])+c[i]*abs(now[z[i]]-now[x[i]])+
		d[i]*(now[x[i]]-now[y[i]])+e[i]*(now[y[i]]-now[z[i]])+f[i]*(now[z[i]]-now[x[i]]);
	}
	if(sum<ans) ans=sum;
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout); 
	scanf("%d",&T);
	while(T--)
	{
		ans=0x7fffffff;
		scanf("%d%d%d%d",&n,&w,&p,&q);
		for(int i=1;i<=p;i++)
		scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for(int i=1;i<=q;i++)
		scanf("%d%d%d",&xx[i],&yy[i],&r[i]);
		for(int i=0;i<(1<<n);i++)
		check(i);
		printf("%d",ans);	
	}
}
