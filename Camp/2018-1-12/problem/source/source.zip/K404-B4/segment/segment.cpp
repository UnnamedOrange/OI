#include <bits/stdc++.h>
#define getchar() *(pp++)
#define MOD 998244353
using namespace std;
char buf[10000100],*pp=buf;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int n,m,k;
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	fread(buf,sizeof(char),sizeof(buf),stdin);	
	n=read();
	m=read();
	k=read();
	int ret=0;
	for(int i=1;i<m;i++)
	{
		ret=(ret+(i*(m-i)%MOD))%MOD;
	}
	cout<<ret<<endl;
	return 0;
}
/*
*/
