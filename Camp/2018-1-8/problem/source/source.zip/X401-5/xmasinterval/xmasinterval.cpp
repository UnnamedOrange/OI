/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
#define MAXN 500000
#define MODP 1000000009
#define MOD(x) ((x)%MODP)
struct Range
{
    int l,r;
} a[MAXN+10];
int p[MAXN+10];
int tong[3*MAXN+10];
int cnt;
int n,m;
LL ans;
namespace bl
{
bool b[MAXN+10];
int cnt;
int t[MAXN+10];
void dfs(int now)
{
    if (now>n)
    {
        if (cnt==m) ++ans;
        return;
    }
    dfs(now+1);
    for(int i=1; i<=m; ++i)
    {
        if (a[now].l<=p[i] && p[i]<=a[now].r)
        {
            if (t[i]==0) ++cnt;
            ++t[i];
        }
    }
    dfs(now+1);
    for(int i=1; i<=m; ++i)
    {
        if (a[now].l<=p[i] && p[i]<=a[now].r)
        {
            --t[i];
            if (t[i]==0) --cnt;
        }
    }
}
}
namespace X
{
bool b[3*MAXN+10];
int f[MAXN+10];
vector<int> v[3*MAXN+10];
void main()
{
    memset(b,false,sizeof(b));
    for(int i=1; i<=n; ++i)
    {
        v[a[i].r].push_back(i);
    }
    f[1]=1;
    p[m+1]=cnt+1;
    for(int i=2; i<=m; ++i)
    {
        for(int x=p[i]; x<p[i+1]; ++x)
            for(int j=0; j<v[x].size(); ++j)
            {
                for(int k=(lower_bound(p+1,p+1+m,a[j].l)-p) ; k<=i; ++k)
                {
                    f[i]=MOD(f[i]+f[k]);
                }
            }
    }
    ans=f[m];
}
}
int main()
{
    freopen("xmasinterval.in","r",stdin);
#ifndef MDEBUG
    freopen("xmasinterval.out","w",stdout);
#endif
    scanf("%d%d",&n,&m);
    for(int i=1; i<=n; ++i)
    {
        scanf("%d%d",&a[i].l,&a[i].r);
        tong[++cnt]=a[i].l;
        tong[++cnt]=a[i].r;
    }
    for(int i=1; i<=m; ++i)
    {
        scanf("%d",&p[i]);
        tong[++cnt]=p[i];
    }
    sort(tong+1,tong+1+cnt);
    cnt=unique(tong+1,tong+1+cnt)-tong-1;
    for(int i=1; i<=n; ++i)
    {
        a[i].l=lower_bound(tong+1,tong+1+cnt,a[i].l)-tong;
        a[i].r=lower_bound(tong+1,tong+1+cnt,a[i].r)-tong;
    }
    sort(p+1,p+1+m);
    m=unique(p+1,p+1+m)-p-1;
    for(int i=1; i<=m; ++i)
    {
        p[i]=lower_bound(tong+1,tong+1+cnt,p[i])-tong;
    }
    if (n<=20 && m<=20)
    {
        bl::dfs(1);
    }
    else
    {
        X::main();
    }
    printf("%lld\n",ans);
    return 0;
}
