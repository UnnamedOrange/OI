#include<cstdio>
#include<iostream>
using namespace std;
int T,n,x[30];
int cnt=0,ans=0;
void swaps(int l,int r)
{
	for (;l<=r;l++,r--)
		swap(x[l],x[r]);
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
		ans=0;
		scanf("%d",&n); 
		for (int i=1;i<=n;i++)
			scanf("%d",&x[i]);
		cnt=n;
		for (int i=n;i>=1;i--)
			if (x[i]==cnt) cnt--;
			else break;
		while (cnt>1)
		{
			int pos=0;
			for (int i=1;i<=cnt;i++)
				if (x[i]==cnt) {pos=i;break;}
			if (pos==cnt){cnt--;continue;} 
			if (pos!=1)swaps(1,pos),ans++;
			swaps(1,cnt);
			ans++;
			cnt--;
	//		for (int i=1;i<=n;i++)
	//			printf("%d ",x[i]);
	//		printf("\n");
		}
		printf("%d\n",ans);
	}
}
