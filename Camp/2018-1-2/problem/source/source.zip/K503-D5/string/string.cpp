#include <cstdio>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=1e5+5;
int t,n,i,j,flag;
char st[N];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d%s",&n,st+1);
		flag=1;
		i=1; j=n;
		while (i<j)
		{
			if (st[i]!=st[j]) {flag=0;break;}
		    i++; j--;
		}
		if (!flag) printf("1\n");
		else {
			for (i=1;i<=n;i+=2)
			  if (i>1 && st[i]!=st[i-2]) flag=0;
			for (j=2;j<=n;j+=2)
			  if (j>2 && st[j]!=st[j-2]) flag=0;
			if (!flag) printf("2\n");
			else printf("-1\n");
		}
	}
	return 0;
}
