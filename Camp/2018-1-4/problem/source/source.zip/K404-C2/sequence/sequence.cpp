#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#include<vector>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
const int N=25,lim=1000005,m0=100007,m1=1000000007;
typedef long long LL;
int ok1,ok2;
int n,head1,head2,tail1,tail2,ans;
struct que
{
	int dis,a[N];
} q1[lim+5],q2[lim+5];
que operator * (que a,int x)
{
	rep(i,1,x>>1) swap(a.a[i],a.a[x-i+1]);
	return a;
}
struct data{int id,x;} ;
vector <data> vt[2][m0+5];
struct hsh{int a0,a1;} nw;

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

hsh gethash(que x)
{
	hsh rt=(hsh){0,0};
	rep(i,1,n)
		if(x.a[i]>9) rt.a0=((LL)rt.a0*100+x.a[i])%m0,rt.a1=((LL)rt.a1*100+x.a[i])%m1;
		else rt.a0=((LL)rt.a0*10+x.a[i])%m0,rt.a1=((LL)rt.a1*10+x.a[i])%m1;
	return rt;
}

bool check(bool tp)
{
	int siz=vt[tp][nw.a0].size();
	if(!siz) return 0;
	rep(i,0,siz-1) if(vt[tp][nw.a0][i].id==nw.a1) return 1;
	return 0;
}

void ins(bool tp,int x)
{
	vt[tp][nw.a0].push_back((data){nw.a1,x});
}

int query()
{
	int siz=vt[0][nw.a0].size(),rt=0;
	rep(i,0,siz-1) if(vt[0][nw.a0][i].id==nw.a1) {rt+=vt[0][nw.a0][i].x; break;}
	siz=vt[1][nw.a0].size();
	rep(i,0,siz-1) if(vt[1][nw.a0][i].id==nw.a1) {rt+=vt[1][nw.a0][i].x; break;}
	return rt;
}

void init()
{
	rep(i,0,m0-1) vt[0][i].clear(),vt[1][i].clear();
	ok1=ok2=0,ans=1000;
}

void solve()
{
	n=getint(),init();
	rep(i,1,n) q1[0].a[i]=getint(),q2[0].a[i]=i;
	head1=head2=0,tail1=tail2=1;
	q1[0].dis=q2[0].dis=0;
	nw=gethash(q1[0]),ins(0,0);
	nw=gethash(q2[0]),ins(1,0);
	while(head1!=tail1 || head2!=tail2)
	{
		while(head1!=tail1 && q1[head1].dis==ok1)
		{
			que x=q1[head1],v;
			if((++head1)>lim) head1=0;
			rep(i,2,n)
			{
				v=x*i,++v.dis,nw=gethash(v);
				if(!check(0))
				{
					q1[tail1]=v;
					if((++tail1)>lim) tail1=lim;
					ins(0,v.dis);
				}
				if(check(1))
				{
					ans=min(ans,query());
				}
			}
		}
		++ok1;
		while(head2!=tail2 && q2[head2].dis==ok2)
		{
			que x=q2[head2],v;
			if((++head2)>lim) head2=0;
			rep(i,2,n)
			{
				v=x*i,++v.dis,nw=gethash(v);
				if(!check(1))
				{
					q2[tail2]=v;
					if((++tail2)>lim) tail2=lim;
					ins(1,v.dis);
				}
				if(check(0))
				{
					ans=min(ans,query());
				}
			}
		}
		++ok2;
		if(ans!=1000) {printf("%d\n",ans); return;}
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	for(int T=getint(); T--; solve());
	return 0;
}
