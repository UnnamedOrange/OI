#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
using namespace std;

const int N=7;

int n,m,ans,st,u,x,cnt;
int f[N][N];
bool vis[N];

bool search(int k,int l,int st){
	int i; bool flag=0;
	vis[k]=1;
	for (i=1;i<=n;i++){
		if (!f[k][i]) continue;
		if (l==1&&i==st) return 1;
		if (vis[i]) continue;
		flag|=search(i,l-1,st);
	}
	vis[k]=0;
	return flag;
}

void dfs(int k){
	int i,j,s; bool tag;
	if (k>n){
		tag=0;
		for (st=1;st<=n;st++){
			memset(vis,0,sizeof(vis));
			tag|=search(st,m,st);
			if (tag) break;
		}
		ans+=tag;
		return;
	}
	for (s=0;s<(1<<k-1);s++){
		for (i=1;i<k;i++){
			f[k][i]=(s>>i-1)&1;
			f[i][k]=f[k][i]^1;
		}
		dfs(k+1);
	}
}

int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&m);
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
