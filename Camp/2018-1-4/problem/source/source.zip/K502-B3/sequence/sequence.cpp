#include <stdio.h>
#include <algorithm>
using namespace std;

long long int x[30];	
long long int T,n,l,flag;

inline long long int read()
{
    char ch;
    bool flag = false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

bool check()
{
	long long int i;
	for(i=1;i<=n;i++)
	{
		if(x[i]!=i)
			return 1;
	}
	return 0;
} 

long long int Astar()
{
	long long int i,temp=0;
	for(i=1;i<=n-1;i++)
	{
		if(abs(x[i+1]-x[i])>1)
			temp++;
	}
	return temp;
}

void change(long long int t)
{
	long long int i,temp;
	for(i=1;i<=t/2;i++)
	{
		temp=x[i];
		x[i]=x[t-i+1];
		x[t-i+1]=temp;
	}
	return;
}

void dfs(long long int t)
{
	if(t==l)
	{
		if(!check())
			flag=1;
		return; 
	}
	if(t+Astar()>l)
		return;
	long long int i;
	for(i=2;i<=n;i++)
	{
		change(i);
		dfs(t+1);
		if(flag)
			return;
		change(i);
	}
} 

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	T=read();
	while(T--)
	{
		flag=0;
		n=read();
		long long int i; 
		for(i=1;i<=n;i++)
			x[i]=read();
		for(l=0;;l++)
		{ 
			dfs(0); 
			if(flag)
			{
				printf("%lld",l);
				break;
			} 
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0; 
} 
