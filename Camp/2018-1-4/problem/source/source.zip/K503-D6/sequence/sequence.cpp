#include <map>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)
#define repd(i,x,y) for (int i=x; i>=(y); --i)

using namespace std;
const int inf=0x3f3f3f3f;

int tc,src,ter[10],n;

namespace force
{
    int idx,q[400000],h,t,dis[400000],a[10],k[1<<22|1],v[1<<22|1];
    
    void insert(int key,int val)
    {
        int i=key&((1<<22)-1);
        for (; ~v[i]; ++i);
        k[i]=key,v[i]=val;
    }
    
    int id(int x)
    {
        int i=x&((1<<22)-1);
        for (; ~v[i] && k[i]!=x; ++i);
        return v[i];
    }
    
    void work()
    {
        rep(i,1,n)
            a[i]=i;
        idx=0,memset(v,-1,sizeof(v));
        do
        {
            int x=0;
            rep(i,1,n)
                x=x*10+a[i];
            insert(x,++idx);
        } while (next_permutation(a+1,a+1+n));
        src=0;
        rep(i,1,n)
            src=src*10+i;
        q[h=t=0]=src,memset(dis,63,sizeof(dis)),dis[id(src)]=0;
        while (h<=t)
        {
            int x=q[h];
            repd(i,n,1)
                a[i]=x%10,x/=10;
            x=id(q[h++]);
            rep(i,2,n)
            {
                reverse(a+1,a+i+1);
                int y=0;
                rep(j,1,n)
                    y=y*10+a[j];
                if (dis[id(y)]==inf)
                    dis[id(y)]=dis[x]+1,q[++t]=y;
                reverse(a+1,a+i+1);
            }
        }
        rep(i,1,tc)
            printf("%d\n",dis[id(ter[i])]);
    }
}

int main()
{
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
    scanf("%d",&tc);
    rep(i,1,tc)
    {
        scanf("%d",&n);
        rep(j,1,n)
        {
            int x;
            scanf("%d",&x);
            ter[i]=ter[i]*10+x;
        }
    }
    if (n<10)
        force::work();
    return 0;
}
