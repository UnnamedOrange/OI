//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=507;
const int mod=998244353;
typedef long long LL;
using namespace std;
int n,m,lr[N];
LL dp[N][101][101][2];
char s[N][101],ss[N],my[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	read(n); read(m);
	if(n==1) {
		scanf("%s",ss+1);
		int len=strlen(ss);
		dp[0][0][0][0]=1;
		for(int i=1;i<=n;i++) 
			for(int j=1;j<=min(i,len);j++) 
				for(int k=1;k<=min(i,len);k++) {
					if(dp[i-1][j][k][0]||dp[i-1][j][k][1]) {
						
					}
				}
	}
	else {
		int ans=0;
		for(int i=1;i<=n;i++) {
			scanf("%s",s[i]);
			lr[i]=strlen(s[i]);
		}
		int nn=(1<<m);
		for(int i=0;i<nn;i++) {
			for(int j=0;j<m;j++) {
				if(i&(1<<j)) {
					my[j]='1'; my[2*m-j-1]='0';
				}
				else {
					my[j]='0'; my[2*m-j-1]='1';
				}
			}
			int fll=1;
			for(int j=1;j<=n;j++) {
				int fl=0;
				for(int k=0;k+lr[j]-1<2*m;k++) {
					fl=1;
					for(int l=0;l<lr[j];l++) 
						if(s[j][l]!=my[k+l]) {
							fl=0; break;
						}
					if(fl) break;
				}
				if(!fl) {fll=0; break;}
			}
			if(fll) ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}

