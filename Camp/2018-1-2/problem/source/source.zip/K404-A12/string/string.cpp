#include <iostream>
#include <cstdio>
#include <cstring>
#define N 100005
using namespace std;
char a[N<<1],s[N<<1];
int n,d[N<<1];
void manacher(){
	int pos=1,r=1;
	d[1]=1;
	for(int i=2;i<=n;i++){
		d[i]=1;
		if(r>i) d[i]=min(d[pos+pos-i],r-i+1);
		while(i-d[i]>0&&i+d[i]<=n&&s[i-d[i]]==s[i+d[i]]) d[i]++;
		if(i+d[i]-1>r) r=i+d[i]-1,pos=i;
	}
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%d%s",&n,a+1);
		for(int i=1;i<=n;i++){
			s[i+i-1]='#',s[i+i]=a[i];
		}
		n=n+n+1;
		s[n]='#';
		manacher();
		n>>=1;
		if(d[1+n]-1<n){
			puts("1");continue;
		}
		bool t=0;
		for(int i=1;i<n;i++){
			if(d[1+i]-1<i&&d[n+i+1]-1<n-i){
				t=1;break;
			}
		}
		if(t) puts("2");
		else puts("-1");
	}
	return 0;
}
