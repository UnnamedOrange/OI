#include<bits/stdc++.h>
using namespace std;
int main(){

freopen("function.out","w",stdout);
	return 0;
}

