#include<bits/stdc++.h>
using namespace std;
const int maxn=100;
struct node{
	int l,r;
}a[maxn];
bool vis[maxn];
int b[maxn];
int n,m,ans;
void solve(){
	bool bo;
	for(int i=1;i<=m;i++){
		bo=0;
		for(int j=1;j<=n;j++){
			if(vis[j]&&a[j].l<=b[i]&&b[i]<=a[j].r){
				bo=1;
				break;
			}
		}
		if(!bo) return;
	}
	ans++;
}
void dfs(int p){
	if(p>n){
		solve();
		return;
	}
	vis[p]=1;
	dfs(p+1);
	vis[p]=0;
	dfs(p+1);
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("baoli.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&a[i].l,&a[i].r);
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	dfs(1);
	printf("%d\n",ans);
	cerr<<ans<<endl;
	return 0;
}
