#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=30;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
}
int T,n,a[N],ans;
inline int G()
{
	int ret=0;
	For(i,1,n)ret+=(a[i+1]!=a[i]-1&&a[i+1]!=a[i]+1);
	return ret;
}
inline bool check()
{
	For(i,1,n)if(a[i]!=i)return 0;
	return 1;
}
inline bool dfs(int cnt)
{
	if(cnt+G()>ans)return 0;
	//if(cnt>ans)return 0;
	if(check()){chkmin(ans,cnt);return 1;}
	For(i,2,n)
	{
		reverse(a+1,a+i+1);
		if(dfs(cnt+1))return 1;
		reverse(a+1,a+i+1);
	}
	return 0;
}
int main()
{
	file();
	read(T);
	while(T--)
	{
		read(n);
		For(i,1,n)read(a[i]);a[n+1]=n+1;
		for(ans=1;;ans++)if(dfs(0))break;
		printf("%d\n",ans);
	}
	return 0;
}
