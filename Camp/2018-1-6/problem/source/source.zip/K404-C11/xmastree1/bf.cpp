#include <bits/stdc++.h>

namespace {

const int MAXN = 100000 + 9;

int c[MAXN], in[MAXN], out[MAXN], id[MAXN], idx;
std::bitset<MAXN> buc;
std::vector<int> edge[MAXN];

inline void addEdge(const int u, const int v) {
    edge[u].push_back(v);
    edge[v].push_back(u);
}

void dfs(const int u, const int fa) {
    in[u] = ++idx;
    id[idx] = u;
    for (register int i = 0, v; i < (int)edge[u].size(); i++) 
        if ((v = edge[u][i]) != fa) dfs(v, u);
    out[u] = idx;
}

inline void solve() {
    register int n, q, t;
    std::cin >> n >> q >> t;
    for (register int i = 1; i <= n; i++) {
        std::cin >> c[i];
    }
    for (register int i = 1, u, v; i < n; i++) {
        std::cin >> u >> v;
        addEdge(u, v);
    }
    dfs(1, 0);
    register int ans = 0;
    for (register int cmd, u, l, r, col; q--;) {
        std::cin >> cmd;
        switch (cmd) {
            case 1: {
                std::cin >> u >> l >> r;
                if (t) {
                    u ^= ans;
                    l ^= ans;
                    r ^= ans;
                }
                buc.reset();
                for (register int i = in[u]; i <= out[u]; i++) {
                    if (c[id[i]] >= l && c[id[i]] <= r) buc.set(c[id[i]]);
                }
                ans = buc.count();
                std::cout << ans << '\n';
                break;
            }
            case 2: {
                std::cin >> u >> col;
                if (t) {
                    u ^= ans;
                    col ^= ans;
                }
                c[u] = col;
            }
        } 
    }
}
}

int main() {
    freopen("xmastree1.in", "r", stdin);
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);
    solve();
    return 0;
}