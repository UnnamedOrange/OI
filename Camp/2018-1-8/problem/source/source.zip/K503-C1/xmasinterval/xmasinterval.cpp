# include <bits/stdc++.h>
# define 	N 		1000100
# define 	P 		1000000009
# define 	ll 		int 
using namespace std;
struct node{
	ll l,r;
}p[N];
ll f[N],h[N],q[N],m,n,num,ans,h2[N],h3[N],use[N];
bool cmp(node x, node y){
	return x.r<y.r||x.r==y.r&&x.l>y.l;
}
ll mypow(ll x, ll y){
	ll i=x; x=1;
	while (y>0){
		if (y%2==1) x=x*i%P;
		i=i*i%P;
		y/=2;
	}
	return x;
}
ll read(){
	ll tmp=0, fh=1; char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') fh=-1; ch=getchar();}
	while (ch>='0'&&ch<='9'){tmp=tmp*10+ch-'0'; ch=getchar();}
	return tmp*fh;
}
ll lowbit(ll x){
	return x&(-x);
}
ll findl(ll x){
	ll pl=1, pr=m, ans=m+1;
	while (pl<=pr){
		ll mid=(pl+pr)/2;
		if (q[mid]>=x){
			ans=mid;
			pr=mid-1;
		}
		else pl=mid+1;
	}
	return ans;
}
ll findr(ll x){
	ll pl=1, pr=m, ans=0;
	while (pl<=pr){
		ll mid=(pl+pr)/2;
		if (q[mid]<=x){
			ans=mid;
			pl=mid+1;
		}
		else pr=mid-1;
	}
	return ans;
}
ll query(ll x){
	ll num=0;
	while (x>0){
		num=(num+h[x])%P;
		x=x-lowbit(x);
	}
	return num;
}
void modify(ll x, ll num){
	while (x<=m+1){
		h[x]=(h[x]+num)%P;
		x=x+lowbit(x);
	}
}
ll querydel(ll x){
	ll num=0;
	while (x>0){
		num=(num+h2[x])%P;
		x=x-lowbit(x);
	}
	return num;
}
void modifydel(ll x, ll num){
	while (x<=m+1){
		h2[x]=(h2[x]+num)%P;
		x=x+lowbit(x);
	}
}
ll querynum(ll x){
	ll num=0;
	while (x>0){
		num=(num+h3[x])%P;
		x=x-lowbit(x);
	}
	return num;
}
void modifynum(ll x, ll num){
	while (x<=m+1){
		h3[x]=(h3[x]+num)%P;
		x=x+lowbit(x);
	}
}
bool check(){
	for (int i=2; i<=m+1; i++)
		if (use[i]==false) return false;
	return true;
}
void work(int k){
	if (k>n) {
		ans=ans+check();
		return;
	}
	work(k+1);
	for (int i=p[k].l; i<=p[k].r; i++) use[i]++;
	work(k+1);
	for (int i=p[k].l; i<=p[k].r; i++) use[i]--;
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read(); m=read();
	for (ll i=1; i<=n; i++)
		p[i].l=read(), p[i].r=read();
	for (ll i=1; i<=m; i++)
		q[i]=read();
	sort(q+1,q+m+1);
	num=0;
	for (ll i=1,la=0; i<=m; i++){
		if (q[i]!=la){
			la=q[i];
			q[++num]=q[i];
		}
	}
	m=num;
	for (ll i=1; i<=n; i++){
		p[i].l=findl(p[i].l)+1;
		p[i].r=findr(p[i].r)+1;
	}
	sort(p+1,p+n+1,cmp);
	num=0; ans=1;
	for (ll i=1; i<=n; i++){
		if (p[i].l>p[i].r)
			ans=(ans*2)%P;
			else p[++num]=p[i];
	}
	n=num;
	num=ans, ans=0;
	/*f[1]=1; modify(1,1);
	n=num;
	for (ll i=1,k=0; i<=n; i++){
		if (p[i].r==p[i+1].r&&i<n){
			k++;
			continue;
		}
		ll num=(query(p[i].r)-query(p[i].l-2)+P)%P;
		ll del=(querydel(p[i].r)-querydel(p[i].l-1)+P)%P;
		ll delnum=(querynum(p[i].r)-querynum(p[i].l-1)+P)%P;
		num=(num-del+P)%P*mypow(2,delnum+k)%P;
		f[p[i].r]=(f[p[i].r]+num)%P;
		modify(p[i].r,num); 
		modifydel(p[i].l,num); modifynum(p[i].l,1);
		k=0;
	}
	printf("%lld\n",(long long)(f[m+1])*(long long)(ans));*/
	work(1);
	printf("%d\n",ans*num);
	return 0;
}

