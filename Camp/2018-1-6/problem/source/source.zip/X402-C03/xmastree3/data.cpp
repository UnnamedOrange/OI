#include<bits/stdc++.h>
using namespace std;

int main(){
	srand(time(0));
	freopen("xmastree3.in","w",stdout);
	int n=20,k=15;
	n-=rand()%n/4;
	k-=rand()%k/4;
	printf("%d %d\n",n,k);
	for(int i=2;i<=n;++i)
		printf("%d %d\n",rand()%(i-1)+1,i);
}
