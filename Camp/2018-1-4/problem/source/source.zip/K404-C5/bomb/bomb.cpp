#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> pii;
inline int rd(){
	char ch=getchar();int i=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getchar();}
	return i*f;
}
const int N=1e6+50;
int n,m,g[N],v[N],nt[N],ec;
int low[N],dfn[N],bl[N],sze[N],ind,bnum;
int st[N],ins[N],tp;
int deg[N];
vector<int>son[N];
inline void add(int x,int y){
	nt[++ec]=g[x];g[x]=ec;v[ec]=y;
}
inline void dfs(int x){
	dfn[x]=++ind; low[x]=dfn[x];
	st[++tp]=x; ins[x]=1;
	for(int e=g[x];e;e=nt[e]){
		if(!dfn[v[e]]){
			dfs(v[e]);
			low[x]=min(low[x],low[v[e]]);
		}else if(ins[v[e]]){
			low[x]=min(low[x],dfn[v[e]]);
		}
	}
	if(low[x]==dfn[x]){
		++bnum;
		do{
			sze[bnum]++;
			int u=st[tp--];
			bl[u]=bnum;
			ins[u]=0;
		}while(st[tp+1]!=x);
	}
}
priority_queue< pii,vector<pii>,greater<pii> >q;
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=rd(),m=rd();
	for(int i=1;i<=m;i++){
		int x=rd(),y=rd();
		add(x,y);
	}
	for(int i=1;i<=n;i++)
		if(!dfn[i])dfs(i);
	for(int i=1;i<=n;i++)
		for(int e=g[i];e;e=nt[e]){
			if(bl[i]!=bl[v[e]]){
				son[bl[i]].push_back(bl[v[e]]);
				++deg[bl[v[e]]];
			}
		}
	int ans=0;
	for(int i=1;i<=bnum;i++)
		if(!deg[i])q.push(make_pair(sze[i],i));
	while(!q.empty()){
		register pii t=q.top();q.pop();
		register int d=t.first-ans,u=t.second;
		ans+=d;
		for(register int e=son[u].size()-1;e>=0;e--){
			register int vt=son[u][e];
			--deg[vt];
			(!deg[vt])&&(q.push(make_pair(sze[vt]+ans,vt)),0);
		}
	}
	cout<<ans<<'\n';
	
}
