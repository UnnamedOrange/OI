#include <bits/stdc++.h>
#define rep(a,b,c) for (int a=b;a<=c;a++)
int type, N;

void init()
{
    
}

int encode(int x, int y)
{
	rep(i,0,9) if ((x&(1<<i))^(y&(1<<i))) return i*2+(x&(1<<i)?1:2);
    return x;
}

bool decode(int q, int h)
{
	return ((h&1)^((q>>((h-1)/2))&1))==0;
    return q == h;
}

int main()
{
    int T;
    freopen("xmasset.in","r",stdin);
    freopen("xmasset.out","w",stdout);
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
