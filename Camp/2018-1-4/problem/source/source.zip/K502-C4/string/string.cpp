#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#define mod 998244353
using namespace std;

int n,m,len[10];
char s[10][105],c[1005];
long long ans;

void half()
{
	for(int i=1;i<=m;i++)
	{
		int j=m*2-i+1;
		if(c[i]=='0') c[j]='1';
		else c[j]='0';
	}
}

bool judge(int k)
{
	for(int i=1;i<=m*2-len[k]+1;i++)
	{
		if(c[i]==s[k][1])
		{
			int flag=1;
			for(int j=2;j<=len[k];j++)
				if(c[i+j-1]!=s[k][j]) { flag=0; break; }
			if(flag==1) return true;
		}
	}
	return false;
}

bool check()
{
	for(int i=1;i<=n;i++)
		if(judge(i)==0) return false;
	return true;
}

void dfs(int now)
{
	if(now==m+1)
	{
		half();
		if(check())
		{
			ans++;
			ans%=mod;
		}
		return;
	}
	c[now]='0';
	dfs(now+1);
	c[now]='1';
	dfs(now+1);
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%s",s[i]+1);
	for(int i=1;i<=n;i++)
		len[i]=strlen(s[i]+1);
	dfs(1);
	printf("%lld",ans);
	return 0;
}
