#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=2e5+10;
char str[maxn];
int P[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,T;
#ifndef ONLINE_JUDGE
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	T=read();
	while(T--){
		memset(P,0,sizeof(P));
		n=read();
		scanf("%s",str);
		for(i=n;i>=0;i--){
			str[i+i+2]=str[i];
			str[i+i+1]='$';
		}
		str[0]='*';
		int id=0;
		for(i=1;i<=2*n+1;i++){
			if(P[id]+id>i)P[i]=min(P[id*2-i],P[id]+id-i);
			else P[i]=1;
			while(str[i-P[i]]==str[i+P[i]])P[i]++;
			if(P[i]+i>P[id]+id)id=i;
		}
		for(i=1;i<=2*n+1;i++)P[i]--;
		if(P[n+1]!=n){
			puts("1");
			continue;
		}
		int flag=0;
		for(i=1;i<=n-1;i++)
			if(P[i+1]<i && P[n+i+1]<n-i)flag=1;
		if(flag)puts("2");
		else puts("-1");
	}
	return 0;
}
