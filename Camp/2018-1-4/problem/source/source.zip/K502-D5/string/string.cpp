#include<bits/stdc++.h>
using namespace std;

int n,m,al[10];
char s[1020],a[10][1020];

void read()
{
	int i;
	
	cin>>n>>m;
	for(i=0;i<n;i++) cin>>a[i],al[i]=strlen(a[i]);
}

void buildstr(int S)
{
	int i;
	
	for(i=0;i<m;i++) s[i]=((S&1<<i)!=0)+'0';
	for(i=m;i<2*m;i++) s[i]=((S&1<<(2*m-i-1))==0)+'0';
	//cout<<s<<endl;
}

bool findstr(int x)
{
	int i,j;
	
	for(i=0;i<=2*m-al[x];i++)
	{
		for(j=0;j<al[x];j++) if(a[x][j]!=s[i+j]) break;
		if(j==al[x]) return true;
	}
	return false;
}

void solve()
{
	int S,i,ans=0;
	
	for(S=0;S<(1<<m);S++)
	{
		buildstr(S);ans++;
		for(i=0;i<n;i++) if(!findstr(i)) {ans--;break;}
	}
	cout<<ans;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	
	read();
	solve();
	
	return 0;
}
