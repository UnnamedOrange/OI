#include <cstdio>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

typedef long long ll;
const int NN = 100010;
const int mod = 998244353;

int n, j, N, M, fl, a[NN], vis[NN];
ll ans;

void work(int x)
{
	int tmp = 1; vis[x] = 1;
	for(j = a[x]; j && j != x; j = a[j])
	{
		++tmp;
		vis[j] = 1;
	}
	if (j == x)
	{
		if (tmp & 1) fl = 1; 
	}
	else if (tmp & 1) ++M; else ++N;
}

int main()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	scanf("%d", &n); ans = 1;
	FOR(i, 1, n) scanf("%d", &a[i]);
	FOR(i, 1, n) if (!vis[i]) work(i);
	if (fl || (M & 1)) {puts("0"); return 0;}
	for(ll i = 1; i < M; i += 2) ans = ans * i % mod * i % mod;
	for(ll i = M + 1; i < M + N + 1; ++i) ans = ans * i % mod;
	printf("%lld\n", ans);
	return 0;
}
