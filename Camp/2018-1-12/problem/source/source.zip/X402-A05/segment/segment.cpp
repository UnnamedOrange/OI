#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0*clock()/CLOCKS_PER_SEC << std::endl
#define fst first
#define snd second

typedef long long LL;
typedef std::pair<int, int> Pii;

#ifndef __linux__
#define getchar getchar_unlocked
#endif
template <typename T> inline bool maximum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T> inline bool minimum(T &a, T b) { return a > b? a = b, 1 : 0; }
template <typename T> 
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 1e4 + 10, mod = 998244353;

int fpm(int e, int x)
{
	int res = 1; 
	for(; x; x >>= 1){
		if(x & 1) res = (LL)res * e % mod;
		e = (LL)e * e % mod;
	}
	return res;
}

int n, m, k;

void Init()
{
	read(n), read(m), read(k);
}

namespace SEGT
{
#define lc (h << 1)
#define rc (lc | 1)

	int cnt[N << 2];

	void clear()
	{
		for(int i = 1; i <= n << 2; ++i) cnt[i] = 0;
	}

	void modify(int h, int l, int r, int u)
	{
		++cnt[h];

		int mid = (l + r) >> 1;
		if(l ^ r)
			u <= mid? modify(lc, l, mid, u) : modify(rc, mid + 1, r, u);
	}

	int query(int h, int l, int r, int u)
	{
		if(l == r) return cnt[h];

		int mid = (l + r) >> 1;
		return (u > mid? query(rc, mid + 1, r, u) : 0) + query(lc, l, mid, u);
	}
}

namespace bfer
{
	int a[N], Ans;

	void dfs(int l, int r, int cnt)
	{
		if(cnt > n){
			for(int i = 1; i <= m; ++i){
				Ans += fpm(a[i], k);
				if(Ans >= mod) Ans -= mod;
			}
			return ;
		}
		for(int L = l + 1; L <= m; ++L)
			for(int R = std::max(l, r+1); R <= m; ++R){
				for(int i = L; i < R; ++i) ++a[i];
				dfs(L, R, cnt + 1);
				for(int i = L; i < R; ++i) --a[i];
			}
	}

	void main()
	{
		dfs(0, 0, 1);
		printf("%d\n", Ans);

		return ;
	}
}

namespace N_1
{
	int Ans;

	void main()
	{
		for(int i = 1; i < m; ++i){
			Ans = (Ans + (LL)i * (m-i) % mod) % mod;
		}
		printf("%d\n", Ans);

		return ;
	}
}

namespace N_2
{
	int fac[N], ifac[N];
	int Ans;

	void Init()
	{
		for(int i = 0; i <= m; ++i) fac[i] = i? (LL)fac[i-1] * i : 1;
		ifac[m] = fpm(fac[m], mod - 2);
		for(int i = m; i >= 1; --i) ifac[i-1] = (LL)ifac[i] * i % mod;
	}

	int C(int a, int b)
	{
		if(a < b) return 0;
		return (LL)fac[a] * ifac[b] % mod * ifac[a-b] % mod;
	}

	void main()
	{
		Init();
		for(int i = 1; i <= m; ++i){
			int c0 = (C(i, 4) + C(m-i, 4)) * 2LL % mod;
			int c2 = (LL)C(i, 2) * C(m-i, 2) % mod;
			c0 = (c0 + c2) % mod;
			int c1 = ((C(m, 4)*2LL-c0-c2) % mod + mod) % mod;
			Ans += ((LL)c2 * fpm(2, k) % mod + c1) % mod;
			if(Ans >= mod) Ans -= mod;
			(Ans += (LL)C(m-i, 2) * i % mod) %= mod;
			(Ans += (LL)C(i, 2) * (m-i) % mod) %= mod;
		}
		printf("%d\n", Ans);
	}
}

int main()
{
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);

	Init();
	if(m <= 5) bfer::main();
	else if(n == 1) N_1::main();
	else if(n == 2) N_2::main();

	return 0;
}
//TODO GKKAK
