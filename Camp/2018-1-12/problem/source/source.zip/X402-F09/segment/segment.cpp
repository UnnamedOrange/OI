#include<bits/stdc++.h>
#define ll long long
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=998244353;
int ksm(int x,int y){
	ll an=1,s=x; int f=1;
	while(y){
		if (y&f) an=an*s%mo,y^=f;
		s=s*s%mo,f<<=1;
	}
	return (int)an;
}
int n,m,h,q[100005],an[100005],ans;
void dfs(int x,int y,int z){
	if (z==n+1){
		For(i,1,m){
			ans+=an[q[i]];
			if (ans>=mo) ans-=mo;
		}
		return;
	}
	int f,r=m+z-n;
	For(i,x+1,r){
		f=max(i,y+1);
		For(j,f,r){
			if (j>i) ++q[j-1];
			dfs(i,j,z+1);
		}
		f=max(i,f-1);
		For(j,f,r-1) --q[j];
	}
}
int main(){
	freopen("segment.in","r",stdin); freopen("segment.out","w",stdout);
	n=read(),m=read(),h=read(); int x=0;
	if (n>=m) printf("0\n"),exit(0);
	if (n==1){
		For(i,1,m-1){
			x=x+i; if (x>=mo) x-=mo;
			ans+=x; if (ans>=mo) ans-=mo;
		}
		printf("%d\n",ans);
	}
	else{
		For(i,1,n) an[i]=ksm(i,h); dfs(0,0,1); printf("%d\n",ans);
	}
	return 0;
}
