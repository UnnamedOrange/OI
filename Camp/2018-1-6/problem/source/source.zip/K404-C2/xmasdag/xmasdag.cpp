#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cctype>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
typedef long long LL;
const int N=100005,M=200005,K=505,mod=998244353;
bool vis[N];
int n,m,k,cnt,x,h[N],u,v,cty,C[N],c[K][K],f[N][K];
struct edge{int v,n;} e[M];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void addedge(int u,int v)
{
	e[cnt]=(edge){v,h[u]},h[u]=cnt++;
}

void dfs(int x)
{
	vis[x]=1;
	for(int i=h[x]; i!=-1; i=e[i].n)
		if(!vis[e[i].v]) dfs(e[i].v);
	C[n-cty]=x,++cty;
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=getint(),m=getint(),k=getint(),memset(h,-1,sizeof(h));
	rep(i,1,m) u=getint(),v=getint(),addedge(u,v);
	dfs(1);
	rep(i,0,k) c[i][0]=c[i][i]=1;
	rep(i,1,k)
		rep(j,1,i)
			c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
	f[1][0]=1;
	rep(i,1,n)
	{
		x=C[i];
		for(int j=h[x]; j!=-1; j=e[j].n)
			rep(a,0,k)
				rep(b,0,a)
					f[e[j].v][a]=(f[e[j].v][a]+(LL)c[a][a-b]*f[x][b])%mod;
	}
	rep(i,1,n) printf("%d\n",f[i][k]);
	return 0;
}			
