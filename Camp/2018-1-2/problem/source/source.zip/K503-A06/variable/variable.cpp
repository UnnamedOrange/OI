#include<cmath>
#include<cstdio>
#include<algorithm>
using namespace std;
#define N 17 
#define M 30
#define LL long long
#define rep(i,j,k) for(i=j;i<=k;++i)
struct node1{
	int x,y,z,a,b,c,d,e,f;
}ed1[M];
struct node2{
	int x,y,r;
}ed2[M];
int tes,i,j,k,n,W,p,q,w[N];
LL ans;
void read(int &p){
	p=0; char x=getchar(); bool fu=false;
	if(x=='-') fu=true;
	while(x<'0' || x>'9') {x=getchar(); if(x=='-') fu=true;}
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar(); }
	if(fu) p=-p;
}
void init(){
	read(n); read(W); read(p); read(q);
	rep(i,1,p){
		read(ed1[i].x); read(ed1[i].y); read(ed1[i].z); 
		read(ed1[i].a); read(ed1[i].b); read(ed1[i].c); read(ed1[i].d); read(ed1[i].e); read(ed1[i].f);
	}
	rep(i,1,q){
		read(ed2[i].x); read(ed2[i].y); read(ed2[i].r);
	}
}
bool check(){
	int i;
	rep(i,1,q){
		if(ed2[i].r==0){
			if(w[ed2[i].x]>w[ed2[i].y]) return false;
		}else
		if(ed2[i].r==1){
			if(w[ed2[i].x]!=w[ed2[i].y]) return false;
		}else
		if(ed2[i].r==2){
			if(w[ed2[i].x]>=w[ed2[i].y]) return false;
		}
	}
	return true;
}
LL calc(){
	int i;LL sum=0;
	rep(i,1,n) sum+=w[i];
	rep(i,1,p){
		int x=ed1[i].x; int y=ed1[i].y; int z=ed1[i].z;
		LL a=ed1[i].a; LL b=ed1[i].b; LL c=ed1[i].c; LL d=ed1[i].d; LL e=ed1[i].e; LL f=ed1[i].f; 
		sum+=a*1ll*abs(w[x]-w[y])+b*1ll*abs(w[y]-w[z])+c*1ll*abs(w[z]-w[x])+d*1ll*(w[x]-w[y])+e*1ll*(w[y]-w[z])+f*1ll*(w[z]-w[x]);
	} 
	return sum; 
}
void dfs(int k){
	if(k>n){
		if(check()) {
			ans=min(ans,calc());
		}
		return ;
	}
	w[k]=W;
	dfs(k+1);
	w[k]=-W;
	dfs(k+1); 
} 
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	read(tes);
	while(tes--){
		init();
		ans=1e15;
		dfs(1);
		printf("%lld\n",ans);
	}
	return 0;
}   
