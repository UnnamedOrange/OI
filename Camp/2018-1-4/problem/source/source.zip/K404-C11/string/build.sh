#!/bin/bash
'/c/Program Files/Dev-Cpp/MinGW64/bin/g++' -g string.cpp -o string -DDBG -Wall -Wextra -m32
