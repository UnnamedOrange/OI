//© 2018 Jazengm/ZengXiangru, AllRightsReserved

#include<bits/stdc++.h>
using namespace std;

//#define debug
#ifdef debug
#define DB(x) x
#endif
#ifndef debug
#define DB(x)
#endif
#define DB2(x)

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;
typedef pair<db, db> pr;
#define fst first
#define snd second
#define mP make_pair

const int mxn=1<<20;

int n, x, y;

#define opr(a, b, c) (x=a, y=b, c())
#define top int u=1, int l=1, int r=n
#define mid ((l+r)>>1)
#define ls u<<1, l, mid
#define rs u<<1|1, mid+1, r

struct segTree1
{
    db a[mxn<<2], b[mxn<<2];
    void bui(top)
    {
        b[u]=r-l+1, a[u]=1;
        if(l==r) Re;
        bui(ls), bui(rs);
    }
    In void mT(int u)
    {
        u[a]=a[u<<1]*a[u<<1|1];
        u[b]=b[u<<1]*a[u<<1|1]+b[u<<1|1];
    }
    void mul(top)
    {
        if(l==r)
        {b[u]=a[u]=0.5; Re;}
        if(x>mid)
            mul(rs);
        else
            mul(ls);
        mT(u);
    }
    pr qry(top)
    {
        DB2(printf("%d %d %d\n", u, l, r);)
        if(r<x || y<l) Re mP(1, 0);
        if(l>=x && y>=r)
            Re mP(a[u], b[u]);
        pr p1=qry(ls), p2=qry(rs);
        Re mP(p1.fst*p2.fst, p1.snd*p2.fst+p2.snd);
    }
} seg1;

struct segTree2
{
    db a[mxn<<2], b[mxn<<2];
    void bui(top)
    {
        b[u]=r-l+1, a[u]=1;
        if(l==r) Re;
        bui(ls), bui(rs);
    }
    In void mT(int u)
    {
        u[a]=a[u<<1]*a[u<<1|1];
        u[b]=b[u<<1]+b[u<<1|1]*a[u<<1];
        DB2(printf("%d: %.4f\n", u, u[a]);)
    }
    In void mul(top)
    {
        if(l==r)
        {u[b]=u[a]=0.5; Re;}
        if(x>mid)
            mul(rs);
        else
            mul(ls);
        mT(u);
    }
    pr qry(top)
    {
        if(r<x || y<l) Re mP(1, 0);
        if(l>=x && y>=r)
            Re mP(a[u], b[u]);
        pr p1=qry(ls), p2=qry(rs);
        Re mP(p1.fst*p2.fst, p1.snd+p2.snd*p1.fst);
    }
}seg2;

In void init()
{
    seg1.bui();
    seg2.bui();
}

int main()
{
    freopen("drink.in", "r", stdin);
    freopen("drink.out", "w", stdout);
    St pair<int, int> a[mxn];
    scanf("%d", &n);
    inc(1, i, n+1)
        scanf("%d", &a[i].fst), a[i].snd=i;
    db ans=0;
    sort(a+1, a+n+1);
    init();
    dec(0, i, n)
    {
        Rg int j=a[i].snd;
        opr(j, 0, seg1.mul), opr(j, 0, seg2.mul);
        double r1=opr(1, j, seg1.qry).snd, r2=opr(j, n, seg2.qry).snd;
        DB(printf("r1: %.4f; r2: %.4f.\n", r1, r2);)
        ans+=2.0*a[i].fst*r1*r2;
        DB(printf("%.4f\n", ans);)
    }
    printf("%.6f\n", ans/n/n);
    Re 0;
}
