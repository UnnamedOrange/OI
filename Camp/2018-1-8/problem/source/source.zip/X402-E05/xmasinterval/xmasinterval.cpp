#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define lc p<<1
#define rc p<<1|1
#define ls l,mid
#define rs mid+1,r
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define lowbit(x) (x&-x)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=500010;
const int inf=0x3f3f3f3f;
const int mod=1e9+9;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
}
int n,m;
int x[N],sum[N<<2],mul[N<<2];
struct node
{
	int l,r;
	node(){}
	node(int l,int r):l(l),r(r){}
}a[N];
inline bool operator<(const node&A,const node&B){return A.r<B.r;}
inline void Add(int&x,int y){x=x+y<mod?x+y:x+y-mod;}
inline void pushdown(int p)
{
	if(mul[p]!=1)
	{
		mul[lc]=1ll*mul[lc]*mul[p]%mod,sum[lc]=1ll*sum[lc]*mul[p]%mod;
		mul[rc]=1ll*mul[rc]*mul[p]%mod,sum[rc]=1ll*sum[rc]*mul[p]%mod;
		mul[p]=1;
	}
}
inline void Add_tree(int l,int r,int p,int x,int y)
{
	if(l==r){Add(sum[p],y);return;}
	int mid=(l+r)>>1;
	pushdown(p);
	if(x<=mid)Add_tree(ls,lc,x,y);
	else	  Add_tree(rs,rc,x,y);
	Add(sum[p]=sum[lc],sum[rc]);
}
inline void mult_tree(int l,int r,int p,int x,int y)
{
	if(x<=l&&r<=y){Add(sum[p],sum[p]);Add(mul[p],mul[p]);return;}
	int mid=(l+r)>>1;
	pushdown(p);
	if(x<=mid)mult_tree(ls,lc,x,y);
	if(y> mid)mult_tree(rs,rc,x,y);
	Add(sum[p]=sum[lc],sum[rc]);
}
inline int Sum_tree(int l,int r,int p,int x,int y)
{
	if(x<=l&&r<=y)return sum[p];
	int mid=(l+r)>>1,ret=0;
	pushdown(p);
	if(x<=mid)Add(ret,Sum_tree(ls,lc,x,y));
	if(y> mid)Add(ret,Sum_tree(rs,rc,x,y));
	return ret;
}
int main()
{
	file();
	read(n),read(m);
	For(i,1,n)read(a[i].l),read(a[i].r);
	For(i,1,m)read(x[i]);
	sort(x+1,x+m+1);
	For(i,1,n)
	{
		a[i].l=lower_bound(x+1,x+m+1,a[i].l)-x;
		a[i].r=upper_bound(x+1,x+m+1,a[i].r)-x-1;
	}
	sort(a+1,a+n+1);
	For(i,1,m*4)mul[i]=1;
	Add_tree(0,m,1,0,1);
	For(i,1,n)
	{
		int ret=Sum_tree(0,m,1,a[i].l-1,a[i].r);
		Add_tree(0,m,1,a[i].r,ret);
		if(a[i].l>=2)mult_tree(0,m,1,0,a[i].l-2);
	}
	printf("%d\n",Sum_tree(0,m,1,m,m));
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
