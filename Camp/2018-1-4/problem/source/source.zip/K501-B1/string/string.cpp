#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define mod 998244353
using namespace std;
// ������ ������QAQ
typedef long long LL;
int n,m,len[8];
char s[8][120];
int f[505][(1<<6)|1],fit[7][7][105];
bool v[8];
int a[32],ans;
bool o(int x,int p)
{
	for(int i=0;i<len[x];i++)
	if(s[x][i]!=a[p++]+'0')return 0;
	return 1;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s[i]);
		len[i]=strlen(s[i]);
	}
	if(m<=15)
	{
		for(int i=0;i<(1<<m);i++)
		{
			for(int j=0;j<m;j++)
			if((i>>j)&1)a[j]=1,a[2*m-1-j]=0;
			else a[j]=0,a[2*m-1-j]=1;
			bool f=0;
			for(int j=1;j<=n;j++)
			{
				f=0;
				for(int l=0;len[j]+l<=(m<<1);l++)
				if(o(j,l)){f=1;break;}
				if(!f)break;
			}
			if(f)++ans;	
		}
		printf("%d\n",ans);
	}
	return 0;
}