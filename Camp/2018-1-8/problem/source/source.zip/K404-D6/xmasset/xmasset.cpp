#include<cstdio>
int type,N,T;
int main(){
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
    scanf("%d%d%d", &type, &N, &T);
    while(T--){
        int x, y;
        scanf("%d%d", &x, &y);
        type==1?printf("%d\n",x):puts(x==y?"yes":"no");
    }
    return 0;
}

