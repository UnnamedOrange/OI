#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

typedef long long LL;
const int N = 100010;
const int P = 998244353;
int n, Sn, Sc; LL ans;
int a[N], in[N];
bool vis[N], zero;

void dfs(int u, int step) {
	if(vis[u]) {
		if(u) {
			if(step & 1) zero = 1; else Sn -= step;
		} else {
			--step;
			if(step & 1) Sn -= step-1, ++Sc; else Sn -= step;
		}
		return;
	}
	vis[u] = 1;
	dfs(a[u], step+1);
}

LL find(int i, int j) {
	if(!j && !i) return 1;
	if(!j) return find(i-2, j) * (i-1) % P * (i-1) % P;
	return find(i-2, j-1) * (i-j) % P;
}

int main() {
	freopen("permutation.in", "r", stdin); freopen("permutation.out", "w", stdout);
	int i;
	scanf("%d", &n);
	rep(i, 1, n) {scanf("%d", &a[i]); ++in[a[i]];}
	
	Sn = n; Sc = 0;
	vis[0] = 1;
	rep(i, 1, n) if(!in[i]) dfs(i, 0);
	rep(i, 1, n) if(!vis[i]) dfs(i, 0);
	if(zero) {puts("0"); return 0;}
	//printf("%d %d\n", Sn, Sc);
	ans = find(Sn, Sc);
	printf("%lld\n", ans);
	return 0;
}
