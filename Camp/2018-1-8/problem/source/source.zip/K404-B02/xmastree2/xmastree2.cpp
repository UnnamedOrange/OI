#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#define ll long long
using namespace std;
int read()
{
	char ch=getchar();int x=0,f=1;
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
vector<int> v;
struct node
{
	int from;
	int to;
	int next;
	int w;
}edge[100005];
int tot,head[50005],size[50005],dep[50005],n;
ll w[50005];bool r[50005];
int a[100005],pos[100005],fa1[15];
bool vis[15];
ll f[30005],sum[30005],temp,ans;
void add(int u,int v)
{
	edge[tot].from=u;
	edge[tot].to=v;
	edge[tot].next=head[u];
	head[u]=tot++;
}
bool cmp(const int &x,const int &y)
{
	return 1LL*size[y]*sum[x]<1LL*size[x]*sum[y];
}
void dfs(int x,int fa)
{
	sum[x]=w[x];
	size[x]=1;
	for(int i=head[x];i!=-1;i=edge[i].next)
	{
		if(edge[i].to!=fa)
		{
			dfs(edge[i].to,x);
			size[x]+=size[edge[i].to];
			sum[x]+=sum[edge[i].to];
		}
	}
	v.clear();
	for(int i=head[x];i!=-1;i=edge[i].next)
	{
		if(edge[i].to==fa) continue;
		v.push_back(edge[i].to);
	}
	sort(v.begin(),v.end(),cmp);
	temp+=w[x];
	int now=1;
	for(int i=0;i<v.size();i++)
	{
		temp+=1LL*now*sum[v[i]];
		now+=size[v[i]];
	}
}
void dfs1(int x)
{
	for(int i=head[x];i!=-1;i=edge[i].next)
	{
		if(edge[i].to!=fa1[x])
		{
			fa1[edge[i].to]=x;
			dfs1(edge[i].to);
		}
	}
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	memset(head,-1,sizeof(head));
	n=read();
	for(int i=1;i<n;i++)
	{
		int u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	for(int i=1;i<=n;i++)
	{
		w[i]=read(),r[i]=read();
	}
	if(n<=10)
	{
		for(int i=1;i<=n;i++)
	{
		a[i]=i;
	}
	do
	{
		bool ac=1;
		for(int i=1;i<=n;i++)
		{
			if(a[i]==1&&r[i]==0)
			{
				ac=0;
				break;
			}
		}
		if(!ac) continue;
		//cout<<"ok";
		memset(vis,0,sizeof(vis));
		for(int i=1;i<=n;i++)
		{
			pos[a[i]]=i;
		}
		memset(fa1,0,sizeof(fa1));
		
		dfs1(pos[1]);
		//for(int i=1;i<=n;i++)
		//cout<<fa[i]<<" ";
		//cout<<endl;
		vis[pos[1]]=1;
		for(int i=2;i<=n;i++)
		{
			if(!vis[fa1[pos[i]]])
			{
				ac=0;
				break;
			}
			vis[pos[i]]=1;
		}
		if(ac)
		{
			ll temp=0;
			for(int i=1;i<=n;i++)
			{
				temp+=w[i]*a[i];
			}
			ans=max(ans,temp);
		}
	}while(next_permutation(a+1,a+n+1));
	cout<<ans;
	return 0;
	}
	for(int i=1;i<=n;i++)
	{
		if(r[i])
		{
			temp=0;
			memset(f,0,sizeof(f));
			memset(sum,0,sizeof(sum));
			dfs(i,0);
			ans=max(ans,temp);
		}
	}
	cout<<ans;
}

/*
5
1 2
1 3
2 4
3 5
4 1
3 0
4 0
3 0
1 0
*/
