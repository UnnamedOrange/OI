//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
//My i/o stream
struct fastio
{
	char s[100000];
	int it,len;
	fastio(){it=len=0;}
	inline char get()
	{
		if(it<len)return s[it++];it=0;
		len=fread(s,1,100000,stdin);
		if(len==0)return EOF;else return s[it++];
	}
	bool notend()
	{
		char c=get();
		while(c==' '||c=='\n')c=get();
		if(it>0)it--;
		return c!=EOF;
	}
}_buff;
#define geti(x) x=getnum()
#define getii(x,y) geti(x),geti(y)
#define getiii(x,y,z) getii(x,y),geti(z)
#define puti(x) putnum(x),putchar(' ')
#define putii(x,y) puti(x),puti(y)
#define putiii(x,y,z) putii(x,y),puti(z)
#define putsi(x) putnum(x),putchar('\n')
#define putsii(x,y) puti(x),putsi(y)
#define putsiii(x,y,z) putii(x,y),putsi(z)
inline ll getnum()
{
	ll r=0;bool ng=0;char c;c=_buff.get();
	while(c!='-'&&(c<'0'||c>'9'))c=_buff.get();
	if(c=='-')ng=1,c=_buff.get();
	while(c>='0'&&c<='9')r=r*10+c-'0',c=_buff.get();
	return ng?-r:r;
}
template<class T> inline void putnum(T x)
{
	if(x<0)putchar('-'),x=-x;
	register short a[20]={},sz=0;
	while(x)a[sz++]=x%10,x/=10;
	if(sz==0)putchar('0');
	for(int i=sz-1;i>=0;i--)putchar('0'+a[i]);
}
inline char getreal(){char c=_buff.get();while(c<=32)c=_buff.get();return c;}

int n,m;
int head[1000111],nxt[1000111],to[1000111],from[1000111],tot;
int dfn[1000111],low[1000111],dtot,st[1000111],stn,g[1000111],gn,sz[1000111];
bool inst[1000111];
int head2[1000111],nxt2[1000111],to2[1000111],tot2;
void adde(int x,int y)
{
	nxt[++tot]=head[x];
	head[x]=tot;
	to[tot]=y;
	from[tot]=x;
}
void adde2(int x,int y)
{
	nxt2[++tot2]=head2[x];
	head2[x]=tot2;
	to2[tot2]=y;
}

void dfs(int x)
{
	dfn[x]=low[x]=++dtot;inst[x]=1;st[stn++]=x;
	for(int i=head[x];i;i=nxt[i])
	{
		if(!dfn[to[i]])
		{
			dfs(to[i]);
			low[x]=min(low[x],low[to[i]]);
		}
		else if(inst[to[i]])
		{
			low[x]=min(low[x],dfn[to[i]]);
		}
	}
	inst[x]=0;
	if(dfn[x]==low[x])
	{
		gn++;
		while(st[stn]!=x)
		{
			int u=st[--stn];
			g[u]=gn;
			sz[gn]++;
		}
	}
}
bool vis[1000111];
int dp[1000111];
int calcans(int x)
{
	if(vis[x])return dp[x];
	vis[x]=1;
	for(int i=head2[x];i;i=nxt2[i])
	{
		int u=to2[i];
		dp[x]=max(dp[x],calcans(u));
	}
	dp[x]+=sz[x];
	return dp[x];
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	getii(n,m);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		getii(x,y);
		adde(x,y);
	}
	for(int i=1;i<=n;i++)if(!dfn[i])dfs(i);
	for(int i=1;i<=tot;i++)if(g[from[i]]!=g[to[i]])adde2(g[from[i]],g[to[i]]);
	int ans=0;
	for(int i=1;i<=gn;i++)ans=max(ans,calcans(i));
	cout<<ans<<endl;
	return 0;
}
