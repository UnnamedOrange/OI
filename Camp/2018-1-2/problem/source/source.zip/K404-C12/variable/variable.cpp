#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std; 
typedef long long ll;
int lst[505], to[100005], pre[100005], tot;
ll cap[100005]; 
int que[505], dep[505], fst[505]; 
inline void init()
{
	memset(lst, -1, sizeof(lst)); 
	tot = 0; 
}
inline void add_edge(int u, int v, ll _cap)
{
	to[tot] = v; 
	pre[tot] = lst[u]; 
	cap[tot] = _cap; 
	lst[u] = tot++; 
	
	to[tot] = u; 
	pre[tot] = lst[v]; 
	cap[tot] = 0; 
	lst[v] = tot++; 
}
inline bool bfs(int s, int t)
{
	int he = 0, ta = 0; 
	memset(dep, -1, sizeof(dep)); 
	que[ta++] = s; 
	dep[s] = 0; 
	while (he < ta)
	{
		int u = que[he++]; 
		for (int i = lst[u]; ~i; i = pre[i])
		{
			if (cap[i] && -1 == dep[to[i]])
			{
				dep[to[i]] = dep[u] + 1;
				que[ta++] = to[i]; 
			}
		}
	}
	return ~dep[t]; 
}
ll dfs(int u, int t, ll mx)
{
	if (u == t)
		return mx; 
	ll ans = 0; 
	for (int i = fst[u]; ~i; i = pre[i])
	{
		if (cap[i] && dep[to[i]] == dep[u] + 1)
		{
			ll res = dfs(to[i], t, min(mx - ans, cap[i]));
			cap[i] -= res; 
			cap[i ^ 1] += res; 
			if (cap[i])
				fst[u] = i; 
			ans += res; 
			if (ans == mx)
				return ans; 
		}
	}
	if (!ans)
		dep[u] = -1; 
	return ans; 
}
inline ll dinic(int s, int t)
{
	ll ans = 0; 
	while (bfs(s, t))
	{
		memcpy(fst, lst, sizeof(lst)); 
		ans += dfs(s, t, 1e18); 
	}
	return ans; 
}
int n, w, p, q;
ll coef[55]; 
inline void add(int u, int v, int x)
{
	coef[u] += x; 
	coef[v] -= x; 
}
inline void upd(int u, int v, int x)
{
	add(u, v, x); 
	add_edge(v, u, 2 * x); 
}
int main()
{
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "wt", stdout); 
	int t; 
	scanf("%d", &t); 
	while (t--)
	{
		memset(coef, 0, sizeof(coef)); 
		init();
		scanf("%d%d%d%d", &n, &w, &p, &q); 
		for (int i = 0; i < p; i++)
		{
			int x, y, z, a, b, c, d, e, f; 
			scanf("%d%d%d%d%d%d%d%d%d", &x, &y, &z, &a, &b, &c, &d, &e, &f);
			upd(x, y, a); 
			upd(y, z, b); 
			upd(z, x, c); 
			add(x, y, d); 
			add(y, z, e); 
			add(z, x, f); 
		}
		ll ans = 0; 
		for (int i = 1; i <= n; i++)
		{
			coef[i]++; 
			if (coef[i] > 0)
			{
				ans -= coef[i] * w; 
				add_edge(0, i, coef[i]); 
			}
			else
			{
				ans -= -coef[i] * w; 
				add_edge(i, n + 1, -coef[i]); 
			}
		}
		for (int i = 0; i < q; i++)
		{
			int u, v, r; 
			scanf("%d%d%d", &u, &v, &r); 
			if (!r)
				add_edge(u, v, 1e18); 
			else if (r == 1)
			{
				add_edge(u, v, 1e18); 
				add_edge(v, u, 1e18);
			}
			else
			{
				add_edge(0, u, 1e18); 
				add_edge(v, n + 1, 1e18); 
			}
		}
		printf("%lld\n", ans + dinic(0, n + 1) * w * 2); 
	}
	return 0; 
}

