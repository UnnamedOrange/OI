#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int mo=1e9+7,maxn=100010;
bool flag;
int n,a,b,t[4],ans1,ans2,ans3,ans4;
int fac[maxn],ifac[maxn];
int fpm(int x,int k){
    int res=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) res=1ll*res*x%mo;
    return res;
}
void init(){
    fac[0]=1;
    for(int i=1;i<=n;i++) fac[i]=1ll*fac[i-1]*i%mo;
    ifac[n]=fpm(fac[n],mo-2);
    for(int i=n-1;~i;i--) ifac[i]=1ll*ifac[i+1]*(i+1)%mo;
}
int C(int N,int M){
    return 1ll*fac[N]*ifac[M]%mo*ifac[N-M]%mo;
}
int main(){
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
    read(n); init();
    read(a); read(b);
    if(a>b){ flag=1; swap(a,b); }
    for(int i=1;i<=n;i++){
        int x; read(x)%=a+b;
        if(x>=a&&x<b) ++t[0];
        if(x>=2*a&&x>=b) ++t[1];
        if(x>=a&&x<2*a&&x>=b) ++t[2];
        if(x<a) ++t[3];
    }
    ans1=1ll*((fpm(2,t[0])-1)%mo+mo)%mo*fpm(2,t[1]+t[2])%mo;
    ans1=(ans1+1ll*((fpm(2,t[1])-t[1]-1)%mo+mo)%mo*fpm(2,t[2])%mo)%mo;
    int sum1=0,sum2=0;
    for(int i=0;i<=t[2];i++){
        if(i&1) (sum1+=C(t[2],i))%=mo;
        else(sum2+=C(t[2],i))%=mo;
    }
    ans1=(ans1+1ll*t[1]*sum1%mo)%mo;
    ans3=1ll*t[1]*sum2%mo;
    ans3=(ans3+sum1)%mo; ans4=sum2;
    if(flag) swap(ans1,ans2);
    int base=fpm(2,t[3]);
    ans1=1ll*ans1*base%mo;
    ans2=1ll*ans2*base%mo;
    ans3=1ll*ans3*base%mo;
    ans4=1ll*ans4*base%mo;
    printf("%d %d %d %d\n",ans1,ans2,ans3,ans4);
    return 0;
}
