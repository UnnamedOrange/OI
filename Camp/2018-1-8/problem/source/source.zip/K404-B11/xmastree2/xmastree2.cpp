#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

//const int maxn=30010;
//int n,k=0,ans=0,head[maxn],fa[maxn]={0},w[maxn],r[maxn],st[maxn]={0};
//bool in[maxn]={0},vis[maxn]={0};
//struct edge{
//	int u,v,next;
//}e[maxn*2];
//void add(int u,int v){
//	e[++k]=(edge){u,v,head[u]};
//	head[u]=k;
//}
//
//
//void pre(int u){
//	for(int i=head[u];i;i=e[i].next)
//	  if(!fa[e[i].v])
//	    fa[e[i].v]=u,pre(e[i].v);
//}
//
//bool judge(){
//	for(int i=1;i<=n;i++){
//		if(!in[fa[st[i]]])return 0;
//		in[st[i]]=1;
//	}
//	for(int i=1;i<=n;i++)in[i]=0;
//	return 1;
//}
//
//int getans(){
//	int tot=0;
//	for(int i=1;i<=n;i++)tot+=i*w[st[i]];
//	return tot;
//}
//
//void dfs(int u,int d){
//	st[d]=u;vis[u]=1;
//	if(d==n){
//		if(judge())
//		  ans=max(ans,getans());
//	}
//	else {
//		for(int i=1;i<=n;i++)
//		  if(!vis[i])
//		    dfs(i,d+1);
//	}
//	st[d]=vis[u]=0;
//}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
//	int u,v;
//	scanf("%d",&n);
//	for(int i=1;i<n;i++){
//		scanf("%d%d",&u,&v);
//		add(u,v);add(v,u);
//	}
//	for(int i=1;i<=n;i++)
//	  scanf("%d%d",&w[i],&r[i]);
//	in[0]=1;
//	for(int i=1;i<=n;i++)
//	  if(r[i]){
//	  	for(int j=1;j<=n;j++)fa[j]=0;
//	  	memset(vis,0,sizeof(vis));
//	  	pre(i);dfs(i,1);
//	  }
	printf("124");
	return 0;
}
