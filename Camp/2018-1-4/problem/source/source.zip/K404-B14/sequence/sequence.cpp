#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int MAXN = 28;
int T, n, ans;
int a[MAXN];
bool check(int *s){
	for(int i = 1; i <= n; i++) if(s[i] != i) return false;
	return true;
}
inline void swap(int &a, int &b){
	int t = a; a = b; b = t;
}
bool dfs(int dep, int need){
	if(dep == 0) return check(a);
	if(need > dep) return false;
	for(int i = 2; i <= n; i++){
		for(int j = 1; j <= i / 2; j++) swap(a[j], a[i - j + 1]);
		int tt = need;
		if(i < n && abs(a[i] - a[i + 1]) > 1) tt++;
		if(i < n && abs(a[1] - a[i + 1]) > 1) tt--;
		if(dfs(dep - 1, tt)) return true;
		for(int j = 1; j <= i / 2; j++) swap(a[j], a[i - j + 1]);
	}
	return false;
}
int main(){
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	cin >> T;
	while(T--){
		cin >> n;
		for(int i = 1; i <= n; i++) cin >> a[i];
		int ans = 0;
		int tt = 0;
		for(int i = 2; i <= n; i++) if(abs(a[i] - a[i - 1]) > 1) tt++;
		while(!dfs(ans, tt)) ++ans;
		cout << ans << endl;
	}
	return 0;
}
