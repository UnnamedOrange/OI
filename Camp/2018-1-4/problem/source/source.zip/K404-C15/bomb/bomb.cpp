#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 1000005;
int n, m;
int ecnt = 1, adj[N], nxt[2 * N], go[2 *N];
int used[1005][1005], que[1005], qr, mx;
bool vis[1005], inq[1005];

void add(int u, int v){
	go[++ecnt] = v;
	nxt[ecnt] = adj[u];
	adj[u] = ecnt;
}
void bfs(int s){
	que[qr = 1] = s, inq[s] = 1;
	for(int ql = 1; ql <= qr; ql++){
		int u = que[ql], c = 1;
		while(used[u][c]) c++;
		mx = max(mx, c);
		vis[u] = 1;
		for(int e = adj[u], v; e; e = nxt[e])
			if(!vis[v = go[e]]){
				used[v][c] = 1;
				if(!inq[v]) que[++qr] = v, inq[v] = 1;
			}
	}
}
void solve1(){
	for(int i = 1; i <= n; i++)
		if(!vis[i]) bfs(i);
	write(mx), enter;
}

int main(){
	
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	
	read(n), read(m);
	for(int i = 1, u, v; i <= m; i++)
		read(u), read(v), add(u, v), add(v, u);
	if(n <= 1005) solve1();
	else puts("2");
	
	return 0;
}
/*
5 8
1 2
1 3
2 3
3 4
4 5
5 2
4 2
3 5
*/
