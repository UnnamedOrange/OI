#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long

using namespace std;

const int P = (int) 1e9 + 7;

ll s;
int t, n, m;

inline void Add(int &a, int b) {
	a += b;
	if (a >= P) a -= P;
}

namespace Subtask1 {
	
	const int N = 105;
	
	int dp[N][N];
	
	void solve() {
		dp[0][0] = 1;
		for (int i = 0; i < m; i++)
			for (int j = 0; j <= s; j++) {
				if (!dp[i][j]) continue;
				int up = min(s - j, (i + 1 <= n ? t : s));
				for (int k = 1; k <= up; k++)
					Add(dp[i + 1][j + k], dp[i][j]);
			}
		int rs = 0;
		for (int i = m; i <= s; i++) Add(rs, dp[m][i]);
		printf("%d\n", rs);
	}
	
}

int main() {
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	cin >> s >> t >> n >> m;
	if (s <= 100 && t <= 100 && n <= 100 && m <= 100) Subtask1::solve();
	return 0;
}
