#include<bits/stdc++.h>
using namespace std;

const int maxn = 25 + 1;
const int mod = 1e+9 + 7;
const int hsiz = 999983;

int n;

struct state{
	int a[maxn],e,f;
	void E()
	{
		if(e!=-1) return;
		
		int i,e=n-1;
		for(i=0;i<n-1;i++) if(a[i]==a[i+1]-1 || a[i]==a[i+1]+1) e--;
		e*=2;
		for(i=0;i<n-1;i++) if(a[i]!=a[i+1]+1 && a[i]>a[i+1]) e++;
	}
	int H()
	{
		int i,ans=0;
		for(i=0;i<n;i++) ans+=a[i],ans=ans*maxn%hsiz;
		return ans;
	}
	bool operator < (const state &s) const
	{
		return !(e+f<s.e+s.f);
	}
	bool operator == (const state &s) const
	{
		int i;
		for(i=0;i<n;i++) if(a[i]!=s.a[i]) return false;
		return true;
	}
	bool check()
	{
		int i;
		for(i=0;i<n;i++) if(a[i]!=i+1) return false;
		return true;
	}
};

struct hash{
	state a[hsiz];bool has[hsiz];
	
	void clear(){memset(has,0,sizeof(has));}
	
	void insert(state x)
	{
		int u=x.H();
		while(has[u] && !(a[u]==x)) (++u)%=hsiz;
		a[u]=x;has[u]=true;
	}
	
	int find(state x)
	{
		int u=x.H();
		while(has[u] && !(a[u]==x)) (++u)%=hsiz;
		if(!has[u]) return -1;
		else return a[u].f;
	}
}h;

state S;

void read()
{
	int i;
	
	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%d",&S.a[i]);
	S.f=0;
}

void bfs()
{
	priority_queue<state> q;
	
	int i,f;state u;
	
	if(S.check()) {cout<<0;return;}
	q.push(S);S.E();S.f=0;h.insert(S);
	while(!q.empty())
	{
		u=q.top();q.pop();
		f=h.find(u);
		for(i=1;i<n;i++) if(i==n-1||(u.a[i]!=u.a[i+1]-1 && u.a[i]!=u.a[i+1]+1)) 
		{
			reverse(u.a,u.a+i+1);
			if(u.check()) {cout<<f+1<<endl;return;}
			if(h.find(u)==-1 || h.find(u)>f+1) 
			{
				u.f=f+1;u.E();
				h.insert(u);
				q.push(u);
			}
			reverse(u.a,u.a+i+1);
		}
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	
	int qq;
	cin>>qq;
	while(qq--)
	{
		h.clear();
		read();
		bfs();
	}
	
	
	return 0;
}
