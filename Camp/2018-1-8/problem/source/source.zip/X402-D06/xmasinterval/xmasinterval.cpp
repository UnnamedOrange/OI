#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=5e5+10;
const int mod=1e9+9;
struct node{
	int l,r;
};
struct node a[maxn],b[maxn];
int c[maxn];
int Sum[maxn<<2],Tag[maxn<<2];
bool cmp(const node &lhs,const node &rhs){
	return lhs.r==rhs.r?lhs.l<rhs.l:lhs.r<rhs.r;
}
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int Mod(int x,int y){
	return x+y>=mod ? x+y-mod : x+y;
}
inline void Push_Down(int h){
	if(Tag[h]!=1){
		Sum[h<<1]=1ll*Sum[h<<1]*Tag[h]%mod;
		Tag[h<<1]=1ll*Tag[h<<1]*Tag[h]%mod;
		Sum[h<<1|1]=1ll*Sum[h<<1|1]*Tag[h]%mod;
		Tag[h<<1|1]=1ll*Tag[h<<1|1]*Tag[h]%mod;
		Tag[h]=1;
	}
	return;
}
int Query_Sum(int h,int l,int r,int L,int R){
	if(L<=l && r<=R)return 1ll*Sum[h]%mod;
	Push_Down(h);
	int mid=(l+r)>>1;
	int ans=0;
	if(L<=mid)ans=Mod(ans,Query_Sum(h<<1,l,mid,L,R));
	if(R>mid)ans=Mod(ans,Query_Sum(h<<1|1,mid+1,r,L,R));
	return ans;
}
void Modify_Sum(int h,int l,int r,int pos,int val){
	if(l==r){
		Sum[h]=(1ll*Sum[h]+1ll*Tag[h]*val)%mod;
		return;
	}
	Push_Down(h);
	int mid=(l+r)>>1;
	if(pos<=mid)Modify_Sum(h<<1,l,mid,pos,val);
	else Modify_Sum(h<<1|1,mid+1,r,pos,val);
	Sum[h]=Mod(Sum[h<<1],Sum[h<<1|1]);
}
void Modify_Tag(int h,int l,int r,int L,int R){
	if(L<=l && r<=R){
		Sum[h]=Mod(Sum[h],Sum[h]);
		Tag[h]=Mod(Tag[h],Tag[h]);
		return;
	}
	Push_Down(h);
	int mid=(l+r)>>1;
	if(L<=mid)Modify_Tag(h<<1,l,mid,L,R);
	if(R>mid)Modify_Tag(h<<1|1,mid+1,r,L,R);
	Sum[h]=Mod(Sum[h<<1],Sum[h<<1|1]);
}
int main(){
	int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
#endif
	n=read();m=read();
	for(i=1;i<=n;i++){
		a[i].l=read();a[i].r=read();
	}
	for(i=1;i<=m;i++)c[i]=read();
	sort(c+1,c+m+1);
	int tot=1;
	for(i=1;i<=n;i++){
		b[i].l=lower_bound(c+1,c+m+1,a[i].l)-c;
		b[i].r=upper_bound(c+1,c+m+1,a[i].r)-c-1;
		if(b[i].r<b[i].l)tot=Mod(tot,tot);
	}
	sort(b+1,b+n+1,cmp);
	for(i=1;i<=((m+1)<<2);i++)Tag[i]=1;
	Modify_Sum(1,1,m+1,1,1);
	for(i=1;i<=n;i++){
		if(b[i].r<b[i].l)continue;
		int sum=Query_Sum(1,1,m+1,b[i].l,b[i].r+1);
		if(b[i].l>=2)Modify_Tag(1,1,m+1,1,b[i].l-1);
		Modify_Sum(1,1,m+1,b[i].r+1,sum);
	}
	printf("%lld\n",1ll*Query_Sum(1,1,m+1,m+1,m+1)*tot%mod);
	return 0;
}

