#include<bits/stdc++.h>
using namespace std;

const int MAXN = 1000010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int e, st[MAXN], to[MAXN];
int nxt[MAXN];
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

int n, m, dfn[MAXN], low[MAXN];
int sccno[MAXN], cnt, sz[MAXN];
int dfs_clock, S[MAXN], top;

void dfs(int u) {
	int i;
	S[++top] = u;
	dfn[u] = low[u] = ++dfs_clock;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(!dfn[v]) {
			dfs(v);
			low[u] = min(low[u], low[v]);
		}
		else if(!sccno[v]) 
			low[u] = min(low[u], dfn[v]);
	}
	if(low[u] == dfn[u]) {
		++cnt;
		while(S[top] != u) {
			sccno[S[top--]] = cnt;
			sz[cnt]++;
		}
		sccno[S[top--]] = cnt;
		sz[cnt]++;
	}
}

vector<int> G[MAXN];
int indeg[MAXN], q[MAXN], ans;
int dp[MAXN];

inline void Topo() {
	int i, u, v, l = 0, r = 0;
	for(u = 1; u <= cnt; u++) 
		if(!indeg[u]) q[++r] = u;
	while(l < r) {
		u = q[++l];
		for(i = 0; i < (int)G[u].size(); i++) {
			v = G[u][i];
			indeg[v]--;
			if(!indeg[v]) q[++r] = v;
		}
	}
}

int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);

	int i, u, v;
	n = read(), m = read();

	for(i = 1; i <= m; i++) {
		u = read(), v = read();
		Add(u, v);
	}

	for(i = 1; i <= n; i++) 
		if(!dfn[i]) dfs(i);

	/*for(i = 1; i <= n; i++) printf("%d ", sccno[i]);
	printf("\n");*/
	for(u = 1; u <= n; u++) {
		for(i = st[u]; i; i = nxt[i]) {
			v = to[i];
			if(sccno[v] == sccno[u]) continue;
			G[sccno[u]].push_back(sccno[v]);
			//printf("%d %d\n", sccno[u], sccno[v]);
			indeg[sccno[v]]++;
		}
	}

	Topo();
	/*for(i = 1; i <= cnt; i++) printf("%d ", sz[i]);
	printf("\n");*/
	for(u = cnt; u >= 1; u--) {
		//printf("%d ", q[u]);
		dp[q[u]] = sz[q[u]];
		for(i = 0; i < (int)G[q[u]].size(); i++) {
			v = G[q[u]][i];
			dp[q[u]] = max(dp[q[u]], dp[v]+sz[q[u]]);
		}
		ans = max(ans, dp[q[u]]);
	}
	//printf("\n");
	printf("%d\n", ans);
	return 0;
}
