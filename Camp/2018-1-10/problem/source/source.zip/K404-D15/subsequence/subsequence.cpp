#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

int n,m,k;

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

namespace task1{
	const int maxn=505,inf=1e9;
	int a[maxn],b[maxn],f[maxn][maxn],nxta[maxn][maxn],nxtb[maxn][maxn];
	void solve(){
		for (int i=1;i<=n;i++) a[i]=read();
		for (int i=1;i<=m;i++) b[i]=read();
		for (int i=1;i<=k;i++) nxta[n][i]=n+1;
		for (int i=n-1;~i;i--){
			memcpy(nxta[i],nxta[i+1],sizeof(int)*(k+1));
			nxta[i][a[i+1]]=i+1;
		}
		for (int i=1;i<=k;i++) nxtb[m][i]=m+1;
		for (int i=m-1;~i;i--){
			memcpy(nxtb[i],nxtb[i+1],sizeof(int)*(k+1));
			nxtb[i][b[i+1]]=i+1;
		}
		memset(f,63,sizeof(f)),f[0][0]=0;
		for (int i=0;i<=n+1;i++)
			for (int j=0;j<=m+1;j++)
				if (f[i][j]<inf){
					int res=f[i][j];
					for (int l=1;l<=k;l++){
						int &v=f[nxta[i][l]][nxtb[j][l]];
						v=min(v,res+1);
					}
				}
		printf("%d\n",f[n+1][m+1]);
	}
}

namespace task2{
	const int maxn=4005,inf=1e9;
	int a[maxn],b[maxn],f[maxn][maxn],nxta[maxn][maxn],nxtb[maxn][maxn],mna[maxn],mnb[maxn];
	void solve(){
		for (int i=1;i<=n;i++) a[i]=read();
		for (int i=1;i<=m;i++) b[i]=read();
		for (int i=1;i<=k;i++) nxta[n][i]=n+1;
		for (int i=n-1;~i;i--){
			memcpy(nxta[i],nxta[i+1],sizeof(int)*(k+1));
			nxta[i][a[i+1]]=i+1;
		}
		for (int i=1;i<=k;i++) nxtb[m][i]=m+1;
		for (int i=m-1;~i;i--){
			memcpy(nxtb[i],nxtb[i+1],sizeof(int)*(k+1));
			nxtb[i][b[i+1]]=i+1;
		}
		for (int i=n;i;i--){
			int res=inf;
			for (int j=1;j<=k;j++) res=min(res,mna[nxta[i][j]]);
			mna[i]=res+1;
		}
		for (int i=m;i;i--){
			int res=inf;
			for (int j=1;j<=k;j++) res=min(res,mnb[nxtb[i][j]]);
			mnb[i]=res+1;
		}
		memset(f,63,sizeof(f)),f[0][0]=0;
		int ans=inf;
		for (int i=0;i<=n+1;i++)
			for (int j=0;j<=m+1;j++)
				if (f[i][j]<inf&&f[i][j]+max(mna[i],mnb[j])<=ans){
					if (i==n+1){ans=min(ans,f[i][j]+mnb[j]); continue;}
					if (j==m+1){ans=min(ans,f[i][j]+mna[i]); continue;}
					int res=f[i][j];
					for (int l=1;l<=k;l++){
						int &v=f[nxta[i][l]][nxtb[j][l]];
						v=min(v,res+1);
					}
				}
		printf("%d\n",ans);
	}
}

int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	n=read(),m=read(),k=read();
	if (n<=500&&m<=500&&k<=500) task1::solve();
	else task2::solve();
	return 0;
}
