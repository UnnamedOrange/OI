#include<bits/stdc++.h>
#define mo 998244353ll
using namespace std;
bool bo[1010];
long long n,f[1010][1010],k,ansn=0;
bool dfs(int x,int pp,int mu,int di){
	if (x==pp&&mu==di) return true;
	if (!bo[x]) return false;
	bo[x]=false;
	for (int i=1;i<=n;i++){
		if (f[x][i]==1) if (dfs(i,pp,mu,di+1))return true;;
	}
	bo[x]=true;
	return false;
}
bool pan(){
	for (int i=1;i<=n;i++) bo[i]=true;
	for (int i=1;i<=n;i++){
		if (dfs(i,i,k,0)) return true;
	}
	return false;
}
long long p(long long x,long long y){
	long long z=1;
	while (y){
		if (y % 2==1) z=(z*x)%mo;
		x=(x*x)%mo;
		y/=2;
	}
	return z;
}
long long jie(long long z){
	long long x=1;
	for (int i=1;i<=z;i++){
		x=(x*i)%mo;
	}
	return x;
}
void dig(int x,int y){
	if (x==n){
		if (pan()) ansn++;
	}else{
		if (y==n+1){
			dig(x+1,x+2);
		}else{
			f[x][y]=1;f[y][x]=0;dig(x,y+1);
			f[x][y]=0;f[y][x]=1;dig(x,y+1);
		}
	}
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	cin>>n>>k;
	if (k==3){
		cout<<(p(2,(n*(n-1)/2))-jie(n)+mo)%mo<<endl;
	}else{
		dig(1,2);
		cout<<ansn<<endl;
	}
}
