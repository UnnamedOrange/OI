#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#define mod 1000000009
using namespace std;

int n,m,x[500005];
long long dp[500005];
long long multi=1;

struct interval
{
	int l,r,pl,pr;
} s[500005];

bool cmp(interval a, interval b)
{
	if(a.l==b.l) return a.r<b.r;
	else return a.l<b.l;
}

void preset()
{
	sort(x+1,x+m+1);
	sort(s+1,s+n+1,cmp);
	for(int i=1,j=1;i<=m&&j<=n;i++)
	{
		while(s[j].l<=x[i])
		{
			s[j].pl=i-1;
			j++;
		}
	}
	for(int i=m,j=n;i>=1&&j>=1;i--)
	{
		while(s[j].r>=x[i])
		{
			s[j].pr=i;
			j--;
		}
	}
	int minus=0;
	for(int i=1;i<=n;i++)
	{
		if(s[i].pl==s[i].pr)
		{
			minus++;
			multi*=2;
			multi%=mod;
			s[i].l=s[i].r=1e9+5;
		}
	}
	sort(s+1,s+n+1,cmp);
	n-=minus;
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&s[i].l,&s[i].r);
	for(int i=1;i<=m;i++)
		scanf("%d",&x[i]);
	preset();
	dp[0]=1;
	for(int i=1;i<=n;i++)
	{
		int pr=s[i].pr, pl=s[i].pl;
		for(int j=pr;j>=pl;j--)
		{
			if(dp[j]==0) continue;
			dp[pr]+=dp[j];
			dp[pr]%=mod;
		}
	}
	dp[n]*=multi;
	dp[n]%=mod;
	printf("%lld",dp[n]);
	return 0;
}
