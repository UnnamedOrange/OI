#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

const int N = 1000000 + 1000;

int n, w[N], cnt[N], tot = 0;
double ans = 0.0;

namespace file{
	inline void open()
	{
		freopen("drink.in", "r", stdin);
		freopen("drink.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

namespace input{
	inline int read()
	{
		int a = 0;
		char ch;
		int f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}

	
	inline void Get()
	{
		n = read();
		for(int i = 1;i <= n;++i)
			w[i] = read();
	}
}

namespace brute{
	inline void solve()
	{
		for(int l = 1;l <= n;++l)
		{
			for(int r = l;r <= n;++r)
			{
				tot = 0;
				double cur = 0;
				for(int j = l;j <= r;++j)
					cnt[++tot] = w[j];
				sort(cnt + 1, cnt + 1 + tot);
				for(int j = 1;j <= tot;++j)
					cur = (cur + (double)(cnt[j])) / 2;
				ans += cur;
			}
		}
		printf("%.9f\n", ans / (n * n));
	}
}

namespace method{
	inline void solve()
	{
		printf("19260817\n");
	}
}

namespace check{
	inline void deter()
	{
		if(n <= 100)
			brute::solve();
		else
			method::solve();
	}
}

int main()
{
	open();
	input::Get();
	check::deter();
	close();
	return 0;
} 
