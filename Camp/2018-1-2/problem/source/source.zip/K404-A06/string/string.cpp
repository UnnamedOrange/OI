#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
char str[100010];
int test, n, s1[100010], s2[100010], t[100010];
int mod;
bool check(int mod) {
	if(mod <= 10000) return 0;
	for(int i = 2; i*i <= mod; ++i)
		if(mod%i == 0) return 0;
	return 1;
}

int query1(int x) {
	int mid = x>>1;
	int a = (1ll*(s2[x-mid+1]-s2[x+1])*t[n-x]+mod)%mod;
	int b = s1[mid];
	//printf("[%d, %d] and [%d, %d] = %d, %d\n", 1, mid, x-mid+1, x, b, a);
	return a == b;
}

int query2(int x) {
	int mid = (n-x)>>1;
	int a = (s2[n-mid+1]-s2[n+1]+mod)%mod;
	int b = (1ll*(s1[mid+x]-s1[x])*t[x]%mod+mod)%mod;
	//printf("[%d, %d] and [%d, %d] = %d, %d\n", x+1, mid+x, n-mid+1, n, b, a);
	return a == b;
}

int pow(int a, int x) {
	int res = 1;
	for(; x; x >>= 1) {
		if(x&1) res = 1ll*res*a%mod;
		a = 1ll*a*a%mod;
	}
	return res;
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	srand(time(0));
	while(mod = rand()+(rand()<<15), mod %= 100000000, !check(mod));
	scanf("%d", &test);
	while(test--) {
		t[0] = 1;
		scanf("%d", &n);
		for(int i = 1, inv = pow(133, mod-2); i <= n; i++) 
			t[i] = 1ll*inv*t[i-1]%mod;
		scanf("%s", str+1);
		s1[0] = 0; s2[n+1] = 0;
		for(int i = 1; i <= n; i++)
			s1[i] = (1ll*s1[i-1]*133+str[i])%mod;
		for(int i = n; i; i--)
			s2[i] = (1ll*s2[i+1]*133+str[i])%mod;
		//printf("%d %d\n", s1[1], s2[n]-s2[n+1]);
		if(!query1(n)) {
			puts("1");
		} else {
			int ans = -1;
			for(int i = 2; i < n; i++)
				if(!query1(i) && !query2(i))
					ans = 2, printf("i = %d\n", i);
			printf("%d\n", ans);
		}
	}
}
