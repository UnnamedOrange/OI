#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

int T,n,x[30],p[30],ans;

void change(int r)
{
	for(int i=1;i<=r/2;i++)
	{
		int j=r+1-i;
		swap(p[x[i]],p[x[j]]);
		swap(x[i],x[j]);
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		memset(x,0,sizeof x); memset(p,0,sizeof p); ans=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&x[i]),p[x[i]]=i;
		while(n>1)
		{
			if(p[n]!=n&&p[n]!=1)
			{
				change(p[n]);
				change(n);
				ans+=2;
			}
			else if(p[n]==1)
			{
				change(n);
				ans++;
			}
			n--;
		}
		printf("%d\n",ans);
	}
	return 0;
} 
