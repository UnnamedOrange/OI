#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){return a<b?a=b,1:0;}
template<class T> inline bool chkmin(T& a,T b){return a>b?a=b,1:0;}
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=1000010;
int n,m,ans;
int head[maxn],nxt[maxn],to[maxn],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}
int dfn[maxn],low[maxn],sccno[maxn],cur,cnt,sz[maxn];
stack<int> s;
void dfs(int u){
    dfn[u]=low[u]=++cur;
    s.push(u);
    for(int i=head[u];i;i=nxt[i]){
        int v=to[i];
        if(!dfn[v]) dfs(v),chkmin(low[u],low[v]);
        else if(!sccno[v]) chkmin(low[u],dfn[v]);
    }
    if(dfn[u]==low[u]){
        ++cnt; int x;
        do{
            x=s.top(); s.pop();
            sccno[x]=cnt; ++sz[cnt];
        } while(x!=u);
    }
}
int Head[maxn],Nxt[maxn],To[maxn],E,ind[maxn];
void AE(int x,int y){
    To[++E]=y; Nxt[E]=Head[x]; Head[x]=E;
}
queue<int> q;
int main(){
    freopen("bomb.in","r",stdin);
    freopen("bomb.out","w",stdout);
    read(n); read(m);
    for(int i=1;i<=m;i++){
        int u,v;
        read(u); read(v);
        if(u!=v) ae(u,v);
    }
    for(int i=1;i<=n;i++) if(!dfn[i]) dfs(i);
    for(int i=1;i<=n;i++)
        for(int j=head[i];j;j=nxt[j]){
            int v=to[j];
            if(sccno[i]!=sccno[v]){
                AE(sccno[v],sccno[i]);
                ++ind[sccno[i]];
            }
        }
    for(int i=1;i<=cnt;i++) if(!ind[i]) q.push(i);
    while(!q.empty()){
        ++ans;
        while(!q.empty()) s.push(q.front()),q.pop();
        while(!s.empty()){
            int u=s.top(); s.pop();
            if(!--sz[u]){
                for(int i=Head[u];i;i=Nxt[i]){
                    int v=To[i];
                    if(!--ind[v]) q.push(v);
                }
            }
            else q.push(u);
        }
    }
    printf("%d\n",ans);
    return 0;
}
