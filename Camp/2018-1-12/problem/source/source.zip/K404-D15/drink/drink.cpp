#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 1000005
typedef long double ld;

int n,mx,ans;
int a[maxn];
bool flag;

vector<int> v[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

ld power(ld a,int k){
	ld ret=1;
	for (;k;k>>=1,a=a*a) if (k&1) ret=ret*a;
	return ret;
}

struct functional_segment_tree{
	int tree_deg,root[maxn];
	struct tree_node{int ls,rs,sum;}tree[maxn*30];
	void change(int &p,int l,int r,int x){
		int tmp=++tree_deg;
		tree[tmp]=tree[p],p=tmp,++tree[p].sum;
		if (l==r) return; int mid=(l+r)>>1;
		if (x<=mid) change(tree[p].ls,l,mid,x);
		else change(tree[p].rs,mid+1,r,x);
	}
	int query(int p,int l,int r,int op){
		if (l==r) return l; int mid=(l+r)>>1;
		if (op){
			if (tree[tree[p].ls].sum) return query(tree[p].ls,l,mid,op);
			else return query(tree[p].rs,mid+1,r,op);
		}
		else{
			if (tree[tree[p].rs].sum) return query(tree[p].rs,mid+1,r,op);
			else return query(tree[p].ls,l,mid,op);
		}
	}
	void query(int p,int l,int r,int x,int y,int op){
		if (!flag) return;
		if (!tree[p].sum) return;
		if (x<=l&&r<=y){
			flag=0,ans=query(p,l,r,op);
			return;
		}
		int mid=(l+r)>>1;
		if (op){
			if (x<=mid) query(tree[p].ls,l,mid,x,y,op);
			if (y>mid) query(tree[p].rs,mid+1,r,x,y,op);
		}
		else{
			if (y>mid) query(tree[p].rs,mid+1,r,x,y,op);
			if (x<=mid) query(tree[p].ls,l,mid,x,y,op);
		}
	}
}T;

int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++) a[i]=read(),mx=max(mx,a[i]),v[a[i]].push_back(i);
	for (int i=mx;i;i--){
		T.root[i]=T.root[i+1];
		for (int j=0,size=v[i].size();j<size;j++)
		    T.change(T2.root[i],1,n,v[i][j]);
	}
	ld modpps=0;
	for (int i=1;i<=n;i++){
		int x=i,v=a[i]; int top1=-1,top2=-1; ld res1=0,res2=0;
		while (top1<=40&&x){
		    ans=0,flag=1,T.query(T.root[v],1,n,1,x-1,0);
			res1=res1*2+x-ans,x=ans,++top1;
		}
		x=i;
		while (top2<=40&&x<=n){
		    ans=n+1,flag=1,T.query(T.root[v+1],1,n,x+1,n,1);
		    res2=res2*2+ans-x,x=ans,++top2;
		}
		modpps+=a[i]*res1*res2/power(2,top1+top2+1);
	}
	modpps/=n,modpps/=n;
	printf("%.10f\n",(double)modpps);
	return 0;
}
