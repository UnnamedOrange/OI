#include<bits/stdc++.h>
using namespace std;
int check(string &s) {
	string tmp=s;
	reverse(tmp.begin(),tmp.end());
	if(tmp==s) return 0;
	return 1;
}
void work2(int n,string s) {
	string tmp=s;
	reverse(tmp.begin(),tmp.end());
	if(tmp!=s) {
		puts("1");
		return;
	}
	string tmp1=s.substr(0,n/2);
	string tmp2;
	if(n%2==1) tmp2=s.substr(n/2+1,n/2);
	else tmp2=s.substr(n/2,n/2);
	if(tmp1.substr(0,n/2-1)==tmp1.substr(1,n/2-1)) {
		puts("-1");
		return;
	}
	if(tmp2.substr(0,n/2-1)==tmp2.substr(1,n/2-1)) {
		puts("-1");
		return;
	}
	if(n%2==1) {
		if(tmp1.substr(0,n/2-1)==tmp2.substr(1,n/2-1)) {
			puts("-1");
			return;
		}
	} else if(n>4){
		if(tmp1.substr(0,n/2-2)==tmp1.substr(2,n/2-2)) {
			puts("-1");
			return;
		}
	}
	puts("2");
	return;
}
void work() {
	int n;
	string s;
	cin>>n>>s;
	if(n>=1000) {
		work2(n,s);
		return;
	}
	string tmp=s;
	reverse(tmp.begin(),tmp.end());
	if(tmp!=s) {
		puts("1");
		return;
	}
	if(n==1) {
		puts("-1");
		return;
	}
	for(int i=0;i<n;i++) {
		for(int j=2;j<n-1;j++) {
			if(i+j-1>=n) break;
			string tmp1,tmp2=s;
			for(int k=1;k<=j;k++) {
				tmp1+=s[k+i-1];
			}
			tmp2.erase(i,j);
			if(check(tmp1)&&check(tmp2)) {
				puts("2");
				return;
			}
		}
	}
	puts("-1");
}
int main() {
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) {
		work();
	}
}
