#include<bits/stdc++.h>
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=30;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence1.out","w",stdout);
}
int T,n,a[N],s[N];
inline int g()
{
	int ret=0;
	For(i,1,n)
		if(s[i+1]!=s[i]-1&&s[i+1]!=s[i]+1)
			ret++;
	return ret;
}
inline bool check()
{
	For(i,1,n)if(s[i]!=i)return 0;
	return 1;
}
inline bool dfs(int res,int last)
{
	if(!res)
	{
		if(check())return 1;
		return 0;
	}
	if(g()>res)return 0;
	int t=n;
	while(s[t]==t)t--;
	For(i,2,t)
	{
		if(i==last)continue;
		reverse(s+1,s+i+1);
		if(dfs(res-1,i))return 1;
		reverse(s+1,s+i+1);
	}
	return 0;
}
int main()
{
	file();
	read(T);
	while(T--)
	{
		read(n);
		For(i,1,n)read(a[i]);
		for(int x=0;;++x)
		{
			For(i,1,n)s[i]=a[i];s[n+1]=n+1;
			if(dfs(x,0))
			{
				printf("%d\n",x);
				//cerr<<x<<endl;
				break;
			}
		}
	}
	return 0;
}
