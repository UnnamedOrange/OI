#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

const int N=105;
int s[N],t[N];
int n;

double calc(int L,int R)
{
	int len=R-L+1;
	memcpy(t+1,s+L,len*4);

	std::sort(t+1,t+len+1);
	double ret=0;

	for(int i=1;i<=len;i++)
		ret=(ret+t[i])/2;
	return ret;
}

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",s+i);
	double ans=0;
	for(int i=1;i<=n;i++)
		for(int j=i;j<=n;j++)
			ans+=calc(i,j);
	ans=ans/n/n;
	printf("%.12lf\n",ans);
	return 0;
}
