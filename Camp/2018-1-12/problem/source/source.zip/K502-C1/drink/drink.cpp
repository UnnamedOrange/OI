#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <queue>
#include <map>
using namespace std;

struct state
{
	vector<double> v;
};

int n;
double ans;
double w[10];
map<vector<int>, bool> m;
queue<state> q;

vector<int> intlize(const vector<double> &x)
{
	vector<int> ret;
	for (auto i : x)
		ret.push_back(i * 10000);
	return ret;
}

double getans(const vector<double> &x)
{
	double ret = 0;
	for (int i = 0; i < n; ++i)
	{
		for (int j = i; j < n; ++j)
		{
			double big = 0;
			for (int k = i; k < j + 1; ++k)
				big = max(big, x[k]);
			ret += big;
		}
	}
	if (ret == 47)
	{
		for (auto i : x)
			cerr << i << " ";
	}
	return ret;
}

int randint()
{
	return rand() % n;
}

void bfs()
{
	state first;
	for (int i = 1; i < n + 1; ++i)
		first.v.push_back(w[i]);
	m[intlize(first.v)] = true;
	q.push(first);
	int tot = 0, cur = 0;
	while (tot < 10000 && !q.empty())
	{
		++tot;
		state now = q.front();
		q.pop();
		double t = getans(now.v);
		ans = max(ans, t);
		for (int k = 0; k < 3; ++k)
		{
			int i = randint();
			int j = randint();
			vector<double> tv = now.v;
			tv[i] = tv[j] = (tv[i] + tv[j]) * 0.5;
			vector<int> iv = intlize(tv);
			if (!m[iv])
			{
				m[iv] = true;
				q.push((state){tv});
			}
			else
				++cur;
		}
	}
	cerr << cur << endl;
}

int main()
{
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	cin >> n;
	for (int i = 1; i < n + 1; ++i)
		cin >> w[i];
	bfs();
	cout << (ans) << endl;
}
