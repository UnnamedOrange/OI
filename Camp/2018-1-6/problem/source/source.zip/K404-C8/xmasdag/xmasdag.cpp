#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
using namespace std;
const int N=100005;
typedef long long ll;
const ll mod=998244353;
inline void MOD(int &x) {if (x>=mod) x-=mod;}

int k,n,m,hd[N],pr[N*2],to[N*2],tot,d[N],q[N],H,T;
void addedge(int u,int v) {to[++tot]=v;pr[tot]=hd[u];hd[u]=tot;}

int f[N][505],s[505][505],jc[505],ans[N];

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	
	scanf("%d%d%d",&n,&m,&k);
	jc[0]=1;for (int i=1;i<=k;i++) jc[i]=(ll)jc[i-1]*i%mod;
	s[0][0]=1;
	for (int i=1;i<=k;i++)
		for (int j=1;j<=i;j++) s[i][j]=((ll)s[i-1][j]*j+s[i-1][j-1])%mod;
	
	for (int u,v,i=1;i<=m;i++) 
	{
		scanf("%d%d",&u,&v);
		addedge(u,v);d[v]++;
	}
	
	q[H=T=1]=1;f[1][0]=1;
	for (int i=1;i<=n;i++)
	{
		int u=q[H++];
		for (int j=0;j<=k;j++) ans[u]=((ll)f[u][j]*jc[j]%mod*s[k][j]+ans[u])%mod;
		
		for (int v,j=hd[u];j;j=pr[j]) 
		{
			d[v=to[j]]--;if (d[v]==0) q[++T]=v;
			MOD(f[v][0]+=f[u][0]);
			for (int j=1;j<=k;j++) MOD(f[v][j]+=f[u][j]),MOD(f[v][j]+=f[u][j-1]);
		}
	}
	for (int i=1;i<=n;i++) printf("%d\n",ans[i]);
	return 0;
}
/*
6 8 2
1 2
1 3
1 5
2 4
3 2
3 4
3 6
4 6
*/
