#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=j;i<=k;++i)
#define Forr(i,j,k) for(register int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=30,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;register char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
int n,a[N],ans,p[N];
inline void rev(int k){
	For(i,1,(k>>1))
	  swap(a[i],a[k+1-i]);
}
int lim;
inline bool dfs(int now,int g,int last){
	if(now+g>lim)return 0;
	if(now==lim){
		For(i,1,n)if(a[i]!=i)return 0;
		return 1;
	}
	int t=n,G;
	while(a[t]==t&&t)t--;
	For(j,2,t){
		if(j==last)continue;
		G=g+(abs(a[j]-a[j+1])==1)-(abs(a[1]-a[j+1])==1);
		rev(j);
		if(dfs(now+1,G,j))return 1;
		rev(j);
	}	
	return 0;
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence1.out","w",stdout);
	int t;
	read(t);
	while(t--){
		read(n);
		For(i,1,n)read(a[i]);
		int k=0;
		a[n+1]=n+1;
		For(i,1,n)
			k+=(abs(a[i]-a[i+1])>1);
		ans=n*n;
		for(lim=0;;lim++)if(dfs(0,k,1)){ans=lim;break;}
		printf("%d\n",ans);
	}
	return 0;
}

