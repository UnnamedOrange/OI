#include <bits/stdc++.h>
using namespace std;
int N, M, K;
int main()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	scanf("%d%d%d", &K, &N, &M);
	if (K % 2) cout<<N<<endl;
	else cout<<M<<endl;
	return 0;
}
