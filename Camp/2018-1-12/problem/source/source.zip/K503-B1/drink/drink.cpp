#include<bits/stdc++.h>
using namespace std;
const int maxn=1000010;
const int T=48;
int n,a[maxn],mp1[maxn][T+4],mp2[maxn][T+4],f1[maxn],f2[maxn],r,rr,b1[maxn],b2[maxn];
long long get2n[maxn];
int i,j,k;
double ans1,ans;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for (i=1;i<=n;i++) a[i]=read();
	get2n[0]=1; for (i=1;i<=60;i++) get2n[i]=get2n[i-1]*2;
	memset(f1,0,sizeof(f1)); r=0;
	for (i=1;i<=n;i++){
		j=r;
		while ( (j!=0)&&(a[f1[j]]<=a[i]) ){
			b1[f1[j]]++;
			mp1[f1[j]][b1[f1[j]]]=i;
			j--;
		}
		rr=0;
		for (k=j+1;k<=r;k++){
			rr++; f2[rr]=f1[k];
		}
		r=j+1;
		f1[r]=i;
		for (j=1;j<=rr;j++){
			if (b1[f2[j]]<T){
				r++; f1[r]=f2[j];
			}
		}
	}
	memset(f1,0,sizeof(f1)); r=0;
	for (i=n;i>=1;i--){
		j=r;
		while ( (j!=0)&&(a[f1[j]]<a[i]) ){
			b2[f1[j]]++;
			mp2[f1[j]][b2[f1[j]]]=i;
			j--;
		}
		rr=0;
		for (k=j+1;k<=r;k++){
			rr++; f2[rr]=f1[k];
		}
		r=j+1;
		f1[r]=i;
		for (j=1;j<=rr;j++){
			if (b2[f2[j]]<T){
				r++; f1[r]=f2[j];
			}
		}
	}
	ans=0;
	for (i=1;i<=n;i++){
		ans1=0;
		mp1[i][0]=i;
		for (j=0;j<=b1[i];j++){
			if (j!=b1[i]) ans1=ans1+(((mp1[i][j+1]-mp1[i][j])*1.0)/get2n[j+1])*a[i];
			else ans1=ans1+((1.0*(n-mp1[i][j]+1))/get2n[j+1])*a[i];
		}
		mp2[i][0]=i;
		for (j=0;j<=b2[i];j++){
			if (j!=b2[i]) ans=ans+ans1*(mp2[i][j]-mp2[i][j+1]);
			else ans=ans+ans1*mp2[i][j];
			ans1=ans1/2;
		}
	}
	ans=ans/(n*n);
	printf("%lf\n",ans);
	return 0;
}
/*
5
1 2 3 4 1

*/
