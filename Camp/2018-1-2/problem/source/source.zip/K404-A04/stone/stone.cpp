#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
const int maxn=100010;
const int mod=1000000007;
int n,da[maxn],a[maxn],t[2],len;
ll ans[4];
bool cal(int b)
{
	for(int i=1;i<=len;i++)
		if(a[i]>=t[b])
		{
			bool f=1;
			a[i]-=t[b];
			f=cal(b^1);
			a[i]+=t[b];
			if(!f) return 1;
		}				
	return 0;	
}
void spc()
{
	ll f[2],p[2];f[0]=0;f[1]=1;
	for(int i=1;i<=n;i++)
	{
		p[0]=f[0];p[1]=f[1];
		int b=((da[i]/t[0])&1);
		(f[0]+=p[b])%=mod;
		(f[1]+=p[b^1])%=mod;
	}
	ans[2]=f[0];ans[3]=f[1];
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&t[0],&t[1]);
	for(int i=1;i<=n;i++)
		scanf("%d",&da[i]);
	if(n<=5)
	{
		for(int i=0;i<(1<<n);i++)
		{
			len=0;
			for(int j=1;j<=n;j++)
				if((i>>(j-1))&1) a[++len]=da[j];
			bool c0=cal(0),c1=cal(1);
			if(c0&&!c1) ans[0]++;
			if(!c0&&c1) ans[1]++;
			if(c0&&c1) ans[2]++;
			if(!c0&&!c1) ans[3]++;	
		}
	}
	else spc();
	for(int i=0;i<=3;i++)
		printf("%lld ",ans[i]);
	return 0;
}
/*4 1 1
6 6 8 10*/
