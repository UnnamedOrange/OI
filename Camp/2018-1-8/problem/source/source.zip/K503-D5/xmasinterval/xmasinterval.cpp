#include <cstdio>
#include <algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
const int N=5e5+5;
using namespace std;
int n,m,i,l[N],r[N],x[N];
int ans,cnt,b[N],used[N],mmp[N];
void judge()
{
	int i;
	rep(i,1,cnt) mmp[i]=0;
	rep(i,1,n)
	  if(used[i]) mmp[l[i]]++,mmp[r[i]+1]--;
	rep(i,1,cnt) mmp[i]+=mmp[i-1];
	rep(i,1,m)
	  if (mmp[x[i]]<1) return;
	ans++;
}
void dfs(int x)
{
	if (x>n) {
		judge(); return;
	}
	dfs(x+1);
	used[x]=1;
	dfs(x+1);
	used[x]=0;
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n) scanf("%d%d",&l[i],&r[i]),b[++cnt]=l[i],b[++cnt]=r[i];
	rep(i,1,m) scanf("%d",&x[i]),b[++cnt]=x[i];
	sort(b+1,b+1+cnt);
	cnt=unique(b+1,b+1+cnt)-b-1;
	rep(i,1,n) l[i]=lower_bound(b+1,b+1+cnt,l[i])-b;
	rep(i,1,n) r[i]=lower_bound(b+1,b+1+cnt,r[i])-b;
	rep(i,1,m) x[i]=lower_bound(b+1,b+1+cnt,x[i])-b;
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
