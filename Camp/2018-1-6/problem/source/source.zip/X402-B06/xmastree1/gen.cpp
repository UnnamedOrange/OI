#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("xmastree1.in","w",stdout);
	#endif
}
const int MAXN=1e5+7;
static int n=50000,q=50000;
int main(void){
	file();
    static int x;
	printf("%d %d 0\n",n,q);
    Rep(i,1,n)printf("%d ",rand()%n+1);
    putchar('\n');
    Rep(i,1,n-1)printf("%d %d\n",i,i+1);
    Rep(i,1,q)
    {
        if(rand()&1)
        {
            x=rand()%n+1;
            printf("1 %d %d %d\n",rand()%n+1,x,rand()%(n-x+1)+x);
        }
        else printf("2 %d %d\n",rand()%n+1,rand()%n+1);
    }
    return 0;
}

