#include<cstdio>
#include<algorithm>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
#define F 1
#define L 0
#define A 2
using namespace std;
const int maxn = 25;
int n, a, b, flag;
int status[maxn], stone[maxn];
int ans[4];

int Merge(int mask) {
	int ans = 0;
	For(i, 1, n) {
		if(mask & 1) 
			if(status[i] < 2)
				if(ans != status[i]) ans = 1;
				else ans = 0;
			else {ans = 2; return ans;}
		mask >>= 1;
	}
	return ans % 4;
}

int main() {
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	scanf("%d%d%d", &n, &a, &b);
	if(n <= 20) {
		if(a > b) swap(a, b), flag = 1;
		For(i, 1, n) {
			scanf("%d", &stone[i]);
			int last = stone[i] % (a + b) - a;
			if(last == 0) {
				if(a != b)status[i] = A;
				else status[i] = (stone[i] / a) & 1;
			}else if(last > 0) status[i] = F;
			else status[i] = L;
		}
		int stmax = (1 << n) - 1;
		++ans[L];/*�ռ�*/
		For(i, 1, stmax) {
			int mask = i, st;
			++ans[st = Merge(i)];
			/*printf("%s : ", st == F ? "First" : st == L ? "Last" : "Smaller");
			For(j, 1, n) {
				if(mask & 1) printf("%d ", stone[j]);
				mask >>= 1;
			}
			putchar('\n');*/
		}
		if(flag) printf("%d %d %d %d", 0, ans[2] + ans[3], ans[0], ans[1]);
		else printf("%d %d %d %d", ans[2] + ans[3], 0, ans[0], ans[1]);
	} else {
		For(i, 1, n) {scanf("%d", &stone[0]), ++ans[(stone[0] / a) & 1];}
		printf("%d %d %d %d", 0, 0, ans[0] * ans[0], ans[1] * ans[1]);
	}
	return 0;
}
