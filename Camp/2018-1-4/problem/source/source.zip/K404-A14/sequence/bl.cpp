#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int INF=1e9;
const int N=30;
int a[N],c[N];int vis[N];
int n;int ans;
int totans;

bool check(){
	int i;
	rep(i,1,n)	if(a[i]!=i)	return false;
	return true;
}

void dfs(int now,int lim,int last){
	int i;
	if(now==lim+1){
		if(check())	{
			ans=min(ans,lim);
			//printf("%d\n",lim);
			//rep(i,1,lim)	printf("%d ",c[i]);
			//printf("\n");
		}
		return;
	}
	for(i=2;i<=n&&ans==INF;i++) if(i!=last){
		reverse(a+1,a+1+i);c[now]=i;
		dfs(now+1,lim,i);
		reverse(a+1,a+1+i);
	}
}

/*void work(int now){
	int i;
	if(now>n){
		ans=INF;
		rep(i,0,2*n-2) {dfs(1,i,0);if(ans!=INF)	break;}
		if(ans>=n){
			rep(i,1,n)	printf("%d ",a[i]);
			printf("\n");
		}
		totans=max(ans,totans);
		return;
	}
	rep(i,1,n)	if(!vis[i]){
		a[now]=i;vis[i]=1;work(now+1);vis[i]=0;
	}
}*/

int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int i;int T;
	scanf("%d",&T);
	while(T--){
		//if(n<=8){			
			scanf("%d",&n);
			ans=INF;
			rep(i,1,n)	scanf("%d",&a[i]);
			rep(i,0,2*n-2) {dfs(1,i,0);if(ans!=INF)	break;}
			printf("%d\n",ans);
		//}
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
