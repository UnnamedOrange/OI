while true
do
./data
./bf
./xmastree3
diff xmastree3.out xmastree3.txt||break
printf "#"
done
