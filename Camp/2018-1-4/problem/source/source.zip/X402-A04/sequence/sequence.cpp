#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
//#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=30;
const int inf=0x3f3f3f3f;
int a[N],b[N],n;
inline void rev(int r)
{
	for(int i=1;i<=r;++i) b[i]=a[r-i+1];
	for(int i=1;i<=r;++i) a[i]=b[i];
}

bool found=0;
void dfs(int r,int las,int lim)
{
	if(found) return ;
	int s=0;
	for(int i=1;i<n;++i) if(abs(a[i]-a[i+1])!=1) s++;
	if(r+s>lim) return ;

	bool can=1;
	for(int i=1;i<=n;++i) if(a[i]!=i) {can=0;break;}
	if(can) {found=1;return ;}
	
	for(int i=2;i<=n;++i)
	{
		if(i==las) continue;
		//for(int j=1;j<=i;++j) b[j]=a[i-j+1];
		//for(int j=1;j<=i;++j) a[j]=b[j];
		for(int j=1;j<=(i>>1);++j){int t=a[j];a[j]=a[i-j+1];a[i-j+1]=t;}
		dfs(r+1,i,lim);
		for(int j=1;j<=(i>>1);++j){int t=a[j];a[j]=a[i-j+1];a[i-j+1]=t;}
		//for(int j=1;j<=i;++j) b[j]=a[i-j+1];
		//for(int j=1;j<=i;++j) a[j]=b[j];
	}
}

void wj()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
//	clock_t sta=clock();
	T=read();
	for(int cas=1;cas<=T;++cas)
	{
		found=0;
		n=read();
		for(i=1;i<=n;++i) a[i]=read();
		for(i=0;;++i)
		{
			//if(i>n+2) cp;
			dfs(0,-1,i);
			if(found) break;
		}
		printf("%d\n",i);
	}
//	clock_t fin=clock();
//	cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
