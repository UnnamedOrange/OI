//#include <bits/stdc++.h>
#include <cstdio>
#include <iostream>
#include <cstring>
#include <queue>

#define MP make_pair
#define PB push_back
#define FO(x) freopen(#x".in", "r", stdin), freopen(#x".out", "w", stdout)

using namespace std;
typedef long long LL;
typedef unsigned long long u64;

template <typename T> inline bool cmin(T & a, const T & b) {
	return a > b ? a = b, 1 : 0;
}
template <typename T> inline bool cmax(T & a, const T & b) {
	return a < b ? a = b, 1 : 0;
}
int read() {
	int x = 0, f = 1;
	char ch;
	for(ch = getchar(); !isdigit(ch); ch = getchar())
		if(ch == '-') f = -1;
	for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	return x * f;
}

const int MaxN = 7, MaxM = 666, P = 998244353;

int n, m, f[2][MaxM][MaxM];
char s[MaxN][MaxM];

struct Aho {
	int dep[MaxM], ch[MaxM][2], fa[MaxM], fail[MaxM], e[MaxM], mask[MaxM],lst[MaxM], pn;
	void clear() {
		memset(lst, 0, sizeof(lst));
		memset(fa, 0, sizeof(fa));
		memset(ch, 0, sizeof(ch));
		memset(e, 0, sizeof(e));
		memset(dep, 0, sizeof(dep));
		memset(mask, 0, sizeof(mask));
		memset(fail, 0, sizeof(fail));
		pn = 0;
	}

	void insert(char *s, int n, int t) {
		int p = 0;
		for(int i = 1; i <= n; i++) {
			int c = s[i] - '0';
			if(!ch[p][c]) ch[p][c] = ++pn;
			dep[ch[p][c]] = dep[p] + 1;
			mask[p] |= (1 << t);
			p = ch[p][c];
		}
		e[p] = 1;
		mask[p] |= (1 << t);
	}

	queue<int> q;
	void build() {
		for(int i = 0; i < 2; i++)
			if(ch[0][i]) q.push(ch[0][i]);
		while(!q.empty()) {
			int c = q.front();
			q.pop();
			for(int i = 0; i < 2; i++) {
				int np = ch[c][i];
				if(!np) ch[c][i] = ch[fail[c]][i];
				else {
					q.push(np);
					fail[np] = ch[fail[c]][i];
					lst[np] = e[fail[np]] ? fail[np] : lst[fail[np]];
				}
			}
		}
	}
	bool safe(int x) {
		return !e[x] && !lst[x]; //????
	}
	bool cov(int x, int i) {
		return mask[x] >> i & 1;
	}
} A, B;

inline int add(int a, int b) {
	return a + b >= P ? a + b - P : a + b;
}

int co[1 << MaxN + 1], len[MaxN];
int t[MaxM], tn;

bool check(int a, int b) {
	if(!A.safe(a) || !B.safe(b)) return 0;
	for(int i = 0; i < n; i++) {
		int m = len[i], x, y;
		++tn;
		for(x = a; x; x = A.fail[x]) if(A.cov(x, i)) t[A.dep[x]] = tn;
		for(y = b; y; y = B.fail[y]) if(B.cov(y, i)) if(B.dep[y] <= m && t[m - B.dep[y]] == tn) return 0;
	}
	return 1;
}
int main() {
	FO(string);
	int i, j, k, o;
	n = read();
	m = read();
	for(i = 0; i < n; i++) {
		scanf("%s", s[i] + 1);
		len[i] = strlen(s[i] + 1);
	}

	co[0] = 1;
	int ans = 0;
	for(int s = 0; s < (1 << n); s++) {
		if(s) co[s] = -co[s - (s & -s)];
		A.clear();
		B.clear();
		for(i = 0; i < n; i++) {
			if(s >> i & 1) {
				int m = len[i];
				char t[MaxM];
				for(j = 1; j <= m; j++) t[j] = :: s[i][m - j + 1];
				t[m + 1] = 0;
				A.insert(:: s[i], m, i);
				B.insert(t, m, i);
			}
		}
		A.build();
		B.build();
		memset(f, 0, sizeof(f));
		f[0][0][0] = 1;
		for(i = 0; i < m; i++) {
			for(j = 0; j <= A.pn; j++)
				for(k = 0; k <= B.pn; k++)
					f[~i & 1][j][k] = 0;
			for(j = 0; j <= A.pn; j++)
				if(A.safe(j))
					for(k = 0; k <= B.pn; k++)
						if(B.safe(k) && f[i & 1][j][k]) {
							for(o = 0; o <= 1; o++) {
								int nj = A.ch[j][o];
								int nk = B.ch[k][o ^ 1];
								f[~i & 1][nj][nk] = add(f[~i & 1][nj][nk], f[i & 1][j][k]);
							}
						}
		}
		int nans = 0;
		for(j = 0; j <= A.pn; j++)
			for(k = 0; k <= B.pn; k++)
				if(f[m & 1][j][k] && check(j, k))
					nans = add(nans, f[m & 1][j][k]);
		if(co[s] > 0) (ans += nans) %= P;
		else (ans -= nans) %= P;
	}
	ans = (ans + P) % P;
	cout << ans << endl;
	return  0;
}

