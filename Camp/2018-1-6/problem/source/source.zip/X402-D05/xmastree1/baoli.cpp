#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
int n,m;
int c[maxn];
int cnt[maxn];
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
int f[maxn];
void dfs(int u){
	cnt[c[u]]=1;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==f[u]) continue;
		f[tto[i]]=u;
		dfs(tto[i]);
	}
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int M,T;
	scanf("%d%d%d",&n,&M,&T);
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]);
	int s,t;
	for(int i=2;i<=n;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	dfs(1);
	int op,l,r,u,v,ans=0;
	for(m=1;m<=M;m++){
		scanf("%d",&op);
		if(op==1){
			scanf("%d%d%d",&u,&l,&r);
			if(T==1) u^=ans,l^=ans,r^=ans;
			if(l>r) swap(l,r);
			for(int i=l;i<=r;i++)
				cnt[i]=0;
			dfs(u);
			ans=0;
			for(int i=l;i<=r;i++)
				ans+=cnt[i];
			printf("%d\n",ans);
			if(m>=M-3) cerr<<ans<<endl;
		}
		else{
			scanf("%d%d",&u,&v);
			c[u]=v;
		}
	}
	return 0;
}
