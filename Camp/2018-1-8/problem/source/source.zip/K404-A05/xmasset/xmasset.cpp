#include <bits/stdc++.h>

int type, N;

void init()
{
    
}

int encode(int x, int y)
{
	for(int i=0;i<10;i++)
	{
		if(((x>>i)&1)&&!((y>>i)&1))
		{
			return i+1;
		}
	}
	for(int i=0;i<10;i++)
	{
		if(!((x>>i)&1)&&((y>>i)&1))
		{
			return i+11;
		}
	}
    return x;
}

bool decode(int q, int h)
{
	h--;
	if(h<10)return ((q>>h)&1);
	else return !((q>>(h-10))&1);
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}

