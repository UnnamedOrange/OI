#include <cstdio>

typedef long double ld;
const int MAXN = 1000000 + 10;
int N;
ld A[MAXN];
ld ans;

int main() {
	freopen( "drink.in", "r", stdin );
	freopen( "drink.out", "w", stdout );
	register int i, j;
	double x;
	ld a, b, res;
	scanf( "%d", &N );
	for( i = 1; i <= N; ++i )
		scanf( "%lf", &x ), A[i] = x;
	for( i = 1; i <= N; ++i ) {
		res = 1;
		a = 1, b = 1;
		for( j = i - 1; j >= 1; --j ) {
			if( A[j] > A[i] )
				res /= 2;
			a += res;
		}
		res = 1;
		for( j = i + 1; j <= N; ++j ) {
			if( A[j] >= A[i] )
				res /= 2;
			b += res;
		}
		ans += a * b * A[i] / 2;
	}
	printf( "%.15lf\n", double( ans / N / N ) );
	return 0;
}
