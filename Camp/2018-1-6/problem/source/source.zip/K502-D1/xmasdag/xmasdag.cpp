#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm> 

using namespace std;

const int MAXN = 1e5 + 10; 
long long mod = 998244353;
int n, m, k;
int vis[MAXN];
int head[MAXN];
long long num[MAXN];
long long sum[MAXN];
long long f[3000][3000];
int in[MAXN];
int u, v;
int cnt = 0;
struct edge {
	int v;
	int next;
} g[MAXN * 3]; 
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

void open()
{
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout); 
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}
void addedge(int u, int v) 
{
	g[++cnt].v = v;
	g[cnt].next = head[u];
	head[u] = cnt;
}

void DFS(int x)
{
	if(x == 1) {
		return ;
	}
	else if(vis[x]) {
		return ;
	}
	for(int j = head[x]; j; j = g[j].next) {
		int to = g[j].v;
		DFS(to);
		for(int t = 1; t <= n; t++) {
			f[x][t] = (f[x][t] + f[to][t - 1]) % mod;
		}
	}
	vis[x] = 1;
}

void DFS2(int x)
{
	if(x == 1) {
		return ;
	}
	else if(vis[x]) {
		return ;
	}
	for(int j = head[x]; j; j = g[j].next) {
		int to = g[j].v;
		DFS2(to);
		num[x] = (num[x] + num[to]) % mod;
		sum[x] = (sum[x] + sum[to] + num[to]) % mod; 
	}
	vis[x] = 1;
}
long long cal(int x, int k)
{
	long long res = 1, cnt = x;
	while(k) {
		if(k % 2 == 1) {
			res = res * cnt % mod;
			k--;
		} else {
			cnt = cnt * cnt % mod;
			k = k / 2;
		}
	}
	return res;
}
int main()
{
	open();
	//cout<<sizeof(f) / 1024 / 1024;
	n = read(), m = read(), k = read();
	if(n <= 2000) {
		f[1][0] = 1;
		for(int i = 1; i <= m; i++) {
			u = read(), v = read();
			addedge(v, u);
			in[u]++;
		}
		for(int i = 1; i <= n; i++) {
			if(!in[i]) {
				DFS(i);
			}
		}
		for(int i = 1; i <= n; i++) {
			long long ans = 0;
		//	cout<<i<<endl; 
			for(int j = 0; j <= n; j++) {
		//		cout<<f[i][j]<<" ";  
				ans = (ans + f[i][j] * cal(j, k)) % mod;
			}
		//	cout<<endl;
			printf("%lld\n", ans);
		}
	} else if(k == 1) {
		num[1] = 1;
		sum[1] = 0;
		for(int i = 1; i <= m; i++) {
			u = read(), v = read();
			addedge(v, u);
			in[u]++;
		}
		for(int i = 1; i <= n; i++) {
			if(!in[i]) {
				DFS2(i);
			}
		}
		for(int i = 1; i <= n; i++) {
			printf("%lld\n", sum[i]);
		}
	}
	close();
}
