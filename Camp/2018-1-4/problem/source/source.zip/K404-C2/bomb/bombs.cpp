#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
const int N=15,M=2000;
int n,m,u,v,f[M];
bool vis[N][N];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

bool check(int s)
{
	rep(i,1,n)
		rep(j,1,n)
			if(i!=j && s&(1<<i-1) && s&(1<<j-1) && vis[i][j])
				return 0;
	return 1;
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bombs.out","w",stdout);
	n=getint(),m=getint();
	rep(i,1,m) u=getint(),v=getint(),vis[u][v]=1;
	rep(k,1,n)
		rep(i,1,n)
			rep(j,1,n)
				vis[i][j]|=(vis[i][k] && vis[k][j]);
	rep(i,1,(1<<n)-1) f[i]=1000000000;
	rep(i,0,(1<<n)-2)
	{
		rep(j,1,(1<<n)-1)
			if(check(j))
				f[i|j]=min(f[i|j],f[i]+1);
	}
	printf("%d\n",f[(1<<n)-1]);
	return 0;
}
