#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#define N 100005
#define mod 998244353
using namespace std;
typedef long long ll;
struct edge{
	int k,next;
}e[500005];
ll f[N][505],w[505],C[505][505];
int n,m,K,home[N],cnt=-1;
void add(int x,int y){
	cnt++;
	e[cnt].k=y;
	e[cnt].next=home[x];
	home[x]=cnt;
}
ll quick_pow(ll a,ll b){
	ll ans=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1) ans=ans*a%mod;
	return ans;
}
int s[N],top,IN[N];
void topsort(){
	for(int i=0;i<=K;i++) C[i][0]=C[i][i]=1;
	for(int i=1;i<=K;i++){
		for(int p=1;p<K;p++) C[i][p]=(C[i-1][p]+C[i-1][p-1])%mod;
	}
	for(int i=1;i<=n;i++) if(!IN[i]) s[++top]=i;
	for(int i=1;i<=n;i++){
		for(int p=home[s[i]];~p;p=e[p].next){
			IN[e[p].k]--;
			if(!IN[e[p].k]) s[++top]=e[p].k;
		}
	}
	for(int i=1;i<=n;i++){
		int x=s[i];
		for(int p=home[s[i]];~p;p=e[p].next){
			for(int j=0;j<=K;j++){
				for(int k=0;k<=j;k++)
					f[e[p].k][j]=(f[e[p].k][j]+f[x][k]*C[j][k])%mod;
			}
		}
	}
	for(int i=1;i<=n;i++) printf("%lld\n",f[i][K]);
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	memset(home,-1,sizeof(home));
	scanf("%d%d%d",&n,&m,&K);
	for(int i=1,x,y;i<=m;i++){
		scanf("%d%d",&x,&y);
		add(x,y);
		IN[y]++;
	}
	f[1][0]=1;
	topsort();
	return 0;
}
