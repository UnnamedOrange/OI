#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=100+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("xmasset.in","r",stdin);
		freopen("xmasset.out","w",stdout);
	#endif
}
int type,n;
void input()
{
	type=read<int>();n=read<int>();
}
int x,y,xx,yy;
void work1()
{
	x=read<int>();y=read<int>();
	if(x%8!=y%8)
	{
		x%=8;
		printf("%d\n",x<<1);
	}
	else
	{
		xx=x;yy=y;
		x%=64;x>>=3;
		y%=64;y>>=3;
		if(x!=y)printf("%d\n",x<<1|1);
		else printf("%d\n",xx);
	}
}
int qq,q,h;
void work2()
{
	q=read<int>();h=read<int>();
	if(h>15)
	{
		if(q==h)puts("yes");
		else puts("no");
	}
	else
	{
		if(h%2==0)
		{
			h>>=1;
			qq=q%8;
			if(qq==h)puts("yes");
			else puts("no");
		}
		else
		{
			h>>=1;
			qq=q%64;qq>>=3;
			if(qq==h)puts("yes");
			else puts("no");
		}
	}	
}
int main()
{
	file();
	input();
	int T=read<int>();
	while(T--)
	{
		if(type==1)work1();
		else if(type==2)work2();
	}
	return 0;
}
