#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 1000000007;

inline ll read() {
	ll x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

ll dp[110][110], ans;
int s, t, n, m;

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int main() {
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);

	int i, j, k;
	s = read(), t = read(), n = read(), m = read();

	dp[0][0] = 1;
	for(i = 0; i < m; i++) {
		for(j = i; j <= s; j++) {
			int ed = i+1 <= n ? min(t, s-j) : s-j;
			for(k = 1; k <= ed; k++) 
				update(dp[i+1][j+k], dp[i][j]);
		}
		/*for(j = 0; j <= s; j++) printf("%lld ", dp[i][j]);
		printf("\n");*/
	}
	for(j = 0; j <= s; j++) update(ans, dp[m][j]);
	printf("%lld\n", ans);
	return 0;
}
