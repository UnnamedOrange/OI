#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
#define chkmin(a,b) (a>(b)?a=(b),1:0)
#define chkmax(a,b) (a<(b)?a=(b),1:0)
using namespace std;
const int mod=1000000007;
const int maxn=1000010;
int n,d[maxn],c[maxn],f[maxn];
ll g[maxn];
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&c[i],&d[i]);
	memset(f,0xff,sizeof(f));
	g[0]=1;f[0]=0;
	for(int i=1;i<=n;i++)
		for(int j=i,l=1,r=n;j;j--)
		{
			chkmax(l,c[j]);chkmin(r,d[j]);
			if(max(l,i-j+1)>r) break;
			if(i-j+1>=l)
			{
				if(f[i]==f[j-1]+1) (g[i]+=g[j-1])%=mod;
				if(chkmax(f[i],f[j-1]+1)) g[i]=g[j-1];
			}
		}
	if(f[n]<=0) puts("-1");
	else printf("%d %lld",f[n],g[n]);
	return 0;
}
/*20
1 19
2 20
1 19
2 20
1 19
2 20
1 19
2 20
1 19
2 20
1 19
2 20
1 19
2 20
1 19
2 20
1 19
2 20
1 19
2 20*/
