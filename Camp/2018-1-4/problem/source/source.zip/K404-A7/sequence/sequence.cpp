/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 25;

int n, t;
int a[MAXN], b[MAXN];

inline int solve1() {
	int ans = 0;
	R(n);
	for (int i = 1; i <= n; ++i) R(a[i]);
	memcpy(b, a, sizeof(a));
	for (int i = n; i >= 1; --i) {
		int pos;
		for (int j = 1; j <= n; ++j) if (a[j] == i) pos = j;
		if (pos == i) continue ;
		if (pos == 1) {
			for (int j = 1; j <= i / 2; ++j) std::swap(a[j], a[i + 1 - j]);
			ans++;
		} else {
			for (int j = 1; j <= pos / 2; ++j) std::swap(a[j], a[pos + 1 - j]);
			for (int j = 1; j <= i / 2; ++j) std::swap(a[j], a[i + 1 - j]);
			ans += 2;
		}
	}
	return ans;
}

inline int solve2(int *a) {
	int ans = 0;
	for (int i = n; i >= 1; --i) {
		int pos;
		for (int j = 1; j <= n; ++j) if (a[j] == i) pos = j;
		if (pos == i) continue ;
		if (pos == 1) {
			for (int j = 1; j <= i / 2; ++j) std::swap(a[j], a[i + 1 - j]);
			ans++;
		} else {
			int temp = i;
			while (a[pos + 1] == temp - 1 && pos < i) pos++, temp--;
			for (int j = 1; j <= pos / 2; ++j) std::swap(a[j], a[pos + 1 - j]);
			for (int j = 1; j <= n; ++j) if (a[j] == i) pos = j;
			if (pos != 1) {			
				for (int j = 1; j <= pos / 2; ++j) 
					std::swap(a[j], a[pos + 1 - j]);
				ans++;
			}
			for (int j = 1; j <= i / 2; ++j) std::swap(a[j], a[i + 1 - j]);
			ans += 2;
		}
	}
	return ans;
}

int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	R(t);
	while (t--) {
		int ans = solve1();
		ans = std::min(solve2(b), ans);
		W(ans), write_char('\n');
	}
	flush();
	return 0;
}
