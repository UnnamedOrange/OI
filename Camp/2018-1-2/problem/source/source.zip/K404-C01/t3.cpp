//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<queue>
#include<cmath>
const int N=100007;
const int mod=1e9+7;
typedef long long LL;
using namespace std;
int n;
LL a,b,x[N],lit,one,zero,Alice,Bob,xs,hs,power[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') f=-1,ch=getchar();
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

LL ksm(LL a,LL b) {
	LL base=a,res=1;
	while(b) {
		if(b&1) (res*=base)%=mod;
		(base*=base)%=mod;
		b>>=1;
	}
	return res;
}

LL C(int n,int m) {
	return power[n]*ksm(power[m],mod-2)%mod*ksm(power[n-m],mod-2)%mod;
}

int main() {
#ifdef DEBUG
	freopen("1.in","r",stdin);
	freopen("my.out","w",stdout);
#endif
	read(n); read(a); read(b);
	int fl=0;
	if(a>b) swap(a,b),fl=1;
	power[0]=1;
	for(int i=1;i<=100000;i++) power[i]=power[i-1]*i%mod;
	for(int i=1;i<=n;i++) {
		read(x[i]);
		int tp=(x[i]%(a+b));
		if(tp>=a&&tp<b) lit++;
		else if(tp>=b) one++;
		else zero++;
	}
	LL ans1=0,ans2=0;
	for(int i=1;i<=lit;i++) 
		(ans1+=C(lit,i))%=mod;
	for(int i=1;i<=n-lit;i++) 
		(ans2+=C(n-lit,i))%=mod;
	if(fl) Bob=(ans1+ans1*ans2%mod)%mod;
	else Alice=(ans1+ans1*ans2%mod)%mod;
	for(int i=0;i<=zero;i++) 
		(hs+=C(zero,i))%=mod;
	ans1=hs;
	for(int i=1;i<=one;i++) {
		if(i&1) 
			(xs+=C(one,i)*ans1%mod)%=mod;
		else 
			(hs+=C(one,i)*ans1%mod)%=mod;
	}
	printf("%lld %lld %lld %lld\n",Alice,Bob,xs,hs);
	return 0;
}
/*
2 2 3
2 3
*/
