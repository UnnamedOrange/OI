#include<bits/stdc++.h>
using namespace std;
const int INF=0x3f3f3f3f;
int T,l;
inline int rd(){int x;cin>>x;return x;}
string S;
inline bool judge_valid(const string &tt,int l,int r){
	int bz=1;int lim=(r-l+1)/2;
	for(int i=1;i<=lim;++i)
		bz&=(tt[i+l-1]==tt[r-i+1]);
	return bz;
}
inline int F(string tar){
	if(tar.length()==0)return 0;
	int r=tar.length();
	int ans=0x3f3f3f3f;
	for(int L=0;L<r;++L){
		for(int R=L;R<r;++R){
			if(!judge_valid(tar,L,R))
				ans=min(ans,F(tar.substr(0,L)+tar.substr(R+1,r-R-1))+1);
		}
	}
	return ans;
}
inline void solve(){
	scanf("%d",&l);
	cin>>S;
	int ans=F(S);
	if(ans>=INF)puts("-1");
	else printf("%d\n",ans);
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	for(T=rd();T;T--)solve();
}
