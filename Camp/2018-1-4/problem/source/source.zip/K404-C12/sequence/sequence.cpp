#include <algorithm>
#include <iostream>
#include <utility>
#include <cstring>
#include <cstdio>
#include <queue>
#define mp make_pair
using namespace std; 
int arr[25]; 
namespace solver
{
	unsigned short idx[100000005]; 
	int n, dis[50005], num[50005]; 
	inline int rev(int x, int l, int r)
	{
		for (int i = n - 1; i >= 0; i--)
		{
			arr[i] = x % 10; 
			x /= 10; 
		}
		reverse(arr + l, arr + r + 1); 
		int y = 0; 
		for (int i = 0; i < n; i++)
			y = y * 10 + arr[i]; 
		return y; 
	}
	void init(int _n)
	{
		n = _n; 
		for (int i = 0; i < n; i++)
			arr[i] = i; 
		int cur = 0; 
		do
		{
			int x = 0; 
			for (int i = 0; i < n; i++)
				x = x * 10 + arr[i]; 
			num[cur] = x; 
			idx[x] = cur++; 
		} while (next_permutation(arr, arr + n)); 
		priority_queue<pair<int, int> > que; 
		memset(dis, 0x3f, sizeof(dis)); 
		dis[0] = 0; 
		que.push(mp(0, 0));
		while (!que.empty())
		{
			int d = -que.top().first, u = que.top().second; 
			que.pop(); 
			if (d != dis[u])
				continue; 
			for (int r = 1; r < n; r++)
			{
				int v = idx[rev(num[u], 0, r)]; 
				if (dis[v] > dis[u] + 1)
				{
					dis[v] = dis[u] + 1; 
					que.push(mp(-dis[v], v)); 
				}
			}
		}
	}
	int solve()
	{
		int x = 0; 
		for (int i = 0; i < n; i++)
			x = x * 10 + arr[i] - 1; 
		return dis[idx[x]]; 
	}
}
int main()
{
	freopen("sequence.in", "r", stdin); 
	freopen("sequence.out", "wt", stdout); 
	int t; 
	scanf("%d", &t); 
	bool f = true; 
	while (t--)
	{
		int n; 
		scanf("%d", &n); 
		if (f)
		{
			solver::init(min(n, 8)); 
			f = false; 
		}
		for (int i = 0; i < n; i++)
			scanf("%d", arr + i);
		int ans = 0; 
		for (int i = n; i; i--)
		{
			if (i <= 8)
			{
				ans += solver::solve(); 
				break; 
			}
			int pos; 
			for (int j = 0; j < n; j++)
			{
				if (arr[j] == i)
				{
					pos = j; 
					break; 
				}
			}
			if (pos == i - 1)
				continue; 
			if (pos)
			{
				reverse(arr, arr + pos + 1);
				ans++; 
			}
			reverse(arr, arr + i); 
			ans++; 
		}
		printf("%d\n", ans); 
	}
	return 0; 
}

