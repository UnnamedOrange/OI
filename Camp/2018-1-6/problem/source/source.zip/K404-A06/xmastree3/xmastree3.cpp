#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <vector> 
#define pb push_back
#define all(x) (x).begin(), (x).end()
using namespace std;

const int mod = 998244353;

void fwt(int *a, int n) {
	for(int i = 0; i < n; ++i) {
		int g = 1<<i;
		for(int j = (1<<n)-1; ~j; --j)
			if(g&j) {
				int x = a[j^g], y = a[j];
				a[j^g] = (x+y)%mod;
				a[j] = (x-y+mod)%mod;
			}
	}
}

int n, k, f[55][1<<15];

int main() {
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for(int i = 1; i < n; ++i) {
		int u, v;
		scanf("%d%d", &u, &v);
	}
	for(int i = 1; i <= n; ++i) fwt(f[i], k);
	printf("%d\n", n*k);
	return 0;
}
