#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=100005;
typedef unsigned long long ull;
const ull base=29;

char s[N];int n;
ull p[N],hs1[N],hs2[N];

inline bool pan(int l,int r) {return hs1[r]-hs1[l-1]*p[r-l+1]==hs2[l]-hs2[r+1]*p[r-l+1];}

void work()
{
	scanf("%d",&n);
	scanf("%s",s+1);
	for (int i=1;i<=n;i++) hs1[i]=hs1[i-1]*base+s[i]-'a'+1;
	hs2[n+1]=0;
	for (int i=n;i>=1;i--) hs2[i]=hs2[i+1]*base+s[i]-'a'+1;
	if (hs1[n]!=hs2[1]) {puts("1");return ;}
	for (int i=1;i<n;i++) 
	if ((!pan(1,i))&&(!pan(i+1,n))) 
	{
		puts("2");
		return ;
	}
	puts("-1");
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	
	p[0]=1;for (int i=1;i<=1e5;i++) p[i]=p[i-1]*base;
	int T;
	scanf("%d",&T);
	while (T--) work();
	return 0;
}

