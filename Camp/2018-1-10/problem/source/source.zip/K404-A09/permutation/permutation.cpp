#include<bits/stdc++.h>
using namespace std;
#define N 100010
const int mod=998244353;
int v[N],vis[N],len[N],v2[N];
int dfs(int po,int num) {
	int l=po,r=v[po],cnt=1,flag=0;
	vis[l]=vis[r]=1;
	while(l!=r) {
		if(v2[l]!=0) {
			l=v2[l];cnt++;vis[l]=1;continue;
		}
		if(v[r]!=0) {
			r=v[r];cnt++;vis[r]=1;continue;
		}
		flag=1;break;
	}
	if(flag) return cnt+N;
	return cnt;
}
void exgcd(int a,int b,long long &x,long long &y) {
	if(b==0) {
		x=1,y=0;
		return;
	}
	exgcd(b,a%b,y,x);
	y-=(long long)a/b*x;
}
int inv(int a) {
	long long x,y;
	exgcd(a,mod,x,y);
	return (x%mod+mod)%mod;
}
long long f[N];
void init(int n) {
	f[0]=1;f[2]=1;
	for(int i=4;i<=n;i++) {
		f[i]=f[i-2]*(i-1)%mod;
	}
}
int main() {
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int n,cnt=0,tn;
	scanf("%d",&n);
	init(n);
	if(n%2==1) {puts("0");return 0;}
	tn=n;
	for(int i=1;i<=n;i++) {scanf("%d",&v[i]);v2[v[i]]=i;};
	for(int i=1;i<=n;i++) {
		if(vis[i]||v[i]==0) continue;
		int tmp=dfs(i,1);
		if(tmp>=N) {
			tmp%=N;tn-=(tmp/2)*2;cnt+=(tmp%2);
		} else {
			if(tmp%2==1) {puts("0");return 0;}
			tn-=tmp;
		}
	}
	long long ans=1;
	int tmp3=tn-cnt*2+2;
	int tmp=cnt+(tn-cnt*2);
	for(int i=tmp3;i<=tmp;i++) ans=ans*i%mod;
	if(cnt==0) {
		printf("%d",f[tn]*f[tn]%mod);
		return 0;
	}
	long long tmp2=f[tmp3]*f[tmp3]%mod*inv(tmp3-1)%mod;
	ans=ans*tmp2%mod;
	printf("%d",(int)ans);
}
