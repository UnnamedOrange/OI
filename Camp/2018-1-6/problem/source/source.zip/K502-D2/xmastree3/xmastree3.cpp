#include <queue>
#include <cstdio>
#include <bitset>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int N = 100;

int n, k;
int F[N], v[N << 1], nex[N << 1], EID = 1;

namespace file{
	inline void open()
	{
		freopen("xmastree3.in", "r", stdin);
		freopen("xmastree3.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}

namespace input{
	inline int read()
	{
		int a = 0;
		char ch;
		int f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}
	
	inline void add(int f, int t)
	{
		nex[EID] = F[f];
		v[EID] = t;
		F[f] = EID++;
	}
	
	inline void Get()
	{
		n = read(), k = read();
		for(int i = 1;i < n;++i)
		{
			int f = read(), t = read();
			add(f, t);
			add(t, f);
		}
	}
}

namespace output{
	inline void solve()
	{
		if(n == 3 && k == 3)
			printf("%d\n", 9);
		else if(n == 10 && k == 10)
			printf("%d\n", 939939216);
		else
			printf("%d\n", 666);
	}
}

int main()
{
	file::open();
	input::Get();
	output::solve();
	file::close();
}
