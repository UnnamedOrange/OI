#include<cstdio>
#include<iostream>
#include<queue>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int main(){
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	int n,t,T,x,y,TT;
	scanf("%d%d%d",&t,&n,&T);
	TT=T;
	if(t==1) while(T--) scanf("%d%d",&x,&y),printf("%d\n",x);
	else while(TT--) scanf("%d%d",&x,&y),printf(x==y?"yes\n":"no\n");
	return 0;
}
