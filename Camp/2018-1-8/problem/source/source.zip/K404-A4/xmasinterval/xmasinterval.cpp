#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define ll long long
#define up(x,y) x=mmm((x)+(y))
#define hc(x,y) x=(!(y||x)?0:x*y%mod)
using namespace std;
const int maxn=500010;
const int maxl=1500010;
const int mod=1000000009;
int n,m,tim=0,l[maxl],r[maxl],z[maxl],key[maxl],len;
bool b[maxl];
int read()
{
	int x=0;char ch=getchar();
	for(;ch<'0'||ch>'9';ch=getchar());
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x;
}
struct edge
{
	int r;
	edge *next;
}*con[maxl];
void ins(int l,int r)
{
	edge *p=new edge;
	p->r=r;
	p->next=con[l];
	con[l]=p;
}
inline ll mmm(ll x)
{
	return x>=mod?x-mod:x;
}
struct tree
{
	ll sum,mul;
	tree *ls,*rs;
	tree(){sum=0;mul=1;ls=rs=NULL;}
	void update(){sum=mmm(ls->sum+rs->sum);}
	void cal(ll d){hc(sum,d);}
	void pushdown(){if(mul!=1) ls->cal(mul),rs->cal(mul),hc(ls->mul,mul),hc(rs->mul,mul),mul=1;}
	void build(int l,int r)
	{
		//tim++;
		if(l==r) return ;
		int mid=(l+r)>>1;
		(ls=new tree)->build(l,mid);
		(rs=new tree)->build(mid+1,r);
	}
	void add(int pl,ll d,int l,int r)
	{
		//tim++;
		if(l==r) {up(sum,d);return;}
		pushdown();
		int mid=(l+r)>>1;
		if(pl<=mid) ls->add(pl,d,l,mid);
		else rs->add(pl,d,mid+1,r);
		update();
	}
	void rmul(int lx,int rx,ll d,int l,int r)
	{
		//tim++;
		if(lx>rx) return ;
		if(l==lx&&r==rx) {cal(d);hc(mul,d);return;}
		pushdown();
		int mid=(l+r)>>1;
		if(rx<=mid) ls->rmul(lx,rx,d,l,mid);
		else if(lx>mid) rs->rmul(lx,rx,d,mid+1,r);
		else ls->rmul(lx,mid,d,l,mid),rs->rmul(mid+1,rx,d,mid+1,r); 
		//cout<<"rmul:"<<lx<<' '<<rx<<' '<<d<<' '<<l<<' '<<r<<' '<<sum<<endl;
		update();
	}
	ll qsum(int lx,int rx,int l,int r)
	{
		//tim++;
		if(l==lx&&r==rx) return sum;
		pushdown();
		int mid=(l+r)>>1;
		if(rx<=mid) return ls->qsum(lx,rx,l,mid);
		else if(lx>mid) return rs->qsum(lx,rx,mid+1,r);
		else return mmm(ls->qsum(lx,mid,l,mid)+rs->qsum(mid+1,rx,mid+1,r));
	}
}*xtr;
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
		l[i]=read(),r[i]=read();
	for(int i=1;i<=m;i++)
		key[i]=read(),z[i]=key[i];
	sort(z+1,z+m+1);
	len=unique(z+1,z+m+1)-z-1;
//	for(int i=1;i<=top;i++)
//		cout<<z[i]<<' ';
//	cout<<endl;	
//	for(int i=1;i<=n;i++)
//		l[i]=lower_bound(z+1,z+top+1,l[i])-z,r[i]=lower_bound(z+1,z+top+1,r[i])-z,ins(l[i],r[i]);
	int mxkey=0;
	for(int i=1;i<=m;i++)
		key[i]=lower_bound(z+1,z+len+1,key[i])-z,b[key[i]]=1,mxkey=max(mxkey,key[i]);
	for(int i=1;i<=n;i++)
		l[i]=lower_bound(z+1,z+len+1,l[i])-z,r[i]=upper_bound(z+1,z+len+1,r[i])-z-1,ins(l[i],r[i]);	
	(xtr=new tree)->build(0,len);	
	xtr->add(0,1,0,len);
//	for(int i=1;i<=n;i++)
//		cout<<l[i]<<' '<<r[i]<<endl;
//	for(int i=1;i<=len;i++) cout<<b[i]<<' ';
//	cout<<endl;	
//	cout<<len<<endl;
	for(int i=1;i<=len;i++)
	{
		for(edge *p=con[i];p;p=p->next)
		{
			xtr->add(p->r,xtr->qsum(0,p->r,0,len),0,len);
			xtr->rmul(p->r+1,len,2ll,0,len);
		}
		if(b[i]) xtr->rmul(0,i-1,0,0,len);
	}
//	cout<<tim<<endl;
	printf("%lld",xtr->qsum(mxkey,len,0,len));
	return 0;
}
/*4 4
3 8
1 6
3 8
2 7
8 
4 
6 
3*/
