#include<cstdio>
#include<iostream>
#include<cstring>
#define NN 4000+20
#define nnn 510
using namespace std;
int str1[NN]={0};
int str2[NN]={0};
int n,m,k;
int dp[nnn][nnn]={0};
int xt1[NN][NN]={0};
int xt2[NN][NN]={0};
int dp_solve(){
	memset(dp,1,sizeof dp);
	dp[0][0]=0;
	for(int i=0;i<=n+1;++i){
		for(int j=0;j<=m+1;++j){
			if(dp[i][j]<=nnn){
				for(int c=1;c<=k;++c){
					dp[xt1[i][c]][xt2[j][c]]=min(dp[xt1[i][c]][xt2[j][c]],dp[i][j]+1);
				}
			}
		}
	}
	return dp[n+1][m+1];
}
int greedy(){
	int pos1=0;
	int pos2=0;
	int ans=0;
	int big=0,col=0,tp;
	while(pos1!=n+1||pos2!=m+1){
		big=0;
		for(int i=1;i<=k;++i){
			tp=xt2[pos2][i]+xt1[pos1][i]-pos2-pos1;
			if(big<tp){
				big=tp;
				col=i;
			}
		}
		pos1=xt1[pos1][col];
		pos2=xt2[pos2][col];
		++ans;
	}
	return ans;
}
void initi(){
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;++i){
		scanf("%d",&str1[i]);
	}
	for(int i=1;i<=m;++i){
		scanf("%d",&str2[i]);
	}
	for(int i=1;i<=k;++i){
		xt1[n+1][i]=n+1;
		xt2[m+1][i]=m+1;
	}
	for(int i=n;i>=0;--i){
		for(int j=1;j<=k;++j){
			xt1[i][j]=xt1[i+1][j];
			if(str1[i+1]==j)xt1[i][j]=i+1;
		}
	}
	for(int i=m;i>=0;--i){
		for(int j=1;j<=k;++j){
			xt2[i][j]=xt2[i+1][j];
			if(str2[i+1]==j)xt2[i][j]=i+1;
		}
	}
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	initi();
	if(n<=500&&m<=500&&k<=500){
		cout<<dp_solve();
	}
	else
		cout<<greedy();
}
