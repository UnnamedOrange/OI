#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;
struct lxy{
	int l,r,vis;
}q[50];
int n,m;
int poi[50];
bool vis[50];
int ans;

void dfs(int k)
{
	for(int i=1;i<=n;i++)
	  cout<<q[i].vis;
	cout<<endl;
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;i++)
	  if(q[i].vis==1)
	    for(int j=1;j<=m;j++)
	      if(poi[j]>=q[i].l&&poi[j]<=q[i].r)
	    	vis[j]=1;
	int p;
	for(p=1;p<=m;p++)
	  if(vis[p]==0)
	    break;
	if(p>m)ans++;
	for(int i=k;i<=n;i++)
	{
		q[i].vis=1;
		dfs(i+1);
		q[i].vis=0;
	}
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	  scanf("%d%d",&q[i].l,&q[i].r);
	for(int i=1;i<=m;i++)
	  scanf("%d",&poi[i]);
	dfs(1);
	printf("%d",ans);
}
