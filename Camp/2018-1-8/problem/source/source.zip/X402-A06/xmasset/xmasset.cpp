#include<bits/stdc++.h>

#define ll long long
#define inf 999999999
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

int encode(int x, int y){
    return x;
}

bool decode(int q, int h){
    return q == h;
}

void solve_bf()
{
	int type, N, T;
    scanf("%d%d%d", &type, &N, &T);
    while (T--) {
        int x, y;
		x = read(), y = read();
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}

int main(){

	freopen("xmasset.in", "r", stdin);
	freopen("xmasset.out", "w", stdout);

	solve_bf(); 

	return 0;
}
