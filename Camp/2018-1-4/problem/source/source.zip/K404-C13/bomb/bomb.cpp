#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<queue>
#include<vector>
using namespace std;

const int N=1000005;
const int M=25;
const int S=5005;

struct E{
	int to,next;
}mem[N];
int n,num,x,y,m,ans,sz,flag,inf,cnt,sig,t;
int dp[N],vis[N],head[N],d[N],f[M][M],a[M],sum[N],st[N],c[N],dfn[N],low[N];
bool tag[S];
vector<int> lev[N];
queue<int> q;

void add(int x,int y){
	num++;
	mem[num].to=y; mem[num].next=head[x];
	head[x]=num;
}

void solve(){
	int k,u,j,i;
	for (i=1;i<=cnt;i++)
		if (!d[i]) q.push(i),dp[i]=sum[i];
	while (!q.empty()){
		k=q.front(); q.pop();
		for (j=0;j<lev[k].size();j++){
			u=lev[k][j]; d[u]--;
			dp[u]=max(dp[u],dp[k]+sum[u]);
			if (!d[u]) q.push(u);
		}
	}
}

void init(){
	int i,j,k;
	for (k=1;k<=n;k++)
		for (i=1;i<=n;i++)
			for (j=1;j<=n;j++) f[i][j]|=f[i][k]&f[k][j];
}

void dfs(int k,int &sig,int &cnt){
	int j,u;
	st[++t]=k; vis[k]=1;
	dfn[k]=low[k]=++sig;
	for (j=head[k];j;j=mem[j].next){
		u=mem[j].to;
		if (!vis[u]){
			dfs(u,sig,cnt);
			low[k]=min(low[k],low[u]);
		}
		else if (vis[u]==1) low[k]=min(low[k],dfn[u]);
	}
	if (low[k]==dfn[k]){
		int tmp=0; cnt++;
		while (tmp!=k){
			tmp=st[t--];
			vis[tmp]=2;
			c[tmp]=cnt;
			sum[cnt]++;
		}
	}
}

void tarjan(){
	int i;
	for (i=1;i<=n;i++)
		if (!vis[i]) dfs(i,sig,cnt);
}

void build(){
	int i,j,u;
	for (i=1;i<=n;i++){
		for (j=head[i];j;j=mem[j].next){
			u=mem[j].to;
			if (c[i]!=c[u]){
				lev[c[i]].push_back(c[u]);
				d[c[u]]++;
			}
		}
	}
}

int read(){
	int num=0; char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		num=num*10+c-'0';
		c=getchar();
	}
	return num;
}

int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int i,j,s,ss,k;
	n=read(); m=read();
	if (n<=10){
		for (i=1;i<=m;i++){
			scanf("%d%d",&x,&y);
			f[x][y]=1;
		}
		init(); sz=(1<<n)-1;
		for (s=0;s<(1<<n);s++){
			cnt=0; flag=1;
			for (i=1;i<=n;i++)
				if ((s>>i-1)&1) a[++cnt]=i;
			for (i=1;i<=cnt;i++)
				for (j=i+1;j<=cnt;j++)
					if (f[a[i]][a[j]]||f[a[j]][a[i]]) flag=0;
			if (flag) tag[s]=1;
		}
		memset(dp,0x3f,sizeof(dp));
		inf=dp[0]; dp[0]=0;
		for (s=0;s<(1<<n);s++){
			if (dp[s]==inf) continue;
			k=sz^s;
			for (ss=k;ss;ss=(ss-1)&k)
				if (tag[ss]) dp[s|ss]=min(dp[s|ss],dp[s]+1);
		}
		printf("%d\n",dp[sz]);
		return 0;
	}
	for (i=1;i<=m;i++){
		x=read(); y=read();
		add(x,y);
	}
	tarjan();
	build();
	solve();
	for (i=1;i<=cnt;i++) ans=max(ans,dp[i]);
	printf("%d\n",ans);
	return 0;
}
