//2018-1-13
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100+5)

const int P = 1e9 + 7;
inline int Mod(int a){
	return a >= P? a-P: a;
}

int f[N][N];

int main(){
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);

	int s, t, n, m;
	scanf("%d%d%d%d", &s, &t, &n, &m);

	f[0][0] = 1;
	For(i, 0, m-1) For(j, i, s) if(f[i][j]){
		if(i+1 <= n){
			For(k, 1, min(t, s-j)) f[i+1][j+k] = Mod(f[i+1][j+k]+f[i][j]);
		}else{
			For(k, 1, s-j) f[i+1][j+k] = Mod(f[i+1][j+k]+f[i][j]);
		}
	}

	int ans = 0;
	For(j, 0, s) ans = Mod(ans + f[m][j]);
	printf("%d\n", ans);

	return 0;
}
