#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N = 1e5 + 10;
const int Mod = 1e9 + 7;

LL Pow(LL x, LL e){
	LL ret = 1;
	if(e < 0) return 0;
	while(e){
		if(e & 1) ret = ret * x % Mod;
		x = x * x % Mod;
		e >>= 1;
	}
	return ret;
}

int A[N], a, b, n;

int fst1, fst2, bwin, draw;

int main(){
	
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);

	bool swaped = false;
	scanf("%d%d%d", &n, &a, &b);
	if(a < b) swap(a, b), swaped = true;

	For(i, 1, n){
		scanf("%d", &A[i]);
		A[i] %= a + b;
		if(A[i] < b) ++draw;
		if(A[i] >= b && A[i] < a) ++bwin;
		if(A[i] >= a){
			if(A[i] >= 2 * b) fst2++;
			else fst1++;
		}
	}

	LL ansa = 0, ansb = 0, fst = 0, snd = 0;
	ansb = (Pow(2, bwin) - 1 + Mod) * Pow(2, fst1 + fst2) % Mod;

	if(fst2 >= 2)
		(ansb += (Pow(2, fst2) - fst2 - 1 + Mod) * Pow(2, fst1)) %= Mod;

	if(fst2){
		fst = fst2 * (fst1 ? Pow(2, fst1 - 1) : 1) % Mod;
		(ansb += fst2 * (fst1 ? Pow(2, fst1 - 1) : 0)) %= Mod;
	}

	(fst += fst1 ? Pow(2, fst1 - 1) : 0) %= Mod;
	snd = fst1 ? Pow(2, fst1 - 1) : 1;

	LL coe = Pow(2, draw);
	(ansa *= coe) %= Mod, (ansb *= coe) %= Mod, (fst *= coe) %= Mod, (snd *= coe) %= Mod;

	assert((ansa + ansb + fst + snd) % Mod == Pow(2, n));
	
	if(swaped) swap(ansa, ansb);
	printf("%lld %lld %lld %lld\n", ansa, ansb, fst, snd);

	return 0;
}
