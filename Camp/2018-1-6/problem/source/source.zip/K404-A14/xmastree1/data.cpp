#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<cstdlib>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;

int ran(int x){
	int i,ret=0;
	rep(i,1,3)	ret=(1ll*ret*20010102+rand())%x;
	return ret;
}

int main(){
	srand(time(0));
	freopen("xmastree1.in","w",stdout);
	int n,Q,i,x,y,l,r,opt;
	n=1000;Q=1000;
	printf("%d %d 0\n",n,Q);
	rep(i,1,n){
		x=ran(n)+1;printf("%d ",x);
	}
	printf("\n");
	rep(i,2,n){
		x=ran(i-1)+1;
		printf("%d %d\n",x,i);
	}
	rep(i,1,Q){
		opt=ran(2)+1;
		if(opt==1){
			x=ran(n)+1;
			l=ran(n)+1;r=ran(n)+1;
			if(l>r)	swap(l,r);
			printf("%d %d %d %d\n",opt,x,l,r);
		}
		else{
			x=ran(n)+1;y=ran(n)+1;
			printf("%d %d %d\n",opt,x,y);
		}
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
