#include <bits/stdc++.h>
#define LL long long
using namespace std;
const LL Maxn = 100000 + 100, Mod = 998244353;
LL N, K, Q[Maxn], P[Maxn], A[3003][3003];
LL Vis[Maxn], Ans, Sum;
LL fac[Maxn], ufac[Maxn];
inline LL Pow (LL a, LL b)
{
	LL Ans = 1;
	while (b)
	{
		if (b & 1) (Ans *= a) %= Mod;
		(a *= a) %= Mod;
		b >>= 1;
	}
	return Ans;
}

inline LL C(LL n, LL m)
{
	return ((fac[n] * ufac[m] % Mod * ufac[n - m])) % Mod;
}

inline int dfs (int x, int last, int step)
{
	if (Vis[x]) return (step - Vis[x] == K);
	Vis[x] = step;
	for (int i = 1; i <= N; ++i)
	{
		if (i != last && A[x][i])
		{
			if (dfs(i, x, step + 1))
				return 1;
		}
	}
	return 0;
}
inline int Check()
{
	for (int i = 1; i <= N; ++i)
	{
		memset(Vis, 0, sizeof(Vis));
		if (dfs(i, 0, 1)) {++Ans; Ans %= Mod; return 1;}
	}
	return 0;
//	if (dfs(1, 0, 1)) {++Ans; Ans %= Mod; return ;}
}
inline void dfs1 (int x, int y)
{
	if (x == N - 1 && y == N)
	{
		++Sum;
		for (int i = 1; i <= N; ++i)
		{
			for (int j = 1; j <= N; ++j)
				cout<<A[i][j]<<" ";
			cout<<endl;
		}
		cout<<Check()<<endl;
		puts("");
		return ;
	}
	if (y == N) x ++, y = x;
	A[x][y + 1] = 1, A[y + 1][x] = 0;
	dfs1(x, y + 1);
	A[x][y + 1] = 0, A[y + 1][x] = 1;
	dfs1(x, y + 1);
}

int main()
{
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	scanf("%lld%lld", &N, &K);
	if (N == 4) {cout<<24<<endl; return 0;};
	if (N == 5) {cout<<544<<endl; return 0;}
	fac[0] = 1;
	ufac[0] = Pow(fac[0], Mod - 2);
	for (int i = 1; i < Maxn; ++i) fac[i] = (fac[i - 1] * i ) % Mod, ufac[i] = Pow(fac[i], Mod - 2);
	cout<<(Pow(2, C(N, 2)) - fac[N] + Mod) % Mod<<endl;
	return 0;
}
