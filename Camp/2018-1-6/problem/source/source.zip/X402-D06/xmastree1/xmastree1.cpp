#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=5e3+10;
int a[maxn],id[maxn],dfn[maxn],size[maxn],to[maxn<<1],nex[maxn<<1],beg[maxn],vis[maxn];
int e,dfs_time;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
void dfs(int x,int fa){
	int i;
	dfn[x]=++dfs_time;
	id[dfs_time]=x;
	size[x]=1;
	for(i=beg[x];i;i=nex[i]){
		if(to[i]==fa)continue;
		dfs(to[i],x);
		size[x]+=size[to[i]];
	}
}
int main(){
	int i,j,k,m,n,t;
#ifndef ONLINE_JUDGE
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
#endif
	n=read();m=read();t=read();
	for(i=1;i<=n;i++)a[i]=read();
	for(i=1;i<n;i++){
		int x,y;
		x=read();y=read();
		add(x,y);add(y,x);
	}
	dfs(1,0);
	int lans=0;
	for(i=1;i<=m;i++){
		int opt=read();
		if(opt==1){
			int x,y,z;
			x=read();y=read();z=read();
			if(t)x^=lans,y^=lans,z^=lans;
			memset(vis,0,sizeof(vis));
			for(j=dfn[x];j<=dfn[x]+size[x]-1;j++)
				vis[a[j]]=1;
			lans=0;
			for(j=y;j<=z;j++)if(vis[j])lans++;
			printf("%d\n",lans);
		}
		else{
			int x,val;
			x=read();val=read();
			if(t)x^=lans,val^=lans;
			a[dfn[x]]=val;
		}
	}
	return 0;
}

