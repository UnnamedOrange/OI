#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, w[maxn], ls[maxn];

void Get(){
	n = read();
	For(i, 1, n) w[i] = read();
}

void solve_bf(){
	double Ans = 0.;
	For(i, 1, n){
		For(j, i, n){
			int cnt = 0;
			For(k, i, j){
				ls[++cnt] = w[k];
			}

			double nowans = 0.;
			sort(ls+1, ls+cnt+1);
			For(i, 1, cnt){
				nowans = (nowans + 1.0 * ls[i]) * 0.5;
			}

			Ans += nowans;
		}
	}
	
	printf("%.10f\n", Ans / (1.0 * n * n));
}

int main(){
	
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	
	Get();
	solve_bf();

	return 0;
}
