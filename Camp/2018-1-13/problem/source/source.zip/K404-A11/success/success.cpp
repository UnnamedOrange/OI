#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int ans;
int a[105];
int n,t,m,s;

void dfs(int wei,int g)
{
	ans++;
	if(g==s)return;
	for(int i=wei;i<=m;i++)
	  if((a[i]<t&&i<=n)||i>n)
	  {
	  	a[i]++;
	  	dfs(i,g+1);
	  	a[i]--;
	  }
}

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	memset(a,0,sizeof(a));
	ans=0;
    for(int i=1;i<=m;i++) a[i]=1;
    dfs(1,m);
    printf("%d",ans);
}
