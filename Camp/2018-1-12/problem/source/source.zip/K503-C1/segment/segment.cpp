# include <bits/stdc++.h>
# define 	ll 		long long
# define 	Nbl 	41
# define 	N 		100010
# define 	P 		998244353
using namespace std;
ll num[Nbl],ans_pow[N],n,tag[Nbl],ans,m,k,f[110][110][110],s[110][110][110];
ll mypow(ll x, ll y){
	ll i=x; x=1;
	while (y>0){
		if (y%2==1) x=x*i%P;
		i=i*i%P;
		y/=2;
	}
	return x;
}
void check(){
	memset(num,0,sizeof(num));
	for (ll i=1; i<=n; i++)
		num[i]=num[i-1]+tag[i];
	for (ll i=1; i<=n; i++)
		ans=(ans+ans_pow[num[i]])%P;
}
void dfs(ll k, ll l, ll r){
	if (k>m){
		check();
		return;
	}
	else {
		for (ll i=l; i<=n; i++)
			for (ll j=max(r,i); j<=n; j++){
				tag[i]++; tag[j]--;
				dfs(k+1,i+1,j+1);
				tag[i]--; tag[j]++;
			}
	}
}
ll getnum(ll t, ll i, ll j){
	ll num=f[t][i][j];
	if (i>0) num=num+s[t][i-1][j];
	if (j>0) num=num+s[t][i][j-1];
	if (i>0&&j>0) num=num-s[t][i-1][j-1];
	return (num+P)%P;
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%lld%lld%lld",&m,&n,&k);// m=caozuoshu n=length
	if (m>=n){
		printf("0\n");
		return 0;
	}
	for (ll i=1; i<=m; i++)
		ans_pow[i]=mypow(i,k);
	if (m==1){
		ll num=0;
		for (ll i=1; i<=n; i++){
			num=n-i+1;
			ans=(ans+ans_pow[1]*num%P*(i-1))%P;
		}
		printf("%lld\n",ans);
		return 0;
		ans=0;
	}
	if (k==1||k==998244352){
		for (int i=0; i<=n; i++)
			for (int j=0; j<=n; j++)
				s[0][i][j]=1;
		for (int t=1; t<=m; t++){
			for (int i=1; i<=n; i++)
				for (int j=i; j<=n; j++)
					f[t][i][j]=s[t-1][i-1][j-1];
			for (int i=0; i<=n; i++)
				for (int j=0; j<=n; j++)
					s[t][i][j]=getnum(t,i,j);
			}
		for (int i=1; i<=n; i++)
			for (int j=1; j<=m; j++)
				for (int l=1; l<=i; l++)
					for (int r=i+1; r<=n; r++)
						ans=(ans+s[j-1][l-1][r-1]*s[m-j][n-r][n-l])%P;
		printf("%lld\n",ans);
		return 0;
		ans=0;
	}
	dfs(1,1,1);
	printf("%lld\n",ans);
	return 0;
}

