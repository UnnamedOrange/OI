#include<bits/stdc++.h>
#define FE "xmasinterval"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		c=='-'?p=-1:0;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
inline void putint(int x){
	x<0?putchar('-'),x=-x:0;
	static int buf[20];
	int tot=0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
int n,m;
int a[1000005];
struct interval{
	int l,r;
}b[1000005];
bool c[35];
int ans=0;
inline void serch(int cur){
	if(cur>n){
		for(int i=1;i<=m;++i){
			if(!c[a[i]])return;
		}
		++ans;
		return;
	}
	serch(cur+1);
	bool t[35];
	memcpy(t,c,sizeof(c));
	for(int i=b[cur].l;i<=b[cur].r;++i){
		c[i]=1;
	}
	serch(cur+1);
	memcpy(c,t,sizeof(c));
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE"2.out","w",stdout);
	n=getint(),m=getint();
	for(int i=1;i<=n;++i){
		b[i].l=getint(),b[i].r=getint();
	}
	for(int i=1;i<=m;++i){
		a[i]=getint();
	}
	serch(1);
	cout<<ans<<endl;
	return 0;
}
