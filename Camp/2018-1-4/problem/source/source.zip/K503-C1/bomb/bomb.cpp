# include <bits/stdc++.h>
# define 	N 		1000100
using namespace std;
struct node{
	int data,next;
}e[N*2];
int n,m,ti,low[N],dfn[N],st[N],mp[N],en[N],place,head[N],use[N],top,num,size[N],q[N],now[N],ans,u[N],v[N],headpre[N];
int read(){
	int tmp=0, fh=1; char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') fh=-1; ch=getchar();}
	while (ch>='0'&&ch<='9'){tmp=tmp*10+ch-'0'; ch=getchar();}
	return tmp*fh;
}
void build(int u, int v){
	e[++place].data=v; e[place].next=head[u]; head[u]=place; 
}
void buildpre(int u, int v){
	e[++place].data=u; e[place].next=headpre[v]; headpre[v]=place; en[u]++;
}
void tarjan(int x){
	use[x]=1; st[++top]=x; low[x]=dfn[x]=++ti;
	for (int ed=head[x]; ed!=0; ed=e[ed].next){
		if (use[e[ed].data]==1)	low[x]=min(low[x],dfn[e[ed].data]);
		if (use[e[ed].data]==0){
			tarjan(e[ed].data);
			low[x]=min(low[e[ed].data],low[x]);
		}
	}
	if (low[x]==dfn[x]){
		num++;
		while (st[top]!=x)
			use[st[top]]=2, mp[st[top--]]=num, size[num]++;
		use[st[top]]=2, mp[st[top--]]=num; size[num]++;
	}
}
void tuopu(){
	int pl=1, pr=0;
	for (int i=1; i<=num; i++){
		if (en[i]==0) q[++pr]=i;
	}	
	while (pl<=pr){
		int x=q[pl++]; 
		for (int ed=head[x]; ed!=0; ed=e[ed].next)
			now[x]=max(now[e[ed].data],now[x]);
		for (int ed=headpre[x]; ed!=0; ed=e[ed].next){
			en[e[ed].data]--;
			if (en[e[ed].data]==0) q[++pr]=e[ed].data;
		}
		now[x]+=size[x];
		if (now[x]>ans) ans=now[x];
	}
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read(); m=read();
	for (int i=1; i<=m; i++){
		u[i]=read(), v[i]=read();
		build(u[i],v[i]);
	}
	for (int i=1; i<=n; i++)
		if (use[i]==false) tarjan(i);
	memset(head,0,sizeof(head)); place=0;
	memset(en,0,sizeof(en));
	for (int i=1; i<=m; i++)
		if (mp[u[i]]!=mp[v[i]]){
			build(mp[u[i]],mp[v[i]]);
			buildpre(mp[u[i]],mp[v[i]]);
		}
	tuopu();
	printf("%d\n",ans);
	return 0;
}

