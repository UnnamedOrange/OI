#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
const long long Mod=1000000007;
int t,n,m;
long long s,f[2][1000010],sum[1000010],fac[1000010],inv[1000010];
long long pw(long long x,long long y)
{
	long long res=1;
	while (y)
	{
		if (y&1)
		{
			res=res*x%Mod;
		}
		y>>=1;
		x=x*x%Mod;
	}
	return res;
}
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%lld%d%d%d",&s,&t,&n,&m);
	int p=0;
	for (int i=1;i<=t;i++)
	{
		f[p][i]=1;
	}
	for (int i=2;i<=n;i++)
	{
		p^=1;
		memset(sum,0,sizeof(sum));
		memset(f[p],0,sizeof(f[p]));
		sum[0]=0;
		for (int j=1;j<=s;j++)
		{
			sum[j]=(sum[j-1]+f[p^1][j])%Mod;
		}
		for (int j=i;j<=n*t;j++)
		{
			f[p][j]=(sum[j-1]-sum[max(0,j-t-1)]+Mod)%Mod;
		}
		/*
		for (int j=1;j<=s;j++)
		{
			cout<<f[p][j]<<" ";
		}
		cout<<endl;
		*/
	}
	for (int j=1;j<=s;j++)
	{
		sum[j]=(sum[j-1]+f[p][j])%Mod;
		//cout<<sum[j]<<" ";
	}
	//cout<<endl;
	fac[0]=1;
	for (int i=1;i<=s;i++)
	{
		fac[i]=fac[i-1]*i%Mod;
	}
	inv[s]=pw(fac[s],Mod-2);
	for (int i=s-1;i>=0;i--)
	{
		inv[i]=inv[i+1]*(i+1)%Mod;
	}
	int a=m-n-1;
	if (a<0)
	{
		printf("%lld\n",sum[s]);
		return 0;
	}
	long long ans=0;
	for (int i=s-a-1;i>=n;i--)
	{
		long long b=s-i-1;
		ans=(ans+fac[b]*inv[b-a]%Mod*inv[a]%Mod*sum[i]%Mod)%Mod;
		//cout<<fac[b]<<" "<<inv[b-a]<<" "<<inv[a]<<endl;
	}
	printf("%lld\n",ans);
	return 0;
}
