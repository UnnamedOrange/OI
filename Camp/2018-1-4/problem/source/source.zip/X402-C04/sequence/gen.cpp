#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=5000;

int n;
int a[N];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("sequence.in","w",stdout);

	puts("1");
	n=25;	
	for(int i=1;i<=n;i++)
		a[i]=i;
	random_shuffle(a+1,a+n+1);

	printf("%d\n",n);
	for(int i=1;i<=n;i++)
		printf("%d ",a[i]);

	return 0;
}
