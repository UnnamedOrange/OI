#include<cstdio>
#include<queue>
#include<algorithm>
#define pa pair<int,int>
#define mp(x,y) make_pair(x,y)
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
using namespace std;
typedef long long ll;
ll ans;
const int maxn=100011;
struct edge{
	int to;
	edge *nxt;
}e[maxn],*las[maxn],*et=e;
int n,x,y;
inline void add(int x,int y){
	*++et=(edge){y,las[x]};las[x]=et;
}
priority_queue<pa>heap;
int v[maxn],can[maxn],num[maxn],pos[maxn],fa[maxn];
bool vis[maxn];
ll b[maxn];
inline ll get(int rt){
	ll ret=0;
	heap.push(mp(-v[rt],rt));
	for(register int i=1;i<=n;++i)
		vis[i]=0;
	vis[rt]=1;
	register int now,times=0;
	while(!heap.empty()){
		ret=1ll*ret+1ll*(++times)*(-heap.top().first);
		now=heap.top().second;heap.pop();
		printf("%d ",now);
		for(register edge *it=las[now];it;it=it->nxt)
			if(!vis[it->to]){
				vis[it->to]=1;
				heap.push(mp(-v[it->to],it->to));
			}
	}
	return ret;
}
inline void dfs(int now){
	for(register edge *it=las[now];it;it=it->nxt)
			if(!fa[it->to]){
				fa[it->to]=now;
				dfs(it->to);
			}
}
inline void _dfs(int x,ll sum){
	if(sum+b[x]<=ans)
		return;
	if(x==n+1){
		ans=max(ans,sum);
		return;
	}
	for(register int i=1;i<=n;++i)
		if(!vis[i]&&pos[fa[i]]<x){
			vis[i]=1;
			num[x]=i;
			pos[i]=x;
			_dfs(x+1,sum+1ll*x*v[i]);
			pos[i]=n+1;
			vis[i]=0;
		}
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	for(register int i=2;i<=n;++i){
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	for(register int i=1;i<=n;++i)scanf("%d%d",v+i,can+i),b[i]=v[i];
	sort(b+1,b+n+1);for(register int i=n;i;--i)b[i]=b[i+1]+1ll*b[i]*i;
	if(n>1000){
		for(register int i=1;i<=n;++i)if(can[i])ans=max(ans,get(i));
		printf("%lld\n",ans);
		return 0;
	}
	for(register int i=1;i<=n;++i)
		if(can[i]){
			for(register int j=1;j<=n;++j)fa[j]=0;
			fa[i]=i;dfs(i);_dfs(1,0);
		}
	printf("%lld\n",ans);
	return 0;
}
