//© 2018 Jazengm/ZengXiangru, AllRightsReserved
#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int mxn=1<<18, p=998244353;

struct edge
{
    int v, o;
    In edge(int v=0, int o=0):
    v(v), o(o) {}
} e[mxn];

int head[mxn];

In void aE(int u, int v)
{St int tot=1; e[++tot]=edge(v, u[head]), u[head]=tot;}

#define fev for(Rg int i_=u[head], v; v=i_[e].v, i_>0; i_=i_[e].o)

In void upd(int& x, ll y){x=((ll)x+y)%p;}

#define DFT_(a, b) (memcpy(a, b, sizeof a), DFT(a))

In int dP(int a, int b)
{
    Rg int r=1;
    for(; b; a=(ll)a*a%p, b>>=1)
        b&1? r=(ll)r*a%p: 0;
    Re r;
}

int ome[1<<10], tot;

In void setOme(int ome1)
{
    inc(ome[0]=1, i, tot)
        ome[i]=(ll)ome[i-1]*ome1%p;
}

In void DFT(int* x)
{
    St int a1[1<<10], a2[1<<10];
    Rg int *f=a1, *g=a2;
    inc(0, i, tot) f[i]=x[i];
    for(Rg int k=1; k<tot; k<<=1, swap(f, g))
        for(Rg int i=0; i<tot>>1; i+=k)
        {
            Rg int *g1=g+(i<<1), *g2=g+(i<<1|k), *f1=f+i, *f2=f+(tot>>1|i);
//            Rg ll ome0=ome[tot/];
            inc(0, j, k)
                g1[j]=((ll)f1[j]+(ll)ome[tot/k/2*j]*f2[j])%p,
                g2[j]=((ll)f1[j]-(ll)ome[tot/k/2*j]*f2[j])%p;
        }
    inc(0, i, tot) x[i]=f[i];
}

int main()
{
    freopen("xmasdag.in", "r", stdin);
    freopen("xmasdag.out", "w", stdout);
    St int n, m, k;
    scanf("%d%d%d", &n, &m, &k);
    for(tot=1; tot<k+1<<1; tot<<=1);
    inc(0, i, m)
    {
        St int u, v;
        scanf("%d%d", &u, &v), aE(u, v);
    }
    getFrac:
    St int inv[mxn], frac[mxn], invF[mxn];
    inv[1]=1;
    inc(2, i, mxn)
        inv[i]=(ll)inv[p%i]*(p-p/i)%p;
    inc(frac[0]=invF[0]=1, i, mxn)
        frac[i]=(ll)frac[i-1]*i%p, invF[i]=(ll)invF[i-1]*inv[i]%p;
    St int b[1<<10];
    setOme(dP(3, (p-1)/tot));
    inc(0, i, tot>>1)
        b[i]=invF[i];
    DFT(b);
    getOrder:
    St int deg[mxn];
    inc(1, u, n+1)
        fev
            ++deg[v];
    St int q[mxn];
    Rg int t=0;
    inc(1, u, n+1)
        if(!deg[u])
            q[t++]=u;
    St int f[mxn][1<<10];
    inc(0, h, t)
    {
        Rg int u=q[h];
        if(u==1)
                f[1][0]=1;
        fev
        {
        //with NTT
            St int a[1<<10];
            DFT_(a, f[u]);
            setOme(ome[tot-1]);
            inc(0, i, tot)
                a[i]=(ll)a[i]*b[i]%p;
            DFT(a);
            setOme(ome[tot-1]);
            inc(0, i, k+1)
                upd(f[v][i], (ll)a[i]*inv[tot]%p);
            if(!--deg[v])
                q[t++]=v;
        }
    }
    inc(1, i, n+1)
        printf("%lld\n", ((ll)f[i][k]*frac[k]%p+p)%p);
    Re 0;
}
