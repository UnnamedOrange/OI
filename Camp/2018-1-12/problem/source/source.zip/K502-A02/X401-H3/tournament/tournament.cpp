#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=998244353;

ll read(){
    ll f=1,ret=0;
    char ch=getchar();
    while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
    while(ch<='9'&&ch>='0'){ret=ret*10+ch-'0';ch=getchar();}
    return f*ret;
}

ll n,k,ans,a[10][10];

bool vst[10],flag;

void dfs(int x,int dep,int s){
	if(flag)return ;
	if(dep==k){if(a[x][s])flag=1;return;}
	vst[x]=1;
	for(int i=1;i<=n;i++){
		if(a[x][i]&&!vst[i]){
			dfs(i,dep+1,s);
		}
	}
	vst[x]=0;
}

void dfs1(int x,int y){
	if(x==n){
		flag=0;
		for(int i=1;i<=n;i++){
			memset(vst,0,sizeof(vst));
			dfs(i,1,i);
		}
		ans+=flag;
		return ;
	}
	a[x][y]=1;a[y][x]=0;
	if(y<n)dfs1(x,y+1);else dfs1(x+1,x+2);
	a[x][y]=0;a[y][x]=1;
	if(y<n)dfs1(x,y+1);else dfs1(x+1,x+2);
	a[x][y]=a[y][x]=0;
}

int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	n=read();k=read();
	dfs1(1,2);
	cout<<ans;
	return 0;
}

