#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>

#define REP(i, t) for(int i = 0, i##E = (t); i < i##E; ++i)
typedef long long LL;

template <class T> inline bool minimum(T &a, T b) {return a > b? a = b, 1 : 0;}
template <class T> inline bool maximum(T &a, T b) {return a < b? a = b, 1 : 0;}

const int N = 1e5 + 10, mod = 1e9 + 7;

int fac[N], ifac[N];

int fpm(int x, int y)
{
	int ret = 1;
	for(; y; y >>= 1, x = 1LL*x*x%mod)
		if(y & 1) ret = 1LL*ret*x%mod;
	return ret;
}

void fac_init(int n)
{
	for(int i = 0; i <= n; ++i) fac[i] = i? 1LL*fac[i-1]*i%mod : 1;
	ifac[n] = fpm(fac[n], mod - 2);
	for(int i = n; i >= 1; --i) ifac[i-1] = 1LL*ifac[i]*i%mod;
}

int C(int n, int m)
{
	if(n < m) return 0;
	return 1LL*fac[n]*ifac[n-m]%mod*ifac[m]%mod;
}

int n, a, b, x[N];

namespace sol_10
{
	int c0, c1;

	void main()
	{
		fac_init(n);
		for(int i = 1; i <= n; ++i)
			if(x[i] % (a<<1) >= a) ++c1; else ++c0;

		int ans = 0;
		for(int i = 1; i <= n; i += 2)
			ans = (ans + C(c1, i)) % mod;
		ans = ans * fpm(2, c0) % mod;
		printf("0 0 %d %d\n", ans, ((fpm(2, n) - ans) % mod + mod) % mod);
	}
}

namespace brute_force
{
	int y[N], tot;
	int FIRST, SECOND, Alice, Bob;

	bool dfs(bool cur)
	{
		int step = cur? a : b;
		for(int i = 1; i <= tot; ++i){
			if(y[i] >= step){
				y[i] -= step;
				if(!dfs(cur ^ 1)) return y[i] += step, true;
				y[i] += step;
			}
		}
		return false;
	}

	void main()
	{
		REP(s, 1<<n){
			tot = 0;
			for(int i = 1; i <= n; ++i) 
				if(s & (1 << (i-1))) y[++tot] = x[i];

			int FST = dfs(1), SEC = dfs(0);
			if(FST ^ SEC){
				if(FST) ++ Alice; else ++ Bob;
			}
			else{
				if(FST) ++ FIRST; else ++ SECOND;
			}
		}
		printf("%d %d %d %d\n", Alice, Bob, FIRST, SECOND);
	}
}

int main()
{
	freopen("stone.in", "r", stdin);
	freopen("stone.ans", "w", stdout);

	scanf("%d%d%d", &n, &a, &b);
	for(int i = 1; i <= n; ++i) scanf("%d", &x[i]);
	brute_force::main();
	return 0;
}
