#include <queue>
#include <vector>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

#define LL long long

const int N = 30000 + 3000;

int n;
int F[N], v[N << 1], nex[N << 1], EID = 1;
int F1[N], v1[N << 1], nex1[N << 1], EID1 = 1;
int w[N], r[N], In[N], In1[N], ans = 0;
vector<int> G[N];
bool vis[N];
struct cmp1{
	bool operator()(int a, int b)
	{
		return w[a] > w[b];
	}
};
struct cmp2{
	bool operator()(int a, int b)
	{
		return w[a] < w[b];
	}
};
priority_queue< int, vector<int>, cmp1> q1;
priority_queue< int, vector<int>, cmp2> q2;

namespace file{
	inline void open()
	{
		freopen("xmastree2.in", "r", stdin);
		freopen("xmastree2.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

inline void add(int f, int t)
{
	nex[EID] = F[f];
	v[EID] = t;
	F[f] = EID++;
}

inline void add1(int f, int t)
{
	nex1[EID1] = F1[f];
	v1[EID1] = t;
	F1[f] = EID1++;
}

namespace input{
	inline int read()
	{
		int a = 0;
		char ch;
		int f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}
	
	inline void Get()
	{
		n = read();
		for(int i = 1;i < n;++i)
		{
			int f = read(), t = read();
			G[f].push_back(t);
			G[t].push_back(f);
		}
		for(int i = 1;i <= n;++i)
			w[i] = read(), r[i] = read();
	}
}

namespace brute{
	inline void init(int x, int fa)
	{
		int s = G[x].size();
		for(int i = 0;i < s;++i)
		{
			int t = G[x][i];
			if(t == fa)
				continue;
			add(x, t);
			++In[t];
			init(t, x);
		}
	}
	
	inline void dfs(int x, int num)
	{
		if(x == n + 1)
		{
			if(ans < num)
				ans = num;
			return;
		}
		for(int i = 1;i <= n;++i)
		{
			if(!vis[i] && In[i] == 0)
			{
				vis[i] = 1;
				for(int k = F[i];k;k = nex[k])
					--In[v[k]];
				dfs(x + 1, num + w[i] * x);
				for(int k = F[i];k;k = nex[k])
					++In[v[k]];
				vis[i] = 0;
			}
		}
	}
	
	inline void solve()
	{
		for(int i = 1;i <= n;++i)
		{
			if(r[i])
			{
				EID = 1;
				memset(F, 0, sizeof F);
				memset(In, 0, sizeof In);
				init(i, 0);
				dfs(1, 0);
			}
		}
		printf("%d\n", ans);
	}
}

namespace greedy{
	inline void init(int x, int fa)
	{
		int s = G[x].size();
		for(int i = 0;i < s;++i)
		{
			int t = G[x][i];
			if(t == fa)
				continue;
			add(x, t);
			++In[t];
			add1(t, x);
			++In1[x];
			init(t, x);
		}
	}
	
	inline void greed(int x)
	{
		int cur = 0, i = 1;
		q1.push(x);
		while(q1.size() > 0)
		{
			int Top = q1.top();q1.pop();
			cur += w[Top] * i;
			for(int i = F[Top];i;i = nex[i])
			{
				int t = v[i];
				--In[t];
				if(!In[t])
					q1.push(t);
			}
			++i;
		}
		if(ans < cur)
			ans = cur;
		cur = 0;
		for(int i = 1;i <= n;++i)
			if(!In1[i])
				q2.push(i);
		i = n;
		while(q2.size() > 0)
		{
			int Top = q2.top();q2.pop();
			cur += w[Top] * i;
			for(int i = F1[Top];i;i = nex1[i])
			{
				int t = v1[i];
				--In1[t];
				if(!In1[t])
					q2.push(t);
			}
			--i;
		}
		if(ans < cur)
			ans = cur;
	}
	
	inline void solve()
	{
		for(int i = 1;i <= n;++i)
		{
			if(r[i])
			{
				EID = 1;
				memset(F, 0, sizeof F);
				memset(In, 0, sizeof In);
				EID1 = 1;
				memset(F1, 0, sizeof F1);
				memset(In1, 0, sizeof In1);
				init(i, 0);
				greed(i);
			}
		}
		printf("%d\n", ans);
	}
}

namespace check{
	inline void deter()
	{
		if(n <= 10)
			brute::solve();
		else
			greedy::solve();
	}
}

int main()
{
	open();
	input::Get();
	check::deter();
	close();
}
/*
5
1 2
1 3
2 4
3 5
4 1
3 0
4 0
3 0
1 0
*/
