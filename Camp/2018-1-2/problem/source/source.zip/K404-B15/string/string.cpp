#include<iostream>
#include<cstdio>
#include<cstring>
#define MAXN (100+10)
#define ERR (1061109567)
using namespace std;
char ch[MAXN];
int n,t;
bool judge[MAXN][MAXN];
int f[MAXN][MAXN];

bool check(int x,int y)
{
	while (ch[x]==ch[y] && x<y)
	{
		x++;
		y--;
	}
	if (x>=y) return true;
	return false;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&t);
	for (int T=1; T<=t; ++T)
	{
		memset(f,0x3f,sizeof(f));
		memset(judge,false,sizeof(judge));
		cin>>n;
		cin>>ch+1;
		for (int i=1; i<=n; ++i)
			for (int j=i; j<=n; ++j)
			{
				judge[i][j]=check(i,j);
				if (!judge[i][j])
					f[i][j]=1;
			}
		for (int l=2; l<=n; ++l)
			for (int i=1; i<=n; ++i)
			{
				int j=i+l-1;
				for (int k=i; k<=j-1; ++k)
					f[i][j]=min(f[i][j],f[i][k]+f[k+1][j]);
			}
		printf("%d\n",f[1][n]==ERR?-1:f[1][n]);
	}
	return 0;
}
