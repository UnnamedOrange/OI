#include<bits/stdc++.h>
#define inf 1e9
using namespace std;
set<int> s;
double b[2000000];
int w[2000000],q[2000000];
inline bool cmp(int a,int b){
	return w[a]>w[b];
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int n;
	scanf("%d",&n);
	b[0]=1;
	for (int i=1;i<=n;i++){
		scanf("%d",w+i);
		q[i]=i;
		b[i]=b[i-1]/2;
	}
	sort(q+1,q+n+1,cmp);
	q[0]=q[n+1]=inf;
	s.insert(0);
	s.insert(n+1);
	double ans=0;
	for (int i=1;i<=n;i++){
		s.insert(q[i]);
		set<int>::iterator t=--s.upper_bound(q[i]);
		double x=0;
		for (int j=1;j<=25;j++){
			set<int>::iterator t2=t--;
			if (t2==s.begin()) break;
			x+=(*t2-*t)*b[j];
		}
		t=s.lower_bound(q[i]);
		double y=0;
		for (int j=1;j<=26;j++){
			set<int>::iterator t2=t++;
			if (t==s.end()) break;
			y+=(*t-*t2)*b[j-1];
		}
		ans+=x*y*w[q[i]];
	}
	printf("%lf\n",ans/n/n);
	return 0;
}
