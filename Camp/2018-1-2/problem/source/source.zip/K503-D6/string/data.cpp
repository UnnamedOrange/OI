#include <cstdio>
#include <cstdlib>
#include <process.h>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

const int N=1e5+10;
char s[N];

int main()
{
    srand(_getpid()^(unsigned long long)new char);
    freopen("string.in","w",stdout);
    int tc=2000;
    printf("%d\n",tc);
    rep(i,1,tc)
    {
        int n=10,mx=3;
        printf("%d\n",n);
        rep(j,1,(n+1)>>1)
            s[j]=s[n-j+1]='a'+rand(mx);
        printf("%s\n",s+1);
    }
    return 0;
}
