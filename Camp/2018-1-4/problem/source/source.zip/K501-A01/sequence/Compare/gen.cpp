#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<stdio.h>
#include<ctime>
#include <algorithm>
using namespace std;
typedef long long LL;
#define Maxn 30
int a[Maxn];
int main(){
	freopen("sequence.in","w",stdout);
	srand(time(NULL));
	int T;
	T = rand() % 6 + 1; 
	cout<<T<<endl;
	while(T--){
		int N=rand()%6+1;
		cout<<N<<endl;
		for (int i = 1;i <= N; ++i) a[i] = i;
		for (int i = 1;i <= rand() % N; ++i)
			reverse(a + 1, a + rand() % N + 1);
		for (int i = 1;i <= N; ++i) printf("%d ", a[i]);
		puts("");
	}
	return 0;
}
