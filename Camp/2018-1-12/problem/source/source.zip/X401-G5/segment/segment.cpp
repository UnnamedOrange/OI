#include<bits/stdc++.h>
using namespace std;
int kcz=998244353,n,m,ans,k,a[100000];
int fastmi(long long i,int j){
	long long ans=1,now=i;
	while (j){
		if (j&1) ans=ans*now%kcz;
		now=now*now%kcz;
		j>>=1;
	}
	return ans;
}
void dfs(int i,int l,int r){
	if (i>n) 	
	{
		for (int i=1;i<=m;i++)			
		ans=(ans+fastmi(a[i],k))%kcz;		
		return ;
	}
	for (int ll=l+1;ll<=m-n+i;++ll)
	  for (int rr=max(ll,r+1);rr<=m-n+i;++rr)
	  {
	  	if (rr!=ll)
		   a[rr-1]++;
		dfs(i+1,ll,rr);
	  	if (rr!=ll)
		   a[rr-1]--;
	  }
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);	
	scanf("%d%d%d",&n,&m,&k);
	dfs(1,0,0);
	cout<<ans;
}

