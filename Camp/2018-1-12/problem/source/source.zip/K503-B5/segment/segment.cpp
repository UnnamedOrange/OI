#include<bits/stdc++.h>
using namespace std;
const int p=998244353;
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	int ans=0;
	for (int i=1;i<=n;i++)
		ans=(ans+(long long)i*(n-i+1)%p)%p;
	printf("%d\n",ans);
	return 0;
}

