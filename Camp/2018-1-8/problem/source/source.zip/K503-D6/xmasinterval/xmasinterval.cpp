#include <cctype>
#include <cstdio>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define mid ((l+r)>>1)
#define lson l,mid,t<<1
#define rson mid+1,r,t<<1|1
#define lc tr[t<<1]
#define rc tr[t<<1|1]

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;    
}

using namespace std;
const int N=5e5+10,p=1e9+9;
int n,m,b[N];
struct data
{
    int l,r;
    bool operator<(const data &x) const
    {
        return r<x.r;
    }
} a[N];
struct node
{
    int len,s,t1,t2;
    void modify(int c1,int c2)
    {
        s=(1ll*s*c1+1ll*c2*len)%p,t1=1ll*t1*c1%p,t2=(1ll*t2*c1+c2)%p;
    }
    void pushdown(node &l,node &r)
    {
        if (t1!=1 || t2)
            l.modify(t1,t2),r.modify(t1,t2),t1=1,t2=0;
    }
} tr[1<<20|1];

void modify(int ql,int qr,int c1,int c2,int l=0,int r=n,int t=1)
{
    if (ql<=l && r<=qr)
        return tr[t].modify(c1,c2);
    tr[t].pushdown(lc,rc);
    if (ql<=mid)
        modify(ql,qr,c1,c2,lson);
    if (mid<qr)
        modify(ql,qr,c1,c2,rson);
    tr[t].s=(lc.s+rc.s)%p;
}

int query(int ql,int qr,int l=0,int r=n,int t=1)
{
    if (ql<=l && r<=qr)
        return tr[t].s;
    tr[t].pushdown(lc,rc);
    if (qr<=mid)
        return query(ql,qr,lson);
    if (mid<ql)
        return query(ql,qr,rson);
    return (query(ql,qr,lson)+query(ql,qr,rson))%p;
}

void build(int l=0,int r=n,int t=1)
{
    tr[t]=(node){r-l+1,!l,1,0};
    if (l<r)
        build(lson),build(rson);
}

int main()
{
    freopen("xmasinterval.in","r",stdin);
    freopen("xmasinterval.in","w",stdout);
    m=get(),n=get();
    rep(i,1,m)
        a[i].l=get(),a[i].r=get();
    rep(i,1,n)
        b[i]=get();
    sort(b+1,b+1+n),n=unique(b+1,b+1+n)-(b+1);
    rep(i,1,m)
    {
        a[i].l=lower_bound(b+1,b+1+n,a[i].l)-b;
        a[i].r=upper_bound(b+1,b+1+n,a[i].r)-b-1;
    }
    sort(a+1,a+1+m),build();
    for (data *i=a+1; i<=a+m; ++i)
    {
        if (i->l>1)
            modify(0,i->l-2,2,0);
        modify(i->r,i->r,1,query(i->l-1,i->r));
    }
    printf("%d",query(n,n));
    return 0;
}
