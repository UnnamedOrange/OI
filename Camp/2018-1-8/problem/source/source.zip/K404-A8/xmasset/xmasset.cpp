#include <cstdio>

int type, T, N;

int main() {
	register int x, y;
	scanf( "%d%d%d", &type, &N, &T );
	while( T-- ) {
		scanf( "%d%d", &x, &y );
		if( type == 1 )
			printf( "%d\n", x );
		else
			puts( x == y ? "yes" : "no" );
	}
	return 0;
}
