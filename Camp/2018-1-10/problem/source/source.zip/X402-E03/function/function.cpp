#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const LL maxn = 5e6+5 ;
LL n, m, pr[maxn+5], tot ;
LL mu[maxn+5], d[maxn+5] ;
bool isp[maxn+5] ;
void init() {
	LL i, j, t ;
	memset ( isp, 1, sizeof isp ) ;
	isp[1] = 0 ;
	mu[1] = d[1] = 1 ;
	for ( i = 2 ; i <= maxn ; i ++ ) {
		if (isp[i]) {
			pr[++tot] = i ;
			mu[i] = -1 ;
			d[i] = 2 ;
		}
		for ( j = 1 ; j <= tot && i*pr[j] <= maxn ; j ++ ) {
			isp[i*pr[j]] = 0 ;
			if (i%pr[j]) {
				mu[i*pr[j]] = -mu[i] ;
				d[i*pr[j]] = d[i]*2 ;
			}
			else {
				mu[i*pr[j]] = 0 ;
				for ( d[i*pr[j]] = 2, t = i ; t%pr[j] == 0 ; d[i*pr[j]] ++, t /= pr[j] ) ;
				d[i*pr[j]] *= d[t] ;
				break ;
			}
		}
	}
	for ( i = 1 ; i <= maxn ; i ++ ) {
		d[i] = d[i - 1] + d[i]*d[i] ;
		mu[i] += mu[i - 1] ;
	}
}
void solve() {
	LL i, rec = 0, r ;
	for ( i = 1 ; i <= n ; ) {
		r = n/(n/i) ;
		rec += (mu[r] - mu[i - 1])*d[n/i] ;
		i = r+1 ;
	}
	printf ( "%lld\n", rec ) ;
}
int main() {
	freopen ( "function.in", "r", stdin ) ;
	freopen ( "function.out", "w", stdout ) ;

	init() ;
	LL _ ;
	scanf ( "%lld", &_ ) ;
	while (_--) {
		scanf ( "%lld", &n ) ;
		solve() ;
	}
	return 0 ;
}
