#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
const int Maxn = 11, Mod = 998244353;

int n, a[Maxn], p[Maxn];
bool visited[Maxn];

int main() {
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	scanf("%d", &n);
	if (n <= 8) {
		for (int i = 1; i <= n; ++i) {
			scanf("%d", &a[i]);
			p[i] = i;
		}
		int ans = 0;
		do {
			bool ok = true;
			for (int i = 1; i <= n; ++i) {
				if (a[i] && p[i] != a[i]) {
					ok = false;
					break;
				}
			}
			if (ok) {
				memset(visited, false, sizeof(visited));
				for (int i = 1, cur, cnt; i <= n; ++i) {
					if (!visited[i]) {
						cur = i, visited[i] = true, cnt = 1;
						while (!visited[p[cur]]) {
							cur = p[cur], visited[cur] = true, ++cnt;
						}
						if (cnt%2) {
							ok = false;
							break;
						}
					}
				}
			}
			ans += ok;
		} while (next_permutation(p+1, p+n+1));
		printf("%d\n", ans);
	} else {
		if (n%2) {
			puts("0");
		} else {
			int ans = 1;
			for (int i = 1; i <= n/2; ++i) {
				ans = LL(ans)*(2LL*i-1)%Mod;
			}
			ans = LL(ans)*ans%Mod;
			printf("%d\n", ans);
		}
	}
	return 0;
}
