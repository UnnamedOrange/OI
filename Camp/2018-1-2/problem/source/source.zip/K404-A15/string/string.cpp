#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int t,len;
char s[200010];
int d[1000];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout); 
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&len);
		scanf("%s",s);
		memset(d,0,sizeof(d));
		int p=0;
		for(int i=0;i<len/2;i++)
		if(s[i]!=s[len-i-1]) {p=1;break;}
		if(p){puts("1");continue;}
		p=1;for(int i=1;i<len;i++)
		if(s[i]!=s[i-1]) p=0;
		if(p){puts("-1");continue;}
		for(int i=0;i<len;i++)	d[s[i]]++;
		p=0;for(int i=1;i<=166;i++) if(d[i]) p++;
		if(p>2) {puts("2");continue;}
		p=0;for(int i=1;i<=166;i++) if(d[i]==1) p=1;
		if(p) {puts("-1");continue;}
		p=0;for(int i=1;i<len;i++) if(s[i]==s[i-1]) p=1;
		if(p==0) {puts("-1");continue;}
		puts("2");
	}
}
