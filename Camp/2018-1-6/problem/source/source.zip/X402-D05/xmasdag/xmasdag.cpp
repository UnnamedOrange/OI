#include<bits/stdc++.h>
using namespace std;
string procstatus(){
	ifstream t("/proc/self/status");
	return string(istreambuf_iterator<char>(t),istreambuf_iterator<char>());
}
const int md=998244353;
const int maxn=100100;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
int n,m,k;
int dp[maxn][501],d[maxn];
long long S[510][510];
long long fac[510],inv[510];
void Mod(int &x){
	x=x>=md?x-md:x;
}
int Mo(int x){
	return x>=md?x-md:x;
}
void solve(){
	static int q[maxn];
	dp[1][0]=1;
	int l=1,r=1;
	q[1]=1;
	int u;
	while(l<=r){
		u=q[l],l++;
		for(int i=beg[u];i;i=nex[i]){
			d[tto[i]]--;
			if(!d[tto[i]]) q[++r]=tto[i];
			for(int j=k;j>=1;j--)
				Mod(dp[tto[i]][j]+=Mo(dp[u][j]+dp[u][j-1]));
			Mod(dp[tto[i]][0]+=dp[u][0]);
		}
	}
}
void solveans(){
	S[1][1]=1;
	for(int i=2;i<=k;i++){
		for(int j=1;j<=i;j++)
			S[i][j]=(S[i-1][j-1]+S[i-1][j]*(long long)j)%md;
	}
	fac[0]=1;
	for(int i=1;i<=k;i++)
		fac[i]=fac[i-1]*i%md;
	for(int i=1;i<=k;i++)
		for(int j=1;j<=i;j++)
			S[i][j]=S[i][j]*fac[j]%md;

	long long ans;
	for(int i=1;i<=n;i++){
		ans=0;
		for(int j=1;j<=k;j++)
			ans=(ans+S[k][j]*dp[i][j])%md;
		printf("%lld\n",ans);
	}
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	int s,t;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		d[t]++;
	}
	solve();
	solveans();
	return 0;
}
