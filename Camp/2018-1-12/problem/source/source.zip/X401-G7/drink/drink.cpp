#include<cstdio>
#define NN 45
#define LL long long
#include<algorithm>
using namespace std;
double ans,sum,mi[80];
int L[1000020],R[1000020],pre[1000020],nxt[1000020];
int n;

int getnum()
{
  int num=0;
  char c=getchar();
  while(c>'9' || c<'0') c=getchar();
  while(c>='0' && c<='9') num=(num<<3)+(num<<1)+c-'0',c=getchar();
  return num;
}

struct S
{
  int num,wz;
}a[1000020];

bool cmp(S t1,S t2)
{
  return t1.num<t2.num;
}

int main()
{
  freopen("drink.in","r",stdin);
  freopen("drink.out","w",stdout);
  int i,j,l,r,t,qwe;
  double tt,ttt;
  n=getnum();
  for(i=1;i<=n;i++) a[i].num=getnum(),a[i].wz=i;
  sort(a+1,a+1+n,cmp);
  for(i=1,mi[0]=1.0;i<=NN;i++) mi[i]=mi[i-1]/2;
  for(i=1;i<=n;i++) pre[i]=i-1,nxt[i]=i+1;
  for(i=1;i<=n;i++) 
	{
	  qwe=a[i].wz;
	  L[0]=R[0]=1,L[1]=R[1]=qwe;
	  t=pre[qwe];
	  while(t && L[0]<=NN) L[++L[0]]=t,t=pre[t];
	  t=nxt[qwe];
	  while(t<=n && R[0]<=NN) R[++R[0]]=t,t=nxt[t];
	  L[L[0]+1]=0,R[R[0]+1]=n+1,tt=ttt=0;
 	  for(j=1;j<=R[0];j++) tt+=(R[j+1]-R[j])*mi[j-1];
	  for(j=1;j<=L[0];j++) ttt+=(L[j]-L[j+1])*mi[j-1];
	  ans+=a[i].num*ttt*tt;
	  nxt[pre[qwe]]=nxt[qwe],pre[nxt[qwe]]=pre[qwe];
	}
  printf("%.12lf\n",ans/2/((LL)n*n));
}
