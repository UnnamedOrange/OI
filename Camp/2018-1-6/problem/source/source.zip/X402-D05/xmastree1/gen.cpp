#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=2000,m=2000,T=0;
	printf("%d %d %d\n",n,m,T);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%n+1);
	printf("\n");
//	for(int i=2;i<=n;i++)
//		printf("%d %d\n",rand()%(i-1)+1,i);
	for(int i=2;i<=n;i++)
		printf("%d %d\n",i-1,i);
	int op;
	for(int i=1;i<=m;i++){
		op=rand()%2+1;
		if(op==1)
			printf("%d %d %d %d\n",op,rand()%n/2+1,rand()%n/2+1,rand()%n/2+1);
		else
			printf("%d %d %d\n",op,rand()%n+1,rand()%n+1);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("xmastree1.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
