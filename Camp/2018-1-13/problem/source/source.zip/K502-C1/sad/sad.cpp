#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>
using namespace std;

const int MAXN = 1e5 + 300, MOD = 998244353;
int n;
int c[MAXN], d[MAXN];
long long w[MAXN], fra[MAXN], inv[MAXN];
vector<int> e[MAXN];

long long fastpow(long long x, long long y)
{
	long long ret = 1;
	if (y > 0)
	{
		if (y % 2 == 1)
			ret = ret * x % MOD;
		x = x * x % MOD;
		y /= 2;
	}
	return ret;
}

void dfs(int p, int fa)
{
	for (int i = 0; i < e[p].size(); ++i)
	{
		int v = e[p][i];
		if (v != fa)
		{
			dfs(v, p);
			w[p] += w[v] * inv[d[p]] % MOD;
			w[p] %= MOD;
			fra[p] += fra[v] * inv[d[p]] % MOD;
			fra[p] %= MOD;
		}
	}
	if (d[p] == 1)
	{
		w[p] = 1;
		fra[p] = 0;
	}
	else
	{
		w[p] += 1;
		fra[p] = (d[p] - fra[p] + MOD) % MOD;
	//	cerr << p << " " << fra[p] << " " << endl;
		if (fra[p] > n + 1)
			fra[p] = fastpow(fra[p], MOD - 2);
		else
			fra[p] = inv[fra[p]];
	}
//	cerr << p << " " << fra[p] << " " << w[p] << endl;
}

void init()
{
	long long fa = 1;
	inv[0] = 1;
	for (int i = 1; i < n + 1; ++i)
		inv[i] = fastpow(i, MOD - 2);
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	n = read();
	init();
	for (int i = 1; i < n + 1; ++i)
	{
		char ch = getchar();
		while (ch != '0' && ch != '1')
			ch = getchar();
		if (ch == '0')
			c[i] = 0;
		else
			c[i] = 1;
	}
	for (int i = 1; i < n; ++i)
	{
		int u = read(), v = read();
		++d[u];
		++d[v];
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs(1, 0);
	printf("%lld\n", fra[1] * w[1] % MOD);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
