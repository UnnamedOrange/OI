#include<bits/stdc++.h>
#define ll long long
using namespace std;

int getint()
{
    int i=0,f=1;char c;
    for(c=getchar();(c<'0'||c>'9')&&c!='-';c=getchar());
    if(c=='-')f=-1,c=getchar();
    for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
    return i*f;
}

const int N=1000005,p=1e9+7;
int n,c[N],d[N],f[N],g[N],pre[N];

int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=getint();
	for(int i=1;i<=n;i++)c[i]=getint(),d[i]=getint();
	memset(f,-1,sizeof(f));
	f[0]=0,g[0]=1;
	for(int i=1;i<=n;i++)
	{
		int mi=c[i],mx=d[i];
		for(int j=i-1;j>=0;j--)
		{
			if(i-j>mx)break;
			if(i-j>=mi&&i-j<=mx&&f[j]!=-1)
				if(f[j]+1>f[i])f[i]=f[j]+1,g[i]=g[j];
				else if(f[j]+1==f[i])g[i]=(g[i]+g[j])%p;
			mi=max(mi,c[j]),mx=min(mx,d[j]);
			if(mi>mx)break;
		}
	}
	//for(int i=1;i<=n;i++)cout<<f[i]<<' ';
	cout<<f[n];
	if(f[n]!=-1)cout<<" "<<g[n];
	putchar('\n');
}

