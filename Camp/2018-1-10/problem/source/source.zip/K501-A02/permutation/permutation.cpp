#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int Mod=998244353;
int c[100010],r[100010];
int p[100010],ap[15]={0};
int q[15],vis[100010];
int n,flag=1,ans=0;
int cnt1=0,cnt2=0;
int mult(int x,int y){
	x%=Mod;y%=Mod;
	return (int)((long long)x*(long long)y%(long long)Mod);
}
int add(int x,int y){
	x%=Mod;y%=Mod;
	return ((x+y)%Mod+Mod)%Mod; 
} 
int Pow(int x,int y){
	int res=1;
	while (y){
		if (y&1) res=mult(res,x);
		x=mult(x,x);
		y>>=1;
	}
	return res;
} 
int C(int x,int y){
	if (y>x) return 0;
	return mult(c[x],mult(r[y],r[x-y]));	
}
void check(){
	memset(vis,0,sizeof(vis));
	for (int i=1;i<=n;++i){
		if (!vis[i]){
			vis[i]=1;
			int k=i,cnt=1;
			while (1){
				k=q[k];
				vis[k]=1;
				cnt++;
				if (k==i){
					cnt--;
					break;
				}
			}
			if (cnt%2) return;
		}
	}
	ans++;
	return;
}
void solve(int x){
	if (x>n){
		check();
		return;	
	}
	if (p[x]){
		q[x]=p[x];
		solve(x+1);
	}
	else{
		for (int i=1;i<=n;++i){
			if (!ap[i]){
				q[x]=i;
				ap[i]=1;
				solve(x+1);
				ap[i]=0;
			}
		}
	}
	return;
}
int getans(int x){
	if (x%2) return 0;
	int res=1;
	for (int i=1;i<=x;i+=2)
		res=mult(res,i);
	return mult(res,res);	
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=read();
	if (n%2){
		printf("0\n");
		return 0;	
	}
	if (n<=8){
		for (int i=1;i<=n;++i){
			p[i]=read();
			if (p[i]) ap[p[i]]=1;	
		}
		solve(1);
		printf("%d\n",ans);
		return 0;
	}
	for (int i=1;i<=n;++i){
		p[i]=read();
		if (p[i]) flag=0;	
	}
	if (flag){
		printf("%d\n",getans(n));	
		return 0;
	}
	for (int i=1;i<=n;++i){
		if (p[i] && !vis[i]){
			int k=i,cnt=1;
			while (1){
				k=p[k];
				cnt++;
				if (k==i){
					cnt--;
					break;
				}
				if (k==0) break;
			}
			if (k!=0 && cnt%2==1){
				printf("0\n");
				return 0;	
			}
			if (cnt%2) cnt1++;
			else cnt2++;
		}
	}
	return 0;
}
