#include <iostream>
#include <cstdio>
#include <cstring>
#define N 1000005
#define mod 1000000007
using namespace std;
char buf[50000005],*p1=buf-1;
int read(){
	int w=0,f=0;char c=*(++p1);
	while(c<'0'||c>'9'){if(c=='-') f=1;c=*(++p1);}
	while(c>='0'&&c<='9'){w=(w<<3)+(w<<1)+c-'0';c=*(++p1);}
	return f?-w:w;
}
int n,c[N],d[N],f[N],sum[N];
int add(int a,int b){
	return (a+b>=mod)?a+b-mod:a+b;
}
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	fread(buf,1,sizeof(buf),stdin);
	n=read();
	for(int i=1;i<=n;i++) c[i]=read(),d[i]=read();
	sum[0]=1;
	for(int i=1;i<=n;i++){
		f[i]=-1e9;
		int L=0,R=i;
		for(int p=i;p>0;p--){
			L=max(L,p-(d[p]-(i-p+1)));
			R=min(R,p-(c[p]-(i-p+1)));
			if(L>R) break;
			if(L<=p&&R>=p)f[i]=max(f[i],f[p-1]+1);
		}
		L=1;R=i;
		for(int p=i;p>0;p--){
			L=max(L,p-(d[p]-(i-p+1)));
			R=min(R,p-(c[p]-(i-p+1)));
			if(L>R) break;
			if(L<=p&&R>=p&&f[p-1]+1==f[i]) sum[i]=add(sum[i],sum[p-1]);
		}
	}
	if(f[n]<=0) puts("-1");
	else printf("%d %d",f[n],sum[n]);
	return 0;
}
