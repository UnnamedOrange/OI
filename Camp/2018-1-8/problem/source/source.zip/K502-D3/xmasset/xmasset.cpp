#include <cstdio>
#include <cstring>
#include <algorithm>
#define ele int
using namespace std;
ele t,n,T;
namespace A{
	inline void solve(){
		while (T--){
			ele x,y;
			scanf("%d%d",&x,&y);
			for (int i=0; ; ++i,x>>=1,y>>=1){
				ele a=x&1,b=y&1;
				if (a!=b){
					printf("%d\n",i*2+a+1);
					break;
				}
			}
		}
	}
};
namespace B{
	inline void solve(){
		while (T--){
			ele q,h;
			scanf("%d%d",&q,&h); --h;
			ele t=(q>>(h/2))&1,t1=h&1;
			puts((t==t1)?"yes":"no");
		}
	}
};
int main(){
	freopen("xmasset.in","r",stdin); freopen("xmasset.out","w",stdout);
	scanf("%d%d%d",&t,&n,&T);
	if (t==1) A::solve(); else B::solve();
	return 0;
}