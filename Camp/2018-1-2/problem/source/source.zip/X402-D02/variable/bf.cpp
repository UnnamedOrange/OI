#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
typedef long long ll;

namespace bf
{
	typedef std::pair<int,int> pii;
	const int N=510;

	int val[N];
	ll ans;

	struct calcer
	{
		int x,y,z,a,b,c,d,e,f;
		void got(){scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&e,&f);}
		ll calc()
		{
			ll ret=0,wx=val[x],wy=val[y],wz=val[z];
			ret+=a*std::abs(wx-wy)+b*std::abs(wy-wz)+c*std::abs(wz-wx);
			ret+=d*(wx-wy)+e*(wy-wz)+f*(wz-wx);
			return ret;
		}
	}s[10010];

	std::vector<pii> t[N];
	int n,w,m0,m1;
	void initialize()
	{
		scanf("%d%d%d%d",&n,&w,&m0,&m1);

		for(int i=1;i<=n;i++)t[i].clear();

		for(int i=1;i<=m0;i++)
			s[i].got();
		for(int i=1,x,y,ty;i<=m1;i++)
		{
			scanf("%d%d%d",&x,&y,&ty);
			if(ty==0 || ty==1)ty^=1;
			t[x].push_back(pii(y,ty));
			t[y].push_back(pii(x,-ty));
		}
	}
	bool check(int p)
	{
		for(std::vector<pii>::iterator it=t[p].begin();it!=t[p].end();it++)
		{
			int q=it->first;
			if(q>p)continue;
			if(it->second==-2)
			{
				if(val[p]<=val[q])return 0;
			}
			else if(it->second==-1)
			{
				if(val[p]<val[q])return 0;
			}
			else if(it->second==0)
			{
				if(val[p]!=val[q])return 0;
			}
			else if(it->second==1)
			{
				if(val[p]>val[q])return 0;
			}
			else
			{
				if(val[p]>=val[q])return 0;
			}
		}
		return 1;
	}
	ll calc()
	{
		ll ret=0;
		for(int i=1;i<=n;i++)ret+=val[i];

//		printf("ret = %d\n",ret);

		for(int i=1;i<=m0;i++)
			ret+=s[i].calc();
		return ret;
	}
	void dfs(int p=1)
	{
		if(p>n)
		{
//			if(calc()==5)
//			{
//				for(int i=1;i<=n;i++)
//					printf("%d ",val[i]);
//				printf("\n--------------\n");
//			}
			ans=std::min(ans,calc());
			return;
		}
		val[p]=w;
		if(check(p))dfs(p+1);
		val[p]=-w;
		if(check(p))dfs(p+1);
	}
	void solve()
	{
		initialize();
		ans=99824435300000ll,dfs();
		printf("%lld\n",ans);
	}
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.ans","w",stdout);
	int T;
	for(scanf("%d",&T);T--;bf::solve());
	return 0;
}
