#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
using namespace std;

const long long mod=1000000009;
int n,m,x[510],l[510],r[510],vis[510]={0};
long long ans=0;
vector<int>cover[510];

bool judge(){
	for(int i=1;i<=m;i++){
		bool yes=0;
		for(int j=1;j<=n;j++)
		  if(vis[j]&&l[j]<=x[i]&&r[j]>=x[i]){
		  	yes=1;break;
		  }
		if(!yes)return 0;
	}
	return 1;
} 

void dfs(int k){
	vis[k]=1;
	if(judge())ans=(ans+1)%mod;
	if(k==n){
		vis[k]=0;
		return;
	}
	dfs(k+1);
	vis[k]=0;
	dfs(k+1);
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d%d",&l[i],&r[i]);
	for(int i=1;i<=m;i++)scanf("%d",&x[i]);
	dfs(1);
	printf("%lld",ans);
	return 0;
}
