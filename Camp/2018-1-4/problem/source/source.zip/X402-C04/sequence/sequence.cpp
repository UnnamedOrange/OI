#include<iostream>
#include<queue>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=29;
int n,ans,a[N];

inline int calc()
{
	int ret=0;
	a[n+1]=n+1;
	for(int i=2;i<=n+1;i++)
		if(a[i-1]!=a[i]-1 && a[i-1]!=a[i]+1)
			ret++;
	return abs(ret);
}

inline bool dfs(int dep)
{
	if(dep==0)
	{
		for(int i=1;i<=n;i++)
			if(a[i]!=i)
				return false;
		return true;
	}

	if(calc()>dep)return false;

	for(int i=1;i<=n;i++)
	{
		reverse(a+1,a+i+1);
		if(dfs(dep-1))return true;
		reverse(a+1,a+i+1);
	}
	return false;
}

int mian()
{
	n=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(ans=0;;ans++)
		if(dfs(ans))
			break;
	printf("%d\n",ans);
	return 0;
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);

	int T=read();
	while(T--)
		mian();

	return 0;
}
