for i in $(seq 1 100000);do  
    ./gen  
    ./test
    ./force
    if diff test.out force.out ;then  
        echo $i "Accepted"  
    else  
        echo $i "Wrong Answer"  
        exit 0  
    fi  
done  
