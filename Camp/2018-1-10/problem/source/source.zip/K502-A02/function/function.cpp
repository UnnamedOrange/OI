#include<cstdio>
using namespace std;
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	return 0;
}
