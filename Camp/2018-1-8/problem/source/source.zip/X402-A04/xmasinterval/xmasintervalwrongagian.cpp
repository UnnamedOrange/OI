#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=1e9+9;
const int N=500050;
int f[N*3],b[N*3],tot=0,n,m,p[N],pw[N],inc[N],nn=0;
pii qu[N],q[N];
bool vis[N*3];

int s[N*3];
inline void add(int x,int k)
{
	x++;
	for(int i=x;i<=tot+1;i+=(i&-i)) s[i]=(s[i]+k)%mod;
}
inline int ask(int l,int r)
{
	int ans=0; l++; r++;
	if(l>r) return 0;
	for(int i=r;i;i-=(i&-i)) ans=(ans+s[i])%mod;
	for(int i=l-1;i;i-=(i&-i)) ans=(ans-s[i]+mod)%mod;
	return ans;
}
bool cmp(pii c,pii d) {return c.se<d.se||(c.se==d.se&&c.fi<d.fi);}

void wj()
{
	freopen("xmasinterval.in","r",stdin);
	//freopen("xmasinterval.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read(); m=read();
	for(i=1;i<=n;++i) qu[i].fi=read(),qu[i].se=read();
	for(i=1;i<=m;++i) p[i]=read(),b[++tot]=p[i];
	sort(b+1,b+1+tot);
	tot=unique(b+1,b+1+tot)-(b+1);
	int unuse=0;
	for(i=1;i<=n;++i)
	{
		qu[i].fi=lower_bound(b+1,b+1+tot,qu[i].fi)-b;
		qu[i].se=upper_bound(b+1,b+1+tot,qu[i].se)-b-1;
		if(qu[i].fi>qu[i].se) unuse++;
		else q[++nn]=qu[i];
	}
	pw[0]=1;
	for(i=1;i<=n;++i) pw[i]=(pw[i-1]+pw[i-1])%mod;
	//for(i=1;i<=m;++i) p[i]=lower(b,tot,p[i]),vis[p[i]]=1;

	n=nn;
	sort(q+1,q+1+n,cmp);
	for(i=1;i<=n;++i)
	{
		inc[i]=ask(q[i].fi+1,tot);
		add(q[i].fi,1);
	}
	memset(s,0,sizeof(s));

	f[0]=1; add(0,1);
	//for(i=1;i<=n;++i) cerr<<q[i].fi<<' '<<q[i].se<<endl;
	int now=0;
	for(i=1;i<=tot;++i)
	{
		int las=now;
		while(now<=n&&q[now+1].se==i) now++;
		for(j=las+1;j<=now;++j)
		{
			f[i]=(f[i]+1ll*pw[now-j+inc[j]]*ask(q[j].fi-1,tot)%mod)%mod;
			//if(j==2) cout<<now-j<<' '<<ask(q[j].fi-1,tot)<<' '<<f[i]<<endl;
			//cerr<<i<<' '<<j<<endl;
		}
		//if(i==2) cout<<now<<' '<<q[now].fi-1<<endl;
		add(i,f[i]);
		//cerr<<f[i]<<endl;
	}
//	cout<<ask(0,1)<<endl;
	printf("%lld\n",1ll*f[tot]*pw[unuse]%mod);
	return 0;
}
