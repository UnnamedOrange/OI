#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;
int n,map[1010];
long double ans;
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&map[i]);
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<=n;j++)
		{
			long double res=0;
			int sorted[1010];
			for(int k=i;k<=j;k++) sorted[k-i+1]=map[k];
			sort(sorted+1,sorted+(j-i+2));
			for(int k=1;k<=(j-i+1);k++) if(sorted[k]>res) res=(res+(1.0)*sorted[k])/2;
			ans+=res;
		}
	}
	ans/=(1.0)*n;
	ans/=(1.0)*n;
	printf("%Lf",ans);
	return 0;
}

