//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
const int maxn=1e5+10;
int n,m,t,col[maxn],ans;
bool ok[maxn];

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

int fir[maxn],nxt[2*maxn],to[2*maxn],e=0;
void add(int x,int y) {
	to[++e]=y; nxt[e]=fir[x]; fir[x]=e;
	to[++e]=x; nxt[e]=fir[y]; fir[y]=e;
}

int fa[maxn],id[maxn],dep[maxn],size[maxn],son[maxn],top[maxn],tot;
void dfs(int pos,int f,int d) {
	fa[pos]=f; dep[pos]=d; size[pos]=1;
	int y,z;
	for(y=fir[pos];y;y=nxt[y]) {
		if((z=to[y])==f) continue;
		dfs(z,pos,d+1); size[pos]+=size[z];
		if(size[z]>size[son[pos]]) son[pos]=z;
	}
}
////////////////////////////////////////
void yh(int &x) {x^=ans;}
void get_ans(int pos,int l,int r) {
	int c=col[pos],y,z;
	if(c>=l&&c<=r&&!ok[c]) { ok[c]=1; ++ans; }
	for(y=fir[pos];y;y=nxt[y]) {
		if((z=to[y])==fa[pos]) continue;
		get_ans(z,l,r);
	}
}
////////////////////////////////////////
////////////////////////////////////////
int totans[maxn],qtot;
struct Node{
	int qid,col,x,id,pos;
	Node(){}
	Node(int qid,int id,int col,int x,int pos):qid(qid),id(id),col(col),x(x),pos(pos){}
}node[2*maxn];
int tt;
bool cmp(const Node& a,const Node& b) {
	return a.col==b.col? a.id < b.id : a.col < b.col;
}

void dfs2(int pos,int tp) {
	id[pos]=++tot; top[pos]=tp;
	if(!son[pos]) return;
	dfs2(son[pos],tp);
	int y,z;
	for(y=fir[pos];y;y=nxt[y]) {
		z=to[y];
		if(z==fa[pos]||z==son[pos]) continue;
		dfs2(z,z);
	}
}

int sz[maxn],sum[maxn];
void clear() {
	
}
////////////////////////////////////////
int main() {
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read(); m=read(); t=read();
	int x,y,l,r,op;
	if(t||n<=5000) {
		for(int i=1;i<=n;++i) col[i]=read();
		for(int i=1;i<n;++i) {
			x=read(); y=read();
			add(x,y);
		}
		dfs(1,0,1);
		for(int i=1;i<=m;++i) {
			op=read(); 
			if(op==1) {
				x=read(); l=read(); r=read();
				if(t) yh(x),yh(l),yh(r);
				memset(ok,0,sizeof(ok)); ans=0;
				get_ans(x,l,r);
				printf("%d\n",ans);
			}
			else {
				x=read(); y=read();
				if(t) yh(x),yh(y);
				col[x]=y;
			}
		}
	}
	else {
		for(int i=1;i<=n;++i) node[++tt]=Node(0,0,col[i]=read(),1,i);
		for(int i=1;i<n;++i) {
			x=read(); y=read();
			add(x,y);
		}
		dfs(1,0,1); dfs2(1,1);
		for(int i=1;i<=m;++i) {
			op=read();
			if(op==1) {
				x=read(); l=read(); r=read();
				if(l>1) node[++tt]=Node(++qtot,i,l-1,-1,x);
				node[++tt]=Node(++qtot,i,r,1,x);
			}
			else {
				x=read(); y=read(); if(col[x]==y) continue;
				node[++tt]=Node(0,i,col[x],-1,x);
				node[++tt]=Node(0,i,col[x]=y,1,x);
			}
		}
		sort(node+1,node+tt+1,cmp);
		for(int i=1;i<=tt;++i) {
			if(i==1||node[i].col!=node[i-1].col) clear();
			
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
5 5 0
5 5 2 5 5
5 1
2 5
4 2
3 5
1 2 2 3
2 5 1
1 1 1 5
2 3 2
1 3 1 5

5 5 1
4 1 1 5 4
5 1
3 5
2 3
4 3
2 5 4
2 2 2
1 3 1 5
2 1 2
1 1 2 7
*/
