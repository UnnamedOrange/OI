#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#define maxn 510
#define INF 0x7fffffff
using namespace std;
int ans,n,W,p,q,link[maxn][maxn],w[maxn];
struct node{
	int x,y,z,a,b,c,d,e,f;
}qu[maxn];
struct Node{
	int x,y,v;
}r[maxn];
bool check(int sta){
	for(int i=1;i<=n;i++){
		w[i]=sta&(1<<(i-1));
		if(w[i]!=0)w[i]=W;
		else w[i]=-W;
	}
	for(int i=1;i<=q;i++){
		if(r[i].v==0){
			if(w[r[i].x]>w[r[i].y])return 0;
		}
		else if(r[i].v==1){
			if(w[r[i].x]!=w[r[i].y])return 0;
		}
		else if(r[i].v==2){
			if(w[r[i].x]>=w[r[i].y])return 0;
		}
	}
	return 1;
}
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("variable.in","r",stdin);freopen("variable.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		ans=INF;
		scanf("%d%d%d%d",&n,&W,&p,&q);
		for(int i=1;i<=p;i++)scanf("%d%d%d%d%d%d%d%d%d",&qu[i].x,&qu[i].y,&qu[i].z,&qu[i].a,&qu[i].b,&qu[i].c,&qu[i].d,&qu[i].e,&qu[i].f);
		for(int i=1;i<=q;i++)scanf("%d%d%d",&r[i].x,&r[i].y,&r[i].v);
		for(int sta=0;sta<(1<<n);sta++){
			if(!check(sta))continue;
			int s1=0,s2=0;
			for(int i=1;i<=n;i++)s1+=w[i];
			for(int i=1;i<=p;i++){
				s2+=qu[i].a*abs(w[qu[i].x]-w[qu[i].y])+qu[i].b*abs(w[qu[i].y]-w[qu[i].z])+qu[i].c*abs(w[qu[i].z]-w[qu[i].x]);
				s2+=qu[i].d*(w[qu[i].x]-w[qu[i].y])+qu[i].e*(w[qu[i].y]-w[qu[i].z])+qu[i].f*(w[qu[i].z]-w[qu[i].x]);
			}
			ans=min(ans,s1+s2);
		}
		printf("%d\n",ans);
	}
	return 0;
}
