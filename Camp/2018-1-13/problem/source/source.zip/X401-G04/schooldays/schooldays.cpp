/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
#define MAXN 1000000

#define MODP 1000000007
#define MOD(x) ((x)%MODP)
int n;
int c[MAXN+10],d[MAXN+10];
int f[MAXN+10],g[MAXN+10];
namespace bl
{
void main()
{
	g[0]=1;
	for(int i=1; i<=n; ++i)
	{
		int Min=0,Max=INT_MAX;
		for(int j=i; j>=1; --j)
		{
			Min=max(Min,c[j]);
			Max=min(Max,d[j]);
			if (Min>Max) break;
			if (i-j+1>=Min && i-j+1<=Max)
			{
				if (g[j-1]==0) continue;
				if (f[j-1]+1>f[i])
				{
					f[i]=f[j-1]+1;
					g[i]=g[j-1];
				}
				else if (f[j-1]+1==f[i])
				{
					g[i]=MOD(g[i]+g[j-1]);
				}
			}
		}
	}
	if (g[n]==0)
	{
		puts("-1");
		return;
	}
	printf("%d %d\n",f[n],g[n]);
}
}
int main()
{
	freopen("schooldays.in","r",stdin);
#ifndef MDEBUG
	freopen("schooldays.out","w",stdout);
#endif
	scanf("%d",&n);
	for(int i=1; i<=n; ++i)
	{
		scanf("%d%d",&c[i],&d[i]);
	}
	bl::main();
    return 0;
}
