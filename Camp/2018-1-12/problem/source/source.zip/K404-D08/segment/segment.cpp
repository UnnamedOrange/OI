#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define per(a,b,c) for (int a=b;a>=c;a--)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=100010,P=998244353;
int n,m,k,a[N];
LL ans;
LL pw(LL x,LL k){
	LL y=1;
	while (k){
		if (k&1) y=y*x%P;
		x=x*x%P;
		k>>=1;
	}
	return y;
}
void add(LL &x,LL y){x=(x+y)%P;}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if (n!=1) return 0;
//	rep(i,1,m) scanf("%d",&a+i);
	rep(i,1,m){
		add(ans,(LL)i*(m-i)%P);
	}
	ans=(ans%P+P)%P;
	printf("%lld\n",ans);
	return 0;
}

