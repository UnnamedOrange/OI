#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int T,a;
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&a);
		printf("��TM������\n"); 
	}
	return 0;
}
