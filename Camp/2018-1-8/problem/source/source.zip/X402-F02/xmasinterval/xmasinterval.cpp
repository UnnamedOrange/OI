#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=5e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("xmasinterval.in","r",stdin);
		freopen("xmasinterval.out","w",stdout);
	#endif
}
const int mo=1e9+9;
int n,m,pos[N];
struct node
{
	int l,r;
	bool operator < (const node &temp)const
	{return r==temp.r?l>temp.l:r<temp.r;}
}e[N];
void input()
{
	n=read<int>();m=read<int>();
	For(i,1,n)
	{
		e[i].l=read<int>();
		e[i].r=read<int>();
	}
	For(i,1,m)pos[i]=read<int>();
}
#define mid ((l+r)>>1)
#define lson h<<1,l,mid
#define rson h<<1|1,mid+1,r
int add(int a,int b)
{
	return (a+b)>=mo?a+b-mo:a+b;
}
int mul(int a,int b)
{
	return 1ll*a*b%mo;
}
struct segment_tree
{
	int dp[N<<2],mc[N<<2],lazy[N<<2];
	void build(int h,int l,int r)
	{
		mc[h]=1;lazy[h]=0;
		if(l==r)return;
		build(lson);build(rson);
	}
	void push_down(int h,int l,int r)
	{
		int ls=h<<1,rs=ls|1;
		if(mc[h]!=1)
		{
			mc[ls]=mul(mc[ls],mc[h]);
			mc[rs]=mul(mc[rs],mc[h]);
			lazy[ls]=mul(lazy[ls],mc[h]);
			lazy[rs]=mul(lazy[rs],mc[h]);
			dp[ls]=mul(dp[ls],mc[h]);
			dp[rs]=mul(dp[rs],mc[h]);
			mc[h]=1;
		}
		if(lazy[h])
		{
			dp[ls]=add(dp[ls],mul(lazy[h],mid-l+1));
			dp[rs]=add(dp[rs],mul(lazy[h],r-mid));
			lazy[ls]=add(lazy[ls],lazy[h]);
			lazy[rs]=add(lazy[rs],lazy[h]);
			lazy[h]=0;
		}
	}
	void push_up(int h)
	{
		dp[h]=add(dp[h<<1],dp[h<<1|1]);
	}
	void update_mul(int h,int l,int r,int s,int t,int v)
	{
		if(s<=l&&r<=t)
		{
			mc[h]=mul(mc[h],v);
			lazy[h]=mul(lazy[h],v);
			dp[h]=mul(dp[h],v);
			return;
		}
		push_down(h,l,r);
		if(s<=mid)update_mul(lson,s,t,v);
		if(mid<t)update_mul(rson,s,t,v);
		push_up(h);
	}
	void update_add(int h,int l,int r,int s,int t,int v)
	{
		if(s<=l&&r<=t)
		{
			dp[h]=add(dp[h],mul(v,r-l+1));
			lazy[h]=add(lazy[h],v);
			return;
		}
		push_down(h,l,r);
		if(s<=mid)update_add(lson,s,t,v);
		if(mid<t)update_add(rson,s,t,v);
		push_up(h);
	}
	int query(int h,int l,int r,int pos)
	{
		if(l==r)return dp[h];
		push_down(h,l,r);
		int res;
		if(pos<=mid)res=query(lson,pos);
		else res=query(rson,pos);
		push_up(h);
		return res;
	}
}S;
#undef mid
#undef lson
#undef rson
void out()
{
	For(i,0,m)
	{
		printf("%d ",S.query(1,0,m,i));
	}
	printf("\n");
}
void work()
{
	int res;
	S.update_add(1,0,m,0,0,1);
	For(i,1,n)
	{
		if(e[i].l<e[i].r)
		{
			res=S.query(1,0,m,e[i].l-1);
			S.update_add(1,0,m,e[i].l,e[i].r,res);
		}
		//out();
		S.update_mul(1,0,m,0,e[i].l-1,2);
		//out();
	}
	printf("%d\n",S.query(1,0,m,m));
}
void init()
{
	sort(pos+1,pos+m+1);
	sort(e+1,e+n+1);
	For(i,1,n)
	{
		e[i].l=lower_bound(pos+1,pos+m+1,e[i].l)-pos;
		e[i].r=upper_bound(pos+1,pos+m+1,e[i].r)-pos-1;
	}
	S.build(1,0,m);
	//For(i,1,n)printf("%d %d\n",e[i].l,e[i].r);
}
int main()
{
	file();
	input();
	init();
	work();
	return 0;
}
