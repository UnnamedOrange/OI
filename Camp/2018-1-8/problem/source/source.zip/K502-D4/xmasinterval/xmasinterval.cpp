#include<cstdio>
using namespace std;
int m,n;
struct qj{
	int l,r;
}q[25];
int a[25];
int map[25][25];
int ans;
void dfs(int loc,int select){
	if(loc<=m){
		dfs(loc+1,select*2+1);
		dfs(loc+1,select*2);
	}
	else{
		bool vis[25]={0};
		int x=m;
		while(select>0){
			int se=select%2;
			select/=2;
			if(se==1)
				for(int i=1;i<=n;i++)
					if(map[x][i])
						vis[i]=1;
			x--;
		}
		for(int i=1;i<=n;i++) if(!vis[i]) return;
		ans++;
	}
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=m;i++)
		scanf("%d%d",&q[i].l,&q[i].r);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		for(int j=1;j<=m;j++)
			if(q[j].l<=a[i]&&a[i]<=q[j].r)
				map[j][i]=1;
	}
	dfs(1,0);
	printf("%d\n",ans);
	return 0;
}
