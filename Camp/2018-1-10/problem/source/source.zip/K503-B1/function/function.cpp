#include<bits/stdc++.h>
using namespace std;
const int maxn=1000010;
int T,opt,n;
int mu[maxn],f[maxn],a[maxn],b[maxn],r,c[maxn];
int i,j,k;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void getf(int x){
	int i,t1=0;
	for (i=1;i<=trunc(sqrt(x));i++){
		if (x%i==0){
			t1=t1+2;
			if (i*i==x) t1--;
		}
	}
	f[x]=t1;
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	T=read();
	r=0;
	for (i=2;i<=1e6;i++){
		if (a[i]==0){
			r++; b[r]=i; a[i]=i;
			mu[i]=-1;
		}
		j=1;
		while ((j<=r)&&(b[j]<=a[i])){
			if (i*b[j]>1e6) break;
			a[i*b[j]]=b[j];
			if (a[i]!=b[j]){
				mu[i*b[j]]=mu[i]*mu[b[j]];
			}
			else{
				mu[i*b[j]]=0;
			}
			j++;
		}
	}
	mu[1]=1;
	for (i=1;i<=1e6;i++){
		j=i;
		while (j<=1e6){
			f[j]++;
			j=j+i;
		}
	}
	for (i=1;i<=1e6;i++){
		j=i;
		while (j<=1e6){
			c[j]=c[j]+mu[i]*f[j/i]*f[j/i];
			j=j+i;
		}
	}
	for (i=1;i<=1e6;i++){
		c[i]=c[i]+c[i-1];
	}
	for (opt=1;opt<=T;opt++){
		n=read();
		printf("%d\n",c[n]);
	}
	return 0;
}
