#include <cstdio>
#include <algorithm>

using namespace std;

#define N (int)1e5+10
#define modp 998244353

int a[N][2],ans=0;

int power(int x, int p){
	int k=x,s=1;
	for (;p;p>>=1,k=1LL*k*k%modp)
		if (p&1) s=1LL*s*k%modp;
	return s;
}

struct segment_tree{
	int v[N<<2];
	#define lson k<<1
	#define rson k<<1|1
	#define mid (l+r>>1)
	void pushdown(int k){
		if (v[k]){
			v[lson]+=v[k];
			v[rson]+=v[k];
			v[k]=0;
		}
	}
	void update(int l, int r, int k, int L, int R, int w){
		if (L<=l&&r<=R) v[k]+=w;
		else{
			pushdown(k);
			if (L<=mid) update(l,mid,lson,L,R,w);
			if (mid<R) update(mid+1,r,rson,L,R,w);
		}
	}
	int query(int l, int r, int k, int p){
		if (l==r) return power(v[k],p);
		pushdown(k);
		return (query(l,mid,lson,p)+query(mid+1,r,rson,p))%modp;
	}
}seg;

void dfs(int x, int n, int m, int k){
	if (x>n){
		ans=(ans+seg.query(1,m,1,k))%modp;
		return;
	}
	for (int l=a[x-1][0]+1;l+n<=m+x;l++)
		for (int r=max(a[x-1][1]+1,l);r+n<=m+x;r++){
			a[x][0]=l,a[x][1]=r;
			if (l<r) seg.update(1,m,1,l,r-1,1);
			dfs(x+1,n,m,k);
			if (l<r) seg.update(1,m,1,l,r-1,-1);
		}
}

int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int n,m,k; scanf("%d%d%d",&n,&m,&k);
	dfs(1,n,m,k); printf("%d\n",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}

