#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int K = 500;
const int N = 5000;
const int M = 200000;
const int mo = 998244353;

inline int fpm(int base, int exp) {
    int res = 1;
    for(; exp > 0; exp >>= 1) {
        if(exp & 1)
            res = 1ll * res * base % mo;
        base = 1ll * base * base % mo;
    }
    return res;
}

int st[N + 5], to[M + 5], nxt[M + 5], e = 1;

inline void addedge(int u, int v) {
    std::swap(u, v);
    to[++ e] = v; nxt[e] = st[u]; st[u] = e;
}

int n, m, k;
bool vis[N + 5];
int coe[N + 5][N + 5];

void dfs(int u) {
    if(vis[u]) return;
    vis[u] = true;

    for(int i = st[u]; i; i = nxt[i]) {
        int v = to[i];
        dfs(v);

        for(int j = 1; j <= n; ++j) {
            coe[u][j] = (coe[u][j] + coe[v][j-1]) % mo;
        }
    }
}

int main() {
    freopen("xmasdag.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(n), read(m), read(k);
    for(int i = 0; i < m; ++i) {
        static int x, y;
        read(x), read(y); addedge(x, y);
    }
    coe[1][0] = 1;
    for(int i = 1; i <= n; ++i) if(!vis[i]) dfs(i);
    for(int i = 1; i <= n; ++i) {
        int ans = 0;
        for(int j = 1; j <= n; ++j) {
            ans = (ans + 1ll * coe[i][j] * fpm(j, k)) % mo;
        }
        printf("%d\n", ans);
    }

    return 0;
}
