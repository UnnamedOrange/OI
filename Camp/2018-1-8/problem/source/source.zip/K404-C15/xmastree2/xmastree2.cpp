#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 12;
int n, ans, w[N], fa[N], per[N], fac = 1;
int ecnt, adj[N], nxt[2 * N], go[2 * N];
bool vis[N], r[N];

void add(int u, int v){
	go[++ecnt] = v;
	nxt[ecnt] = adj[u];
	adj[u] = ecnt;
}
void dfs(int u){
	for(int e = adj[u], v; e; e = nxt[e])
		if((v = go[e]) != fa[u])
			fa[v] = u, dfs(v);
}
void check(){
	vis[0] = 1;
	for(int i = 1; i <= n; i++) vis[i] = 0;
	int res = 0;
	for(int i = 1; i <= n; i++){
		if(!vis[fa[per[i]]]) return;
		vis[per[i]] = 1;
		res += w[per[i]] * i;
	}
	ans = max(ans, res);
}

int main(){
	
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	
	read(n);
	for(int i = 1, u, v; i < n; i++)
		read(u), read(v), add(u, v), add(v, u);
	for(int i = 1; i <= n; i++)
		read(w[i]), read(r[i]), fac *= i;
	for(int i = 1; i <= n; i++)
		if(r[i]){
			fa[i] = 0;
			dfs(i);
			for(int i = 1; i <= n; i++)
				per[i] = i;
			for(int i = 1; i <= fac; i++){
				check();
				next_permutation(per + 1, per + n + 1);
			}
		}
	write(ans), enter;
	
	return 0;
}
