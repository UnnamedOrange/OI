#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while(!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while(isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n = n * sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
int type, n, T, x, y;

int main(){
	read(type), read(n), read(T);
	while(T--){
		read(x), read(y);
		if (type == 1){
			int ret = 0;
			for (int i = 1; x; x /= 10, ++i)
				ret ^= x % 10 + i;
			printf("%d\n", ret);
		} else {
			int ret = 0;
			for (int i = 1; x; x /= 10, ++i)
				ret ^= x % 10 + i;
			puts(ret == y ? "yes" : "no");
		}
	}
	return 0;
}

