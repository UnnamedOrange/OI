#include<cstdio>
#include<algorithm>
using namespace std;
#define N 1000006
#define rep(i,j,k) for(i=j;i<=k;++i)
struct E{
	int to,nxt;
}e1[N],e2[N];
int ans,timing,n,m,i,j,k,top,u,v,scc,L,R;
int du[N],h2[N],dfn[N],low[N],vis[N],stap[N],h1[N],bl[N],f[N],sz[N];
void add1(int u,int v){
	top++; e1[top].to=v; e1[top].nxt=h1[u]; h1[u]=top;
}
void add2(int u,int v){
	top++; e2[top].to=v; e2[top].nxt=h2[u]; h2[u]=top; du[v]++;
}
void read(int &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
} 
void tarjan(int x){
	int i;
	timing++; dfn[x]=low[x]=timing; vis[x]=1; top++; stap[top]=x;
	for(i=h1[x];i;i=e1[i].nxt)
	if(!dfn[e1[i].to]){
		tarjan(e1[i].to);
		low[x]=min(low[x],low[e1[i].to]);
	}else
	if(vis[e1[i].to]){
		low[x]=min(low[x],dfn[e1[i].to]);
	}
	if(low[x]==dfn[x]){
		int u;
		scc++;
		do{
			u=stap[top]; top--; 
			vis[u]=0; bl[u]=scc; sz[scc]++;
		}while(u!=x); 
	} 
}
void init(){
	read(n); read(m);
	rep(i,1,m){
		read(u); read(v);
		add1(u,v);
	}
	top=0;
	rep(i,1,n)
	if(!dfn[i]){
		tarjan(i);
	}
	top=0;
	rep(i,1,n)
	 for(j=h1[i];j;j=e1[j].nxt)
	 if(bl[e1[j].to]!=bl[i]){
	 	add2(bl[i],bl[e1[j].to]);
	 }
	L=1; R=0;
	rep(i,1,scc){
		if(!du[i]){
			R++; stap[R]=i;
		}
		f[i]=sz[i];
	}
	while(L<=R){
		int x=stap[L]; L++;
		for(i=h2[x];i;i=e2[i].nxt){
			du[e2[i].to]--;
			f[e2[i].to]=max(f[e2[i].to],f[x]+sz[e2[i].to]);
			if(!du[e2[i].to]){
				R++; stap[R]=e2[i].to;
			}
		}
	}
	rep(i,1,scc) ans=max(ans,f[i]);
	printf("%d\n",ans);
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	init();
	return 0;
}
