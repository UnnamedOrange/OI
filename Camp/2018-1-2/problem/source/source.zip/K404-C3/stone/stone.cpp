#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 100010
#define ll long long
#define mod 1000000007
using namespace std;
inline int read() 
{ 
    int x=0,f=1;char ch=getchar(); 
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();} 
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
    return x*f; 
}
int n,a,b;
int x[N],k[N];
ll quickmod(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%mod;
		a=a*a%mod,b>>=1;
	}
	return ret;
}
namespace subtask1
{
	void main()
	{
		ll tmp=0,tot=0;;
		int cnt1=0,cnt2;
		for(int i=1;i<=n;i++)x[i]/=a,cnt1+=(x[i]%2==1);
	 	cnt2=n-cnt1;
 		if(cnt1)
 		{
		 	tmp=tot=cnt1;
		 	for(int i=3;i<=cnt1;i+=2)
		 	{
	 			tmp=tmp*quickmod(i-1,mod-2)%mod*(cnt1-i+2)%mod;
	 			tmp=tmp*quickmod(i,mod-2)%mod*(cnt1-i+1)%mod;
	 			tot+=tmp,tot%=mod;
	 		}
	 	}
	 	tot*=quickmod(2,cnt2);
	 	tot%=mod;
	 	ll ans2=(quickmod(2,n)-tot+mod)%mod;
	 	cout<<0<<' '<<0<<' '<<tot<<' '<<ans2<<endl;
	}
}
namespace subtask2
{
	void main()
	{
		int cnt1=0,cnt2;
		for(int i=1;i<=n;i++)cnt1+=(x[i]%(a+b)==b);
		cnt1++;
		ll aaa=(quickmod(2,n)-cnt1+mod)%mod;
		cout<<aaa<<' '<<0<<' '<<0<<' '<<cnt1<<endl;
	}
}
namespace subtask3
{
	bool win;
	void dfs(int turn,int lim,int fst)
	{
		if(turn==0)//a
		{
			bool mov=0;
			for(int i=1;i<=lim;i++)
			if(k[i]>=a)
			{
				k[i]-=a;mov=1;
				dfs(turn^1,lim,fst);
				k[i]+=a;
			}
			if(!mov&&turn!=fst)win=1;
		}
		
		if(turn==1)//b
		{
			bool mov=0;
			for(int i=1;i<=lim;i++)
			if(k[i]>=b)
			{
				k[i]-=b;mov=1;
				dfs(turn^1,lim,fst);
				k[i]+=b;
			}
			if(!mov&&turn!=fst)win=1;
		}
	}
	int hh[N],top;
	int ans1,ans2,ans3,ans4;
	void chos(int now)
	{
		if(now==n+1)
		{
			for(int i=1;i<=top;i++)
			k[i]=hh[i];
			
			bool afs=0,bfs=0;
			dfs(0,top,0);
			afs=win,win=0;
			for(int i=1;i<=top;i++)
			k[i]=hh[i];
			dfs(1,top,1);
			bfs=win,win=0;
			
			if(afs&&bfs)ans3++;
			if(!afs&&!bfs)ans4++;
			if(afs&&!bfs)ans1++;
			if(!afs&&bfs)ans2++;
			return ;
		}
		top++;
		hh[top]=x[now];
		chos(now+1);
		top--;
		chos(now+1);
	}
	void main()
	{
		chos(1);
		cout<<ans1<<' '<<ans2<<' '<<ans3<<' '<<ans4<<endl;
	}
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n=read(),a=read(),b=read();
	for(int i=1;i<=n;i++)x[i]=read();
	if(n<=5)subtask3::main();
	else if(a==b)subtask1::main();
	else if(a==1)subtask2::main();
	else subtask3::main();
}