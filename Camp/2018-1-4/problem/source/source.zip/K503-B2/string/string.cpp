#include<cstdio>
#include<algorithm>
const int mod=998244353;
using namespace std;
char s[505][10];
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%s",s[i]);
	if(n==1){
		printf("%d\n",m);
		return 0;
	}
	else printf("7\n");
	return 0;
}
