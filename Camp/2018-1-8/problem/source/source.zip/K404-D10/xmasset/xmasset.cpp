//© Jazengm/ZengXiangru, AllRightsReserved

#include<bits/stdc++.h>
using namespace std;

//#define debugMod
#ifdef debugMod
#define debug(x) x
#endif
#ifndef debugMod
#define debug(x)
#endif

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

int cnt;
bool f[1<<10][1<<4];

In void DFS(int tot=0, int x=1)
{
    St int q[1<<4];
    if(tot==6)
    {
        ++cnt;
        debug(printf("%d\n", cnt);)
        debug(inc(0, i, 6)
            printf("%d ", q[i]);
        puts("");)
        assert(cnt<1024);
        inc(0, i, 6)
            f[cnt][q[i]]=1;
    }
    inc(x, i, 13)
        q[tot]=i, DFS(tot+1, i+1);
}

int main()
{
    freopen("xmasset.in", "r", stdin);
    freopen("xmasset.out", "w", stdout);
    DFS();
    St int type, n, T;
    scanf("%d%d%d", &type, &n, &T);
    if(type==1)
    {
        for(;T--;)
        {
            St int x, y;
            scanf("%d%d", &x, &y);
            if(x==y)
            {
                inc(1, i, 13)
                    if(f[x][i])
                    {
                        printf("%d\n", i);
                        break;
                    }
                    continue;
            }
            inc(1, i, 13)
                if(f[x][i] && !f[y][i])
                {
                    printf("%d\n", i);
                    break;
                }
        }
        Re 0;
    }
    for(;T--;)
    {
        St int q, h;
        scanf("%d%d", &q, &h);
        if(f[q][h])
            puts("yes");
        else
            puts("no");
    }
    Re 0;
}
