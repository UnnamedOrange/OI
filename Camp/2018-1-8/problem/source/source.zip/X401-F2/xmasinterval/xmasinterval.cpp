#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}
const int maxn=500010;

int n,m,sum;

int X[maxn];

struct node{
	int l,r;
}a[maxn];

int main()
{
    freopen("xmasinterval.in","r",stdin);
    freopen("xmasinterval.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=n;i++)
		read(a[i].l),read(a[i].r);
	for(int i=1;i<=m;i++) read(X[i]),sum+=X[i];
    printf("%d\n",sum/m);
    return 0;
}
