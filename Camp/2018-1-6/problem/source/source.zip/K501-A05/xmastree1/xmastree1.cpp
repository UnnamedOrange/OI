#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int maxn = 5000;

int n, q, t;

struct edge
{
	int adj, nxt;

	edge() { }
	edge(int _adj, int _nxt): adj(_adj), nxt(_nxt) { }
}e[(maxn << 1 ) + 5];

int st[maxn + 5], _cnt;

inline void add_edge(int u, int v)
{
	e[_cnt] = edge(v, st[u]), st[u] = _cnt++;
}

int c[maxn + 5];

inline void input()
{
	n = read<int>(), q = read<int>(), t = read<int>();
	REP(i, 0, n) c[i] = read<int>();

	memset(st, -1, sizeof st), _cnt = 0;
	REP(i, 1, n)
	{
		int u = read<int>() - 1, v = read<int>() - 1;

		add_edge(u, v), add_edge(v, u);
	}
}

int fa[maxn + 5];

inline void pre_dfs(int u, int fa0)
{
	fa[u] = fa0;

	for(int i = st[u]; ~i; i = e[i].nxt)
	{
		int v = e[i].adj;
		if(v != fa0) pre_dfs(v, u);
	}
}

bool vis[maxn + 5];

inline void dfs(int u)
{
	vis[c[u]] = 1;

	for(int i = st[u]; ~i; i = e[i].nxt)
	{
		int v = e[i].adj;
		if(v != fa[u]) dfs(v);
	}
}

inline int calc(int u, int l, int r)
{
	memset(vis, 0, sizeof vis), dfs(u);

	int sum = 0;
	for(int i = l; i <= r; ++i) sum += vis[i];
	return sum;
}

inline void solve()
{
	pre_dfs(0, -1);

	int lastans = 0;
	while(q--)
	{
		int type = read<int>();
		if(type == 1)
		{
			int u = read<int>(), l = read<int>(), r = read<int>();
			if(t) u ^= lastans, l ^= lastans, r ^= lastans;
			printf("%d\n", lastans = calc(u - 1, l, r));
		}
		else
		{
			int u = read<int>(), c0 = read<int>();
			if(t) u ^= lastans, c0 ^= lastans;
			c[u - 1] = c0;
		}
	}
}

int main()
{
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);

	input();
	solve();

	return 0;
}

