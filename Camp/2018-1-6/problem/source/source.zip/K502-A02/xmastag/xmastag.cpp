#include<cstdio>
#include<iostream>
#include<queue>
#define maxn 100010
#define mod 998244353
using namespace std;
vector<int> g[maxn];
int n,m,k;
int s[maxn],f[maxn],r[maxn];
void sort_top(){
	queue<int> q;
	q.push(1);
	f[1]=1; s[1]=0;
	while (!q.empty()){
		int now=q.front();
		q.pop();
		for (int i=0;i<g[now].size();i++){
			int son=g[now][i];
			f[son]=(f[son]+f[now])%mod;
			s[son]=(s[son]+f[now]+s[now])%mod;
			r[son]--;
			if (!r[son]) q.push(son);
		}
	}
	for (int i=1;i<=n;i++) printf("%d\n",s[i]);
}
int main(){
	freopen("xmastag.in","r",stdin);
	freopen("xmastag.out","w",stdout);
	cin>>n>>m>>k;
	for (int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		g[x].push_back(y);
		r[y]++;
	}
	if (k==1) sort_top();
	return 0;
}
