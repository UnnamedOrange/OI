#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}


typedef long long ll;
//const int N=1000009;
const int N=5009;
const ll md=1e9+7;

int n,c[N],d[N],rec[N],top;
ll rmx[N],rmn[N],f[N],g[N][N];

inline bool chkmax(ll &a,ll b){if(a<b){a=b;return 1;}return 0;}
inline bool chkmin(ll &a,ll b){if(a>b){a=b;return 1;}return 0;}
inline void chk(ll &a){if(a>=md)a-=md;}

int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schoolday.out","w",stdout);

	n=read();
	for(int i=1;i<=n;i++)
	{
		c[i]=read(),d[i]=read();
		f[i]=-1e9;
	}

	f[0]=0;
	for(int i=1;i<=n;i++)
	{
		rmx[i]=c[i];rmn[i]=d[i];
		for(int j=i-1;j>=1;j--)
		{
			chkmin((rmn[j]=rmn[j+1]),d[j]);
			chkmax((rmx[j]=rmx[j+1]),c[j]);
		}
		
		for(int j=0;j<i;j++)
			if(i-j<=rmn[j+1] && rmx[j+1]<=i-j)
				chkmax(f[i],f[j]+1);
	}

	int k=f[n];g[0][0]=1;
	if(k<0)return puts("-1"),0;
	for(int i=1;i<=n;i++)
	{
		rmx[i]=c[i];rmn[i]=d[i];
		for(int j=i-1;j>=1;j--)
		{
			chkmin((rmn[j]=rmn[j+1]),d[j]);
			chkmax((rmx[j]=rmx[j+1]),c[j]);
		}
		
		for(int j=0;j<i;j++)
			if(i-j<=rmn[j+1] && rmx[j+1]<=i-j)
				for(int l=1;l<=k;l++)
					chk(g[i][l]+=g[j][l-1]);
	}

	printf("%d %d\n",k,g[n][k]);
	cerr<<k<<" "<<g[n][k]<<endl;
	return 0;
}
