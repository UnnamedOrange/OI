#include<bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-')p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v=-v;
}
int n, m;
char s[11][105], t1[105], t2[105];
char a[1005];
int nxt[1005], nxt2[1005];

int ans;
inline bool check() {
	for(int i = 0; i < m; ++i) {
		a[m + m - i - 1] = a[i] ^ 1;
	}
	int len;
	bool pd;
	for(int i = 1; i <= n; ++i) {
		len = strlen(s[i]);
		pd = 0;
		for(int j = 0; j <= m + m - len; ++j ) {
			pd = 1;
			for(int k = 0; k < len; ++k) {
				if(s[i][k]!= a[j + k]) {
					pd = 0;
					break;
				}
			}
			if(pd) break;
		}
		if(!pd) return 0;
	}
	return 1;
}
inline void dfs(int x) {
	if(x == m) {
		//	for(int i = 0; i < m; ++i) {
		//		printf("%c", a[i]);
		///	}
		//	puts("");
		ans += check();
		return;
	}
	a[x] = '1';
	dfs(x + 1);
	a[x] = '0';
	dfs(x + 1);
}
int dp[505][105][105];
const int mod = 998244353;
int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	R(n), R(m);
	if(m <= 15) {
		for(int i = 1; i <= n; ++i) {
			scanf("%s", s[i]);
		}
		dfs(0);
		printf("%d\n", ans);
		return 0;
	} else {
		if(n == 1) {
			scanf("%s", t1 + 1);
			int len = strlen(t1 + 1);
			int j = 0;
			for(int i = 2; i <= len; ++i) {
				while(j && t1[i] != t1[j + 1]) j = nxt[j];
				if(t1[i] == t1[j + 1]) ++j;
				nxt[i] = j;
			}

			reverse(t1 + 1, t1 + len + 1);
			for(int i = 1; i <= len; ++i) {
				t2[i] = t1[i];
			}
			j = 0;
			for(int i = 2; i <= len; ++i) {
				while(j && t2[i] != t2[j + 1]) j = nxt2[j];
				if(t2[i] == t2[j + 1]) ++j;
				nxt2[i] = j;
			}
			//	for(int i = 1; i <= len; ++i) {
			//		printf("nxt[%d] = %d, nxt2[%d] = %d\n", i, nxt[i], i, nxt2[i]);
			//	}
			reverse(t1 + 1, t1 + len + 1);
			int nxtj, nxtk;
			ans = 0;
			dp[0][0][0] = 1;
			for(int i = 0; i < m; ++i) {
				for(int j = 0; j <= len; ++j) {
					for(int k = 0; k <= len; ++k) {
						// next is 0
						if(j == len) {
							nxtj = len;
						} else {
							if(t1[j + 1] == '0')nxtj = j + 1;
							else  {
								nxtj = j;
								while(nxtj && t1[nxtj + 1] != '0') nxtj = nxt[nxtj];
								if(t1[nxtj + 1] == '0') ++nxtj;
							}
						}
						if(k == len) {
							nxtk = len;
						} else {
							if(t2[k + 1] == '1')nxtk = k + 1;
							else {
								nxtk = k;
								while(nxtk && t2[nxtk + 1] != '1') nxtk = nxt2[nxtk];
								if(t2[nxtk + 1] == '1') ++nxtk;
							}
						}
						dp[i + 1][nxtj][nxtk] +=dp[i][j][k];
						(dp[i + 1][nxtj][nxtk] >= mod) ? (dp[i + 1][nxtj][nxtk] -= mod) : (0);
						//next is 1
						if(j == len) {
							nxtj = len;
						} else {
							if(t1[j + 1] == '1')nxtj = j + 1;
							else  {
								nxtj = j;
								while(nxtj && t1[nxtj + 1] != '1') nxtj = nxt[nxtj];
								if(t1[nxtj + 1] == '1') ++nxtj;
							}
						}
						if(k == len) {
							nxtk = len;
						} else {
							if(t2[k + 1] == '0')nxtk = k + 1;
							else {
								nxtk = k;
								while(nxtk && t2[nxtk + 1] != '0') nxtk = nxt2[nxtk];
								if(t2[nxtk + 1] == '0') ++nxtk;
							}
						}
						dp[i + 1][nxtj][nxtk] +=dp[i][j][k];
						(dp[i + 1][nxtj][nxtk] >= mod) ? (dp[i + 1][nxtj][nxtk] -= mod) : (0);
					}
				}
			}
			//	for(int i = 0; i <= m; ++i) {
			//		for(int j = 0; j <= len; ++j) {
			//			for(int k = 0; k <= len; ++k) {
			//				printf("dp[%d][%d][%d] = %d\n", i, j, k, dp[i][j][k]);
			//			}
			//		}
			//	}
			for(int i = 0; i <= len; ++i) {
				for(int j = 0; j <= len; ++j) {
					if(i + j >= len) {
						ans += dp[m][i][j];
						(ans >= mod) ? (ans -= mod) : (0);
					}
				}
			}
			printf("%d\n", ans);
		}
	}
	return 0;
}
