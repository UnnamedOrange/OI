#include<cstdio>
#include<algorithm>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
struct E{
	int to,nxt;
}ed[10000];
int n,i,j,K,u,v,top,ans,cnt,timing;
int head[30],stap[30][3],dfn[30],low[30],vis[30],stp[30];
void add(int u,int v){
	top++; ed[top].to=v; ed[top].nxt=head[u]; head[u]=top;
}
bool tarjan(int x){
	int i;
	timing++; dfn[x]=low[x]=timing; vis[x]=1; top++; stp[top]=x;
	for(i=head[x];i;i=ed[i].nxt)
	if(!dfn[ed[i].to]){
		if(tarjan(ed[i].to)) return true;
		low[x]=min(low[x],low[ed[i].to]);
	}else
	if(vis[ed[i].to]){
		low[x]=min(low[x],dfn[ed[i].to]);
	}
	if(low[x]==dfn[x]){
		int u,size=0;
		do{
			u=stp[top]; top--;
			size++; vis[u]=0;
		}while(u!=x);
		if(size==K) return true;
	}
	return false;
}
bool check(){
	int i;
	timing=top=0;
	rep(i,1,n) vis[i]=head[i]=dfn[i]=0;
	rep(i,1,cnt)
	if(stap[i][2]){
		add(stap[i][1],stap[i][0]);
	}else add(stap[i][0],stap[i][1]);
	top=0;
	rep(i,1,n)
	if(!dfn[i]){
		if(tarjan(i)) return true;
	}
	return false;
}
void work(int k){
	if(k>cnt){
		if(check()) ans++;
		return ;
	}
	stap[k][2]=0;
	work(k+1);
	stap[k][2]=1;
	work(k+1);
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&K);
	rep(i,1,n)
	 rep(j,i+1,n){
		cnt++; stap[cnt][0]=i; stap[cnt][1]=j;
	 }
	work(1);
	printf("%d\n",ans);
	return 0;
}
