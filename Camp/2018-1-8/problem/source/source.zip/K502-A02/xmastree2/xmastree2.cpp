#include<cstdio>
#include<iostream>
#include<cstring>
#include<vector>
#include<queue>
#define maxn 30010
using namespace std;
typedef long long LL;
typedef pair<int,int> pii;
vector<int> g[maxn];
int n,w[maxn],v[maxn];
int root[11],cnt=0;
LL BFS(int rt){
	memset(v,0,sizeof(v));
	LL sum=0;
	priority_queue<pii,vector<pii>,greater<pii> > pq;
	pq.push({w[rt],rt});
	int k=0;
	while (!pq.empty()){
		int now=pq.top().second,c=pq.top().first;
		pq.pop();
		v[now]=1;
		k++; sum+=(LL)k*c;
		for (int i=0;i<g[now].size();i++){
			int son=g[now][i];
			if (!v[son]) pq.push({w[son],son});
		}
	}
	return sum;
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	cin>>n;
	for (int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		g[x].push_back(y);
		g[y].push_back(x);
	}
	for (int i=1;i<=n;i++){
		int r;
		scanf("%d%d",&w[i],&r);
		if (r) root[++cnt]=i;
	}
	LL ans=0;
	for (int i=1;i<=cnt;i++)
		ans=max(ans,BFS(root[i]));
	cout<<ans<<endl;
	return 0;
}
