#include<bits/stdc++.h>
using namespace std;
int main(){
	int s,n,t;
	scanf("%d%d%d",&s,&n,&t);
	while (t--){
		int x,y;
		scanf("%d%d",&x,&y);
		if (s==1) printf("%d\n",x);
		else if (x==y) puts("yes");
		else puts("no");
	}
	return 0;
}
