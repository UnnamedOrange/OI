#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int T;
int n, W, p, q;
struct shizi {
	int x, y, z, a, b, c, d, e, f;
} shi[1005];
struct tiaojian {
	int x, y, r;
} tiao[1005];
int w[505];
long long ans;
inline bool check() {
	for(int i = 1; i <= q; ++i) {
		if(tiao[i].r == 0 && w[tiao[i].x] > w[tiao[i].y]) return 0;
		if(tiao[i].r == 1 && w[tiao[i].x] != w[tiao[i].y]) return 0;
		if(tiao[i].r == 2 && w[tiao[i].x] >= w[tiao[i].y]) return 0;
	}
	return 1;
}
inline long long calc() {
	long long ret = 0;
	for(int i = 1; i <= p; ++i) {
	//	printf("a = %d, b = %d, c = %d, d = %d, e = %d, f = %d, x = %d, y = %d, z = %d\n",
	//	       shi[i].a, shi[i].b, shi[i].c, shi[i].d, shi[i].e, shi[i].f, shi[i].x, shi[i].y, shi[i].z);
		ret += (long long)(shi[i].a) * abs(w[shi[i].x] - w[shi[i].y])
		       + (long long)(shi[i].b) * abs(w[shi[i].y] - w[shi[i].z])
		       + (long long)(shi[i].c) * abs(w[shi[i].z] - w[shi[i].x])
		       +(long long)(shi[i].d) * (w[shi[i].x] - w[shi[i].y])
		       + (long long)(shi[i].e) * (w[shi[i].y] - w[shi[i].z])
		       + (long long)(shi[i].f) * (w[shi[i].z] - w[shi[i].x]);
	}
	//cout<<"ret1 = "<<ret<<'\n';
	for(int i = 1; i <= n; ++i) {
		ret += w[i];
	}
//	cout<<"ret2 = "<<ret<<'\n';
	return ret;
}
inline void dfs(int x) {
	if(x == n + 1) {
		if(check()) {
	//		for(int i = 1; i <= n; ++i) {
	///			printf("w[%d] = %d\n", i, w[i]);
	//		}
	//		printf("calc() = %d\n", calc());
	//		puts("");
			ans = min(ans, calc());
		}
		return;
	}
	w[x] = W;
	dfs(x + 1);
	w[x] = -W;
	dfs(x + 1);
}
int main() {
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	R(T);
	while(T--) {
		R(n), R(W), R(p), R(q);
		for(int i = 1; i <= p; ++i) {
			R(shi[i].x), R(shi[i].y), R(shi[i].z), R(shi[i].a), R(shi[i].b),
			R(shi[i].c), R(shi[i].d), R(shi[i].e), R(shi[i].f);
		}
		for(int i = 1; i <= q; ++i) {
			R(tiao[i].x), R(tiao[i].y), R(tiao[i].r);
		}
		ans = 1ll<<60ll;
		dfs(1);
		cout<<ans<<'\n';
	}
	return 0;
}
