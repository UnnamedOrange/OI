#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define per(a,b,c) for (int a=b;a>=c;a--)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
int a[30],ans,n;
void dfs(int d=0,int f=0,int cur=0){
	if (d>=ans) return;
	int cnt=0;
	rep(i,2,n) if (abs(a[i]-a[i-1])!=1) ++cnt;
	if (d+cnt>=ans) return;
	int flag=0;
	rep(i,1,n) if (a[i]!=i) flag=1;
	if (!flag){
		ans=d;
		return;
	}
	per(i,f-1,2){
		rep(j,1,i/2) swap(a[j],a[1+i-j]);
		dfs(d+1,i);
		rep(j,1,i/2) swap(a[j],a[1+i-j]);
	}
	per(i,n,f+1){
		rep(j,1,i/2) swap(a[j],a[1+i-j]);
		dfs(d+1,i);
		rep(j,1,i/2) swap(a[j],a[1+i-j]);
	}
}
void work(){
	scanf("%d",&n);
	rep(i,1,n) scanf("%d",a+i);
	rep(i,0,2*n){
		ans=i;
		dfs();
		if (ans!=i) break;
	}
	printf("%d\n",ans);
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int tc;
	scanf("%d",&tc);
	while (tc--) work();
	return 0;
}

