#include <bits/stdc++.h>
#define LL long long
using namespace std;
const LL Mod = 1000000007;
LL S, T, N, M;
LL A[1000000 + 100];
LL fac[1000000 + 100], ufac[10000000 + 100];
LL Prefix[1010];
LL Ans;
inline LL Pow(LL a, LL b)
{
	LL ans = 1;
	while (b)
	{
		if (b & 1) (ans *= a) %= Mod;
		(a *= a) %= Mod;
		b >>= 1;
	}
	return ans;
}

inline LL C(LL n, LL m)
{
	return ((fac[n] * ufac[m]) % Mod * ufac[n - m]) % Mod;
}

LL SUM;
inline void Check()
{
	LL Cnt = 0;
	for (LL i = 1; i <= N; ++i) Cnt += A[i]; 
	if (S - Cnt < (M - N)) return ;
	LL Sum = SUM, cnt = 1;
	for (LL i = 2; i <= N; ++i)
		if (A[i] == A[i - 1]) cnt ++;
		else (Sum *= ufac[cnt]) %= Mod, cnt = 1;
	(Sum *= ufac[cnt]) %= Mod;
	int Tmp = 0;
	for (LL i = (S - Cnt); i >= (M - N); --i)
		(Tmp += C(i - 1, M - N - 1)) %= Mod;
	(Sum *= Tmp) %= Mod;
	(Ans += Sum) %= Mod;
}

int cntt = 0;
inline void dfs()
{
	cntt++;
	Check();
	LL fl = 0;
	for (LL i = 1; i <= N; ++i)
		if (A[i] == T)
		{
			fl = i;
			break;
		}
	if (!fl) A[N] ++;
	else 
	{
		if (fl == 1) return ;
		A[fl - 1] ++;
		for (LL i = fl; i <= N; ++i) A[i] = A[fl - 1];
	}
	dfs();
}
int main()
{
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	scanf("%lld%lld%lld%lld", &S, &T, &N, &M);
	if (T == 1 && S == N * T)
	{
		cout<<0<<endl;
		return 0;
	}
	for (LL i = 1; i <= N; ++i) A[i] = 1;
	fac[0] = 1;
	ufac[0] = Pow(fac[0], Mod - 2);
	for (LL i = 1; i <= 1000000; ++i) fac[i] = (fac[i - 1] * i) % Mod, ufac[i] = Pow(fac[i], Mod - 2);
	SUM = fac[N];
//	for (int i = M - N - 1; i <= 1000; ++i) Prefix[i] = (Prefix[i - 1] + C(i, M - N - 1)) % Mod;
	dfs();
	cout<<Ans<<endl;
	//cout<<cntt<<endl;
	return 0;
}
