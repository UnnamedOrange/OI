#include <queue>
#include <cstdio>
#include <iostream>
#include <cstring>

#define MP make_pair
#define PB push_back
#define FO(x) freopen(#x".in", "r", stdin), freopen(#x".out", "w", stdout)

using namespace std;
typedef long long LL;
typedef unsigned long long u64;

template <typename T> inline bool cmin(T & a, const T & b) { return a > b ? a = b, 1 : 0;}
template <typename T> inline bool cmax(T & a, const T & b) { return a < b ? a = b, 1 : 0;}
int read() {
	int x = 0, f = 1;char ch;
	for(ch = getchar(); !isdigit(ch); ch = getchar())
		if(ch == '-') f = -1;
	for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	return x * f;
}

const int MaxN = 101234;
int T, n; char s[MaxN];

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int i;
	T = read();
	while(T--) {
		n = read();
		scanf("%s", s + 1);
		int all = 1;
		for(i = 2; i <= n; i++) if(s[i] != s[i - 1]) all = 0;
		int p = 1;
		for(i = 1; i <= n; i++)
			if(s[i] != s[n - i + 1])
				p = 0;
		if(all) 
			puts("-1");
		else {
			if(!p) {
				puts("1"); continue;
			}
			if(p) {
				if(~n & 1) {
					puts("2"); 
					continue;
				}
				int chk = 1;
				for(i = 1; i <= n; i++)
					if(i != n / 2 + 1) {
						if(s[i] != s[1]) 
							chk = 0;
					}
				if(chk) puts("-1"); else puts("2");
			}
		}
	}
	return 0;
}
