#include<cstdio>
#include<iostream>
using namespace std;
const int N=100010;
int ru[N];
struct edg{
	int to,next;
}e[2*N];
int head[N],n,m,x,y,k,size;
int q[N],val[N][31],h,t;
int C[100][100];
const int mod=998244353;
void add(int x,int y)
{
	size++;
	e[size].to=y;
	e[size].next=head[x];
	head[x]=size;
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=m;i++) scanf("%d%d",&x,&y),ru[y]++,add(x,y);
	C[0][0]=1;
	for (int i=1;i<=k;i++)
	{
		C[i][0]=1;
		for (int j=1;j<=i;j++)
			C[i][j]=(1ll*C[i-1][j-1]+C[i-1][j])%mod;
	}
	for (int i=1;i<=n;i++) if (ru[i]==0){q[++t]=i;val[i][0]=1;}
	while (h<t)
	{
		x=q[++h];
		for (int i=head[x];i;i=e[i].next)
		{
			y=e[i].to;
			for (int j=0;j<=k;j++)
				for (int t=0;t<=j;t++)
					val[y][j]=(1ll*val[y][j]+1ll*val[x][t]*C[j][t])%mod;
			ru[y]--;
			if (ru[y]==0) q[++t]=y;
		}
	}
	for (int i=1;i<=n;i++)
		printf("%d\n",val[i][k]);
}
