#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}

const int maxn=1e6+10;
int n,m,dfs_clock,dfn[maxn],low[maxn],stk[maxn],top,scccnt,scc[maxn],size[maxn];
int dp[maxn],deg[maxn],ans;

struct graph{
	int ecnt,ebeg[maxn],eto[maxn],enxt[maxn];
	inline int ae(int u,int v){
		++ecnt;
		enxt[ecnt]=ebeg[u];
		ebeg[u]=ecnt;
		eto[ecnt]=v;
	}
}g,gg;

inline void chkmin(int&a,int b){
	if(a>b)a=b;
}
inline void chkmax(int&a,int b){
	if(a<b)a=b;
}
void dfs(int pos){
	dfn[pos]=low[pos]=++dfs_clock;
	stk[top++]=pos;
	for(int i=g.ebeg[pos],v;i;i=g.enxt[i])
		if(!dfn[v=g.eto[i]]){
			dfs(v);
			chkmin(low[pos],low[v]);
		}
		else if(!scc[v])
			chkmin(low[pos],dfn[v]);
	if(low[pos]>=dfn[pos]){
		++scccnt;
		do
			scc[stk[--top]]=scccnt,++size[scccnt];
		while(stk[top]!=pos);
	}
}

int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;++i){
		int u=read(),v=read();
		g.ae(u,v);
	}
	for(int i=1;i<=n;++i)
		if(!dfn[i])
			dfs(i);
	for(int i=1;i<=n;++i)
		for(int j=g.ebeg[i];j;j=g.enxt[j])
			if(scc[i]!=scc[g.eto[j]]){
				++deg[scc[g.eto[j]]];
				gg.ae(scc[i],scc[g.eto[j]]);
			}
	queue<int> q;
	for(int i=1;i<=scccnt;++i)
		if(!deg[i])
			q.push(i);
	while(!q.empty()){
		int pos=q.front();q.pop();
		dp[pos]+=size[pos];
		for(int i=gg.ebeg[pos],v;i;i=gg.enxt[i]){
			--deg[v=gg.eto[i]];
			chkmax(dp[v],dp[pos]);
			if(!deg[v])
				q.push(v);
		}
		chkmax(ans,dp[pos]);
	}
	printf("%d\n",ans);
	return 0;
}
