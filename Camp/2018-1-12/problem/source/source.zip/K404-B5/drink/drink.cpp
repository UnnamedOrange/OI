#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 1000007;
const int MAXL = 53;
const int L = 45;
const int BUFSIZE = 20000007;

int n;
int a[MAXN];
int ord[MAXN];
set < int > s;
int il[MAXN][MAXL], ir[MAXN][MAXL];
LD rpw2[MAXL];
char _buf[BUFSIZE], *bp;
int itl[MAXN], itr[MAXN];



void init ();
void input ();
void work ();

int read ()
{
	int num = 0;
	char ch;
	for ( ch = *(bp++); ch < '0' || ch > '9'; ch = *(bp++) );
	for ( ; ch >= '0' && ch <= '9'; ch = *(bp++) ) num = num * 10 + ch - '0';
	return num;
}



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "drink" );
	
	fread ( _buf, 1, BUFSIZE, stdin );
	bp = _buf;
	
	rpw2[0] = 1;
	lp ( i, 1, MAXL ) rpw2[i] = rpw2[i-1] / 2;
}

void input ()
{
	n = read ();
	lpi ( i, 1, n ) a[i] = read ();
}

void work ()
{
	lpi ( i, 1, n ) ord[i] = i;
	sort ( ord+1, ord+1+n, [] ( int x, int y ) { return a[x] > a[y]; } );
	
	s.insert ( 0 ), s.insert ( n+1 );
	itl[0] = itr[n+1] = -1;
	
	int pre, nv;
	set < int > ::iterator it;
	lpi ( _i, 1, n ){
		int i = ord[_i];
		pre = i;
		it = s.upper_bound ( i ), nv = *it;
//		cerr << i << ":" << endl;
		lpi ( j, 0, L ){
//			cerr << *it << " " << pre << endl;
			ir[i][j] = nv - pre;
			pre = nv;
			nv = itr[nv];
			if ( nv == -1 ) break;
		}
		it = s.upper_bound ( i ), --it, nv = *it;
		pre = i;
		lpi ( j, 0, L ){
			il[i][j] = pre - nv;
			pre = nv;
			nv = itl[nv];
			if ( nv == -1 ) break;
		}
		
		it = s.upper_bound ( i );
		itl[*it] = i;
		itr[i] = *it;
		--it;
		itr[*it] = i;
		itl[i] = *it;
		s.insert ( i );
	}
	
//	lpi ( i, 1, n ){
//		cerr << i << endl;
//		lpi ( j, 0, 10 ) cerr << il[i][j] << " ";
//		cerr << endl;
//		lpi ( j, 0, 10 ) cerr << ir[i][j] << " ";
//		cerr << endl;
//	}
	
	LD ans = 0, vl, vr;;
	lpi ( i, 1, n ){
		vl = 0, vr = 0;
		lpi ( j, 0, L ) vl += rpw2[j] * il[i][j], vr += rpw2[j] * ir[i][j];
//		cerr << i << " " << vl << " " << vr << endl;
		ans += vl * vr * a[i];
	}
	
	cout << setprecision ( 13 ) << fixed << ans / 2 / n / n << endl;
}
