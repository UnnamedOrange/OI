#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define per(a,b,c) for (int a=b;a>=c;a--)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=4010;
int n,m,k,a[N],b[N],f[N],g[N],r[N],cnt[N],ans;
void add(int x){
	++cnt[x];
}
void del(int x){
	--cnt[x];
}
bool judge(){
	rep(i,1,k) if (!cnt[i]) return 0;
	return 1;
}
void clr(){
	memset(cnt,0,sizeof(cnt));
}
void upd(int &x,int y){x=max(x,y);}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	rep(i,1,n) scanf("%d",a+i);
	rep(i,1,m) scanf("%d",b+i);
//	f[n+1]=-1;
//	g[m+1]=-1;
	per(i,n,1){
		r[i]=i==n?n:r[i+1];
		add(a[i]);
		while (1){
			del(a[r[i]]);
			--r[i];
			if (!judge()) break;
		}
		++r[i];
		add(a[r[i]]);
		if (!judge()) f[i]=0; else
		f[i]=f[r[i]+1]+1;
	}
	clr();
	per(i,m,1){
		r[i]=i==m?m:r[i+1];
		add(b[i]);
		while (1){
			del(b[r[i]]);
			--r[i];
			if (!judge()) break;
		}
		++r[i];
		add(b[r[i]]);
		if (!judge()) g[i]=0; else
		g[i]=g[r[i]+1]+1;
	}
	clr();
	int r0=0;
	while (r0<m){
		++r0;
		add(b[r0]);
		if (judge()) break;
	}
	if (judge()) upd(ans,1+min(f[1],g[r0+1]));
	rep(i,1,n){
		add(a[i]);
		while (r0){
			del(b[r0]);
			--r0;
			if (!judge()){
				++r0;
				add(b[r0]);
				break;
			}
		}
		if (judge()) upd(ans,1+min(f[i+1],g[r0+1]));
	}
	printf("%d\n",ans+1);
	return 0;
}

