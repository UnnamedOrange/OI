#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=20+5;
const int mod=1e9+9;
struct node{
	int l,r;
};
struct node a[maxn];
int q[maxn],c[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int ans=0,n,m;
void dfs(int cur,int goal){
	int i,j;
	if(cur>goal){
		for(i=1;i<=m;i++){
			int flag=0;
			for(j=1;j<=n;j++)
				if(q[j]==1 && a[j].l<=c[i] && a[j].r>=c[i]){
					flag=1;
					break;
				}
			if(!flag)return;
		}
		ans++;
		return;
	}
	q[cur]=1;
	dfs(cur+1,goal);
	q[cur]=0;
	dfs(cur+1,goal);
}
int main(){
	int i,j,k;
#ifndef ONLINE_JUDGE
	freopen("xmasinterval.in","r",stdin);
	freopen("bf.out","w",stdout);
#endif
	n=read();m=read();
	for(i=1;i<=n;i++){
		a[i].l=read();a[i].r=read();
	}
	for(i=1;i<=m;i++)c[i]=read();
	sort(c+1,c+m+1);
	dfs(1,n);
	printf("%d\n",ans);
	cerr<<ans<<endl;
	return 0;
}

