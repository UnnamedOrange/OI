#include<bits/stdc++.h>
using namespace std;
//int a[4100],ss[4100];
int n,m,k;
int a[4100],b[4100],c[4100],ans=12345678;

void dfs(int x,int y,int dep)
{
	int xx=x,yy=y;
	if (x==-1&&y==-1) 
	  {
	  	ans=min(dep,ans);
	  	return;
	  }
	for (int i=1;i<=k;i++)
	  {
	  	if (x!=-1) 
	  	  {
			for (int j=x+1;j<=n;j++) 
			  if (a[j]==i) 
			    {
			    	xx=j;
			    	break;
				}
			if (xx==x) xx=-1;
		  }
	  	if (y!=-1)
		  {
		  	for (int j=y+1;j<=n;j++) 
			  if (b[j]==i) 
			    {
			    	yy=j;
			    	break;
				}
		  	if (yy==y) yy=-1;
		  } 
	  	dfs(xx,yy,dep+1);
	  }
}

int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++) scanf("%d",&a[i]);
	for (int i=1;i<=m;i++) scanf("%d",&b[i]);
//	for (int i=1;i<=n;i++)
//	  {
//	  	for (int j=i+1;j<=n;j++)
//	  	  {
//	  	  	if (a[j]==a[i])
//	  	  	  {
//	  	  	  	s[i]=j;
//	  	  	  	break;
//			  }
//		  }
//		if (!s[i]) s[i]=-1;   
//	  }
//	for (int i=1;i<=m;i++)
//	  {
//	  	for (int j=i+1;j<=n;j++)
//	  	  {
//	  	  	if (b[i]==b[j])
//	  		  {
//	  		  	ss[i]=j;
//	  		  	break;
//			  }
//		  }
//		if (!ss[i]) ss[i]=-1; 
//	  }  
	dfs(0,0,0);  
	printf("%d",ans);
}
