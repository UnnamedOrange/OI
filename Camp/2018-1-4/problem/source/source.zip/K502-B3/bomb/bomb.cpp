#include <stdio.h> 
#include <string.h>
#include <queue>
using namespace std;

queue<long long int>q; 

const int maxn=1000001;
long long int a[maxn],b[maxn],first[maxn],next[maxn],to[maxn],vis[maxn],dfn[maxn],low[maxn],t[maxn],f[maxn],v[maxn],c[maxn],dis[maxn];
long long int n,m,cur1=0,cnt=0,cnt1=1,cnt2,cur2=0,ans=0;

inline long long int read()
{
    char ch;
    bool flag = false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void add1(long long int x,long long int y)
{
	next[cur1]=first[x];
	first[x]=cur1;
	to[cur1]=y;
	cur1++;
}

void add2(long long int x,long long int y)
{
	next[cur2]=first[x];
	first[x]=cur2;
	to[cur2]=y;
	cur2++;
	c[y]++;
}

void tarjan(long long int x)
{
	vis[x]=1;
	dfn[x]=cnt1;
	low[x]=dfn[x];
	cnt1++;
	long long int i;
	for(i=first[x];i!=-1;i=next[i])
	{
		if(vis[to[i]]==0)
			tarjan(to[i]);
		if(vis[to[i]]==1&&dfn[to[i]]>=cnt2)
			low[x]=(long long int)min(low[x],low[to[i]]);
	}
	f[x]=low[x];
	v[f[x]]++;
	if(dfn[x]==low[x])
		t[cnt++]=dfn[x];
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout); 
	memset(first,-1,sizeof(first));
	n=read();
	m=read();
	long long int i;
	for(i=1;i<=m;i++)
	{
		a[i]=read(),b[i]=read();
		add1(a[i],b[i]);
	}
	for(i=1;i<=n;i++)
	{
		if(!vis[i])
		{
			cnt2=cnt1;
			tarjan(i);
		}
	}
	memset(first,-1,sizeof(first));
	memset(next,0,sizeof(next));
	memset(to,0,sizeof(to));
	for(i=1;i<=m;i++)
	{
		if(f[a[i]]!=f[b[i]])
		{
			add2(f[a[i]],f[b[i]]);
		}
	}
	for(i=0;i<=cnt-1;i++)
	{
		if(c[t[i]]==0)
			q.push(t[i]);
	}
	while(!q.empty())
	{
		long long int x=q.front();
		q.pop();
		ans=(long long int)max(ans,dis[x]+v[x]);
		for(i=first[x];i!=-1;i=next[i])
		{
			dis[to[i]]=(long long int)max(dis[to[i]],dis[x]+v[x]);
			c[to[i]]--;
			if(c[to[i]]==0)
				q.push(to[i]); 
		}
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
