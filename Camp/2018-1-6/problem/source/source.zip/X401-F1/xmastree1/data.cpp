#include<bits/stdc++.h>
using namespace std;
int main()
{
	srand(time(0));
	int n=500,q=500,t=0;
	printf("%d %d %d\n",n,q,t);
	for(int i=1;i<=n;++i)printf("%d ",rand()%n+1);
	puts("");
	for(int i=2;i<=n;++i)
		printf("%d %d\n",i,rand()%(i-1)+1);
	for(int i=1;i<=q;++i)
	{
		int opt=rand()%2+1;
		printf("%d ",opt);
		if(opt==1)
		{
			int x=rand()%n+1,l=rand()%n+1,r=rand()%n+1;
			if(l>r)swap(l,r);
			printf("%d %d %d\n",x,l,r);
		}
		else
		{
			int x=rand()%n+1,k=rand()%n+1;
			printf("%d %d\n",x,k);
		}
	}
	return 0;
}
