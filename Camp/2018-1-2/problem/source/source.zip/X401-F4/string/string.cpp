#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define maxn 1000010
inline int read(){
	int ret=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ret=ret*10+ch-'0';
		ch=getchar();
	}
	return ret*f;
}
int cnt=0;
int p[maxn];
bool vis[100];
char s[maxn],str[maxn];
int manacher(int len){
	s[0]='$';
	s[1]='#';
	for(int i=1;i<=len;++i){
		int ch=str[i]-'a';
		if(!vis[ch]){
			++cnt;
			vis[ch]=1;
		}
		s[i<<1]=ch;
		s[i<<1|1]='#';
	}
	int ans=0;
	len=len<<1|1;
	int id=0,mx=0;
	for(int i=1;i<=len;++i){
		int j=(id<<1)-i;
		p[i]=i<mx?min(p[j],mx-i):1;
		while(s[i+p[i]]==s[i-p[i]])++p[i];
		if(i>mx){
			id=i;
			mx=i+p[i];
		}
		--p[i];
		ans=max(ans,p[i]);
	}
	return ans;
	
}
void init(){
	memset(vis,0,sizeof(vis));
	memset(str,0,sizeof(str));
	memset(s,0,sizeof(s));
	memset(p,0,sizeof(p));
	cnt=0;
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	T=read();
	while(T--){
		init();
		int n=read();
		scanf("%s",str+1);
		int mx=manacher(n);
		if(mx!=n)printf("1\n");
		else if(cnt<=2){
			printf("-1\n");
		}
		else printf("2\n");
	}
	return 0;
}/*

1
3
xxx
*/
