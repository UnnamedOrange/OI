#include <bits/stdc++.h>
#define N 500010
#define P 1000000009
#define ll long long
using namespace std;
int n,m,b[N],r[N];
ll f[N],s[N];
struct itv{
	int l,r;
	inline bool operator <(const itv &b) const {
		return r<b.r;
	}
}a[N];

template <class Aqua>
inline void read(Aqua &s){
	s=0; char c=getchar();
	while (!isdigit(c)) c=getchar(); // -?
	while (isdigit(c)) s=s*10+c-'0',c=getchar();
}

int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	read(n),read(m);
	for (int i=1;i<=n;i++)
		read(a[i].l),read(a[i].r);
	for (int i=1;i<=m;i++)
		read(b[i]);
	sort(a+1,a+1+n);
	sort(b+1,b+1+m);
	for (int i=1;i<=n;i++)
		r[i]=a[i].r;
	int pos;
	for (int i=1;i<=n;i++){
		int pos=lower_bound(b+1,b+1+m,a[i].l)-b;
		pos--; f[i]=0;
		if (!pos) f[i]++;
		pos=lower_bound(r+1,r+1+i,b[pos])-r;
		f[i]=(s[i-1]-s[pos-1]+P+f[i])%P;
		s[i]=(s[i-1]+f[i])%P;
	}
	ll ans=0;
	for (int i=1;i<=n;i++)
		if (a[i].r>=b[m])
			ans=(ans+f[i])%P;
	printf("%lld\n",ans);
	return 0;
}
