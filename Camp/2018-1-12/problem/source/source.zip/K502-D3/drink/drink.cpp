#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <set>
#define ele int
#define fi first
#define se second
using namespace std;
#define maxn 1000010
ele n,K,a[maxn],l1[maxn],l2[maxn];
long double bin[maxn];
pair<ele,ele> p[maxn];
set<ele> S;
int main(){
	freopen("drink.in","r",stdin); freopen("drink.out","w",stdout);
	scanf("%d",&n);
	ele mx=0;
	for (int i=0; i<n; ++i) scanf("%d",a+i),mx=max(mx,a[i]),p[i]=make_pair(a[i],i);
	K=log((long double)mx/n*100)/log(2.0)+45;
	bin[0]=1;
	for (int i=1; i<=K; ++i) bin[i]=bin[i-1]/2;
	sort(p,p+n);
	S.clear();
	S.insert(-1); S.insert(n);
	long double ans=0;
	for (int r=n-1; ~r; --r){
		set<ele>::iterator it1=S.upper_bound(p[r].se),it2=it1;
		ele cnt1=0,cnt2=0;
		do{
			--it1;
			l1[cnt1++]=p[r].se-*it1;
		}while (cnt1<K && it1!=S.begin());
		for (int i=cnt1-1; ~i; --i) l1[i]-=l1[i-1];
		while (cnt2<K && it2!=S.end()) l2[cnt2++]=*(it2++)-p[r].se;
		for (int i=cnt2-1; ~i; --i) l2[i]-=l2[i-1];
		for (int i=0; i<cnt1; ++i)
			for (int j=0; j<cnt2; ++j)
				ans+=bin[i+j+1]*l1[i]*l2[j]*p[r].fi/n/n;
		S.insert(p[r].se);
	}
	printf("%Lf\n",ans);
	return 0;
}