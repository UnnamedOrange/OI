#include<iostream>
#include<cstdio>
#define mod 998244353
#define maxn 100010
using namespace std;
int n,m,K,a[maxn],ans;
int Pow(int x,int y){
	int res=1;
	while(y){
		if(y&1)res=1LL*res*x%mod;
		x=1LL*x*x%mod;
		y>>=1;
	}
	return res;
}
int count(){
	int res=0;
	for(int i=1;i<=m;i++){
		res+=Pow(a[i],K);
		if(res>=mod)res-=mod;
	}
	return res;
}
void dfs(int l,int r,int step){
	if(step==n){
		ans+=count();
		if(ans>=mod)ans-=mod;
		return;
	}
	if(n-step>m-r)return;
	for(int i=l+1;i<=m;i++)
		for(int j=max(i,r+1);j<=m;j++){
			for(int k=i;k<j;k++)a[k]++;
			dfs(i,j,step+1);
			for(int k=i;k<j;k++)a[k]--;
		}
}
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("segment.in","r",stdin);freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	if(n>m){puts("0");return 0;}
	for(int i=1;i<=m;i++){
		for(int j=i;j<=m;j++){
			for(int k=i;k<j;k++)a[k]++;
			dfs(i,j,1);
			for(int k=i;k<j;k++)a[k]--;
		}
	}
	printf("%d",ans);
	return 0;
}
