/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 50 + 10;

int ans, n, m;
char s[MAXN][MAXN];
int t[MAXN];

inline void dfs(int cur) {
	if (cur == m + 1) {
		for (int i = 1; i <= m; ++i)
			t[2 * m + 1 - i] = (t[i] ^ 1);
		for (int i = 1; i <= n; ++i) {
			int len = strlen(s[i] + 1);
			bool able = false ;
			for (int j = 1; j + len - 1 <= 2 * m; ++j) {
				bool flag = true ;
				for (int k = j; k <= j + len - 1; ++k)
					if (s[i][k - j + 1] != t[k] + '0') {
						flag = false;
						break ;
					}
				if (flag) {
					able = true ;
					break ;
				}
			}
			if (!able) return ;
		}
		ans++;
		return ;
	}
	t[cur] = 0, dfs(cur + 1);
	t[cur] = 1, dfs(cur + 1);
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) scanf("%s", s[i] + 1);
	dfs(1), std::cout << ans;
	return 0;
}
