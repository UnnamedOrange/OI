#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define F first
#define S second
#define PII pair<int, int>
const int INF = 0x3f3f3f3f;
using namespace std;
const int MAXN = 100010;
const LL p = 1000000007LL;
const int c = 27;
int T;
int n;
char s[MAXN];
LL h1[MAXN], h2[MAXN], pc[MAXN];
LL geth(LL *h, int l, int r){
	return (h[r] - h[l - 1] * pc[r - l + 1] % p + p) % p;
}
LL q1(int l, int r){
	return geth(h1, l, r);
}
LL q2(int l, int r){
	return geth(h2, n - r + 1, n - l + 1);
}

int main(){
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &T);
	pc[0] = 1;
	for(int i = 1; i <= 100000; i++) pc[i] = pc[i - 1] * c % p;
	while(T--){
		scanf("%d", &n);
		scanf("%s", s + 1);
		
		
		bool flag = false;
		for(int i = 1; i <= n; i++) if(s[i] != s[n - i + 1]){
			flag = true;
			break;
		}
		if(flag){
			puts("1");
			continue;
		}
		
		flag = false;
		for(int i = 2; i <= n; i++) if(s[i] != s[i - 1]){
			flag = true;
			break;
		}
		if(!flag){
			puts("-1");
			continue;
		}
		if(!(n & 1)){
			puts("2");
			continue;
		}
		
		flag = false;
		for(int i = 3; i <= n; i += 2){
			if(s[i] != s[1] || s[i + 1] != s[2]){
				flag = true;
				break;
			}
		}
		if(!flag){
			puts("-1");
			continue;
		}
		
		flag = false;
		for(int i = 2; i <= n / 2; i++){
			if(s[i] != s[1] || s[n - i + 1] != s[n]){
				flag = true;
				break;
			}
		}
		if(!flag){
			puts("-1");
			continue;
		}
		puts("2");
	}
	return 0;
}
