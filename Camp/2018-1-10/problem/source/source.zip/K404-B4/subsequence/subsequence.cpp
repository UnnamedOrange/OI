#include <bits/stdc++.h>
using namespace std;
int a[301],b[301],n,m,k,ret[301];
int main() {
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		a[i]--;
	}
	for(int i=0;i<m;i++)
	{
		cin>>b[i];
		b[i]--;
	}
	for(int i=1;i<=max(n,m);i++)
	{
		for(int j=0;j<(1<<i);j++)
		{
			int k2=0,k3=0;
			for(int k1=0;k1<n&&k2<i;k1++,k2++)
			{
				while(a[k1]!=((j>>k2)&1)&&k1<n&&k2<i)k1++;
			}
			for(int k1=0;k1<n&&k3<i;k1++,k3++)
			{
				while(a[k1]!=((j>>k3)&1)&&k1<m&&k3<i)k1++;
			}
			if(k2!=i&&k3!=i)
			{
				cout<<i<<endl;
				exit(0);
			}
		}
	}
	return 0;
}
/*

*/

