#include <bits/stdc++.h>
using namespace std;
int prime[1000100], tot, book[1000100], mu[1000100], num[1000100], d[1000100], sum[1000100];
int main() {
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	ios::sync_with_stdio(false);
	int T;
	cin >> T;
	num[1]=1, mu[1]=1;
	for (int i=2;i<=1000000;i++) {
		if (!book[i]) prime[++tot]=i,num[i]=2,mu[i]=-1,d[i]=1;
		for (int j=1;j<=tot&&prime[j]*i<=1000000;j++) {
			book[prime[j]*i]=true;
			if (i%prime[j]==0) {
				d[i*prime[j]]=d[i]+1;
				num[prime[j]*i]=num[i]/(d[i]+1)*(d[i]+2);
				mu[i*prime[j]]=0;
				break;
			} 
			num[prime[j]*i]=num[i]*2;
			d[i*prime[j]]=1;
			mu[i*prime[j]]=-mu[i];
		}
	}
	while (T--) {
		int n;
		cin >> n;
		int sum=0;
		for (int i=1;i<=n;i++) {
			for (int j=1;j*j<=i;j++) {
				if (i%j==0) {
					sum+=mu[j]*num[i/j]*num[i/j];
					if (j*j!=i) sum+=mu[i/j]*num[j]*num[j];
				}
			}
		}
		cout << sum << endl; 
	}
	return 0;
}
