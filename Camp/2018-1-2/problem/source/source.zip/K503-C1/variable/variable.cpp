# include<bits/stdc++.h>
# define 	N 		100010
# define 	inf 	1e9
# define 	ll 		long long
using namespace std;
ll n,m,p,q,r[N],x[N],y[N],z[N],a[N],b[N],c[N],d[N],e[N],f[N],qx[N],qy[N],num[N],ans;
void check(){
	for (ll i=1; i<=q; i++){
		if (r[i]==0&&(!(num[qx[i]]<=num[qy[i]]))) return;
		if (r[i]==1&&(!(num[qx[i]]==num[qy[i]]))) return;
		if (r[i]==2&&(!(num[qx[i]]<num[qy[i]]))) return;
	}
	ll now=0;
	for (ll i=1; i<=n; i++)
		now=now+num[i];
	for (ll i=1; i<=p; i++)
		now=now+a[i]*abs(num[x[i]]-num[y[i]])+b[i]*abs(num[y[i]]-num[z[i]])+c[i]*abs(num[z[i]]-num[x[i]])+
				d[i]*(num[x[i]]-num[y[i]])+e[i]*(num[y[i]]-num[z[i]])+f[i]*(num[z[i]]-num[x[i]]);
	ans=min(now,ans);
}
void dfs(ll x){
	if (x>n){
		check();
		return;
	}
	num[x]=m;dfs(x+1);
	num[x]=-m;dfs(x+1);
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	ll opt,ca=1;
	for (scanf("%lld",&opt); ca<=opt; ca++){
		scanf("%lld%lld%lld%lld",&n,&m,&p,&q);
		for (ll i=1; i<=p; i++)
			scanf("%lld%lld%lld%lld%lld%lld%lld%lld%lld",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for (ll i=1; i<=q; i++)
			scanf("%lld%lld%lld",&qx[i],&qy[i],&r[i]);
		ans=inf;
		dfs(1);
		printf("%lld\n",ans);
	}
}
