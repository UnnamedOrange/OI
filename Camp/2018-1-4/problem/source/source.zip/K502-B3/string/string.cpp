#include <stdio.h>
#include <string.h>

const int mod=998244353;
char s[7][101],a[1001];
long long int len[7];
long long int n,m,ans=0;

inline long long int read()
{
    char ch;
    bool flag = false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

bool check()
{
	long long int i;
	for(i=1;i<=m;i++)
	{
		if(a[i]=='0')
			a[2*m-i+1]='1';
		else
			a[2*m-i+1]='0';
	}
	long long int j,k;
	for(i=1;i<=n;i++)
	{
		bool flag=0;
		for(j=1;j<=2*m-len[i]+1;j++)
		{
			bool temp=0;
			for(k=j;k<=j+len[i]-1;k++)
			{
				if(a[k]!=s[i][k-j])
				{
					temp=1;
					break;
				}
			}
			if(temp==0)
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
			return 0;
	}
	return 1;
}

void dfs(long long int x)
{
	if(x==m+1)
	{
		if(!check())
			return;
		ans=(ans+1)%mod;
		return;
	}
	a[x]='0';
	dfs(x+1);
	a[x]='1';
	dfs(x+1);
}

long long int ksm(long long int x,long long int y)
{
	long long int temp=1;
	while(y)
	{
		if(y%2==1)
			temp=(temp*x)%mod;
		x=(x*x)%mod;
		y=y/2; 
	}
	return temp;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	n=read(),m=read();
	long long int i; 
	for(i=1;i<=n;i++)
	{
		gets(s[i]);
		len[i]=strlen(s[i]);
	}
	if(m<=15)
	{ 
		dfs(1);
		printf("%lld",ans%mod);
	}
	else
		printf("%lld",ksm(2,m-len[1]+1));
	fclose(stdin);
	fclose(stdout);
	return 0;
}
