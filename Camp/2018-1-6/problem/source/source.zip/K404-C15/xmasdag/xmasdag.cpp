#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 100005, P = 998244353;
int n, m, k, pw[N];
int ecnt, adj[N], nxt[2 * N], go[2 * N];
int dp[2005][2005], dp2[N], cnt[N];
bool vis[2005][2005], vis2[N];

int qpow(ll a, ll x){
	ll ret = 1;
	while(x){
		if(x & 1) ret = ret * a % P;
		a = a * a % P;
		x >>= 1;
	}
	return ret;
}
void add(int u, int v){
	go[++ecnt] = v;
	nxt[ecnt] = adj[u];
	adj[u] = ecnt;
}
int naive_dfs(int u, int j){
	if(vis[u][j]) return dp[u][j];
	if(j) 
		for(int e = adj[u], v; e; e = nxt[e])
			dp[u][j] = (dp[u][j] + naive_dfs(go[e], j - 1)) % P;
	return vis[u][j] = 1, dp[u][j];
}
int naive_dfs2(int u){
	if(vis2[u]) return dp2[u];
	for(int e = adj[u], v; e; e = nxt[e]){
		v = go[e];
		dp2[u] = (dp2[u] + (naive_dfs2(v) + cnt[v]) % P) % P;
		cnt[u] = (cnt[u] + cnt[v]) % P;
	}
	return vis2[u] = 1, dp2[u];
}

int main(){
	
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	
	read(n), read(m), read(k);
	if(n <= 2000 && m <= 2000){
		dp[1][0] = 1, vis[1][0] = 1;
		for(int i = 1; i <= n; i++)
			pw[i] = qpow(i, k);
		for(int i = 1, u, v; i <= m; i++)
			read(u), read(v), add(v, u);
		for(int i = 1; i <= n; i++){
			int res = 0;
			for(int j = 0; j <= n; j++)
				res = (res + (ll)naive_dfs(i, j) * pw[j]) % P;
			write(res), enter;
		}
		return 0;
	}
	if(k == 1){
		dp2[1] = 0, vis2[1] = 1, cnt[1] = 1;
		for(int i = 1, u, v; i <= m; i++)
			read(u), read(v), add(v, u);
		for(int i = 1; i <= n; i++)
			write(naive_dfs2(i)), enter;
		return 0;
	}
	
	return 0;
}
/*
6 9 1
1 2
1 3
1 4
3 2
3 5
4 5
5 2
2 6
5 6
*/
