#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
int n,m,t,a[maxn],x,y,z,thi,u,f[maxn],tim,b[maxn],ll[maxn],rr[maxn],lastans,ha[5010];
int i,j,k;
int r,f1[maxn],f2[maxn],f3[maxn];
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void dfs(int x,int fa){
	int i=f1[x];
	tim++; f[x]=tim;
	ll[x]=tim;
	while (i!=0){
		if (f2[i]!=fa) dfs(f2[i],x);
		i=f3[i];	
	}
	rr[x]=tim;
}
void work1(int x,int y,int z){
	int i,ans=0;
	memset(ha,0,sizeof(ha));
	for (i=ll[x];i<=rr[x];i++) ha[b[i]]=1;
	for (i=y;i<=z;i++) ans=ans+ha[i];
	printf("%d\n",ans);
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read(); m=read(); t=read();
	for (i=1;i<=n;i++){
		a[i]=read();
	}
	for (i=1;i<=n-1;i++){
		x=read(); y=read();
		r++; f2[r]=y; f3[r]=f1[x]; f1[x]=r;
		r++; f2[r]=x; f3[r]=f1[y]; f1[y]=r;
	}
	dfs(1,0);
	for (i=1;i<=n;i++){
		b[f[i]]=a[i];
	}
	lastans=0;
	for (i=1;i<=m;i++){
		thi=read();
		if (thi==1){
			x=read(); y=read(); z=read();
			if (t==1){
				x=x^lastans;
				y=y^lastans;
				z=z^lastans;
			}
			work1(x,y,z);
		}
		else{
			x=read(); y=read();
			if (t==1){
				x=x^lastans;
				y=y^lastans;
			}
			b[f[x]]=y;
		}
	}
	return 0;
}
