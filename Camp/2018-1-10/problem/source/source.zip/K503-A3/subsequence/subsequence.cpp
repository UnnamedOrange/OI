#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
#define pr pair<int, int>
#define x first
#define y second
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while (!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while (isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n *= sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 4111;
int n, m, k;
int a[N], b[N];

namespace sp{
	int ans;
	int c[N];
	bool check(int x){
		rep(s, 0, (1 << x) - 1){
			rep(i, 1, x) c[i] = ((s >> i - 1) & 1) ? 2 : 1;
			int j = 1, flg = false;
			rep(i, 1, n){
				if (a[i] == c[j]) j++;
				if (j > x) flg = true;
			}
			j = 1;
			rep(i, 1, m){
				if (b[i] == c[j]) j++;
				if (j > x) flg = true;
			}
			if (!flg) return true;
		}
		return false;
	}
	int main(){
		for (ans = 1; ; ans++){
			if (check(ans)) break;
		}
		printf("%d\n", ans);
		return 0;
	}
};

int main(){
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	read(n), read(m), read(k);
	rep(i, 1, n) read(a[i]);
	rep(i, 1, m) read(b[i]);
	if (k == 2){sp::main(); return 0;}
	return 0;
}
