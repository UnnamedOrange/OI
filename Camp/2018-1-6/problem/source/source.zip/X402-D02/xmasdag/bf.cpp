#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<ctime>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
}

namespace bf
{
	typedef long long ll;
	const int N=101000,M=N*2,K=505,MOD=998244353;
	int fact[K],ifact[K];
	int f[N][K];

	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}
	ll C(int n,int m){return (ll)fact[n]*ifact[m]%MOD*ifact[n-m]%MOD;}

	int begin[N],next[M],to[M];
	int n,m,k,e;

	int lim[N];
	void add(int x,int y)
	{
		lim[y]++;
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
	}
	void initialize()
	{
		read(n),read(m),read(k);
		for(int u,v;m--;)read(u),read(v),add(u,v);
		fact[0]=1;
		for(int i=1;i<K;i++)fact[i]=(ll)fact[i-1]*i%MOD;
		ifact[K-1]=inv(fact[K-1]);
		for(int i=K-1;i;i--)ifact[i-1]=(ll)ifact[i]*i%MOD;
	}
	int seq[N],tot;
	void topsort()
	{
		static std::queue<int> Q;
		while(!Q.empty())Q.pop();
		for(int i=1;i<=n;i++)if(!lim[i])Q.push(i);
		for(int p,q;!Q.empty();)
		{
			p=Q.front();Q.pop();
			seq[++tot]=p;
			for(int i=begin[p];i;i=next[i])
			{
				lim[q=to[i]]--;
				if(!lim[q])Q.push(q);
			}
		}
	}
	void dp()
	{
		static int g[K];
		f[seq[1]][0]=1;
		for(int o=1;o<=n;o++)
		{
			int p=seq[o],q;
			for(int i=k;i>=0;i--)
			{
				int res=0;
				for(int j=0;j<=i;j++)
					res=(res+f[p][j]*C(i,j))%MOD;
				g[i]=res;
			}

			for(int i=begin[p];i;i=next[i])
			{
				q=to[i];
				for(int j=0;j<=k;j++)
					f[q][j]=(f[q][j]+g[j])%MOD;
			}
		}
	}
	void solve()
	{
		initialize();
		topsort();
		dp();
		for(int i=1;i<=n;i++)
			printf("%d\n",f[i][k]);
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.ans","w",stdout);
	bf::solve();
	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
