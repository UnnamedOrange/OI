#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
const int N=30005;
typedef long long LL;
LL ans;
int f[N],s[N],w[N],R[N],h[N],id[N],cnt,n,p[N];
struct edge{int v,n;} e[N<<1];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void addedge(int u,int v)
{
	e[cnt]=(edge){v,h[u]},h[u]=cnt++;
	e[cnt]=(edge){u,h[v]},h[v]=cnt++;
}

void dfs(int x,int fa)
{
	f[x]=fa,s[x]=w[x];
	for(int i=h[x]; i!=-1; i=e[i].n)
		if(e[i].v!=fa) dfs(e[i].v,x),s[x]+=s[e[i].v];
}

void solve(int rt)
{
	LL tot=0;
	dfs(rt,0),p[*p=1]=rt;
	rep(i,1,n)
	{
		LL minn=10000000000000;
		int k=0;
		rep(j,1,*p)
		{
			if(!p[j]) continue;
			if(minn>(LL)(i-id[f[p[j]]])*s[p[j]]) minn=(LL)(i-id[f[p[j]]])*s[p[j]],k=j;
		}
		tot+=(LL)(i-id[f[p[k]]])*s[p[k]],id[p[k]]=i;
		for(int j=h[p[k]]; j!=-1; j=e[j].n)
			if(e[j].v!=f[p[k]])
				p[++*p]=e[j].v;
		p[k]=0;
	}
	ans=max(ans,tot);
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	n=getint(),memset(h,-1,sizeof(h));
	rep(i,1,n-1) addedge(getint(),getint());
	rep(i,1,n) w[i]=getint(),R[i]=getint();
	rep(i,1,n) if(R[i]) solve(i);
	printf("%lld\n",ans);
	return 0;
}
