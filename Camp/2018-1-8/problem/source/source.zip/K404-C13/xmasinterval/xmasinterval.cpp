#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

const int N=500005;
const int mod=1000000009;

struct ST{
	int l,r,s,tag;
}t[N<<2];
struct Q{
	int l,r;
}q[N];
int n,m,l,r,sum;
int ls[N],rs[N],x[N];

bool cmp(Q a,Q b){
	return a.l<b.l||(a.l==b.l&&a.r<b.r);
}

void build(int k,int l,int r){
	t[k].tag=1; t[k].l=l; t[k].r=r;
	if (l==r) return;
	int mid=(l+r)>>1;
	build(k<<1,l,mid);
	build(k<<1|1,mid+1,r);
}

void update(int k){
	t[k].s=t[k<<1].s+t[k<<1|1].s;
}

void mul(int k,int x){
	t[k].tag=1ll*t[k].tag*x%mod;
	t[k].s=1ll*t[k].s*x%mod;
}

void pushdown(int k){
	if (t[k].tag!=1){
		mul(k<<1,t[k].tag);
		mul(k<<1|1,t[k].tag);
		t[k].tag=1;
	}
}

void modifym(int k,int L,int R,int x){
	if (L<=t[k].l&&t[k].r<=R){
		mul(k,x);
		return;
	}
	pushdown(k);
	int mid=(t[k].l+t[k].r)>>1;
	if (L<=mid) modifym(k<<1,L,R,x);
	if (R>mid) modifym(k<<1|1,L,R,x);
	update(k);
}

void modifyp(int k,int p,int x){
	if (t[k].l==t[k].r){
		t[k].s=(t[k].s+x)%mod;
		return;
	}
	pushdown(k);
	int mid=(t[k].l+t[k].r)>>1;
	if (p<=mid) modifyp(k<<1,p,x);
	else modifyp(k<<1|1,p,x);
	update(k);
}

int query(int k,int L,int R){
	if (L<=t[k].l&&t[k].r<=R) return t[k].s;
	pushdown(k);
	int mid=(t[k].l+t[k].r)>>1;
	if (R<=mid) return query(k<<1,L,R);
	else if (L>mid) return query(k<<1|1,L,R);
	else return query(k<<1,L,R)+query(k<<1|1,L,R);
}

int read(){
	int num=0; char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		num=num*10+c-'0';
		c=getchar();
	}
	return num;
}

int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	int i;
	n=read(); m=read();
	for (i=1;i<=n;i++) q[i].l=read(),q[i].r=read();
	sort(q+1,q+1+n,cmp);
	for (i=1;i<=m;i++) x[i]=read();
	x[++m]=0; sort(x+1,x+1+m);
	m=unique(x+1,x+1+m)-x-1;
	for (i=1;i<=n;i++){
		ls[i]=lower_bound(x+1,x+1+m,q[i].l)-x;
		rs[i]=lower_bound(x+1,x+1+m,q[i].r+1)-x-1;
	}
	build(1,1,m);
	modifyp(1,1,1);
	for (i=1;i<=n;i++){
		if (ls[i]-1<=rs[i]){
			sum=query(1,ls[i]-1,rs[i]);
			modifyp(1,rs[i],sum);
		}
		if (rs[i]<m) modifym(1,rs[i]+1,m,2);
	}
	printf("%d\n",query(1,m,m));
	return 0;
}
