#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define mod 1000000009
#define inf 1000000007
#define ll long long
#define N 500010

char xB[1<<15],*xS=xB,*xTT=xB;
#define getc() (xS==xTT&&(xTT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xTT)?0:*xS++)
#define isd(c) (c>='0'&&c<='9')
inline int rd(){
	char xchh;
	int xaa;
	while(xchh=getc(),!isd(xchh));(xaa=xchh-'0');
	while(xchh=getc(),isd(xchh))xaa=xaa*10+xchh-'0';return xaa;
}
/*
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}*/
int n,m,a[N];
struct qaz{int l,r;}e[N];
bool cmp(qaz a,qaz b){return a.l<b.l;}
int getl(int x)
{
	int l=0,r=m+1,mid,p;
	while(l<=r)
	{
		mid=l+r>>1;
		if(a[mid]>=x) p=mid,r=mid-1;
		else l=mid+1;
	}
	return p;
}
int getr(int x)
{
	int l=0,r=m+1,mid,p;
	while(l<=r)
	{
		mid=l+r>>1;
		if(a[mid]<=x) p=mid,l=mid+1;
		else r=mid-1;
	}
}
int lz[N<<2];
#define ls p<<1
#define rs p<<1|1
inline int Mod(int x,int y){x+=y;if(x>=mod) x-=mod;return x;}
void add(int p,int l,int r,int L,int R,int v)
{
	if(l==L&&R==r)
	{
		lz[p]=Mod(lz[p],v);
		return;
	}
	int mid=l+r>>1;
	if(R<=mid) add(ls,l,mid,L,R,v);
	else if(L>mid) add(rs,mid+1,r,L,R,v);
	else add(ls,l,mid,L,mid,v),add(rs,mid+1,r,mid+1,r,v);
}
int fd(int p,int l,int r,int x)
{
	if(l==r) return lz[p];
	int mid=l+r>>1;
	return Mod(x<=mid?fd(ls,l,mid,x):fd(rs,mid+1,r,x),lz[p]);
}
int main()
{
	//*
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);//*/
	n=rd();m=rd();
	for(int i=1;i<=n;i++) e[i].l=rd(),e[i].r=rd();
	for(int i=1;i<=m;i++) a[i]=rd();
	sort(a+1,a+m+1);a[m+1]=inf;
	for(int i=1;i<=n;i++)
	{
		e[i].l=getl(e[i].l)+1;
		e[i].r=getr(e[i].r)+1;
	}
	sort(e+1,e+n+1,cmp);
	m+=2;
	add(1,1,n,1,1,1);
	for(int i=1,x;i<=n;i++)
	{
		x=fd(1,1,m,e[i].l-1);
		add(1,1,m,e[i].l,e[i].r,x);
	}
	printf("%d\n",fd(1,1,m,m-1));
	return 0;
}