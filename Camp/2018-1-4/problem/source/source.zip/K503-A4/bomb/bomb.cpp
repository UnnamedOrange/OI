#include <bits/stdc++.h>
using namespace std;
const int MAXN = 10;

inline bool valid(int S, int N, bool G[][MAXN+10]) {
	for(int i=1; i<=N; i++)
		for(int j=1; j<=N; j++)
			if(i!=j && (S & (1<<(i-1))) && (S & (1<<(j-1))))
				if(G[i][j]) return false;
	return true;
}

int N, M;

inline void Work10() {
	int e_ptr, vis[(1<<MAXN)+10], dist[(1<<MAXN)+10]; 
	bool G[MAXN+10][MAXN+10];
	int u, v;
	for(int i=1; i<=N; i++) G[i][i]=true;
	for(int i=1; i<=M; i++) {
		scanf("%d%d", &u, &v);
		G[u][v]=true;
	}
	for(int k=1; k<=N; k++)
		for(int i=1; i<=N; i++)
			for(int j=1; j<=N; j++)
				G[i][j] = G[i][j] || (G[i][k] && G[k][j]);
	
	queue<int> Q;
	vis[0]=true; dist[0]=0; Q.push(0);
	while(!Q.empty()) {
		int u = Q.front(); Q.pop();
		for(int i=1; i<(1<<N); i++) 
			if(valid(i, N, G)) {
				int v = (u|i);
				if(vis[v]) continue;
				vis[v]=true; dist[v]=dist[u]+1;
				Q.push(v);
			}
	}
	printf("%d", dist[(1<<N)-1]);
}

void WorkNonCycle() {
	puts("gg");
}

int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	scanf("%d%d", &N, &M);
	if(N<=10) Work10();
	else WorkNonCycle();
	return 0;
}
