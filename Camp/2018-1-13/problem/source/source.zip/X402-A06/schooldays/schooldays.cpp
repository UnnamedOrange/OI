#include<bits/stdc++.h>

#define ll long long
#define inf 999999999
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 1000010;

int n, c[maxn], d[maxn];

void Get(){
	n = read();
	For(i, 1, n) c[i] = read(), d[i] = read();
}

const int mod = 1e9 + 7;

int dp[maxn], Max[maxn];

void solve_bf(){
	For(i, 0, n + 1) Max[i] = -1;
	Max[0] = 0;
	dp[0] = 1;

	For(i, 1, n){
		int cnt = 0, least = 0, most = inf, nowpos = -1, flag = 0;
		rep(j, i, 1){
			++ cnt;
			least = max(least, c[j]);
			most = min(most, d[j]);

			if(cnt > most) break;
			nowpos = j;

			if(Max[j-1] == -1) continue;

			if(cnt >= least && cnt <= most){
				if(!flag) flag = j;
				if(Max[i] == -1){
					Max[i] = Max[j-1] + 1;
					(dp[i] += dp[j-1]) %= mod;
				}
				else{
					if(Max[j-1] + 1 > Max[i]){
						Max[i] = Max[j-1] + 1;
						dp[i] = dp[j-1] % mod;
					}
					else if(Max[j-1] + 1 == Max[i]){
						(dp[i] += dp[j-1]) %= mod;
					}
				}
			}
		}
	}

	if(Max[n] == -1){printf("-1\n"); return;}
	printf("%d %d\n", Max[n], dp[n]);
}
/*
int tree[maxn << 2], root[maxn], sum[maxn], ls[maxn], rs[maxn], tot, minn[maxn][21], maxx[maxn][21];

void build(int h,int l,int r){
	tree[h] = -1;
	if(l == r) return;

	int mid = l+r >> 1;
	build(h<<1, l, mid);
	build(h<<1|1, mid+1, r);
}

void rmq(){
	For(i, 1, n) minn[i][0] = d[i], maxx[i][0] = c[i];
	For(j, 1, 19){
		For(i, 1, n){
			if(i + (1 << j) > n + 1) break;
			minn[i][j] = min(minn[i][j-1], minn[i+(1<<j-1)][j-1]);
			maxx[i][j] = max(maxx[i][j-1], maxx[i+(1<<j-1)][j-1]);
		}
	}
}

void pre_work(){
	rmq();
	build(1, 0, n);
}

int askmin(int l,int r){
	int k = log2(r - l + 1);
	return min(minn[l][k], minn[r-(1<<k)+1][k]);
}

int askmax(int l,int r){
	int k = log2(r - l + 1);
	return max(maxx[l][k], maxx[r-(1<<k)+1][k]);
}

int efl(int h){
	int l = 1, r = h, Ans = -1;
	while(l <= r){
		int mid = l+r >> 1;
		int nowmax = askmax(mid, h), nowmin = askmin(mid, h), nowcnt = h - mid + 1;
		if(nowcnt >= nowmax && nowcnt <= nowmin){
			Ans = mid;
			r = mid-1;
		}
		else if(nowcnt < nowmax) r = mid-1;
		else l = mid+1;
	}
	
	return Ans;
}

int efr(int h){
	int l = 1, r = h, Ans = -1;
	while(l <= r){
		int mid = l+r >> 1;
		int nowmax = askmax(mid, h), nowmin = askmin(mid, h), nowcnt = h - mid + 1;
		if(nowcnt >= nowmax && nowcnt <= nowmin){
			Ans = mid;
			l = mid+1;
		}
		else if(nowcnt < nowmax) r = mid-1;
		else l = mid+1;
	}

	return Ans;
}
//remember to larger the shuzu
int mo(int x){
	if(x >= mod) x -= mod; 
	return x;
}

void insertMax(int h,int l,int r,int pos,int val){
	if(l == r){
		tree[h] = val;
		return ;
	}

	int mid = l+r >> 1;
	if(pos <= mid) insertMax(h<<1, l, mid, pos, val);
	else insertMax(h<<1|1, mid+1, r, pos, val);

	tree[h] = max(tree[h<<1], tree[h<<1|1]);
}

int queryMax(int h,int l,int r,int s,int e){
	if(l == s && r == e) return tree[h];
	int mid = l+r >> 1;
	if(e <= mid) return queryMax(h<<1, l, mid, s, e);
	else if(s > mid) return queryMax(h<<1|1, mid+1, r, s, e);
	else return max(queryMax(h<<1, l, mid, s, mid), queryMax(h<<1|1, mid+1, r, mid+1, e));
}

void insertdp(int &h,int l,int r,int pos,int val){
	if(!h) h = ++ tot;
	if(l == r){
		sum[h] = val;
		return;
	}

	int mid = l+r >> 1;
	if(pos <= mid) insertdp(ls[h], l, mid, pos, val);
	else insertdp(rs[h], mid+1, r, pos, val);

	sum[h] = mo(sum[ls[h]] + sum[rs[h]]);
}

int querydp(int h,int l,int r,int s,int e){
	if(!sum[h]) return 0;
	if(l == s && r == e) return sum[h];

	int mid = l+r >> 1;
	if(e <= mid) return querydp(ls[h], l, mid, s, e);
	else if(s > mid) return querydp(rs[h], mid+1, r, s, e);
	else return mo(querydp(ls[h], l, mid, s, mid) + querydp(rs[h], mid+1, r, mid+1, e));
}
//remember to add inline
int ef(int h){
	int l = 1, r = h, Ans = -1;
	while(l <= r){
		int mid = l+r >> 1;
		if(h - mid + 1 <= askmin(mid, h)){
			Ans = mid;
			r = mid-1;
		}
		else l = mid+1;
	}

	return Ans;
}

void failure(){
	//区间不连续
	int ans = 0, ansmax = -1;

	For(i, 1, n){
		int l = efl(i);
		int r = efr(i);
		if(l == -1 || r == -1) continue;

		int nowmax = queryMax(1, 0, n, l-1, r-1);
		if(nowmax == -1) continue;

		int Ans = querydp(root[nowmax], 0, n, l-1, r-1);
		insertMax(1, 0, n, i, nowmax+1);

		if(i != n) insertdp(root[nowmax+1], 0, n, i, Ans);
		else ans = Ans, ansmax = nowmax + 1;
	}

	if(ansmax == -1){ printf("-1\n"); return;}
	else printf("%d %d\n", ansmax, ans);
}

int q[maxn];

struct node{
	int val;
};

set<int> MAX[maxn], big;

void failure2(){

	pre_work();

	insertMax(1, 0, n, 0, 0);
	insertdp(root[0], 0, n, 0, 1);

	int ans = 0, ansmax = -1;

	int l = 1, r = 0;

	For(i, 1, n){
		int nowl = ef(i);
		while(l <= r && c[q[r]] <= c[i]){
			big.erase(Max[q[r]]);
			MAX[Max[q[r]]].erase(dp[q[r]]);
			-- r;
		}
		while(l <= r && q[l] < nowl){
			big.erase(Max[q[l]]);
			MAX[Max[q[l]]].erase(dp[q[l]]);
			++ l;
		}

		if(l < r){
			
		}
	}

	if(ansmax == -1){printf("-1\n"); return;}
	else printf("%d %d\n", ansmax, ans);
}


int q[maxn];

void solve(){
	pre_work();
	int l = 1, r = 0;
	insertMax(1, 0, n, 0, 0);
	insertdp(root[0], 0, n, 0, 1);

	For(i, 1, n){
		int nowl = ef(i);
		while(l <= r && c[q[r]] <= c[i]) -- r;
		while(l <= r && i - q[r] + 1 >= c[q[r]]) -- r;
		while(l <= r && q[l] < nowl) ++ l;
		q[++r] = i;
		int nowmax = -1;
		For(j, l, r-1){
			if(q[l] <= h - q[r+1] + 1) 
				nowmax = max(nowmax, queryMax(1, 0, n, q[l], h - q[r]));
		}

		if(nowmax == -1) continue;
		if(l <= r) nowmax = max(nowmax, queryMax(1, 0, n, nowl-1, 
	}
}
*/
int main(){

	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
