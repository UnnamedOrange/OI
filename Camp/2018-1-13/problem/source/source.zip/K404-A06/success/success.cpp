#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
#define ll long long
using namespace std;
const int mod=1e9+7;
ll s;int n,m,t,f[110][110];
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	cin>>s>>t>>n>>m;
	f[0][0]=1;
	for(int i=1;i<=m;++i) {
		if(i<=n){
			for(int k=0;k<=s;++k)
				for(int j=1;j<=t&&j<=k;++j)
					(f[i][k]+=f[i-1][k-j])%=mod;
		}else{
			for(int k=0;k<=s;++k)
				for(int j=1;j<=k;++j)
					(f[i][k]+=f[i-1][k-j])%=mod;
		}
	}
	int ans=0;
	for(int i=0;i<=s;++i)(ans+=f[m][i])%=mod;
	printf("%d\n",ans);
}
