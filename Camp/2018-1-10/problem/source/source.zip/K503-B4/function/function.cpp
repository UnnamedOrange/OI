#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const int maxn=1e6+5;
int T,n,val[maxn],ask[maxn],mu[maxn],pi[maxn],num;
ll val2[maxn],sum[maxn];
bool vis[maxn];
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	read(T);
	int Max=0;
	for(int i=1;i<=T;i++)
	{
		read(ask[i]);
		if(ask[i]>Max)
			Max=ask[i];
	}
	if(Max<maxn)
	{
		for(int i=1;i<maxn;i++)
			for(int v=i;v<maxn;v+=i)
				++val[v];
		mu[1]=1;
		for(int i=2;i<maxn;i++)
		{
			if(!vis[i])
			{
				pi[++num]=i;
				mu[i]=-1;
			}
			for(int v=1;v<=num&&pi[v]*i<maxn;v++)
			{
				vis[i*pi[v]]=true;
				if(i%pi[v]==0)
					break;
				mu[i*pi[v]]=mu[i]*(-1);
			}
		}
		for(int i=1;i<maxn;i++)
			for(int v=i,t=1;v<maxn;v+=i,t++)
				val2[v]+=mu[i]*val[t]*val[t];
		for(int i=2;i<maxn;i++)
		{
			val2[i]+=val2[i-1];
		}
		for(int i=1;i<=T;i++)
		{
			printf("%lld\n",val2[ask[i]]);
		}
	}
	else
	{
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
