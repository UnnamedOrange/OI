#include<cstdio>
#include<cstring>
#include<algorithm>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
using namespace std;
const int maxn = 15;
int stmax, n, k, p = 1, flag, ans;
int mp[maxn][maxn], vis[maxn];
void dfs(int st, int u, int step) {
	if(flag) return;
	vis[u] = 1;
	For(v, 1, n) {
		if(!mp[u][v]) continue;
		if(v == st && step == k) {flag = 1; return;}
		if(!vis[v]) dfs(st, v, step + 1);
	}
	vis[u] = 0;
}
int main() {
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	scanf("%d%d", &n, &k), stmax = (1 << ((n - 1) * n / 2)) - 1;
	For(i, 0, stmax) {
		memset(mp, 0, sizeof(mp)), p = 1;
		For(u, 1, n - 1) For(v, u + 1, n) {
			if(i & p) mp[u][v] = 1;
			else mp[v][u] = 1;
			p <<= 1;
		}
		For(p, 1, n) {
			flag = 0, dfs(p, p, 1);
			if(flag) 
				{++ans;break;}
		}
	}
	printf("%d", ans);
	return 0;
}
