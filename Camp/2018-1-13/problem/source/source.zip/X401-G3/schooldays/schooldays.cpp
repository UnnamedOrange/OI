#include<bits/stdc++.h>
using namespace std;

template <typename T> void chmax(T &x,const T &y)
{
	if(x<y)x=y;
}
template <typename T> void chmin(T &x,const T &y)
{
	if(x>y)x=y;
}
typedef long long ll;
#define rep(i,l,r) for(int i=l;i<=r;++i)
#define per(i,r,l) for(int i=r;i>=l;--i)
const int N=1e6+5,D=1e9+7,inf=1e9;
ll mi(ll x,int y=D-2)
{
	ll ans=1;
	while(y)
	{
		if(y&1)ans=ans*x%D;
		x=x*x%D;y>>=1;
	}
	return ans;
}
struct point
{
	int mx,cnt;
};
point operator +(const point &p1,const point &p2)
{
	if(p1.mx!=p2.mx)return p1.mx>p2.mx?p1:p2;
	return (point){p1.mx,(p1.cnt+p2.cnt)%D};
}
void operator +=(point &p1,const point &p2)
{
	p1=p1+p2;
//	if(p1.mx>=0&&!p1.cnt)
//		int kcz=1;
}
const int T=N*3;
int n,c[N],d[N];
namespace ZKW
{
#define cl (i*2)
#define cr (cl+1)
point a[T];	
int l[T],r[T],mxc[T],mnd[T];
int d;
void init()
{
	for(d=1;d<n;d<<=1);d-=1;
	rep(i,1,n){l[d+i]=r[d+i]=d+i-1;mxc[d+i]=c[i];mnd[d+i]=::d[i];}
	per(i,d,1){l[i]=min(l[cl],l[cr]);r[i]=max(r[cl],r[cr]);mxc[i]=max(mxc[cl],mxc[cr]);mnd[i]=min(mnd[cl],mnd[cr]);}
	rep(i,1,n+d)a[i]=(point){-inf,0};
}
int now,nmxc,nmnd;
point ans;
void dfs(int i)
{
	if(i>d)
	{
		chmax(nmxc,mxc[i]);chmin(nmnd,mnd[i]);
		if(now-(i-1)>=nmxc&&now-(i-1)<=nmnd)ans+=a[i];
		return ;
	}
	if(a[i].mx<ans.mx||l[i]>now-nmxc||r[i]<now-nmnd)
	{
		chmax(nmxc,mxc[i]);chmin(nmnd,mnd[i]);
		return ;
	} 
	if(r[i]<=now-nmxc&&l[i]>=now-nmnd&&mxc[i]<=nmxc&&mnd[i]>=nmnd)
	{
		ans+=a[i];
		return ;
	}
	dfs(cr);dfs(cl);
}
point qiu(int i)
{
	ans.mx=-inf+i*2;
	i+=d;
	now=i;
	nmxc=mxc[i];
	nmnd=mnd[i];
	dfs(i);
	while(i>1)
	{
		if(i&1)dfs(i-1);
		i>>=1;
	}
	++ans.mx;
//	if(ans.mx>0&&!ans.cnt)
//		cout<<now<<endl;
	return ans;
}
void add(int i,const point &ans)
{
	i+=d;
	a[i]=ans;
	while(i>>=1)a[i]+=ans;
}
};
int main()
{
	freopen("schooldays.in","r",stdin);freopen("schooldays.out","w",stdout);
	cin>>n;
	rep(i,1,n)scanf("%d%d",c+i,d+i);
	ZKW::init();
	ZKW::add(1,(point){0,1});
	rep(i,1,n-1)ZKW::add(i+1,ZKW::qiu(i));
	point ans=ZKW::qiu(n);
	if(ans.mx<0)puts("-1");
	else printf("%d %d\n",ans.mx,ans.cnt);
}
