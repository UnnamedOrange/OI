/*+lmake
 * DEFINE += MDEBUG
 * OPTIMIZE = 2
 */
#include <bits/stdc++.h>
#define MODP 998244353
#define MOD(x) ((x)%MODP)
using namespace std;
typedef long long LL;
#define MAXN 100000
int n,m,k;
int a[MAXN+10];
LL qpow(LL x,LL n)
{
    if (n==1) return x;
    LL t=qpow(x,n/2);
    t=MOD(t*t);
    if (n%2!=0) t=MOD(t*x);
    return t;
}
namespace bl
{
LL ans;
LL tab[MAXN+10];
LL getQpow(LL x,LL n)
{
    if (tab[x]>0) return tab[x];
    return tab[x]=qpow(x,n);
}
void calc()
{
    LL nowans=0;
    for(int i=1; i<=m; ++i)
    {
        nowans=MOD(nowans+getQpow(a[i],k));
    }
    ans+=nowans;
}
void dfs(int now,int lmin,int rmin)
{
    if (now>n)
    {
        return calc();
    }
    for(int l=lmin; l<=m; ++l)
    {
        for(int i=l; i<rmin; ++i)
        {
            ++a[i];
        }
        for(int r=max(rmin,l); r<=m; ++r)
        {
            dfs(now+1,l+1,r+1);
            ++a[r];
        }
        for(int i=l; i<=m; ++i)
        {
            --a[i];
        }
    }
}
LL main()
{
    ans=0;
    dfs(1,1,1);
    return ans;
}
}
namespace p1
{
LL main()
{
}
}
int main()
{
#ifndef MDEBUG
    freopen("segment.in","r",stdin);
    freopen("segment.out","w",stdout);
#endif
    cin>>n>>m>>k;
    LL ans;
    ans=bl::main();
    cout<<ans<<endl;
    return 0;
}
