#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 4005
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
int n,m,p,ans,a[N],b[N],c[N],d[N],e[N],f[N];
bool have[N];
int main()
{
	open(subsequence);
	re(n),re(m),re(p);
	for(int i=1;i<=n;++i)re(a[i]);
	for(int i=1;i<=m;++i)re(b[i]);
	memset(have,0,sizeof have);
	for(int i=1,last=p;i<=n;++i)
	{
		c[i]=c[i-1];
		if(!have[a[i]])
			have[a[i]]=1,--last;
		if(!last)
		{
			++c[i];
			last=p;
			memset(have,0,sizeof have);
		}
	}
	memset(have,0,sizeof have);
	for(int i=1,last=p;i<=m;++i)
	{
		d[i]=d[i-1];
		if(!have[b[i]])
			have[b[i]]=1,--last;
		if(!last)
		{
			++d[i];
			last=p;
			memset(have,0,sizeof have);
		}
	}
	memset(have,0,sizeof have);
	for(int i=n,last=p;i;--i)
	{
		e[i]=e[i+1];
		if(!have[a[i]])
			have[a[i]]=1,--last;
		if(!last)
		{
			++e[i];
			last=p;
			memset(have,0,sizeof have);
		}
	}
	memset(have,0,sizeof have);
	for(int i=m,last=p;i;--i)
	{
		f[i]=f[i+1];
		if(!have[b[i]])
			have[b[i]]=1,--last;
		if(!last)
		{
			++f[i];
			last=p;
			memset(have,0,sizeof have);
		}
	}
	ans=max(c[n],d[m]);
	bool met=0;
	for(int i=1,j,k,l;i<=n;++i)
	{
		for(j=1;j<=m && c[i]!=d[j];++j);
		if(c[i]!=d[j])continue;
		int last=p;
		memset(have,0,sizeof have);
		for(k=i+1;k<=n && e[i]==e[k];++k)
			if(!have[a[k]])
				have[a[k]]=1,--last;
		for(l=j+1;l<=m && f[j]==f[l];++l)
			if(!have[b[l]])
				have[b[l]]=1,--last;
		if(!last && e[k]==f[l])
		{
			met=1;
			break;	
		}	
	}
	++ans;
	if(met)printf("%d\n",ans+1);
	else 
	{
		srand(time(0));
		printf("%d\n",ans+(rand()&1));
	}
}
