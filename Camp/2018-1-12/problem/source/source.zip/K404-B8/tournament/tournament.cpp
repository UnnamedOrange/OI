#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl
typedef long long ll;
using namespace std;
const int maxn = 5009;
const int mod = 998244353;

int fac[maxn],inv[maxn],f[maxn];
int n,k;

int C(int x,int y){return 1ll*fac[x]*inv[y]%mod*inv[x-y]%mod;}
int PowerMod(int x,int y)
{
	int res=1;
	while(y)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;y>>=1;
	}return res;
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	fac[1]=inv[1]=inv[0]=1;
	for(int i=2;i<=n;i++) fac[i]=1ll*fac[i-1]*i%mod;
	for(int i=2;i<=n;i++) inv[i]=1ll*(mod-mod/i)*inv[mod%i]%mod;
	for(int i=2;i<=n;i++) inv[i]=1ll*inv[i]*inv[i-1]%mod;
	ll tot=1ll*n*(n-1)/2;
	f[1]=1;f[2]=0;
	for(int i=3;i<=n;i++)
	{
		f[i]=PowerMod(2,1ll*i*(i-1)/2%(mod-1));
		for(int j=1;j<i;j++) f[i]=(f[i]-1ll*C(i,j)*f[j]%mod*PowerMod(2,1ll*(i-j)*(i-j-1)/2%(mod-1))%mod+mod)%mod;
	}
	cout<<f[k]<<endl;
//	cout<<C(n,k)*f[k]%mod*PowerMod(2,(1ll*n*(n-1)/2-1ll*k*(k-1)/2)%(mod-1))%mod<<endl;
	return 0;
}
//655938692*384960822

