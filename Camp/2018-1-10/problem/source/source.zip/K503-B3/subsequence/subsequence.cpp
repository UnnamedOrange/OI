#include <bits/stdc++.h>
using namespace std;

const int Max = 22;

int n, m, k, a[Max], b[Max];

int main() {
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
	}
	for (int i = 1; i <= m; ++i) {
		scanf("%d", &b[i]);
	}
	for (int ans = 1; ans <= max(n, m) + 1; ++ans) {
		bool ok = false;
		for (int S = 0, cur; S < 1<<ans; ++S) {
			cur = 0;
			for (int i = 1; i <= n; ++i) {
				if (a[i] == (S>>cur&1)+1) {
					if (++cur == ans) {
						break;
					}
				}
			}
			if (cur < ans) {
				cur = 0;
				for (int i = 1; i <= m; ++i) {
					if (b[i] == (S>>cur&1)+1) {
						if (++cur == ans) {
							break;
						}
					}
				}
				if (cur < ans) {
					ok = true;
					break;
				}
			}
		}
		if (ok) {
			printf("%d\n", ans);
			break;
		}
	}
	return 0;
}
