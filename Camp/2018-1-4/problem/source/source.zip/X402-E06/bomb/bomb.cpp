#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 1000000;

int st[N + 5], to[N + 5], nxt[N + 5], e = 1;
inline void addedge(int u, int v) {
    to[++ e] = v; nxt[e] = st[u]; st[u] = e;
}

int bel[N + 5], sz[N + 5], scc_cnt;
int dfn[N + 5], low[N + 5], dfs_clock;

void dfs(int u) {
    static int stk[N + 5], top = 0;

    stk[top ++] = u;
    dfn[u] = low[u] = ++ dfs_clock;
    for(int i = st[u]; i; i = nxt[i]) {
        int v = to[i];

        if(!dfn[v]) {
            dfs(v);
            chkmin(low[u], low[v]);
        } else if(!bel[v]) {
            chkmin(low[u], dfn[v]);
        }
    }

    if(dfn[u] == low[u]) {
        ++ scc_cnt;
        do {
            ++ sz[scc_cnt];
            bel[stk[top-1]] = scc_cnt;
        } while(stk[--top] != u);
    }
}

int n, m;
int f[N + 5];
bool vis[N + 5];
pii edge[N + 5];

void dfs_calc(int u) {
    if(vis[u]) return; 
    vis[u] = true;

    f[u] = sz[u];
    for(int i = st[u]; i; i = nxt[i]) {
        int v = to[i];
        dfs_calc(v);
        chkmax(f[u], sz[u] + f[v]);
    }
}

int main() {
    freopen("bomb.in", "r", stdin);
    freopen("bomb.out", "w", stdout);

    read(n), read(m);
    for(int i = 1; i <= m; ++i) {
        static int x, y;
        read(x), read(y);
        addedge(x, y); edge[i] = mp(x, y);
    }
    for(int i = 1; i <= n; ++i) if(!dfn[i]) dfs(i);

    e = 1;
    memset(st, 0, sizeof st);

    for(int i = 1; i <= m; ++i) {
        static int x, y;
        x = edge[i].fst, y = edge[i].snd;
        if(bel[x] != bel[y]) addedge(bel[x], bel[y]);
    }

    int ans = 0;
    for(int i = 1; i <= scc_cnt; ++i) if(!vis[i]) dfs_calc(i), chkmax(ans, f[i]);
    printf("%d\n", ans);

    return 0;
}
