#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while (c = getchar(), c >= '0');
}

const int M = 30005;

int n, Head[M], tot, W[M], R[M], fa[M], P[M];
struct Node {int to, nxt;} Edge[M << 1];

inline void Addedge(int a, int b) {
	Edge[tot] = (Node) {b, Head[a]}; Head[a] = tot++;
	Edge[tot] = (Node) {a, Head[b]}; Head[b] = tot++;
}

void dfs(int x, int f) {
	fa[x] = f;
	for (int i = Head[x]; ~i; i = Edge[i].nxt) {
		int to = Edge[i].to;
		if (to == f) continue;
		dfs(to, x);
	}
}

int main() {
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	Rd(n);
	memset(Head, -1, sizeof(Head));
	for (int i = 1; i < n; i++) {
		int u, v;
		Rd(u), Rd(v);
		Addedge(u, v);
	}
	for (int i = 1; i <= n; i++) Rd(W[i]), Rd(R[i]);
	int ans = 0;
	for (int i = 1; i <= n; i++) {
		if (!R[i]) continue;
		dfs(i, 0);
		for (int j = 1; j <= n; j++) P[j] = j;
		do {
			bool flag = true;
			for (int k = 1; k <= n; k++) {
				if (P[fa[k]] > P[k]) {
					flag = false;
					break;
				}
			}
			int rs = 0;
			for (int k = 1; k <= n; k++) rs += W[k] * P[k];
			if (flag) ans = max(ans, rs);
		} while (next_permutation(P + 1, P + n + 1));
	}
	printf("%d\n", ans);
	return 0;
}
