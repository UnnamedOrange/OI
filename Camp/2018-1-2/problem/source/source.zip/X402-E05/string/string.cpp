#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
}
int T,n,ans;
string S;
inline bool check(string A,int len)
{
	For(i,0,len/2-1)if(A[i]!=A[len-i-1])return 0;
	return 1;
}
inline void dfs(string now,int len,int cnt)
{
	if(cnt+1>=ans)return;
	if(!check(now,len)){chkmin(ans,cnt+1);return;}
	For(i,0,len)
		rFor(j,len-i,2)
		{
			if(i+j>len)break;
			if(!check(now.substr(i,j),j))
				dfs(now.substr(0,i)+now.substr(i+j,len-i-j),len-j,cnt+1);
			if(ans==2)return;
		}
	return;
}
int main()
{
	file();
	read(T);
	while(T--)
	{
		read(n);
		cin>>S;
		ans=inf;
		dfs(S,n,0);
		printf("%d\n",ans==inf?-1:ans);
		//cerr<<ans<<' ';
	}
	//assert((double)clock()/CLOCKS_PER_SEC<=1.0);
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
