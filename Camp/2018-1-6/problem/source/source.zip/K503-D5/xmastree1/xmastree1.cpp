#include <cstdio>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=5e3+5;
int tm,n,t,i,j,lastans,a[N],b[N],cnt[N],tag[N],lft[N],rgt[N];
int ver,En,fst[N],dfn[N],to[N*2],nxt[N*2];
int q,od,u,v,l,r;
void add(int a,int b) {
	En++; nxt[En]=fst[a]; fst[a]=En; to[En]=b;
}
void dfs(int x,int fa)
{
	lft[x]=dfn[x]=++tm; 
	int j;
	for (j=fst[x];j;j=nxt[j])
	  if (to[j]!=fa) dfs(to[j],x);
    rgt[x]=tm;
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	rep(i,1,n) scanf("%d",&b[i]);
	rep(i,1,n-1)
    {
    	scanf("%d%d",&u,&v);
    	add(u,v); add(v,u);
	}
	dfs(1,1);
	rep(i,1,n) a[dfn[i]]=b[i];
	while (q--)
	{
		ver++;
		scanf("%d",&od);
		if (od==1)
		{
			scanf("%d%d%d",&u,&l,&r);
	        if (t) { u^=lastans; l^=lastans; r^=lastans; }
			lastans=0;
			rep(i,lft[u],rgt[u]) cnt[a[i]]=ver;
			rep(i,l,r)
			  if (cnt[i]==ver) lastans++;
			printf("%d\n",lastans);
		}
		else {
		    scanf("%d%d",&u,&v);
		    a[dfn[u]]=v;
		}
	}
	return 0;
}
