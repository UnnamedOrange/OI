#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

inline int Rand(int l, int r) { return rand() % (r - l + 1) + l; }

int main()
{
	freopen("seed.txt", "r", stdin);
	srand(time(0) ^ read<int>());

	freopen("xmasinterval.in", "w", stdout);

	int n = 3, m = 5, MAXV = int(1e2);
	printf("%d %d\n", n, m);
	while(n--)
	{
		int l = Rand(1, MAXV), r = Rand(1, MAXV);
		if(l > r) swap(l, r);
		printf("%d %d\n", l, r);
	}
	while(m--) printf("%d\n", Rand(1, MAXV));

	freopen("seed.txt", "w", stderr);
	fprintf(stderr, "%d\n", rand());

	return 0;
}

