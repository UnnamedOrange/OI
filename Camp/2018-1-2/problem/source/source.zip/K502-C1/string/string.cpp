#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
using namespace std;

const int MAXN = 3e5 + 100;
int n;
int a[MAXN];
bool visit[MAXN];

bool check(int l, int r)
{
	int i = l, j = r;
	while (i < j)
	{
		if (i < j && visit[i])
			++i;
		if (i < j && visit[j])
			--j;
		if (a[i] != a[j])
			return false;
		++i;
		--j;
	}
	return true;
}

bool invalid(int l, int r)
{
	int pre = a[l], mid = -1;
	for (int i = l + 1; i < r + 1; ++i)
	{
		if (a[i] != pre && mid == -1)
			mid = a[i];
		else if (a[i] != pre)
			return false;
	}
	return true;
}

namespace Brust
{
	int dfs(int l, int r)
	{
		if (invalid(l, r))
			return 1000000000;
		int mid = (l + r) / 2;
		vector<int> g, h;
		for (int i = l; i < mid + 1; ++i)
		{
			bool le = check(l, i), ri = check(i + 1, r);
			if (!le && !ri)
				return 2;
			else if (!le)
				g.push_back(i);
			else if (!ri)
				h.push_back(i + 1);
		}
		int ret = 1000000000;
		for (int i = 0; i < g.size(); ++i)
		{
			int t = dfs(g[i] + 1, r) + 1;
			if (t <= 3)
				return t;
			ret = min(ret, t);
		}
		for (int i = 0; i < h.size(); ++i)
		{
			int t = dfs(l, h[i] - 1) + 1;
			if (t <= 3)
				return t;
			ret = min(ret, t);
		}
		return ret;
	}
	void main()
	{
		if (!check(1, n))
			printf("1\n");
		else if (invalid(1, n))
			printf("-1\n");
		else
		{
		//	cerr << "i am here" << endl;
			int t = dfs(1, n);
			if (t == 1000000000)
				t = -1;
			printf("%d\n", t);	
		}
	}
}

namespace Greedy
{
	void main()
	{
		if (!check(1, n))
			printf("1\n");
		else if (invalid(1, n))
			printf("-1\n");
		else
			printf("2\n");
	}
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int T = read();
	while (T--)
	{
		n = read();
		for (int i = 1; i < n + 1; ++i)
		{
			char ch = getchar();
			while (ch > 'z' || ch < 'a')
				ch = getchar();
			a[i] = ch - 'a';
		}
		if (n <= 100)
			Brust::main();
		else
			Greedy::main();
	}
	fclose(stdin);
	fclose(stdout);
}
