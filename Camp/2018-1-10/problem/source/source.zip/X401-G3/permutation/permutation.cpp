#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
#define rep(i,l,r) for(int i=l;i<=r;++i)
#define per(i,r,l) for(int i=r;i>=l;--i)

const int N=1e5+5,D=998244353;
int n,a[N];
int p[N];

bool vis[N];
bool ok()
{
	rep(i,1,n)
	if(a[i]&&a[i]!=p[i])return 0;
	memset(vis,0,sizeof(vis));
	rep(x,1,n)
	if(!vis[x])
	{
		int cnt=0;
		for(int y=x;!vis[y];y=p[y]){++cnt;vis[y]=1;}
		if(cnt%2)return 0;
	}	
	return 1;
}
void brute()
{
	rep(i,1,n)p[i]=i;
	int ans=0;
	do
	{
		if(ok())++ans;
	}while(next_permutation(p+1,p+n+1));
	cout<<ans;exit(0);
}

int main()
{
	freopen("permutation.in","r",stdin);freopen("permutation.out","w",stdout);
	cin>>n;
	rep(i,1,n)scanf("%d",a+i);
	if(n%2){puts("0");return 0;}
	if(n<=8)brute();
	ll ans=1;
	for(int i=1;i<n;i+=2)ans=ans*i%D*i%D;
	cout<<ans;
}
