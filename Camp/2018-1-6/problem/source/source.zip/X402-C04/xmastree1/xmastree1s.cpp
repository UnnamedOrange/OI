#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int N=100009;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

int n,q,ty;
int c[N],to[N<<1],nxt[N<<1],beg[N],tot;
int id[N],ed[N],seg[N],fa[N],dfn;
int vis[N];

struct query
{
	int ty,p,x,y,id;
	bool operator < (query o)const
	{
		if(p==o.p)
			return id<o.id;
		return p<o
	}
}

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void dfs(int u)
{
	seg[id[u]=++dfn]=u;
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa[u])
		{
			fa[to[i]]=u;
			dfs(to[i]);
		}
	ed[u]=dfn;
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);


	n=read();q=read();ty=read();

	for(int i=1;i<=n;i++)
		c[i]=read();
		
	for(int i=1,u,v;i<n;i++)
	{
		u=read();v=read();
		add(u,v);add(v,u);
	}

	dfs(1);

	int ans=0;
	for(int tim=1;tim<=q;tim++)
	{
		int typ=read();
		if(typ==1)
		{
			int u=read(),l=read(),r=read();
			if(ty==1)u^=ans,l^=ans,r^=ans;

			ans=0;
			for(int i=id[u];i<=ed[u];i++)
				if(l<=c[seg[i]] && c[seg[i]]<=r && vis[c[seg[i]]]!=tim)
					ans++,vis[c[seg[i]]]=tim;
			printf("%d\n",ans);
		}	
		else
		{
			int u=read(),cc=read();
			if(ty==1)u^=ans,cc^=ans;
			c[id[u]]=cc;
		}
	}

	return 0;
}
