#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
#define lc (o<<1)
#define rc (o<<1|1)
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1e5+10;
int n,m,k;
namespace case1
{
	struct Seg_T
	{
		int sumv[MAXN*3],addv[MAXN*3];
		void push_up(int o)
		{
			sumv[o]=sumv[lc]+sumv[rc];
			return;
		}
		void push_down(int o,int l,int r)
		{
			if(addv[o])
			{
				int mid=(l+r)>>1;
				sumv[lc]+=(mid-l+1)*addv[o];
				sumv[rc]+=(r-mid)*addv[o];
				addv[lc]+=addv[o];
				addv[rc]+=addv[o];
				addv[o]=0;
			}
			return;
		}
		void update(int o,int l,int r,int yl,int yr,int v)
		{
			if(yl<=l&&r<=yr)
			{
				addv[o]+=v;
				sumv[o]+=(r-l+1)*v;
				return;
			}
			int mid=(l+r)>>1;
			push_down(o,l,r);
			if(yl<=mid)update(lc,l,mid,yl,yr,v);
			if(yr>mid)update(rc,mid+1,r,yl,yr,v);
			push_up(o);
			return;
		}
		int query(int o,int l,int r,int yl,int yr)
		{
			if(yl<=l&&r<=yr)return sumv[o];
			int mid=(l+r)>>1;
			push_down(o,l,r);
			if(yl<=mid)query(lc,l,mid,yl,yr);
			if(yr>mid)query(rc,mid+1,r,yl,yr);
			return;
		}
	}T1;
	void solve()
	{
		
	}
}
int main()
{
	n=read();m=read();
}
