#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int mod=998244353;
int n,m,K;
vector<int> g[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
ll Pow(ll x, ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

int a[maxn], deg[maxn] ,tot;
ll dp[2010][2010];
void top(){
	queue<int> q;
	for(int i=1;i<=n;i++) if(!deg[i]) q.push(i);
	while(!q.empty()){
		int u=q.front(); q.pop();
		a[++tot]=u;
		for(int i=0;i<g[u].size();i++){
			int v=g[u][i];
			if(!(--deg[v])) q.push(v);
		}
	}
}

ll f[maxn], cnt[maxn];
void solve(){
	f[1]=0; cnt[1]=1;
	for(int i=1;i<=n;i++){
		int u=a[i];
		for(int j=0;j<g[u].size();j++){
			int v=g[u][j];
			(f[v]+=f[u]+cnt[u])%=mod;
			cnt[v]+=cnt[u];
		}
	}
	for(int i=1;i<=n;i++) printf("%lld\n", f[i]);
}
void solve0(){
	f[1]=1;
	for(int i=1;i<=n;i++){
		int u=a[i];
		for(int j=0;j<g[u].size();j++){
			int v=g[u][j];
			(f[v]+=f[u])%=mod;
		}
	}
	for(int i=1;i<=n;i++) printf("%lld\n", f[i]);
}

ll pw[maxn];
int main(){
	freopen("xmasdag.in","r",stdin),freopen("xmasdag.out","w",stdout);

	read(n), read(m), read(K);
	int u, v;
	for(int i=1;i<=m;i++) read(u), read(v), g[u].push_back(v), deg[v]++;
	top();
	if(K==1){ solve(); return 0; }
	if(K==0){ solve0(); return 0; }
	for(int i=1;i<=n;i++) pw[i]=Pow(i, K);
	dp[1][0]=1;
	for(int i=1;i<=n;i++){
		int u=a[i];
		for(int j=0;j<g[u].size();j++){
			int v=g[u][j];
			for(int k=0;k<=n;k++) (dp[v][k+1]+=dp[u][k])%=mod;
		}
	}
	for(int i=1;i<=n;i++){
		ll ans=0;
		for(int j=1;j<=n;j++) (ans+=pw[j]*dp[i][j]%mod)%=mod;
		printf("%lld\n", ans);
	}
	return 0;
}
