//#include <bits/stdc++.h>
#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <queue> 

#define fir first
#define sec second
#define MP make_pair
#define PB push_back
#define FO(x) freopen(#x".in", "r", stdin), freopen(#x".out", "w", stdout)

using namespace std;
typedef long long LL;
typedef unsigned long long u64;

template <typename T> inline bool cmin(T & a, const T & b) { return a > b ? a = b, 1 : 0;}
template <typename T> inline bool cmax(T & a, const T & b) { return a < b ? a = b, 1 : 0;}
int read() {
	int x = 0, f = 1;char ch;
	for(ch = getchar(); !isdigit(ch); ch = getchar())
		if(ch == '-') f = -1;
	for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	return x * f;
}

const int MaxN = 1001234;

struct edge{ 
	int to, nxt;
}e[MaxN]; int cnt, lst[MaxN];

void addEdge(int a, int b) {
	e[++cnt] = (edge) {b, lst[a]}; lst[a] = cnt;
}

int n, m, ind, scc, siz[MaxN], dfn[MaxN], low[MaxN], ins[MaxN], s[MaxN], bel[MaxN], sn;

void dfs(int x) {
	low[x] = dfn[x] = ++ind;
	ins[s[++sn] = x] = 1;
	for(int i = lst[x], y; y = e[i].to, i; i = e[i].nxt) {
		if(!dfn[y]) {
			dfs(y); cmin(low[x], low[y]);
		}else {
			if(ins[y]) 
				cmin(low[x], dfn[y]);
		}
	}
	if(low[x] == dfn[x]) {
		int c = -1;
		++scc;
		while(c != x && sn) {
			ins[c = s[sn--]] = 0;
			bel[c] = scc;
		}
	}
}

pair<int, int> d[MaxN]; int dN, sz[MaxN], f[MaxN], deg[MaxN];
queue<int> q;

int main() {
	int i, j; FO(bomb);
	n = read(); m = read();
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		addEdge(u, v);
	}	
	for(i = 1; i <= n; i++) if(!dfn[i]) dfs(i);
	for(i = 1; i <= n; i++) {
		sz[bel[i]]++;
		for(j = lst[i]; j; j = e[j].nxt)
			if(bel[i] != bel[e[j].to])
				d[++dN] = MP(bel[i], bel[e[j].to]);
	}
	cnt = 0; memset(lst, 0, sizeof(lst));
	
	for(i = 1; i <= dN; i++)
		addEdge(d[i].fir, d[i].sec), ++deg[d[i].sec];
	
	n = scc;
	for(i = 1; i <= n; i++) if(!deg[i]) f[i] = sz[i], q.push(i);
	
	while(!q.empty()) {
		int c = q.front(); q.pop();
		for(int i = lst[c], b; b = e[i].to, i; i = e[i].nxt) {
			cmax(f[b], f[c] + sz[b]);
			if(!--deg[b]) q.push(b);
		}
	} 
	cout << *max_element(f + 1, f + n + 1);
	return  0;
}

