#include<bits/stdc++.h>
#define rep(i,x,y) for(register int i = x ;i <= y; ++ i)
using namespace std;
template<typename T>inline void read(T&x)
{
	x = 0;char c;int sign = 1;
	do { c = getchar(); if(c == '-') sign = -1; }while(!isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); }while(isdigit(c));
	x *= sign;
}
inline void init(string name )
{
	string in = name + ".in",out = name + ".out";
	freopen(in.c_str(),"r",stdin);
	freopen(out.c_str(),"w",stdout);
}
const int N = 1e6 + 500;
int n; double ans;
int a[N],t[N];;

double solve(int l,int r)
{
	int cnt = 0;
	rep(i,l,r)
		t[++cnt] = a[i];
	
	sort(t + 1,t + 1 + cnt);
	
	double ans = 0;

	rep(i,1,cnt)
		ans = (ans + t[i]) / 2;
	
	return ans;	
}

int main()
{
	init("drink");
	read(n);
	rep(i,1,n)
		read(a[i]);
	
	rep(i,1,n)
		rep(j,i,n)
		{
//			printf("l = %d r = %d ans = %.13lf\n",i,j,solve(i,j));
			ans += solve(i,j);
		}
	
	printf("%.13lf\n",ans/n/n);
	
	return 0;
}
