#include<bits/stdc++.h>
#define ll long long
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c<'0'||c>'9')&&c!='-';c=getchar());
	if(c=='-')f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

const int p=998244353;
int m,n,k,ans,a[1000005];
struct node
{
	int l,r;
}t[1000005];

int ksm(int x,int y)
{
	int res=1;
	for(;y;y>>=1,x=1ll*x*x%p)
		if(y&1)res=1ll*res*x%p;
	return res;
}

int calc()
{
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;i++)
		for(int j=t[i].l;j<t[i].r;j++)
			a[j]++;
	int res=0;
	for(int i=1;i<=m;i++)res=(res+ksm(a[i],k))%p;
	return res;
}

void dfs(int l,int r,int x)
{
	if(x==n+1)
	{
		//cout<<t[1].l<<" "<<t[1].r<<'\n';
		ans+=calc();
		return;
	}
	for(int i=l+1;i<=m;i++)
		for(int j=max(r+1,i);j<=m;j++)
		{
			t[x].l=i,t[x].r=j;
			dfs(i,j,x+1);
		}
}

void work()
{
	m--;
	for(int i=1;i<=m;i++)
		ans=(ans+(ll)i*(m+1-i)%p)%p;
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=getint(),m=getint(),k=getint();
	if(m<=6)dfs(0,0,1);
	else if(n==1)work();
	printf("%d\n",ans);
	return 0;
}
