#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
using namespace std;
const int N=1e5+10;
const lovelive mod=998244353;
void read(int &x)
{
  x=0;
  char c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c>='0'&&c<='9')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
int fir[N],nxt[N*2],to[N*2],rd[N],a[N],tot,cnt;
void add_edge(int x,int y)
{
  nxt[++tot]=fir[x];
  fir[x]=tot;
  to[tot]=y;
}
queue<int> sp;
void tpsort(int n)
{
  int p;
  for(int i=1;i<=n;i++)
    if(!rd[i])
      sp.push(i);
  while(!sp.empty())
  {
  	p=sp.front();
  	sp.pop();
  	a[++cnt]=p;
  	for(int j=fir[p];j;j=nxt[j])
  	  {
  	  	--rd[to[j]];
  	  	if(!rd[to[j]])
  	  	  sp.push(to[j]);
	  }
  }
}
lovelive f[N][31],C[550][550];
int main()
{
  freopen("xmasdag.in","r",stdin);
  freopen("xmasdag.out","w",stdout);
  int n,m,k,x,y;
  read(n);read(m);read(k);
  for(int i=1;i<=m;i++)
  {
  	read(x);read(y);
  	add_edge(x,y);
  	rd[y]++;
  }
  for(int i=0;i<=550;i++)
  {
    C[i][0]=1;
    for(int j=1;j<=i;j++)
      C[i][j]=C[i-1][j-1]+C[i-1][j],C[i][j]%=mod;
  }
  tpsort(n);
  f[1][0]=1;
  for(int i=1;i<=n;i++)
    for(int j=fir[a[i]];j;j=nxt[j])
      f[to[j]][0]+=f[a[i]][0],f[to[j]][0]%=mod;
  for(int p=1;p<=k;p++)
  {
  	for(int i=1;i<=n;i++)
  	  for(int j=fir[a[i]];j;j=nxt[j])
  	    for(int l=0;l<=p;l++)
  	      f[to[j]][p]+=C[p][l]*f[a[i]][l]%mod,f[to[j]][p]%=mod;
  }
  puts("0");
  for(int i=2;i<=n;i++)
    printf("%d",f[i][k]);
  return 0;
}
/*
6 8 2
1 2
1 3
1 5
2 4
3 2
3 4
3 6
4 6
*/
