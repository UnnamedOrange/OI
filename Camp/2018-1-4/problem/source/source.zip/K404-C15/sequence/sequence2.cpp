#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 30;
int T, n, fac, a[N], b[N];

void debug(){
	for(int i = 1; i <= n; i++)
		printf("%d%c", b[i], " \n"[i == n]);	
}
void rev(int x){
	for(int i = 1, j = x; i < j; i++, j--)
		swap(b[i], b[j]);	
}
bool check(){
	for(int i = 1; i <= n; i++)
		if(a[i] != b[i]) return 0;
	return 1;
}
bool dfs(int last, int step){
	if(step == 0) return check();
	for(int i = 2; i <= n; i++)
		if(i != last){
			rev(i);
			if(dfs(i, step - 1)) return 1;
			rev(i);
		}
	return 0;
}

int main(){
	
	read(T);
	while(T--){
		read(n);
		for(int i = 1; i <= n; i++) 
			read(a[i]), b[i] = i;
		int ans = 0;
		while(!dfs(0, ans)) ans++;
		write(ans), enter;
	}
	
	return 0;
}
/*
1
10
7 3 5 2 6 1 8 10 9 4
*/
