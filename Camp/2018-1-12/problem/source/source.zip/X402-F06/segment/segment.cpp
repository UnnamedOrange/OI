#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int mod=998244353;
int n,m,k;
inline void add(int &x,int y){
	if(y>mod) y-=mod;
	x+=y;
	if(x>mod) x-=mod;
	if(x<0) x+=mod;
}
int ksm(int x,int y){
	int num=1;
	while(y){
		if(y&1) num=1ll*num*x%mod;
		y>>=1;
		x=1ll*x*x%mod;
	}
	return num;
}
namespace bf{
	const int maxn=7;
	int vis[maxn],ans;
	void dfs(int step,int l,int r){
		if(!step){
			REP(i,1,m)
				add(ans,ksm(vis[i],k));
			return;
		}
		REP(i,l+1,m)
			REP(j,max(i,r+1),m){
				REP(l,i,j-1) vis[l]++;
				dfs(step-1,i,j);
				REP(l,i,j-1) vis[l]--;
			}
	}
	void work(){
		ans=0;
		dfs(n,0,0);
		printf("%d\n",ans);
	}
}
namespace n1{
	void work(){
		int ans=0;
		REP(len,1,m-1)
			add(ans,1ll*len*(m-len)%mod);
		printf("%d\n",ans);
	}
}
namespace k1{
	const int maxn=350+1;
	int dp[2][maxn][maxn],sum[2][maxn][maxn],f[2][maxn][maxn];
	void work(){
		REP(i,0,1)REP(j,0,m)REP(k,0,m) dp[i][j][k]=sum[i][j][k]=f[i][j][k]=0;
		REP(i,1,n)
			REP(j,1,m)
				REP(k,j,m){
					int x=i&1,y=(i-1)&1;
					f[x][j][k]=f[y][j-1][k-1];
					if(i==1) f[x][j][k]=1;
					dp[x][j][k]=(sum[y][j-1][k-1]+1ll*f[x][j][k]*(k-j)%mod)%mod;
					sum[x][j][k]=(sum[x][j-1][k]+sum[x][j][k-1]-sum[x][j-1][k-1])%mod;
					add(f[x][j][k],f[x][j-1][k]+f[x][j][k-1]-f[x][j-1][k-1]);
					add(sum[x][j][k],dp[x][j][k]);
				}
		printf("%d\n",sum[n&1][m][m]);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
#endif
	n=read(),m=read(),k=read();
	if(n>m){
		printf("0\n");
		return 0;
	}
	if(m<=6){
		bf::work();
		return 0;
	}
	if(n==1){
		n1::work();
		return 0;
	}
	if(k==1 && m<=350){
		k1::work();
		return 0;
	}
	return 0;
}
