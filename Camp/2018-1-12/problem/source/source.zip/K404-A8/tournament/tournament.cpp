#include <cstdio>

typedef long long ll;
const int MAXN = 100000 + 10;
const ll Mod = 998244353;
ll N, M, K;
ll f[MAXN];

inline ll fastpow_mod( ll a, ll b ) {
	ll x = 1;
	while( b ) {
		if( b & 1ll ) x = ( x * a ) % Mod;
		a = ( a * a ) % Mod; b >>= 1ll;
	}
	return x;
}

int main() {
	freopen( "tournament.in", "r", stdin );
	freopen( "tournament.out", "w", stdout );
	register int i;
	scanf( "%lld%lld", &N, &K ), M = N * ( N - 1 ) / 2;
	f[1] = 1;
	for( i = 2; i <= N; ++i )
		f[i] = f[i - 1] * i % Mod;
	if( K == 3 )
		return 0 * printf( "%lld\n", ( fastpow_mod( 2, M ) - f[N] + Mod ) % Mod );
	if( K == N )
		return 0 * printf( "%lld\n", ( fastpow_mod( 2, M ) - N * ( N - 1 ) + Mod ) % Mod );
	return 0;
}
