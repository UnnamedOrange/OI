//2018-1-10
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (10000000+5)

const int P = 998244353;
inline int Mod(int a){return a >= P? a-P: a;}
inline int Mul(int a, int b){return 1ll * a * b % P;}

int mu[N], f[N], g[N], pn, prime[N];
bool vis[N];

void Init(int n){
	mu[1] = 1; f[1] = 1;
	For(i, 2, n){
		if(!vis[i]){mu[i] = Mod(-1), f[i] = 2; g[i] = 1; prime[++pn] = i;}
		
		For(j, 1, pn){
			if(1ll*prime[j]*i > n) break;
			vis[i*prime[j]] = true;

			if(i % prime[j] == 0){
				mu[i*prime[j]] = 0;
				f[i*prime[j]] = Mod(f[i] + g[i]); g[i*prime[j]] = g[i]; 
				break;
			}
				
			mu[i*prime[j]] = Mod(-mu[i]);
			f[i*prime[j]] = Mul(2, f[i]); g[i*prime[j]] = f[i];
		}
	}
	
	For(i, 2, n){
		f[i] = Mul(f[i], f[i]); mu[i] = Mod(mu[i] + mu[i-1]);
	}
}

int main(){
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	
	Init(10000000);
	int T, n, ans;

	scanf("%d", &T);
	while(T--){
		scanf("%d", &n);
		
		ans = 0;
		For(i, 1, n) ans = Mod(ans + Mul(f[i], mu[n/i]));
		printf("%d\n", ans);
	}

	return 0;
}
