cas=1
while true; do
	./test || break
	./string ||break
	./string1 || break
	diff ./string.out ./string1.out || break
	echo $cas
	cas=`expr $cas + 1`
done
