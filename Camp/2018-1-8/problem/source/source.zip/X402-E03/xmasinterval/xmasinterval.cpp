#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 25, modd = 1000000009 ;
struct segment {
	int l, r ;
} s[maxn] ;
int n, m, p[maxn], S ;
bool vis[maxn] ;
bool judge ( int x ) {
	int i, j, tmp = x ;
	memset (vis, 0, sizeof vis) ;
	for ( i = 1 ; i <= n ; i ++, x >>= 1 )
		if (x&1) for ( j = 1 ; j <= m ; j ++ )
			if (s[i].l <= p[j] && p[j] <= s[i].r)
				vis[j] = 1 ;
	for ( i = 1 ; i <= m ; i ++ )
		if (!vis[i]) return 0 ;
	x = tmp ;
	/*for ( i = 1 ; i <= n ; i ++, x >>= 1 )
		if (x&1) printf ( "[%d,%d]\n", s[i].l, s[i].r ) ;
	puts("") ;*/
	return 1 ;
}
int main() {
	freopen ( "xmasinterval.in", "r", stdin ) ;
	freopen ( "xmasinterval.out", "w", stdout ) ;
	//freopen ( "force.out", "w", stdout ) ;
	
	int i, ans = 0 ;
	Read(n) ; Read(m) ;
	for ( i = 1 ; i <= n ; i ++ ) {
		Read(s[i].l) ; Read(s[i].r) ;
	}
	for ( i = 1 ; i <= m ; i ++ )
		Read(p[i]) ;
	S = (1<<n)-1 ;
	for ( i = 0 ; i <= S ; i ++ )
		(ans += judge(i)) %= modd ;
	printf ( "%d\n", ans ) ;
	return 0 ;
}
