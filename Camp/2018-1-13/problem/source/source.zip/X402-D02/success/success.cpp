#include<iostream>
#include<cstdio>
#include<cstring>

int n,m,s,t;

namespace bf
{
	const int N=1050,MOD=1000000007;
	int f[N];
	void solve()
	{
		memset(f,0,sizeof(f));
		f[0]=1;
		for(int cnt=1;cnt<=n;cnt++)
		{
			for(int i=s;i>=0;i--)
			{
				f[i]=0;
				for(int j=1;j<=t && i-j>=0;j++)
					f[i]=(f[i]+f[i-j])%MOD;
			}
		}

		for(int cnt=n+1;cnt<=m;cnt++)
		{
			for(int i=s;i>=0;i--)
			{
				f[i]=0;
				for(int j=1;j<=i;j++)
					f[i]=(f[i]+f[i-j])%MOD;
			}
		}

		int ans=0;
		for(int i=0;i<=s;i++)
			ans=(ans+f[i])%MOD;
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	return 0;
}
