#include <cstdio>
using namespace std;
#define N 4050
int a[N],b[N],c[N],i,maxd,n,m,k;
bool zw;
void dfs(int dep)
{
	if (dep==maxd+1){
		int j=1;
		for (i=1;i<=maxd;i++){
			while (j<=n&&a[j]!=c[i]) j++;
			if (j>n) break;j++;
		}
		if (i==maxd+1) return;
		j=1;
		for (i=1;i<=maxd;i++){
			while (j<=m&&b[j]!=c[i]) j++;
			if (j>m) break;j++;
		}
		if (i==maxd+1) return;
		zw=true;return;
	}
	for (c[dep]=1;c[dep]<=k;c[dep]++) dfs(dep+1);
}
int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (i=1;i<=n;i++) scanf("%d",&a[i]);
	for (i=1;i<=m;i++) scanf("%d",&b[i]);
	for (maxd=1;;maxd++){
		dfs(1);if (zw) return printf("%d\n",maxd),0;
	}
	return 0;
}
