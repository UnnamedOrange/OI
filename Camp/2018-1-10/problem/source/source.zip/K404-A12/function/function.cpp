#include <iostream>
#include <cstdio>
#include <cstring>
#define N 1000000
using namespace std;
int prime[N+5],cnt=0,mu[N+5],v[N+5],pre[N+5],sig[N+5],f[N+5];
bool isprime[N+5];
void init(){
	mu[1]=sig[1]=1;
	for(int i=2;i<=N+2;i++){
		if(!isprime[i]){
			prime[++cnt]=i;
			mu[i]=-1;
			v[i]=1;pre[i]=1;
			sig[i]=2;
		}
		for(int p=1;p<=cnt&&prime[p]*i<=N+2;p++){
			int x=prime[p]*i;
			isprime[x]=1;
			if(i%prime[p]==0){
				v[x]=v[i]+1;
				pre[x]=pre[i];
				mu[x]=0;
				sig[x]=sig[pre[i]]*(v[x]+1);
				break;
			}
			v[x]=1;pre[x]=i;
			mu[x]=-mu[i];
			sig[x]=sig[i]+sig[i];
		}
	}
	for(int i=1;i<=N+2;i++){
		for(int p=i,j=1;p<=N+2;p+=i,j++){
			f[p]+=mu[i]*sig[j]*sig[j];
		}
	}
	for(int i=1;i<=N+2;i++) f[i]+=f[i-1];
}
int n;
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	init();
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		printf("%d\n",f[n]);
	}
	return 0;
}
