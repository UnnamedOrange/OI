#include <bits/stdc++.h>
 
#define fir first
#define sec second
#define MP make_pair
#define PB push_back
 
using namespace std;
typedef long long LL;
typedef unsigned long long u64;
 
template <typename T> inline bool cmin(T & a, const T & b) { return a > b ? a = b, 1 : 0;}
template <typename T> inline bool cmax(T & a, const T & b) { return a < b ? a = b, 1 : 0;}
int read() {
    int x = 0, f = 1;char ch;
    for(ch = getchar(); !isdigit(ch); ch = getchar())
        if(ch == '-') f = -1;
    for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
    return x * f;
}

const int MaxN = 1001234, P = 1e9 + 9;

int n, m, K, l[MaxN], r[MaxN], x[MaxN], f[MaxN];

int seg[MaxN << 2], mul[MaxN << 2];

#define lc(p) (p << 1)
#define rc(p) (p << 1 | 1)
#define mid (l + r >> 1)
#define add(x, y) (x + y >= P ? x + y - P : x + y)

void build(int p, int l, int r) {
	mul[p] = 1;
	if(l == r)return;
	build(lc(p), l, mid); build(rc(p), mid + 1, r);
}

void push_down(int p, int l, int r) {
	if(mul[p] == 1) return;
	mul[lc(p)] = (LL) mul[lc(p)] * mul[p] % P;
	mul[rc(p)] = (LL) mul[rc(p)] * mul[p] % P;
	seg[lc(p)] = (LL) seg[lc(p)] * mul[p] % P;
	seg[rc(p)] = (LL) seg[rc(p)] * mul[p] % P; mul[p] = 1;
}

void inc(int p, int l, int r, int x, int d) {
	if(l == r) seg[p] = add(seg[p], d); 
	else {
		push_down(p, l, r);
		x <= mid ? inc(lc(p), l, mid, x, d) : inc(rc(p), mid + 1, r, x, d);
		seg[p] = add(seg[lc(p)], seg[rc(p)]);
	} 
}

void mult(int p, int l, int r, int a, int b, int x) {
	if(a > r || b < l) return;
	if(a <= l && r <= b) {
		seg[p] = (LL) seg[p] * x % P;
		mul[p] = (LL) mul[p] * x % P;
		return; 
	}
	push_down(p, l, r);
	mult(lc(p), l, mid, a, b, x);
	mult(rc(p), mid + 1, r, a, b, x);
	seg[p] = add(seg[lc(p)], seg[rc(p)]);
}

int sum(int p, int l, int r, int a, int b) {
	if(a > r || b < l) return 0;
	if(a <= l && r <= b) return seg[p];
	push_down(p, l, r);
	return (sum(lc(p), l, mid, a, b) + sum(rc(p), mid + 1, r, a, b)) % P;
}

int ls[MaxN], p[MaxN]; 
int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	
	int i, j, k;
	n = read(); m = read();
	for(i = 1; i <= n; i++) l[i] = read(), r[i] = read();
	for(i = 1; i <= m; i++) x[i] = read(), ls[++K] = x[i]; 
	sort(x + 1, x + m + 1); 
	sort(ls + 1, ls + K + 1); K = unique(ls + 1, ls + K + 1) - ls - 1;
	int nn = 0;
	for(i = 1; i <= n; i++) {
		l[i] = lower_bound(ls + 1, ls + K + 1, l[i]) - ls;
		r[i] = upper_bound(ls + 1, ls + K + 1, r[i]) - ls - 1;
		if(l[i] <= r[i]) l[++nn] = l[i], r[nn] = r[i];
	}
	int pp = n - nn; n = nn;
	for(i = 1; i <= m; i++) x[i] = lower_bound(ls + 1, ls + K + 1, x[i]) - ls;
	for(i = 1; i <= n; i++) p[i] = i; 
	sort(p + 1, p + n + 1, [&] (int x, int y) {return l[x] < l[y] || (l[x] == l[y] && r[x] > r[y]);});
	build(1, 0, K); 
	inc(1, 0, K, 0, 1);
	for(k = 1; k <= n; k++) {
		int i = p[k];
		mult(1, 0, K, r[i], K, 2);
		int d = sum(1, 0, K, l[i] - 1, r[i] - 1);
		inc(1, 0, K, r[i], d);
	}
	int ans = sum(1, 0, K, K, K);
	for(i = 1; i <= pp; i++) (ans <<= 1) %= P;
	printf("%d\n", ans); 
	return 0;
}
