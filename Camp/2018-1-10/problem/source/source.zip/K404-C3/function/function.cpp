#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 1000010
#define ll long long
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int pri[N],n,mu[N],cnt;
bool pd[N];
vector<int> o[N];
void pre()
{
    mu[1]=1;
	for(int i=2;i<=n;i++)
	{
		if(!pd[i])pri[++cnt]=i,mu[i]=-1;
		for(int j=1;i*pri[j]<=n&&j<=cnt;j++)
		{
			pd[i*pri[j]]=1;
			if(i%pri[j]==0)
			{mu[i*pri[j]]=0;break;}
			mu[i*pri[j]]=-mu[i];
		}
	}
}
int T;
int ans[N];
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
    T=read();int i,j;
    if(!T)return 0;

    n=1000000;

    pre();
    for(i=1;i<=n;i++)
    for(j=i;j<=n;j+=i)o[j].push_back(i);

	for(i=1;i<=n;++i)
    {
        ans[i]=ans[i-1];
        for(j=0;j<o[i].size();++j)
     	{
      		int d=o[i][j];
       		ans[i]+=mu[d]*o[i/d].size()*o[i/d].size();
        }
    }

    while(T--)
    {
        n=read();
        printf("%d\n",ans[n]);
    }
}
