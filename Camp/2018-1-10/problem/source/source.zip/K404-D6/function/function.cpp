#include<cstdio>
typedef long long ll;
const int maxn=15000011,N=15000000;
int T,n;
bool np[maxn];
ll o[maxn];
int mu[maxn],maxh[maxn],pr[maxn/10];
inline void shai_fa(){
	mu[1]=1;o[1]=1;
	for(register int i=2;i<=N;++i){
		if(!np[i]){
			pr[++pr[0]]=i;
			mu[i]=-1;
			o[i]=2;
			maxh[i]=i;
		}
		for(register int j=1;j<=pr[0]&&pr[j]*i<=N;++j){
			np[i*pr[j]]=1;
			if(i%pr[j]==0){
				if(maxh[i]==i){
					o[i*pr[j]]=o[i]+1;
					maxh[i*pr[j]]=maxh[i]*pr[j];
					break;
				}
				o[i*pr[j]]=1ll*o[i/maxh[i]]*o[maxh[i]*pr[j]];
				maxh[i*pr[j]]=maxh[i]*pr[j];
				break;
			}
			o[i*pr[j]]=1ll*o[i]*o[pr[j]];
			maxh[i*pr[j]]=pr[j];
			mu[i*pr[j]]=-mu[i];
		}
	}
	for(register int i=1;i<=N;++i)
		mu[i]+=mu[i-1],o[i]=1ll*o[i]*o[i]+1ll*o[i-1];
}
inline ll query(int n){
	ll ret=0;
	for(register int i=1,pos=0;i<=n;i=pos+1){
		pos=n/(n/i);
		ret=ret+1ll*(mu[pos]-mu[i-1])*o[n/i];
	}
	return ret;
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	scanf("%d",&T);
	shai_fa();
	while(T--){
		scanf("%d",&n);
		printf("%lld\n",query(n));
	}
	return 0;
}
