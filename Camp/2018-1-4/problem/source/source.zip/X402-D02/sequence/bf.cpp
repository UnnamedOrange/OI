#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
#include<ctime>

namespace Nan_Ti
{
	const int N=26;

	int n,ans;

	struct node
	{
		int s[N],cost;
		inline void rot(int i){std::reverse(s+1,s+i+1);}
		inline int calc()
		{
			int val=0;
			for(int i=2;i<=n;i++)
				if(s[i]!=s[i-1]+1 && s[i]!=s[i-1]-1)val++;
			return val;
		}
	};
	struct cmp
	{
		bool operator() (node &A,node &B)
		{
			int a=A.cost+A.calc(),b=B.cost+B.calc();
			return a>b;
		}
	};
	std::priority_queue<node,std::vector<node>,cmp> Q;

	void work()
	{
		while(!Q.empty())
		{
			node A=Q.top();Q.pop();
			int val=A.calc();
			if(A.cost+val>=ans)continue;
			if(val==0){ans=A.cost;continue;}
			
			A.cost++;

			for(int i=2;i<=n;i++)
			{
				A.rot(i);
				Q.push(A);
				A.rot(i);
			}
		}
	}

	void solve()
	{
		node A;
		A.cost=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&A.s[i]);
		while(!Q.empty())Q.pop();
		Q.push(A);
		ans=n*2;
		work();
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.ans","w",stdout);
	int T;
	for(scanf("%d",&T);T--;Nan_Ti::solve());

	fprintf(stderr,"queue time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
