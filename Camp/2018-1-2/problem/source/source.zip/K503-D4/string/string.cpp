#include<bits/stdc++.h>
#define maxn 200000
using namespace std;
char s[maxn],tmp[maxn];
bool check(int len)
{
	for (int i=1;i*2<=len;i++)
		if (tmp[i]!=tmp[len-i+1]) return false;
	return true;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--)
	{
		int n,flag=1;
		scanf("%d",&n);
		char c=getchar();
		for (int i=1;i<=n;i++)
			s[i]=getchar();
		for (int i=2;i<=n;i++)
			if (s[i]!=s[i-1]) {flag=0; break;}
		if (flag) {puts("-1"); continue;}
		for (int i=1;i<=n;i++)
			tmp[i]=s[i];
		if (check(n)==0) {puts("1"); continue;}
		flag=0;
		for (int i=1;i<=n;i++)
		{
			for (int j=i+1;j<=n;j++)
			{
				int len=0;
				for (int k=i;k<=j;k++)
					tmp[++len]=s[k];
				if (check(len)) continue;
				len=0;
				for (int k=1;k<i;k++)
					tmp[++len]=s[k];
				for (int k=j+1;k<=n;k++)
					tmp[++len]=s[k];
				if (check(len)==0)
				{
					flag=1; break;
				}
			}
			if (flag) break;
		}
		if (flag) puts("2"); else puts("-1");
	}
	return 0;
}
