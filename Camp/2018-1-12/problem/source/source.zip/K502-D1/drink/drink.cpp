#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int MAXN = 1e6 + 10;
double n;
int cnt = 0;
double f[MAXN];
double g[MAXN];
double temp[MAXN];
double a[MAXN];
int m[MAXN];
double sum = 0;
double ans = 0;

void open()
{
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}
int main()
{
	open();
	n = read();
	for(int i = 1; i <= n; i++) {
		temp[i] = a[i] = read();
	}
	int k = n;
	sort(temp + 1, temp + k + 1);
	for(int i = 1; i <= n; i++) {
		if(temp[i] != temp[i - 1]) {
			int num = temp[i];
			m[num] = ++cnt;
		}
	}
	/*for(int i = 1; i <= n; i++) {
		for(int j = i; j <= n; j++) {
			for(int k = i; k <= j; k++) {
				temp[k - i] = a[k];
			}
			sum = 0;
			sort(temp, temp + j - i + 1);
			for(int k = 0; k <= j - i; k++) {
			//	cout<<temp[k]<<" ";
				sum = (sum + temp[k]) / 2;
			}
		//	cout<<sum<<endl;
			ans += sum;
		}
	}*/
	ans = 0;
	for(int i = 1; i <= n; i++) {
		int num = a[i];
		sum = a[i];
		g[m[num]] += sum;
		for(int j = i - 1; j >= 1; j--) {
			if(a[j] > a[i]) {
				sum = sum / 2;
			}
			g[m[num]] += sum;
		}
		for(int j = m[num]; j >= 1; j--) {
			g[j] = g[j] / 2;
		}
		/*for(int j = 1; j <= 10; j++) {
			cout<<g[j]<<" ";
		}*/
		for(int j = 1; j <= cnt; j++) {
			f[i] += g[j];
		}
		//cout<<f[i]<<endl;
	}
	for(int i = 1; i <= n; i++) {
		ans += f[i];
	}
//	cout<<ans<<endl;
	ans = ans / n / n;
	printf("%lf\n", ans);
	close();
}
