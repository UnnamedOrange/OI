#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

typedef long long ll;
const int N=100009;
const int md=998244353;

int n,m,ans;
int p[N],a[N],id[N];
bool vis[N];

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);

	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p[i]);
		vis[p[i]]=1;
		if(!p[i])
			id[++m]=i;
	}

	if(n&1)
	{
		puts("0");
		return 0;
	}

	if(m==n)
	{
		ll ans=1;
		for(ll i=3;i<n;i+=2)
			ans=(ans*i*i)%md;
		printf("%lld\n",ans);
		return 0;
	}

	m=0;
	for(int i=1;i<=n;i++)
		if(!vis[i])
			a[++m]=i;

	for(int i=1;i<=n;i++)
		vis[i]=0;
	for(int i=1;i<=n;i++)
		if(p[i] && !vis[i])
		{
			int pos=p[i],dis=1;
			vis[i]=1;
			while(pos && pos!=i)
			{
				dis++;
				vis[pos]=1;
				pos=p[pos];
			}
			if(pos==i && dis&1)
			{
				puts("0");
				return 0;
			}
		}

	do
	{
		for(int i=1;i<=m;i++)
			p[id[i]]=a[i];
		for(int i=1;i<=n;i++)
			vis[i]=0;
		for(int i=1;i<=n;i++)
			if(!vis[i])
			{
				int pos=p[i],dis=1;
				vis[i]=1;
				while(pos!=i)
				{
					dis++;
					vis[pos]=1;
					pos=p[pos];
				}
				if(dis&1)
					goto nxt;
			}
		ans++;
		if(ans>=md)
			ans-=md;
		nxt:;
	}while(next_permutation(a+1,a+m+1));

	printf("%d\n",ans);
	return 0;
}
