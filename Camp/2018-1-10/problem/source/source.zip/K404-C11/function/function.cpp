#include <bits/stdc++.h>
#include <tr1/unordered_map>

namespace {

const int MAXN = 30000000;

typedef unsigned long long ulong;
std::tr1::unordered_map<int, ulong> map;

ulong sum[MAXN + 1];

ulong get(int n) {
    register ulong &ret = map[n];
    if (ret) return ret;
    ret = sum[n];
    for (register int i = 2, last; i <= n; i = last + 1) {
        last = n / (n / i);
        ret -= (last - i + 1ull) * get(n / i);
    }
    return ret;
}

typedef unsigned char byte;
typedef unsigned int uint;

int p[MAXN / 15 + 1], cnt;
uint vis[MAXN / 32 + 1];

byte idx[MAXN + 1];

inline void fastLinearSieveMethod(const int n) {
    sum[1] = 1;
    for (register int i = 2; i <= n; i++) {
        if (!((vis[i >> 5] >> (i & 31)) & 1)) {
            p[cnt++] = i;
            sum[i] = 2;
            idx[i] = 1;
        }
        for (register int j = 0, k; j < cnt && (k = i * p[j]) <= n; j++) {
            vis[k >> 5] |= 1u << (k & 31);
            if (i % p[j] == 0) {
                idx[k] = idx[i] + 1;
                sum[k] = (sum[i] / (idx[i] + 1)) * (idx[k] + 1);
                break;
            } else {
                idx[k] = 1;
                sum[k] = sum[i] << 1;
            }
        }
    }
}

inline void init(const int n) {
    fastLinearSieveMethod(n);
    for (register int i = 1; i <= n; i++) sum[i] = sum[i] * sum[i] + sum[i - 1];
}

inline void solve() {
    init(30000000);
    register int T;
    std::cin >> T;
    for (register int n; T--;) {
        std::cin >> n;      
        if (n <= 30000000) {
            std::cout << get(n) << '\n';
        } else {
            std::cout << "QAQ" << '\n';
        }
    }
}
}  // namespace

int main() {
    freopen("function.in", "r", stdin);
    freopen("function.out", "w", stdout);
    solve();
    return 0;
}
