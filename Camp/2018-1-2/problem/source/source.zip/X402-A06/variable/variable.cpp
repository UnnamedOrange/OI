#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

ll llread(){
	ll sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, q, p;

ll W, w[maxn];

struct calcH{
	ll x, y, z, a, b, c, d, e, f;

	void get(){
		x = llread(), y = llread(), z = llread();
		a = llread(), b = llread(), c = llread();
		d = llread(), e = llread(), f = llread();
	}

	ll calc(){
		return a * abs(w[x] - w[y]) + b * abs(w[y] - w[z]) + c * abs(w[z] - w[x])
			+ d * (w[x] - w[y]) + e * (w[y] - w[z]) + f * (w[z] - w[x]);
	}

}H[maxn];

struct limit{
	int u, v, r;

	bool pd(){
		if(r == 0) return w[u] <= w[v];
		else if(r == 1) return w[u] == w[v];
		else return w[u] < w[v];
	}

}lim[maxn];

void Get(){
	n = read(), W = llread(), p = read(), q = read();
	For(i, 1, p){
		H[i].get();
	}
	For(i, 1, q){
		lim[i].u = read(), lim[i].v = read(), lim[i].r = read();
	}
}

void solve_bf(){
	int tmp = (1 << n) - 1;
	ll Ans = 9e18;
	For(i, 0, tmp){
		ll ans = 0;
		For(j, 1, n){
			if(i & (1 << j-1)){
				w[j] = W;
			}
			else w[j] = -W;
			ans += w[j];
		}

		bool flag = 0;
		For(j, 1, q){
			if(!lim[j].pd()){
				flag = 1;
				break;
			}
		}

		if(flag) continue;

		For(j, 1, p) ans += H[j].calc();
		Ans = min(Ans, ans);
	}

	printf("%lld\n", Ans);
}

int main(){
	
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	
	int _ = read();
	while(_ --){
		Get();
		if(n <= 20)solve_bf();
		else puts("0");
	}

	return 0;
}
