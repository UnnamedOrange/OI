#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<set>
using namespace std;
struct lxy{
	int dep;
	long long f;
};

set <long long> pan;
queue <lxy> d;

int n,T;
long long aim;

long long tur(long long f,int r)
{
	int a[30];
	for(int i=n;i>=1;i--)
	{
	  a[i]=f%10;
	  f=f/10;
    }
    for(int i=1;i<=r/2;i++)
      swap(a[i],a[r-i+1]);
    for(int i=1;i<=n;i++)
	  f=f*10+a[i];
	return f;
}

int dfs()
{
	while(!d.empty())
	{
		lxy m=d.front();
		d.pop();
		for(int i=2;i<=n;i++)
		{
			long long x=tur(m.f,i);
			if(x==aim)
			  return m.dep+1;
			if(pan.find(x)==pan.end())
			{
				pan.insert(x);
				lxy t;t.dep=m.dep+1;t.f=x;
				d.push(t);
			}
		}
    }
    return 0;
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&T);
	while(T!=0)
	{T--;
		scanf("%d",&n);
		pan.clear();
		while(!d.empty())d.pop();
		long long x=0,a=0;
		aim=0;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&x);
			a=a*10+x;
		}
		for(int i=1;i<=n;i++)
		  aim=aim*10+i;
		pan.insert(a);
		lxy m;m.f=a;m.dep=1;
		d.push(m);
		printf("%d\n",dfs()-1);
    }
}
