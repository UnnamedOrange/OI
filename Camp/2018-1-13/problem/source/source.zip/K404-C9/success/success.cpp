#include<bits/stdc++.h>
using namespace std;
int s,n,m,t;
long long ans=0;
long long dp[1000][1000];
const int mod=1000000007;
int main() { 
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	s-=m;t--;
	for(int i=0;i<=t;++i) dp[1][i]=1;	
	for(int i=1;i<=m;++i) { 
		for(int j=0;j<=s;++j) { 
			if(dp[i][j]==0) continue;
			long long lim=0;
			if(i<=n-1) lim=min(t,s-j);
			else lim=s-j;
			for(int k=0;k<=lim;++k) { 
				dp[i+1][j+k]+=dp[i][j];
				if(dp[i+1][j+k]>mod) dp[i+1][j+k]-=mod;
			} 
		} 
	} 
	for(int i=0;i<=s;++i) ans+=dp[m][i];
	cout<<ans%mod;
	return 0;
} 
