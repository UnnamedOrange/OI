#include<iostream>
#include<cstdio>
#include<algorithm>
#define maxn 1010
#define mod 1000000009
using namespace std;
int a[maxn],n,m,w[maxn],cnt,ans;
struct node{int l,r;}q[maxn];
void count(int x){
	int pos=0;cnt=0;
	while(x){
		pos++;
		if(x&1)w[++cnt]=pos;
		x>>=1;
	}
}
int main(){
	freopen("xmasinterval.in","r",stdin);freopen("xmasinterval.out","w",stdout); 
//	freopen("Cola.txt","r",stdin);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d%d",&q[i].l,&q[i].r);
	for(int i=1;i<=m;i++)scanf("%d",&a[i]);
	sort(a+1,a+m+1);
	for(int i=1;i<(1<<n);i++){
		count(i);
		int pos=1;
		bool ff=0;
		for(int j=1;j<=m;j++){
			bool flag=0;
			for(int k=1;k<=cnt;k++)
				if(q[w[k]].l<=a[j]&&q[w[k]].r>=a[j]){
					flag=1;break;
				}
			if(flag==0){ff=1;break;}
		}
		if(ff==0)ans++;
		if(ans>=mod)ans-=mod;
	}
	printf("%d",ans);
	return 0;
}
