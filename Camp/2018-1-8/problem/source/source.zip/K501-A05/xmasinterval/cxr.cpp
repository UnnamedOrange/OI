#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int Mod=1e9+9;
int p[500010];
struct node{
	int l,r;
}a[500010];
int dp[500010],s[500010];
int n,m,cnt=0,ans=0;
int mult(int x,int y){
	x%=Mod;y%=Mod;
	return (int)((long long)x*(long long)y%(long long)Mod);	
}
int add(int x,int y){
	x%=Mod;y%=Mod;
	return ((x+y)%Mod+Mod)%Mod;
}
int cmp1(int x,int y){
	return x<y;	
} 
int cmp2(node x,node y){
	if (x.r<y.r) return 1;
	if (x.r==y.r && x.l<y.l) return 1;
	return 0;	
}
void solve(int x){
	int sl=a[x].l,sr=a[x].r;
	int s,t,l,r;
	if (a[x].l<=p[1]) s=1;
	else if (a[x].l==p[m]) s=m;
	else if (a[x].l>p[m]){
		a[x].l=-1;
		a[x].r=-1;
		return;	
	}else{
		l=1;r=m;
		while (l<r){
			int mid=(l+r)>>1;
			if (p[mid]>=a[x].l){
				r=mid-1;
				s=mid;	
			}else l=mid+1;
		}
	}
	if (a[x].r>=p[m]) t=m;
	else if (a[x].r==p[1]) t=1;
	else if (a[x].r<p[1]){
		a[x].l=-1;
		a[x].r=-1;
		return;	
	}else{
		l=1;r=m;
		while (l<r){
			int mid=(l+r)>>1;
			if (p[mid]>=a[x].r){
				r=mid-1;
				t=mid;	
			}else l=mid+1;
		}
		if (p[t]>a[x].r) t--;	
	}
	a[x].l=s;a[x].r=t;
	if (t==1) cnt++;
}
int lowbit(int x){
	return x&(-x);
}	
void work(int x,int y){
	for (int i=x;i<=m;i+=lowbit(i))
		s[i]=add(s[i],y);
} 
int sum(int x){
	int res=0;
	for (int i=x;i>=1;i-=lowbit(i))	
		res=add(s[i],res);
	return res;
}
int Pow(int x,int y){
	int res=1;
	while (y){
		if (y%2) res=mult(res,x);
		x=mult(x,x);
		y/=2;
	}
	return res;
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=n;++i){
		a[i].l=read();
		a[i].r=read();
	}
	for (int i=1;i<=m;++i)
		p[i]=read();	
	sort(p+1,p+m+1,cmp1);
	for (int i=1;i<=n;++i)
		solve(i);
	sort(a+1,a+n+1,cmp2);
	dp[1]=add(Pow(2,cnt),-1);
	work(1,dp[1]);
	cnt=0;
	for (int i=1;i<=n;++i){
		if (a[i].l==-1){
			cnt++; 
			continue;
		} 
		if (a[i].r==1) continue;
		int k;
		if (a[i].l==1){
			k=add(sum(a[i].r),1);
			dp[a[i].r]=add(dp[a[i].r],k);
			work(a[i].r,k);
		}else if (a[i].l==2){
			k=sum(a[i].r);
			dp[a[i].r]=add(dp[a[i].r],k);
			work(a[i].r,k);
		}else{
			k=add(sum(a[i].r),-sum(a[i].l-2));
			work(a[i].r,k);
			dp[a[i].r]=add(dp[a[i].r],k);
		} 
	} 
	printf("%d\n",mult(dp[m],Pow(2,cnt)));
	return 0;
}

