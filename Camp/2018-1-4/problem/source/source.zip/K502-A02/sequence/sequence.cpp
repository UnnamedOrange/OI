#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<stack>
#define maxn 30
using namespace std;
stack<int> S;
int a[maxn],n,flag;
int check(){
	for (int i=1;i<=n;i++)
		if (a[i]!=i) return 0;
	return 1;
}
void dfs(int x,int Max,int c){
	if (flag) return;
	if (x+c>Max) return;
	if (check()){
		flag=1;
		return;	
	}
	for (int i=1;i<=n;i++){
		int t=0;
		if (abs(a[1]-a[i+1])==1) t--;
		if (abs(a[i]-a[i+1])==1) t++;
		reverse(a+1,a+i+1);
		dfs(x+1,Max,c+t);
		reverse(a+1,a+i+1);
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int T;
	cin>>T;
	while (T--){
		int sum=0;
		scanf("%d",&n);
		for (int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		a[n + 1] = n + 1;
		for (int i=1;i<=n;i++)
			if (abs(a[i]-a[i+1])>1) sum++;
		int Max=0;
		flag=0;
		while(1){
			dfs(0,Max,sum);
			if (flag) break;
			Max++;
		}
		printf("%d\n",Max);
	}
	return 0;
}
