#include<bits/stdc++.h>
#define mo 998244353
using namespace std;
struct Info{
	int nu,ne;
}a[200010];
int ru[100010]={0},li[100010],m,n,nu,k,x,y,l,r,b[100010],d[100010],an[2010][2010]={0},p[100010][33];
long long sum=0,pp[510][510];
void jb(int x,int y){
	a[++nu].nu=y;a[nu].ne=b[x];b[x]=nu;
}
long long po(long long x,long long y){
	long long z=1;
	while (y){
		if (y % 2==1){z=(z*x)%mo;}
		x=(x*x) %mo;
		y/=2;
	}
	return z;
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for(int i=1;i<=n;i++)d[i]=po(i,k);
	for (int i=1;i<=m;i++){
		scanf("%d %d",&x,&y);
		jb(x,y);ru[y]++;
	}
	l=1,r=1,li[1]=1;
	if (n<=2000&&m<=5000){
		an[1][0]=1;
		while (l<=n){
			for (int y=b[li[l]];y;y=a[y].ne){
				ru[a[y].nu]--;
				if (ru[a[y].nu]==0) li[++r]=a[y].nu;
				for (int i=0;i<n;i++) an[a[y].nu][i+1]+=an[li[l]][i];
			}
			l++;
		}
		for (int i=1;i<=n;i++){
			sum=0;
			for (int j=1;j<=n;j++){
				sum+=d[j]*an[i][j];
				sum%=mo;
			}
			cout<<sum<<endl;
		}
	}else{
		for (int i=0;i<=k;i++){
			pp[i][0]=1;
			for (int j=1;j<=i;j++){
				pp[i][j]=(((pp[i][j-1]*(i-j+1))%mo)*po(j,mo-2))%mo;
			}
		}
		p[1][0]=1;
		while (l<=n){
			for (int y=b[li[l]];y;y=a[y].ne){
				ru[a[y].nu]--;
				if (ru[a[y].nu]==0) li[++r]=a[y].nu;
				for (int i=0;i<=k;i++){
					for (int j=0;j<=i;j++){
						p[a[y].nu][i]=(p[a[y].nu][i]+p[li[l]][j]*pp[i][j])%mo;
					}
				}
			}
			l++;
		}
		for (int i=1;i<=n;i++){
			cout<<p[i][k]<<endl;
		}		
	}
}
