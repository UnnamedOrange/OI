#include <bits/stdc++.h>
using namespace std;
template <typename T> void read(T &x) {
	x=0;char c=getchar();
	while (!isdigit(c)) {c=getchar();}
	while (isdigit(c)) {x=x*10+c-'0';c=getchar();}
	return;
}
struct Edge {
	int to; Edge *nxt;
} pool[100100], *tail=pool, *G[100100];
int n, c[100100], clk, dfn[100100], low[100100], clr[100100], book[100100];
void add(int u, int v) {
	(++tail)->to=v, tail->nxt=G[u], G[u]=tail;
	(++tail)->to=u, tail->nxt=G[v], G[v]=tail;
}
void dfs(int x) {
	if (dfn[x]) return;
	dfn[x]=++clk;
	for (Edge *p=G[x];p;p=p->nxt) {
		dfs(p->to);
	}
	low[x]=clk;
}
int main() {
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int q, t;
	read(n), read(q), read(t);
	for (int i=1;i<=n;i++) {
		read(c[i]);
	}
	for (int i=1;i<n;i++) {
		int u, v;
		read(u), read(v);
		add(u,v);
	}
	dfs(1);
	for (int i=1;i<=n;i++) {
		clr[dfn[i]]=c[i];
	}
	int lastans=0;
	/*for (int i=1;i<=n;i++) {
		cout << dfn[i] << " ";
	}
	cout << endl;
	for (int i=1;i<=n;i++) {
		cout << low[i] << " ";
	}
	cout << endl;
	for (int i=1;i<=n;i++) {
		cout << clr[i] << " ";
	}
	cout << endl;*/
	while (q--) {
		int opt;
		read(opt);
		if (opt==1) {
			int u,l,r;
			read(u), read(l), read(r);
			if (t==1) {
				u^=lastans;
				l^=lastans;
				r^=lastans;
			}
			int cnt=0;
			fill(book+1,book+n+1,0);
			for (int i=dfn[u];i<=low[u];i++) {
				if (clr[i]<=r && clr[i]>=l && !book[clr[i]]) cnt++, book[clr[i]]=true;
			}
			printf("%d\n",cnt);
			lastans=cnt;
		} else {
			int u,c;
			read(u), read(c);
			if (t==1) {
				u^=lastans;
				c^=lastans;
			}
			clr[dfn[u]]=c;
		}
	}
	return 0;
}

