#include <bits/stdc++.h>

namespace Force {

const int MAXN = 50000;
const int MOD = 1000000009;

inline int add(int x) {
    return x >= MOD ? x - MOD : x;
}

struct Interval {
    int l, r;

    inline bool operator<(const Interval &p) const {
        return l < p.l || (l == p.l && r < p.r);
    }
} in[MAXN];

int f[MAXN], a[MAXN], buc[MAXN], cnt, id[MAXN], ans, n, m;
std::bitset<20> vis;

void dfs(int i) {
    if (i == n) {
        vis.reset();        
        for (register int i = 0; i < n; i++) {
            if (id[i]) {
                for (register int j = 0; j < m; j++)
                    if (in[i].l <= a[j] && in[i].r >= a[j])
                        vis.set(j);
            }
        }
        ans += vis.count() == m;
        return;
    }
    id[i] = 1;
    dfs(i + 1);
    id[i] = 0;
    dfs(i + 1);
}

inline void solve() {
    std::cin >> n >> m;
    for (register int i = 0; i < n; i++) {
        std::cin >> in[i].l >> in[i].r;
    }
    for (register int i = 0; i < m; i++)
        std::cin >> a[i];
    dfs(0);
    std::cout << ans;
    return;
    memcpy(buc, a, sizeof(int) * (m));
    std::sort(buc, buc + m);
    cnt = std::unique(buc, buc + m) - buc;
    for (register int i = 0; i < n; i++) {
        in[i].l = std::lower_bound(buc, buc + cnt, in[i].l) - buc;
        in[i].r = std::upper_bound(buc, buc + cnt, in[i].r) - buc - 1;
    }
    std::sort(in, in + n);
    f[0] = 1;
    for (register int i = 0; i < n; i++) {
        if (in[i].l > in[i].r) {
            for (register int j = in[i].r + 1; j <= cnt; j++) 
                f[j] = add(f[j] + f[j]);
            continue;    
        }
        for (register int j = in[i].r + 1; j <= cnt; j++) 
            f[j] = add(f[j] + f[j]);
        for (register int j = in[i].l; j <= in[i].r; j++)
            f[in[i].r + 1] = add(f[in[i].r + 1] + f[j]);
    }
    std::cout << f[cnt];
}
}

int main() {
    freopen("xmasinterval.in", "r", stdin);
    Force::solve();
    return 0;
}