#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cstdio>
#include <queue>
using namespace std;

const int MAXN = 1e5 + 1000, MOD = 998244353;
int n, m, h;
int in[MAXN];
long long p[MAXN], val[MAXN], r[MAXN], f[32], c[600][600];
vector<int> e[MAXN], w[MAXN];
queue<int> q;

namespace Force
{
	long long fastpow(long long x, long long y)
	{
		long long ret = 1;
		while (y > 0)
		{
			if (y % 2 == 1)
				ret = ret * x % MOD;
			x = x * x % MOD;
			y /= 2;
		}
		return ret % MOD;
	}
	void init()
	{
		p[0] = 0;
		for (int i = 1; i < m + 1; ++i)
			p[i] = fastpow(i, h);
	}
	void main()
	{
		init();
		long long ans = 0;
		q.push(1);
		w[1].push_back(0);
		while (!q.empty())
		{
			int now = q.front();
			q.pop();
			for (int i = 0; i < w[now].size(); ++i)
				val[now] = (val[now] + p[w[now][i]]) % MOD;
			for (int i = 0; i < e[now].size(); ++i)
			{
				int v = e[now][i];
				for (int j = 0; j < w[now].size(); ++j)
					w[v].push_back(w[now][j] + 1);
				--in[v];
				if (in[v] == 0)
					q.push(v);
			}
		}
		for (int i = 1; i < n + 1; ++i)
			printf("%lld\n", val[i]);
	}
}

namespace Spe
{
	void init()
	{
		c[0][0] = 1;
		for (int i = 0; i < h + 1; ++i)
		{
			for (int j = 0; j < h + 1; ++j)
			{
				if (j > 0)
					c[i][j] = c[i - 1][j - 1];
				c[i][j] = (c[i][j] + c[i - 1][j]) % MOD;
			}
		}
	}
	void main()
	{
		q.push(1);
		while (!q.empty())
		{
			int now = q.front();
			q.pop();
			if (w[now].size() == 1)
				val[now] = Force::fastpow(r[now], h);
			else
			{
				long long o = 1;
				for (int i = 0; i < w[now].size(); ++i)
				{
					int b = w[now][i];
					val[now] += b * o % MOD;
					val[now] %= MOD;
					o = o * r[now] % MOD; 
				}
			}
			for (int i = 0; i < e[now].size(); ++i)
			{
				int v = e[now][i];
				if (w[v].size() == 0)
				{
					for (int i = 0; i < w[now].size(); ++i)
						w[v].push_back(w[now][i]);
					r[v] = r[now] + 1;
				}
				else
				{
					long long d = r[now] - r[v];
					memset(f, 0, sizeof f);
					for (int i = 0; i < w[now].size(); ++i)
					{
						for (int k = 0; k < i + 1; ++i)
						{
							f[i - k] += c[i][k] * c[i][i - k] % MOD * d % MOD;
							f[i - k] %= MOD;
						}
					}
					for (int i = 0; i < w[v].size(); ++i)
					{
						w[v][i] += f[i];
						w[v][i] %= MOD;
					}
				}
				--in[v];
				if (in[v] == 0)
					q.push(v);
			}
		}
		for (int i = 1; i < n + 1; ++i)
			printf("%lld\n", val[i]);
	}
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	n = read();
	m = read();
	h = read();
	for (int i = 0; i < m; ++i)
	{
		int u = read(), v = read();
		e[u].push_back(v);
		++in[v];
	}
	if (n <= 2000)
		Force::main();
	else 
		Spe::main();
	fclose(stdin);
	fclose(stdout);
}
