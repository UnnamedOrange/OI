#include <bits/stdc++.h>
using namespace std;
const int maxn = 100 +10;
int ai[maxn];
int n,ans;
bool chk(){
	for(int i=2;i<=n;i++)if(ai[i]<ai[i-1])return 0;return 1;
}
int dfs(int step,int bas){
	if(step+bas==ans&&bas==0&&chk())return 1;
	if(step+bas>ans)return 0;
	for(int i=2;i<=n;i++){
		int bas2 = bas;
		if(i!=n){
			if( abs(ai[1] - ai[i+1]) == 1)--bas2;
			if( abs(ai[i] - ai[i+1]) == 1)++bas2;
		}
		reverse(ai+1,ai+1+i);
		int tmp=dfs(step+1,bas2);
		reverse(ai+1,ai+1+i);
		if(tmp)return 1;
	}
	return 0;
}
int main(){
	freopen("sequence.in","r",stdin),freopen("sequence.out","w",stdout);
	int T;scanf("%d",&T);
	for(int cas=1;cas<=T;cas++){	
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&ai[i]);
		int bas=0;
		for(int i=2;i<=n;i++)if(abs(ai[i]-ai[i-1])!=1)++bas;
		for(ans=0;;ans++)if(dfs(0,bas))break;
		printf("%d\n",ans);
	}
	return 0;
}
