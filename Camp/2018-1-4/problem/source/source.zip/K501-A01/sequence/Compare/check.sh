g++ foo.cpp -o foo -lm
g++ gen.cpp -o gen -lm
g++ bar.cpp -o bar -lm
while true; do
	./gen
	./foo
	./bar
	diff sequence.out sequence.ans || break;
	echo AC!!
done;


