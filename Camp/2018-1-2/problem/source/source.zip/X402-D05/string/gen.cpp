#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int T=20;
	int n=100000;
	printf("%d\n",T);
	while(T--){
		printf("%d\n",n);
		int maxval=rand()%3+1;
		for(int i=1;i<=n;i++)
			printf("%c",rand()%maxval+'a');
		printf("\n");
	}
}
int main(){
	srand(time(0)+getx());
	freopen("string.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
