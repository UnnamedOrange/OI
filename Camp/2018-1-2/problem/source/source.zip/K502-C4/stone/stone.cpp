#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#define mod 1000000007
using namespace std;

int n,a,b,x[100005],c[100005];
bool changeflag,vis[100005];
long long ans[5];

void judge(int i)
{
	int k=x[i]%(a+b);
	if(k<a) c[i]=4;
	else if(k>=a&&k<b) c[i]=1;
	else c[i]=3;
}

int decide(int u,int v)
{
	if(v==0) return u;
	if(u==1||v==1) return 1;
	if(u==3&&v==3) return 1;
	if(u==3&&v==4 || u==4&&v==3) return 3;
	if(u==4&&v==4) return 4;
}

void dfs(int now,int type)
{
	if(now==n+1)
	{
		/*
		for(int i=1;i<=n;i++)
			if(vis[i]==1) printf("%d ",x[i]);
		printf("type=%d\n",type);
		*/ 
		if(type==0) type=4;
		ans[type]++;
		ans[type]%=mod;
		return;
	}
	dfs(now+1,type);
	int newtype = decide(c[now],type);
	vis[now]=1;
	dfs(now+1,newtype);
	vis[now]=0;
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	if(a>b) swap(a,b), changeflag=1;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&x[i]);
		judge(i);
	}
	dfs(1,0);
	if(changeflag==1) swap(ans[1],ans[2]);
	for(int i=1;i<=4;i++)
		printf("%lld ",ans[i]);
	return 0;
}
