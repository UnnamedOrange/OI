#include<bits/stdc++.h>
using namespace std;
#define mp make_pair
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
typedef pair<int,int> PII;
const int mo=998244353;
const int maxn=100010;
int n,m,ans;
int fpm(int x,long long k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}
int fac[maxn],cnt;
PII book[100];
bool G[10][10];
bool vis[10];
void init(){
    fac[0]=1;
    for(int i=1;i<=maxn-10;i++) fac[i]=1ll*fac[i-1]*i%mo;
}
bool dfs(int goal,int u,int step){
    if(step==m+1) return u==goal;
    vis[u]=1;
    for(int i=1;i<=n;i++) if(G[u][i]&&(!vis[i]||step==m)&&dfs(goal,i,step+1)) return 1;
    vis[u]=0;
    return 0;
}
int main(){
    freopen("tournament.in","r",stdin);
    freopen("tournament.out","w",stdout);
    init();
    read(n); read(m);
    if(m==3) printf("%d\n",((fpm(2,1ll*n*(n-1)/2)-fac[n])%mo+mo)%mo),exit(0);
    int lim=n*(n-1)/2;
    for(int i=1;i<=n;i++)
        for(int j=i+1;j<=n;j++) book[++cnt]=mp(i,j);
    for(int s=0;s<(1<<lim);s++){
        memset(G,0,sizeof G);
        for(int i=1;i<=lim;i++){
            int u=book[i].first,v=book[i].second;
            ((s>>(i-1))&1)?G[u][v]=1:G[v][u]=1;
        }
        memset(vis,0,sizeof vis);
        if(dfs(1,1,1)) ++ans;
    }
    printf("%d\n",ans);
    return 0;
}
