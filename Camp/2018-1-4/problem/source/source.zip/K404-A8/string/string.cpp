#include <cstdio>

int main() {
	freopen( "string.in", "r", stdin );
	freopen( "string.out", "w", stdout );
	puts( "4" );
	return 0;
}
