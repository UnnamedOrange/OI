#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
const int maxn=1000010;
const int mod=1e9+9;
int n,m;
struct node{
	int x, y;
	bool operator <(const node& A)const{ return y<A.y || (y==A.y && x<A.x); }
}a[maxn];
int c[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int ans, vis[maxn], cnt;
int dp[maxn];
int main(){
	freopen("xmasinterval.in","r",stdin),freopen("xmasinterval.out","w",stdout);

	read(n), read(m);
	//printf("n = %d\n", n);
	for(int i=1;i<=n;i++) read(a[i].x), read(a[i].y);
	for(int i=1;i<=m;i++) read(c[i]);
	sort(c+1,c+1+m);
	cnt=unique(c+1,c+1+m)-c-1;
	// for(int i=1;i<=cnt;i++) printf("%d ", c[i]); puts("");
	for(int i=1;i<=n;i++) a[i].x=lower_bound(c+1,c+1+cnt,a[i].x)-c, a[i].y=upper_bound(c+1,c+1+cnt,a[i].y)-c-1;
	sort(a+1,a+1+n);
	 for(int i=1;i<=n;i++) printf("%d %d\n", a[i].x, a[i].y);
	dp[0]=1;
	for(int i=1;i<=n;i++){
		dp[i]=1;
		for(int j=0;j<i;j++){
			if(a[j].y+1>=a[i].x) (dp[i]+=dp[j])%=mod;
		}
		 printf("dp[ %d ] = %d\n", i, dp[i]);
	}
	for(int i=1;i<=n;i++) if(a[i].y==n) (ans+=dp[i])%=mod;
	printf("%d\n", ans);
	return 0;
}
