#include <cstdio>
#include <algorithm>
#define FOR(i, l, r) for(LL i = l; i <= r; ++i)

using namespace std;

typedef long long LL;
const int Maxn = 1000000;
const int M = 100100;

LL pr[Maxn], pn, F[Maxn + 10], fr[Maxn + 10];
LL CntP[M], SumP1[M], L0[M], L1[M], g0[M], g1[M], f0[M], f1[M];
bool vis[Maxn + 10]; int T; LL n;

void getprime()
{
    F[1] = 1;
    FOR(i, 2, Maxn)
    {
        if (!vis[i]) pr[pn++] = i, F[i] = 3, fr[i] = i;
        FOR(j, 0, pn - 1)
        {
            if (i * pr[j] > Maxn) break;
            vis[i * pr[j]] = 1;
            if (!(i % pr[j]))
            {
                if (i == fr[i]) F[i * pr[j]] = F[i] + 2;
                else F[i * pr[j]] = F[i / fr[i]] * F[pr[j] * fr[i]];
                fr[i * pr[j]] = fr[i] * pr[j];
				break;
            }
            else F[i * pr[j]] = F[i] * 3,fr[i * pr[j]] = pr[j];
        }
    }
}

void GetG(LL sq, LL PN, LL n)
{
    FOR(i, 1, sq - 1) g0[i] = i, g1[i] = n / i;
    FOR(i, 0, PN - 1)
    {
        for(LL j = 1; j < sq && i < L1[j]; ++j)
        {
            LL y = n / j / pr[i];
            g1[j] -= ((y < sq) ?
                (g0[y] - max(0LL, min(i, CntP[y]) - L0[y])) :
                (g1[n / y] - max(0LL, i - L1[n / y])));
        }
        for(LL j = sq-1; j && i < L0[j]; --j)
        {
            LL y = j / pr[i];
            g0[j] -= (g0[y] - max(0LL, min(i, CntP[y]) - L0[y]));
        }
    }
    FOR(i, 1, sq - 1) g0[i] -= CntP[i] - L0[i] + 1, g1[i] -= max(0LL, PN - L1[i]) + 1;
    FOR(i, 1, sq - 1) g0[i] *= 3, g1[i] *= 3;
}

void GetF(LL sq, LL PN, LL n)
{
    FOR(i, 1, sq - 1) f0[i] = f1[i] = 1;
    for(LL i = PN - 1; ~i; --i)
    {
        for (LL j = 1; j < sq && i < L1[j]; ++j)
        {
            LL y = n / j / pr[i];
            for(LL c = 1; y; y /= pr[i], ++c)
                f1[j] += (2 * c + 1) * ((y < sq)?
                    (f0[y] + 3 * max(0LL, CntP[y] - max(i + 1, L0[y]))):
                    (f1[n / y] + 3 * max(0LL, PN - max(i + 1, L1[n / y]))));
        }
        for(LL j = sq-1; j && i < L0[j]; --j)
        {
            LL y = j / pr[i];
            for(LL c = 1; y; y /= pr[i], ++c)
                f0[j] += (2 * c + 1) * (f0[y] + 3 * max(0LL, CntP[y] - max(i + 1,L0[y])));
        }
    }
    FOR(i, 1, sq - 1) f0[i] += 3 * max(0LL, CntP[i] - L0[i]), f1[i] += 3 * (PN - L1[i]);
}

LL getsum(LL n)
{
    LL sq = 1, PN = 0;
    for (; sq * sq <= n; ++sq);
    for (; pr[PN] * pr[PN] <= n; ++PN);
    L0[0]=0; L1[sq]=0;
    FOR(i, 1, sq - 1) for(L0[i] = L0[i - 1]; pr[L0[i]] * pr[L0[i]] <= i; ++L0[i]);
    for (LL i = sq - 1; i; --i) 
    {
        LL x = n / i;
        for (L1[i] = L1[i + 1]; pr[L1[i]] * pr[L1[i]] <= x; ++L1[i]);
    }
    CntP[0] = 0;
    FOR(i, 1, sq - 1) for (CntP[i] = CntP[i-1]; pr[CntP[i]] <= i; ++CntP[i]);
    GetG(sq, PN, n); GetF(sq, PN, n);
    LL Ans = f1[1]; FOR(i, 1, sq - 1) Ans += F[i] * g1[i];
    return Ans;
}

int main()
{
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
    getprime();
    scanf("%d", &T);
    while (T--)
    {
        scanf("%lld", &n);
        printf("%lld\n", getsum(n));
    }
    return 0;
}
