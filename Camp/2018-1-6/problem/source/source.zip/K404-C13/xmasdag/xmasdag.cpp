#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>
using namespace std;

const int N=100005;
const int M=200005;
const int K=505;
const int S=2005;
const int mod=998244353;

struct E{
	int to,next;
}mem[M<<1];
int n,m,l,num,x,y,ans;
int d[N],head[N],dp[N][K],c[K][K],f[S][S],pw[S];
queue<int> q;

void add(int x,int y){
	num++;
	mem[num].to=y; mem[num].next=head[x];
	head[x]=num;
}

void init(){
	int i,j;
	c[0][0]=1;
	for (i=1;i<=l;i++){
		c[i][0]=1;
		for (j=1;j<=i;j++) c[i][j]=(c[i-1][j]+c[i-1][j-1])%mod;
	}
}

int quickpow(int x,int y){
	int s=1;
	for (;y;y>>=1,x=1ll*x*x%mod)
		if (y&1) s=1ll*s*x%mod;
	return s;
}

int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	int i,k,u,j,p;
	scanf("%d%d%d",&n,&m,&l);
	for (i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		add(x,y); d[y]++;
	}
	if (n<=2000&&k>30){
		f[1][0]=1; q.push(1);
		while (!q.empty()){
			k=q.front(); q.pop();
			for (j=head[k];j;j=mem[j].next){
				u=mem[j].to; d[u]--;
				for (i=1;i<=n;i++) f[u][i]=(f[u][i]+f[k][i-1])%mod;
				if (!d[u]) q.push(u);
			}
		}
		for (i=0;i<=n;i++) pw[i]=quickpow(i,l);
		for (i=1;i<=n;i++){
			ans=0;
			for (j=0;j<=n;j++){
				ans=(ans+1ll*f[i][j]*pw[j]%mod)%mod;
			}
			printf("%d\n",ans);
		}
		return 0;
	}
	init();
	q.push(1); dp[1][0]=1;
	while (!q.empty()){
		k=q.front(); q.pop();
		for (j=head[k];j;j=mem[j].next){
			u=mem[j].to; d[u]--;
			for (i=0;i<=l;i++)
				for (p=0;p<=i;p++) dp[u][i]=(dp[u][i]+1ll*c[i][p]*dp[k][p]%mod)%mod;
			if (!d[u]) q.push(u);
		}
	}
	for (i=1;i<=n;i++) printf("%d\n",dp[i][l]);
	return 0;
}
