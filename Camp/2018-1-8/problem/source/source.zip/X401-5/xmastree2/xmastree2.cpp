/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
#define MAXN 30000
typedef long long LL;
struct Edge
{
	int to,next;
}e[2*MAXN+10];
int head[MAXN+10];
void addEdge(int a,int b)
{
	static int c=0;
	e[++c]=(Edge){b,head[a]};
	head[a]=c;
	e[++c]=(Edge){a,head[b]};
	head[b]=c;
}
int f[MAXN+10];
int find(int x)
{
	if (f[x]==x) return x;
	return f[x]=find(f[x]);
}
int w[MAXN+10],r[MAXN+10];
int fa[MAXN+10];
void dfs(int now,int fa)
{
	::fa[now]=fa;
	for(int i=head[now]; i!=0; i=e[i].next)
	{
		if (e[i].to==fa) continue;
		dfs(e[i].to,now);
	}
}
struct Data
{
	int size;
	LL sum;
}p[MAXN+10];
struct Comp
{
	bool operator()(const int a,const int b)
	{
		int t=p[a].sum*p[b].size-p[b].sum*p[a].size;
		if (t==0) return a<b;
		return t<0;
	}
};
set<int,Comp> s;
int main()
{
	freopen("xmastree2.in","r",stdin);
#ifndef MDEBUG  
	freopen("xmastree2.out","w",stdout);
#endif
	int n;
	scanf("%d",&n);
	LL Max=0;
	for(int i=1; i<n; ++i)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		addEdge(a,b);
	}
	for(int i=1; i<=n; ++i)
	{
		scanf("%d%d",&w[i],&r[i]);
	}
	for(int nr=1; nr<=n; ++nr)
	{
		if (r[nr]==0) continue;
		LL ans=0;
		dfs(nr,0);
		for(int i=1; i<=n; ++i)
		{
			p[i].sum=w[i];
			p[i].size=1;
			ans+=w[i];
		}
		for(int i=1; i<=n; ++i)
		{
			f[i]=i;
		}
		s.clear();
		for(int i=1; i<=n; ++i)
		{
			if (i==nr) continue;
			s.insert(i);
		}
		while(!s.empty())
		{
			int now=*s.begin();
			s.erase(s.begin());
			int nf=find(fa[now]);
			if (nf!=nr) s.erase(nf);
			ans+=p[now].sum*p[nf].size;
			p[nf].sum+=p[now].sum;
			p[nf].size+=p[now].size;
			f[now]=nf;
			if (nf!=nr) s.insert(nf);
		}
		Max=max(Max,ans);
	}
	printf("%lld\n",Max);
    return 0;
}
