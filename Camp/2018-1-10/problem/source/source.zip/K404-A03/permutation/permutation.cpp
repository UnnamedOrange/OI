//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const int maxn=1e5+10;
const ll mod=998244353;
ll n,p[maxn],ans,now[maxn],fa[maxn];

ll aa;char cc;
ll read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

bool vis[maxn];
int get_ans() {
	memset(vis,0,sizeof(vis));
	int t;
	for(int i=1;i<=n;++i) if(!vis[i]){
		vis[i]=1;t=0;
		for(int j=p[i];j!=i;j=p[j]) {
			vis[j]=1; t^=1;
		}
		if(!t) return 0;
	}
	return 1;
}

void s(int pos) {
	if(pos==n+1) {
		ans+=get_ans();
		return ;
	}
	if(p[pos]) now[p[pos]]=1,s(pos+1);
	else {
		for(int i=1;i<=n;++i) if(!now[i]&&i!=pos) {
			now[p[pos]=i]=1;
			s(pos+1);
			now[p[pos]]=0;
			p[pos]=0;
		}
	}
}

int main() {
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) p[i]=read();
	if((n&1)==0) {
		if(n<=8) s(1);
		else {
			ans=1;
			for(ll i=3;i<n;i+=2) ans=ans*i%mod*i%mod;
		}
	}
	printf("%lld",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
6
2 0 0 0 0 0
*/
