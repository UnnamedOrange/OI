#include<bits/stdc++.h>
using namespace std;
bool f[5000000];
int pr[5000000],mu[5000000],o[5000000],sum[5000000],t[5000000],tot=0;
void getpri(){
	mu[1]=1;
	o[1]=1;
	for (int i=2;i<=3e6;i++){
		if (!f[i]){
			pr[++tot]=i;
			mu[i]=-1;
			o[i]=2;
			t[i]=1;
		}
		for (int j=1;j<=tot;j++){
			int x=i*pr[j];
			if (x>3e6) break;
			f[x]=1;
			if (i%pr[j]){
				mu[x]=-mu[i];
				o[x]=o[i]*2;
				t[x]=i;
			}
			else{
				mu[x]=0;
				if (t[i]==1) o[x]=o[i]+1;
				else o[x]=o[x/t[i]]*o[t[i]];
				t[x]=t[i];
				break;
			}
		}
	}
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	getpri();
	for (int i=1;i<=3e6;i++)
		sum[i]=sum[i-1]+mu[i];
	int t;
	scanf("%d",&t);
	while (t--){
		int n;
		scanf("%d",&n);
		long long ans=0;
		for (int i=1;i<=n;i++)
			ans+=(long long)sum[n/i]*o[i]*o[i];
		printf("%lld\n",ans);
	}
	return 0;
}
