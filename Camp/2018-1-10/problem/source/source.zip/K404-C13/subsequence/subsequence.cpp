#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

const int N=4005;

struct ST{
	int l,r,mn;
}t[N<<2];
int n,m,k,inf,now,last,x,y;
int dp[N][N],a[N],b[N],nxt1[N][N],nxt2[N][N],mp[N][N],p[N],fm[N],ml[N],pl[N];
bool vis[N];

void init(){
	int i,j;
	for (i=1;i<=k;i++) nxt1[n+1][i]=n+1;
	for (i=1;i<=k;i++) nxt2[m+1][i]=m+1;
	for (i=n;i>=0;i--){
		memcpy(nxt1[i],nxt1[i+1],sizeof(nxt1[i]));
		nxt1[i][a[i+1]]=i+1;
	}
	for (i=m;i>=0;i--){
		memcpy(nxt2[i],nxt2[i+1],sizeof(nxt2[i]));
		nxt2[i][b[i+1]]=i+1;
	}
}

void build(int k,int l,int r){
	t[k].l=l; t[k].r=r;
	t[k].mn=inf;
	if (l==r) return;
	int mid=(l+r)>>1;
	build(k<<1,l,mid);
	build(k<<1|1,mid+1,r);
}

void update(int k){
	t[k].mn=min(t[k<<1].mn,t[k<<1|1].mn);
}

void modify(int k,int p,int w){
	if (t[k].l==t[k].r){
		t[k].mn=w;
		return;
	}
	int mid=(t[k].l+t[k].r)>>1;
	if (p<=mid) modify(k<<1,p,w);
	else modify(k<<1|1,p,w);
	update(k);
}

void modifym(int k,int p,int w){
	if (t[k].l==t[k].r){
		t[k].mn=min(t[k].mn,w);
		return;
	}
	int mid=(t[k].l+t[k].r)>>1;
	if (p<=mid) modifym(k<<1,p,w);
	else modify(k<<1|1,p,w);
	update(k);
}

void cm(int k,int w){
	t[k].mn=min(t[k].mn,w);
}

void pushdown(int k){
	t[k<<1].mn=min(t[k<<1].mn,t[k].mn);
	t[k<<1|1].mn=min(t[k<<1|1].mn,t[k].mn);
}

void modifys(int k,int L,int R,int w){
	if (L<=t[k].l&&t[k].r<=R){
		cm(k,w);
		return;
	}
	pushdown(k);
	int mid=(t[k].l+t[k].r)>>1;
	if (L<=mid) modifys(k<<1,L,R,w);
	if (R>mid) modifys(k<<1|1,L,R,w);
}

int query(int k,int p){
	if (t[k].l==t[k].r) return t[k].mn;
	pushdown(k);
	int mid=(t[k].l+t[k].r)>>1;
	if (p<=mid) return query(k<<1,p);
	else return query(k<<1|1,p);
}

int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	int i,j,c,l,r,mid;
	scanf("%d%d%d",&n,&m,&k);
	for (i=1;i<=n;i++) scanf("%d",&a[i]);
	for (i=1;i<=m;i++) scanf("%d",&b[i]);
	init();
	if (n<=300&&m<=300&&k<=300){
		memset(dp,0x3f,sizeof(dp)); inf=dp[0][0];
		dp[0][0]=0;
		for (i=0;i<=n+1;i++)
			for (j=0;j<=m+1;j++){
				if (dp[i][j]>=inf) continue;
				for (c=1;c<=k;c++){
					dp[nxt1[i][c]][nxt2[j][c]]=min(dp[nxt1[i][c]][nxt2[j][c]],dp[i][j]+1);
				}	
			}
		printf("%d\n",dp[n+1][m+1]);
		return 0;
	}
	memset(dp,0x3f,sizeof(dp)); inf=dp[0][0];
	dp[0][0]=0;
	for (i=1;i<=k;i++) dp[nxt1[0][i]][nxt2[0][i]]=1;
	for (i=1;i<=n;i++) mp[a[i]][++p[a[i]]]=i;
	for (i=1;i<=k;i++) mp[i][++p[i]]=n+1;
	for (i=1;i<=n;i++){
		build(1,1,k); last=0;
		for (j=1;j<=m;j++){
			c=b[j];
			if (mp[c][1]>i) continue;
			l=1; r=p[c];
			while (l<r){
				mid=(l+r+1)>>1;
				if (mp[c][mid]<i) l=mid;
				else r=mid-1;
			}
			now=mp[c][l];
			if (c!=a[i]) modify(1,c,dp[now][j]);
			else{
				dp[i][j]=min(dp[i][j],t[1].mn+1);
				for (;last+1<j;){
					last++; modify(1,b[last],inf);
				}
				if (now<i) modify(1,c,dp[now][j]);
			}
		}
	}
	for (i=1;i<=k;i++){
		for (j=n;j>=1;j--)
			if (nxt1[j][i]==n+1) fm[i]=j;
		else break;
	}
	for (j=1;j<=m;j++){
		ml[n+1]=dp[n+1][j];
		for (i=n;i>=1;i--) ml[i]=min(ml[i+1],dp[i][j]);
		for (i=1;i<=k;i++){
			l=fm[i];
			dp[n+1][nxt2[j][i]]=min(dp[n+1][nxt2[j][i]],ml[l]+1);
		}
	}
	for (i=1;i<=n;i++){
		if (dp[i][m+1]==inf) continue;
		for (j=1;j<=k;j++) dp[nxt1[i][j]][m+1]=min(dp[nxt1[i][j]][m+1],dp[i][m+1]+1);
	}
	for (i=1;i<=n+1;i++) pl[i]=m+1;
	build(1,1,n+1);
	modifys(1,1,n+1,m+1);
	for (i=1;i<=k;i++){
		for (x=n;x&&nxt1[x][i]==n+1;x--);
		for (y=m;y&&nxt2[y][i]==m+1;y--);
		modifys(1,x+1,n+1,y+1);
	}
	for (i=1;i<=n+1;i++){
		pl[i]=query(1,i);
		for (j=pl[i];j<=m+1;j++) dp[n+1][m+1]=min(dp[n+1][m+1],dp[i][j]+1);
	}
	printf("%d\n",dp[n+1][m+1]);
	return 0;
}
