//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=26;
typedef long long LL;
using namespace std;
int T,n,a[N],b[N],ans;

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

void dfs(int now) {
	if(now>=ans) return;
	int fl=1,gj=0;
	for(int i=1;i<=n;i++) 
		if(a[i]!=i) {
			fl=0;
			break;
		}
	if(fl) {
		ans=min(ans,now);
		return;
	}
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=i/2;j++) 
			swap(a[j],a[i-j+1]);
		dfs(now+1);
		for(int j=1;j<=i/2;j++) 
			swap(a[j],a[i-j+1]);
	}
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
#endif
	read(T);
	while(T--) {
		read(n);
		for(int i=1;i<=n;i++) {read(a[i]); b[i]=a[i];}
		int now=n;
		ans=0;
		while(now>1) {
			for(int i=1;i<=n;i++) 
				if(a[i]==now) {
					int j=i+1,k=i-1;
					if(a[j]==now-1) {
						for(int l=2;i+l<=n;l++) {
							if(a[i+l]==a[j]-1) 
								j=i+l;
							else break;
						}
						int tpp=a[j]-1;
						if(i==1) {
							ans+=1;
							for(int l=1;l<=now/2;l++)
								swap(a[l],a[now-l+1]);
						}
						else {
							ans+=3;
							for(int l=1;l<=j/2;l++) 
								swap(a[l],a[j-l+1]);
							for(int l=1;l<=now/2;l++)
								swap(a[l],a[now-l+1]);
						}
						now=tpp;
					}
					else if(a[k]==now-1) {
						for(int l=2;i-l>=1;l++) {
							if(a[i-l]==a[k]-1) 
								k=i-l;
							else break;
						}
						int tpp=a[k]-1;
						if(i==now) ans=ans;
						else {
							ans+=2;
							for(int l=1;l<=i/2;l++) 
								swap(a[l],a[i-l+1]);
							for(int l=1;l<=now/2;l++)
								swap(a[l],a[now-l+1]);
						}
						now=tpp;
					}
					else {
						if(i!=now) {
							if(i==1) ans+=1;
							else ans+=2;
							for(int l=1;l<=i/2;l++) 
								swap(a[l],a[i-l+1]);
							for(int l=1;l<=now/2;l++)
								swap(a[l],a[now-l+1]);
						}
						now--;
					}
					break;
				}
		}
		for(int i=1;i<=n;i++) a[i]=b[i];
		dfs(0);
		printf("%d\n",ans);
	}
	return 0;
}
