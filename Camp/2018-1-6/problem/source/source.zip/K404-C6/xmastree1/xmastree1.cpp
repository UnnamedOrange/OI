#include <bits/stdc++.h>
 
#define fir first
#define sec second
#define MP make_pair
#define PB push_back
 
using namespace std;
typedef long long LL;
typedef unsigned long long u64;
 
template <typename T> inline bool cmin(T & a, const T & b) { return a > b ? a = b, 1 : 0;}
template <typename T> inline bool cmax(T & a, const T & b) { return a < b ? a = b, 1 : 0;}
int read() {
    int x = 0, f = 1;char ch;
    for(ch = getchar(); !isdigit(ch); ch = getchar())
        if(ch == '-') f = -1;
    for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
    return x * f;
}

const int MaxN = 101234, MaxM = MaxN << 1;

int n, q, c[MaxN], v[MaxN];
struct edge {int to, nxt;} e[MaxM]; int cnt, lst[MaxN];
void addEdge(int a, int b) {
	e[++cnt] = (edge) {b, lst[a]}; lst[a] = cnt;
}

int in[MaxN], out[MaxN], pos[MaxN], dfn;
void dfs(int x, int fa = 0) {
	in[x] = ++dfn; pos[in[x]] = x;
	for(int i = lst[x], y; y = e[i].to, i; i = e[i].nxt) {
		if(y == fa) continue;
		dfs(y, x);
	}
	out[x] = dfn;
}

int main() {
	int i;
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	n = read();	q = read(); int ty = read();
	for(i = 1; i <= n; i++) {
		c[i] = read();
	}
	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		addEdge(u, v);
		addEdge(v, u);
	}
	dfs(1);
	int lastans = 0;
	int T = 1;
	while(q--) {
		int op, x; op = read(); x = read() ^ lastans;
		if(op == 1) {
			int l = read() ^ lastans, r = read() ^ lastans;
			int ans = 0;
			for(i = in[x]; i <= out[x]; i++)
				if(c[pos[i]] >= l && c[pos[i]] <= r && v[c[pos[i]]] != T) 
					ans++, v[c[pos[i]]] = T;
			if(ty) lastans = ans; T++;
			printf("%d\n", ans);
		} else {
			int y = read() ^ lastans;
			c[x] = y;
		}
	
	}
	return 0;
}
