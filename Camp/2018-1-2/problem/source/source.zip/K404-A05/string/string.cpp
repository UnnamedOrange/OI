//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
int Tn;
char s[100111];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&Tn);
	while(Tn--)
	{
		int n;
		scanf("%d",&n);
		scanf("%s",s);
		bool allsame=1;
		for(int i=0;i<n;i++)allsame&=s[i]==s[0];
		if(allsame)puts("-1");
		else
		{
			bool ispalindrome=1;
			for(int i=0;i<n;i++)ispalindrome&=s[i]==s[n-i-1];
			if(ispalindrome)
			{
				if(n%2==0)puts("2");
				else
				{
					int cnt=0;
					for(int i=0;i<n;i++)cnt+=s[i]==s[0];
					bool f0=1,f1=1;
					for(int i=0;i<n;i+=2)f0&=s[i]==s[0];
					for(int i=1;i<n;i+=2)f1&=s[i]==s[1];
					if(cnt==n-1||f0&&f1)puts("-1");
					else puts("2");
				}
			}
			else puts("1");
		}
	}
	return 0;
}
