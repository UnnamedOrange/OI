#include <bits/stdc++.h>
#define LL long long
using namespace std;
const LL Maxn = 100;
LL Begin[Maxn], To[Maxn], Next[Maxn], e;
LL W[Maxn], r[Maxn], fa[Maxn];
LL N;
inline void add(LL x, LL y)
{
	To[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}
inline void pre_dfs(LL x)
{
	for (LL i = Begin[x]; i; i = Next[i])
	{
		LL y = To[i];
		if (fa[x] == y) continue ;
		fa[y] = x;
		pre_dfs(y);
	}
}
LL P[Maxn], Q[Maxn], fan[Maxn], Ans;
inline void Check()
{
	/*
	for (LL i = 1; i <= N; ++i)
		cout<<Q[i]<<" ";
	cout<<endl;
	for (LL i = 1; i <= N; ++i)
		cout<<fan[i]<<" ";
	cout<<endl<<endl;
	*/
	for (LL i = 1; i <= N; ++i)
		if (fan[fa[i]] > fan[i]) return ;
	LL Sum = 0;
	for (LL i = 1; i <= N; ++i)
		Sum += W[Q[i]] * i;
	Ans = max(Ans, Sum);
}
inline void dfs(LL x)
{
	if (x == N)
	{
		Check();
		return ;
	}
	for (LL i = 1; i <= N; ++i)
	{
		if (!P[i])
		{
			P[i] = 1;
			Q[x + 1] = i;
			fan[i] = x + 1;
			dfs(x + 1);
			P[i] = 0;
		}
	}
}
int main()
{
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	scanf("%lld", &N);
	for (LL i = 1; i < N; ++i)
	{
		LL x, y;
		scanf("%lld%lld", &x, &y);
		add(x, y);
		add(y, x);
	}
	for (LL i = 1; i <= N; ++i)
		scanf("%lld%lld", &W[i], &r[i]);
	for (LL i = 1; i <= N; ++i)
	{
		if (r[i])
		{
			memset(fa, 0, sizeof(fa));
			fa[i] = i;
			memset(fan, 0, sizeof(fan));
			memset(P, 0, sizeof(P));
			pre_dfs(i);
			dfs(0);
		}
	}
	cout<<Ans<<endl;
	return 0;
}
