#include <bits/stdc++.h>
using namespace std ;
const int maxn = 105 ;
int n ;
char s[maxn] ;
int solve ( char *c, int m ) {
	int i, j, l, r, ans = 0x3f3f3f3f ;
	if (m == 0) return 0 ;
	if (m == 1) return ans ;
	/*printf ( "solve %d : ", m ) ;
	for ( i = 0 ; i < m ; i ++ )
		putchar(c[i]) ;
	puts("") ;*/
	bool fg ;
	char t[maxn] ;
	for ( i = 0 ; i < m ; i ++ )
		for ( j = i+1 ; j < m ; j ++ ) {
			fg = 0 ;
			for ( l = i, r = j ; l < r ; l ++, r -- )
				if (c[l] ^ c[r]) {
					fg = 1 ;
					break ;
				}
			if (!fg) continue ;
			l = 0 ;
			for ( r = 0 ; r < i ; r ++ )
				t[l ++] = c[r] ;
			for ( r = j+1 ; r < m ; r ++ )
				t[l ++] = c[r] ;
			ans = min(ans, solve(t, l)+1) ;
		}

	return ans ;
}
int main() {
	freopen ( "string.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;

	int k, _ ;
	scanf ( "%d", &_ ) ;
	while (_--) {
		scanf ( "%d", &n ) ;
		scanf ( "%s", s ) ;
		k = solve(s, n) ;
		if (k == 0x3f3f3f3f) k = -1 ;
		printf ( "%d\n", k ) ;
	}
	return 0 ;
}
