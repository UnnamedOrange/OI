#include<bits/stdc++.h>
#define random(l,r) (l == r ?l : (((int)rand()) % (r - l + 1)) + l)
using namespace std;
int n = 100000,m = 100000;
queue<int>q;
void bfs(int top)
{
	int now = 0;
	q.push(1);
	while(!q.empty())
	{
		if(now == m) break;
		int x = q.front(); q.pop();
		if(x == n) continue;
		int sz = random(0,m - now);
		while(sz--)
		{
			++now;
			int z;
			printf("%d %d\n",x,z = random((x + 1),n));
			if(x != n)
				q.push(z);
		}
	}
}
int main()
{
	freopen("xmasdag.in","w",stdout);
	srand(time(NULL));
	printf("%d ",n);printf("%d %d\n",m,3);
	bfs(m);
	return 0;
}
