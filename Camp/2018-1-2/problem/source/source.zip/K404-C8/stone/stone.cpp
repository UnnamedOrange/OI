#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=100005;
const int mod=1e9+7;

int n,a,b,t,f[2][2],g[2][2],ty;
inline void MOD(int &x) {if (x>=mod) x-=mod;}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	
	scanf("%d%d%d",&n,&a,&b);if (a>b) swap(a,b),ty=1;
	
	g[0][0]=1;
	for (int i=1;i<=n;i++) 
	{
		scanf("%d",&t);t=t%(a+b);
		if (t<a) 
		{
			MOD(g[0][0]=g[0][0]<<1);MOD(g[0][1]=g[0][1]<<1);
			MOD(g[1][0]=g[1][0]<<1);MOD(g[1][1]=g[1][1]<<1);
		}
		else
		{
			for (int x=0;x<=1;x++)
			for (int y=0;y<=1;y++) 
			if (t>=a&&t<b)
			{
				MOD(f[x][y]+=g[x][y]);
				MOD(f[x][y|1]+=g[x][y]);
			}
			else 
			{
				MOD(f[x][y]+=g[x][y]);
				MOD(f[x^1][y]+=g[x][y]);
			}
			g[0][0]=f[0][0];g[0][1]=f[0][1];g[1][0]=f[1][0];g[1][1]=f[1][1];
			f[0][0]=f[0][1]=f[1][0]=f[1][1]=0;
		}
	}
	if (ty) printf("0 %d ",(g[1][1]+g[0][1])%mod);else printf("%d 0 ",(g[1][1]+g[0][1])%mod);	
	printf("%d %d\n",g[1][0],g[0][0]);
	return 0;
}

