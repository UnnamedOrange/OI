#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;
long long n,k,map[20][20],vis[20],ans,tmp,in[20];
bool flag;
void work(long long u,int dep)
{
	if(vis[u])
	{
		if(dep==k) flag=true;
		return;
	}
	vis[u]=1;
	for(int i=1;i<=n;i++)
	{
		if(flag) return ;
		if(map[u][i]) work(i,dep+1);
	}
	vis[u]=0;
}
void topo()
{
	queue<int> Q;
	for(int i=1;i<=n;i++) if(!in[i]) Q.push(i);
	while(!Q.empty())
	{
		int u=Q.front();
		Q.pop();
		for(int i=1;i<=n;i++)
		{
			if(map[u][i])
			{
				map[u][i]=0;
				if(--in[i]==0) Q.push(i);
			}
		}
	}
}
void dfs(long long dep)
{
	if(dep==0)
	{
		flag=false;
		memset(vis,0,sizeof(vis));
		topo();
		for(int i=1;i<=n;i++)
		{
		 	if(in[i] && !vis[i]) work(i,0);
		}
		if(flag) ans++;
		return ;
	}
	long long tmp[20][20],in_[20];
	memcpy(tmp,map,sizeof(tmp));
	memcpy(in_,in,sizeof(in_));
	for(long long i=0;i<(1<<(dep-1));i++)
	{
		memcpy(map,tmp,sizeof(map));
		memcpy(in,in_,sizeof(in));
		for(long long j=1;j<dep;j++) 
		{
			if(i&(1<<(j-1))) map[dep][j]=1,in[j]++;
			else map[j][dep]=1,in[dep]++;
		}
		dfs(dep-1);
	}
}
long long q_p(long long x,long long q)
{
	long long res=1;
	while(q)
	{
		if(q%2==1) res=(res*x)%998244353;
		x=(x*x)%998244353;
		q/=2;
	}
	return res;
} 
int main()
{
	//freopen("tournament.in","r",stdin);
	//freopen("tournament.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	if(n==k && n==4)
	{
		printf("16");
		return 0;
	}
	dfs(n);
	printf("%lld",ans%998244353);
	return 0;
}
// 1 2 3 4 1 2 4 3 1 3 2 4 1 3 4 2 1 4 2 3 1 4 3 2
