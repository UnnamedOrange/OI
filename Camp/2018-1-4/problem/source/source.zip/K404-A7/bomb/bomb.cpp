/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 1000000 + 10;

int n, m, x, y;
std::vector<int> edge[MAXN];
int deg[MAXN], dep[MAXN];
int vis[20];
int f[1 << 15 | 1];
bool able[1 << 15 | 1];

inline void add_edge(int x, int y) {
	edge[x].push_back(y), deg[y]++;
}

inline void read_in() {
	R(n), R(m);
	for (int i = 1; i <= m; ++i) R(x), R(y), add_edge(x, y);
}

inline void bfs(int num) {
	std::queue<int> q;
	q.push(num);
	while (!q.empty()) {
		int cur = q.front();
		q.pop();
		for (int p = 0; p < edge[cur].size(); ++p) {
			int v = edge[cur][p];
			if ((vis[num] & (1 << v - 1)) == 0 && v != num) 
				q.push(v), vis[num] |= (1 << v - 1);
		}
	}
}

inline int dfs(int cur) {
	if (~f[cur]) return f[cur];
	if (cur == 0) return 0;
	if (able[cur]) return 1;
	int ret = ~0u >> 1;
	for (int i = ((cur - 1) & cur); i; i = ((i - 1) & cur))
		ret = std::min(dfs(i) + dfs(cur ^ i), ret);
	return f[cur] = ret;
}

inline void solve1() {
	for (int i = 1; i <= n; ++i) bfs(i);
	for (int i = 0, s = (1 << n); i < s; ++i) {
		bool flag = true ;
		for (int j = 0; j < n; ++j)
			if (i & (1 << j)) {
				if (vis[j + 1] & i) {
					flag = false;
					break ;
				}
			}
		able[i] = flag;
	}
	memset(f, -1, sizeof(int) * (1 << n | 1));
	std::cout << dfs((1 << n) - 1);
}

inline void solve2() {
	std::queue<int> q;
	for (int i = 1; i <= n; ++i) if (deg[i] == 0) q.push(i), dep[i] = 1;
	while (!q.empty()) {
		int cur = q.front();
		q.pop();
		for (int p = 0; p < edge[cur].size(); ++p) {
			int v = edge[cur][p];
			if (--deg[v] == 0) dep[v] = dep[cur] + 1, q.push(v);
		}
	}
	int ans = 0;
	for (int i = 1; i <= n; ++i) ans = std::max(ans, dep[i]);
	std::cout << ans;
}

int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	read_in();
	if (n <= 10) solve1();
	else solve2();
	return 0;
}
