#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
long long Mod=998244353;
int n,m,k,du[100010],f[2010][2010];
int cnt,head[100010],to[200010],nxt[200010];
int dp[100010],g[100010];
queue<int> q;
void add(int x,int y)
{
	cnt++;
	to[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
long long pw(long long x,long long y)
{
	long long res=1;
	while (y)
	{
		if (y&1)
		{
			res=res*x%Mod;
		}
		y>>=1;
		x=x*x%Mod;
	}
	return res;
}
void solve()
{
	for (int i=1;i<=n;i++)
	{
		if (!du[i])
		{
			q.push(i);
		}
	}
	g[1]=1;
	while (!q.empty())
	{
		int x=q.front();
		q.pop();
		for (int i=head[x];i;i=nxt[i])
		{
			int y=to[i];
			du[y]--;
			if (!du[y])
			{
				q.push(y);
			}
			g[y]=(g[y]+g[x])%Mod;
			dp[y]=((dp[y]+dp[x])%Mod+g[x])%Mod;
		}
	}
	for (int i=1;i<=n;i++)
	{
		printf("%d\n",dp[i]);
	}
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read();
	m=read();
	k=read();
	//scanf("%d%d%d",&n,&m,&k);
	for (int i=0;i<m;i++)
	{
		int x,y;
		x=read();
		y=read();
		//scanf("%d%d",&x,&y);
		add(x,y);
		du[y]++;
	}
	if (k==1)
	{
		solve();
		return 0;
	}
	for (int i=1;i<=n;i++)
	{
		if (!du[i])
		{
			q.push(i);
		}
	}
	for (int i=head[1];i;i=nxt[i])
	{
		int y=to[i];
		f[y][1]++;
	}
	while (!q.empty())
	{
		int x=q.front();
		q.pop();
		for (int i=head[x];i;i=nxt[i])
		{
			int y=to[i];
			du[y]--;
			if (!du[y])
			{
				q.push(y);
			}
			for (int j=1;j<n;j++)
			{
				f[y][j+1]+=f[x][j];
				f[y][j+1]%=Mod;
			}
		}
	}
	puts("0");
	for (int i=2;i<=n;i++)
	{
		long long ans=0;
		for (int j=1;j<=n;j++)
		{
			if (!f[i][j])
			{
				continue;
			}
			ans=(ans+(long long)f[i][j]*pw(j,k)%Mod)%Mod;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
