#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<queue>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=8;
const int M=505;
const int mod=998244353;
int n,m;

int len[N];
char in[M],p[N][M];
void wj()
{
	freopen("string.in","r",stdin);
	//freopen("string.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read(); m=read();
	for(i=1;i<=n;++i)
	{
		scanf("%s",p[i]+1);
		len[i]=strlen(p[i]+1);
	}
	int tot=1<<m,ans=0,ans0=0;
	for(int s=0;s<tot;++s)
	{
		for(i=1;i<=m;++i) in[i]=((s>>i-1)&1)+48;
		for(i=m+1;i<=(m<<1);++i) in[i]=97-in[2*m+1-i];
		int add=0;
		for(i=1;i<=n;++i)
		{
			for(j=1;j<=(m<<1);++j)
			{
				if(j+len[i]-1>(m<<1)) break;
				bool can=1;
				for(int k=0;k<len[i];++k) if(in[j+k]!=p[i][1+k]) {can=0;break;}
				if(can) {add++;break;}
			}
		}
		if(add==n) 
		{
			ans=(ans+1)%mod; //printf("%s\n",in+1);
			if(in[1]=='0') ans0++;
		}
	}
	printf("%d\n",ans);
	//cout<<ans0<<endl;
	return 0;
}
