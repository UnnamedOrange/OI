#include <set>
#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
const int N=8010,M=4010;
int s[N];
int n,m,k,ans;
struct SAM
{
    int a[N],e[N][M],n,last[M];
    void pre(int *s,int n)
    {
        for(int i=n;i>=1;i--)
        {
            memcpy(e[i+1],last,sizeof(int[M]));
            a[i]=s[i],last[a[i]]=i+1;
        }
        memcpy(e[1],last,sizeof(int[M]));
    }
    int dfs(int x,int dep)
    {
        for(int i=1;i<=k;i++)
        {
            if(!e[x][i])return dep;
        }
        for(int i=1;i<=k;i++)
        return dfs(e[x][i],dep+1);
    }
}S;
int main()
{
    freopen("subsequence.in","r",stdin);
    freopen("subsequence.out","w",stdout);
    n=read(),m=read(),k=read();
    for(int i=1;i<=n;i++)s[i]=read();
    for(int i=n+1;i<=m+n;i++)s[i]=read();
    S.pre(s,n+m);
    cout<<S.dfs(1,0);
    return 0;
}
