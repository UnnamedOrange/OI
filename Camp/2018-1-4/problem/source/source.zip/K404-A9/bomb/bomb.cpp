#include<bits/stdc++.h>
using namespace std;
#define N 1000010
#define vi vector<int>::iterator
#define si set<int>::iterator
#define spp set<Point>::iterator
vector<int> ep[N];
int dfn[N],tim,low[N],Instack[N],taj,Belong[N];
stack<int> Stack;
int getint() {
	static char c;
	static int x=0;
	x=0;
	c=getchar();
	while(!isdigit(c)) c=getchar();
	do {
		x=x*10+c-'0';
		c=getchar();
	} while(isdigit(c));
	return x;
}
void Tarjan(int po) {
	dfn[po]=low[po]=++tim;
	Stack.push(po);
	Instack[po]=1;
	for(vi i=ep[po].begin();i!=ep[po].end();i++) {
		int v=*i;
		if(dfn[v]==-1){
			Tarjan(v);
			low[po]=min(low[po],low[v]);
		} else if(Instack[v]){
			low[po]=min(low[po],dfn[v]);
		}
	}
	if(low[po]==dfn[po]) {
		int now;
		++taj;
		do {
			now=Stack.top();
			Stack.pop();
			Instack[now]=0;
			Belong[now]=taj;
		} while(now!=po);
	}
}
struct Edge {
	int u,v,nxt;
}e[N*2];
int head[N],cnt,num[N];
void add(int u,int v) {
	e[++cnt].u=u;e[cnt].v=v;e[cnt].nxt=head[u];head[u]=cnt;
}
int r[N];
set<int> ss[N];
struct Point {
	int r,cnt,id;
	bool operator < (const Point &A) const {
		if(r==A.r) return id < A.id;
		return r<A.r;
	}
	Point(int _r=0,int _cnt=0,int _id=0) : r(_r),cnt(_cnt),id(_id) {}
}p[N];
set<Point> sp;
int main() {
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int n,m;
//	scanf("%d%d",&n,&m);
	n=getint(),m=getint();
	for(int i=1;i<=m;i++) {
		int a,b;
//		scanf("%d%d",&a,&b);
		a=getint(),b=getint();
		ep[a].push_back(b);
	}
	memset(dfn,-1,sizeof(dfn));
	for(int i=1;i<=n;i++) if(dfn[i]==-1) Tarjan(i);
	for(int i=1;i<=n;i++) num[Belong[i]]++;
	for(int i=1;i<=n;i++) {
		for(vi j=ep[i].begin();j!=ep[i].end();j++) {
			if(Belong[i]!=Belong[*j]) {
				ss[Belong[i]].insert(Belong[*j]);
			}
		}
	}
	for(int i=1;i<=n;i++) ep[i].clear();
	for(int i=1;i<=taj;i++) {
		for(si j=ss[i].begin();j!=ss[i].end();j++) {
			add(i,*j);
			ep[*j].push_back(i);
		}
	}
	for(int i=1;i<=cnt;i++) r[e[i].u]++;
	for(int i=1;i<=taj;i++) {
		p[i]=Point(r[i],num[i],i);
		sp.insert(p[i]);
	}
	while(!sp.empty()) {
		while(!sp.empty()) {
			spp i=sp.begin();
			int u=(*i).id;
			sp.erase(i);
			for(vi j=ep[u].begin();j!=ep[u].end();j++) {
				if(r[*j]==0) continue;
				spp tmp3=sp.lower_bound(Point(r[*j],0,*j));
				int v=(*tmp3).id;
				sp.erase(*tmp3);
				p[v].r--;r[v]--;
				if(r[v]==0) p[v].cnt+=p[u].cnt;
				sp.insert(p[v]);
			}
		}
	}
	int ans=0;
	for(int i=1;i<=taj;i++) ans=max(ans,p[i].cnt);
	printf("%d",ans);
}
