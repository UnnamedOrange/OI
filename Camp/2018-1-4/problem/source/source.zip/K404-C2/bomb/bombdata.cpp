#include<algorithm>
#include<unistd.h>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<ctime>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;

int main()
{
	freopen("bomb.in","w",stdout);
	srand(time(0)+getpid());
	int n=10,m=rand()%20;
	printf("%d %d\n",n,m);
	rep(i,1,m)
	{
		int x=rand()%n+1,y=rand()%n+1;
		while(x==y) x=rand()%n+1,y=rand()%n+1;
		printf("%d %d\n",x,y);
	}
}
