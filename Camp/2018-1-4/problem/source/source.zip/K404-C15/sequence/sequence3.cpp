#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <map>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 30, INF = 0x3f3f3f3f;
int T, n, fac, a[N], b[N], ans;
map <ll, int> mp;

void debug(){
	for(int i = 1; i <= n; i++)
		printf("%d%c", a[i], " \n"[i == n]);	
}
ll tonum(int *a){
	ll ret = 0;
	for(int i = 1; i <= n; i++)
		ret = ret * (n + 1) + a[i];
	return ret;
}
void rev(int *a, int x){
	for(int i = 1, j = x; i < j; i++, j--)
		swap(a[i], a[j]);	
}
void dfs1(int last, int step){
	//printf("step = %d, ", step);
	//debug();
	int num = tonum(a);
	//printf("num = %d\n", num);
	map<ll, int>:: iterator it = mp.find(num);
	if(it == mp.end()) mp[num] = step;
	else it -> second = min(it -> second, step);
	if(step == (n + 1) / 2) return;
	for(int i = 2; i <= n; i++)
		if(i != last){
			rev(a, i);
			dfs1(i, step + 1);
			rev(a, i);
		}
}
void dfs2(int last, int step){
	int num = tonum(b);
	map<ll, int>:: iterator it = mp.find(num);
	if(it != mp.end()) ans = min(ans, step + it -> second);
	if(step == n / 2) return;
	for(int i = 2; i <= n; i++)
		if(i != last){
			rev(b, i);
			dfs2(i, step + 1);
			rev(b, i);
		}
}

int main(){
	
	read(T);
	while(T--){
		read(n);
		for(int i = 1; i <= n; i++) 
			read(a[i]), b[i] = i;
		ans = INF;
		mp.clear();
		dfs1(0, 0);
		dfs2(0, 0);
		write(ans), enter;
	}
	
	return 0;
}
/*
1 
8
8 6 1 3 2 4 5 7

1
7
1 5 2 6 3 7 4
*/
