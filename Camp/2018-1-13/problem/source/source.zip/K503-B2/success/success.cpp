#include<cstdio>
using namespace std;
const int mod=1000000007;
typedef long long LL;
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	LL n,m,s,t;
	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
	if(s==m){
		printf("1\n");
		return 0;
	}
	s-=m,t--;
	s%=mod;
	printf("%lld",(n*t%m)*((m-n)*s%mod));
	return 0;
}
