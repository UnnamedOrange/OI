#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
const int Maxn = 25;
int A[Maxn];
int N, Max, fl;
inline void dfs(int x, int y)
{
	if (fl) return ;
	if (x + y > Max) return ;
	int tmpfl = 0;
	for (int i = 1; i <= N; ++i)
		if (A[i] != i)
		{
			tmpfl = 1;
			break;
		}
	if (!tmpfl)
	{
		fl = 1;
		return ;
	}
	for (int i = 1; i <= N; ++i)
	{
		int Sum = y;
		if (i != N && abs(A[i] - A[i + 1]) == 1) ++Sum;
		if (i != N && abs(A[1] - A[i + 1]) == 1) --Sum;
		reverse(A + 1, A + i + 1);
		dfs(x + 1, Sum);
		reverse(A + 1, A + i + 1);
	}
}
int main()
{
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while (T--)
	{
		fl = 0;
		scanf("%d", &N);
		for (int i = 1; i <= N; ++i) scanf("%d", &A[i]);
		int Sum;
		Max = Sum = 0;
		for (int i = 2; i <= N; ++i) if (abs(A[i] - A[i - 1]) > 1) ++Sum;
		while (1)
		{
			dfs(0, Sum);
			if (fl) break;
			++Max;
		}
		printf("%d\n", Max);
	}
	return 0;
}
