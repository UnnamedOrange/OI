//2018-1-12
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define Double long double
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define M (60+5)
#define N (50000+5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' && chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x<<1) + (x<<3) + (chr^'0'); chr = getchar();
	}
}

int nl[N], nr[N];
int w[N], num[N], lpos[N][M], rpos[N][M];
LL tot[N][M];

struct node{
	int v, p;
	bool operator >(const node &rhs)const{
		if(v != rhs.v) return v > rhs.v;
		return p > rhs.p;
	}
};

int n, ql, qr;

#define lc (o<<1)
#define rc (o<<1|1)
#define mid ((L+R)>>1)

namespace Seg_tree{
	node h[N<<2];

	node Comb(node a, node b){
		if(a.v != b.v) return a.v>b.v? a: b;
		return a.p > b.p? a: b;
	}
	
	void Build(int o, int L, int R){
		if(L == R){
			h[o] = (node){w[L], L}; return;
		}

		Build(lc, L, mid); Build(rc, mid+1, R);
		h[o] = Comb(h[lc], h[rc]);
	}

	node Query(int o, int L, int R){
		if(ql <= L && qr >= R) return h[o];

		if(qr <= mid) return Query(lc, L, mid);
		if(ql > mid) return Query(rc, mid+1, R);
		return Comb(Query(lc, L, mid), Query(rc, mid+1, R));
	}
};

#undef lc
#undef rc
#undef mid

using namespace Seg_tree;

int Findl(int p, node me){
	ql = 1, qr = p;
	node now = Query(1, 1, n);
	if(me > now) return 0;
	
	int L = 1, R = p, mid;
	while(L < R){
		ql = mid = (L+R+1) >> 1;
		if(Query(1, 1, n) > me) L = mid;
		else R = mid-1;
	}
	return L;
}

int Findr(int p, node me){
	ql = p; qr = n;
	node now = Query(1, 1, n);
	if(me > now) return n+1;

	int L = p, R = n, mid;
	while(L < R){
		qr = mid = (L+R) >> 1;
		if(Query(1, 1, n) > me) R = mid;
		else L = mid+1;
	}
	return L;
}

int main(){
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);

	Read(n);
	For(i, 1, n) Read(w[i]);
	Build(1, 1, n);

	node me;
	For(i, 1, n){
	//	printf("i = %d v = %d\n", i, w[i]);
		me = (node){w[i], i}; lpos[i][0] = rpos[i][0] = i;

		int tmp, p = i-1;
		while(p >= 1){
			tmp = Findl(p, me); if(tmp <= 0) break;
		//	printf("p = %d tmp = %d\n", p, tmp);
			lpos[i][++nl[i]] = tmp; if(nl[i] >= 60) break;
			p = tmp-1;
		}
		lpos[i][++nl[i]] = 0;
	//	puts("-------");

		p = i+1;
		while(p <= n){
			tmp = Findr(p, me); if(tmp > n) break;
		//	printf("p = %d tmp = %d\n", p, tmp);
			rpos[i][++nr[i]] = tmp; if(nr[i] >= 60) break;
			p = tmp+1;
		}
		rpos[i][++nr[i]] = n+1;

	//	puts("===================");
	}

	Double base, ans = 0;

	For(o, 1, n){
		For(i, 1, nl[o]) For(j, 1, nr[o]){
			if(i+j > 60) break;
			tot[o][i+j-1] += 1ll * (lpos[o][i-1]-lpos[o][i]) * (rpos[o][j]-rpos[o][j-1]);
		}

		base = 1.0;
		For(i, 1, 60){
			base /= 2.0;
			ans += 1.0*w[o]*tot[o][i] * base;
		}
	}

	ans = ans / n / n;
	printf("%.15Lf\n", ans);

	return 0;
}
