#include<bits/stdc++.h>
#define FE "xmastree2"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		c=='-'?p=-1:0;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
inline void putint(int x){
	x<0?putchar('-'),x=-x:0;
	static int buf[20];
	int tot=0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	return 0;
}
