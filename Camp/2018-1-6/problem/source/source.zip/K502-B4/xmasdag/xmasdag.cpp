#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
long long n,m,k,cnt,ans[100010]; 
struct node 
{
	long long v;
	node *next_;
}pool[400010],*h[100010];
void addedge(long long u,long long v)
{
	node *p=&pool[++cnt];
	p->v=v;p->next_=h[u];h[u]=p;
}
long long q_p(long long x,long long q)
{
	long long res=1,p=q;
	while(p)
	{
		if(p%2==1) res=(res*x)%998244353;
		x=(x*x)%998244353;
		p/=2;
	}
	return res;
}
void dfs(long long u,long long dep)
{
	ans[u]+=q_p(dep,k);
	ans[u]%=998244353;
	for(node *p=h[u];p;p=p->next_)
	{
		long long v=p->v;
		dfs(v,dep+1);
	}
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmaxdag.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	long long u,v;
	for(long long i=1;i<=m;i++) scanf("%lld%lld",&u,&v),addedge(u,v);
	dfs(1,0);
	for(long long i=1;i<=n;i++) printf("%lld\n",ans[i]%998244353);
	return 0;
}
