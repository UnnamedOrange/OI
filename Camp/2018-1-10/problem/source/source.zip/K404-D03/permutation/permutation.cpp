#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=100100,mod=998244353;

int n;
int a[N];
bool used[N];

namespace violence
{
	int ans;
	bool book[N];
	
	void dfs(int step)
	{
		if(step>n)
		{
			for(int i=1;i<=n;++i) book[i]=0;
			bool flag=0;
			for(int i=1;i<=n;++i)
			{
				if(!book[a[i]])
				{
					int now=a[i];
					int res=0;
					while(!book[now])
					{
						book[now]=1;
						res++;
						now=a[now];
					}
					if(res&1)
					{flag=1;break;}
				}
			}
			if(!flag) ans++;
			return ;
		}
		if(a[step]) dfs(step+1);
		else
		{
			for(int i=1;i<=n;++i)
				if(!used[i])
				{
					a[step]=i;used[i]=1;
					dfs(step+1);
					used[i]=0;a[step]=0;
				}
		}
	}
	
	void Main()
	{
		register int i;
		for(i=1;i<=n;++i) used[a[i]]=1;
		dfs(1);
		cout<<ans<<endl;
	}
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	
	n=read();
	if(n&1)
	{puts("0");return 0;}
	register int i,now(0),res;
	for(i=1;i<=n;++i) a[i]=read(),now+=a[i];
	if(now)
	{
		violence::Main();
		return 0;
	}
	now=1;
	for(i=3;i<n;i+=2)
		now=1ll*now*i%mod;
	now=1ll*now*now%mod;
	cout<<now<<endl;
	/*
	for(i=1;i<=n;++i) a[i]=i;
	int ans=0;
	do
	{
		for(i=1;i<=n;++i) used[i]=0;
		bool flag=0;
		for(i=1;i<=n;++i)
		{
			if(!used[a[i]])
			{
				now=a[i];
				res=0;
				while(!used[now])
				{
					used[now]=1;
					res++;
					now=a[now];
				}
				if(res&1)
				{flag=1;break;}
			}
		}
		if(!flag) ans++;
	}while(next_permutation(a+1,a+1+n));
	cout<<ans<<endl;
	*/
	return 0;
}
/*
6
0 0 0 0 0 0

*/

