#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int p=998244353, mxn=1<<9;

int main()
{
    freopen("segment.in", "r", stdin);
    freopen("segment.out", "w", stdout);
    St int n, m, k;
    scanf("%d%d%d", &n, &m, &k);
    if(k==998244353)
    {
        St int f[mxn][mxn];
        f[0][0]=1;
        inc(0, i_, n)
        {
            inc(1, i, m+1)
            {
                f[i][0]=(f[i][0]+f[i-1][0])%p;
                f[0][i]=(f[0][i]+f[0][i-1])%p;
            }
            inc(1, i, m+1)
                inc(1, j, m+1)
                    f[i][j]=((ll)f[i][j]-f[i-1][j-1]+f[i-1][j]+f[i][j-1]+p)%p;
            inc(0, i, m+1)
                inc(0, j, m+1)
                    if(i>j)
                        f[i][j]=0;
            dec(0, i, m)
                dec(0, j, m)
                    f[i][j]=f[i-1][j-1], f[i-1][j-1]=0;
            inc(0, i, m+1)
            {
                inc(0, j, m+1)
                    printf("%d ", f[i][j]);
                puts("");
            }
            puts("");
        }
        Rg int ans=0;
        inc(1, i, m+1)
            inc(1, j, m+1)
                ans=(ans+f[i][j])%p;
        printf("%lld\n", (ll)ans*m%p);
    }
    if(n==1)
    {
        Rg int ans=0;
        inc(1, i, m+1)
            ans=((ll)i*(m-i+1)+ans)%p;
        printf("%d\n", ans);
    }
    Re 0;
}
