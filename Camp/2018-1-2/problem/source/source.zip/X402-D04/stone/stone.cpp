#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int mod=1e9+7;
int n, a, b;
int x[maxn], use[maxn];
int dp[maxn][2];
ll Pow[maxn];

int main(){
	freopen("stone.in","r",stdin),freopen("stone.out","w",stdout);

	scanf("%d%d%d",&n,&a,&b);
	Pow[0]=1;
	for(int i=1;i<maxn;i++) Pow[i]=Pow[i-1]*2%mod;
	for(int i=1;i<=n;i++) scanf("%d",&x[i]), x[i]%=(a+b);
	int cnt1=0, cnt2=0, cnt3=0;
	if(a==b){
		int ans=0;
		dp[0][0]=1;
		for(int i=1;i<=n;i++){
			dp[i][0]=dp[i-1][0], dp[i][1]=dp[i-1][1];
			if((x[i]/a)&1) (dp[i][1]+=dp[i-1][0])%=mod, (dp[i][0]+=dp[i-1][1])%=mod;
			else (dp[i][1]+=dp[i-1][1])%=mod, (dp[i][0]+=dp[i-1][0])%=mod;
		}
		printf("0 0 %d %d\n", dp[n][1], dp[n][0]);
	}else if(a<=b){
		for(int i=1;i<=n;i++){
			if(x[i]<a) cnt1++;
			else if(x[i]>=a && x[i]<b) cnt2++;
			else cnt3++;
		}
		if(!cnt3) printf("%lld 0 0 %lld\n", (Pow[n]-Pow[cnt2]+mod)%mod, Pow[cnt1+cnt3]);
	}else{
		for(int i=1;i<=n;i++){
			if(x[i]<b) cnt1++;
			else if(x[i]>=b && x[i]<a) cnt2++;
			else cnt3++;
		}
		if(!cnt3) printf("0 %lld 0 %lld\n", (Pow[n]-Pow[cnt2]+mod)%mod, Pow[cnt1+cnt3]);
	}
	return 0;
}
