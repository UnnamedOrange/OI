#include <stdio.h>
#include <stdlib.h>
#define maxn 510
int a[maxn],b[maxn][9],c[maxn][3],t,n,w,p,q,i,j;
long long min(long long x,long long y)
{
	return x<y ? x : y;
}
bool check()
{
	int i;
	for (i=0;i<q;i++)
		if (((c[i][2]==0) && (a[c[i][0]]>a[c[i][1]])) || ((c[i][2]==1) && (a[c[i][0]]!=a[c[i][1]])) || ((c[i][2]==2) && (a[c[i][0]]>=a[c[i][1]]))) return false;
	return true;
}
long long sum()
{
	long long ans=0;
	int i;
	for (i=1;i<=n;i++)
		ans+=(long long)a[i];
	for (i=0;i<p;i++)
		ans+=(long long)b[i][3]*(long long)abs(a[b[i][0]]-a[b[i][1]])+(long long)b[i][4]*(long long)abs(a[b[i][1]]-a[b[i][2]])+(long long)b[i][5]*(long long)abs(a[b[i][2]]-a[b[i][0]])+(long long)b[i][6]*(long long)(a[b[i][0]]-a[b[i][1]])+(long long)b[i][7]*(long long)(a[b[i][1]]-a[b[i][2]])+(long long)b[i][8]*(long long)(a[b[i][2]]-a[b[i][0]]);
	return ans;
}
long long work(int x)
{
	long long ans;
	if (x==n+1)
	{
		if (check()) return sum();
		return 1e18;
	}
	a[x]=w;
	ans=work(x+1);
	a[x]=-w;
	ans=min(ans,work(x+1));
	return ans;
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	for (scanf("%d",&t);t>0;t--)
	{
		scanf("%d%d%d%d",&n,&w,&p,&q);
		for (i=0;i<p;i++)
			for (j=0;j<9;j++)
				scanf("%d",&b[i][j]);
		for (i=0;i<q;i++)
			for (j=0;j<3;j++)
				scanf("%d",&c[i][j]);
		printf("%lld\n",work(1));
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
