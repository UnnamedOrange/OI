#include <cstdio>
#include <vector>
using namespace std;
#define Mod 998244353
#define N 100
#define K 20
int fa[N],dep[N],f[N][K],k,n,faa[N],ans,i;
vector<int> g[N],sn[N];
bool vis[N];
void dfs(int now,int lst)
{
	fa[now]=lst;dep[now]=dep[lst]+1;
	for (int ii=0;ii<g[now].size();ii++) if (g[now][ii]!=lst) dfs(g[now][ii],now);
}
void dfs3(int now)
{
	for (int ii=1;ii<=k;ii++) f[now][ii]=1;
	for (int ii=0;ii<sn[now].size();ii++){
		dfs3(sn[now][ii]);
		for (int jj=1;jj<=k;jj++) f[now][jj]=1LL*f[now][jj]*f[sn[now][ii]][jj+1]%Mod;
	}
	for (int ii=k;ii>1;ii--) f[now][ii]=(f[now][ii]+f[now][ii+1])%Mod;
}
void dfs2(int now,int lst)
{
	int cnt=0;
	for (int ii=1;ii<=n;ii++) if (!vis[ii]) cnt++;
	if (cnt==1){
		faa[now]=lst;
		for (int ii=0;ii<=n;ii++) sn[ii].clear();
		for (int ii=1;ii<=n;ii++) sn[faa[ii]].push_back(ii);
		int rt=sn[0][0];
		dfs3(rt);
		ans=(ans+f[rt][1])%Mod;
	}
	for (int ii=1;ii<=n;ii++){
		int u=ii,v=now;bool zw=vis[u]|vis[v];
		while (u!=v){
			if (dep[u]<dep[v]) swap(u,v);
			u=fa[u];zw|=vis[u];
		}if (!zw){
			faa[ii]=lst;vis[ii]=true;for (int jj=0;jj<g[ii].size();jj++) if (!vis[jj]) dfs2(g[ii][jj],ii);vis[ii]=false;
		}
	}
}
int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	for (i=1;i<n;i++){
		int x,y;scanf("%d%d",&x,&y);
		g[x].push_back(y);g[y].push_back(x);
	}dfs(1,0);dfs2(1,0);printf("%d\n",ans);
	return 0;
}
