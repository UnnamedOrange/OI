//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const int maxn=500+7,maxm=1000+7;
ll T,n,w,m1,m2,ans;
int fa[maxn];

ll aa,ff;char cc;
ll read() {
	aa=0;ff=1;cc=getchar();
	while(cc!='-'&&(cc<'0'||cc>'9')) cc=getchar();
	if(cc=='-') ff=-1,cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa*ff;
}

struct Ask{
	ll x,y,a;
	Ask(){}
	Ask(ll x,ll y,ll a):x(x),y(y),a(a){}
}ask[6*maxm];
int tot;

struct Lmt{
	int x,y;
}lmt[maxm];
int t;

int find(int x){return x==fa[x]? x:fa[x]=find(fa[x]);}

void lj(int x,int y) {
	int a=find(x),b=find(y);
	if(a<b) fa[a]=b; else fa[b]=a;
}

int p[maxn],totp;
int num[maxn],xs[maxn];

void get_ans() {
	for(int i=1;i<=t;++i) {
		if(num[ask[i].x]>num[ask[i].y]) return;
	}
	ll rs=0;
	for(int i=1;i<=totp;++i) rs+=xs[p[i]]*num[i];
	for(int i=1;i<=tot;++i) rs+=ask[i].a*abs(ask[i].x-ask[i].y);
	ans=min(ans,rs);
}

void s(int pos) {
	if(pos>totp) {
		get_ans(); return;
	}
	if(num[pos]) {
		s(pos+1);
		return;
	}
	num[pos]=1; s(pos+1);
	num[pos]=-1; s(pos+1);
	num[pos]=0;
}

void clear() {
	tot=t=totp=0; ans=1e15;
	memset(num,0,sizeof(num));
	memset(xs,0,sizeof(xs));
	for(int i=1;i<=n+2;++i) fa[i]=i;
	for(int i=1;i<=n;++i) xs[i]=1;
}

int main() {
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	T=read(); ll x,y,z,d,e,f;
	while(T--) {
		n=read(); w=abs(read()); m1=read(); m2=read();
		clear();
		for(int i=1;i<=m1;++i) {
			x=read(); y=read(); z=read();
			ask[++tot]=Ask(x,y,read());
			ask[++tot]=Ask(y,z,read());
			ask[++tot]=Ask(x,z,read());
			d=read(); e=read(); f=read();
			xs[x]+=(d-f);
			xs[y]+=(e-d);
			xs[z]+=(f-e);
		}
		for(int i=1;i<=m2;++i) {
			x=read(); y=read(); z=read();
			if(z==0) {
				lmt[++t].x=x;
				lmt[++t].y=y;
			}
			else if(z==1) lj(x,y);
			else lj(x,n+1),lj(y,n+2);
		}
		for(int i=1;i<=n+2;++i) {
			if(find(i)==i) {
				p[++totp]=i;
				if(i==n+1) num[totp]=-1;
				else if(i==n+2) num[totp]=1;
			}
			else xs[find(i)]+=xs[i];
		}
		for(int i=1;i<=tot;++i) ask[i].x=find(ask[i].x),ask[i].y=find(ask[i].y);
		for(int i=1;i<=t;++i) lmt[i].x=find(lmt[i].x),lmt[i].y=find(lmt[i].y);
		s(1);
		printf("%lld\n",ans*w);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
1
3 1 1 1
1 2 3 1 1 1 1 1 1 
1 2 2
*/
