#include <iostream>
#include <cstdio>
#include <cstring>
#define mod 998244353
using namespace std;
int n,m;
char a[10][150];
void solve1() {
	char s[35];int sum=0;
	for(int S=0; S<(1<<m); S++) {
		for(int p=1; p<=m; p++) {
			s[p]='0';
			if(S&(1<<p-1)) s[p]='1';
		}
		for(int i=m+1; i<=m+m; i++) s[i]=('1'-s[m+m-i+1])+'0';
		bool t2=1;
		for(int i=1; i<=n; i++) {
			int len=strlen(a[i]+1);
			bool t1=0;
			for(int p=1; p+len-1<=m+m; p++) {
				bool t=1;
				for(int j=p; j<=p+len-1; j++) {
					if(s[j]!=a[i][j-p+1]) {
						t=0;
						break;
					}
				}
				if(t) {
					t1=1;
					break;
				}
			}
			if(!t1){
				t2=0;break;
			}
		}
		if(!t2) continue;
		sum++;
	}
	printf("%d",sum);
}
void solve2(){
	
}
int main() {
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=n; i++) {
		scanf("%s",a[i]+1);
	}
	if(m<=15) solve1();
	else solve2();
	return 0;
}
