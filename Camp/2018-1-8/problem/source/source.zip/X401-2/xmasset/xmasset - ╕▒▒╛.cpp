#include <bits/stdc++.h>

int type, N;

void init()
{
    
}

int encode(int x, int y)
{
    if(x%3!=y%3)return x%3;
    x/=3; y/=3;
    if(x%3!=y%3)return x%3+3;
    x/=3; y/=3;
    if(x%3!=y%3)return x%3+6;
    x/=3; y/=3;
    if(x%3!=y%3)return x%3+9;
    x/=3; y/=3;
    if(x%3!=y%3)return x%3+12;
    x/=3; y/=3;
    return x%4+15;
}

bool decode(int q, int h)
{
	--h;
    if(h<3)if(q%3==h)return 1; else return 0;
    h-=3; //%=  ()%=  //no
    if(h<3)if(q%3==h)return 1; else return 0;
    h-=3;
    if(h<3)if(q%3==h)return 1; else return 0;
    h-=3;
    if(h<3)if(q%3==h)return 1; else return 0;
    h-=3;
    if(h<3)if(q%3==h)return 1; else return 0;
    h-=3;
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y)+1);
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
