#include <bits/stdc++.h>

#ifdef DEBUG
#define MAXBF 14
#else
#define MAXBF 8
#endif

using namespace std;

const int MAXN = 1e5, MOD = 998244353;
int N, A[MAXN+10]; bool QinDing;

template<typename T>
inline void readint(T& x) {
	T f=1, r=0; char c=getchar();
	while(!isdigit(c)){ if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)){ r=r*10+c-'0'; c=getchar(); }
	x = f*r;
}

void Init() {
	readint(N);
	for(int i=1; i<=N; i++) {
		readint(A[i]);
		if(A[i]) QinDing = true;
	}
}

int Cnt; bool vis[MAXN+10], vis2[MAXN+10];
inline bool check() {
	memset(vis2, 0, sizeof(vis2));
	for(int i=1; i<=N; i++) if(!vis2[i]) {
		int Len = 1;
		for(int j=A[i]; j!=i; j=A[j]) Len++;
		if(Len&1) return false;
	}
	return true;
}
void Dfs(int u) {
	if(u == N+1) {
		if(check()) Cnt++;
		return;
	}
	if(A[u]) Dfs(u+1);
	else {
		for(int i=1; i<=N; i++) {
			if(vis[i]) continue;
			vis[i]=true;
			A[u] = i;
			Dfs(u+1);
			vis[i]=false;
			A[u] = 0;
		}
	}
}
void BruteWork() {
	for(int i=1; i<=N; i++) if(A[i]) vis[A[i]]=true;
	Dfs(1);
	printf("%d\n", Cnt);
}

inline int fastmul(int a, int x) {
	int ret=0;
	while(x) {
		if(x&1) ret = ((ret%MOD) + (a%MOD)) % MOD;
		x>>=1; a = (a%MOD + a%MOD) % MOD;
	}
	return ret;
}
void Work1() {
	if(N&1) printf("0");
	else {
		int a=1;
		for(int i=2; i<N; i+=2) 
			a = fastmul(a, i+1);
		a = fastmul(a, a);
		printf("%d", a);
	}
}

void Work2() {
	int OC=0, PC=0;
	for(int i=1; i<=N; i++) if(!vis[i]) {
		int j, len = 1; vis[i] = true;
		for(j=A[i];j && j!=i; j=A[j]) {
			len++; vis[j] = true;
		}
		if(j==i && (len&1)) {
			puts("0"); return;
		}
		if(!j) len--;
		if(len&1) OC++;
		else PC++;
	}
	puts("0");	
}

int main() {
#ifndef DEBUG
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
#endif	
	Init();
	if( N <= MAXBF ) BruteWork();
	else if( !QinDing ) Work1();
	else Work2();
	return 0;
}
