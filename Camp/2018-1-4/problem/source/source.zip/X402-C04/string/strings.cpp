#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

typedef long long ll;
const ll md=998244353;
const int M=509;
const int N=109;
const int K=9;

int n,m,m2,ans;
char s[K][N],rs[K][N];
int nxt[K][N],rnxt[K][N];
int len[K];
ll f[M][N][N][2];

inline void kmp(char *s,int *fail,int n)
{
	fail[0]=fail[1]=0;
	for(int i=2,j=0;i<=n;i++)
	{
		while(j && s[j+1]!=s[i])
			j=fail[j];
		fail[i]=(j+=(s[j+1]==s[i]));
	}
}

inline void chk(ll &a){if(a>=md)a-=md;}

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)
			ret=ret*a%md;
		a=a*a%md;
		b>>=1;
	}
	return ret;
}

inline ll calc(int id,int n)
{
	memset(f,0,sizeof(f));
	f[0][0][0][0]=1;

	char *ss=s[id],*sr=rs[id];
	int *fail=nxt[id],*rail=rnxt[id];
	for(int i=0;i<m;i++)
		for(int j=min(i,n);j>=0;j--)
			for(int k=min(i,n);k>=0;k--)
				for(int l=0;l<=1;l++)//vis
				{
					if(f[i][j][k][l])
						for(int ll=0;ll<=1;ll++)//choose
						{
							int nj=j,nk=k;
							while(nj && ss[nj+1]!=ll)nj=fail[nj];
							while(nk && sr[nk+1]==ll)nk=rail[nk];
							nj+=(ss[nj+1]==ll);nk+=(sr[nk+1]!=ll);

							if(nj==n || nk==n)
								chk(f[i+1][nj][nk][1]+=f[i][j][k][l]);
							else
								chk(f[i+1][nj][nk][l]+=f[i][j][k][l]);
						}
				}
	ll ans=0;
	for(int i=0;i<=n;i++)
	{
		for(int j=0;j<=n;j++)
		{
			if(f[m][i][j][1])
				chk(ans+=f[m][i][j][1]);
			if(f[m][i][j][0] && i+j>=n)
			{
				for(int nj=i;nj;nj=fail[nj])
					for(int nk=j;nk;nk=fail[nk])
						if(nj+nk==n)
						{
							chk(ans+=f[m][i][j][0]);
							goto ed;
						}
						else if(nj+nk<n)break;
				ed:;
			}
		}
	}
	return ans;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);

	scanf("%d%d",&n,&m);
	m2=m*2;
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s[i]+1);
		len[i]=strlen(s[i]+1);
		for(int j=1;j<=len[i];j++)
			s[i][j]-='0',rs[i][len[i]-j+1]=s[i][j];
		kmp(s[i],nxt[i],len[i]);
		kmp(rs[i],rnxt[i],len[i]);
	}

	if(n==1)
	{
		printf("%lld\n",calc(1,len[1]));
		return 0;
	}

	printf("%d\n",ans);
	return 0;
}
