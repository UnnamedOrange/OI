#include<iostream>
using namespace std;
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	cout<<3<<endl;
	return 0;
}
