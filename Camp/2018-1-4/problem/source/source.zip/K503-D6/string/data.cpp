#include <cstdio>
#include <cstdlib>
#include <process.h>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

void rands(int n,int mx=2)
{
    rep(i,1,n)
        putchar('0'+rand(mx));
    puts("");
}

int main()
{
    srand(_getpid()^(unsigned long long)new char);
    freopen("string.in","w",stdout);
    int n=6,m=500;
    printf("%d %d\n",n,m);
    rep(i,1,n)
        rands(rand(50,100));
    return 0;
}
