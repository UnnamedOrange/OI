#include <bits/stdc++.h>
using namespace std;

vector<int> Edge[100010];
int Color[100010];
int Map[100010];
int Right[100010];
int Data[100010];
int I;
void Dfs(int p, int f = 0) {
	Map[p] = I++;
	Data[Map[p]] = Color[p];
	for (vector<int>::iterator it = Edge[p].begin(); it != Edge[p].end(); ++it) {
		if (*it != f) {
			Dfs(*it, p);
		}
	}
	Right[Map[p]] = I;
}

int main() {
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	int n, q, t;
	cin >> n >> q >> t;
	for (int i = 1; i <= n; ++i) {
		cin >> Color[i];
	}
	for (int i = 1; i < n; ++i) {
		int u, v;
		cin >> u >> v;
		Edge[u].push_back(v);
		Edge[v].push_back(u);
	}
	Dfs(1);
	int preans = 0;
	while (q--) {
		int cmd, x;
		cin >> cmd >> x;
		if (t) {
			x ^= preans;
		}
		if (cmd == 1) {
			int l, r;
			cin >> l >> r;
			if (t) {
				l ^= preans;
				r ^= preans;
			}
			set<int> ans;
			for (int i = Map[x]; i < Right[Map[x]]; ++i) {
				if (l <= Data[i] && Data[i] <= r) {
					ans.insert(Data[i]);
				}
			}
			cout << ans.size() << '\n';
			preans = ans.size();
		} else {
			int c;
			cin >> c;
			if (t) {
				c ^= preans;
			}
			Data[Map[x]] = c;
		}
	}
}
