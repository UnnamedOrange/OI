#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=50010,mo=998244353;
int n,head[maxn],nxt[maxn<<1],to[maxn<<1],e;
int deg[maxn];
char s[maxn];
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}
void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}
int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}
namespace chain{
    void solve(){
        int u=1,fa=0,cnt=0;
        while(1){
            bool flag=0;
            for(int i=head[u];i;i=nxt[i]){
                int v=to[i];
                if(v!=fa){
                    flag=1; ++cnt;
                    fa=u; u=v; break;
                }
            }
            if(!flag) break;
        }
        int len1=cnt,len2=n-cnt-1,sum=0,ans=0;
        for(int i=0;i<len2;i++) Add(ans,len1+i+1),sum++;
        for(int i=0;i<len1;i++) Add(ans,len2+i+1),sum++;
        printf("%d\n",1ll*ans*fpm(sum,mo-2)%mo);
    }
}
int main(){
    freopen("sad.in","r",stdin);
    freopen("sad.out","w",stdout);
    read(n); scanf("%s",s);
    for(int i=1;i<n;i++){
        int u,v;
        read(u); read(v);
        ae(u,v); ae(v,u);
        ++deg[u]; ++deg[v];
    }
    bool flag=1;
    for(int i=1;i<=n;i++) if(deg[i]>2){ flag=0; break; }
    if(flag) chain::solve();
    return 0;
}
