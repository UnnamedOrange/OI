#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e6+10;
int mu[maxn],ph[maxn],f[maxn],lst[maxn];
int isprime[maxn],tmp,pri[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
#endif
	int T=read();
	int n=1e6;
	mu[1]=ph[1]=1;
	REP(i,2,n){
		if(!isprime[i]) pri[++tmp]=i,mu[i]=-1;
		REP(j,1,tmp){
			if(i*pri[j]>n) break;
			isprime[i*pri[j]]=1;
			if(i%pri[j]==0){
				mu[i*pri[j]]=0;
				break;
			}
			else mu[i*pri[j]]=-mu[i];
		}
	}
	int num=0;
	REP(i,2,n){
		if(!isprime[i]){
			ph[i]=2,lst[i]=++num;
			int l=i,k=1;
			while(1){
				if(1ll*l*i>n) break;
				l*=i,++k;
				ph[l]=k+1;
				lst[l]=num;
			}
		}
		REP(j,lst[i]+1,tmp){
			if(i*pri[j]>n) break;
			int l=i;
			REP(k,1,n){
				if(1ll*l*pri[j]>n) break;
				l*=pri[j];
				ph[l]=ph[i]*(k+1);
				lst[l]=j;
			}
		}
	}
	REP(i,1,n)
		REP(j,1,n/i)
			f[j*i]+=mu[i]*ph[j]*ph[j];
	REP(i,1,n) f[i]+=f[i-1];
	while(T--){
		n=read();
		if(n>1e6) printf("19260817");
		else printf("%d\n",f[n]);
	}
	return 0;
}
