//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=1e6+7;
const int mod=1000000007;
typedef long long LL;
using namespace std;
LL s,t,n,m,power[N],sum[N],ans;

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

LL ksm(LL a,LL b) {
	LL base=a,res=1;
	while(b) {
		if(b&1) res=res*base%mod;
		base=base*base%mod;
		b>>=1;	
	}
	return res;
}

LL C(LL n,LL m) {
	if(n<m) return 0;
	return power[n]*ksm(power[m],mod-2)%mod*ksm(power[n-m],mod-2)%mod;
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
#endif
	read(s); read(t); read(n); read(m);
	power[0]=1;
	for(int i=1;i<=1e6;i++) { power[i]=power[i-1]*i%mod; }
	for(int i=1;i<=s;i++) {
		LL tp=C(i,m-1);
		sum[i]=(tp+sum[i-1])%mod;
	}
	ans=sum[s-1];
	for(int i=1;i<=n;i++) {
		LL f=(i&1)?-1LL:1LL;
		if(s-i*t-1>=0) 
			ans=(ans+f*C(n,i)*sum[s-i*t-1]%mod+mod)%mod;
	}
	printf("%lld\n",ans);
	return 0;
}
