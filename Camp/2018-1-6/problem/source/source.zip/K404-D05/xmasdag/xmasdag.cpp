#include<bits/stdc++.h>
#define FE "xmasdag"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		c=='-'?p=-1:0;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
inline void putint(int x){
	x<0?putchar('-'),x=-x:0;
	static int buf[20];
	int tot=0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
const int LEN = 200005, MOD = 998244353;
int n,m,k;
int ans[LEN][505],deg[LEN];
int q[LEN];
int head=1,tail=0;
int c[1005][1005];
struct rode{
	int e,nxt;
}r[LEN<<2];
int tot=1,first[LEN];
inline void creat(int a,int b){
	r[++tot].e=b;
	r[tot].nxt=first[a];
	first[a]=tot;
}
inline void pre(){
	for(int i=0;i<=k;++i){
		c[i][0]=1;
		for(int j=1;j<=i;++j){
			c[i][j]=c[i-1][j-1]+c[i-1][j];
			c[i][j]%=MOD;
		}
	}
}
inline void work2(){
	//n=getint(),m=getint(),k=getint();
	pre();
	for(int i=1;i<=m;++i){
		int a=getint(),b=getint();
		creat(a,b);
		++deg[b];
	}
	ans[1][0]=1;
	q[++tail]=1;
	while(head<=tail){
		int u=q[head++];
		for(int i=first[u];i;i=r[i].nxt){
			int v=r[i].e;
			for(int j=0;j<=k;++j){
				for(int k1=0;k1<=j;++k1){
					ans[v][j]+=(long long)ans[u][k1]*c[j][k1]%MOD;
					ans[v][j]%=MOD;
				}
			}
			--deg[v];
			if(deg[v]==0)q[++tail]=v;
		}
	}
	for(int i=1;i<=n;++i){
		putint(ans[i][k]),putchar('\n');
	}
}
int ans1[2005][2005];
inline long long ksm(long long a,long long b,long long c=MOD){
	long long ans=1;
	while(b){
		if(b&1)ans=ans*a%MOD;
		b>>=1;
		a=a*a%MOD;
	}
	return ans;
}
inline void work1(){
	//n=getint(),m=getint(),k=getint();
	for(int i=1;i<=m;++i){
		int a=getint(),b=getint();
		creat(a,b);
		++deg[b];
	}
	ans1[1][0]=1;
	q[++tail]=1;
	while(head<=tail){
		int u=q[head++];
		for(int i=first[u];i;i=r[i].nxt){
			int v=r[i].e;
			for(int j=1;j<=n;++j){
				ans1[v][j]+=ans1[u][j-1];
				ans1[v][j]%=MOD;
			}
			--deg[v];
			if(deg[v]==0)q[++tail]=v;
		}
	}
	for(int i=1;i<=n;++i){
		int ans=0;
		for(int j=0;j<=n;++j){
//			cout<<ans1[i][j]<<" ";
			ans+=(long long)ans1[i][j]*ksm(j,k)%MOD;
			ans%=MOD;
		}
		cout<<ans<<"\n";
	}
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	n=getint(),m=getint(),k=getint();
	if(m<=5000)work1();
	else work2();
	return 0;
}
