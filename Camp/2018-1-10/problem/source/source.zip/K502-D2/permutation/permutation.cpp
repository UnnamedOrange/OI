#include <queue>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

#define LL long long
const int mod = 998244353;
const int N = 100000 + 1000;

int n, p[N];
LL f[N], ans = 0, uf[N], tot = 0, sum = 0, In[N];
bool us[N], vis[10], vi[N], flag = true;

namespace file{
	inline void open()
	{
		freopen("permutation.in", "r", stdin);
		freopen("permutation.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	} 
}
using namespace file;

inline int read()
{
	int a = 0;
	char ch;
	int f = 1;
	while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
	if(ch == '-')
		f = -1;
	else
	{
		a = a * 10;
		a += ch - '0';
	}
	while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
	{
		a = a * 10;
		a += ch - '0';
	}
	return a * f;
}

inline void input()
{
	n = read();
	for(int i = 1;i <= n;++i)
	{
		p[i] = read();
		if(p[i])
			++In[p[i]], us[p[i]] = 1, flag = false, ++sum;
	}
}

inline bool judge()
{
	memset(vis, 0, sizeof vis);
	for(int i = 1;i <= n;++i)
	{
		if(!vis[i])
		{
			int point = i, num = 0;
			vis[point] = 1;
			while(true)
			{
				point = p[point];
				++num;
				vis[point] = 1;
				if(point == i)
					break;
			}
			if(num & 1)
				return false;
		}
	}
	return true;
}

inline void dfs(int x)
{
	if(x == n + 1)
	{
		if(judge())
		{
			++ans;
			//for(int i = 1;i <= n;++i)
			//	printf("%d ", p[i]);
			//printf("\n");
		}
		return;
	}
	if(p[x])
		dfs(x + 1);
	else
	{
		for(int i = 1;i <= n;++i)
			if(x != i && !us[i])
			{
				p[x] = i;
				us[i] = 1;
				dfs(x + 1);
				us[i] = 0;
				p[x] = 0;
			}
	}
}

inline void brute()
{
	dfs(1);
	printf("%lld\n", ans);
}

inline void method()
{
	f[0] = f[2] = 1;
	for(int i = 4;i <= n;i += 2)
		f[i] = f[i - 2] * (i - 1) % mod * (i - 1) % mod;
	printf("%lld\n", f[n]);
}

inline void solve()
{
	if(n & 1)
	{
		printf("%d\n", 0);
		return;
	}
	f[0] = f[2] = 1;
	for(int i = 4;i <= n;i += 2)
		f[i] = f[i - 2] * (i - 1) % mod * (i - 1) % mod;
	bool f1 = true;
	sum = n - sum;
	for(int i = 1;i <= n;++i)
	{
		if(p[i] && !vi[i] && !In[i])
		{
			int point = i, num = 0;
			while(true)
			{
				vi[point] = 1;
				point = p[point];
				++num;
				if(point == 0)
					break;
			}
			if((num - 1) & 1)
				uf[++tot] = num - 1;
		}
	}
	for(int i = 1;i <= n;++i)
	{
		if(p[i] && !vi[i] && In[i])
		{
			int point = i, num = 0;
			while(true)
			{
				vi[point] = 1;
				point = p[point];
				++num;
				if(point == i)
					break;
			}
			if(num & 1)
			{
				f1 = false;
				break;
			}
		}
	}
	if(!f1)
	{
		printf("%d\n", 0);
		return;
	}
	ans = 1;
	for(int i = 1;i <= tot;++i)
	{
		if(uf[i] & 1)
			ans = ans * sum % mod, --sum;
		if(sum < 0)
			f1 = false;
	}
	if(!f1)
	{
		printf("%d\n", 0);
		return;
	}
	ans = ans * f[sum] % mod;
	printf("%lld\n", ans);
	return;
}

inline void check()
{
	if(n <= 8)
		brute();
	else if(flag)
		method();
	else
		solve();
}

int main()
{
	open();
	input();
	check();
	close();
	return 0;
} 
