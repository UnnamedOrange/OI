#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
const int mod= 1e9 +7;
int a[1010101],b[1010101];
int f[1010101],t[1010101];
int n;
inline void read(int &x)
{
    int data=0,w=1;
    char ch=0;
    while (ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
    if (ch=='-') w=-1,ch=getchar();
    while (ch>='0'&&ch<='9') data=(data<<3)+(data<<1)+(ch^'0'),ch=getchar();
    x=data*w;
}
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);

	memset(f,-1,sizeof(f));
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
		read(a[i]),read(b[i]);
	f[0]=0; t[0]=1; a[0]=-mod; b[0]=mod;
	for (int i=1;i<=n;++i)
	{
		int mx=b[i],mn=a[i];
		for (int j=i;j>=1;--j)
		{
//			printf("i:%d  j:%d\n",i,j);
//			printf("%d %d\n",mn,mx);
			if (j+1 < f[i]) break;
			if (i-j+1>mx) break;
			mx=min(mx,b[j]);
			mn=max(mn,a[j]);
			if (mn>mx) break;
			if (mn<=i-j+1 && f[j-1]!=-1)
			{	
				if (f[j-1]+1>f[i]) t[i]=0;
				if (f[j-1]+1>=f[i]) t[i]=(t[i]+t[j-1])%mod,f[i]=f[j-1]+1;
			}
		}

	}
//	for (int i=1;i<=n;++i)
//		printf("%d ",f[i]);
//	printf("\n");
	if (f[n]==-1) printf("-1\n");
	else printf("%d %d\n",f[n],t[n]);
	return 0;
}
