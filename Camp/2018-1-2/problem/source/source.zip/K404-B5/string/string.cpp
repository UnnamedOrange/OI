#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 100007;

int n;
char s[MAXN];



void init ();
void input ();
void work ();

bool ispam ( char s[], int l, int r )
{
	lp ( i, 0, (r-l)>>1 ){
		if ( s[l+i] != s[r-i] ) return false;
	}
	return true;
}



int main ()
{
	init ();
	
	int T;
	scanf ( "%d", &T );
	while ( T-- ){
		input ();
		work ();
	}
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "string" );
}

void input ()
{
	scanf ( "%d%s", &n, s );
}

void work ()
{
	if ( !ispam ( s, 0, n-1 ) ){
		printf ( "1\n" );
		return;
	}
	
	int mp = -1;
	char cf = s[0];
	lp ( i, 1, n ){
		if ( s[i] != cf ){
			mp = i;
			break;
		}
	}
	
	if ( ( ~mp ) && ( !ispam ( s, mp+1, n-1 ) ) ){
		printf ( "2\n" );
		return;
	}
	
	printf ( "-1\n" );
}
