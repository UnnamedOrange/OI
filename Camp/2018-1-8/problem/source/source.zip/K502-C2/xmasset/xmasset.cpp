#include<cstdio>
#include<cstring>
#include<cassert>
#include<iostream>
#include<algorithm>

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while(c = getchar(), c >= '0');
}

int type, N;

void init() {
	
}

int encode(int x, int y) {
	/*for (int i = 0; i <= 4; i++) {
		int id = i << 1;
		if ((x >> id & 3) ^ (y >> id & 3)) {
			int v = x >> id & 3;
			return i * 4 + v;
		}
	}*/
	{
		for (int i = 1; i <= 10; i++)
			if ((x >> (i - 1) & 1) ^ (y >> (i - 1) & 1)) return i + (x >> (i - 1) & 1) * 10;
	}
	assert(0);
	return x;
}

bool decode(int q, int h) {
	{
		int v = h / 11;
		int p = h - v * 10;
		return (q >> (p - 1) & 1) == v;
	}
	/*{
		return q == h;
	}*/
}

int main() {
	int T;
	Rd(type), Rd(N), Rd(T);
	init();
	while (T--) {
		int x, y;
		Rd(x), Rd(y);
		if (type == 1) printf("%d\n", encode(x, y));
		else puts(decode(x, y) ? "yes" : "no");
	}
	return 0;
}
