#include<cstdio>
#include<algorithm>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
#define Down(i, a, b) for(register int i = a; i >= b; --i)
#define LL long long
using namespace std;
const int maxn = 1e2 + 5, mod = 1e9 + 7;
int dp[maxn][maxn];
int n, m, s, t, ans;

int main() {
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	scanf("%d%d%d%d", &s, &t, &n, &m);
	dp[0][s] = 1;
	For(i, 0, n - 1) Down(j, s, 1) {
		For(k, 1, min(j, t)) (dp[i + 1][j - k] += dp[i][j]) %= mod;
	}
	For(i, n, m - 1) Down(j, s, 1) {
		For(k, 1, j) (dp[i + 1][j - k] += dp[i][j]) %= mod;
	}
	For(i, 0, s) (ans += dp[m][i]) %= mod;
	printf("%d", ans);
	return 0;
}
