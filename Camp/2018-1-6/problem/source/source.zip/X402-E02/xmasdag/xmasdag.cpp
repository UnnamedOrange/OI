#include<bits/stdc++.h>
using namespace std;
int qmax(int &x,int y) {if (x<y) x=y;}
int qmin(int &x,int y) {if (x>y) x=y;}
int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
void write(int x)
{
	if(x<0){putchar('-');write(-x);}
	else{if(x/10)write(x/10);putchar(x%10+'0');}
}
const int maxn=100000+100;
const int maxm=200000+100;
const int mod=998244353;
int n,m,k,X,Y,RD[maxn],ss;
long long ans[maxn];
int Q[maxn],l,r,Q1[maxn],s[maxn];
int to[maxm<<1],ne[maxm<<1],po[maxn],id;
long long ksm(long long x,int y)
{
	long long sum=1;
	while (y)
	{
		if (y&1) sum=sum*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return sum;
}
void add(int x,int y) {to[++id]=y;ne[id]=po[x];po[x]=id;}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read();m=read();k=read();	
	for (int i=1;i<=m;i++)
	{
		X=read();Y=read();RD[Y]++;add(X,Y);
	}
	if (k==1)
	{
		l=0;r=1;Q[r]=1;s[1]=1;
		int u=0,v=1;
		while (l!=r)
		{
			l++;if (l==maxn) l=1;
			u=Q[l];
			for (int i=po[u];i;i=ne[i])
			{
				v=to[i];RD[v]--;
				ans[v]+=ans[u]+(long long)s[u];
				s[v]+=s[u];
				if (RD[v]==0)
				{
					r++;if (r==maxn) r=1;
					Q[r]=v;
				}
			}
		}
		for (int i=1;i<=n;i++) printf("%lld\n",(ans[i]%mod+mod)%mod);
		return 0;
	}
	if (n<=2000&&m<=5000)
	{
		l=0;r=1;Q[r]=1;int u=0,v;Q1[r]=0;
		while (l!=r)
		{
			l++;if (l==maxn) l=1;
			u=Q[l];
			ans[u]+=ksm(Q1[l],k);if (ans[u]>=mod) ans[u]-=mod;
			for (int i=po[u];i;i=ne[i])
			{
				v=to[i];
				r++;if (r==maxn) r=1;
				Q[r]=v;
				Q1[r]=Q1[l]+1;
			}
		}
		for (int i=1;i<=n;i++) printf("%lld\n",(ans[i]%mod+mod)%mod);
		return 0;
	}
	return 0;
}
