#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctime>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
typedef long long ll;
const int N=1000100,maxn=1000000,maxm=50000;
int prime[N],cnt_pri,flag[N],e[N];int vis[1010];
int mu[N];
ll d[N];
ll f[N],sf[N];
int g[N];
int n;

ll calcf(int m){
	if(n/m<=maxn)	return f[n/m];
	if(vis[m])	return sf[m];
	ll &ret=sf[m];int i,last;
	m=n/m;
	ret=0;
	for(i=1;i<=m;i=last+1){
		last=m/(m/i);
		ret+=(m/i)*(last-i+1);
	}
	return ret;
}

void euler(){
	int i,j;
	d[1]=1;mu[1]=1;
	rep(i,2,maxn){
		if(!flag[i]){prime[++cnt_pri]=i;e[i]=1;d[i]=3;mu[i]=-1;}
		for(j=1;j<=cnt_pri&&i*prime[j]<=maxn;j++){
			flag[i*prime[j]]=1;
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				e[i*prime[j]]=e[i]+1;
				d[i*prime[j]]=d[i]/(2*e[i]+1)*(2*e[i]+3);
				break;
			}
			else{
				mu[i*prime[j]]=-mu[i];
				e[i*prime[j]]=1;
				d[i*prime[j]]=d[i]*3;
			}
		}
	}
	rep(i,1,maxn) d[i]+=d[i-1];
	rep(i,1,maxn) mu[i]+=mu[i-1];
	rep(i,1,maxn) for(j=i;j<=maxn;j+=i) f[j]++;
	rep(i,1,maxn) f[i]+=f[i-1];
	//rep(i,1,maxm)	f[i]=calcf(i);
}

int sqr(int x){
	int ret=(int)sqrt(x+1);
	while(ret*ret>x)	ret--;
	return ret;
}

int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int T;ll ans=0;int i,j,lasti,lastj,m,now,pre;
	//int xx=clock();
	scanf("%d",&T);
	if(!T)	return 0;
	euler();
	while(T--){		
		scanf("%d",&n);
		if(n<=maxn){printf("%lld\n",d[n]);continue;}
		memset(vis,0,sizeof(vis));
		pre=0;ans=0;
		for(i=1;i*i<=n;i=lasti+1){
			m=n/(i*i);
			lasti=sqr(n/m);
			now=mu[lasti];
			//printf("%d %d\n",i,lasti);
			for(j=1;j<=m;j=lastj+1){				
				lastj=m/(m/j);
				ans+=1ll*(now-pre)*(lastj-j+1)*calcf(i*i*j);
			}
			pre=now;
		}
		printf("%lld\n",ans);	
		/*ans=0;
		for(i=1;i*i<=n;i++){
			m=n/i/i;
			rep(j,1,m){
				ans+=mu[i]*f[m/j];
			}
		}
		printf("%lld %d\n",ans,d[n]);*/		
	}
	//printf("%d\n",clock()-xx);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
