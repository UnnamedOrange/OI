//#include <bits/stdc++.h>
#include <cstdio>
#include <iostream>
#include <cstring>

#define MP make_pair
#define PB push_back
#define FO(x) freopen(#x".in", "r", stdin), freopen(#x".out", "w", stdout)

using namespace std;
typedef long long LL;
typedef unsigned long long u64;

template <typename T> inline bool cmin(T & a, const T & b) { return a > b ? a = b, 1 : 0;}
template <typename T> inline bool cmax(T & a, const T & b) { return a < b ? a = b, 1 : 0;}
int read() {
	int x = 0, f = 1;char ch;
	for(ch = getchar(); !isdigit(ch); ch = getchar())
		if(ch == '-') f = -1;
	for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	return x * f;
}

const int MaxN = 101234, P = 1e9 + 7; 
int n, a, b, x[MaxN], f[MaxN][2];

int exp(int a, int n) {
	int res = 1;
	for(; n; n >>= 1) {
		if(n & 1) 
			res = (LL) res * a % P;
		a = (LL) a * a % P;
	}
	return 0;
}

int main() {
	int i;
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	n = read(); a = read(); b = read();
	for(i = 1; i <= n; i++) x[i] = read();
	if(a == b) {
		f[0][0] = 1;
		for(i = 1; i <= n; i++) {
			int o = ((x[i] / b) & 1);
			if(o) {
				f[i][1] = (f[i - 1][1] + f[i - 1][0]) % P;
				f[i][0] = (f[i - 1][0] + f[i - 1][1]) % P;
			} else {
				f[i][1] = (f[i - 1][0] + f[i - 1][0]) % P;
				f[i][0] = (f[i - 1][1] + f[i - 1][1]) % P;
			}
		}
		printf("0 0 %d %d\n", f[n][1], f[n][0]);
		return 0;
	}	
	return  0;
}
