#include<bits/stdc++.h>
using namespace std;
struct edge{int u,v,nex;} e[2200000];
int fir[1200000],fa[1200000],a[1200000],degree[1200000],f[1200000],size,size2,n,m,ans;
int dfn[1200000],low[1200000],stk[1200000],top,cnt;
bool ha[1200000];
int read(){
	int f=0,g=1;
	register char ch=getchar();
	for (;!isdigit(ch);ch=getchar()) if (ch=='-') g=-1;
	for (;isdigit(ch);ch=getchar()) f=f*10+ch-'0';
	return f*g;
}
void add(int u,int v){e[++size].u=u;e[size].v=v;e[size].nex=fir[u];fir[u]=size;}
void update(int x){
	e[x].u=fa[e[x].u];e[x].v=fa[e[x].v];
	if (e[x].u==e[x].v) return;
	e[x].nex=fir[e[x].u];fir[e[x].u]=x;degree[e[x].v]++;
}
void tarjan(int x){
	dfn[x]=low[x]=++cnt;
	stk[++top]=x;ha[x]=1;
	for (int i=fir[x];i;i=e[i].nex){
		if (dfn[e[i].v]) {if (ha[e[i].v])low[x]=min(low[x],dfn[e[i].v]);}
		else {tarjan(e[i].v);low[x]=min(low[x],low[e[i].v]);}
	}
	if (dfn[x]==low[x]){
		while (stk[top]!=x){
			fa[stk[top]]=x;
			ha[stk[top]]=0;
			a[x]++;top--;
		}
		ha[x]=0;fa[x]=x;a[x]++;top--;
	}
}
void work(int x,int sum){
	sum+=a[x];degree[x]--;
	if (sum>f[x]) f[x]=sum;
	if (degree[x]<1){
		ans=max(ans,f[x]);
		for (int i=fir[x];i;i=e[i].nex){
			work(e[i].v,sum);
		}
	}
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=m;i++){
		int u=read(),v=read();
		add(u,v);
	}
	memset(a,0,sizeof(a));
	for (int i=1;i<=n;i++) add(0,i);
	cnt=top=ans=0;
	tarjan(0);
	memset(fir,0,sizeof(fir));
	for (int i=1;i<=m+n;i++) update(i);
	a[0]=0;
	work(0,0);
	printf("%d\n",ans);
	return 0;
}
