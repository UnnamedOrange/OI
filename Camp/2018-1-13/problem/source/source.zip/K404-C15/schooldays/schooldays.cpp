#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 2005, P = 1000000007;
int n, l[N], r[N], L[N][N], R[N][N];
ll f[N][N];
bool vis[N][N];

int main(){
	
	read(n);
	for(int i = 1; i <= n; i++)
		read(l[i]), read(r[i]), L[i][i] = l[i], R[i][i] = r[i];
	for(int i = 1; i <= n; i++)
		for(int j = i + 1; j <= n; j++){
			L[i][j] = max(L[i][j - 1], l[j]);
			R[i][j] = min(R[i][j - 1], r[j]);
		}
	f[0][0] = 1;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++)
			for(int k = 1; k <= i; k++)
				if(k >= L[i - k + 1][i] && k <= R[i - k + 1][i])
					f[i][j] += f[i - k][j - 1];
	
	return 0;
}
/*
9
1 4
2 5
3 4
1 5
1 1
2 5
3 5
1 3
1 1
*/
