#include <map>
#include <set>
#include <cmath>
#include <queue>
#include <cctype>
#include <cstdio>
#include <vector>
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <functional>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)
#define repe(i,x) for (edge *i=fst[x]; i; i=i->nxt)

int get()
{
    char c;
    while (!isdigit(c=getchar()) && c!='-');
    int s=c=='-'? -1:1,k=~s? c-'0':0;
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return s*k;
}

using namespace std;
typedef long long ll;
const int N=1e5+10,M=2e5+10,K=510,p=998244353,P=1025;
struct edge
{
	int v;
	edge *nxt;
} pool[M],*tp=pool,*fst[N];
int n,m,pw,mx,imx,fac[K],ifac[K],rev[P],vif[P],e[P],vs[N][P],ans[N];
bool vis[N];

int power(int a,int b)
{
	int t=1;
	for (; b; b>>=1,a=1ll*a*a%p)
		if (b&1)
			t=1ll*t*a%p;
	return t;
}

void inc(int &x,int y)
{
	(x+=y)<p? 0:x-=p;
}

void ntt(int *a,int flag=0)
{
	rep(i,0,mx-1)
		if (rev[i]>i)
			swap(a[i],a[rev[i]]);
	for (int k=1; k<mx; k<<=1)
		for (int j=0,wn=e[flag? mx-mx/k/2:mx/k/2]; j<mx; j+=k<<1)
			for (int i=j,w=1,t; i<j+k; ++i,w=1ll*w*wn%p)
				t=1ll*a[i+k]*w%p,inc(a[i+k],p-t),inc(a[i],t);
	if (flag)
		rep(i,0,mx-1)
			a[i]=1ll*a[i]*imx%p;
}

void dfs(int x)
{
	if (vis[x])
		return;
	vis[x]=1;
	repe(i,x)
	{
		dfs(i->v);
		rep(j,0,mx-1)
			vs[x][j]=(vs[x][j]+1ll*vs[i->v][j]*vif[j])%p;
		/*
		rep(j,0,pw)
			rep(k,0,j)
				sum[x][j]=(sum[x][j]+1ll*sum[i->v][k]*ifac[j-k])%p;
		*/
	}
	ntt(vs[x],1);
	ans[x]=vs[x][pw];
	fill(vs[x]+pw+1,vs[x]+mx,0);
	ntt(vs[x]);
}

int main()
{
    freopen("xmasdag.in","r",stdin);
//    freopen("xmasdag.out","w",stdout);
    n=get(),m=get(),pw=get();
    fac[0]=1;
    rep(i,1,pw)
    	fac[i]=1ll*fac[i-1]*i%p;
    ifac[pw]=power(fac[pw],p-2);
    repd(i,pw,1)
    	ifac[i-1]=1ll*ifac[i]*i%p;
    for (mx=1; mx<pw*2; mx<<=1);
    imx=power(mx,p-2);
    rep(i,1,mx-1)
    	rev[i]=(rev[i>>1]>>1)|(i&1)*(mx>>1);
    e[0]=1,e[1]=power(3,(p-1)/mx);
	rep(i,2,mx)
		e[i]=1ll*e[i-1]*e[1]%p;
	memcpy(vif,ifac,sizeof(ifac)),ntt(vif);
//	for (int i=0; 1<<i<mx; ++i)
//    	e[0][i]=power(3,(p-1)/(1<<i)),e[1][i]=power(3,p-1-(p-1)/(1<<i));
//    rep(i,0,mx-1)
//    	for (int w=1,j=0; j<=pw; ++j,w=1ll*w*e[i]%p)
//    		vif[i]=(vif[i]+1ll*w*ifac[j])%p;
//    /*
    rep(i,0,pw)
    {
    	int t=0;
    	assert(1ll*e[i]*e[mx-i]%p==1);
    	for (int w=1,wn=e[mx-i],j=0; j<mx; ++j,w=1ll*w*wn%p)
    		t=(t+1ll*w*vif[j])%p;
    	t=1ll*t*imx%p;
    	assert(t==ifac[i]);
    }
//    */
    rep(i,1,m)
    {
    	int u=get(),v=get();
    	*tp=(edge){u,fst[v]},fst[v]=tp++;
    }
    vis[1]=1,fill(vs[1],vs[1]+mx,1);
    rep(i,1,n)
    {
    	dfs(i);
    	printf("%d\n",ans[i]);
    	/*
    	int ans=0;
    	for (int j=0,w=1,wn=e[mx-pw]; j<mx; ++j,w=1ll*w*wn%p)
    		ans=(ans+1ll*vs[i][j]*w)%p;
    	ans=1ll*ans*imx%p,ans=1ll*ans*fac[pw]%p;
    	printf("%d\n",ans);
    	*/
    }
    return 0;
}
