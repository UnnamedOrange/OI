#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while(c = getchar(), c >= '0');
}

const int M = (int) 1e5 + 5;
const int P = 998244353;

char str[M];
int n, Head[M], tot, deg[M];
struct Node {int to, nxt;} Edge[M << 1];

inline void Addedge(int a, int b) {
	deg[a]++, deg[b]++;
	Edge[tot] = (Node) {b, Head[a]}; Head[a] = tot++;
	Edge[tot] = (Node) {a, Head[b]}; Head[b] = tot++;
}

inline void Add(int &a, int b) {
	a += b;
	if (a >= P) a -= P;
}

int Pow(int x, int k) {
	int rs = 1;
	while (k) {
		if (k & 1) rs = (ll) rs * x % P;
		x = (ll) x * x % P;
		k >>= 1;
	}
	return rs;
}

namespace Subtask1 {
	
	const int N = 200;
	
	int Id[10][1 << 8], tot, mat[N][N];
	
	void Gauss() {
		for (int i = 1; i <= tot; i++) {
			for (int j = 1; j <= tot; j++) {
				if (i == j) continue;
				int prod = (ll) mat[j][i] * Pow(mat[i][i], P - 2) % P;
				for (int k = 1; k <= tot + 1; k++)
					Add(mat[j][k], P - (ll) prod * mat[i][k] % P);
			}
		}
	}
	
	void solve() {
		for (int i = 1; i <= n; i++)
			for (int j = 0; j < (1 << n); j++)
				if (j >> (i - 1) & 1) Id[i][j] = ++tot;
		for (int i = 1; i <= n; i++) {
			for (int j = 0; j < (1 << n); j++) {
				if (!(j >> (i - 1) & 1)) continue;
				mat[Id[i][j]][Id[i][j]] = 1;
				if (deg[i] > 1) {
					int inv = Pow(deg[i], P - 2);
					for (int k = Head[i]; ~k; k = Edge[k].nxt) {
						int to = Edge[k].to;
						if (str[to] == '1' || !(j >> (to - 1) & 1)) {
							Add(mat[Id[i][j]][Id[to][j | (1 << (to - 1))]], P - inv);
							Add(mat[Id[i][j]][tot + 1], inv);
						} else Add(mat[Id[i][j]][Id[to][j | (1 << (to - 1))]], P - inv);
					}
				}
			}
		}
		Gauss();
		int rs = (ll) mat[Id[1][1]][tot + 1] * Pow(mat[Id[1][1]][Id[1][1]], P - 2) % P;
		Add(rs, 1);
		printf("%d\n", rs);
	}
	
}

namespace Subtask2 {
	
	int A[M], B[M]; // f[i] = A[i] * f[fa[i]] + B[i]
	
	void dfs(int x, int f) {
		B[x] = 1;
		if (deg[x] == 1) return;
		int inv = Pow(deg[x], P - 2);
		int now = 1;
		for (int i = Head[x]; ~i; i = Edge[i].nxt) {
			int to = Edge[i].to;
			if (to == f) continue;
			dfs(to, x);
			Add(B[x], (ll) inv * B[to] % P);
			Add(now , P - (ll) inv * A[to] % P);
		}
		A[x] = inv;
		A[x] = (ll) A[x] * Pow(now, P - 2) % P;
		B[x] = (ll) B[x] * Pow(now, P - 2) % P;
	}
	
	void solve() {
		int now = 1, c = 1, inv = Pow(deg[1], P - 2);
		for (int i = Head[1]; ~i; i = Edge[i].nxt) {
			int to = Edge[i].to;
			dfs(to, 1);
			Add(c, (ll) inv * B[to] % P);
			Add(now, P - (ll) inv * A[to] % P);
		}
		int rs = (ll) c * Pow(now, P - 2) % P;
		printf("%d\n", rs);
	}
	
}

int main() {
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	Rd(n);
	bool allb = true;
	scanf("%s", str + 1);
	for (int i = 1; i <= n; i++) allb &= (str[i] == '1');
	memset(Head, -1, sizeof(Head));
	for (int i = 1; i < n; i++) {
		int a, b;
		Rd(a), Rd(b);
		Addedge(a, b);
	}
	if (n <= 6) Subtask1::solve();
	else if (allb) Subtask2::solve();
	return 0;
}
