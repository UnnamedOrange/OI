#include<bits/stdc++.h>
using namespace std;
struct Info{
	int nu,ki;
}f[1000010];
int n,a[100010],b[100010];
void ge(int x,int y){
	if (f[x].nu+1==f[y].nu) f[y].ki+=f[x].ki;
	if (f[x].nu+1>f[y].nu){f[y]=f[x];f[y].nu++;}
}
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	f[0].ki=1;
	for (int i=1;i<=n;i++) scanf("%d %d",&a[i],&b[i]);
	for (int i=1;i<=n;i++){
		for (int j=i-1,jc=a[i],jd=b[i];j>=0;j--){
			if (i-j>=jc&&i-j<=jd)ge(j,i);
			jc=max(jc,a[j]);jd=min(jd,b[j]);
		}
	}
	if (f[n].nu==0) cout<<"-1"<<endl;else cout<<f[n].nu<<' '<<f[n].ki<<endl;
}
