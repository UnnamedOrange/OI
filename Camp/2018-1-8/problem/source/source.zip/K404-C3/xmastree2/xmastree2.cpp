#include<cmath>
#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iomanip>
#include<iostream>
#include<algorithm>
#define N 50
#define ll long long
#define mod 1000000009
using namespace std;
inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
struct zgz
{
	int next,to;
}edge[N<<1];
int head[N],cnt=1;
void add(int from,int to)
{
	edge[cnt].to=to;
	edge[cnt].next=head[from];
	head[from]=cnt++;
}
int w[N],r[N],p[N];
int fa[N];
void dfs(int x)
{
	for(int i=head[x];i;i=edge[i].next)
	{
		int to=edge[i].to;
		if(to!=fa[x])
		{
			fa[to]=x;
			dfs(to);
		}
	}
}
int n,ans;
int cho[N],T;
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	n=read();
	for(int i=2;i<=n;i++)
	{
		int x=read(),y=read();
		add(x,y),add(y,x);
	}
	for(int i=1;i<=n;i++)
	w[i]=read(),r[i]=read();
	for(int i=1;i<=n;i++)
	if(r[i])
	{
		memset(fa,0,sizeof(fa));
		dfs(i);
		for(int j=1;j<=n;j++)p[j]=j;
		do{
			T++;
			cho[0]=T;
			bool flag=0;
			int tmp=0;
			for(int j=1;j<=n;j++)
			{
				if(cho[fa[p[j]]]==T)
				{
					tmp+=w[p[j]]*j;
					cho[p[j]]=T;
				}
				else 
				{
					flag=1;
					break ;
				}
			}
			if(!flag)ans=max(ans,tmp);
			
		}while(next_permutation(p+1,p+n+1));
	}
	cout<<ans<<endl;
}