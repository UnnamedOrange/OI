#include<bits/stdc++.h>
using namespace std;
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
int mp[100100];
int popcnt[100100];
void csh(){
	for(int i=1;i<(1<<12);i++)
		popcnt[i]=popcnt[i>>1]+(i&1);
	int num=0;
	for(int i=0;i<(1<<12);i++)
		if(popcnt[i]==6)
			mp[++num]=i;
}
int main(){
//	freopen("xmasset.in","r",stdin);
//	freopen("xmasset.out","w",stdout);
	csh();
	int t;
	int n,T;
	scanf("%d",&t);
	scanf("%d%d",&n,&T);
	int x,y;
	for(int i=1;i<=T;i++){
		readl(x),readl(y);
		if(t==1){
			x=mp[x],y=mp[y];
			for(int j=0;j<12;j++){
				if((x&(1<<j))&&!(y&(1<<j))){
					printf("%d\n",j+1);
					break;
				}
			}
		}
		else{
			x=mp[x],y--;
			if(x&(1<<y))
				printf("yes\n");
			else
				printf("no\n");
		}
		
	}
	return 0;
}
