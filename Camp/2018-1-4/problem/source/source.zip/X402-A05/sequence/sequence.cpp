#include <bits/stdc++.h>

#define REP(i, t) for(int i = 0, i##E = (t); i < i##E; ++i)

int a[50], n, depth;

void swap(int j)
{
	for(int i = 1; i <= j/2; ++i)
		std::swap(a[i], a[j - (i-1)]);
}

bool dfs(int u, int now)
{
	if(depth - u + now < n) return false;

	if(u == depth){
		for(int i = 1; i <= n; ++i)
			if(a[i+1] - a[i] != 1) return false;
		return true;
	}
	for(int i = 2; i <= n; ++i){
		int cnt = bool(abs(a[i+1] - a[1]) == 1) - bool(abs(a[i+1] - a[i]) == 1);
		swap(i);
		if(dfs(u + 1, now + cnt)){
			return swap(i), true;
		}
		swap(i);
	}

	return false;
}

int main()
{
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);

	int T; scanf("%d", &T);
	while(T--){
		scanf("%d", &n);
		for(int i = 1; i <= n; ++i) scanf("%d", &a[i]);
		a[n + 1] = n + 1;
		int First = 0;
		for(int i = 1; i <= n; ++i) First += abs(a[i] - a[i+1]) == 1;

		for(depth = 1;; ++depth){
			if(dfs(0, First)){
				printf("%d\n", depth);
				break;
			}
		}
	}
	return 0;
}
