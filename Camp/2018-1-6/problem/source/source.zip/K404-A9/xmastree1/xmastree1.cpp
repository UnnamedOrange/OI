#include<bits/stdc++.h>
using namespace std;
#define N 100100
int c[N],c2[N];
struct Query {
	int opt,lc,rc,u,l,r;
}q[N];
bitset<N> s[2000];
struct Edge {
	int u,v,nxt;
}e[N*2];
int head[N],cnt;
void add(int u,int v) {
	e[++cnt].u=u;e[cnt].v=v;e[cnt].nxt=head[u];head[u]=cnt;
}
int l[N],r[N],tim;
void dfs(int po,int fa) {
	l[po]=++tim;
	c2[tim]=c[po];
	for(int i=head[po];i!=-1;i=e[i].nxt) {
		if(fa!=e[i].v) dfs(e[i].v,po);
	}
	r[po]=tim;
}
bitset<N> ans;
int main() {
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int n,Q,t;
	scanf("%d%d%d",&n,&Q,&t);
	memset(head,-1,sizeof(head));
	for(int i=1;i<=n;i++) scanf("%d",&c[i]);
	for(int i=1;i<n;i++) {
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	int n1=0,n2=0;
	for(int i=1;i<=Q;i++) {
		scanf("%d",&q[i].opt);
		if(q[i].opt==1) {
			scanf("%d%d%d",&q[i].u,&q[i].lc,&q[i].rc);
			n1++;
		} else {
			scanf("%d%d",&q[i].u,&q[i].lc);
			n2++;
		}
	}
	/*if(n1==0) n1=1;
	if(n2==0) n2=1;
	long double t1=(unsigned long long)n1*n*n;
	t1/=32.0*(abs(n1-n2)==0?1:abs(n1-n2));*/
	int quai;
	double _tmp=(n2+1)/(n1+1);
	quai=sqrt(n)*_tmp;
	if(quai==0) quai=1;
	dfs(1,1);
	for(int i=1;i<=n;i++) {
		s[i/quai][c2[i]-1]=1;
	}
	int last=0;
	for(int i=1;i<=Q;i++) {
		if(q[i].opt==1) {
			ans.reset();
			if(t==1) q[i].u^=last,q[i].lc^=last,q[i].rc^=last;
			q[i].l=l[q[i].u],q[i].r=r[q[i].u];
			int L=q[i].l/quai,R=q[i].r/quai;
			int Lr=(L+1)*quai-1,Rl=R*quai;
			Lr=min(Lr,n),Rl=max(Rl,1);
			if(L==R) {
				for(int j=q[i].l;j<=q[i].r;j++) {
					ans[c2[j]-1]=1;
				}
			} else {
				for(int j=q[i].l;j<=Lr;j++) {
					ans[c2[j]-1]=1;
				}
				for(int j=Rl;j<=q[i].r;j++) {
					ans[c2[j]-1]=1;
				}
				for(int j=L+1;j<R;j++) {
					ans|=s[j];
				}
			}
			last=(ans>>(q[i].lc-1)).count()-(ans>>q[i].rc).count();
			printf("%d\n",last);
		} 
		else {
			if(t==1) q[i].u^=last,q[i].lc^=last;
			int u=l[q[i].u];
			int fro=u/quai;
			int R=(fro+1)*quai-1,L=fro*quai,flag=0;
			for(int j=L;j<u;j++) {
				flag=(c2[j]==c2[u]);
			}
			for(int j=u+1;j<=R;j++) {
				flag=(c2[j]==c2[u]);
			}
			s[fro][c2[u]-1]=flag;
			c2[u]=q[i].lc;
			s[fro][c2[u]-1]=1;
			//cerr<<s[fro][9];
		}
	}
}
