#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 1010
#define ll long long
using namespace std;
inline int read() 
{ 
    int x=0,f=1;char ch=getchar(); 
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();} 
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
    return x*f; 
}
int T;
int n,W,p,q;
int x[N],y[N],z[N];
ll a[N],b[N],c[N],d[N],e[N],f[N];
struct zgz
{
	int x,y,r;
}lim[N];
ll w[N];
ll ans;
void dfs(int now)
{
	if(now==n+1)
	{
		for(int i=1;i<=q;i++)
		{
			if(lim[i].r==0&&w[lim[i].x]>w[lim[i].y])return ;
			if(lim[i].r==1&&w[lim[i].x]!=w[lim[i].y])return ;
			if(lim[i].r==2&&w[lim[i].x]>=w[lim[i].y])return ;
		}
		ll tmp=0;
		for(int i=1;i<=p;i++)
		tmp+=(a[i]*abs(w[x[i]]-w[y[i]]))+(b[i]*abs(w[y[i]]-w[z[i]]))+(c[i]*abs(w[z[i]]-w[x[i]]))+
			 (d[i]*   (w[x[i]]-w[y[i]]))+(e[i]*   (w[y[i]]-w[z[i]]))+(f[i]*   (w[z[i]]-w[x[i]]));
	 	for(int i=1;i<=n;i++)tmp+=w[i];
 		ans=min(ans,tmp);
		return ;
	}
	w[now]=W;
	dfs(now+1);
	w[now]=-W;
	dfs(now+1);
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read(),W=read(),p=read(),q=read();
		for(int i=1;i<=p;i++)
		x[i]=read(),y[i]=read(),z[i]=read(),
		a[i]=read(),b[i]=read(),c[i]=read(),
		d[i]=read(),e[i]=read(),f[i]=read();
		for(int i=1;i<=q;i++)
		lim[i].x=read(),lim[i].y=read(),lim[i].r=read();
		ans=1000000000000000000ll;
		dfs(1);
		cout<<ans<<endl;
	}
}