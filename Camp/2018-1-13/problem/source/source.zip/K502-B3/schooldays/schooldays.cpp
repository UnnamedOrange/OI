#include <stdio.h>
using namespace std;

#define ll long long int

const int maxn=1000001;
ll c[maxn],d[maxn];
ll n;

inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read();
	ll i;
	for(i=1;i<=n;i++)
		c[i]=read(),d[i]=read();
	printf("-1");
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
