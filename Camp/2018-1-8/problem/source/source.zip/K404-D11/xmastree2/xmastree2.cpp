#include<cstdio>
#include<vector>
#include<algorithm>
#include<queue>
#include<cstring>
#define LL long long
using namespace std;

const int maxn = 1e3 + 5;
int n;
int w[maxn], qq[maxn];
bool flag[maxn];
LL ans = 0;
vector<int> point[maxn];
queue<int> q;

struct lpl
{
	int w, fa;
}tree[maxn];

inline void putit()
{
	int u, v;
	scanf("%d", &n);
	for(int i = 1; i < n; ++i)
	{
		scanf("%d%d", &u, &v);
		point[u].push_back(v);	point[v].push_back(u);
	}	
	for(int i = 1; i <= n; ++i)
	{
		scanf("%d%d", &tree[i].w, &v);
		if(v == 1)	q.push(i);
	}
}

void build(int t)
{
	for(int i = point[t].size() - 1; i >= 0; --i)
	{
		int now = point[t][i];
		if(now == tree[t].fa)	continue;
		tree[now].fa = t; build(now);
	}
}

inline void print()
{
	LL ret = 0;
	for(int i = 1; i <= n; ++i)
	{
		ret += tree[qq[i]].w * i;
	}
	ans = max(ans, ret);
}

void dfs(int t)
{
	if(t == n + 1)	
	{
		print();
		return;
	}
	for(int i = 1; i <= n; ++i)
	{
		if(flag[i] == false)
		{
			if(flag[tree[i].fa] == true)
			{
				flag[i] = true; qq[t] = i;
				dfs(t + 1);
				flag[i] = false;
			}
		}
	}
}

inline void workk()
{
	memset(flag, false, sizeof(flag)); flag[0] = true;
	dfs(1);
}

int main()
{
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	putit();	
	while(!q.empty())
	{
		int now = q.front(); q.pop(); tree[now].fa = 0;
		build(now);
		workk();
		printf("%lld\n", ans);
	}
	return 0;
}
