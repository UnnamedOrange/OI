#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 4007;

struct qT
{
	qT () : x ( 0 ), y ( 0 ) {}
	qT ( int _x, int _y ) : x ( _x ), y ( _y ) {}
	
	void setd ( int _x, int _y )
	{
		x = _x, y = _y;
	}
	
	int x, y;
}q[MAXN*MAXN];

int n, m, k;
int a[MAXN], b[MAXN];
int lev[MAXN][MAXN];
int na[MAXN][MAXN], nb[MAXN][MAXN];



void init ();
void input ();
void work ();



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "subsequence" );
}

void input ()
{
	scanf ( "%d%d%d", &n, &m, &k );
	lpi ( i, 1, n ) scanf ( "%d", &a[i] );
	lpi ( i, 1, m ) scanf ( "%d", &b[i] );
}

void work ()
{
	lpi ( i, 1, k ) na[n+1][i] = n+1;
	lpdi ( i, n, 0 ){
		lpi ( j, 1, k ) na[i][j] = na[i+1][j];
		if ( i < n ) na[i][a[i+1]] = i+1;
	}
	
	lpi ( i, 1, k ) nb[m+1][i] = m+1;
	lpdi ( i, m, 0 ){
		lpi ( j, 1, k ) nb[i][j] = nb[i+1][j];
		if ( i < m ) nb[i][b[i+1]] = i+1;
	}
	
	int l = 0, r = 0, nx, ny, vx, vy;
	q[r++].setd ( 0, 0 );
	INIT ( lev, -1 );
	lev[0][0] = 0;
	while ( l < r ){
		if ( ~lev[n+1][m+1] ) break;
		nx = q[l].x, ny = q[l].y, ++l;
		lpi ( i, 1, k ){
			vx = na[nx][i], vy = nb[ny][i];
			if ( lev[vx][vy] == -1 ){
				lev[vx][vy] = lev[nx][ny] + 1;
				q[r++].setd ( vx, vy );
			}
		}
	}
	
	printf ( "%d\n", lev[n+1][m+1] );
}
