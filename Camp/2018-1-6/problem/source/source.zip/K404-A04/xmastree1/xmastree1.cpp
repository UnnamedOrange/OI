#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int maxn=100010;
int n,q,t,c[maxn],fa[maxn];
bool vis[5010];
struct edge
{
	int t;
	edge *next;
}*con[maxn];
void ins(int x,int y)
{
	edge *p=new edge;
	p->t=y;
	p->next=con[x];
	con[x]=p;
}
void dfs(int v)
{
	for(edge *p=con[v];p;p=p->next)
		if(p->t!=fa[v]) fa[p->t]=v,dfs(p->t);
}
void cal(int v)
{
	vis[c[v]]=1;
	for(edge *p=con[v];p;p=p->next)
		if(p->t!=fa[v]) cal(p->t);
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]);
	for(int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y);
		ins(y,x);
	}
	dfs(1);
	int ans=0;
	while(q--)
	{
		int opt,x,y,z;
		scanf("%d%d%d",&opt,&x,&y);
		x^=(t*ans);y^=(t*ans);
		if(opt==1)
		{
			scanf("%d",&z);z^=(t*ans);
			memset(vis,0,sizeof(vis));
			cal(x);ans=0;
			for(int i=y;i<=z;i++) ans+=vis[i];
			printf("%d\n",ans);
		}
		else c[x]=y;
	}
	return 0;
}

