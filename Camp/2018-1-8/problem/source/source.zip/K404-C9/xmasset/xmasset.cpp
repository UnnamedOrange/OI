#include<bits/stdc++.h> 
using namespace std;
int main() { 
	int mark,n,t;
	cin>>mark>>n>>t;
	int a,b;
	for(int i=0;i<t;++i) {
		scanf("%d%d",&a,&b);
		if(mark==1) cout<<-a<<endl;
		else {
			if(-a==b) cout<<"yes"<<endl;
			else cout<<"no"<<endl;
		}
	}
} 
