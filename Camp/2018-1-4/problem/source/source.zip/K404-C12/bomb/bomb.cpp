#include <iostream>
#include <cstring>
#include <cstdio>
#define MAX_N 1000005
using namespace std; 
inline int getint()
{
	int ch = getchar(), res = 0; 
	for (; ch < 48; ch = getchar()); 
	for (; ch >= 48; ch = getchar())
		res = (res << 3) + (res << 1) + ch - 48; 
	return res; 
}
int seq[MAX_N], cnt, comp[MAX_N], sz[MAX_N], comp_cnt; 
int x[MAX_N], y[MAX_N], que[MAX_N], dp[MAX_N], t; 
int low[MAX_N], dfn[MAX_N], vis[MAX_N], st[MAX_N], tp; 
int lst[MAX_N], to[MAX_N], pre[MAX_N], deg[MAX_N], tot; 
inline void add_edge(int u, int v)
{
	to[tot] = v; 
	pre[tot] = lst[u]; 
	lst[u] = tot++; 
	deg[v]++; 
}
void tarjan(int u)
{
	vis[u] = 1; 
	low[u] = dfn[u] = t++; 
	st[tp++] = u; 
	for (int i = lst[u]; ~i; i = pre[i])
	{
		if (vis[to[i]] == 0)
			tarjan(to[i]); 
		if (vis[to[i]] == 1)
			low[u] = min(low[u], low[to[i]]); 
	}
	if (low[u] == dfn[u])
	{
		do
		{
			tp--; 
			comp[st[tp]] = comp_cnt; 
			sz[comp_cnt]++; 
			low[st[tp]] = comp_cnt; 
			vis[st[tp]] = -1; 
		} while (st[tp] != u);
		comp_cnt++; 
	}
}
int main()
{
	freopen("bomb.in", "r", stdin); 
	freopen("bomb.out", "wt", stdout); 
	int n = getint(), m = getint(); 
	memset(lst, -1, sizeof(lst)); 
	for (int i = 0; i < m; i++)
	{
		x[i] = getint(); 
		y[i] = getint(); 
		add_edge(--x[i], --y[i]); 
	}
	for (int i = 0; i < n; i++)
	{
		if (!vis[i])
			tarjan(i); 
	}
	memset(lst, -1, sizeof(lst));
	memset(deg, 0, sizeof(deg));  
	tot = 0; 
	for (int i = 0; i < m; i++)
	{
		if (comp[x[i]] != comp[y[i]])
			add_edge(comp[x[i]], comp[y[i]]); 
	}
	int he = 0, ta = 0; 
	for (int i = 0; i < comp_cnt; i++)
	{
		if (!deg[i])
		{
			que[ta++] = i; 
			dp[i] = sz[i]; 
		}
	}
	while (he < ta)
	{
		int u = que[he++]; 
		for (int i = lst[u]; ~i; i = pre[i])
		{
			dp[to[i]] = max(dp[to[i]], dp[u] + sz[to[i]]); 
			if (!--deg[to[i]])
				que[ta++] = to[i]; 
		}
	}
	int ans = 0; 
	for (int i = 0; i < comp_cnt; i++)
		ans = max(ans, dp[i]); 
	printf("%d\n", ans); 
	return 0; 
}

