#include<stdio.h>
#include<cctype>
#include<stack>
#include<algorithm>
using namespace std;
#define Maxm 1000009
#define Maxn 1000009
#define rep(i, a, b) for(int i = (a), i##_end_ = (b); i <= i##_end_ ; ++i)
#define inf (1 << 30)
int nxt[Maxm], to[Maxm], head[Maxm], e;
int nxt2[Maxm], to2[Maxm], head2[Maxm], e2;
inline void add(int a, int b) {
	to[++e] = b;
	nxt[e] = head[a];
	head[a] = e;
}
inline void add2(int a, int b) {
	to2[++e2] = b;
	nxt2[e2] = head2[a];
	head2[a] = e2;
}
int n, m;
int dfn[Maxn], low[Maxn], index, belong[Maxn], sak, size[Maxn];
int instack[Maxn];
stack <int> s;
void tarjan(int u) {
	dfn[u] = low[u] = ++index;
	instack[u] = 1;
	s.push(u);
	for(int i = head[u]; i; i = nxt[i]) {
		int v = to[i];
		if(!dfn[v]) {
			tarjan(v);
			low[u] = min(low[v], low[u]);
		}else if(instack[v]) low[u] = min(low[u], dfn[v]);
	}
	if(low[u] == dfn[u]) {
		++sak;int v;
		do {
			v = s.top(); s.pop();
			belong[v] = sak; ++size[sak];
			instack[v] = 0;
		}while(v != u);
	}
}
int dp[Maxn];
int dfs(int a) {
	if(dp[a]) return dp[a];
	dp[a] = 0;
	for(int i = head2[a];i;i = nxt2[i]) {
		int v = to2[i];
		dp[a] = max(dp[a], dfs(v));
	}
	return dp[a] += size[a];
}
inline int read() {
	int x = 0;
	char ch = getchar();
	while(!isdigit(ch)) ch = getchar();
	while(isdigit(ch)) {
		x = (x << 3) + (x << 1) + (ch ^ 48);
		ch = getchar();
	}
	return x;
}

int main(){
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	n = read(); m = read();
	rep(i, 1, m) add(read(), read());
	rep(i, 1, n) 
		if(!dfn[i]) tarjan(i);
	rep(i, 1, n) 
		for(int j = head[i];j;j = nxt[j]) {
			int v = to[j];
			if(belong[v] != belong[i])
				add2(belong[i], belong[v]);
		}
	int ans = -inf;
	rep(i, 1, sak) 
		ans = max(dfs(i), ans);
	printf("%d\n", ans);
	return 0;
}
