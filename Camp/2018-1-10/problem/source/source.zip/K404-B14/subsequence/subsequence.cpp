#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int INF = 0x3f3f3f3f;
const int p = 666623333;
inline void gmin(int &x, int y){x = x < y ? x : y;}
inline void gmax(int &x, int y){x = x > y ? x : y;}
const int MAXN = 4010;
int n, m, K, uplen;
int a[MAXN], b[MAXN];
int pa[MAXN], pb[MAXN];
int pos[MAXN];
int f[2][MAXN];
int g[2][MAXN][MAXN];
LL cnt[MAXN];
LL s[MAXN];
int ans;
int qm(LL a, int x){
	LL ret = 1;
	while(x){
		if(x & 1) ret = ret * a % p;
		a = a * a % p;
		x >>= 1;
	}
	return ret;
}
int main(){
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &K);
	uplen = max(n, m) + 1;
	memset(pos, 0, sizeof(pos));
	for(int i = 1; i <= n; i++){
		scanf("%d", a + i);
		pa[i] = pos[a[i]];
		pos[a[i]] = i;
	}
	memset(pos, 0, sizeof(pos));
	for(int i = 1; i <= m; i++){
		scanf("%d", b + i);
		pb[i] = pos[b[i]];
		pos[b[i]] = i;
	}
	//dpA
	for(int i = 1; i <= n; i++) if(!pa[i]) f[1][i] = 1, cnt[1]++; else f[1][i] = 0;
	for(int j = 2, cur = j & 1; j <= uplen; j++, cur ^= 1){
		LL sum = 0;
		for(int i = 1; i <= n; i++){
			f[cur][i] = sum;
			cnt[j] = (cnt[j] + f[cur][i]) % p;
			sum = (sum + f[!cur][i]) % p;
		}
	}
	//dpB
	for(int i = 1; i <= m; i++) if(!pb[i]) f[1][i] = 1, cnt[1]++; else f[1][i] = 0;
	for(int j = 2, cur = j & 1; j <= uplen; j++, cur ^= 1){
		LL sum = 0;
		for(int i = 1; i <= m; i++){
			f[cur][i] = sum;
			cnt[j] = (cnt[j] + f[cur][i]) % p;
			sum = (sum + f[!cur][i]) % p;
		}
	}
	//dpAandB
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
			if((a[i] == b[j]) && (!pa[i] && !pb[j])) g[1][i][j] = 1, cnt[1]--; else g[1][i][j] = 0;
	for(int k = 2, cur = k & 1; k <= uplen; k++, cur ^= 1){
		memset(s, 0, sizeof(s));
		for(int i = 1; i <= n; i++){
			LL sum = 0;
			for(int j = 1; j <= m; j++){
				if(a[i] == b[j]){
					g[cur][i][j] = (sum + s[j]) % p;
					cnt[k] = (cnt[k] - g[cur][i][j] + p) % p;
				}
				else g[cur][i][j] = 0;
				sum = (sum + s[j]) % p;
				s[j] = (s[j] + g[!cur][i][j]) % p;
			}
		}
	}
	//calc
	ans = 1;
	while(qm(K, ans) == cnt[ans]) ans++;
	printf("%d\n", ans);
	return 0;
}

