#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
int n,m,a[1000010],ans,ti;
int k,b[1000010];
bool vis[1000010];
int cnt,head[1000010],to[2000010],nxt[2000010];
queue<int> q;
void add(int x,int y)
{
	cnt++;
	to[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
void dfs(int x)
{
	vis[x]=true;
	k=0;
	for (int i=head[x];i;i=nxt[i])
	{
		ti++;
		int y=to[i];
		if (vis[y])
		{
			b[k]=a[y];
			k++;
		}
	}
	sort(b,b+k);
	if (!k || b[0]>1)
	{
		a[x]=1;
	}
	else
	{
		bool f=false;
		for (int i=1;i<k;i++)
		{
			ti++;
			if (b[i]-b[i-1]>1)
			{
				a[x]=b[i-1]+1;
				f=true;
				break;
			}
		}
		if (!f)
		{
			a[x]=b[k-1]+1;
		}
	}
	for (int i=head[x];i;i=nxt[i])
	{
		ti++;
		int y=to[i];
		if (!vis[y])
		{
			q.push(y);
		}
	}
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read();
	m=read();
	for (int i=0;i<m;i++)
	{
		int x,y;
		x=read();
		y=read();
		if (x==y)
		{
			continue;
		}
		add(x,y);
		add(y,x);
	}
	for (int i=1;i<=n;i++)
	{
		if (!vis[i])
		{
			q.push(i);
			while (!q.empty())
			{
				int x=q.front();
				q.pop();
				dfs(x);
				if (ti>=1e8)
				{
					break;
				}
			}
		}
		if (ti>=1e8)
		{
			break;
		}
	}
	ans=0;
	for (int i=1;i<=n;i++)
	{
		ans=max(ans,a[i]);
	}
	printf("%d\n",ans);
	return 0;
}
