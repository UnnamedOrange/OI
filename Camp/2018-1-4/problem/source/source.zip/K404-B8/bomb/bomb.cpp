#include<bits/stdc++.h>
using namespace std;
const int maxn = 1000009;

vector<int> to[maxn],E[maxn];
int dfn[maxn],low[maxn],bel[maxn],val[maxn],du[maxn],f[maxn];
bool vis[maxn];
int n,m,tot,idx,ans;
stack<int> stk;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

void tarjan(int x)
{
	dfn[x]=low[x]=++idx;
	stk.push(x);vis[x]=1;
	int sz=to[x].size();
	for(int i=0;i<sz;i++)
	{
		int w=to[x][i];
		if(!dfn[w]) tarjan(w),low[x]=min(low[x],low[w]);
		else if(vis[w]) low[x]=min(low[x],dfn[w]);
	}
	if(low[x]==dfn[x])
	{
		tot++;int t;
		do
		{
			t=stk.top();stk.pop();
			val[tot]++;bel[t]=tot;vis[t]=0;
		}while(t!=x);
	}
}

int dp(int x)
{
	if(f[x]) return f[x];
	int res=0,sz=E[x].size();
	for(int i=0;i<sz;i++) res=max(res,dp(E[x][i]));
	res+=val[x];
	return f[x]=res;
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();
		to[x].push_back(y);
	}
	for(int i=1;i<=n;i++) if(!dfn[i]) tarjan(i);
	for(int x=1;x<=n;x++)
	{
		int sz=to[x].size();
		for(int i=0;i<sz;i++)
		{
			int w=to[x][i];
			if(bel[x]!=bel[w]) E[bel[x]].push_back(bel[w]),du[bel[w]]++;
		}
	}
	int ans=0;
	for(int i=1;i<=tot;i++) if(du[i]==0) ans=max(ans,dp(i));
	cout<<ans<<endl;
	return 0;
}
