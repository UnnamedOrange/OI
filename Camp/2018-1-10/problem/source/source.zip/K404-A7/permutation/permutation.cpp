/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 100000 + 10;
const int mod = 998244353;

int ans, n;
int p[MAXN], father[MAXN], cnt[MAXN];
bool chose[MAXN];

inline int get_father(int x) {
	return (father[x] == x) ? (x) : (father[x] = get_father(father[x]));
}

inline void unite(int x, int y) {
	int fa1 = get_father(x), fa2 = get_father(y);
	if (fa1 != fa2) father[fa1] = fa2;
}

inline void dfs(int cur) {
	if (cur == n + 1) {
		for (int i = 1; i <= n; ++i) father[i] = i, cnt[i] = 0;
		for (int i = 1; i <= n; ++i) unite(i, p[i]);
		for (int i = 1; i <= n; ++i) cnt[get_father(i)]++;
		for (int i = 1; i <= n; ++i) if (cnt[i] & 1) return ;
		ans++;
		return ;
	}
	if (p[cur] != 0) {
		dfs(cur + 1);
	} else {
		for (int i = 1; i <= n; ++i) 
			if (!chose[i]) p[cur] = i, chose[i] = true, 
				dfs(cur + 1), chose[i] = false, p[cur] = 0;
	}
}

inline void solve() {
	if (n & 1) std::cout << "0";
	else {
		int ans = 1;
		for (int i = 1; i <= n; i += 2)
			ans = (long long)ans * i % mod;
		std::cout << (long long)ans * ans % mod;
	}
}

int main() {
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	bool flag = false;
	R(n);
	for (int i = 1; i <= n; ++i) {
		R(p[i]), chose[p[i]] = true;
		if (p[i] != 0) flag = true ;
	}
	if (n & 1) std::cout << "0", exit(0); 
	if (!flag) solve();
	else dfs(1), std::cout << ans % mod;
	return 0;
}
