#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int mo=998244353;
int n,m,k,ans;
int a[10];
int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}
void Add(int& x,int y){
    x+=y;
    if(x>=mo) x-=mo;
    if(x<0) x+=mo;
}
void dfs(int u,int L,int R){
    if(u==n+1){
        for(int i=1;i<=m;i++) Add(ans,fpm(a[i],k));
        return;
    }
    for(int l=L+1;l<=m;l++)
        for(int r=max(l,R+1);r<=m;r++){
            for(int i=l;i<r;i++) a[i]++;
            dfs(u+1,l,r);
            for(int i=l;i<r;i++) a[i]--;
        }
}
int f[41][41][41],g[41][41][41];
int main(){
    freopen("segment.in","r",stdin);
    freopen("segment.out","w",stdout);
    read(n); read(m); read(k);
    if(n>m) puts("0"),exit(0);
    if(n==1){
        for(int i=1;i<=m;i++) Add(ans,1ll*(i-1)*(m-i+1)%mo);
        printf("%d\n",ans);
        return 0;
    }
    if(k==1&&m<=40){
        for(int L=1;L<=m;L++)
            for(int R=L;R<=m;R++){
                f[1][L][R]=R-L;
                g[1][L][R]=1;
            }
        for(int i=2;i<=n;i++)
            for(int L=1;L<=m;L++)
                for(int R=L;R<=m;R++){
                    for(int l=L-1;l;l--)
                        for(int r=R-1;r>=l;r--){
                            Add(f[i][L][R],f[i-1][l][r]);
                            Add(g[i][L][R],g[i-1][l][r]);
                        }
                    Add(f[i][L][R],1ll*(R-L)*g[i][L][R]%mo);
                }
        for(int L=1;L<=m;L++)
            for(int R=L;R<=m;R++) Add(ans,f[n][L][R]);
        printf("%d\n",ans);
        return 0;
    }
    dfs(1,0,0);
    printf("%d\n",ans);
    return 0;
}
