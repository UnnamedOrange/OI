#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;
typedef long long ll;

struct edge{
	int to, nxt;
}e[2000005];

int h[1000005], h2[1000005], cnt;

const int MAXSIZE=50000020;
int bufpos;
char buf[MAXSIZE];
int re(){
    int val=0;
    for(;buf[bufpos]<'0' || buf[bufpos]>'9';bufpos++);
    for(;buf[bufpos]>='0' && buf[bufpos]<='9' ;bufpos++)
        val=val*10+buf[bufpos]-'0';
    return val;
}

void addedge(int x, int y){
	cnt++; e[cnt].to = y; e[cnt].nxt = h[x]; h[x] = cnt;
}
void addedge2(int x, int y){
	cnt++; e[cnt].to = y; e[cnt].nxt = h2[x]; h2[x] = cnt;
}
int dfn[1000005], low[1000005], bl[1000005], siz[1000005], tot, du[1000005];
int vis[1000005], ct;
int stk[1000005], tp;
int n, m;

void dfs(int x){
	dfn[x] = low[x] = ++ct;
	vis[x] = 1; stk[++tp] = x;
	for(int i = h[x]; i; i = e[i].nxt){
		if(!dfn[e[i].to]){
			dfs(e[i].to);
			low[x] = min(low[x], low[e[i].to]);
		}else if(vis[e[i].to]){
			low[x] = min(low[x], dfn[e[i].to]);
		}
	}
	if(dfn[x] == low[x]){
		tot++;
		while(stk[tp] != x){
			bl[stk[tp]] = tot;
			++siz[tot];
			vis[stk[tp]] = 0;
			tp--;
		}
		bl[stk[tp]] = tot;
		++siz[tot];
		vis[stk[tp]] = 0;
		tp--;
	}
}

void rebuild(int x){
	for(int i = h[x]; i; i = e[i].nxt){
		if(bl[x] != bl[e[i].to]){
			addedge2(bl[x], bl[e[i].to]);
			du[bl[e[i].to]] ++;
		}
	}
}
int dis[1000005];
queue<int> q;
void solve(){
	for(int i = 1; i <= tot; i ++){
		if(du[i] == 0) q.push(i), dis[i] = siz[i];
	}
	while(!q.empty()){
		int x = q.front();
		q.pop();
		for(int i = h2[x]; i; i = e[i].nxt){
			du[e[i].to] --;
			dis[e[i].to] = max(dis[e[i].to], dis[x]);
			if(du[e[i].to] == 0){
				dis[e[i].to] += siz[e[i].to];
				q.push(e[i].to);
			}
		}
	}
	int ans = 0;
	for(int i = 1; i <= tot; i ++){
//		printf("%d %d\n", siz[i], dis[i]);
		ans = max(ans, dis[i]);
	}
	printf("%d\n", ans);
}


int main(){
    freopen("bomb.in", "r", stdin);
    freopen("bomb.out", "w", stdout);
	//scanf("%d%d", &n, &m);
	buf[fread(buf, 1, MAXSIZE, stdin)] = '\0';
    bufpos=0;
	n = re(); m = re();
	for(int i = 1; i <= m; i ++){
		int x, y;
		//scanf("%d%d", &x, &y);
		x = re(); y = re();
		addedge(x, y);
	}
	for(int i = 1; i <= n; i ++){
		if(!dfn[i]) dfs(i);
	}
	for(int i = 1; i <= n; i ++){
		rebuild(i);
	}
	solve();
	return 0;
} 
