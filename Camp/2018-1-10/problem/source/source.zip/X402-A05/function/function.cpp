#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl
#define fst first
#define snd second

typedef long long LL;
typedef std::pair<int, int> Pii;

#ifdef __linux__
#define getchar getchar_unlocked
#endif
template <typename T> inline bool maximum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T> inline bool minimum(T &a, T b) { return a > b? a = b, 1 : 0; }
template <typename T>
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 1e6 + 10;

int fpm(int x, int y)
{
	int ret = 1;
	for(; y; y >>= 1, x = x * x)
		if(y & 1) ret = ret * x;
	return ret;
}

int prime[N], tot;
int mu[N], d[N];
int minfac[N], times[N];
bool isn_prime[N];

void prime_init()
{
	mu[1] = 1;
	for(int i = 2; i < N; ++i){
		if(!isn_prime[i]){
			prime[++tot] = i;
			mu[i] = -1;
			minfac[i] = i, times[i] = 1;
		}
		for(int j = 1; j <= tot && prime[j] * i < N; ++j){
			int o = i * prime[j];
			isn_prime[o] = 1;

			if(i % prime[j]){
				minfac[o] = prime[j];
				times[o] = 1;
				mu[o] = -mu[i];
			}
			else{
				int tmp = i, cnt = 0;
				while(tmp % prime[j] == 0) tmp /= prime[j], ++cnt;
				minfac[o] = prime[j];
				times[o] = cnt + 1;
				mu[o] = 0;
				break;
			}
		}
	}
}

int n; LL F[N];
std::vector<Pii> diver[N];
std::vector<int> factor[N];

void dfs_factor(int dep, int ret, int u)
{
	if(dep == (int)diver[u].size()){
		factor[u].push_back(ret);
		return ;
	}
	for(int i = 0; i <= diver[u][dep].snd; ++i){
		dfs_factor(dep + 1, ret, u);
		ret *= diver[u][dep].fst;
	}
}

int main()
{
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);

	prime_init();

	for(int i = 1; i < N; ++i){
		d[i] = 1;
		for(int tmp = i; tmp != 1;){
			d[i] *= (1 + times[tmp]);
			diver[i].push_back(Pii(minfac[tmp], times[tmp]));
			tmp /= fpm(minfac[tmp], times[tmp]);
		}
	}

	for(int i = 1; i < N; ++i){
		if(i != 1) dfs_factor(0, 1, i);
		else factor[i].push_back(1);
	}

	for(int i = 1; i < N; ++i){
		for(int j = 0; j < (int)factor[i].size(); ++j){
			int p = factor[i][j];
			F[i] += 1LL * mu[p] * d[i/p] * d[i/p];
		}
		F[i] += F[i-1];
	}

	int T; read(T);
	while(T--){
		read(n); printf("%lld\n", F[n]);
	}

	return 0;
}
