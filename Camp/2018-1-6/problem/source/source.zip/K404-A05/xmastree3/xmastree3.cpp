//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=998244353;
void upd(int &x,int v){x=x+v>=mod?x+v-mod:x+v;}
int A[1<<15][31],B[1<<15][31];
void FMT(int n,int coef)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<(1<<n);j++)
		{
			if((j>>i)&1)continue;
			for(int t=0;t<=2*n;t++)
			{
				upd(A[j|(1<<i)][t],coef==1?A[j][t]:mod-A[j][t]);
			}
		}
	}
}
int n,k;
int dp[52][1<<15];
int tc[1<<15];
vector<int> con[52];
int cnt1[1<<15];
void combine(int a[],int b[],int c[],int n)
{
	
	for(int i=0;i<(1<<n);i++)for(int j=0;j<=2*n;j++)A[i][j]=a[i]*(cnt1[i]==j);
	FMT(n,1);
	for(int i=0;i<(1<<n);i++)for(int j=0;j<=2*n;j++)B[i][j]=b[i]*(cnt1[i]==j);
	for(int i=0;i<(1<<n);i++)for(int j=0;j<=2*n;j++)swap(A[i][j],B[i][j]);
	FMT(n,1);
	for(int i=0;i<(1<<n);i++)
	{
		int tmp[32]={};
		for(int j=0;j<=n;j++)
		{
			for(int k=0;k<=n;k++)
			{
				upd(tmp[j+k],1ll*A[i][j]*B[i][k]%mod);
			}
		}
		for(int j=0;j<=2*n;j++)A[i][j]=tmp[j];
	}
	FMT(n,-1);
	for(int i=0;i<(1<<n);i++)c[i]=A[i][cnt1[i]];
	/*
	memset(tc,0,sizeof(tc));
	for(int i=0;i<(1<<n);i++)
	{
		if(!a[i])continue;
		int S=(1<<n)-1-i,msk=S;
		while(true)
		{
			upd(tc[i|msk],1ll*a[i]*b[msk]%mod);
			if(msk==0)break;
			msk=(msk-1)&S;
		}
	}
	for(int i=0;i<(1<<n);i++)c[i]=tc[i];*/
}
int tmp[1<<15],cur[1<<15];
void dfs(int x,int pre=-1)
{
	for(int i=0;i<con[x].size();i++)
	{
		int u=con[x][i];
		if(u==pre)continue;
		dfs(u,x);
	}
	for(int v=0;v<k;v++)
	{
		memset(cur,0,sizeof(cur));
		cur[1<<v]=1;
		for(int i=0;i<con[x].size();i++)
		{
			int u=con[x][i];
			if(u==pre)continue;
			memset(tmp,0,sizeof(tmp));
			for(int j=0;j<(1<<k);j++)
			{
				if((j>>v)&1)continue;
				upd(tmp[j&((1<<v)-1)],dp[u][j]);
			}
			combine(tmp,cur,cur,v+1);
		}
		for(int i=0;i<(1<<k);i++)upd(dp[x][i],cur[i]);
	}
//	cerr<<"x="<<x<<endl;
//	for(int i=0;i<(1<<k);i++)cerr<<dp[x][i]<<" ";cerr<<endl;
}
int main()
{
	for(int i=1;i<(1<<15);i++)cnt1[i]=cnt1[i-(i&(-i))]+1;
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<n;i++)
	{
		int x,y;
		cin>>x>>y;
		con[x].PB(y);
		con[y].PB(x);
	}
	dfs(1);
	int sum=0;
	for(int i=0;i<(1<<k);i++)upd(sum,dp[1][i]);
	cout<<sum<<endl;
	return 0;
}
