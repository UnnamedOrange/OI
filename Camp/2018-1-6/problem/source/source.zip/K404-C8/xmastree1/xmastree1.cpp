#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<set>
using namespace std;
const int N=100005;
const double pi=0.75;


set<int> col[N];
set<int>::iterator it,pre,nex;


int n,q,tt,hd[N],pr[N*2],to[N*2],tot,ans;
void addedge(int u,int v) {to[++tot]=v;pr[tot]=hd[u];hd[u]=tot;}
int c[N],p[N],L[N],dfn,R[N],idd[N];
void dfs(int u,int fa) 
{
	L[u]=++dfn;idd[dfn]=u;
	for (int i=hd[u];i;i=pr[i]) if (to[i]!=fa) dfs(to[i],u);
	R[u]=dfn;
}

int root,D,tmp[N],s[N*30],top,cnt,id[N];
inline int node(){return top ? s[top--] : ++cnt;}
struct aa
{
	int lc,rc,mi[3],mx[3],x[3],sz,dsz;bool o;
	void print()
	{
		printf("lc=%d rc=%d mi0=%d mx0=%d mi1=%d mx1=%d mi2=%d mx2=%d sz=%d dsz=%d o=%d\n",
		lc,rc,mi[0],mx[0],mi[1],mx[1],mi[2],mx[2],sz,dsz,o
		);
	}
}a[N*30];
void print(int u)
{
	if (u==0) return ;
	printf("u=%d ",u);a[u].print();
	print(a[u].lc);
	print(a[u].rc);
}
bool cmp(int x,int y) 
{
	if (a[x].x[D]!=a[y].x[D]) return a[x].x[D]<a[y].x[D];
	if (a[x].x[(D+1)%3]!=a[y].x[(D+1)%3]) return a[x].x[(D+1)%3]<a[y].x[(D+1)%3];
	return a[x].x[(D+2)%3]<a[y].x[(D+2)%3];
}
void up(int u,int v) 
{
	for (int i=0;i<3;i++) 
	{
		a[u].mi[i]=min(a[u].mi[i],a[v].mi[i]);
		a[u].mx[i]=max(a[u].mx[i],a[v].mx[i]);
	}
}
int build(int l,int r,int d) 
{
	D=d;int mid=(l+r)>>1,u;
	nth_element(tmp+l,tmp+mid,tmp+r+1,cmp);
	u=tmp[mid];
	for (int i=0;i<3;i++) a[u].mi[i]=a[u].mx[i]=a[u].x[i];
	a[u].sz=r-l+1;a[u].dsz=0;a[u].o=false;
	if (l<mid) a[u].lc=build(l,mid-1,(d+1)%3),up(u,a[u].lc);else a[u].lc=0;
	if (mid<r) a[u].rc=build(mid+1,r,(d+1)%3),up(u,a[u].rc);else a[u].rc=0;
	return u;
}



int S,fa,dd;

void dfsdel(int u,int t,int d,int la) 
{
	a[u].dsz++;
	if (u==t) a[u].o=true;
	else 
	{
		D=d;
		if (cmp(t,u)) dfsdel(a[u].lc,t,(d+1)%3,u);
		else dfsdel(a[u].rc,t,(d+1)%3,-u);
	}

	for (int i=0;i<3;i++) 
	if (!a[u].o) a[u].mi[i]=a[u].mx[i]=a[u].x[i];
	else a[u].mi[i]=1e9,a[u].mx[i]=-1e9;
	
	if (a[u].lc) up(u,a[u].lc);
	if (a[u].rc) up(u,a[u].rc); 
	if (a[u].dsz>a[u].sz*pi) S=u,fa=la,dd=d;
}
int num;
void clear(int u) 
{
	if (!u) return ;
	if (a[u].o) s[++top]=u;else tmp[++num]=u;
	clear(a[u].lc);
	clear(a[u].rc);
}
void del(int u) 
{
//	printf("del %d\n",u);
	int t=id[u];
	S=0,fa=0;
	dfsdel(root,t,0,0);

	if (S!=0) 
	{
		num=0,clear(S);
		if (!num) 
		{
			if (fa>0) a[fa].lc=0;else a[-fa].rc=0;
			return ;
		}
		int u=build(1,num,dd);
		if (fa==0) root=u;
		else if (fa>0) a[fa].lc=u;
		else a[-fa].rc=u;
	}
}

void insert(int &u,int t,int d,int la) 
{
	if (!u) {u=t;return;}
	a[u].sz++;up(u,t);
	D=d;if (cmp(t,u)) insert(a[u].lc,t,(d+1)%3,u);
		else insert(a[u].rc,t,(d+1)%3,-u);
	if (max(a[a[u].lc].sz,a[a[u].rc].sz)>a[u].sz*pi) S=u,fa=la,dd=d;
}
void ins(int u) 
{
	//printf("ins %d\n",u);
	id[u]=node();
	a[id[u]].x[0]=L[u],a[id[u]].x[1]=c[u],a[id[u]].x[2]=p[u];
	a[id[u]].sz=1;a[id[u]].dsz=0;a[id[u]].o=false;a[id[u]].lc=a[id[u]].rc=0;

	for (int i=0;i<3;i++) a[id[u]].mi[i]=a[id[u]].mx[i]=a[id[u]].x[i];
	
	S=0;fa=0;
	insert(root,id[u],0,0);

	if (S!=0) 
	{		
		num=0,clear(S);
		if (!num) 
		{
			if (fa>0) a[fa].lc=0;else a[-fa].rc=0;
			return ;
		}
		int u=build(1,num,dd);
		if (fa==0) root=u;
		else if (fa>0) a[fa].lc=u;
		else a[-fa].rc=u;
	}
}

void work2()
{
	int u,C,v;
	scanf("%d%d",&u,&C);u^=ans,C^=ans;
	if (C==c[u]) return ;

	del(u);
	
	it=pre=nex=col[c[u]].find(L[u]);
	++nex;
	if (nex!=col[c[u]].end()) 
	{
		del(v=idd[*nex]);
		if (pre==col[c[u]].begin()) p[v]=0;else p[v]=*(--pre);
		ins(v);
	}
	
	col[c[u]].erase(it);
	c[u]=C;
	col[c[u]].insert(L[u]);
	it=pre=nex=col[c[u]].find(L[u]);
	if (pre==col[c[u]].begin()) p[u]=0;else p[u]= *(--pre);
	ins(u);
	
	++nex;
	if (nex!=col[c[u]].end()) 
	{
		del(v=idd[*nex]);
		p[v]=L[u];
		ins(v);
	}
	//for (int i=1;i<=n;i++) printf("id[%d]=%d\n",i,id[i]);
	//print(root);
	//for (int i=1;i<=n;i++) 
	//printf("i=%d c=%d L=%d p=%d\n",i,c[i],L[i],p[i]);
}



int pan(int u,int *x,int *y) 
{
	bool o1=false,o2=false,o3=false;
	for (int i=0;i<3;i++)
	{	
		if (a[u].mi[i]<x[i]||a[u].mx[i]>y[i]) o1=true;
		if (a[u].x[i]<x[i]||a[u].x[i]>y[i]) o2=true;
		if (a[u].mi[i]>y[i]||a[u].mx[i]<x[i]) o3=true;
	}
	if (o3) return -1;
	if (!o1) return 1;
	if (!a[u].o&&!o2) return 2;
	return 3;
}
void query(int u,int *x,int *y)
{
	if (!u) return ;
	int t=pan(u,x,y);
	if (t==-1) return ;
	if (t==1) {ans+=a[u].sz-a[u].dsz;return;}
	if (t==2) ans++;
	query(a[u].lc,x,y);
	query(a[u].rc,x,y);
}
void work1()
{
	int u,l,r,x[3],y[3];
	scanf("%d%d%d",&u,&l,&r);u^=ans,l^=ans,r^=ans;
	ans=0;
	x[0]=L[u],x[1]=l,x[2]=0;
	y[0]=R[u],y[1]=r,y[2]=L[u]-1;
	query(root,x,y);
	printf("%d\n",ans);
	if (!tt) ans=0;
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);

	scanf("%d%d%d",&n,&q,&tt);
	for (int i=1;i<=n;i++) scanf("%d",&c[i]);
	for (int u,v,i=1;i<n;i++) {scanf("%d%d",&u,&v);addedge(u,v);addedge(v,u);}
	dfs(1,0);


	
	memset(hd,0,sizeof(hd));
	for (int u,i=1;i<=n;i++) 
	{
		u=idd[i];p[u]=hd[c[u]];hd[c[u]]=i;
		col[c[u]].insert(i);
	}
	for (int i=1;i<=n;i++) 
	{
		//printf("i=%d c=%d L=%d p=%d\n",i,c[i],L[i],p[i]);
		id[i]=i;
		a[i].x[0]=L[i],a[i].x[1]=c[i],a[i].x[2]=p[i];
		tmp[i]=i;
	}
	cnt=n;
	root=build(1,n,0);
	//
	//for (int i=1;i<=n;i++) printf("id[%d]=%d\n",i,id[i]);
	//print(root);
	
	
	int op;
	while (q--) {scanf("%d",&op);if (op==1) work1();else work2();}
	return 0;
}

/*
5 100 0
5 5 2 5 5
5 1
2 5
4 2
3 5


5 5 1
4 1 1 5 4
5 1
3 5
2 3
4 3
2 5 4
2 2 2
1 3 1 5
2 1 2
1 1 2 7
*/
