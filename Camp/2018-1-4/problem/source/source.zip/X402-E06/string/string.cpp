#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int M = 500;
const int N = 1200;
const int mo = 998244353;

namespace DFA {
    int ch[N + 5][2], cnt;
    int eval[N + 5], val[N + 5], fail[N + 5];

    void insert(char *s, bool *f, int len, int id) {
        int u = 0;
        for(int i = 0; i < len; ++i) {
            int c = s[i] - '0';
            if(!ch[u][c]) ch[u][c] = ++ cnt;
            u = ch[u][c];

            if(f[i]) eval[u] |= 1 << id;
        }
        val[u] |= 1 << id;
    }

    void get_fail() {
        static int que[N + 5]; 
        int head = 0, tail = 0;
        
        for(int i = 0; i < 2; ++i) {
            if(ch[0][i]) {
                fail[ch[0][i]] = 0;
                que[tail++] = ch[0][i];
            }
        }

        while(head < tail) {
            int x = que[head++];
            for(int c = 0; c < 2; ++c) {
                int y = ch[x][c];
                if(!y) { ch[x][c] = ch[fail[x]][c]; continue; }

                int j = fail[x];
                while(j && !ch[j][c]) j = fail[j];

                fail[y] = ch[j][c];
                val[y] |= val[fail[y]];
                eval[y] |= eval[fail[y]];

                que[tail++] = y;
            }
        }
    }

    int n, m, len;
    char st[N + 5];
    bool rev[N + 5];
    inline bool chk(int p) {
        int x = p;
        for(int i = p+1; i < len; ++i) {
            if(x < 0 || st[x] == st[i]) return false;
            -- x;
        }
        return true;
    }

    int dp[(1 << 6) + 5][N + 5][M + 5];
    int dfs(int s, int p, int l) {

        if(l == m) {
            return (s | eval[p]) == (1 << n) - 1;
        }

        int &ans = dp[s][p][l];
        if(ans >= 0) return ans;

        ans = 0;
        for(int i = 0; i < 2; ++i) {
            int nxtp = ch[p][i];
            ans = (ans + dfs(s | val[nxtp], nxtp, l+1)) % mo;
        }
        return ans;
    }

    void solve() {

        read(n), read(m);
        memset(dp, -1, sizeof dp);

        for(int i = 0; i < n; ++i) {
            scanf("%s", st);
            len = strlen(st);

            for(int j = 0; j < len; ++j) rev[j] = chk(j);
            insert(st, rev, len, i);

            std::reverse(st, st + len);
            for(int j = 0; j < len; ++j) st[j] = st[j] == '0' ? '1' : '0';
            for(int j = 0; j < len; ++j) rev[j] = chk(j);
            insert(st, rev, len, i);
        }

        get_fail();
        printf("%d\n", dfs(0, 0, 0));
    }
}

int main() {
    freopen("string.in", "r", stdin);
    freopen("string.out", "w", stdout);

    DFA::solve();
    return 0;
}
