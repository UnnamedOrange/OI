#include "diff.h"

template <class T> bool chkmin (T &x, T y) { return x > y ? x = y, true : false; }

long long getMiniumDistance(int R, int C) {
	long long ret = 1ll << 60;
	int x, y;
	for (x = 1; x <= R; x ++) for (y = 1; y <= C; y ++) {
		chkmin (ret, getDistance(x, y));
	}
	return ret;
}
