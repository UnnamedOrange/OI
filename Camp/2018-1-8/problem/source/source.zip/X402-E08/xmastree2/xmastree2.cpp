/*
Author: CNYALI_LK
LANG: C++
PROG: xmastree2.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#include<ext/pb_ds/priority_queue.hpp>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll beg[102424],to[204646],lst[230343],e;
void add(ll u,ll v){
	to[++e]=v;
	lst[e]=beg[u];
	beg[u]=e;
}
ll d[102424],w[102424],sum[102424],fa[102424];
void dfs(ll x,ll f){
	fa[x]=f;
	sum[x]=w[x];
	for(ll i=beg[x];i;i=lst[i])if(to[i]!=f){
		dfs(to[i],x);
		sum[x]+=sum[to[i]];
	}
}
typedef pair<ll,ll> pii;
__gnu_pbds::priority_queue<pii,greater<pii> > p;
#define x first
#define y second
ll js(ll n,ll h){
	while(!p.empty())p.pop();
	p.push(make_pair(sum[h],h));
	ll tot=sum[h],ans=0;
	while(n){
		--n;
		pii s=p.top();
		p.pop();
		ans+=tot;
		tot-=w[s.y];
		for(ll i=beg[s.y];i;i=lst[i])if(to[i]!=fa[s.y]){
			p.push(make_pair(sum[to[i]],to[i]));	
		}
	}
	return ans;
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	ll n,u,v;
	n=read();
	for(ll i=1;i<n;++i){
		u=read();v=read();
		add(u,v);
		add(v,u);
	}
	for(ll i=1;i<=n;++i){w[i]=read();d[i]=read();}
	ll ans=0;
	for(ll i=1;i<=n;++i)if(d[i]){
		dfs(i,0);
		chkmax(ans,js(n,i));
	}
	printf("%lld\n",ans);
	return 0;
}

