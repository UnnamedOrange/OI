#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,q,t,map[100010],cnt,lastans,fa[100010],vis[5010];
struct node 
{
	int v;
	node *next_;
}pool[400010],*h[100010];
void addedge(int u,int v)
{
	node *p=&pool[++cnt];
	p->v=v;p->next_=h[u];h[u]=p;
	p=&pool[++cnt];
	p->v=u;p->next_=h[v];h[v]=p;
}
void dfs1(int u,int ff)
{
	for(node *p=h[u];p;p=p->next_)
	{
		int v=p->v;
		if(v==ff) continue;
		fa[v]=u;dfs1(v,u);
	}
}
void dfs(int u)
{
	vis[map[u]]=q;
	for(node *p=h[u];p;p=p->next_)
	{
		int v=p->v;
		if(v==fa[u]) continue;
		dfs(v);
	}
}
int main()
{
	
	freopen("xmastree1.in","r",stdin);
	freopen("xmaxtree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++) scanf("%d",&map[i]),vis[i]=q+1;
	int u,v;
	for(int i=1;i<n;i++) scanf("%d%d",&u,&v),addedge(u,v);
	dfs1(1,1);
	if(n<=5000)
	{
		int type,u,l,r;
		while(q--)
		{
			scanf("%d",&type);
			if(type==1)
			{
				scanf("%d%d%d",&u,&l,&r);
				int ans=0;
				if(t) u^=lastans,l^=lastans,r^=lastans;
				dfs(u);
				for(int i=l;i<=r;i++) if(vis[i]==q) ans++;
				printf("%d\n",ans);
				lastans=ans;
			}
			if(type==2)
			{
				scanf("%d%d",&u,&l);
				if(t) u^=lastans,l^=lastans;
				map[u]=l;
			}
		}
	}
	return 0;
}
