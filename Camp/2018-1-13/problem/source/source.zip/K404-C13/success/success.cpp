#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<cstdio>
#include<algorithm>
using namespace std;

const int N=2000005;
const int mod=1000000007;

int n,m,s,t,ans,tag;
int fac[N],inv[N];

int quickpow(int x,int y){
	int s=1;
	for (;y;y>>=1,x=1ll*x*x%mod)
		if (y&1) s=1ll*s*x%mod;
	return s;
}

void init(){
	int i;
	fac[0]=inv[0]=1;
	for (i=1;i<=m+s;i++) fac[i]=1ll*fac[i-1]*i%mod;
	inv[m+s]=quickpow(fac[m+s],mod-2);
	for (i=m+s-1;i;i--) inv[i]=1ll*inv[i+1]*(i+1)%mod;
}

int C(int x,int y){
	if (x<y) return 0;
	return 1ll*fac[x]*inv[y]%mod*inv[x-y]%mod;
}

int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	int i;
	scanf("%d%d%d%d",&s,&t,&n,&m);
	init();
	tag=1;
	for (i=0;i<=n;i++){
		(ans+=1ll*tag*C(n,i)*C(s-i*t,m)%mod)%=mod;
		tag*=-1;
	}
	ans=(ans+mod)%mod;
	printf("%d\n",ans);
	return 0;
}
