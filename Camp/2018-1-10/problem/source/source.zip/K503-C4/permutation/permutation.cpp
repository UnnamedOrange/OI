#include<iostream>
#include<cstdio>
#define maxn 100010
#define mod 998244353
using namespace std;
int a[maxn],num,head[maxn],n,yuan[maxn],pos[maxn],cnt,sz[maxn],ans,tot,g;
struct node{int to,pre;}e[maxn];
bool vis[maxn],in[maxn];
int dfn[maxn],low[maxn],st[maxn],top;
void Insert(int from,int to){
	e[++num].to=to;
	e[num].pre=head[from];
	head[from]=num;
}
void Tarjan(int u){
	tot++;
	dfn[u]=low[u]=tot;
	st[++top]=u;in[u]=1;
	for(int i=head[u];i;i=e[i].pre){
		int v=e[i].to;
		if(!dfn[v]){
			Tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else{
			if(in[v])
			low[u]=min(low[u],dfn[v]);
		}
	}
	if(dfn[u]==low[u]){
		g++;
		while(st[top]!=u){
			int x=st[top];top--;
			in[x]=0;
			sz[g]++;
		}
		top--;
		in[u]=0;
		sz[g]++;
	}
}
void work(){
//	for(int i=1;i<=n;i++)printf("%d ",a[i]);puts("");
	for(int i=1;i<=8;i++){
		head[i]=0;
		e[i].to=e[i].pre=0;
		sz[i]=in[i]=dfn[i]=low[i]=st[i]=0;
		top=0;
	}num=0;tot=0;g=0;
	for(int i=1;i<=n;i++)Insert(i,a[i]);
	for(int i=1;i<=n;i++)
		if(!dfn[i])Tarjan(i);
	bool flag=0;
	for(int i=1;i<=g;i++)
		if(sz[i]&1){flag=1;break;}
	if(!flag)ans++;
	if(ans>=mod)ans-=mod;
}
void dfs(int now){
	if(now==cnt+1){
		work();
		return;
	}
	for(int i=n;i>=1;i--){
		if(!vis[i]){
			vis[i]=1;
			a[pos[now]]=i;
			dfs(now+1);
			vis[i]=0;
		}
	}
}
int main(){
	freopen("permutation.in","r",stdin);freopen("permutation.out","w",stdout);
//	freopen("Cola.txt","r",stdin);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&yuan[i]);a[i]=yuan[i];
		if(yuan[i])vis[yuan[i]]=1;
		else{pos[++cnt]=i;}
	}
	if((n&1)&&cnt==n){puts("0");return 0;}
	dfs(1);
	printf("%d",ans);
	return 0;
}
