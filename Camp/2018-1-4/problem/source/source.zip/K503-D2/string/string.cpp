#include<bits/stdc++.h>
using namespace std;
int m,n,an[100],f[100],ansn=0;
string st[20];
bool c;
void dfs(int x){
	if (x>m){
		for (int i=1;i<=m;i++)an[i]=f[i];
		for (int i=m+1;i<=m*2;i++) an[i]=1-f[2*n-i+1];
		for (int i=1;i<=n;i++){
			c=false;
			for (int j=1;j<=m*2-st[i].length()+1;j++){
				for (int k=0;k<st[i].length();k++){
					if (st[i][k]-'0'!=an[j+k]) break;
					if (k==st[i].length()-1) c=true;
				}
				if (c) break;
			}
			if (!c)return ;
		}
		ansn++;
	}else{
		f[x]=0;dfs(x+1);
		f[x]=1;dfs(x+1);
	}
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d %d",&n,&m);
	for (int i=1;i<=n;i++) cin>>st[i];
	if (m<=15){
		dfs(1);
		cout<<ansn<<endl;
	}	
}
