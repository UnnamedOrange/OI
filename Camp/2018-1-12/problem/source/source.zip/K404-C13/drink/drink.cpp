#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
using namespace std;

const int N=1000005;

struct node{
	int w,p;
	node(){}
	node(int w,int p):w(w),p(p){}
}p[N],now;
int n,x,ls,nx,ny;
bool tag;
double ans;
int a[N],nxt[N],pre[N];

bool cmp(node a,node b){
	return a.w<b.w;
}

void del(int k){
	nxt[pre[k]]=nxt[k];
	pre[nxt[k]]=pre[k];
}

int read(){
	int num=0; char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		num=num*10+c-'0';
		c=getchar();
	}
	return num;
}

int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int i,j,k;
	scanf("%d",&n);
	for (i=1;i<=n;i++) a[i]=read();
	for (i=1;i<=n;i++) p[i]=node(a[i],i);
	sort(p+1,p+1+n,cmp);
	for (i=1;i<=n;i++) nxt[i]=i+1,pre[i]=i-1;
	for (i=1;i<=n;i++){
		now=p[i]; ls=0; x=now.p;
		for (j=1;j<=25;j++){
			while (ls<j-1&&pre[x]) ls++,x=pre[x];
			k=1; ny=x;
			for (nx=x;nx<=now.p;nx=nxt[nx]){
				tag=1;
				for (;k<j;k++){
					ny=nxt[ny];
					if (ny>n||!ny){
						tag=0; break;
					}
				}
				if (!tag) break;
				ans+=(double)(nx-pre[nx])*(nxt[ny]-ny)*now.w/(1<<j);
				k--;
			}
		}
		del(now.p);
	}
	printf("%.6f\n",ans/((double)n*n));
	return 0;
}
