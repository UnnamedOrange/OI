#include <stdio.h>
#include <string.h>
#define maxn 100010
#define modn 998244353
int head[maxn],e[maxn*2][2],d[maxn],f[maxn],n,i,x,y,t=0;;
char c;
bool b[maxn];
double ans;
void addedge(int x,int y)
{
	e[++t][1]=y;
	e[t][0]=head[x];
	head[x]=t;
	e[++t][1]=x;
	e[t][0]=head[y];
	head[y]=t;
}
void dfs(int x,double p,int s)
{
	int i;
	if (p<1e-18) return;
	if (b[x] || !f[x]) s++;
	if (d[x]==1)
	{
		ans+=p*s;
		if (ans>modn) ans-=modn;
		return;
	}
	f[x]++;
	for (i=head[x];i>0;i=e[i][0])
		dfs(e[i][1],p/d[x],s);
	f[x]--;
}
int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	scanf("%d\n",&n);
	for (i=1;i<=n;i++)
	{
		c=getchar();
		b[i]=(c=='1');
	}
	for (i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		addedge(x,y);
		d[x]++;
		d[y]++;
	}
	dfs(1,1,0);
	printf("%d",(int)(ans+0.5));
	fclose(stdin);
	fclose(stdout);
}
