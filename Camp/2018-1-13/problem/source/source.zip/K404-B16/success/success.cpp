#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)
#define dep(i, s, t) for(i = s; i >= t; --i)

using namespace std;

typedef long long LL;
const int P = 1e9+7;
int S, t, n, m, M;
LL fac[1000010], inv[1000010];
LL ans;

LL lp(LL a, LL b) {
	LL c = 1;
	for(; b; b >>= 1, a = a * a % P)
		if(b & 1) c = c * a % P;
	return c;
}

LL C(int a, int b) {
	if(a < b) return 0;
	return fac[a] * inv[b] % P * inv[a-b] % P;
}

int main() {
	freopen("success.in", "r", stdin); freopen("success.out", "w", stdout);
	int i, s; LL tt;
	scanf("%d %d %d %d", &S, &t, &n, &m);
	M = max(S, m);
	fac[0] = 1; rep(i, 1, M) fac[i] = fac[i-1] * i % P;
	inv[M] = lp(fac[M], P-2); dep(i, M, 1) inv[i-1] = inv[i] * i % P;
	rep(s, m, S) {
		rep(i, 0, n) {
			tt = C(n, i) * C(s-1-i*t, m-1) % P; //printf("%lld\n", tt);
			if(i & 1) ans = (ans - tt + P) % P; else ans = (ans + tt) % P;
		}
	}
	printf("%lld\n", ans);
	return 0;
}
