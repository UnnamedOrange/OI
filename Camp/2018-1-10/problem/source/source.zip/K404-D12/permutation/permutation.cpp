#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define MAXN 100000
#define MOD 998244353
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int f[MAXN+5], fac[MAXN+5], efac[MAXN+5], s[MAXN+5], a[MAXN+5], n, cnt; bool book[MAXN+5];
inline int e(int s, int n=MOD-2){int a = 1; for(; n; n&1 ? a = 1ll*a*s%MOD : 0, s = 1ll*s*s%MOD, n >>= 1); return a;}
int main()
{
	freopen("permutation.in","r",stdin), freopen("permutation.out","w",stdout);
	n = read(); for(rint i = 1; i <= n; cnt += !!(a[i++]=read())); if(n&1) return puts("0"),0;
	for(rint i = 1; i <= n; a[i]?book[a[i]]=true:0, i++) if(a[i]<0||a[i]>n||book[a[i]]||a[i]==i) return puts("0"),0;
	if(!cnt)
	{
		fac[0] = 1; for(rint i = 1; i <= n; fac[i] = 1ll*i*fac[i-1]%MOD, i++);	
		efac[n] = e(fac[n]); for(rint i = n; i; efac[i-1] = 1ll*i*efac[i]%MOD, i--); f[0] = s[0] = 1;
		for(rint i = 2; i <= n; f[i] = 1ll*s[i-2]*fac[i-1]%MOD, s[i] = (s[i-2]+1ll*f[i]*efac[i])%MOD, i += 2); printf("%d\n",f[n]); return 0;
	}
	else if(n <= 8)
	{
		static int p[10], c[10], i, j, x, ans; for(i = 1; i <= n; p[i] = i, i++);
		do
		{
			for(i = 1; i <= n && (!a[i]||a[i]==p[i]); i++); if(i<=n) continue;
			for(memset(c+1,0,n<<2), i = 1; i <= n; i++)
				if(!c[i]){for(j = i, x = 0; !c[j]; c[j] = true, x ^= 1, j = p[j]); if(x) break;} ans += i>n;
		}while(next_permutation(p+1,p+n+1)); printf("%d\n",ans); return 0;
	}
	else if(cnt == 1)
	{
		fac[0] = 1; for(rint i = 1; i <= n; fac[i] = 1ll*i*fac[i-1]%MOD, i++);	
		efac[n] = e(fac[n]); for(rint i = n; i; efac[i-1] = 1ll*i*efac[i]%MOD, i--); f[0] = s[0] = 1;
		for(rint i = 2; i <= n; f[i] = 1ll*s[i-2]*fac[i-1]%MOD, s[i] = (s[i-2]+1ll*f[i]*efac[i])%MOD, i += 2); printf("%lld\n",1ll*f[n]*e(n-1)%MOD); return 0;
	}	return 0;
}
