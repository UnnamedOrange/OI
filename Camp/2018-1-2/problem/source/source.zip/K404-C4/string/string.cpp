#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
int t,n,f[110][110];
char s[110];
bool used[110][110];
int dp(int l,int r)
{
	if (used[l][r])
	{
		return f[l][r];
	}
	used[l][r]=true;
	bool flag=false;
	for (int i=l,j=r;i<j;i++,j--)
	{
		if (s[i]!=s[j])
		{
			flag=true;
			break;
		}
	}
	if (flag)
	{
		f[l][r]=1;
		return f[l][r];
	}
	int mn=1000000;
	for (int i=l;i<=r;i++)
	{
		for (int j=i+1;j<=r && j-i<=(r-l-2);j++)
		{
			int x=dp(i,j);
			if (x==-1 || x+1>=mn)
			{
				continue;
			}
			flag=false;
			for (int k=l,h=r;k<h;k++,h--)
			{
				if (k==i)
				{
					k=j+1;
				}
				if (h==j)
				{
					h=i-1;
				}
				if (k>=h)
				{
					break;
				}
				if (s[k]!=s[h])
				{
					flag=true;
					break;
				}
			}
			if (flag)
			{
				mn=x+1;
			}
		}
	}
	if (mn==1000000)
	{
		f[l][r]=-1;
	}
	else
	{
		f[l][r]=mn;
	}
	return f[l][r];
}
void solve()
{
	printf("%d\n",dp(0,n-1));
}
int dp1(int l,int r)
{
	if (used[l][r])
	{
		return f[l][r];
	}
	used[l][r]=true;
	bool flag=false;
	for (int i=l,j=r;i<j;i++,j--)
	{
		if (s[i]!=s[j])
		{
			flag=true;
			break;
		}
	}
	if (flag)
	{
		f[l][r]=1;
		return f[l][r];
	}
	int mn=1000000;
	for (int i=l+1;i<r-1;i++)
	{
		int x=dp1(l,i);
		int y=dp1(i+1,r);
		if (x==-1 || y==-1)
		{
			continue;
		}
		mn=min(mn,x+y);
	}
	if (mn==1000000)
	{
		f[l][r]=-1;
	}
	else
	{
		f[l][r]=mn;
	}
	return f[l][r];
}
void solve1()
{
	printf("%d\n",dp1(0,n-1));
}
void solve2()
{
	int mid=n/2;
	for (int k=mid-1;k>=mid-100;k--)
	{
		if (k<0)
		{
			break;
		}
		bool flag=false;
		for (int i=0,j=k;i<j;i++,j--)
		{
			if (s[i]!=s[j])
			{
				flag=true;
				break;
			}
		}
		if (!flag)
		{
			continue;
		}
		flag=false;
		for (int i=k+1,j=n-1;i<j;i++,j--)
		{
			if (s[i]!=s[j])
			{
				flag=true;
				break;
			}
		}
		if (flag)
		{
			puts("2");
			return;
		}
	}
	puts("-1");
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d",&n);
		scanf("%s",&s);
		bool flag=false;
		for (int i=0,j=n-1;i<j;i++,j--)
		{
			if (s[i]!=s[j])
			{
				flag=true;
				break;
			}
		}
		if (flag)
		{
			puts("1");
			continue;
		}
		for (int i=1;i<n;i++)
		{
			if (s[i]!=s[0])
			{
				flag=true;
				break;
			}
		}
		if (!flag)
		{
			puts("-1");
			continue;
		}
		memset(used,false,sizeof(used));
		memset(f,-1,sizeof(f));
		if (n<=10)
		{
			solve();
		}
		else if (n<=100)
		{
			solve1();
		}
		else
		{
			solve2();
		}
	}
	return 0;
}
/*
7
13
ababababababa
7
abcdcba
3
xxx
4
abba
17
abcbabcbabcbabcba
13
abacadadacaba
5
abcba
*/
