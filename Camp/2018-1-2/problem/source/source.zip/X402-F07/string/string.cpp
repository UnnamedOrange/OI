#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005,inf=0x3f3f3f3f;
char s[maxn<<1],ss[maxn];
int n,l[maxn<<1],dp[maxn];
void manacher(){
	int r=0,p=0;
	memset(l,0,sizeof(l));
	REP(i,1,2*n){
		if(i<=r)l[i]=min(r-i,l[2*p-i]);
		while(s[i+l[i]+1]==s[i-l[i]-1])l[i]++;
		if(chkmax(r,i+l[i]))p=i;
	}
}
bool check(int a,int b){
	return l[a+b-1]<b-a;
}
void work(){
	n=read(),scanf("%s",ss+1);
	REP(i,1,n)
		s[2*i-1]=ss[i],s[2*i]='$';
	manacher();
	if(n<=100){
		memset(dp,inf,sizeof(dp));
		dp[0]=0;
		REP(i,2,n)
			REP(j,0,i-2)
				if(l[i+j]+i+j<2*i-1)
					chkmin(dp[i],dp[j]+1);
		int ans=dp[n]==inf?-1:dp[n];
		write(ans,'\n');
	}else{
		if(l[n]!=n-1)puts("1");
		else{
			bool res=0;
			REP(i,2,n-2)
				if(check(1,i)&&check(i+1,n))res=1;
			puts(res?"2":"-1");
		}
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	int T=read();
	while(T--)work();
	return 0;
}
