#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 1500007;
const int MAXS = MAXN * 4;
const int MAX = 2097152;
const int MOD = 1e9 + 9;
const int BUFSIZE = 20000007;

inline int add ( int x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
	return x;
}

inline void addv ( int &x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
}

inline int dec ( int x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
	return x;
}

inline void decv ( int &x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
}



class stT
{
public:
	stT ()
	{
		fill ( tag, tag+MAXS, 1 );
	}
	
	inline void mul2 ( int l, int r, int now = 1, int ll = 1, int rr = MAX )
	{
		if ( ll >= l && rr <= r ) addv ( tag[now], tag[now] ), addv ( data[now], data[now] );
		else if ( rr < l || ll > r ) return;
		else{
			int mid = ( ll + rr ) >> 1;
			downtag ( now );
			mul2 ( l, r, now<<1, ll, mid );
			mul2 ( l, r, now<<1|1, mid+1, rr );
			data[now] = add ( data[now<<1], data[now<<1|1] );
		}
	}
	
	inline void upd ( int p, int x, int now = 1, int ll = 1, int rr = MAX )
	{
		if ( ll == rr ) addv ( data[now], x );
		else{
			int mid = ( ll + rr ) >> 1;
			downtag ( now );
			if ( p <= mid ) upd ( p, x, now<<1, ll, mid );
			else upd ( p, x, now<<1|1, mid+1, rr );
			data[now] = add ( data[now<<1], data[now<<1|1] );
		}
	}
	
	inline int query ( int l, int r, int now = 1, int ll = 1, int rr = MAX )
	{
		if ( ll >= l && rr <= r ) return data[now];
		else if ( rr < l || ll > r ) return 0;
		else{
			int mid = ( ll + rr ) >> 1;
			downtag ( now );
			return add ( query ( l, r, now<<1, ll, mid ), query ( l, r, now<<1|1, mid+1, rr ) );
		}
	}
	
private:
	inline void downtag ( int now )
	{
		if ( tag[now] ^ 1 ){
			tag[now<<1] = SC ( LL, tag[now<<1] ) * tag[now] % MOD;
			tag[now<<1|1] = SC ( LL, tag[now<<1|1] ) * tag[now] % MOD;
			data[now<<1] = SC ( LL, data[now<<1] ) * tag[now] % MOD;
			data[now<<1|1] = SC ( LL, data[now<<1|1] ) * tag[now] % MOD;
			tag[now] = 1;
		}
	}
	
	int tag[MAXS];
	int data[MAXS];
}st;



struct iT
{
	inline bool operator < ( const iT &a ) const
	{
		return r < a.r;
	}
	
	int l, r;
}it[MAXN];

int n, m;
int ax[MAXN];
int a[MAXN];
int pre[MAXN];
int dp[MAXN];
int pw2[MAXN];
char buf[BUFSIZE], *pb;
int mp[MAXN], km, tto[MAXN];



void init ();
void input ();
void work ();

int read ()
{
	int num = 0;
	char ch;
	for ( ch = *(pb++); ch < '0' || ch > '9'; ch = *(pb++) );
	for ( ; ch >= '0' && ch <= '9'; ch = *(pb++) ) num = num * 10 + ch - '0';
	return num;
}



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "xmasinterval" );
	
	fread ( buf, 1, BUFSIZE, stdin );
	pb = buf;
	
	pw2[0] = 1;
	lp ( i, 1, MAXN ) pw2[i] = add ( pw2[i-1], pw2[i-1] );
}

void input ()
{
	n = read (), m = read ();
	lpi ( i, 1, n ) it[i].l = read (), it[i].r = read ();
	lpi ( i, 1, m ) ax[i] = read ();
}

void work ()
{
	lpi ( i, 1, n ) mp[++km] = it[i].l, mp[++km] = it[i].r;
	lpi ( i, 1, m ) mp[++km] = ax[i];
	sort ( mp+1, mp+1+km );
	lpi ( i, 1, km ) tto[i] = i;
	lpi ( i, 1, n ) it[i].l = tto[lower_bound(mp+1,mp+1+km,it[i].l)-mp]++;
	lpi ( i, 1, m ) ++a[tto[lower_bound(mp+1,mp+1+km,ax[i])-mp]++];
	lpi ( i, 1, n ) it[i].r = tto[lower_bound(mp+1,mp+1+km,it[i].r)-mp]++;
	int kc = km;
	
	sort ( it+1, it+1+n );
	
	int nl = 0;
	lpi ( i, 1, kc+1 ){
		pre[i] = nl;
		if ( a[i] ) nl = i;
	}
	
//	lpi ( i, 1, kc ) cerr << a[i] << " ";
//	cerr << endl;
//	lpi ( i, 1, kc ) cerr << pre[i] << " ";
//	cerr << endl;
	
	dp[0] = 1;
	st.upd ( 1, 1 );
	int cl = 1;
	lpi ( i, 1, kc ){
		if ( cl <= n && it[cl].r == i ){
//			cerr << it[cl].l << " " << it[cl].r << " " << pre[it[cl].l] << endl;
			dp[i] = st.query ( pre[it[cl].l]+1, i+1 );
			st.mul2 ( 1, pre[it[cl].l] );
			st.upd ( i+1, dp[i] );
			++cl;
		}
	}
	
//	lpi ( i, 1, kc ) cerr << dp[i] << " ";
//	cerr << endl;
	
	int ans = 0;
	lpi ( i, pre[kc+1], kc ) addv ( ans, dp[i] );
	printf ( "%d\n", ans );
}
