#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define N 30010
using namespace std;
int n,ans,tot;
int w[N],r[N],fa[N],head[N];
bool v[N];
struct Map
{
    int r,next;
} line[N<<1];
void add(int x,int y)
{
    tot++;
    line[tot].r=y;
    line[tot].next=head[x];
    head[x]=tot;
}
void pre(int x,int f)
{
    fa[x]=f;
    for(int i=head[x]; i; i=line[i].next)
    {
        int rx=line[i].r;
        if(rx==f)
            continue;
        pre(rx,x);
    }
}
void dfs(int sum,int step)
{
    if(step==n+1)
        ans=max(ans,sum);
    else for(int i=1; i<=n; i++)
            if(!v[i]&&v[fa[i]])
            {
                v[i]=true;
                dfs(sum+w[i]*step,step+1);
                v[i]=false;
            }
}
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("xmastree2.in","r",stdin);
    freopen("xmastree2.out","w",stdout);
    n=read();
    for(int i=1; i<n; i++)
    {
        int u=read(),v=read();
        add(u,v),add(v,u);
    }
    for(int i=1; i<=n; i++)
        w[i]=read(),r[i]=read();
    v[0]=true;
    for(int i=1; i<=n; i++)
        if(r[i])
        {
            pre(i,0);
            dfs(0,1);
        }
    printf("%d",ans);
    return 0;
}
