#include<cstdio>
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
int n,W,p,q,ans;
int a[1001][11];
int w[1001],r[1001],x[1001],y[1001];
inline int fabs(int x){
	return x>=0?x:(-x);
}
inline int min(int a,int b){
	return a<b?a:b;
}
inline void dfs(int now,int sum){
	if(now==n+1){
		for(register int i=1;i<=q;++i){
			if(r[i]==0&&w[x[i]]>w[y[i]])return;
			if(r[i]==1&&w[x[i]]!=w[y[i]])return;
			if(r[i]==2&&w[x[i]]>=w[y[i]])return;
		}
		int ret=sum;
		for(register int i=1;i<=p;++i)
			ret+=a[i][4]*fabs(w[a[i][1]]-w[a[i][2]])
				+a[i][5]*fabs(w[a[i][2]]-w[a[i][3]])
				+a[i][6]*fabs(w[a[i][3]]-w[a[i][1]])
				+a[i][7]*(w[a[i][1]]-w[a[i][2]])
				+a[i][8]*(w[a[i][2]]-w[a[i][3]])
				+a[i][9]*(w[a[i][3]]-w[a[i][1]]);
		ans=min(ans,ret);
		return ;
	}
	w[now]=W;
	dfs(now+1,sum+W);
	w[now]=-W;
	dfs(now+1,sum-W);
	return;
}
int T;
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d%d%d%d",&n,&W,&p,&q);
		ans=(1<<30);
		FOR(i,1,p)FOR(j,1,9)scanf("%d",&a[i][j]);
		FOR(i,1,q)scanf("%d%d%d",&x[i],&y[i],&r[i]);
		dfs(1,0);
		printf("%d\n",ans);
	}
	return 0;
}
