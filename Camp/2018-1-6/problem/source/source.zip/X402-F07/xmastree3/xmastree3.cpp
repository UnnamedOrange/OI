#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=55,mod=998244353;
int n,m;
int fa[maxn],dep[maxn];
bool vis[maxn];
struct data{int to,id;};
vector<data>E[maxn];
int g[maxn],p[maxn][maxn];
struct edge{int u,v;}e[maxn];
int find_fa(int x){
	return x==g[x]?x:g[x]=find_fa(g[x]);
}
bool check(){
	memset(vis,0,sizeof(vis));
	static queue<int>Q;
	while(!Q.empty())Q.pop();
	REP(i,1,n)if(fa[i]==0)Q.push(i);
	while(!Q.empty()){
		int u=Q.front();Q.pop();
		REP(i,1,n)if(fa[i]==u){
			REP(j,1,n)g[j]=j;
			REP(j,1,n-1)
				if(!vis[j])
					g[find_fa(e[j].v)]=find_fa(e[j].u);
			if(find_fa(u)!=find_fa(i))return 0;
			vis[p[u][i]]=1;
			Q.push(i);
		}
	}
	REP(i,1,n-1)if(!vis[i])return 0;
	return 1;
}
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
}
int dp[maxn][maxn];
int DFS(int u,int dep){
	if(dep>m)return 0;
	int &res=dp[u][dep];
	if(res>=0)return res;
	res=0;
	REP(j,dep,m){
		int tmp=1;
		REP(i,1,n)
			if(fa[i]==u)
				tmp=1ll*tmp*DFS(i,j+1)%mod;
		add(res,tmp);
	}
	return res;
}
int ans=0;
void DP(){
	memset(dp,-1,sizeof(dp));
	REP(i,1,n)if(fa[i]==0)add(ans,DFS(i,1));
}
void dfs(int step){
	if(step>n){
		if(check())DP();
		return;
	}
	if(fa[step]==0)return dfs(step+1);
	REP(i,1,n)if(i!=step)fa[step]=i,dfs(step+1),fa[step]=-1;
}
int find(int u,int fa,int t){
	if(u==t)return 1;
	REP(i,0,E[u].size()-1){
		int v=E[u][i].to;
		if(v==fa)continue;
		else if(find(v,u,t))return E[u][i].id;
	}return 0;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n-1){
		int u=read(),v=read();
		e[i]=(edge){u,v};
		E[u].pb((data){v,i}),E[v].pb((data){u,i});
	}
	REP(i,1,n)
		REP(j,1,n)
			p[i][j]=find(i,0,j);
	REP(i,1,n){
		memset(fa,-1,sizeof(fa));
		fa[i]=0,dfs(1);
	}write(ans,'\n');
	return 0;
}
