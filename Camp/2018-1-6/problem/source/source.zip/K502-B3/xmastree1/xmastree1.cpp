#include <stdio.h>
#include <string.h>

const int maxn=200001;
long long int c[maxn],first[maxn],nxt[maxn],to[maxn],size[maxn],dfn[maxn],v[maxn],vis[maxn];
long long int n,q,t,cnt,num,lastans;
 
inline long long int read()
{
    char ch;
    bool flag=false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void clear()
{
	memset(first,-1,sizeof(first));
	long long int i;
	for(i=0;i<=200000;i++)
		size[i]=1;
	cnt=0;
	num=1;
	lastans=0;
}

void add(long long int ui,long long int vi)
{
	nxt[cnt]=first[ui];
	first[ui]=cnt;
	to[cnt]=vi;
	cnt++;
}

void dfs(long long int x,long long int fa)
{
	dfn[x]=num++;
	v[dfn[x]]=c[x];
	long long int i;
	for(i=first[x];i!=-1;i=nxt[i])
	{
		if(to[i]==fa)
			continue;
		dfs(to[i],x);
		size[x]+=size[to[i]];
	}
} 

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	clear(); 
	n=read(),q=read(),t=read();
	long long int i;
	for(i=1;i<=n;i++)
		c[i]=read();
	for(i=1;i<=n-1;i++)
	{
		long long int ui=read(),vi=read();
		add(ui,vi);
		add(vi,ui);
	}
	dfs(1,0);
	for(i=1;i<=q;i++)
	{
		long long int temp=read();
		if(temp==1)
		{
			if(t==1)
			{
				memset(vis,0,sizeof(vis));
				long long int u=read(),l=read(),r=read();
				u=u xor lastans,l=l xor lastans,r=r xor lastans;
				long long int j,ans=0;
				for(j=dfn[u];j<=dfn[u]+size[u]-1;j++)
				{
					if(v[j]>=l&&v[j]<=r&&!vis[v[j]])
					{
						ans++;
						vis[v[j]]=1;
					}
				}
				printf("%lld\n",ans);
				lastans=ans;
			}
			else
			{
				memset(vis,0,sizeof(vis));
				long long int u=read(),l=read(),r=read();
				long long int j,ans=0;
				for(j=dfn[u];j<=dfn[u]+size[u]-1;j++)
				{
					if(v[j]>=l&&v[j]<=r&&!vis[v[j]])
					{
						ans++;
						vis[v[j]]=1;
					}
				}
				printf("%lld\n",ans);
			}
		}
		else
		{
			long long int u=read(),wc=read();
			if(t==1)
				u=u xor lastans,wc=wc xor lastans;
			v[dfn[u]]=wc;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
