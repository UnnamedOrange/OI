#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;

#define ll long long int

const int maxn=4001;
ll a[maxn],b[maxn],c[maxn],vis[maxn];
ll n,m,k,h,hash=0,ans=0;
 
inline ll read()
{
    char ch;
    bool flag=false;
    ll r=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        r*=10;
        r+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        r*=10;
        r+=ch-'0';
    }
    if(flag)
	{
        r=-r;
    }
    return r; 
}

bool check()
{
	ll i,t=1;
	if(h<=n)
	{ 
		for(i=1;i<=n;i++)
		{
			if(a[i]==c[t])
				t++;
			if(t==h+1)
				return 0;
		}
	}
	t=1;
	if(h<=m)
	{
		for(i=1;i<=m;i++)
		{
			if(b[i]==c[t])
				t++;
			if(t==h+1)
				return 0;
		}
	}
	return 1;
}

void dfs(ll x)
{
	if(x==h+1)
	{
		if(check())
			hash=1;
		return;
	}
	c[x]=1;
	dfs(x+1);
	if(hash==1)
		return;
	c[x]=2;
	dfs(x+1);
}

int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	n=read(),m=read(),k=read();
	ll i;
	for(i=1;i<=n;i++)
		a[i]=read();
	for(i=1;i<=m;i++)
		b[i]=read();
	if(n<=18&&m<=18&&k==2)
	{
		for(i=1;i<=18;i++)
		{
			h=i;
			dfs(1);
			if(hash==1)
			{
				printf("%lld",i);
				break;
			}  
		}
		fclose(stdin);
		fclose(stdout);
		return 0; 
	}
	ll sum=0,temp=(ll)max(n,m);
	for(i=1;i<=temp;i++)
	{
		if(!vis[a[i]]&&a[i]!=0)
		{
			vis[a[i]]=1;
			sum++;
		}
		if(!vis[b[i]]&&b[i]!=0)
		{
			vis[b[i]]=1;
			sum++;
		}
		if(sum==k)
		{
			memset(vis,0,sizeof(vis));
			ans++;
			sum=0;	
		}
	}
	printf("%lld",ans+1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
