#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const LL maxn = 1005, modd = 1e9+7 ;
LL S[maxn][maxn] ;
void init() {
	LL i, j ;
	S[0][0] = 1 ;
	for ( i = 1 ; i < maxn ; i ++ ) {
		S[i][0] = 0 ;
		for ( j = 1 ; j <= i ; j ++ )
			S[i][j] = (S[i - 1][j] + S[i - 1][j - 1])%modd ;
	}
}
LL f[maxn][maxn] ;
LL n, m, tot, sum, lim ;
LL F ( LL x, LL y ) {
	if (x < y) return 0 ;
	if (x <= 0) return 0 ;
	if (f[x][y] >= 0) return f[x][y] ;
	if (y == 1) {
		if (x && x <= lim) return 1 ;
		else return 0 ;
	}
	LL i, rec = 0 ;
	for ( i = 1 ; i <= lim && i < x ; i ++ )
		(rec += F(x-i, y-1)) %= modd ;
	return f[x][y] = rec ;
}
int main() {
	freopen ( "success.in", "r", stdin ) ;
	freopen ( "success.out", "w", stdout ) ;
	LL i, j, ans = 0 ;
	init() ;
	memset ( f, -1, sizeof f ) ;
	cin >> sum >> lim >> n >> m ;
	for ( i = 1 ; i <= sum ; i ++ )
		for ( j = min(n*lim, i-1) ; j >= n ; j -- ) {
			(ans += (LL)F(j, n)*S[i - j][m - n]%modd) %= modd ;
		}
	cout << ans << endl ;
	return 0 ;
}
