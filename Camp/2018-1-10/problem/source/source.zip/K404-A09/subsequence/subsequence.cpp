#include<bits/stdc++.h>
using namespace std;
#define N 4100
int a[N],b[N],c[N],n,m,k,li[N];
int check(int len) {
	memset(li,0,sizeof(li));
	int flag2=1;
	for(int i=1;i<=n;i++) {
		if(i+len-1>n) break;
		int flag=1;
		for(int j=1;j<=len;j++) {
			if(a[i+j-1]!=c[j]) {
				flag=0;
				break;
			}
		}
		if(flag) {
			flag2=0;
			if(i>1) li[a[i-1]]=1;
			if(i+len-1<=n) li[a[i+len-1]]=1;
		}
	}
	for(int i=1;i<=m;i++) {
		if(i+len-1>m) break;
		int flag=1;
		for(int j=1;j<=len;j++) {
			if(b[i+j-1]!=c[j]) {
				flag=0;
				break;
			}
		}
		if(flag) {
			flag2=0;
			if(i>1) li[b[i-1]]=1;
			if(i+len-1<=m) li[b[i+len-1]]=1;
		}
	}
	for(int i=1;i<=k;i++) if(li[i]==0) return 1;
	return 0;
}
int main() {
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++) {
		scanf("%d",&a[i]);
	}
	for(int j=1;j<=m;j++) {
		scanf("%d",&b[j]);
	}
	int ans=max(n,m)+1;
	for(int i=1;i<=n;i++) li[a[i]]=1;
	for(int i=1;i<=m;i++) li[b[i]]=1;
	for(int i=1;i<=k;i++) if(li[i]==0) ans=1;
	for(int i=1;i<=n;i++) {
		for(int j=i;j<=n;j++) {
//			for(int k=i;k<=j;k++) c[k-i+1]=a[k];
			c[j-i+1]=a[j];
			if(check(j-i+1)) ans=min(ans,j-i+1+1);
		}
	}
	for(int i=1;i<=m;i++) {
		for(int j=i;j<=m;j++) {
//			for(int k=i;k<=j;k++) c[k-i+1]=b[k];
			c[j-i+1]=b[j];
			if(check(j-i+1)) ans=min(ans,j-i+1+1);
		}
	}
	printf("%d",ans);
}
