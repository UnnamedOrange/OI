while true; do
	./gen
	./bf
	./stone
	if diff stone.out stone.ans; then
		echo "correct answer"
	else
		echo "wrong answer"
		exit
	fi
done
