#include<bits/stdc++.h>
#define maxi 1000000
using namespace std;
long long f[maxi+10],m[maxi+10],t,n,ansn;
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	m[1]=1;
	for (int i=1;i<=maxi;i++){
		f[i]++;
		for (int j=i+i;j<=maxi;j+=i){
			f[j]++;
			m[j]-=m[i];
		}
	}
	for (int j=1;j<=maxi;j++)f[j]=f[j]*f[j];
	for (int i=2;i<=maxi;i++){
		f[i]+=f[i-1];
	}
	cin>>t;
	while (t--){
		ansn=0;
		cin>>n;
		for (int i=1;i<=n;i++){
			ansn+=m[i]*f[n/i];
		}
		cout<<ansn<<endl;
	}
}
