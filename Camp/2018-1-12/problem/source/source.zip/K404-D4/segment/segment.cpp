#include <iostream>
#include <cstdio>
using namespace std;
int n, m, k;
int main () {
	freopen ("segment.in", "r", stdin);
	freopen ("segment.out", "w", stdout);
	scanf ("%d%d%d", &n, &m, &k);
	printf ("0\n");
	return 0;
}
