#include <bits/stdc++.h>

typedef long long int int64;
static const int64 mod = 1000000007;
int n,a,b,p,q,r;
int64 pow2[100009];
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	pow2[0] = 1;
	for(int i = 1;i <= 100000;++i) pow2[i] = (pow2[i-1] * 2) % mod;
	if(a <= b) {
		for(int i = 0;i < n;++i) {
			int v;
			scanf("%d",&v);v %= a + b;
			if(v < a) ++p;
			else if(v >= a && v < b) ++q;
			else ++r;
		}
		if(r == 0) {
			printf("%lld %lld %lld %lld\n",
				(pow2[n] - pow2[n - q] + mod) % mod,
				0LL,
				0LL,
				pow2[p + r]
			);
		} else {
			printf("%lld %lld %lld %lld\n",
				(pow2[n] - pow2[n - q] + mod) % mod,
				0LL,
				pow2[p + r - 1],
				pow2[p + r - 1]
			);
		}
	} else {
		for(int i = 0;i < n;++i) {
			int v;
			scanf("%d",&v);v %= a + b;
			if(v < b) ++p;
			else if(v >= b && v < a) ++q;
			else ++r;
		}
		if(r == 0) {
			printf("%lld %lld %lld %lld\n",
				0LL,
				(pow2[n] - pow2[n - q] + mod) % mod,
				0LL,
				pow2[p + r]
			);
		} else {
			printf("%lld %lld %lld %lld\n",
				0LL,
				(pow2[n] - pow2[n - q] + mod) % mod,
				pow2[p + r - 1],
				pow2[p + r - 1]
			);
		}
	}
}
