#include<cstdio>
#include<queue>
using namespace std;
const int maxn=100005,inf=2147483647;
int head[maxn],dis[maxn],num;
int color[maxn];
bool inq[maxn];
char s[maxn];
queue<int> q;
struct cp{
	int to,val,next;
}edge[maxn];
inline void add(int u,int v){
	edge[++num].to=v;
	edge[num].val=1;
	edge[num].next=head[u];
	head[u]=num;
}
int max(int a,int b){
	return a>b?a:b;
}
void spfa(){
	dis[1]=0;
	inq[1]=1;
	q.push(1);
	while(!q.empty()){
		int u=q.front();
		q.pop();
		inq[u]=0;
		for(int i=head[u];i;i=edge[i].next){
			int v=edge[i].to;
			if(dis[v]>dis[u]+edge[i].val){
				dis[v]=dis[u]+edge[i].val;
				if(!inq[v]){
					q.push(v);
					inq[v]=1;
				}
			}
		}
	}
}
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	int n,m,x,y,ans=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) dis[i]=inf;
	scanf("%s",s);
	for(int i=0;i<n;i++){
		color[i]=s[i]-'0';
	}
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);
	}
	spfa();
	for(int i=1;i<=n;i++) if(dis[i]!=inf) ans=max(ans,dis[i]);
	printf("%d\n",ans+1);
	return 0;
}
