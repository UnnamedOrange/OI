#include <bits/stdc++.h>

namespace Force {

const int MAXN = 2000 + 9;

std::bitset<MAXN> vis[MAXN];

int n, m;

inline void solve() {
    std::cin >> n >> m;
    for (register int i = 1, u, v; i <= m; i++) {
        std::cin >> u >> v;
        vis[u].set(u);
        vis[v].set(v);
        vis[u].set(v);
    }
    for (register int k = 1; k <= n; k++)
        for (register int i = 1; i <= n; i++)
            if (vis[i].test(k)) vis[i] |= vis[k];
    /*for (register int i = 1; i <= n; i++) {
        for (register int j = 1; j <= n; j++) {
            std::cerr << vis[i][j] << ' ';
        }
        std::cerr << std::endl;
    }*/
    register int ans = 0;
    std::set<int> set;
    for (register int i = 1; i <= n; i++) {
        if (vis[i].test(i)) set.insert(set.end(), i);
    }
    /*for (std::set<int>::iterator it = set.begin(); it != set.end(); ++it) {
        std::cerr << *it << ' ';
    }
    std::cerr << std::endl;*/
    while (!set.empty()) {
        register int u = *set.begin();
        set.erase(set.begin());
        for (register int i = 1; i <= n; i++) {
            if (!vis[u].test(i) && set.count(i)) {
                vis[u] |= vis[i];
                set.erase(i);
            }
        }
        ans++;
    }
    std::cout << ans;
}
}

int main() {
    freopen("bomb.in", "r", stdin);
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);
    Force::solve();
    return 0;
}