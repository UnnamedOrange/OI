#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#define pb push_back
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int N=1000010;
struct node{
	int to,next;
};node edge[N*2];
int graph[N],tot;
int vis[N],dfn[N],low[N],stack[N],top,dfn_cnt;
int col[N],cnt,c[N],dp[N],in[N];
int q[N],h,t;
int ex[N],ey[N];
int ans;int n,m;

void addedge(int i,int x,int y){
	edge[i].to=y;edge[i].next=graph[x];graph[x]=i;
}

void tarjan(int x){
	int i,y,tmp;
	dfn[x]=low[x]=++dfn_cnt;stack[++top]=x;vis[x]=1;
	for(i=graph[x];i;i=edge[i].next){
		y=edge[i].to;
		if(!vis[y]){tarjan(y);low[x]=min(low[x],low[y]);}
		else if(vis[y]==1)	{low[x]=min(low[x],dfn[y]);}
	}
	if(dfn[x]==low[x]){
		cnt++;
		do{
			tmp=stack[top--];
			vis[tmp]=2;
			col[tmp]=cnt;
			c[cnt]++;
		}while(tmp!=x);
	}
}

int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int i,x,y;
	scanf("%d%d",&n,&m);
	rep(i,1,m){
		scanf("%d%d",&ex[i],&ey[i]);
		tot++;addedge(tot,ex[i],ey[i]);
	}
	rep(i,1,n)	if(!vis[i])	tarjan(i);
	tot=0;memset(graph,0,sizeof(graph));
	rep(i,1,m){
		x=col[ex[i]];y=col[ey[i]];
		if(x!=y){tot++;addedge(tot,x,y);in[y]++;}
	}
	rep(i,1,cnt)	if(!in[i])	q[++t]=i;
	while(h<t){
		x=q[++h];dp[x]+=c[x];ans=max(ans,dp[x]);
		for(i=graph[x];i;i=edge[i].next){
			y=edge[i].to;
			dp[y]=max(dp[y],dp[x]);	
			in[y]--;
			if(!in[y])	q[++t]=y;
		}
	}
	printf("%d\n",ans);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
