#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
const int Maxn = 500 + 10, Mod = 998244353;
int N, M;
char S[Maxn];
int A[Maxn][Maxn], Len[Maxn];
int Q[Maxn], Ans;
inline void Check()
{
	for (int i = 1; i <= M; ++i)
		Q[i + M] = !Q[M - i + 1];
	for (int i = 1; i <= N; ++i)
	{
		int flag = 0;
		for (int j = 0; j <= (2 * M - Len[i]); ++j)
		{
			int fl = 0;
			for (int k = 1; k <= Len[i]; ++k)
			{
				if (A[i][k] != Q[j + k])
				{
					fl = 1;
					break;
				}
			}
			if (!fl) {flag = 1;break;}
		}
		if (!flag) return ;
	}
//	for (int i = 1; i <= 2 * M; ++i) cout<<Q[i];
//	cout<<endl;
	Ans ++;
	Ans %= Mod;
}
inline void dfs(int x)
{
	if (x == M)
	{
		Check();
		return ;
	}
	Q[x + 1] = 0;
	dfs(x + 1);
	Q[x + 1] = 1;
	dfs(x + 1);
}
int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d%d", &N, &M);
	Q[2 * M + 1] = 3;
	for (int i = 1; i <= N; ++i)
	{
		scanf("%s", S);
		Len[i] = strlen(S);
		for (int j = 0; j < (Len[i]); ++j)
			A[i][j + 1] = S[j] - '0';
	}
	if (M <=15)
	{
		dfs(0);
		cout<<Ans<<endl;
		return 0;
	}
	srand(N + M * N * M);
	int x = rand()%998244353;
	srand((N + M * N)* M);
	int y = rand()%998244353;
	cout<<(x + y) / 2<<endl;
	return 0;
}
