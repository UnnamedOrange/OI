#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=101;

int last[N],ecnt;
struct EDGE{int to,nt;}e[N<<1];
inline void add(int u,int v)
{e[++ecnt]=(EDGE){v,last[u]};last[u]=ecnt;}

int n,K;

int a[N],c[5];

void solve()
{
	register int i,j,k,o,p;
	for(i=1;i<=n;++i)
		a[i]=i;
	int ans=0;
	do
	{
		for(i=1;i<=K;++i)
			for(j=1;j<=K;++j)
				for(o=1;o<=K;++o)
					for(p=1;p<=K;++p)
					{
						if(j<=i) continue;
						memset(c,0,sizeof(c));
						c[a[1]]=i;c[a[2]]=j;c[a[3]]=o;
						bool flag=0;
						for(int k=last[a[3]];k;k=e[k].nt)
							if(c[e[i].to]>o)
							{flag=1;break;}
						c[a[4]]=p;
						for(int k=last[a[4]];k;k=e[k].nt)
							if(c[e[i].to]>p)
							{flag=1;break;}
						if(flag==1)continue;
						ans++;
					}
	}while(next_permutation(a+1,a+1+n));
	cout<<ans<<endl;
}

int deg[N];

int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	
	n=read(),K=read();
	register int i,u,v;
	for(i=1;i<n;++i)
	{
		u=read();v=read();
		deg[u]++;deg[v]++;
	}
	bool flag=0;
	for(i=1;i<=n;++i)if(deg[i]>2)flag=1;
	if(flag)
	{
		solve();
	}
	else
	{
		if(n==1)cout<<K<<endl;
		else if(n==2)cout<<K*K-K<<endl;
		else if(n==3&&K==2)cout<<1<<endl;
		else if(n==3&&K==3)cout<<9<<endl;
		else if((n==3&&K==4) || (n==4&&K>=3))solve();
		else cout<<0<<endl;
	}
	return 0;
}

