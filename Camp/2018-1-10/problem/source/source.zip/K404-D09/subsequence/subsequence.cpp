#include <cstdio>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

namespace OUTBUFFER {
	char buf[1048576];
	int pt;
	inline void putch(register char ch) { buf[pt++] = ch; }
	inline void flush() { if(pt) fwrite(buf,sizeof(char),pt,stdout), pt = 0; }
	inline void check() { if(pt > 1000000) flush(); }
}

template <class T>
inline void put_int(register T x) {
	char temp[23];
	register int top;
	if(x == 0) return OUTBUFFER::putch('0');
	if(x < 0) OUTBUFFER::putch('-'), x = -x;
	for(top = 0; x; temp[++top] = x % 10, x /= 10);
	do OUTBUFFER::putch(temp[top] ^ '0'); while(--top);
	OUTBUFFER::check();
}

struct OUT {
	OUT() { OUTBUFFER::pt = 0; }
	~OUT() { OUTBUFFER::flush(); }
	const OUT &operator << (const char *str) const {
		while(*str) OUTBUFFER::putch(*str++);
		OUTBUFFER::check();
		return *this;
	}
	const OUT &operator << (register char ch) const {
		return OUTBUFFER::putch(ch), *this;
	}
	const OUT &operator << (register int x) const {
		return put_int<int>(x), *this;
	}
	const OUT &operator << (register long long x) const {
		return put_int<long long>(x), *this;
	}
} out;

int N, M, K, A[4005], B[4005], C[4005];

inline void init() {
	N = get_int(), M = get_int(), K = get_int();
	for(int i = 1; i <= N; ++i) A[i] = get_int();
	for(int i = 1; i <= M; ++i) B[i] = get_int();
}

inline bool check(int len, int x) {
	int pta = 0, ptb = 0;
	for(int i = 1; i <= len; ++i)
		C[i] = 1 + (x & (1 << (i - 1)) ? 1 : 0);
	for(int i = 1; i <= len; ++i) {
		for(++pta; (pta <= N && A[pta] != C[i]); ++pta);
		for(++ptb; (ptb <= M && B[ptb] != C[i]); ++ptb);
		if(pta > N && ptb > M) return true;
	}
	return false;
}

inline void solve() {
	if(K == 2) {
		for(int len = 1; len <= 31; ++len) {
			int u = 1 << len;
			for(int x = 0; x < u; ++x)
				if(check(len, x)) {
					out <<len;
					return;
				}
		}
	}
	out <<32;
}

#define PROBLEM_NAME	"subsequence"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	init();
	solve();
	return 0;
}
