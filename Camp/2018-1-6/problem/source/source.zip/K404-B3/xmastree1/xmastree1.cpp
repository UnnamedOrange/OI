#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define ll long long
#define N 200010
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int n,Q,tp,lans;
int c[N];
int lj[N],fro[N],to[N],cnt;
void add(int a,int b){fro[++cnt]=lj[a];to[cnt]=b;lj[a]=cnt;}
int L[N],R[N],tim,pos[N];
void dfs(int x,int f)
{
	L[x]=++tim;pos[tim]=x;
	for(int i=lj[x];i;i=fro[i]) if(to[i]!=f) dfs(to[i],x);
	R[x]=tim;
}
namespace sub1
{
	#define M 5010
	int col[M];
	bool p[M];
	int ask(int x,int l,int r)
	{
		memset(p,0,sizeof(p));
		int sum=0;
		for(int i=L[x];i<=R[x];i++)
		{
			if(col[i]<l||col[i]>r) continue;
			if(!p[col[i]]) sum++,p[col[i]]=1;
		}
		return sum;
	}
	void Main()
	{
		int op,l,r,x,C;
		for(int i=1;i<=n;i++) col[L[i]]=c[i];
		while(Q--)
		{
			op=rd();
			if(op==1)
			{
				x=rd();l=rd();r=rd();
				if(tp) x^=lans,l^=lans,r^=lans; 
				lans=ask(x,l,r);
				printf("%d\n",lans);
			} 
			else 
			{
				x=rd();C=rd();
				if(tp) x^=lans,C^=lans;
				col[L[x]]=C;
			}
		}
	}
};
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=rd();Q=rd();tp=rd();
	for(int i=1;i<=n;i++) c[i]=rd();
	for(int i=1,x,y;i<n;i++)
	{
		x=rd();y=rd();
		add(x,y);add(y,x);
	}
	dfs(1,0);
	if(n<=5000) sub1::Main();
	return 0;
}