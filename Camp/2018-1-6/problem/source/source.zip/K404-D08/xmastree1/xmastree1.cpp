#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=5010;
int n,q,opt,ft[N],tot,fa[N],vis[N],c[N];
struct edge{int t,n;}E[N<<1];
void dfs(int u,int f=0){
	fa[u]=f;
	go(u) if (v!=f) dfs(v,u);
}
void get(int u,int f){
	vis[c[u]]=1;
	go(u) if (v!=f) get(v,u);
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&opt);
	rep(i,1,n) scanf("%d",c+i);
	rep(i,2,n){
		int x,y;
		scanf("%d%d",&x,&y);
		E[++tot]=(edge){y,ft[x]},ft[x]=tot;
		E[++tot]=(edge){x,ft[y]},ft[y]=tot;
	}
	dfs(1);
	int lastans=0;
	while (q--){
		int op,u,l,r,k;
		scanf("%d",&op);
		if (op==1){
			scanf("%d%d%d",&u,&l,&r);
			u^=opt*lastans;
			l^=opt*lastans;
			r^=opt*lastans;
			memset(vis,0,sizeof(vis));
			get(u,fa[u]);
			lastans=0;
			rep(i,l,r) lastans+=vis[i];
			printf("%d\n",lastans);
		} else {
			scanf("%d%d",&u,&k);
			u^=opt*lastans;
			k^=opt*lastans;
			c[u]=k;
		}
	}
	return 0;
}

