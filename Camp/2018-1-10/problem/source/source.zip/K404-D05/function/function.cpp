#include<bits/stdc++.h>
#define FE "function"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c))(c=='-'?p=-1:0),c=getchar();
	while(isdigit(c))x=(x<<3)+(x<<1)+(c^'0'),c=getchar();
	return x*p;
}
inline void putint(int x){
	static int buf[20];
	int tot=0;
	x<0?putchar('-'),x=-x:0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
#define LEN 10000002
int not_prime[LEN+5],expm[LEN+5],pm[LEN+5],f[LEN+5];
int prime[LEN+1],tot=0;
inline void pre(){
	not_prime[1]=expm[1]=f[1]=1,pm[1]=0;
	for(int i=2;i<LEN;++i){
		if(!not_prime[i]){
			prime[++tot]=i;
			expm[i]=1;
			pm[i]=1;
			f[i]=3;
		}
		for(int j=1;j<=tot&&i*prime[j]<LEN;++j){
			not_prime[i*prime[j]]=1;
			if(i%prime[j]==0){
				expm[i*prime[j]]=expm[i];
				pm[i*prime[j]]=pm[i]+1;
				f[i*prime[j]]=f[expm[i]]*(2*pm[i*prime[j]]+1);
				break;
			}
			expm[i*prime[j]]=i;
			pm[i*prime[j]]=1;
			f[i*prime[j]]=f[i]*f[prime[j]];
		}
	}
//	for(int i=1;i<=100;++i){
//		cout<<i<<" "<<f[i]<<endl;
//	}
	for(int i=2;i<LEN;++i){
		f[i]+=f[i-1];
	}
//	for(int i=1;i<=100;++i){
//		//cout<<prime[i]<<endl;
//		cout<<i<<" "<<miu[i]/*<<" "<<pm[i]<<" "<<expm[i]*/<<" "<<o0[i]<<endl;
//	}
}
inline void work(){
	int n=getint();
	cout<<f[n]<<"\n";
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	pre();
	int t=getint();
	while(t--){
		work();
	}
	return 0;
}
