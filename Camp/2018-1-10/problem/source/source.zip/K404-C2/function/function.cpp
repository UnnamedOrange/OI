#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<cctype>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
typedef long long LL;
const int N=1000010;
bool vis[N];
int prm[N/10];
LL n,d[N],mu1[N],mu2[N],a[N],b[N],lim;

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void prepare()
{
	lim=1000000;
	d[1]=1,mu1[1]=1;
	rep(i,2,lim)
	{
		if(!vis[i]) prm[++*prm]=i,d[i]=2,mu1[i]=-1,a[i]=i,b[i]=1;
		rep(j,1,*prm)
		{
			if(i*prm[j]>lim) break;
			vis[i*prm[j]]=1;
			if(i%prm[j])
				d[i*prm[j]]=d[i]*2,mu1[i*prm[j]]=-mu1[i],a[i*prm[j]]=prm[j],b[i*prm[j]]=1;
			else
			{
				d[i*prm[j]]=d[i]/(b[i]+1)*(b[i]+2),b[i*prm[j]]=b[i]+1;
				break;
			}
		}
	}
	rep(i,1,lim) mu2[i]=mu2[i-1]+mu1[i]*mu1[i],mu1[i]+=mu1[i-1],d[i]=d[i]+d[i-1];
}

LL getd(LL x)
{
	if(x<=lim) return d[x];
	LL rt=0,i=1,j,m;
	for(; i<=x; i=j+1)
	{
		m=x/i,j=x/m;
		rt+=(j-i+1)*m;
	}
	return rt;
}

LL getmu2(LL x)
{
	if(x<=lim) return mu2[x];
	LL m=cbrt(x),rt=0,sq=sqrt(x);
	rep(i,1,m) rt+=(mu1[i]-mu1[i-1])*x/(i*i);
	for(LL i=m+1,j,t=x/(i*i); t; --t,i=j+1)
		j=sqrt(x/t),rt+=(mu1[j]-mu1[i-1])*t;
	return rt;
}
	
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	prepare();
	for(int T=getint(); T--; )
	{
		n=getint();
		LL i=1,j,lst=0,nxt,m,ans=0;
		for(; i<=n; i=j+1,lst=nxt)
		{
			m=n/i,j=n/m,nxt=getmu2(j);
			ans+=(nxt-lst)*getd(m);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
