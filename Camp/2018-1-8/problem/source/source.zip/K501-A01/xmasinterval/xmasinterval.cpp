#include<stdio.h>
#include<cctype>
#include<algorithm>
#include<iostream>
using namespace std;
#define Mod (1000000009)
typedef long long LL;
#define rep(i, a, b) for(int i = (a), i##_end_ = (b); i <= i##_end_; ++i)
int read(){
	int x = 0;
	char ch = getchar();
	while(!isdigit(ch)) ch = getchar();
	while(isdigit(ch)) {
		x = (x << 3) + (x << 1) + (ch - 48);
		ch = getchar();
	}
	return x;
}
#define Maxn 500009
#define inf (1 << 30)
struct node{
	int fi, se;
}l[Maxn];
int n, m, a[Maxn];
int ans, vis[Maxn];
int check() {
	rep(i, 1, m){
		int flag = 0;
		rep(j, 1, n)
			if(vis[j]) 
				if(l[j].fi <= a[i] && a[i] <= l[j].se){
					flag = 1;
					break;
				}
		if(!flag) return 0;
	}
	return 1;
}
void dfs(int a){
	if(a == n + 1){
		(ans += check()) %= Mod;
		return ;
	}
	vis[a] = 1;
	dfs(a + 1);
	vis[a] = 0;
	dfs(a + 1);
}
int main(){
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	n = read(), m = read();
	rep(i, 1, n) 
		l[i] = {read(), read()};
	rep(i, 1, m) a[i] = read();
	dfs(1);
	printf("%d\n", ans);
	return 0;
}
