#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 100005;
int n, m, T, ans, col[N], st[N], ed[N], seq[N], idx;
int ecnt, adj[N], nxt[2 * N], go[2 * N];

void add(int u, int v){
	go[++ecnt] = v;
	nxt[ecnt] = adj[u];
	adj[u] = ecnt;
}
void dfs(int u, int pre){
	seq[++idx] = col[u], st[u] = idx;
	for(int e = adj[u], v; e; e = nxt[e])
		if((v = go[e]) != pre)
			dfs(v, u);
	ed[u] = idx;
}
void solve1(){
	static bool vis[5005];
	int op, u, l, r, c;
	while(m--){
		memset(vis, 0, sizeof(vis));
		read(op);
		if(op == 1){
			read(u), read(l), read(r);
			if(T) u ^= ans, l ^= ans, r ^= ans;
			ans = 0;
			for(int i = st[u]; i <= ed[u]; i++)
				if(!vis[seq[i]] && seq[i] >= l && seq[i] <= r)
					ans++, vis[seq[i]] = 1;
			write(ans), enter;
		}
		else{
			read(u), read(c);
			if(T) u ^= ans, c ^= ans;
			seq[st[u]] = c;
		}
	}
}

int main(){

	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	
	read(n), read(m), read(T);
	for(int i = 1; i <= n; i++) read(col[i]);
	for(int i = 1, u, v; i < n; i++)
		read(u), read(v), add(u, v), add(v, u);
	dfs(1, 0);
	if(n <= 5000 && m <= 5000) solve1();
	
	return 0;
}
