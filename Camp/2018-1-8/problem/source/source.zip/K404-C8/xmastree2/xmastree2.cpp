#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=30005;
typedef long long ll;

int n,hd[N],pr[N*2],to[N*2],tot,w[N],r[N];
void addedge(int u,int v) {to[++tot]=v;pr[tot]=hd[u];hd[u]=tot;}

int ans[1005],sum[1005];
int g[1005][1005],sz[1005],dp[1005][1005],pre[1005][1005],rt;

void dfs(int u,int fa)
{
	sz[u]=0;
	sum[u]=w[u];
	ans[u]=0;
	
	for (int v,i=hd[u];i;i=pr[i]) if ((v=to[i])!=fa) 
	{
		dfs(v,u);
		sum[u]+=sum[v];
		ans[u]+=ans[v];
		
		dp[0][0]=0;
		for (int x=0;x<=sz[u];x++)
			for (int y=0;y<=sz[v];y++) 
			{
				if (!x&&!y) continue; 
				dp[x][y]=-1e9;
				
				if (x) if (dp[x-1][y]+y*w[g[u][x]]>dp[x][y]) 
				dp[x][y]=dp[x-1][y]+y*w[g[u][x]],pre[x][y]=0;
				
				if (y) if (dp[x][y-1]+x*w[g[v][y]]>dp[x][y])
				dp[x][y]=dp[x][y-1]+x*w[g[v][y]],pre[x][y]=1;
			}
		ans[u]+=dp[sz[u]][sz[v]];
				
		int x=sz[u],y=sz[v];
		sz[u]+=sz[v];
		
		
		for (int j=sz[u];j>=1;j--) 
		{
			if (!pre[x][y]) g[u][j]=g[u][x--];
			else g[u][j]=g[v][y--];
		}
		
	}

	ans[u]+=sum[u];
	sz[u]++;
	for (int i=sz[u];i>=2;i--) g[u][i]=g[u][i-1];g[u][1]=u;
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	for (int u,v,i=1;i<n;i++) 
	{
		scanf("%d%d",&u,&v);
		addedge(u,v);
		addedge(v,u);
	}
	for (int i=1;i<=n;i++) scanf("%d%d",&w[i],&r[i]);
	
	int ANS=0;
	for (int i=1;i<=n;i++) if (r[i]) dfs(i,0),ANS=max(ANS,ans[i]);
	
	printf("%d\n",ANS);
	return 0;
}
/*
5
1 2
1 3
2 4
3 5
4 1
3 1
4 1
3 1
1 1

5
1 2
1 5
1 4
1 3
1 1 
2 1
3 1 
4 1 
5 1
*/

