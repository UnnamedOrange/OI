#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#include<vector>
#define N 100010
vector<int>t[N];
int n,q,c[N],p[N],ans,g[N],b[N],e[N],num,_;
void dfs(int x)
{
	num++;
	g[num]=c[x];
	b[x]=num;
	fr(i,0,t[x].size()-1)
		if(!b[t[x][i]])
			dfs(t[x][i]);
	e[x]=num;
}
int main()
{
	freopen("xmastree1.out","w",stdout);
	freopen("xmastree1.in","r",stdin);
	n=read();
	q=read();
	_=read();
	fr(i,1,n)
		c[i]=read();
	fr(i,1,n-1)
	{
		int u=read(),v=read();
		t[u].push_back(v);
		t[v].push_back(u);
	}
	dfs(1);
	while(q--)
	{
		int opt=read();
		if(opt&1)
		{
			int u=read();
			int l=read();
			int r=read();
			if(_)
			{
				u^=ans;
				l^=ans;
				r^=ans;
			}
			ans=0;
			fr(i,b[u],e[u])
				if(g[i]>=l&&g[i]<=r&&p[g[i]]!=q+1)
				{
					p[g[i]]=q+1;
					ans++;
				}
			printf("%d\n",ans);
		}
		else
		{
			int pos=read();
			int m=read();
			if(_)
			{
				pos^=ans;
				m^=ans;
			}
			g[b[pos]]=m;
		}
	}
	return 0;
}