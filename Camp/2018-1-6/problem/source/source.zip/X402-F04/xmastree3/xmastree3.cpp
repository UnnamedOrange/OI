//2018-1-6
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (20+5)
const int P = 998244353;

LL n, k, u, v;
struct node{
	LL data, next;
}e[N];

LL place, head[N], ti, use[N], tag[N], ans;

void build(LL u, LL v){
	e[++place].data=v; e[place].next=head[u]; head[u]=place;
	e[++place].data=u; e[place].next=head[v]; head[v]=place;
}

LL dfs(LL x, LL now){
	LL pl=1, pr=1, q[11];
	q[1] = x; ti++; use[x] = ti;

	while (pl <= pr){
		x=q[pl++];
		for(LL ed=head[x]; ed!=0; ed=e[ed].next){
			if(tag[e[ed].data] || use[e[ed].data]==ti) continue;
			q[++pr]=e[ed].data; use[e[ed].data]=ti;
		}
	}

	LL tot = 0;
	For(i, 1, pr){
		tag[q[i]] = true;
		LL sum = 1;

		for(LL ed=head[q[i]]; ed!=0; ed=e[ed].next){
			if(tag[e[ed].data]) continue;
			LL num = 0;
			For(i, now+1, k) num = (num+dfs(e[ed].data, i)) % P;
			sum = sum * num % P;
		}
		tot = (tot + sum) % P;
		tag[q[i]]=false;
	}

	return tot;
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	
	scanf("%lld%lld", &n, &k);
	For(i, 1, n-1){
		scanf("%lld%lld", &u, &v);
		build(u, v);
	}

	For(i, 1, k) ans = (ans + dfs(1, i)) % P;
	printf("%lld\n",ans);
	
	return 0;
}

