#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define in(x) freopen(x,"r",stdin)
#define out(x) freopen(x,"w",stdout)
#define LL long long
#define mod 1000000007
#define NN 1010000+10
using namespace std;
struct node{
	int cnt;
	int ans;
}dp[NN];
struct XiYuanSiShiJie{
	int low,up;
}a[NN]={0};
int main(){
	in("schooldays.in");
	out("schooldays.out");
	int n;
	scanf("%d",&n);
	memset(dp,-2,sizeof dp);
	for(int i=1;i<=n;++i){
		scanf("%d%d",&a[i].low,&a[i].up);
	}
	dp[0].cnt=1;
	dp[0].ans=0;
	for(int i=0;i<n;++i){
		int low=0;
		int up=1000000000;
		for(int j=i+1;j<=n;++j){
			low=max(low,a[j].low);
			up=min(up,a[j].up);
			if(j-i>up){
				break;
			}
			if(low<=j-i){
				if(dp[j].ans<dp[i].ans+1){
					dp[j].ans=dp[i].ans+1;
					dp[j].cnt=dp[i].cnt;
				}
				else if(dp[j].ans==dp[i].ans+1){
					dp[j].cnt+=dp[i].cnt;
					if(dp[j].cnt>=mod)dp[j].cnt-=mod;
				}
			}
		}
	}
	if(dp[n].ans<0)printf("-1");
	else printf("%d %d",dp[n].ans,dp[n].cnt);
}
		
		

