#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int read()
{
	char ch=getchar();int x=0,f=1;
	while(ch<'0'||ch>'9')  ch=getchar();
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int n,m,p,q,w,ans;
struct data
{
	int x,y,r;
}h[100005];
int a[100005],b[100005],c[100005],d[100005],e[100005],f[100005],g[100005],x[100005],y[100005],z[100005];
int val[100005];
bool check()
{
	for(int i=1;i<=q;i++)
	{
		if(h[i].r==0)
		{
			if(val[h[i].x]>val[h[i].y]) return 0;
		}
		else if(h[i].r==1)
		{
			if(val[h[i].x]!=val[h[i].y]) return 0;
		}
		else
		{
			if(val[h[i].x]>=val[h[i].y]) return 0;
		}
	}
	return 1;
}
void dfs(int xx)
{
	val[xx]=w;
	if(xx==n)
	{
		if(check())
		{
			int temp=0;
			for(int i=1;i<=p;i++)
			{
				temp+=a[i]*abs(val[x[i]]-val[y[i]])+b[i]*abs(val[y[i]]-val[z[i]])+
				c[i]*abs(val[z[i]]-val[x[i]])+d[i]*(val[x[i]]-val[y[i]])+
				e[i]*(val[y[i]]-val[z[i]])+f[i]*(val[z[i]]-val[x[i]]);
			}
			for(int i=1;i<=n;i++)
			temp+=val[i];
			ans=min(ans,temp);
		}
	}
	else
	{
		dfs(xx+1);
	}
	val[xx]=-w;
	if(xx==n)
	{
		if(check())
		{
			int temp=0;
			for(int i=1;i<=p;i++)
			{
				temp+=a[i]*abs(val[x[i]]-val[y[i]])+b[i]*abs(val[y[i]]-val[z[i]])+
				c[i]*abs(val[z[i]]-val[x[i]])+d[i]*(val[x[i]]-val[y[i]])+
				e[i]*(val[y[i]]-val[z[i]])+f[i]*(val[z[i]]-val[x[i]]);
			}
			for(int i=1;i<=n;i++)
			temp+=val[i];
			ans=min(ans,temp);
		}
	}
	else
	{
		dfs(xx+1);
	}
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T=read();
	while(T--)
	{
		n=read();w=read();p=read();q=read();
		for(int i=1;i<=p;i++)
		{
			scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		}
		for(int i=1;i<=q;i++)
		{
			scanf("%d%d%d",&h[i].x,&h[i].y,&h[i].r);
		}
		ans=2000000000;
		dfs(1);
		cout<<ans<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
1
3 1 1 1
1 2 3 1 1 1 1 1 1
1 2 2
*/
