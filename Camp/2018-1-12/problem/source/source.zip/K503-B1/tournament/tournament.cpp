#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
const int mod=998244353;
int T,opt,n,m,mp[50][50],vis[50],a[50],ha[50];
int i,j,k,fla,ans,anss,r,s;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void dfs(int x,int dep){
	int i;
	if (fla==1) return;
	vis[x]=1;
	for (i=1;i<=n;i++){
		if (mp[x][i]==1){
			if (vis[i]==0){
				dfs(i,dep+1);
			}
			else{
				if (i==s){
					if (dep==m){
						fla=1;
					}
				}
			}
		}
	}
	vis[x]=0;
}
void check(){
	int i;
	fla=0;
	memset(vis,0,sizeof(vis));
	for (i=1;i<=n;i++){
		s=i; dfs(i,1);
	}
	ans=ans+fla;
}
void work(int x,int y){
	if ((x==n)&&(y==n+1)){
		check();
		return;
	}
	if (x==y){
		mp[x][y]=0;
		work(x,y+1);
		return;
	}
	if (mp[y][x]==-1){
		mp[x][y]=1;
		if (y==n) work(x+1,1);
		else work(x,y+1);
		mp[x][y]=0;
		if (y==n) work(x+1,1);
		else work(x,y+1);
	}
	else{
		mp[x][y]=1^mp[y][x];
		if (y==n) work(x+1,1);
		else work(x,y+1);
	}
	mp[x][y]=-1;
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	n=read(); m=read(); ans=0;
	if (m==3){
		ans=1;
		for (i=1;i<=n*(n-1)/2;i++){
			ans=(ans*2)%mod;
		}
		anss=1;
		for (i=1;i<=n;i++){
			anss=(anss*i)%mod;
		}
		ans=(ans-anss+mod)%mod;
		printf("%d\n",ans);
		return 0;
	}
	memset(mp,-1,sizeof(mp));
	work(1,1);
	printf("%d\n",ans);
	return 0;
}
