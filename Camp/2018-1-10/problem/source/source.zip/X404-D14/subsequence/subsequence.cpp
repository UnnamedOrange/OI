#include<cstdio>
#include<iostream>
using namespace std;
int n,m,k;
int a[20],b[20];
int c[20],len;
bool p=0;
bool pan()
{
	int cnt=1;
	for (int i=1;i<=n;i++)
	{
		if (c[cnt]==a[i]) cnt++;
		if (cnt>len) return 0;
	}
	cnt=1;
	for (int i=1;i<=m;i++)
	{
		if (c[cnt]==b[i]) cnt++;
		if (cnt>len) return 0;
	}
	return 1;
}
void dfs(int deep)
{
	if (p) return;
	if (deep==len+1) {p=pan();return;}
	c[deep]=1;
	dfs(deep+1);
	if (p) return;
	c[deep]=0;
	dfs(deep+1);
	if (p) return;
}
int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++)
		scanf("%d",&a[i]),a[i]--;
	for (int i=1;i<=m;i++)
		scanf("%d",&b[i]),b[i]--;
	for (len=1;len<=max(n,m)+1;len++)
	{
		dfs(1);
		if (p) {printf("%d\n",len);return 0;}
	}
}
