#include<bits/stdc++.h>
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')c=getchar(),f=-1;
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

const int N=30;
int T,n,dep,a[N],ans[50];

bool dfs(int step,int last)
{
	if(step==dep)
	{
		for(int i=1;i<=n;i++)
			if(a[i]!=i)return false;
		return true;
	}
	int tmp=0;
	for(int i=1;i<=n;i++)if(abs(a[i+1]-a[i])>1)tmp++;
	if(step+tmp>dep)return false;
	for(int i=2;i<=n;i++)
	{
		if(i==last)continue;
		reverse(a+1,a+i+1);//ans[step+1]=i;
		if(dfs(step+1,i))return true;
		reverse(a+1,a+i+1);
	}
	return false;
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	T=getint();
	while(T--)
	{
		n=getint();
		for(int i=1;i<=n;i++)a[i]=getint();
		a[n+1]=n+1;
		dep=0;
		for(int i=1;i<=n;i++)if(abs(a[i+1]-a[i])>1)dep++;
		while(!dfs(0,0))dep++;
		printf("%d\n",dep);
		//for(int i=1;i<=dep;i++)cout<<ans[i]<<' ';
	}
	return 0;
}
