#include <cstdio>
#include <algorithm>
using namespace std;
#define Mod 998244353
#define N 100050
int ni[N],fa[N],sz[N],f[N],g[N][2],n,m,q,i,p[N];
bool vis[N];
int gf(int x)
{
	return fa[x]==x?x:fa[x]=gf(fa[x]);
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	ni[1]=1;
	for (i=2;i<=n;i++) ni[i]=-1LL*(Mod/i)*ni[Mod%i]%Mod;
	for (i=1;i<=n;i++) scanf("%d",&p[i]);
	for (i=1;i<=n;i++) fa[i]=i,sz[i]=1;
	for (i=1;i<=n;i++) if (p[i]){
		int f1=gf(i),f2=gf(p[i]);
		if (f1!=f2){
			if (sz[f1]>sz[f2]) swap(f1,f2);
			fa[f1]=f2;sz[f2]+=sz[f1];
		}else{
			if (sz[f1]&1) return puts("0"),0;
			vis[f1]=true;
		}
	}for (i=1;i<=n;i++) if (fa[i]==i&&!vis[i]){
		if (sz[i]&1) m++;else q++;
	}
	f[0]=1;g[0][0]=1;g[0][1]=0;
	for (i=1;i<=m;i++){
		f[i]=1LL*ni[i]*g[i-1][i&1]%Mod;
		g[i][i&1]=(g[i-1][i&1]+f[i])%Mod;
		g[i][(i&1)^1]=g[i-1][(i&1)^1];
	}
	for (i=1;i<=m+q;i++) f[m]=1LL*f[m]*i%Mod;
	printf("%d\n",(f[m]+Mod)%Mod);
	return 0;
}
