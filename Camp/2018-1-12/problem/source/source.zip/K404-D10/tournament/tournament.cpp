//© 2018 Jazengm/ZengXiangru, AllRightsReserved

#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int p=998244353, mxn=1<<17;

int n, k, frac[mxn];

In void init()
{
    inc(frac[0]=1, i, n+1)
        frac[i]=(ll)frac[i-1]*i%p;
}

In int dP(int a, int b)
{
    Rg int r=1;
    for(; b; a=(ll)a*a%p, b>>=1)
        b&1? r=(ll)r*a%p: 0;
    Re r;
}

int flag; bool a[1<<7][1<<7];

void DFS(int x, int pre)
{
    St bool vis[1<<7];
    St int fst;
    if(x==n+1)
    {
        flag|=a[pre][fst];
        Re;
    }
    inc(1, i, n+1)
        if(!vis[i] && (!pre || a[pre][i]))
        {
            if(!pre) fst=i;
            vis[i]=1;
            DFS(x+1, i);
            vis[i]=0;
        }
}

int main()
{
    freopen("tournament.in", "r", stdin);
    freopen("tournament.out", "w", stdout);
    scanf("%d%d", &n, &k);
    init();
    if(k==3)
    {
        printf("%d\n", (dP(2, (ll)n*(n-1)/2%(p-1))-frac[n]+p)%p);
        Re 0;
    }
    if(k==n)
    {
        Rg int ans=0;
        inc(0, i_, 1<<n*(n-1)/2)
        {
            Rg int tot=0;
            inc(1, i, n)
                inc(i+1, j, n+1)
                    a[i][j]=i_>>tot & 1, a[j][i]=!a[i][j], ++tot;
            flag=0;
            DFS(1, 0);
            ans+=flag;
        }
        printf("%d\n", ans);
    }
    Re 0;
}
