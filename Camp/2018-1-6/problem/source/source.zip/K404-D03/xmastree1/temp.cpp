#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=100100;

int last[N],ecnt;
struct EDGE{int to,nt;}e[N<<1];
inline void add(int u,int v)
{e[++ecnt]=(EDGE){v,last[u]};last[u]=ecnt;}

int n,Q;

int dfn[N],size[N],tim;
void dfs(int u)
{
	dfn[u]=++tim;
	for(int i=last[u],v;i;i=e[i].nt)
		if(!dfn[v=e[i].to])
			dfs(v);
}

void solve_1()
{
	
}

void solve_2()
{
	register 
}

int main()
{
	n=read()+1;
	Q=read();int T=read();
	register int i,j;
	for(i=2;i<=n;++i) C[i]=read();
	for(i=2;i<n;++i)
		u=read()+1,v=read()+1,
		add(u,v),add(v,u);
	dfs(2);
	for(i=2;i<=n;++i)
		for(j=i;j<=n;j+=(j&(-j)))
			insert();
	
	T ? solve_1() : solve_2();
	return 0;
}


