#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<set>
using namespace std;
const int N=1000005;

int read()
{
	int ans;char ch;
	while ((ch=getchar())<'0'||ch>'9') ;ans=ch-'0';
	while ((ch=getchar())>='0'&&ch<='9') ans=ans*10+ch-'0';
	return ans;
}

int n,w[N],t[N];
int tmp[65],L,R;
double p[40],ans;
bool cmp(int x,int y) 
{
	if (w[x]!=w[y]) return w[x]>w[y];
	return x<y;
}

int lc[N*2],rc[N*2],sz[N*2],tot=1;
void build(int u,int l,int r) 
{
	if (l==r) 
	{
		if (l==0||l==n+1) sz[u]=1;
		return ;
	}
	int mid=(l+r)>>1;
	build(lc[u]=++tot,l,mid);
	build(rc[u]=++tot,mid+1,r);
	sz[u]=sz[lc[u]]+sz[rc[u]];
}
void work(int u,int l,int r,int p) 
{
	int mid=(l+r)>>1;
	if (r<p) 
	{
		if (!L||!sz[u]) return ;
		if (l==r) {tmp[--L]=l;return ;}
		work(rc[u],mid+1,r,p);
		work(lc[u],l,mid,p);
		return ;
	}
	if (p<l) 
	{
		if (R==60||!sz[u]) return ;
		if (l==r) {tmp[++R]=l;return ;}
		work(lc[u],l,mid,p);
		work(rc[u],mid+1,r,p);
		return ;
	}
	sz[u]++;
	if (l==r) return ;
	if (p<=mid) work(lc[u],l,mid,p),work(rc[u],mid+1,r,p);
	else work(rc[u],mid+1,r,p),work(lc[u],l,mid,p);
}


int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	
	scanf("%d",&n);
	for (int i=1;i<=n;i++) w[i]=read(),t[i]=i;
	sort(t+1,t+n+1,cmp);

	p[0]=1;for (int i=1;i<=35;i++) p[i]=p[i-1]/2;
	
	build(1,0,n+1);
	for (int i=1;i<=n;i++) 
	{
		int a=t[i];

		tmp[L=R=30]=a;
		work(1,0,n+1,a);

		for (int x=L;x<30;x++)
			for (int y=31;(y-x-1)<=30&&y<=R;y++) 
				ans+=(double)w[a]*(tmp[x+1]-tmp[x])*p[y-x-1]*(tmp[y]-tmp[y-1]);
	}
	printf("%.10lf\n",ans/((double)n*n));
	return 0;
}
