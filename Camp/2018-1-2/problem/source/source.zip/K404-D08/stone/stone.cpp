#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=100010,P=1000000007;
int n,a,b,flag,w[N];
LL pw[N],sum,s1,s2,sa,sb,c1,c2,c3,c4;
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d",&n);
	scanf("%d%d",&a,&b);
	if (a>b) swap(a,b),flag=1;
	rep(i,1,n){
		scanf("%d",w+i);
		w[i]%=a+b;
		if (w[i]<a) ++c1; else
		if (w[i]/a==w[i]/b) ++c2; else
		if (w[i]/a>w[i]/b){
			++c3;
			if (w[i]<b) ++c4;
		}
	}
	pw[0]=1;
	rep(i,1,n) pw[i]=pw[i-1]*2%P;
	// even
	sum=pw[c2+c3-1];
	s2=pw[c2-1];
	sa=(sa+sum-s2)%P;
	// odd
	s1=(pw[c2-1]+pw[c2-1]*c3)%P;
	sa=(sa+sum-s1)%P;
	LL tp=pw[c2-1]*c4;
	s1=(s1-tp)%P;
	sa=(sa+tp)%P;
	sa=sa*pw[c1]%P;
	s1=s1*pw[c1]%P;
	s2=s2*pw[c1]%P;
	sa=(sa+P)%P;
	s1=(s1+P)%P;
	s2=(s2+P)%P;
	if (flag) swap(sa,sb);
	printf("%lld %lld %lld %lld\n",sa,sb,s1,s2);
	return 0;
}

