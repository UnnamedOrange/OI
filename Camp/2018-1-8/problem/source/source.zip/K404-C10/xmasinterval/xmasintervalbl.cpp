#include <cstdio>
using namespace std;
#define N 500050
int a[N],l[N],r[N],n,m,i,j,mask;
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval1.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (i=0;i<n;i++) scanf("%d%d",&l[i],&r[i]);
	for (i=1;i<=m;i++) scanf("%d",&a[i]);int ans=0;
	for (mask=1;mask<(1<<n);mask++){
		for (i=1;i<=m;i++){
			for (j=0;j<n;j++) if (mask&(1<<j)&&l[j]<=a[i]&&r[j]>=a[i]) break;
			if (j==n) break;
		}if (i==m+1) ans++;
	}printf("%d\n",ans);
	return 0;
}
