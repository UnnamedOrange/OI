#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=30;
int a[maxn];
int n;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int calc(){
	int cnt=0;
	for(register int i=1;i<n;i++)
		if(a[i]!=a[i+1]+1 && a[i]!=a[i+1]-1)cnt++;
	return cnt;
}
int dfs(int step){
	int sum=calc();
	if(step<sum)return 0;
	int flag=0;
	if(!step){
		if(sum==0 && a[1]==1)return 1;
		else return 0;
	}
	for(register int i=2;i<=n;i++){
		for(register int j=1;j<=i/2;j++)swap(a[j],a[i-j+1]);
		if(dfs(step-1))return 1;
		for(register int j=1;j<=i/2;j++)swap(a[j],a[i-j+1]);
	}
	return 0;
}
int main(){
	int i,j,k,m,T;
#ifndef ONLINE_JUDGE
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
#endif
	T=read();
	while(T--){
		n=read();
		for(i=1;i<=n;i++)a[i]=read();
		int minans=calc();
		for(i=minans;;i++){
			if(dfs(i)){
				printf("%d\n",i);
				break;
			}
		}
	}
	return 0;
}
