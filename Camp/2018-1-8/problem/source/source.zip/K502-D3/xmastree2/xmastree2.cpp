#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>
#include <vector>
#define ele long long
using namespace std;
#define maxn 15
struct edge{
	ele v;
	edge *nxt;
}ep[maxn<<1],*ecnt;
ele n,ans,now,w[maxn],r[maxn];
bool flag[maxn];
edge *h[maxn];
set<ele> S;
inline void addedge(ele u,ele v){
	edge *p=ecnt++;
	p->v=v; p->nxt=h[u];
	h[u]=p;
}
void dfs(ele i){
	if (i==n){
		ans=max(ans,now);
		return;
	}
	vector<ele> v;
	for (set<ele>::iterator it=S.begin(); it!=S.end(); ++it) v.push_back(*it);
	for (int j=0; j<v.size(); ++j){
		flag[v[j]]=true;
		S.erase(v[j]);
		now+=w[v[j]]*(i+1);
		for (edge *k=h[v[j]]; k; k=k->nxt)
			if (!flag[k->v]) S.insert(k->v);
		dfs(i+1);
		flag[v[j]]=false;
		S.insert(v[j]);
		now-=w[v[j]]*(i+1);
		for (edge *k=h[v[j]]; k; k=k->nxt)
			if (!flag[k->v]) S.erase(k->v);
	}
}
int main(){
	freopen("xmastree2.in","r",stdin); freopen("xmastree2.out","w",stdout);
	scanf("%lld",&n);
	ecnt=ep; memset(h,0,sizeof(h));
	for (int i=0; i<n-1; ++i){
		ele u,v;
		scanf("%lld%lld",&u,&v); --u,--v;
		addedge(u,v); addedge(v,u);
	}
	for (int i=0; i<n; ++i) scanf("%lld%lld",w+i,r+i);
	ans=now=0;
	for (int i=0; i<n; ++i)
		if (r[i]) S.insert(i),dfs(0),S.erase(i);
	printf("%lld\n",ans);
	return 0;
}