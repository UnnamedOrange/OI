#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=100+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("string.in","r",stdin);
		freopen("string.out","w",stdout);
	#endif
}
int n,m;
char s[10][100+5];
int len[10];
const int mo=998244353;
void input()
{
	n=read<int>();m=read<int>();
	For(i,1,n)scanf("%s",s[i]+1),len[i]=strlen(s[i]+1);
}
struct A
{
	int ans,v;
	char a[N];
	bool flag;
	bool check()
	{
		For(i,m+1,m*2)a[i]=a[m*2-i+1]=='0'?'1':'0';
		//puts(a+1);
		For(i,1,n)
		{
			flag=0;
			For(j,1,m*2-len[i]+1)
			{
				for(v=1;v<=len[i];++v)if(s[i][v]!=a[j+v-1])break;
				if(v==len[i]+1){flag=1;break;}
			}
			if(!flag)return 0;
		}
		return 1;
	}
	void dfs(int dep)
	{
		if(dep==m+1)
		{
			if(check())
			{
				ans++;
				//puts(a+1);
				if(ans>=mo)ans-=mo;
			}
			return;
		}
		a[dep]='1';dfs(dep+1);
		a[dep]='0';dfs(dep+1);
	}
	void solve()
	{
		ans=0;
		dfs(1);
		printf("%d\n",ans);
	}
}sub1;
struct B
{
	int power(ll x,ll y)
	{
		ll res=1;
		for(;y;x=x*x%mo,y>>=1)if(y&1)res=res*x%mo;
		return res;
	}
	bool check(int pos)
	{
		int l=pos,r=pos+1;
		while(l>=1&&r<=len[1]&&s[1][l]!=s[1][r])l--,r++;
		if(l==0||r==len[1]+1)return 1;
		return 0; 
	}
	void solve()
	{
		puts("0");
	}
}sub2;
void work()
{
	if(m<=25)sub1.solve(); 
	else if(n==1)sub2.solve();
	//sub1.solve();sub2.solve();
}
int main()
{
	file();
	input();
	work();
	return 0;
}
