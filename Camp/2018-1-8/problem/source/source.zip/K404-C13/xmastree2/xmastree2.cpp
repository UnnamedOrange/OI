#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
#include<queue>
#define ll long long
using namespace std;

const int N=30005;
const int M=35;

struct E{
	int to,next;
}mem[N<<1];
struct node{
	int sz,s;
	double p;
	node(){}
	node(int sz,int s,double p):sz(sz),s(s),p(p){}
}a[N];
int n,num,cnt,x,y,t;
ll ans,sum;
int head[N],w[N],tag[N],sz[N],s[N],f[N];
bool vis1[M];
ll dp[N];

void add(int x,int y){
	num++;
	mem[num].to=y; mem[num].next=head[x];
	head[x]=num;
}

bool cmp(node a,node b){
	return a.p>b.p;
}

void dfs(int k,int pre){
	int j,u,cnt=0,sum=1;
	sz[k]=1; s[k]=w[k]; dp[k]=1ll*w[k];
	for (j=head[k];j;j=mem[j].next){
		u=mem[j].to;
		if (u==pre) continue;
		dfs(u,k);
		sz[k]+=sz[u]; s[k]+=s[u];
		dp[k]+=dp[u];
	}
	for (j=head[k];j;j=mem[j].next){
		u=mem[j].to;
		if (u==pre) continue;
		a[++cnt]=node(sz[u],s[u],(double)sz[u]/s[u]);
	}
	sort(a+1,a+1+cnt,cmp);
	for (j=1;j<=cnt;j++){
		dp[k]+=1ll*sum*a[j].s;
		sum+=a[j].sz;
	}
}

int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	int i,rt,s,u,j;
	scanf("%d",&n);
	for (i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y); add(y,x);
	}
	for (i=1;i<=n;i++) scanf("%d%d",&w[i],&tag[i]);
	if (n<=10){
		for (rt=1;rt<=n;rt++)
			if (tag[rt]){
				memset(f,-1,sizeof(f));
				f[1<<rt-1]=w[rt];
				for (s=0;s<(1<<n);s++){
					if (f[s]==-1) continue; cnt=0;
					memset(vis1,0,sizeof(vis1));
					for (i=1;i<=n;i++)
						if ((s>>i-1)&1) cnt++,vis1[i]=1;
					for (i=1;i<=n;i++)
						if ((s>>i-1)&1){
							for (j=head[i];j;j=mem[j].next){
								u=mem[j].to;
								if (vis1[u]) continue;
								f[s|(1<<u-1)]=max(f[s|(1<<u-1)],f[s]+w[u]*(cnt+1));
							}
						}
				}
				ans=max(ans,1ll*f[(1<<n)-1]);
			}
		printf("%lld\n",ans);
		return 0;
	}
	for (i=1;i<=n;i++)
		if (tag[i]){
			dfs(i,0);
			ans=max(ans,dp[i]);
		} 
	printf("%lld\n",ans);
	return 0;
}
