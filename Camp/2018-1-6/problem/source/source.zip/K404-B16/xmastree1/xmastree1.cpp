#include<cstdio>
#include<vector>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

const int N = 100010;
int n, q, t, ans;
int sta[N], col[N], f[N];
vector<int> e[N];

void dfs(int u, int fa) {
	f[u] = fa;
	for(int i = 0; i < e[u].size(); ++i) 
	if(e[u][i] != fa) dfs(e[u][i], u);
}

void get(int u) {
	++sta[col[u]];
	for(int i = 0; i < e[u].size(); ++i)
	if(e[u][i] != f[u]) get(e[u][i]);
}

int main() {
	freopen("xmastree1.in", "r", stdin); freopen("xmastree1.out", "w", stdout);
	int o, u, l, r, x, y, i;
	scanf("%d %d %d", &n, &q, &t);
	rep(i, 1, n) scanf("%d", &col[i]);
	rep(i, 1, n-1) {
		scanf("%d %d", &x, &y);
		e[x].push_back(y);
		e[y].push_back(x);
	}
	dfs(1, 0);
	while(q--) {
		scanf("%d", &o);
		if(o == 1) {
			scanf("%d %d %d", &u, &l, &r);
			if(t) u ^= ans, l ^= ans, r ^= ans;
			ans = 0;
			memset(sta, 0, sizeof sta);
			get(u);
			rep(i, l, r) ans += sta[i] > 0;
			printf("%d\n", ans);
		} else {
			scanf("%d %d", &x, &y);
			if(t) x ^= ans, y ^= ans;
			col[x] = y;
		}
	}
	return 0;
}
