#include<bits/stdc++.h>
using namespace std;
long long n,k;
long long mo=998244353;
long long ksm(long long base,long long u){
	if(u==0) return 1;
	else if(u==1) return base;
	long long ks=ksm(base,u/2);
	if(u%2==0) return (ks*ks)%mo;
	return (((ks*ks)%mo)*base)%mo;
}
long long read(){
	long long x=0,f=1;char c; c=getchar();
	while(c<'0'||c>'9') { if(c=='-') f=-1; c=getchar(); }
	while(c>='0'&&c<='9') { x=x*10+c-'0'; c=getchar(); }
	return x*f;
}
long long jc(long long u){
	long long an=1;
	for(int i=2;i<=u;i++) an=(an*i)%mo;
	return an;
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	n=read();
	k=read();
	if(k==3){
		printf("%lld\n",ksm(2,(n*n-n)/2)-jc(n));
	}
	else if(k==n){
		if(n==4) printf("24\n");
		if(n==5) printf("544\n");
		if(n==6) printf("22320\n");
	}
	else{
		printf("321425233\n");//-_-!
	}
	return 0;
}
