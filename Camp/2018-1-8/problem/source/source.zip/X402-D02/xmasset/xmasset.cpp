#include<iostream>
#include<cstdio>
#include<cstring>

int type,n;

#define lowbit(x) (x&(-x))

inline int count(int x){int ret=0;for(;x;x-=lowbit(x))ret++;return ret;}

void output(int x,int y)
{
	fprintf(stderr,"--> %d %d\n",x,y);
	for(int i=9;i>=0;i--)
	{
		if(x&(1<<i))fprintf(stderr,"1");
		else fprintf(stderr,"0");
	}
	fprintf(stderr,"\n");

	for(int i=9;i>=0;i--)
	{
		if(y&(1<<i))fprintf(stderr,"1");
		else fprintf(stderr,"0");
	}
	fprintf(stderr,"\n");
	fprintf(stderr,"------------\n");
}

int a[10],b[5][5];

void init()
{
	a[1]=1;
	a[2]=2;
	a[4]=3;
	a[8]=4;

	a[3]=1;
	a[5]=2;
	a[6]=3;
	a[9]=4;

	a[7]=1;

	b[1][1]=1,b[1][2]=2,b[1][3]=4,b[1][4]=8;
	b[2][1]=3,b[2][2]=5,b[2][3]=6,b[2][4]=9;
	b[3][1]=7;
}

int encode(int x,int y)
{
	int cx=count(x),cy=count(y);
	if(cx!=cy)
	{
		if(count(cx)!=count(cy))return count(cx);
		else return a[cx]+3;
	}

	for(int i=1,k;i<=10;i++)
	{
		k=1<<(i-1);
		cx=x&k,cy=y&k;
		if(cx && !cy)
			return i+7;
	}

	return x;
}

bool decode(int q, int h)
{
	int cq=count(q);

	if(h<=3)
		return count(cq)==h;
	else if(h<=7)
	{
		h-=3;
		return b[count(cq)][h]==cq;
	}
	else if(h<=17)
		return q&(1<<(h-8));
	else return q==h;
}

int main()
{
    int T;
	init();
    scanf("%d%d%d",&type,&n,&T);
    while(T--)
	{
        int x,y;
        scanf("%d%d",&x,&y);
        if(type==1)printf("%d\n",encode(x,y));
        else puts(decode(x,y)?"yes":"no");
    }
	return 0;
}
