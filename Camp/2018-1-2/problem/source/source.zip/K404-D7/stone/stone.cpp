#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int n, a, b;
int x[100005], kind[100005];
inline int gao(int x) {
	int mo = x % (a + b);
	int xian, hou;
	if(mo >= a) xian = 1;
	else xian = 0;
	if(mo >= b) hou = 0;
	else hou = 1;
	if(xian == 1 && hou == 1) return 1;
	if(xian == 1 && hou == 0) return 2;
	if(xian == 0 && hou == 1) return 3;
	if(xian == 0 && hou == 0) return 4;
}
int ge[10];
int ans[10];
inline void calc() {
/*	if(ge[1] + ge[2] + ge[3] + ge[4] == 0) {
		ans[4]++;
		return 0;
	}*/
	bool ablea, ableb;
	//a xian
	if(ge[1]) {
		ablea = 1;
	} else {
		ablea = ge[2] & 1;
	}
	//b xian
	if(ge[4]) {
		ableb = 1;
	}  else {
		ableb = ge[2] & 1;
	}
	if(ablea == 1 && ableb == 1) {
		ans[3]++;
		return;
	}
	if(ablea == 1 && ableb == 0) {
		ans[1]++;

		return;
	}
	if(ablea == 0 && ableb == 1) {
		ans[2]++;

		return;
	}
	if(ablea == 0 && ableb == 0) {
		ans[4]++;

		return;
	}
}
inline void dfs(int x) {
	if(x == n + 1) {
		calc();
		return;
	}
	ge[kind[x]]++;
	dfs(x + 1);
	ge[kind[x]]--;
	dfs(x + 1);
}
int main() {
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	R(n), R(a), R(b);
	for(int i = 1; i <= n; ++i) {
		R(x[i]);
		kind[i] = gao(x[i]);
	}
	dfs(1);
	cout<<ans[1]<<' '<<ans[2]<<' '<<ans[3]<<' '<<ans[4]<<'\n';
}
