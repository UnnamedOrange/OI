#include <cstdio>
#include <string.h>
#define F(x,y,z) for (x=y;x<=z;++x)
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
using namespace std;
const int Mod=1000000007;
int n,m,ans,t,s;
long long f[10000][10000];

int work(int x/*��*/,int y/*ʣ�ೡ*/)
{
	if (f[x][y]) return f[x][y];
	if (x==y) return 1;
	if (x<y) return 0;
	if (y==0) return 1;
	if (x<0 || y<0) return 0;
	int i;
	F(i,1,((y<=n)?Min(t,x-y+1):x-y+1)) 
		f[x][y]=(f[x][y]+work(x-i,y-1))%Mod;
	return f[x][y];
}

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	printf("%d",work(s,m));
	return 0;
}
