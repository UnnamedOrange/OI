#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
const int Mod=998244353;
int n,m,ans;
char s[10][110],st[1010];
int t,fail[10010],l1,l2;
bool kmp(char *s1,char *s2)
{
	l1=strlen(s1);
	l2=strlen(s2);
	memset(fail,255,sizeof(fail));
	int p=-1;
	fail[0]=-1;
	for (int i=1;i<l1;i++)
	{
		while (s1[i]!=s1[p+1] && p>=0)
		{
			p=fail[p];
		}
		if (s1[i]==s1[p+1])
		{
			p++;
		}
		fail[i]=p;
	}
	int res=0;
	p=-1;
	for (int i=0;i<l2;i++)
	{
		while (s2[i]!=s1[p+1] && p>=0)
		{
			p=fail[p];
		}
		if (s2[i]==s1[p+1])
		{
			p++;
		}
		if (p==l1-1)
		{
			res++;
		}
	}
	if (res>0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=0;i<n;i++)
	{
		scanf("%s",&s[i]);
	}
	for (int mask=0;mask<(1<<m);mask++)
	{
		for (int i=0;i<m;i++)
		{
			if (mask&(1<<i))
			{
				st[i]='1';
			}
			else
			{
				st[i]='0';
			}
		}
		for (int i=m;i<2*m;i++)
		{
			st[i]='1'+'0'-st[2*m-i-1];
		}
		st[2*m]='\0';
		bool f=true;
		for (int i=0;i<n;i++)
		{
			if (!kmp(s[i],st))
			{
				f=false;
				break;
			}
		}
		if (f)
		{
			//cout<<st<<endl;
			ans++;
			if (ans>=Mod)
			{
				ans-=Mod;
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
