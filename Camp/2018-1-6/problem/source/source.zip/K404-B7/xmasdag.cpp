#include<bits/stdc++.h>
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f; 
}

const int N=100005,M=200005,p=998244353;
int n,m,k;
int tot,first[N],du[N],nxt[M],to[M];
int c[505][505],f[N][505],tmp[509];
queue<int>q;

void add(int x,int y)
{
	nxt[++tot]=first[x],first[x]=tot,to[tot]=y;
}

void calc(int u)
{
	memset(tmp,0,sizeof(tmp));
	for(int i=0;i<=k;i++)
		for(int j=0;j<=i;j++)
			tmp[i]=(tmp[i]+1ll*c[i][j]*f[u][i-j]%p)%p;
}

void topsort()
{
	f[1][0]=1,q.push(1);
	while(!q.empty())
	{
		int u=q.front();q.pop();
		calc(u);
		for(int e=first[u];e;e=nxt[e])
		{
			int v=to[e];
			for(int i=0;i<=k;i++)f[v][i]=(f[v][i]+tmp[i])%p;
			if(!(--du[v]))q.push(v);
		}
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	int x,y;
	n=getint(),m=getint(),k=getint();
	for(int i=0;i<=k;i++)c[i][0]=1;
	for(int i=1;i<=k;i++)
		for(int j=1;j<=i;j++)c[i][j]=(c[i-1][j-1]+c[i-1][j])%p;
	while(m--)
	{
		x=getint(),y=getint();
		add(x,y),du[y]++;
	}
	topsort();
	for(int i=1;i<=n;i++)printf("%d\n",f[i][k]);
	return 0;
}

