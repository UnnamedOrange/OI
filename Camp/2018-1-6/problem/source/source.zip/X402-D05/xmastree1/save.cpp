#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
#define mid ((l+r)>>1)
string procstatus(){
	ifstream t("/proc/self/status");
	return string(istreambuf_iterator<char>(t),istreambuf_iterator<char>());
}
int n,m;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
int pre[maxn],low[maxn],dfs_time;
int f[maxn][18],c[maxn];
int siz[maxn],mxson[maxn];
int tp[maxn];
void dfs_getf(int u){
	siz[u]=1;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==f[u][0]) continue;
		f[tto[i]][0]=u;
		dfs_getf(tto[i]);
		siz[u]+=siz[tto[i]];
		if(siz[tto[i]]>siz[mxson[u]])
			mxson[u]=tto[i];
	}
}
void dfs_gettop(int u,int top){
	pre[u]=++dfs_time;
	tp[u]=top;
	if(mxson[u])
		dfs_gettop(mxson[u],top);
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==f[u][0]) continue;
		if(tto[i]==mxson[u]) continue;
		dfs_gettop(tto[i],tto[i]);
	}
	low[u]=dfs_time;
}
struct node{
	int l,r,v;
}tr[maxn*350];
int num;
int newnode(){
	num++;
	tr[num].l=tr[num].r=tr[num].v=0;
	return num;
}
void push_up(int h){
	tr[h].v=tr[tr[h].l].v+tr[tr[h].r].v;
}
void Insert(int &h,int l,int r,int s,int t){
	if(!h) h=newnode();
	if(tr[h].v) return;
	if(s<=l&&r<=t){
		tr[h].v|=1;
		tr[h].l=0,tr[h].r=0;
		return;
	}
	if(t<=mid)
		Insert(tr[h].l,l,mid,s,t);
	else if(s>mid)
		Insert(tr[h].r,mid+1,r,s,t);
	else{
		Insert(tr[h].l,l,mid,s,mid);
		Insert(tr[h].r,mid+1,r,mid+1,t);
	}
}
void Add(int &h,int l,int r,int p,int v){
	if(!h) h=newnode();
	if(l==r){
		tr[h].v+=v;
		return;
	}
	if(p<=mid) Add(tr[h].l,l,mid,p,v);
	else Add(tr[h].r,mid+1,r,p,v);
	push_up(h);
}
int Query(int h,int l,int r,int s,int t){
	if(!h) return 0;
	if(s<=l&&r<=t) return tr[h].v;
	if(t<=mid)
		return Query(tr[h].l,l,mid,s,t);
	else if(s>mid)
		return Query(tr[h].r,mid+1,r,s,t);
	else
		return Query(tr[h].l,l,mid,s,mid)+Query(tr[h].r,mid+1,r,mid+1,t);
}
int Query(int h,int l,int r,int p){
	if(!h) return 0;
	if(l==r) return tr[h].v;
	if(p<=mid) return Query(tr[h].l,l,mid,p)+tr[h].v;
	else return Query(tr[h].r,mid+1,r,p)+tr[h].v;
}
void Merge(int &h1,int h2,int l,int r){
	if(!h1||!h2){
		h1=h1+h2;
		return;
	}
	tr[h1].v=tr[h1].v+tr[h2].v;
	Merge(tr[h1].l,tr[h2].l,l,mid);
	Merge(tr[h1].r,tr[h2].r,mid+1,r);
}
int rt1[maxn],rt2[maxn];
int val[maxn];
void Insert(int u){
	int co=c[u];
	while(u){
		Insert(rt2[co],1,n,pre[tp[u]],pre[u]);
		u=f[tp[u]][0];
	}
}
int Query(int x,int l,int r){
	int res=0;
	while(x){
		res+=Query(val[x],1,n,l,r);
		x-=x&(-x);
	}
	return res;
}
void change(int x,int p,int v){
	if(x==0) return;
	while(x<=n){
		Add(val[x],1,n,p,v);
		x+=x&(-x);
	}
}
int getans(int u,int l,int r){
	int ans=Query(rt2[r],1,n,pre[u])-Query(rt2[l-1],1,n,pre[u]);
	ans=ans+Query(low[u],l,r)-Query(pre[u]-1,l,r);
//	printf("Q=%d %d\n",Query(low[u],l,r),Query(pre[u]-1,l,r));
//	if(m==5){
//		printf("Q=%d\n",Query(val[5],1,n,l,r));
//	}
	return ans;
}
void updata(int u,int v){
	int p;
	if(Query(rt1[c[u]],1,n,pre[u],low[u])==1){
		p=u;
		for(int i=17;i>=0;i--){
			if(f[p][i]==0) continue;
			if(Query(rt1[c[u]],1,n,pre[f[p][i]],low[f[p][i]])==1)
				p=f[p][i];
		}
		p=f[p][0];
		change(pre[u],c[u],-1);
		change(pre[p],c[u],1);
	}
	Add(rt1[c[u]],1,n,pre[u],-1);
	c[u]=v;
	if(Query(rt1[c[u]],1,n,pre[u],low[u])==0){
		p=u;
		for(int i=17;i>=0;i--){
			if(f[p][i]==0) continue;
			if(Query(rt1[c[u]],1,n,pre[f[p][i]],low[f[p][i]])==0)
				p=f[p][i];
		}
		p=f[p][0];
		change(pre[u],c[u],1);
		change(pre[p],c[u],-1);
	}
	Add(rt1[c[u]],1,n,pre[u],1);
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int M,T;
	scanf("%d%d%d",&n,&M,&T);
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]);
	int s,t;
	for(int i=1;i<n;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	dfs_getf(1);
	dfs_gettop(1,1);
	for(int i=1;i<=17;i++)
		for(int j=1;j<=n;j++)
			f[j][i]=f[f[j][i-1]][i-1];
	for(int i=1;i<=n;i++){
		m=i;
		Add(rt1[c[i]],1,n,pre[i],1);
		Insert(i);
	}
	for(int i=2;i<=n;i++)
		Merge(rt2[i],rt2[i-1],1,n);
	int op,l,r,u,v;
	int ans=0;
	for(m=1;m<=M;m++){
		scanf("%d",&op);
		if(op==1){
			scanf("%d%d%d",&u,&l,&r);
			if(T) u^=ans,l^=ans,r^=ans;
			if(l>r) swap(l,r);
			ans=getans(u,l,r);
			printf("%d\n",ans);
		}
		else{
			scanf("%d%d",&u,&v);
			updata(u,v);
		}
	}
//	cerr<<num<<endl;
//	cerr<<clock()*1.0/CLOCKS_PER_SEC<<endl;
//	cerr<<procstatus()<<endl;
	return 0;
}
