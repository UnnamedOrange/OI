#include<bits/stdc++.h>
#define N 100050
#define MO 998244353

using namespace std;

inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48 && c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}

int dd,a[N],tot,n,p[N],w,ans;
bool d[N],op[N];

void dfs(int x)
{
	if(x>tot)
	{
		bool fl;  
		memset(d,0,dd); 
		fl=1; // 0 1  //- 1  - 2
		for(int i=1; i<=n; ++i)if(!d[i])
		{
			w=1;
			for(int j=p[i]; j!=i; j=p[j])  
			{
				++w;
				d[j]=1;
			}
			if(w&1){
				fl=0;
				return;
			} 
		} 
		++ans; 
		return;
	}
	for(int i=1; i<=n; ++i)if(!op[i])
	{
		p[a[x]]=i;
		op[i]=1;
		dfs(x+1);
		op[i]=0;
	}
} 

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
    n=read();
    if(n&1)
    {
    	puts("0");
    	return 0;
	}
	for(int i=1; i<=n; ++i)
	{
	    p[i]=read();
	    if(!p[i])a[++tot]=i; else op[p[i]]=1;
	}
    if(tot==n)
    {
    	ans=1;
    	n=n/2-1;
    	w=3;
    	for(int i=1; i<=n; ++i)
    	{
    		ans=(long long)ans*w%MO;
    		w+=2;
		}
		 ans=(long long)ans*ans%MO;
		printf("%d\n",ans);
		exit(0); 
	}
//	dd=sizeof(d);
	dd=(n+1)*sizeof(bool);
	dfs(1); 
	printf("%d\n",ans);
} // 1 3 15 105 945
