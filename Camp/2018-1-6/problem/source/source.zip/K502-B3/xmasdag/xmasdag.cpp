#include <stdio.h>
#include <string.h>
#include <queue>
using namespace std;

struct node
{
	long long int num,dis;	
};

const int maxn=100001,maxm=200001,mod=998244353;
long long int first[maxn],nxt[maxm],to[maxm],ans[maxn];
long long int n,m,k,cnt;

inline long long int read()
{
    char ch;
    bool flag=false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void clear()
{
	memset(first,-1,sizeof(first));
	cnt=0;
}

void add(long long int ui,long long int vi)
{
	nxt[cnt]=first[ui];
	first[ui]=cnt;
	to[cnt]=vi;
	cnt++;
}

long long int cou(long long int x)
{
	long long int temp=1,kk=k;
	while(kk)
	{
		if(kk%2==1)
			temp=(temp*x)%mod;
		x=(x*x)%mod;
		kk=kk/2;
	}
	return temp;
}

void bfs()
{
	queue<node>q;
	node u;
	u.num=1;
	u.dis=0;
	q.push(u);
	while(!q.empty())
	{
		node u=q.front();
		q.pop();
		ans[u.num]=(ans[u.num]+cou(u.dis))%mod;
		long long int i;
		for(i=first[u.num];i!=-1;i=nxt[i])
		{
			node t;
			t.num=to[i];
			t.dis=u.dis+1;
			q.push(t);
		}
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	clear();
	n=read(),m=read(),k=read();
	long long int i;
	for(i=1;i<=m;i++)
	{
		long long int ui=read(),vi=read();
		add(ui,vi);
	}
	bfs();
	for(i=1;i<=n;i++)
		printf("%lld\n",ans[i]%mod);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
