#include<bits/stdc++.h>
using namespace std;
const int N=1000005;
int read(){
    int f=1,ret=0;
    char ch=getchar();
    while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
    while(ch<='9'&&ch>='0'){ret=ret*10+ch-'0';ch=getchar();}
    return f*ret;
}

long long n;
double w[N],ans=0.0;

int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)w[i]=1.0*read();
	int T=28;
	for(int i=1;i<=n;i++){
		double call=0.0,calr=0.0,mi=1.0;
		int last=i,cnt=0;
		for(int x=i-1;x&&cnt<=T;x--){
			if(w[x]>=w[i]){
				call+=(last-x)/mi;
				mi*=2.0;
				last=x;
				cnt++;
			}
		}
		if(cnt<=T)call+=last/mi;
		last=i;mi=1.0;cnt=0;
		for(int x=i+1;x<=n&&cnt<=T;x++){
			if(w[x]>w[i]){
				calr+=(x-last)/mi;
				mi*=2.0;
				last=x;
				cnt++;
			}
		}
		if(cnt<=T)calr+=(n+1-last)/mi;
		ans+=call*calr*w[i]/2.0;
	}
	ans/=1.0*(n*n);
	printf("%.8lf",ans);
	return 0;
}

