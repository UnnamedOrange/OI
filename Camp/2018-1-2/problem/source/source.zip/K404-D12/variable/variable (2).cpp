#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>

using namespace std;
#define MAXN 1000
#define ll long long
#define pb push_back
#define INFLL 0x3f3f3f3f3f3f3f3fll
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int x[MAXN+5], y[MAXN+5], z[MAXN+5], a[MAXN+5], b[MAXN+5], c[MAXN+5], d[MAXN+5], e[MAXN+5], f[MAXN+5]; vector<int> g[MAXN+5];
int limx[MAXN+5], limy[MAXN+5], limr[MAXN+5], X[MAXN+5], n, W, p, q, E, T; ll Ans, Res; int fa[MAXN+5], Free[MAXN+5], in[MAXN+5];
bool Check()
{
	for(rint i = 1; i <= q; i++)
		switch(limr[i])
		{
			case 0: if(X[limx[i]] > X[limy[i]]) return false; break;
			case 1: if(X[limx[i]] ^ X[limy[i]]) return false; break;
			case 2: if(X[limx[i]] >=X[limy[i]]) return false; break;
		}	return true;
}
ll Func(int i)
{
	return 1ll*a[i]*abs(X[x[i]]-X[y[i]])+1ll*d[i]*(X[x[i]]-X[y[i]])
		  +1ll*b[i]*abs(X[y[i]]-X[z[i]])+1ll*e[i]*(X[y[i]]-X[z[i]])
		  +1ll*c[i]*abs(X[z[i]]-X[x[i]])+1ll*f[i]*(X[z[i]]-X[x[i]]);
}
void Calc(){Res = 0; for(rint i = 1; i <= n; Res += X[i], i++); for(rint i = 1; i <= p; Res += Func(i), i++);}
inline int getf(int x){return x-fa[x] ? fa[x] = getf(fa[x]) : x;}
inline void Union(int x, int y){(x=getf(x))-(y=getf(y)) ? fa[x] = y : 0;}
void Topo()
{
	static int q[MAXN+5], head, tail; head = tail = 0;
	for(rint i = 1; i <= n; fa[i]==i&&!in[i] ? q[++tail] = i : 0, i++);
	for(rint p, i, v; head<tail; )
		for(p = q[++head], !X[p] ? X[p] = -1 : 0, i = 0; i < g[p].size(); i++)
			!--in[v=getf(g[p][i])] ? q[++tail] = v : 0, X[p]==1 ? X[v] = 1 : 0;
	for(rint j = tail, p, i; j; j--) for(p = q[j], i = 0; i < g[p].size(); X[p] = min(X[p],X[g[p][i]]), i++);
}
int main()
{
	freopen("variable.in","r",stdin), freopen("variable.out","w",stdout), srand(20010425);
	for(T = read(); T--; )
	{
		n = read(), W = abs(read()), p = read(), q = read(), E = ~-(1<<n), Ans = INFLL;
		for(rint i = 1; i <= p; x[i] = read(), y[i] = read(), z[i] = read(), a[i] = read(), b[i] = read(), c[i] = read(), d[i] = read(), e[i] = read(), f[i] = read(), i++);
		for(rint i = 1; i <= q; limx[i] = read(), limy[i] = read(), limr[i] = read(), i++);
		if(n <= 15)
		{
			for(rint i = 1, j, S; i <= E; i++)
			{
				for(S = i, j = 1; j <= n; X[j] = S&1?1:-1, S >>= 1, j++);
				if(Check()) Calc(), Ans = min(Ans,Res);
			}	printf("%lld\n",1ll*W*Ans);
		}
		else
		{
			for(rint i = 1; i <= n; fa[i] = i, X[i] = 0, g[i].clear(), i++);
			for(rint i = 1; i <= q; i++) if(limr[i] == 1) Union(limx[i],limy[i]);
			for(rint i = 1; i <= q; i++) if(limr[i] == 2) X[getf(limx[i])] = -1, X[getf(limy[i])] = 1;
			for(rint i = 1; i <= q; i++) if(limr[i] == 0) g[getf(limx[i])].pb(getf(limy[i])), ++in[getf(limy[i])];
			Topo(); for(rint i = 1; i <= n; X[i] = X[getf(i)], i++); if(Check()) Calc(), Ans = min(Ans,Res);
			
			for(rint i = 1; i <= n; fa[i] = i, X[i] = 0, Free[i] = true, g[i].clear(), i++);
			for(rint i = 1; i <= q; i++) if(limr[i] == 1) Union(limx[i],limy[i]);
			for(rint i = 1; i <= q; i++) if(limr[i] == 2) X[getf(limx[i])] = -1, X[getf(limy[i])] = 1, Free[getf(limx[i])] = Free[getf(limy[i])] = false;
			for(rint i = 1, j; i <= 1000; i++)
			{
				for(j = 1; j <= n; j==getf(j) && Free[getf(j)] ? X[getf(j)] = rand()&1?1:-1 : 0, j++);
				for(j = 1; j <= n; X[j] = X[getf(j)], j++); if(Check()) Calc(), Ans = min(Ans,Res);
			}	printf("%lld\n",1ll*W*Ans);
		}
	}	return 0;
}
