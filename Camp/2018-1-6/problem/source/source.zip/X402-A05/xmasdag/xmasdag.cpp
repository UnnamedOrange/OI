#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>

#define REP(i, t) for(int i = 0, i##E = (t); i < i##E; ++i)
typedef long long LL;

const int N = 1e5 + 10, M = 2e5 + 10, mod = 998244353;

int fpm(int x, int y)
{
	int ret = 1;
	for(; y; y >>= 1, x = 1LL * x*x % mod)
		if(y & 1) ret = 1LL * ret*x % mod;
	return ret;
}

int n, m, k, degree[N];
int e, to[M], Next[M], Begin[N];

void add_edge(int u, int v)
{
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

void add(int &a, int b)
{
	a += b; if(a >= mod) a -= mod;
}

namespace brute_force
{
	int dp[2010][2010], q[N];
	void Topsort(int l = 1, int r = 0)
	{
		dp[1][0] = 1;
		for(int i = 1; i <= n; ++i)
			if(!degree[i]) q[++r] = i;

		while(l <= r){
			int u = q[l++];
			for(int i = Begin[u]; i; i = Next[i]){
				int v = to[i];
				for(int i = 0; i < n; ++i) add(dp[v][i+1], dp[u][i]);
				if(!(--degree[v])) q[++r] = v;
			}
		}

		for(int i = 1; i <= n; ++i){
			int ans = 0;
			for(int l = 1; l <= n; ++l)
				add(ans, 1LL * dp[i][l]*fpm(l, k) % mod);
			printf("%d\n", ans);
		}

		return ;
	}
}

namespace K_1
{
	int dp[N], g[N];
	int q[N];

	void Topsort(int l = 1, int r = 0)
	{
		dp[1] = 0, g[1] = 1;
		for(int i = 1; i <= n; ++i)
			if(!degree[i]) q[++r] = i;

		while(l <= r){
			int u = q[l++];
			for(int i = Begin[u]; i; i = Next[i]){
				int v = to[i];
				add(dp[v], (dp[u] + g[u]) % mod);
				add(g[v], g[u]);
				if(!(--degree[v])) q[++r] = v;
			}
		}

		for(int i = 1; i <= n; ++i) printf("%d\n", dp[i]);

		return ;
	}
}

int main()
{
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);
	for(int i = 1; i <= m; ++i){
		int u, v; scanf("%d%d", &u, &v);
		add_edge(u, v), ++degree[v];
	}

	if(k == 1) K_1::Topsort();
	else
		brute_force::Topsort();

	return 0;
}
