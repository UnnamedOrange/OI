#include <map>
#include <cstdio>
#include <queue>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

#define ret return

const int N = 100;

int n, x[N], pos[N], ans = 0;
map<string, int> m;
string null;
struct BFS{
	string str;
	int step;
	int last;
};

inline void open()
{
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	ret;
}

inline void close()
{
	fclose(stdin);
	fclose(stdout);
	ret;
}

inline int read()
{
	int a = 0;
	char ch;
	int f = 1;
	while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
	if(ch == '-')
		f = -1;
	else
	{
		a = a * 10;
		a += ch - '0';
	}
	while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
	{
		a = a * 10;
		a += ch - '0';
	}
	ret a * f;
}

inline string rev(string a, int b)
{
	int m = (b + 1) / 2;
	for(int i = 0;i < m;++i)
	{
		char c = a[i];
		a[i] = a[b - i];
		a[b - i] = c;
	}
	ret a;
}

inline void brute()
{
	string st = null, ta = null;
	for(int i = 1;i <= n;++i)
	{
		char c = '0' + x[i], d = '0' + i;
		st = st + c;
		ta = ta + d;
	}
	m[st] = 0;
	BFS s;
	s.str = st;
	s.step = 0;
	s.last = 0;
	queue<BFS> q;
	q.push(s);
	while(q.size() > 0)
	{
		BFS f = q.front();q.pop();
		if(f.str == ta)
		{
			printf("%d\n", f.step);
			ret;
		}
		int mm = m[f.str];
		if(mm != 0 && mm <= f.step)
			continue;
		if(mm == 0)
			m[f.str] = f.step;
		//cout << f.str << " " << f.step << " " << mm << endl;
		if(f.step == 8)
			continue;
		for(int i = 1;i < n;++i)
		{
			if(i == f.last)
				continue;
			BFS t;
			t.str = rev(f.str, i);
			t.step = f.step + 1;
			t.last = i;
			int tt = m[t.str];
			if(tt && tt <= f.step + 1)
				continue;
			q.push(t);
		}
	}
	
	ret;
}

inline void revv(int p)
{
	int m = p / 2;
	for(int i = 1;i <= m;++i)
		swap(x[i], x[p - i + 1]);
	for(int i = 1;i <= n;++i)
		pos[x[i]] = i;
}

inline void wr()
{
	for(int i = 1;i <= n;++i)
		pos[x[i]] = i;
	for(int i = n;i >= 1;--i)
	{
		if(pos[i] != i)
		{
			if(pos[i] != 1)
				revv(pos[i]), ++ans;
			revv(i), ++ans;
		}
	}
	if(ans > n)
		ans = n;
	printf("%d\n", ans);
	ret;
}

inline void solve()
{
	n = read();
	for(int i = 1;i <= n;++i)
		x[i] = read();
	ans = 0;
	if(n <= 8)
		brute();
	else
		wr();
	ret;
}

inline void Do()
{
	int t = read();
	while(t--)
		solve();
	ret;
}

int main()
{
	open();
	Do();
	close();
	ret 0;
} 
