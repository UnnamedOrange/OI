《算法竞赛入门经典——训练指南》代码仓库

第四章习题代码

注意：有些题目并没有在书中出现，但是仍然有一定的启发意义，所以一并放在这里，供读者参考。

基础练习（Basic Problems）
UVa10347 Medians 陈锋
UVa10522 Height to Area 陈锋
UVa10566 Crossed Ladders 陈锋
UVa11437 Triangle Fun 陈锋
UVa11646 Athletics Track 刘汝佳
UVa11800 Determine the Shape 陈锋
UVa11817 Tunnelling the Earth 刘汝佳
UVa12300 Smallest Regular Polygon 陈锋
UVa12301 An Angular Puzzle 陈锋

二维几何计算（Geometric Computations in 2D）
UVa10674 Tangents 刘汝佳
UVa10075 Airlines 陈锋
UVa10556 Biometrics 陈锋
UVa10585 Center of Symmetry 陈锋
UVa10969 Sweet Dream 陈锋
UVa11928 The Busy Dog 刘汝佳

二维几何算法（Geometric Algorithms in 2D）
LA2453 Wall 陈锋
UVa10084 Hotter Colder 陈锋

三维几何（Geometric Computations and Algorithms in 3D）
UVa1373 How I Wonder What You Are! 陈锋
UVa1360(LA3500) Model Rocket Height 陈锋
UVa1333(LA3147) Model Rocket Height 陈锋
UVa11836 Star War 陈锋
UVa10794 The Deadly Olympic Returns 陈锋
