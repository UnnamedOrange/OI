#include<bits/stdc++.h>
using namespace std;
#define mid ((l+r)>>1)
const int maxn=1001000;
const int maxv=100100;
int a[maxn];
double pw2[maxn];
namespace Seg{
	double tr[maxn<<2];
	int tg[maxn<<2];
	void push_down(int h){
		if(!tg[h]) return;
		tr[h<<1]*=pw2[tg[h]];
		tr[h<<1|1]*=pw2[tg[h]];
		tg[h<<1]+=tg[h];
		tg[h<<1|1]+=tg[h];
		tg[h]=0;
	}
	void push_up(int h){
		tr[h]=tr[h<<1]+tr[h<<1|1];
	}
	void updata(int h,int l,int r,int s,int t){
		if(s<=l&&r<=t){
			tr[h]=tr[h]/2.0;
			tg[h]++;
			return;
		}
		push_down(h);
		if(t<=mid) updata(h<<1,l,mid,s,t);
		else if(s>mid) updata(h<<1|1,mid+1,r,s,t);
		else{
			updata(h<<1,l,mid,s,mid);
			updata(h<<1|1,mid+1,r,mid+1,t);
		}
		push_up(h);
	}
	void Add(int h,int l,int r,int p,double v){
		if(l==r){
			tr[h]+=v;
			return;
		}
		push_down(h);
		if(p<=mid) Add(h<<1,l,mid,p,v);
		else Add(h<<1|1,mid+1,r,p,v);
		push_up(h);
	}
	double Query1(){
		return tr[1];
	}
}
struct node{
	int l,r,siz;
	double v;
}tr[maxn*30];
int num;
struct Pos{
	int p,v;
}b[maxn];
bool cmp(const Pos &A,const Pos &B){
	return A.v==B.v?A.p>B.p:A.v<B.v;
}
int rt[maxn];
void push_up(int h){
	tr[h].v=tr[tr[h].r].v+tr[tr[h].l].v*pw2[tr[tr[h].r].siz];
}
void build_tree(int &h,int l,int r){
	h=++num;
	if(l==r){
		tr[h].v=1;
		return;
	}
	build_tree(tr[h].l,l,mid);
	build_tree(tr[h].r,mid+1,r);
	push_up(h);
}
int cnt=0;
void Insert(int &h1,int h2,int l,int r,int p){
	cnt++;
	h1=++num;
	tr[h1].siz=tr[h2].siz+1;
	if(l==r){
		tr[h1].v=tr[h2].v/2.0;
		return;
	}
	if(p<=mid){
		tr[h1].r=tr[h2].r;
		Insert(tr[h1].l,tr[h2].l,l,mid,p);
	}
	else{
		tr[h1].l=tr[h2].l;
		Insert(tr[h1].r,tr[h2].r,mid+1,r,p);
	}
	push_up(h1);
}
struct Ret{
	int siz;
	double v;
};
Ret Query(int h,int l,int r,int s,int t){
	if(s<=l&&r<=t)
		return (Ret){tr[h].siz,tr[h].v};
	if(t<=mid) return Query(tr[h].l,l,mid,s,t);
	else if(s>mid) return Query(tr[h].r,mid+1,r,s,t);
	else{
		Ret ret1=Query(tr[h].l,l,mid,s,mid);
		Ret ret2=Query(tr[h].r,mid+1,r,mid+1,t);
		return (Ret){ret1.siz+ret2.siz,ret1.v*pw2[ret2.siz]+ret2.v};
	}
}
int ps[maxn];
void readl(int &x){
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int n;
	scanf("%d",&n);
	pw2[0]=1;
	for(int i=1;i<=n;i++)
		pw2[i]=pw2[i-1]/2.0;
	for(int i=1;i<=n;i++){
		readl(a[i]);
		b[i]=(Pos){i,a[i]};
	}
	sort(b+1,b+n+1,cmp);
	build_tree(rt[n+1],1,n);
	for(int i=n;i>=1;i--){
		Insert(rt[i],rt[i+1],1,n,b[i].p);
		ps[b[i].p]=i;
	}
	Ret st;
	double ans;
	for(int i=1;i<=n;i++){
		if(a[i]>1)Seg::updata(1,1,maxv,1,a[i]-1);
		st=Query(rt[ps[i]],1,n,1,i);
		Seg::Add(1,1,maxv,a[i],st.v*a[i]);
		ans=ans+Seg::Query1();
	}
	printf("%.8f\n",ans/(n*(long long)n));
//	cerr<<clock()*1.0/CLOCKS_PER_SEC<<endl;
	return 0;
}
