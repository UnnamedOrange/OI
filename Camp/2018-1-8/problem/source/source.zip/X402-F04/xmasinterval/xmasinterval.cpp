//2018-1-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (10000+5)
#define N (1000000+5)

const int P = 1e9 + 9;
const int oo = 0x7f7f7f7f;

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x<<1) + (x<<3) + (chr^'0'); chr = getchar();
	}
}

inline int Mod(int a){return a >= P? a-P: a;}
inline int Mul(int a, int b){return 1ll * a * b % P;}

struct Seg{
	int l, r, id;
	bool operator <(const Seg &rhs)const{
		return r < rhs.r;
	}
}a[N], seg[N];

vector<Seg> ed[N];
int rn, n, m, cnt, imp[N], pow2[N], c[N], Tot[N];

int Find(int p){
	if(imp[1] > p) return 0;

	int L = 1, R = m, mid;
	while(L < R){
		mid = (L + R + 1) >> 1;
		if(imp[mid] <= p) L = mid; else R = mid-1;
	}
	return L;
}

void Init(){
	sort(imp+1, imp+m+1);
	m = unique(imp+1, imp+m+1) - imp - 1;
	imp[m+1] = oo;

	int l, r;
	For(i, 1, rn){
		l = lower_bound(imp, imp+m+2, a[i].l) - imp;
		r = Find(a[i].r);

		if(l > r) ++cnt;
		else
			ed[r].pb((Seg){l, r, ++n}), seg[n] = (Seg){l, r, n};
	}
	sort(seg+1, seg+n+1);

	pow2[0] = 1;
	For(i, 1, max(rn,m)) pow2[i] = Mul(pow2[i-1], 2);
}

bool vis[N];
void Bf(){
	int ans = 0;
	bool flag;

	For(i, 0, (1<<n)-1){
		For(j, 1, m) vis[j] = false;
		For(j, 1, n) if(i & (1<<(j-1))){
			For(k, seg[j].l, seg[j].r) vis[k] = true;
		}
		
		flag = true;
		For(j, 1, m) if(!vis[j]){flag = false; break;}

		if(flag) ++ans;
	}
	
	printf("%d\n", Mul(Mod(ans), pow2[cnt]));
}

int ql, qr;

#define lc (o<<1)
#define rc (o<<1|1)
#define mid ((L+R)>>1)

namespace Seg_tree{
	int base[N<<2], h[N<<2];
	
	void InitS(){
		For(i, 0, (m<<2)+1) base[i] = 1;
	}

	void Modify(int o, int L, int R, int p, int pv){
		h[o] = Mod(h[o] + pv);
		if(L == R) return;
		if(p <= mid) Modify(lc, L, mid, p, pv);
		else Modify(rc, mid+1, R, p, pv);
	}

	void PutBase(int o, int L, int R){
		if(ql <= L && qr >= R){
			base[o] = Mul(base[o], 2); h[o] = Mul(h[o], 2); return;
		}
		if(ql <= mid) PutBase(lc, L, mid);
		if(qr > mid) PutBase(rc, mid+1, R);
		h[o] = Mul(Mod(h[lc]+h[rc]), base[o]);
	}

	int Query(int o, int L, int R){
		if(ql <= L && qr >= R) return h[o];
		
		int ret = 0;
		if(ql <= mid) ret = Mod(ret + Query(lc, L, mid));
		if(qr > mid) ret = Mod(ret + Query(rc, mid+1, R));
		return Mul(ret, base[o]);
	}
};

#undef lc
#undef rc
#undef mid

using namespace Seg_tree;

void Solve(){
	++m;
	InitS();
	Modify(1, 1, m, 1, 1);	
	For(i, 1, n) ++seg[i].l, ++seg[i].r;

	int now;
	For(i, 1, n){
		ql = seg[i].l-1, qr = seg[i].r, now = Query(1, 1, m);
		
		ql = qr = m;
		
		Modify(1, 1, m, seg[i].r, now);

		if(seg[i].l > 2){
			ql = 1; qr = seg[i].l - 2;
			PutBase(1, 1, m);
		}
	}

	ql = qr = m;
	int ans = Query(1, 1, m);
	
	printf("%d\n", Mul(ans, pow2[cnt]));
}

int main(){
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	
	Read(rn); Read(m);
	For(i, 1, rn) Read(a[i].l), Read(a[i].r);
	For(i, 1, m) Read(imp[i]);

	Init();
	
	if(n <= 20) Bf(); else 
	Solve();

	return 0;
}
