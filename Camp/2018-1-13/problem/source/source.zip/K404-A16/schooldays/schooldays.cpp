#include <cstdio>
#include <vector>
#include <algorithm>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

const int N = 100010;
const int mod = 1e9 + 7;

int l[N], r[N], f[N], num[N];
int n, mn, mx;
vector <int> w[N];

int main()
{
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
	scanf("%d", &n);
	FOR(i, 1, n) scanf("%d%d", &l[i], &r[i]);
	FOR(i, 1, n)
	{
		mn = 1; mx = n;
		FOR(j, i, n)
		{
			mn = max(mn, l[j]);
			mx = min(mx, r[j]);
			if (mn <= j - i + 1 && j - i + 1 <= mx)
			{
				if (j == n) f[i] = 1; else w[i].push_back(j);	
			}
			if (mn > mx || j - i + 1 > mx) break;
		}
	}
	for(int i = n; i; --i)
	{
		for(int j = 0; j < w[i].size(); ++j)
			if (f[w[i][j] + 1] != -1)
				f[i] = max(f[i], f[w[i][j] + 1] + 1);
		if (!f[i]) f[i] = -1;
	}
	if (f[1] == -1) {puts("-1"); return 0;}
	for(int i = n; i; --i)
	{
		if (f[i] == -1) continue;
		if (f[i] == 1) num[i] = 1;
		for(int j = 0; j < w[i].size(); ++j)
			if (f[w[i][j] + 1] + 1 == f[i])
				num[i] = (num[i] + num[w[i][j] + 1]) % mod;
	}
	printf("%d %d\n", f[1], num[1]);
	return 0;
}
