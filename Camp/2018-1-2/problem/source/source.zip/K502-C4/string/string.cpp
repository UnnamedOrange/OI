#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

int T,n,top;
char s[100005],c[100005];

void init()
{
	n=top=0;
	memset(s,0,sizeof s);
	memset(c,0,sizeof c);
}

bool checks()
{
	if(n==1) return true;
	for(int i=1;i<=n/2;i++)
		if(s[i]!=s[n+1-i]) return false;
	return true;
}

bool checkc()
{
	if(top==1) return true;
	for(int i=1;i<=top/2;i++)
		if(c[i]!=c[top+1-i]) return false;
	return true;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		init();
		scanf("%d",&n);
		scanf("%s",s+1);
		if(n==0)
		{
			printf("0\n");
			continue;
		} 
		if(checks()==0)//origin one can be delete at once
		{
			printf("1\n");
			continue;
		}
		int flag=0;
		while(n>1)
		{
			c[++top]=s[n];
			s[n--]='0';
			if(checks()==0&&checkc()==0)
			{
				flag=1;
				break;
			}
		}
		if(flag==1) printf("2\n");
		else printf("-1\n");
	}
	return 0;
} 
