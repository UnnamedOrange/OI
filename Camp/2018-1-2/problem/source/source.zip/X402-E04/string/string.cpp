#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=100010,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
template<class T>inline bool chmx(T &a,T b){return a<b?a=b,1:0;}
template<class T>inline bool chmi(T &a,T b){return a>b?a=b,1:0;}
inline void file(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
}
int n;
int Ban[N],ans=INF;

char st[N],s[N];
inline void init(){
	scanf("%d",&n);
	scanf("%s",s+1);
	ans=INF;
}
inline bool check(int l,int r){
	int tot=0;
	For(i,l,r)if(!Ban[i])st[++tot]=s[i];
	l=1,r=tot;
	while(s[l]==s[r]&&l<r){
		l++;r--;
	}
	if(l>=r)return 0;
	return 1;
}
void dfs(int tot,int now){
	if(now>=ans)return ;
	if(tot==0)return void (chmi(ans,now));
	For(i,1,n)if(!Ban[i])
		Forr(j,n,i+1)if(!Ban[j]){
			if(check(i,j)){
				int cnt=tot,vis[110];
				For(k,i,j)vis[k]=!Ban[k],cnt-=!Ban[k],Ban[k]=1;
				dfs(cnt,now+1);
				For(k,i,j)if(vis[k])Ban[k]=0;
			}
		}
}
void solve(){
	For(i,1,n)Ban[i]=0;
	dfs(n,0);
	if(ans==INF)puts("-1");
	else printf("%d\n",ans);
}
int main(){
	file();
	int T;
	read(T);
	while(T--){
		init();
		solve();
	}
	return 0;
}
