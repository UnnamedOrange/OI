#include <bits/stdc++.h>
#define LL long long
#define MOD 998244353
using namespace std;
inline int read() {
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int n,p[100010],fac[100010],ifac[100010];
inline int pow(int x,int y) {
	int temp=x,ans=1;
	while(y) {
		if(y&1)ans=1LL*ans*temp%MOD;
		temp=1LL*temp*temp%MOD;
		y<<=1;
	}
	return ans;
}
void init() {
	for(int i=1; i<=n; i++) {
		fac[i]=1LL*i*fac[i-1]%MOD;
		ifac[i]=pow(fac[i],MOD-2);
	}
}
bool b[100],bb[100];
bool judge() {
	bool vis[100];
	memset(vis,0,sizeof(vis));
	for(int i=1; i<=n; i++) {
		int cnt=0;
		if(!vis[i]) {
			for(int j=i; !vis[j]; j=p[j]) {
				vis[j]=1;
				cnt++;
			}
		}
		if(cnt%2) {
			return 0;
		}
	}
//	for(int i=1;i<=n;i++)
//	{
//		cout<<p[i]<<' ';
//	}
//	cout<<endl;
	return 1;
}
int dfs(int x) {
	if(x==n+1) {
		return judge();
	} else {
		int ret=0;
		if(p[x]) {
			b[p[x]]=1;
			ret=dfs(x+1);
			b[p[x]]=0;
		} else {
			for(int i=1; i<=n; i++) {
				if(!b[i]&&!bb[i]) {
					b[i]=1;
					p[x]=i;
					ret+=dfs(x+1);
					ret%=MOD;
					b[i]=0;
					p[x]=0;
				}
			}
		}
		return ret;
	}
}
int main() {
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++) {
		p[i]=read();
		bb[p[i]]=1;
	}
	if(n<=10) {
		cout<<dfs(1)<<endl;
	} else {
//		init();
		int ret=1;
		for(int i=1; i<=n; i+=2) {
			ret=1LL*ret*i%MOD;
		}
		ret=ret*ret%MOD;
		cout<<ret<<endl;
	}
}
/*

*/

