#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
int T, n;
long long miu[1000010], o[1000010], mi[1000010], prime[1000010], cnt;
long long smiu[1000010], so[1000010];
bool isprime[1000010];
inline void getprime () {
	miu[1] = 1, o[1] = 1;
	for (int i = 2; i <= 1000000; i++) {
		if (!isprime[i]) prime[++cnt] = i, miu[i] = -1, mi[i] = 1, o[i] = 2;
		for (int j = 1; j <= cnt && i * prime[j] <= 1000000; j++) {
			isprime[i * prime[j]] = true;
			if (i % prime[j] == 0) {
				miu[i * prime[j]] = 0;
				mi[i * prime[j]] = mi[i] + 1;
				o[i * prime[j]] = 1ll * o[i] * o[prime[j]] / 2 / mi[i * prime[j]] * (mi[i * prime[j]] + 1);
				break;
			}
			miu[i * prime[j]] = miu[i] * miu[prime[j]];
			mi[i * prime[j]] = 1;
			o[i * prime[j]] = 1ll * o[i] * o[prime[j]];
		}
	}
	for (int i = 1; i <= 1000000; i++) smiu[i] = miu[i] + smiu[i - 1];
	for (int i = 1; i <= 1000000; i++) o[i] = 1ll * o[i] * o[i], so[i] = o[i] + so[i - 1];
}
inline void solve (int x) {
	long long res = 0;
	for (int i = 1; i <= x; i++)
		for (int j = 1; i * j <= x; j++)
			res = res + 1ll * miu[i] * o[j];
	/*int q = sqrt (x);
	for (int i = 1; i <= q; i++) res = (res + 1ll * miu[i] * so[x / i] % MOD) % MOD;
	for (int i = 1; i <= q; i++) res = (res + 1ll * o[i] * smiu[x / i] % MOD) % MOD;
	for (int i = 1; i <= q; i++) res = (res - 1ll * miu[i] * so[q] % MOD + MOD) % MOD;*/
	printf ("%lld\n", res);
}
int main () {
	freopen ("function.in", "r", stdin);
	freopen ("function.out", "w", stdout);
	scanf ("%d", &T);
	getprime ();
	//for (int i = 1; i <= 30; i++) printf ("%lld\n", o[i]);
	while (T--) {
		scanf ("%d", &n);
		solve (n);
	}
	return 0;
}
