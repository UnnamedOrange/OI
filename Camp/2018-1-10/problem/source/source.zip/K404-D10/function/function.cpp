//© 2018 Jazengm/ZengXiangru, AllRightsReserved

#include<bits/stdc++.h>
using namespace std;

//#define debug
#ifdef debug
#define DB(x) x
#endif
#ifndef debug
#define DB(x)
#endif

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int E6=1<<22 DB(>>15);

ll mu[E6], sigma[E6], sigmaSqr[E6], muSigmaSqr[E6], sumSigmaSqr[E6], ans[E6], f[E6];

In ll Pow(ll a, int b)
{
    Rg ll r=1;
    for(;b; a=a*a, b>>=1)
        b&1? r=r*a: 0;
    Re r;
}

In int gcd(int a, int b)
{
    for(;b; swap(a%=b, b));
    Re a;
}

In void getAll()
{
    St int temp[E6], cnt[E6];
    mu[1]=1,
    sigma[1]=1,
    sigmaSqr[1]=1,
    muSigmaSqr[1]=1,
    f[1]=1,
    temp[1]=1, cnt[1]=0;
    Rg int m=0;
    inc(2, i, E6)
    {
        St bool vis[E6];
        St int p[E6];
        if(!vis[i])
            p[m++]=i,
            mu[i]=-1,
            sigma[i]=2,
            sigmaSqr[i]=4,
            muSigmaSqr[i]=3,
            f[i]=3,
            temp[i]=i, cnt[i]=1;
        for(Rg int j=0, k; j<m && (k=i*p[j])<E6; ++j)
            if(vis[k]=1, i%p[j])
                mu[k]=-mu[i],
                sigma[k]=sigma[i]*2,
                sigmaSqr[k]=sigmaSqr[i]*4,
                muSigmaSqr[k]=muSigmaSqr[i]*3,
                f[k]=f[i]*3,
                temp[k]=p[j], cnt[k]=1;
            else
            {
                temp[k]=temp[i]*p[j], cnt[k]=cnt[i]+1;
                sigma[k]=sigma[k/temp[k]]*(cnt[k]+1);
                sigmaSqr[k]=sigmaSqr[k/temp[k]]*Pow(cnt[k]+1, 2);
                muSigmaSqr[k]=muSigmaSqr[k/temp[k]]*(2*cnt[k]+1);
                f[k]=f[i];
                break;
            }
    }
    DB(inc(1, i, E6)
        printf("%lld ", mu[i]); puts("");
    inc(1, i, E6)
        printf("%lld ", sigma[i]); puts("");
    inc(1, i, E6)
        printf("%lld ", sigmaSqr[i]); puts("");
    inc(1, i, E6)
        printf("%lld ", muSigmaSqr[i]); puts("");)
    
    DB(inc(1, i, E6)
        printf("(%d %lld) ", i, sumSigmaSqr[i]=sumSigmaSqr[i-1]+sigmaSqr[i]);
    puts("");
    inc(1, i, E6)
    {
        Rg ll tot=0;
        inc(1, x, i+1)
            inc(1, y, i+1)
                tot+=i*gcd(x, y)/x/y;
        printf("(%d %lld) ", i, tot);
    }
    puts("");
    inc(1, i, E6)
    {
        Rg ll tot=0;
        inc(1, d, i+1)
            tot+=(i/d)*f[d];
        printf("(%d %lld) ", i, tot);
    }
    puts("");)
        
    inc(1, i, E6)
        ans[i]=ans[i-1]+muSigmaSqr[i];
}

ll getAns(int n)
{
    Re ans[n];
}

int main()
{
    freopen("function.in", "r", stdin);
    freopen("function.out", "w", stdout);
    getAll();
    St int t;
    for(scanf("%d", &t); t--;)
    {
        St int n;
        scanf("%d", &n);
        printf("%lld\n", getAns(n));
    }
    Re 0;
}
