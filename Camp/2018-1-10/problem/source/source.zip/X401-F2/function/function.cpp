#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}

int tot;

int Pri[1000100],ispri[1000100],mu[1000100],num[1000100],d[1000100];

void init(){
	num[1]=1,mu[1]=1;
	for(int i=2;i<=1000000;i++){
		if(!ispri[i]) Pri[++tot]=i,num[i]=2,mu[i]=-1,d[i]=1;
		for(int j=1;j<=tot&&Pri[j]*i<=1000000;j++){
			ispri[Pri[j]*i]=true;
			if(!(i%Pri[j])){
				d[i*Pri[j]]=d[i]+1;
				num[Pri[j]*i]=num[i]/(d[i]+1)*(d[i]+2);
				mu[i*Pri[j]]=0;
				break;
			} 
			num[Pri[j]*i]=num[i]*2;
			d[i*Pri[j]]=1;
			mu[i*Pri[j]]=-mu[i];
		}
	}
}

int main() {
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int T;read(T);init();
	while (T--) {
		int n;read(n);
		int Sum=0;
		for(int i=1;i<=n;i++) for(int j=1;j*j<=i;j++)
			if(i%j==0){
				Sum+=mu[j]*num[i/j]*num[i/j];
				if(j*j!=i) Sum+=mu[i/j]*num[j]*num[j];
			}
		printf("%d\n",Sum);
	}
	return 0;
}
