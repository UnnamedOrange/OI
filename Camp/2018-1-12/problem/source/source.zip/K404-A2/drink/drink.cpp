#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
char xB[1<<15],*xT=xB,*xS=xB;
#define getchar() (xS==xT&&(xT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xT)?0:*xS++)
inline int read()
{
    int X=0,w=0; char ch=0;
    while(!isdigit(ch)) w|=ch=='-',ch=getchar();
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}
int n,w[1000010];
double ans,f[1000010],a[1000010];
int main()
{
  freopen("drink.in","r",stdin);
  freopen("drink.out","w",stdout);
  register int k,j,i;
  n=read();
  for(i=1;i<=n;++i)
  {
    w[i]=read();
  }
  for(i=1;i<=n;++i)
  for(j=1;(i+j-1)<=n;++j)
  {
    for(k=1;k<=j;++k)
    {
      a[k]=w[i+k-1];
      f[k]=0;
    }
    sort(a+1,a+j+1);
    f[1]=a[1]/2;
    for(k=2;k<=j;++k)
    {
      if(f[k-1]>a[k])
      {
        f[k]=max(f[k-1],(f[k-2]+a[k])/2);
      }
      else f[k]=(f[k-1]+a[k])/2;
    }
    ans+=f[j];
  }
  printf("%lf\n",ans/(n*n));
}
