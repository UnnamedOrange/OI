#include<bits/stdc++.h>
using namespace std;
int n;
long long mo=998244353;
int rule[100];
int a[100];
bool vis[100];
int ans;
long long jc(){
	long long suc=1;
	for(int i=2;i<=n;i++)
		suc*=i;
	return suc;
}
int dfs(int u,int sum){
	if(vis[u])
		return sum;
	vis[u]=1;
	return dfs(a[u],sum+1);
}
int check(){
	for(int i=1;i<=n;i++)
		vis[i]=0;
	for(int i=1;i<=n;i++){
		if(!vis[i])
			if(dfs(i,0)%2==1)
				return 0;
	}
	return 1;
}
void cFile(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
}
long long solve(){
	if(n%2==1){
		return 0;
	}
	bool p30=1;
	for(int i=1;i<=n;i++){
		a[i]=i;
		scanf("%d",&rule[i]);
		if(rule[i]) p30=0;
	}
	if(p30){
		long long pans=1;
		for(int i=2;i<n;i+=2){
			pans=(pans*(i+1)*(i+1))%mo;
		}
		return pans;
	}
	for(int i=1;i<=jc();i++){
		if(i!=1)
			next_permutation(a+1,a+1+n);
		bool flag=1;
		for(int j=1;j<=n;j++){
			if(rule[j]!=0&&rule[j]!=a[j]){
				flag=0;
				break;
			}
		}
		if(flag){
			ans+=check();
		}
	}
	return ans;
}
int main(){
	cFile();
	scanf("%d",&n);
	printf("%lld\n",solve());
	return 0;
}
