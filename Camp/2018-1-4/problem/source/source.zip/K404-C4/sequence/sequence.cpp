#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
struct node
{
	int hsh,x;
};
int t,n,a[25],ans;
void solve()
{
	queue<node> q;
	map<int,bool> mp;
	map<int,int> lst;
	mp.clear();
	while (!q.empty())
	{
		q.pop();
	}
	node x;
	for (int i=1;i<=n;i++)
	{
		x.hsh=x.hsh*10+a[i];
	}
	mp[x.hsh]=true;
	x.x=0;
	q.push(x);
	while (!q.empty())
	{
		x=q.front();
		q.pop();
		bool f=true;
		int tmp=x.hsh;
		//cout<<tmp<<" "<<x.x<<endl;
		//system("pause");
		//cout<<tmp<<endl;
		for (int i=n;i;i--)
		{
			//cout<<tmp%10<<" "<<i<<endl;
			if (tmp%10!=i)
			{
				f=false;
				break;
			}
			tmp/=10;
		}
		//system("pause");
		if (f)
		{
			printf("%d\n",x.x);
			return;
		}
		int w[25];
		tmp=x.hsh;
		int k=n;
		while (tmp)
		{
			w[k]=tmp%10;
			k--;
			tmp/=10;
		}
		for (int i=2;i<=n;i++)
		{
			tmp=0;
			for (int j=1;j<=i/2;j++)
			{
				swap(w[j],w[i+1-j]);
			}
			for (int j=1;j<=n;j++)
			{
				tmp=tmp*10+w[j];
			}
			for (int j=1;j<=i/2;j++)
			{
				swap(w[j],w[i+1-j]);
			}
			if (!mp[tmp])
			{
				//cout<<x.hsh<<" "<<tmp<<endl;
				//system("pause");
				mp[tmp]=true;
				q.push((node){tmp,x.x+1});
				lst[tmp]=x.hsh;
			}
		}
	}
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		if (n<=8)
		{
			solve();
			continue;
		}
		int k=n;
		ans=0;
		while (k)
		{
			while (a[k]==k && k)
			{
				k--;
			}
			if (!k)
			{
				break;
			}
			if (a[1]==k)
			{
				for (int i=1;i<=k/2;i++)
				{
					swap(a[i],a[k+1-i]);
				}
				ans++;
				continue;
			}
			int s1,s2;
			for (int i=1;i<=k;i++)
			{
				if (a[i]==k)
				{
					s1=i;
					break;
				}
			}
			int j=s1;
			while (a[j+1]+1==a[j] && j<k)
			{
				j++;
			}
			s2=j;
			for (int i=1;i<=s2/2;i++)
			{
				swap(a[i],a[s2+1-i]);
			}
			ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}
/*
5
6
4 2 3 1 5 6
6
5 6 1 3 2 4
8
8 6 1 3 2 4 5 7
8
8 1 6 5 7 4 3 2
8
8 1 3 6 5 4 7 2
*/
