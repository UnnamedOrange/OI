#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
#define rep(i,l,r) for(int i=l;i<=r;++i)
const int N=1e5+5,D=998244353;
ll mi(ll x,int y)
{
	ll ans=1;
	while(y)
	{
		if(y&1)ans=ans*x%D;
		x=x*x%D;y>>=1;
	}
	return ans;
}
int n,m,k;
int cnt[N],a[N];
void dfs(int n,int l,int r)
{
	if(!n)
	{
		rep(i,1,m)++cnt[a[i]];
		return ;
	}

	int mr=m-(n-1);
	rep(j,r+1,mr)
	{
		dfs(n-1,j,j);
		int i=j;
		while(--i>l)
		{
			++a[i];
			dfs(n-1,i,j);
		}
		while(++i<j)--a[i];
	}
}

int main()
{
	freopen("segment.in","r",stdin);freopen("segment.out","w",stdout);
	cin>>n>>m>>k;
	dfs(n,0,0);
	ll ans=0;
	rep(i,1,n)(ans+=mi(i,k)*cnt[i])%=D;
	cout<<ans;
}
