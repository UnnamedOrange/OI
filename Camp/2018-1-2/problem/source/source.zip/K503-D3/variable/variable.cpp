#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 1024

struct linking{
	int head[N],to[N],next[N],type[N],cnt;
	void insert(int x, int y, int z){
		to[++cnt]=y,next[cnt]=head[x],head[x]=cnt;
		type[cnt]=(z==0?1:0);
		to[++cnt]=x,next[cnt]=head[y],head[y]=cnt;
		type[cnt]=(z==0?2:0);
	}
}list;

int n,m,c,k,a[N][9],w[N],ans;

void dfs(int x){
	if (x>n){
		int s=0;
		for (int i=0;i<n;i++){
			s+=w[i+1];
			for (int j=0;j<3;j++){
				int t=w[a[i][j]]-w[a[i][(j+1)%3]];
				s+=a[i][j+3]*abs(t)+a[i][j+6]*t;
			}
		}
		if (s<ans) ans=s; return;
	}
	bool mark1=true,mark2=true;
	for (int i=list.head[x];i;i=list.next[i]){
		if (!list.type[i]&&w[list.to[i]])
  		    (w[list.to[i]]==1?mark1:mark2)=false;
		else if (list.type[i]==1&&w[list.to[i]]==-1)
			mark2=false;
		else if (list.type[i]==2&&w[list.to[i]]==1)
			mark1=false;
	}
	int t=w[x];
	if (mark1&&w[x]!=1) w[x]=-1,dfs(x+1),w[x]=t;
	if (mark2&&w[x]!=-1) w[x]=1,dfs(x+1),w[x]=t;
}

int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int t; scanf("%d",&t);
	while (t--){
		scanf("%d%d%d%d",&n,&k,&m,&c);
		for (int i=0;i<m;i++)
			for (int j=0;j<9;j++)
				scanf("%d",&a[i][j]);
		memset(w,0,sizeof(w)); list.cnt=0;
		memset(list.head,0,sizeof(list.head));
		for (int i=0;i<c;i++){
			int x,y,z; scanf("%d%d%d",&x,&y,&z);
			if (z==2) w[x]=-1,w[y]=1;
			else if (x!=y) list.insert(x,y,z);
		}
		ans=(int)1e10;
		dfs(1); printf("%lld\n",(long long)ans*k);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

