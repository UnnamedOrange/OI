#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<map>
#include<set>
#include<iomanip>
#include<ctime>
using namespace std;
typedef long long ll;
char xB[1<<15],*xT=xB,*xS=xB;
#define getchar() (xS==xT&&(xT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xT)?0:*xS++)
inline int read()
{
    int X=0,w=0; char ch=0;
    while(!isdigit(ch)) w|=ch=='-',ch=getchar();
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}
int n,m;
int to[1000010],nexl[1000010],edgecnt,head[1000010],dis[1000010];
int dfn[1000010],low[1000010],belong[1000010],num,sta[1000010],topp,tot,cnt[1000010],ans;
struct EDGE
{
	int to,nexl;
}edge[1000010];
int fro[1000010],ecnt;
void tarjan(int u)
{
	sta[++topp]=u;
	dfn[u]=low[u]=++tot;
	for(int i=head[u];i;i=nexl[i])
	{
		if(!dfn[to[i]])
		{
			tarjan(to[i]);
			low[u]=min(low[u],low[to[i]]);
		}
		else if(!belong[to[i]])low[u]=min(low[u],dfn[to[i]]);
	}
	if(dfn[u]==low[u])
	{
		int ppx;++num;
		while(topp!=0)
		{
			ppx=sta[topp];--topp;
			belong[ppx]=num;
			++cnt[num];
			if(ppx==u)break;
		}
	}
}
void addedge(int u,int v)
{
	edge[++ecnt]=(EDGE){v,fro[u]};
	fro[u]=ecnt;
}
int dp(int u)
{
	if(dis[u])return dis[u];
	else 
	{
		for(int i=fro[u];i;i=edge[i].nexl)
		{
			dis[u]=max(dis[u],dp(edge[i].to));
		}
		dis[u]+=cnt[u];
		return dis[u];
	}
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	register int j,i,a,b;
	n=read();m=read();
	for(i=1;i<=m;++i)
	{
		a=read();b=read();
		to[++edgecnt]=b;nexl[edgecnt]=head[a];head[a]=edgecnt;
	}
	for(i=1;i<=n;++i)if(!dfn[i])tarjan(i);
	for(i=1;i<=n;++i)
	{
		for(j=head[i];j;j=nexl[j])
		{
			if(belong[to[j]]!=belong[i])
			{
				addedge(belong[to[j]],belong[i]);
			}
		}
	}
	for(i=1;i<=num;++i)
	{
		ans=max(ans,dp(i));
	}
	printf("%d\n",ans);
}
