#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int P=998244353;
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
struct W{
	int to,nx;
}Lis[105];
int Head[55],tot;
void eAdd(int x,int y){
	Lis[++tot]=(W){y,Head[x]};
	Head[x]=tot;
}
int n,k;
struct SHUI{
	int S,bin[15];
	int rdfs(int x,int f){
		int re=bin[x];
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if((bin[to]&S)&&to!=f)
				re|=rdfs(to,x);
		return re;
	}
	int dfs(int SS,int d){
		int re=0;
		for(int i=0,tmp,sm,v;i<n;i++)
			if(bin[i]&SS){
				tmp=1;
				for(int j=Head[i],to;j&&(to=Lis[j].to,1);j=Lis[j].nx)
					if(bin[to]&SS){
						sm=0;
						S=SS;
						v=rdfs(to,i);
						for(int l=d+1;l<=k;l++)Add(sm,dfs(v,l));
						tmp=(long long)tmp*sm%P;
						if(tmp==0)break;
					}
				Add(re,tmp);
			}
		return re;
	}
	void solve(){
		for(int i=0;i<n;i++)bin[i]=(1<<i);
		int ans=0;
		for(int i=1;i<=k;i++)Add(ans,dfs((1<<n)-1,i));
		printf("%d\n",ans);
	}
}P30;
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1,x,y;i<n;i++)scanf("%d %d",&x,&y),x--,y--,eAdd(x,y),eAdd(y,x);
	P30.solve();
	
	return 0;
}
