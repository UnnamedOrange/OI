#include<cstdio>
#include<iostream>
#include<queue>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
#define ll long long
using namespace std;
const int N=1e5+5;
int point[N],dep[N],col[N],cnt;
bool used[N];
struct edge{
	int u,nxt;
}e[N<<1];
inline void add(int x,int y){
	e[++cnt].u=y;
	e[cnt].nxt=point[x];
	point[x]=cnt;
}
queue<int>q;
void bfs(){
	q.push(1);
	dep[1]=1;
	while(!q.empty()){
		int s=q.front();
		q.pop();
		for(int i=point[s];i;i=e[i].nxt)
			if(!dep[e[i].u]){
				q.push(e[i].u);
				dep[e[i].u]=dep[s]+1;
			}
	}
}
inline int query(int u,int l,int r){
	int ans=0;
	for(int i=l;i<=r;i++) used[i]=0;
	q.push(u);
	while(!q.empty()){
		int s=q.front();
		q.pop();
		if(!used[col[s]]&&col[s]>=l&&col[s]<=r){
			used[col[s]]=1;
			ans++;
		}
		for(int i=point[s];i;i=e[i].nxt)
			if(dep[e[i].u]>dep[s]) q.push(e[i].u);
	}
	return ans;
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int n,q,t,x,y,z,ans=0,tmp;
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++) scanf("%d",&col[i]);
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	bfs();
	while(q--){
		scanf("%d",&tmp);
		if(tmp==1){
			scanf("%d%d%d",&x,&y,&z);
			if(t==1) x^=ans,y^=ans,z^=ans;
			ans=query(x,y,z);
			printf("%d\n",ans);
		}
		if(tmp==2){
			scanf("%d%d",&x,&y);
			if(t==1) x^=ans,y^=ans;
			col[x]=y;
		}
	}
	return 0;
}
