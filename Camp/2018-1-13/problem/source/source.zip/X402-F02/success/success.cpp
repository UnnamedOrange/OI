#include<bits/stdc++.h>
using namespace std;
typedef long long sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
template<typename T>void write(T x,char y)
{
	if(x==0)
	{
		putchar('0');putchar(y);
		return;
	}
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	static char wr[20];
	int top=0;
	for(;x;x/=10)wr[++top]=x%10+'0';
	while(top)putchar(wr[top--]);
	putchar(y);
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("success.in","r",stdin);
		freopen("success.out","w",stdout);
	#endif
}
ll s,t,n,m;
const int mo=1e9+7,max_d=1e5;
void input()
{
	s=read<ll>();t=read<ll>();n=read<ll>();m=read<ll>();
}
ll power(ll x,ll y)
{
	ll res=1;x%=mo;
	for(;y;x=x*x%mo,y>>=1)if(y&1)res=res*x%mo;
	return res;
}
ll inv[N],mc[N];
ll C(ll n,ll m)
{
	if(n<m)return 0;
	return mc[n]*inv[m]%mo*inv[n-m]%mo;
}
void add(ll &a,ll b)
{
	a+=b;
	if(a>=mo)a-=mo;
}
ll S(ll n,ll m)
{
	if(n<m)return 0;
	ll f=1,res=0;
	For(k,0,m)
	{
		add(res,C(m,k)*power(m-k,n)%mo*f);
		f=-f;
	}
	return res*inv[m]%mo;
}
void init()
{
	mc[0]=inv[0]=1;
	For(i,1,max_d)mc[i]=mc[i-1]*i%mo;
	inv[max_d]=power(mc[max_d],mo-2);
	Fordown(i,max_d-1,1)inv[i]=inv[i+1]*(i+1)%mo;
}
ll dp[105][105];
void out()
{
	For(i,1,50)
	{
		dp[i][1]=dp[i][i]=1;
		For(j,2,i-1)
		{
			dp[i][j]=(dp[i-1][j-1]+dp[i-1][j]*j%mo)%mo;	
		}
	}
}
ll ans;
void work2()
{
	
}
void work1()
{
	dp[0][0]=1;
	For(i,1,m)For(j,i,s)
	{
		if(i<=n)
		{
			For(k,1,min(j,t))
			{
				add(dp[i][j],dp[i-1][j-k]);
			}
		}
		else
		{
			For(k,1,min(j,s))
			{
				add(dp[i][j],dp[i-1][j-k]);
			}
		}
	}
	For(i,m,s)
	{
		cout<<i<<' '<<dp[m][i]<<endl;
		add(ans,dp[m][i]);
	}
	write(ans,'\n');
}
int main()
{
	file();
	input();
	init();
	if(m<=100&&s<=100)work1();
	else work2(); 
	return 0;
}
