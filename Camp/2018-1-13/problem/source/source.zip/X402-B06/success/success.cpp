#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	#endif
}
static int s,t,n,m;
const int mod=1e9+7;
inline int add(int a,int b){return a+b<mod?a+b:a+b-mod;}
inline int tim(int a,int b)
{
    static int sum;
    for(sum=0;b;b>>=1,(a<<=1)%=mod)if(b&1)
        sum=sum+a<mod?sum+a:sum+a-mod;
    return sum;
}
inline void plu(int&a,int b){a+=b;if(a>mod)a-=mod;}
namespace subtask1//20pt
{
    int main()
    {
        static int ans=0,C[111][2011]={0},dp[2011][2011]={0};
        C[0][0]=1;
        Rep(i,1,s)Rep(j,0,i)
        {
            if(j==i||!j)C[i][j]=1;
            else C[i][j]=add(C[i-1][j],C[i-1][j-1]);
        }
        dp[0][0]=1;
        Rep(i,1,n)Rep(j,0,t*i)Rep(k,0,min(j,t-1))plu(dp[i][j],dp[i-1][j-k]);
        Rep(i,n,s)plu(ans,tim(dp[n][i-n],C[s-i][m-n]));
        printf("%d\n",ans);
        return 0;
    }
}
int main(void){
	file();
	read(s);read(t);read(n);read(m);
    if(s<=100)return subtask1::main();
    return 0;
}

