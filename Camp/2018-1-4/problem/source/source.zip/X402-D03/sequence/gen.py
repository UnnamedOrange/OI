import sys
from random import *

sys.stdout = open("sequence.in", "w")

T = 5
print(T)
while T > 0:
	T = T-1
	n = randint(5, 10)
	print(n)
	p = list(range(1, n+1))

	shuffle(p)

	for i in p:
		print(i, end= ' ')
	print()
