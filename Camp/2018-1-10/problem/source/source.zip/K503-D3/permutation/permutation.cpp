#include <cstdio>
#include <cstring>

#define p 998244353

int a[100100],f[100100],n,ans;
bool mark[20]={0},visit[20];

bool check(){
	memset(visit,0,sizeof(visit));
	for (int i=1;i<=n;i++)
		if (!visit[i]){
			int x=i,len=0;
			while (!visit[x])
				len++,visit[x]=true,x=a[x];
			if (len&1) return false;
		}
	return true;
}

void dfs(int x){
	if (x>n){
		ans+=check();
		if (ans>=p) ans-=p;
		return;
	}
	if (a[x]) dfs(x+1);
	else
		for (int i=1;i<=n;i++)
			if (!mark[i]){
				a[x]=i,mark[i]=true;
				dfs(x+1);
				a[x]=0,mark[i]=false;
			}
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n); int c=0; bool flag=false;
	for (int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if (a[i]) mark[a[i]]=true,c++;
		if (a[i]==i) flag=true;
	}
	if ((n&1)||flag) ans=0;
	else if (c<=1){
		n/=2; f[0]=1;
		for (int i=1;i<=n;i++)
			f[i]=1LL*f[i-1]*(i*2-1)%p;
		if (c==0) ans=1LL*f[n]*f[n]%p;
		else ans=1LL*f[n-1]*f[n-1]%p*(n*2-1)%p;
	}
	else dfs(1);
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

