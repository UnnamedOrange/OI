#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define K 501
#define N 100001
#define M 200001
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
const int mod=998244353;
int n,m,e,w[N],f[N][K],f2[2001][2001],c[K][K];
int cnt,head[N],nxt[M],to[M];
bool check,vis[N];
int mi(int a,int b)
{
	int res=1;
	while(b)
	{
		if(b&1)res=1ll*res*a%mod;
		a=1ll*a*a%mod;
		b>>=1;
	}
	return res;
}
void sol(int u)
{
	if(vis[u])return;
	vis[u]=1;
	int tmp[K]={};
	for(int i=head[u],v;i;i=nxt[i])
	{
		v=to[i];
		sol(v);
		if(check)
		{
			for(int j=1;j<=n;++j)
				f2[u][j]=(f2[u][j]+f2[v][j-1])%mod;
		}
		else
		{
			for(int j=0;j<=e;++j)
				tmp[j]=(tmp[j]+f[v][j])%mod;
		}
	}
	if(!check)
		for(int i=0;i<=e;++i)
			for(int j=0;j<=i;++j)
				f[u][i]=(f[u][i]+1ll*tmp[j]*c[i][j])%mod;
}
int main()
{
	open(xmasdag);
	re(n),re(m),re(e);
	check=(n<=2000 && m<=5000);
	for(int u,v,i=1;i<=m;++i)
	{
		re(u),re(v);
		add_edge(v,u);
	}
	for(int i=0;i<=e;++i)c[i][0]=1;
	for(int i=1;i<=e;++i)
		for(int j=1;j<=i;++j)
			c[i][j]=(c[i-1][j]+c[i-1][j-1])%mod;
	vis[1]=1;f2[1][0]=f[1][0]=1;
	for(int i=1;i<=n;++i)w[i]=mi(i,e);
	for(int i=1;i<=n;++i)
	{
		sol(i);
		if(i==1 && e==0)puts("1");
		else if(check)
		{
			int ans=0;
			for(int j=1;j<=n;++j)
				ans=(ans+1ll*f2[i][j]*w[j])%mod;
			printf("%d\n",ans);
		}
		else printf("%d\n",f[i][e]);
	}
}
