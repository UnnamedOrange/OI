#include<cstdio>
using namespace std;
#define N 1000006
#define LL long long
#define rep(i,j,k) for(i=j;i<=k;++i)
int n,m,i,j,k,tes,tot;
int prime[N],vis[N],mu[N];
LL ans[N],sum[N],f[N];
void read(int &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
}
void init(){
	mu[1]=1; 
	rep(i,2,1000000){
		if(!vis[i]) tot++,prime[tot]=i,mu[i]=-1;
		rep(j,1,tot){
			if(prime[j]*i>1000000) break ;
			vis[prime[j]*i]=1;
			if(!(i%prime[j])) {mu[i*prime[j]]=0; break ;}
			mu[i*prime[j]]=-mu[i];
		}
	}
	rep(i,1,1000000){
		for(j=i;j<=1000000;j+=i) {
			f[j]++;
		}
	}
	rep(i,1,1000000){
		ans[i]=ans[i-1]+f[i]*f[i]*sum[i];
	}
	read(tes);
	while(tes--){
		read(n);
		rep(i,1,n){
			for(j=i;j<=n;j+=i) {
				sum[i]+=mu[j/i];
			}
		}
		rep(i,1,n){
			ans[i]=ans[i-1]+f[i]*f[i]*sum[i];
		}
		rep(i,1,n)	sum[i]=0;
		printf("%lld\n",ans[n]);
	}
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	init();
	return 0;
}
