#include<bits/stdc++.h>
using namespace std;

const int maxn=4e3+10;
int n,m,k,a[maxn],b[maxn],afir[maxn][maxn],bfir[maxn][maxn];
int dp[maxn][maxn];

inline void chkmin(int&a,int b){
	if(a>b)a=b;
}

int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;++i)
		scanf("%d",&b[i]);
	for(int i=1;i<=k;++i)
		afir[n+1][i]=afir[n+2][i]=n+1,bfir[m+1][i]=bfir[m+2][i]=m+1;
	for(int i=n;i;--i){
		for(int j=1;j<=k;++j)
			afir[i][j]=afir[i+1][j];
		afir[i][a[i]]=i;
	}
	for(int i=m;i;--i){
		for(int j=1;j<=k;++j)
			bfir[i][j]=bfir[i+1][j];
		bfir[i][b[i]]=i;
	}
	memset(dp,100,sizeof(dp));
	dp[0][0]=0;
	for(int i=0;i<=n+1;++i)
		for(int j=0;j<=m+1;++j)
			for(int v=1;v<=k;++v)
				chkmin(dp[afir[i+1][v]][bfir[j+1][v]],dp[i][j]+1);
	printf("%d\n",dp[n+1][m+1]);
	return 0;
}
