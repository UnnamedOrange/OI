#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 20;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], to[MAXN<<1];
int nxt[MAXN<<1], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

ll ans;
int n, fa[MAXN], p[MAXN], w[MAXN];
bool cs[MAXN], r[MAXN];

void dfs(int u) {
	int i;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa[u]) continue;
		fa[v] = u, dfs(v);
	}
}

void solve(int u) {
	int i;
	if(u == n+1) {
		ll res = 0;
		for(i = 1; i <= n; i++) res += w[p[i]]*i;
		ans = max(ans, res);
		return;
	}
	for(i = 1; i <= n; i++) {
		if(cs[i]) continue;
		if(!cs[fa[i]]) continue;
		p[u] = i;
		cs[i] = true;
		solve(u+1);
		cs[i] = false;
	}
}

int main() {
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	
	int i;

	n = read();
	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		Add(u, v), Add(v, u);
	}

	for(i = 1; i <= n; i++) 
		w[i] = read(), r[i] = read();

	cs[0] = true;
	for(i = 1; i <= n; i++) {
		if(!r[i]) continue;
		fa[i] = 0, dfs(i);
		solve(1);
	}

	printf("%lld\n", ans);
	return 0;
}
