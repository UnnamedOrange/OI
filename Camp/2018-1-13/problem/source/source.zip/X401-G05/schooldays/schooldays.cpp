#include<bits/stdc++.h>
using namespace std;
const int kcz=1000000007;
const int m=1000500;
int dp[m],r[m],n,l[m],f[m];
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	 
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	  scanf("%d%d",&l[i],&r[i]);
	dp[0]=0;
	f[0]=1;
	for (int i=1;i<=n;i++)
	{
		int ma=n+1;
		int mi=0;
		for (int j=i;j>=1;j--)
		{
			ma=min(ma,r[j]);
			mi=max(mi,l[j]);
			if (((i-j+1)>=mi)&&((i-j+1)<=ma))
			{
				if (dp[i]==(dp[j-1]+1))
					f[i]=(f[i]+f[j-1])%kcz;
				if (dp[i]<(dp[j-1]+1))
				{
					dp[i]=dp[j-1]+1;
					f[i]=f[j-1];
				}
			}
		}
	}
	if (dp[n]==0) cout<<-1;
	else cout<<dp[n]<<' '<<f[n];
	
}
