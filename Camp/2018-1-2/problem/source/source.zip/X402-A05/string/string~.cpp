#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <string>

#define REP(i, t) for(int i = 0, i##E = (t); i < i##E; ++i)

template <class T> inline bool minimum(T &a, T b) {return a > b? a = b, 1 : 0;}
template <class T> inline bool maximum(T &a, T b) {return a < b? a = b, 1 : 0;}

using namespace std;

const int N = 1e5 + 10, inf = 1e9;

namespace brute_force
{
	int ans;

	void dfs_delete(string s, int step)
	{
		if(step >= ans) return ;

		int len = s.length();
		if(!len) return (void) (minimum(ans, step));

		REP(l, len)for(int r = l+1; r < len; ++r){
			bool flag = true;
			for(int i = l; i <= (r + l) >> 1; ++i)
				if(s[i] != s[r-i+l]) {flag = false; break;}
			if(flag) continue;
			string tmp = "";
			for(int i = 0; i < l; ++i) tmp.push_back(s[i]);
			for(int i = r + 1; i < len; ++i) tmp.push_back(s[i]);
			dfs_delete(tmp, step + 1);
		}
	}

	void main(string s)
	{
		ans = inf; dfs_delete(s, 0);
		printf("%d\n", ans >= inf? -1 : ans);
	}
}

namespace solver
{
	bool check(string s)
	{
		int len = s.length();
		for(int i = 0; i <= (len-1)/2; ++i)
			if(s[i] != s[len-1-i]) return false;
		return true;
	}

	void main(char *s)
	{
		int len = strlen(s);

		bool judge = true;
		for(int i = 0; i <= (len-1)/2; ++i)
			if(s[i] != s[len-1-i]) { judge = false; break; }
		if(!judge) puts("1");
		else{
			bool flag = false;
			for(int l = 0; l < len; ++l)
				for(int r = l+1; r < len; ++r){
					string s1 = "", s2 = "";
					for(int i = 0; i < l; ++i) s1.push_back(s[i]);
					for(int i = r + 1; i < len; ++i) s1.push_back(s[i]);
					for(int i = l; i <= r; ++i) s2.push_back(s[i]);
					if(!check(s1) && !check(s2)) { flag = true; break; }
				}
			puts(flag? "2" : "-1");
		}
	}
}

int n; char s[N];

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.ans", "w", stdout);

	int T; scanf("%d", &T);
	while(T--){
		scanf("%d", &n);
//		if(n <= 10){
			string tmp; cin >> tmp;
			brute_force::main(tmp);
//		}
//		else{
//			scanf("%s", s);
//			solver::main(s);
//		}
	}
	return 0;
}
