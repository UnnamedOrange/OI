#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <sstream>
#include <cctype>
#include <cmath>
#include <algorithm>
#define THE_BRST_PONY "Rainbow Dash"

using namespace std;

int T;

int main() {
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	scanf("%d",&T);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

