#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#define ele int
#define ll long long
using namespace std;
#define maxn 100010
#define maxm 200010
#define maxk 501
#define MOD 998244353
struct edge{
	ele v;
	edge *nxt;
}ep[maxm],*ecnt;
ele n,m,k,scnt,seq[maxn],f[maxn][maxk],C[maxk][maxk],ind[maxn];
edge *h[maxn];
queue<ele> Q;
inline void addedge(ele u,ele v){
	edge *p=ecnt++;
	p->v=v; p->nxt=h[u];
	h[u]=p;
}
int main(){
	freopen("xmasdag.in","r",stdin); freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	ecnt=ep; memset(h,0,sizeof(h));
	for (int i=0; i<m; ++i){
		ele x,y;
		scanf("%d%d",&x,&y);
		addedge(x-1,y-1);
		++ind[y-1];
	}
	memset(f[0],0,sizeof(f[0]));
	f[0][0]=1;
	memset(C,0,sizeof(C));
	for (int i=0; i<=k; ++i){
		C[i][0]=1;
		for (int j=1; j<=i; ++j) C[i][j]=(C[i-1][j-1]+C[i-1][j])%MOD;
	}
	for (int i=0; i<n; ++i)
		if (!ind[i]) Q.push(i);
	scnt=0;
	while (!Q.empty()){
		ele i=Q.front(); Q.pop();
		seq[scnt++]=i;
		for (edge *j=h[i]; j; j=j->nxt){
			--ind[j->v];
			if (!ind[j->v]) Q.push(j->v);
		}
	}
	for (int i=0; i<n-1; ++i){
		ele p=seq[i];
		for (edge *j=h[p]; j; j=j->nxt)
			for (int r=0; r<=k; ++r){
				ele tmp=f[p][r];
				for (int r1=0; r1<r; ++r1){
					ele t1=(ll)C[r][r1]*f[p][r1]%MOD;
					(tmp+=t1)%=MOD;
				}
				(f[j->v][r]+=tmp)%=MOD;
			}
	}
	for (int i=0; i<n; ++i) printf("%d\n",f[i][k]);
	return 0;
}