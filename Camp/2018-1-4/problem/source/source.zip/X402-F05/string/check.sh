while true;
do
	python gen.py
	./string
	./bf
	diff string.ans string.out || break
	echo '???'
done
echo '!!!'
