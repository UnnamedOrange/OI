#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=500005,mod=1e9+9;
int n,m;
int pos[maxn];
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
}
struct seg_tree{
	int sum[maxn<<2],tag[maxn<<2];
	void init(int p,int l,int r){
		tag[p]=1;
		if(l==r)return;
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		init(u,l,mid),init(v,mid+1,r);
	}
	void push_down(int p,int u,int v){
		if(tag[p]!=1){
			tag[u]=1ll*tag[u]*tag[p]%mod;
			tag[v]=1ll*tag[v]*tag[p]%mod;
			sum[u]=1ll*sum[u]*tag[p]%mod;
			sum[v]=1ll*sum[v]*tag[p]%mod;
			tag[p]=1;
		}
	}
	void push_up(int p,int u,int v){
		sum[p]=(sum[u]+sum[v])%mod;
	}
	void update1(int p,int l,int r,int pos,int val){
		if(l==r)return add(sum[p],val);
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		push_down(p,u,v);
		if(pos<=mid)update1(u,l,mid,pos,val);
		else update1(v,mid+1,r,pos,val);
		push_up(p,u,v);
	}
	void update2(int p,int l,int r,int L,int R){
		if((L<=l)&&(R>=r))return add(sum[p],sum[p]),add(tag[p],tag[p]);
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		push_down(p,u,v);
		if(L<=mid)update2(u,l,mid,L,R);
		if(R>mid)update2(v,mid+1,r,L,R);
		push_up(p,u,v);
	}
	int query(int p,int l,int r,int L,int R){
		if((L<=l)&&(R>=r))return sum[p];
		int mid=(l+r)>>1,u=p<<1,v=u+1,res=0;
		push_down(p,u,v);
		if(L<=mid)add(res,query(u,l,mid,L,R));
		if(R>mid)add(res,query(v,mid+1,r,L,R));
		push_up(p,u,v);
		return res;
	}
}T;
struct segment{
	int l,r;
	bool operator < (const segment &A) const {
		return l<A.l;
	}
}s[maxn];
int tot;
vector<int>G[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n)s[i].l=read(),s[i].r=read();
	REP(i,1,m)pos[i]=read();
	sort(pos+1,pos+1+m);
	m=unique(pos+1,pos+1+m)-pos-1;
	REP(i,1,n){
		s[i].l=lower_bound(pos+1,pos+1+m,s[i].l)-pos;
		s[i].r=upper_bound(pos+1,pos+1+m,s[i].r)-pos-1;
	}
	sort(s+1,s+1+n);
	REP(i,1,n){
		if((s[i].r==0)||(s[i].l==m+1))++tot;
		else G[s[i].r].push_back(s[i].l);
	}
	T.init(1,0,m);
	T.update1(1,0,m,0,1);
	REP(i,1,m)
		REP(j,0,G[i].size()-1){
			int tmp=0;
			add(tmp,T.query(1,0,m,G[i][j]-1,i));
//			cout<<G[i][j]<<' '<<i<<' '<<tmp<<endl;
			T.update1(1,0,m,i,tmp);
			if(G[i][j]>=2)T.update2(1,0,m,0,G[i][j]-2);
		}
	int ans=T.query(1,0,m,m,m);
	REP(i,1,tot)add(ans,ans);
	write(ans,'\n');
	return 0;
}
