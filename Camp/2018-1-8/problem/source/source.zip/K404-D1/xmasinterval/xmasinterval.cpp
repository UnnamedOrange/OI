#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define N 500010
#define M 500010
#define ll long long
#define mod 1000000009
using namespace std;
int n,m;
int x[M];
struct Edge
{
    int l,r;
} e[N];
struct Segment_Tree
{
    int add,mul=1;
} data[M<<2];
bool operator<(const Edge &x,const Edge &y)
{
    if(x.l==y.l)
        return x.r<y.r;
    else return x.l<y.l;
}
void pushdown(int x)
{
    if(data[x].mul>1)
    {
        data[x<<1].add=(ll)data[x<<1].add*data[x].mul%mod;
        data[x<<1|1].add=(ll)data[x<<1|1].add*data[x].mul%mod;
        data[x<<1].mul=(ll)data[x<<1].mul*data[x].mul%mod;
        data[x<<1|1].mul=(ll)data[x<<1|1].mul*data[x].mul%mod;
        data[x].mul=1;
    }
    if(data[x].add)
    {
        data[x<<1].add+=data[x].add;
        if(data[x<<1].add>=mod)
            data[x<<1].add-=mod;
        data[x<<1|1].add+=data[x].add;
        if(data[x<<1|1].add>=mod)
            data[x<<1|1].add-=mod;
        data[x].add=0;
    }
}
int query(int x,int l,int r,int pos)
{
    if(l==r)
        return data[x].add;
    pushdown(x);
    int mid=(l+r)>>1;
    if(pos<=mid)
        return query(x<<1,l,mid,pos);
    else return query(x<<1|1,mid+1,r,pos)%mod;
}
void modify1(int x,int l,int r,int a,int b,int v)
{
    if(a<=l&&r<=b)
    {
        data[x].add+=v;
        if(data[x].add>=mod)
            data[x].add-=mod;
        return;
    }
    pushdown(x);
    int mid=(l+r)>>1;
    if(a<=mid)
        modify1(x<<1,l,mid,a,b,v);
    if(b>mid)
        modify1(x<<1|1,mid+1,r,a,b,v);
}
void modify2(int x,int l,int r,int a,int b)
{
    if(a<=l&&r<=b)
    {
        data[x].add<<=1;
        if(data[x].add>=mod)
            data[x].add-=mod;
        data[x].mul<<=1;
        if(data[x].mul>=mod)
            data[x].mul-=mod;
        return;
    }
    pushdown(x);
    int mid=(l+r)>>1;
    if(a<=mid)
        modify2(x<<1,l,mid,a,b);
    if(b>mid)
        modify2(x<<1|1,mid+1,r,a,b);
}
int found_l(int v)
{
    int l=1,r=m,ret=0;
    while(l<=r)
    {
        int mid=(l+r)>>1;
        if(x[mid]<=v)
            ret=mid,l=mid+1;
        else r=mid-1;
    }
    return ret;
}
int found_r(int v)
{
    int l=1,r=m,ret=m+1;
    while(l<=r)
    {
        int mid=(l+r)>>1;
        if(x[mid]>=v)
            ret=mid,r=mid-1;
        else l=mid+1;
    }
    return ret;
}
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("xmasinterval.in","r",stdin);
    freopen("xmasinterval.out","w",stdout);
    n=read(),m=read();
    for(int i=1; i<=n; i++)
        e[i].l=read(),e[i].r=read();
    for(int i=1; i<=m; i++)
        x[i]=read();
    sort(&x[1],&x[m+1]);
    sort(&e[1],&e[n+1]);
    modify1(1,0,m,0,0,1);
    for(int i=1; i<=n; i++)
    {
        int l=found_r(e[i].l),r=found_l(e[i].r);
        modify2(1,0,m,0,l-1);
        if(l<=r)
            modify1(1,0,m,l,r,query(1,0,m,l-1));
    }
    printf("%lld",(ll)query(1,0,m,m)*500000005%mod);
    return 0;
}
