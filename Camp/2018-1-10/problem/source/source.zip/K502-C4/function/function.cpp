#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;

int T,n;
int d[1000005],top;
long long ans;
const long long p[11]={0,2,6,30,210,2310,30030,510510,9699690,223092870,6469693230};

void set_d(int x)
{
	memset(d,0,sizeof d); top=1; d[1]=1;
	if(x==1) return;
	for(int i=2;i<=sqrt(x);i++)
	{
		if(x%i==0)
		{
			if(x/i==i) d[++top]=i;
			else
			{
				d[++top]=i;
				d[++top]=x/i;
			}
		}
	}
	d[++top]=x;
	sort(d+1,d+top+1);
}

long long calcu(int k)
{
	long long sum=2;
	if(k==1) return 1;
	for(int i=2;i<=sqrt(k);i++)
	{
		if(k%i==0)
		{
			if(k/i==i) sum++;
			else sum+=2;
		}
	}
	return sum;
}

bool judge(int x)
{
	
	for(int k=1;k<=10;k++)
		if(x==p[k])
			if(k%2==1) return true;
	return false;
	
	/*
	if(x&1==0)
	{
		int t=x/2;
		if(t&1==0) return false;
		else if(prime(t)) return true;
		else return false;
	}
	for()
	*/
}

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		ans=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			set_d(i);
			for(int j=1;j<=top;j++)
			{
				int x=d[j];
				int u=0;//u(x)
				if(x==1) u=1;
				else if(judge(x)) u=-1;
				long long omega=calcu(i/x);
				ans+=u*omega*omega;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
