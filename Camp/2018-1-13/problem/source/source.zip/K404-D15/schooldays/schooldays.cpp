#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 1000005
const int mod=1e9+7,inf=1e9;

int n;
int c[maxn],d[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

namespace task1{
	struct state{
		int f,g; state(){} state(int _f,int _g){f=_f,g=_g;}
		state operator +(const state &a){
			if (f>a.f) return *this;
			else if (f<a.f) return a;
			else return state(f,(g+a.g)%mod);
		}
	}dp[maxn];
	void solve(){
		dp[0]=state(0,1);
		for (int i=1;i<=n;i++) dp[i]=state(-inf,0);
		for (int i=1;i<=n;i++){
			int mn=i-d[i],mx=i-c[i];
			for (int j=i-1;~j;j--){
				if (j<mn) break;
				if (j>=mn&&j<=mx) dp[i]=dp[i]+state(dp[j].f+1,dp[j].g);
				mn=max(mn,i-d[j]),mx=min(mx,i-c[j]);
			}
		}
		dp[n].f<=-inf?puts("-1"):printf("%d %d\n",dp[n].f,dp[n].g);
	}
}

namespace task2{
	struct state{
		int f,g; state(){} state(int _f,int _g){f=_f,g=_g;}
		state operator +(const state &a){
			if (f>a.f) return *this;
			else if (f<a.f) return a;
			else return state(f,(g+a.g)%mod);
		}
		bool operator <(const state &a)const{return f<a.f;}
	}dp[maxn];
	struct segment_tree{
		state tree[maxn*4];
		void change(int p,int l,int r,int x){
			if (l==r){tree[p]=dp[x]; return;}
			int mid=(l+r)>>1;
			if (x<=mid) change(p<<1,l,mid,x);
			else change(p<<1|1,mid+1,r,x);
			tree[p]=tree[p<<1]+tree[p<<1|1];
		}
		state query(int p,int l,int r,int x,int y){
			if (x<=l&&r<=y) return tree[p];
			int mid=(l+r)>>1; state ret(-inf,0);
			if (x<=mid) ret=ret+query(p<<1,l,mid,x,y);
			if (y>mid) ret=ret+query(p<<1|1,mid+1,r,x,y);
			return ret;
		}
	}T;
	int f[22][maxn],g[22][maxn],Log[maxn];
	int query_c(int l,int r){
		int x=Log[r-l+1];
		return max(f[x][l],f[x][r-(1<<x)+1]);
	}
	int query_d(int l,int r){
		int x=Log[r-l+1];
		return min(g[x][l],g[x][r-(1<<x)+1]);
	}
	void solve(){
		for (int i=2;i<=n;i++) Log[i]=Log[i>>1]+1;
		for (int i=1;i<=n;i++) f[0][i]=c[i];
		for (int i=1;i<=Log[n];i++)
			for (int j=1;j+(1<<i)-1<=n;j++)
				f[i][j]=max(f[i-1][j],f[i-1][j+(1<<(i-1))]);
		for (int i=1;i<=n;i++) g[0][i]=d[i];
		for (int i=1;i<=Log[n];i++)
			for (int j=1;j+(1<<i)-1<=n;j++)
				g[i][j]=min(g[i-1][j],g[i-1][j+(1<<(i-1))]);
		int l=0,r=-1;
		dp[0]=state(0,1),T.change(1,0,n,0);
		for (int i=1;i<=n;i++){
			while (r+1<i){
				int mn=i-query_d(r+2,i),mx=i-query_c(r+2,i);
				if (r+1>=mn&&r+1<=mx) ++r;
				else break;
			}
			while (l<=r){
				int mn=i-query_d(l+1,i),mx=i-query_c(l+1,i);
				if (l>=mn&&l<=mx) break;
				else ++l;
			}
			state res(-inf,0);
			if (l<=r) res=T.query(1,0,n,l,r),++res.f;
			dp[i]=res,T.change(1,0,n,i);
		}
		dp[n].f<=-inf?puts("-1"):printf("%d %d\n",dp[n].f,dp[n].g);
	}
}

int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++) c[i]=read(),d[i]=read();
	if (n<=2000) task1::solve();
	else task2::solve();
	return 0;
}
