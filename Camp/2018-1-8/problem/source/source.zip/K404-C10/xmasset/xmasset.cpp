#include <cstdio>
using namespace std;
inline int rd()
{
	char ch=getchar();int ret=0;
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9') ret=(ret<<3)+(ret<<1)+ch-'0',ch=getchar();
	return ret;
}
int main()
{
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	int t=rd(),n=rd(),q=rd(),x,y,i;
	while (q--){
		x=rd();y=rd();
		if (t==1){
		int cnt1=0,cnt2=0;
		for (i=0;i<10;i++) if (x&(1<<i)) cnt1++;
		for (i=0;i<10;i++) if (y&(1<<i)) cnt2++;
		if (cnt1!=cnt2) printf("%d\n",cnt1);
		else for (i=0;i<10;i++) if ((x&(1<<i))&&!(y&(1<<i))) printf("%d\n",i+10); 
		}
		else{
		int cnt=0;
		for (i=0;i<10;i++) if (x&(1<<i)) cnt++;
		if (y<=9&&cnt==y||y>9&&(x&(1<<y-10))) puts("yes");else puts("no");
		}
	}
	return 0;
}
