#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=1e9+9;
const int N=500050;
int n,m,p[N],nn,tot,b[N];
pii q[N],qu[N];
bool vis[N];

void wj()
{
	freopen("xmasinterval.in","r",stdin);
	//freopen("xmasinterval.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read(); m=read();
	for(i=1;i<=n;++i) qu[i].fi=read(),qu[i].se=read();
	for(i=1;i<=m;++i) p[i]=read(),b[++tot]=p[i];
	sort(b+1,b+1+tot);
	tot=unique(b+1,b+1+tot)-(b+1);
	int unuse=0;
	for(i=1;i<=n;++i)
	{
		qu[i].fi=lower_bound(b+1,b+1+tot,qu[i].fi)-b;
		qu[i].se=upper_bound(b+1,b+1+tot,qu[i].se)-b-1;
		if(qu[i].fi>qu[i].se) unuse++;
		else q[++nn]=qu[i];
	}
	//for(i=1;i<=m;++i) p[i]=lower(b,tot,p[i]),vis[p[i]]=1;

	n=nn;
	//sort(q+1,q+1+n,cmp);
	int all=1<<n,ans=0;
	for(int s=0;s<all;++s)
	{
		for(i=1;i<=tot;++i) vis[i]=0;
		for(i=1;i<=n;++i) if(s&(1<<i-1))
		{
			for(j=q[i].fi;j<=q[i].se;++j) vis[j]=1;
		}
		bool can=1;
		for(i=1;i<=tot;++i) if(!vis[i]) {can=0;break;}
		ans+=can;
	}
	printf("%d\n",ans*(1<<unuse));
	return 0;
}
