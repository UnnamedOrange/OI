#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<cmath>
using namespace std;
struct lxy{
	int to,next;
}b[200005];

int n,m,k;
int const mod=998244353;
int gree[100005];
long long way[100005];
long long f[100005];
long long c[2005][2005];
queue <int> topu;
queue <int> a;
int cnt,head[100005],p[2005],q[2005];

void add(int op,int ed)
{
	cnt++;
	b[cnt].next=head[op];
	b[cnt].to=ed;
	head[op]=cnt;
}

long long quick(long long x,long long e)
{
	if(e==1) return x%mod;
	if(e%2==0) return quick((x*x)%mod,e/2);
	else return (quick((x*x)%mod,e/2)*x)%mod;
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)head[i]=-1;
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		gree[y]++;
	}
	topu.push(1);
	while(!topu.empty())
	{
		int now=topu.front();
		topu.pop();
		a.push(now);
		for(int i=head[now];i!=-1;i=b[i].next)
		  if(--gree[b[i].to]==0)
		    topu.push(b[i].to);
	}
	way[1]=1;
	if(k==1)
	{
		while(!a.empty())
			{
			int now=a.front();
			a.pop();
			for(int i=head[now];i!=-1;i=b[i].next)
			{
				way[b[i].to]=(way[b[i].to]+way[now])%mod;
				f[b[i].to]=(f[b[i].to]+way[now]+f[now])%mod;
			}
	    }
	    for(int i=1;i<=n;i++)
	      printf("%d\n",f[i]);
	    return 0;
	}
	c[1][0]=1;p[1]=0;
	for(int i=1;i<=n;i++)
	  q[i]=quick(i,k);
	while(!a.empty())
	{
		int now=a.front();
		a.pop();
		for(int i=head[now];i!=-1;i=b[i].next)
		{
			for(int j=0;j<=p[now];j++)
			  c[b[i].to][j+1]=(c[b[i].to][j+1]+c[now][j])%mod;
			p[b[i].to]=max(p[now]+1,p[b[i].to]);
		}
		for(int i=1;i<=p[now];i++)
		  f[now]=(f[now]+c[now][i]*q[i])%mod;
    }
    for(int i=1;i<=n;i++)
	    printf("%d\n",f[i]);
	return 0;
}
