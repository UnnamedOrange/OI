#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int maxn = 1e+6 + 10;
const int mod = 1e+9 + 7;

ll fac[maxn],rfac[maxn];
ll s,t,n,m;

inline ll qpow(ll a,ll x)
{
	ll ans=1;
	for(;x;x>>=1,a=a*a%mod) if(x&1) ans=ans*a%mod;
	return ans;
}
inline ll C(ll n,ll r)
{
	if(r>n || r<0 || n<0) return 0;
	return fac[n]*rfac[r]%mod*rfac[n-r]%mod;
}
inline ll MOD(ll x){return x<mod?x:x-mod;}

ll pre()
{
	fac[0]=1;
	for(ll i=1;i<maxn;i++) fac[i]=fac[i-1]*i%mod;
	rfac[maxn-1]=qpow(fac[maxn-1],mod-2);
	for(ll i=maxn-2;i>=0;i--) rfac[i]=rfac[i+1]*(i+1)%mod;
}

void input(){cin>>s>>t>>n>>m;}

void solve()
{
	ll i,ans=0;
	
	for(i=0;i<=n;i++)
	{
		ans=MOD(ans+MOD(C(s-i*t,m)*C(n,i)*(i&1?-1:1)%mod+mod));
	}
	cout<<ans;
}

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	
	pre();
	input();
	solve();
	
	return 0;
}
