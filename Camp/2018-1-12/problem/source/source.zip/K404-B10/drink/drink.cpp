#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <deque>
#include <map>
#include <set>
#include <bitset>
#include <list>
typedef int INT;
using std::cin;
using std::cout;
using std::endl;
INT readIn()
{
	INT a = 0;
	bool minus = false;
	char ch = getchar();
	while (!(ch == '-' || (ch >= '0' && ch <= '9'))) ch = getchar();
	if (ch == '-')
	{
		minus = true;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9')
	{
		a = a * 10 + (ch - '0');
		ch = getchar();
	}
	if (minus) a = -a;
	return a;
}
void printOut(INT x)
{
	char buffer[20];
	INT length = 0;
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	do
	{
		buffer[length++] = x % 10 + '0';
		x /= 10;
	}
	while (x);
	do
	{
		putchar(buffer[--length]);
	}
	while (length);
}

const INT maxn = INT(1e6) + 5;
INT n;
INT w[maxn];

#define RunInstance(x) delete new x
struct brute1
{
	static const INT maxN = 1505;
	INT buf[maxN];
	
	brute1()
	{
		double sum = 0;
		for(int i = 1; i <= n; i++)
		{
			for(int j = i; j <= n; j++)
			{
				buf[0] = 0;
				for(int k = i; k <= j; k++)
					buf[++buf[0]] = w[k];
				std::sort(buf + 1, buf + 1 + buf[0]);
				double cnt = 0;
				for(int k = 1; k <= buf[0]; k++)
					cnt = (cnt + buf[k]) / 2;
				sum += cnt;
			}
		}
		printf("%.8f", sum / (n * n));
	}
};
struct brute2
{
	static const INT maxN = 1505;
};
struct work
{
	
};

void run()
{
	n = readIn();
	for(int i = 1; i <= n; i++)
		w[i] = readIn();

	if(n <= brute1::maxN)
		RunInstance(brute1);
	else if(n <= brute2::maxN)
		RunInstance(brute2);
	else
		RunInstance(work);
}

int main()
{
#ifndef LOCAL
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
#endif
	run();
	return 0;
}
