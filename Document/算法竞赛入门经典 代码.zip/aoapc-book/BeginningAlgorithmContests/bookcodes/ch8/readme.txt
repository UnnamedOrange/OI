第八章 高效算法设计

* 最大连续和合集 seq.c(C语言), seq.cpp(C++语言)
* 归并排序       merge_sort.c(含测试代码)
* 逆序对统计     inverse_pair.c
* 二分查找       bsearch.c(递归), bsearch2.c(迭代), lbub.c(上界/下界)
* 范围统计       range.cpp(STL)
* 贷款           loan.c
