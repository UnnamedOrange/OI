#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
const int maxn=100010;
const int mod=998244353;
int n,m,k,rd[maxn],o[maxn],st[maxn];
ll mi[maxn],f[2010][2010],h[maxn],ans[maxn];
int read()
{
	char ch=getchar();
	int x=0;
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	return x;
}
ll ksm(ll a,int b){ll r=1;for(;b;b>>=1){if(b&1)r=r*a%mod;a=a*a%mod;}return r;}
struct edge
{
	int t;
	edge *next;
}*con[maxn];
void ins(int x,int y)
{
	edge *p=new edge;
	p->t=y;
	p->next=con[x];
	con[x]=p;
}
void tuopu()
{
	int top=0;
	for(int i=1;i<=n;i++) if(!rd[i]) st[++top]=i;
	for(int i=1;i<=n;i++)
	{
		o[i]=st[top--];
		for(edge *p=con[o[i]];p;p=p->next)
		{
			rd[p->t]--;
			if(!rd[p->t]) st[++top]=p->t;
		}
	}
}
void spc()
{
	h[1]=1;
	for(int i=1;i<=n;i++)
		for(edge *p=con[o[i]];p;p=p->next)
			(h[p->t]+=h[o[i]])%=mod,(ans[p->t]+=h[o[i]]+ans[o[i]])%=mod;	
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read();m=read();k=read();
	//cout<<n<<' '<<m<<' '<<k<<endl;
	for(int i=0;i<=n;i++)
		mi[i]=ksm(i,k);
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();
		ins(x,y);rd[y]++;
	}
	tuopu();	
	if(k==1) spc();
	else 
	{
		f[1][0]=1;
		for(int i=1;i<=n;i++)
			for(edge *p=con[o[i]];p;p=p->next)
				for(int j=1;j<=n;j++)
					(f[p->t][j]+=f[o[i]][j-1])%=mod;
		for(int i=1;i<=n;i++)
			for(int j=0;j<=n;j++)
				(ans[i]+=f[i][j]*mi[j])%=mod;					
	}
	for(int i=1;i<=n;i++)
		printf("%lld\n",ans[i]);
	return 0;
}
/*6 8 500
1 2
1 3
1 5
2 4
3 2
3 4
3 6
4 6*/
