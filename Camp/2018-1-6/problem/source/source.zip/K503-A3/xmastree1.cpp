#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
#define pr pair<int, int>
#define x first
#define y second
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while (!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while (isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n *= sign;
}
typedef long long ll;
typedef set<int>::iterator iter;
const int INF = 1e9 + 7;
const int N = 52222;
int n, q, t, dfntt, l, r, x, y, opt, tt(1);
int c[N], d[N], dfn[N], sz[N], rk[N];
struct edge{int to, nxt;} g[N*2];
int ghead[N], gtail;
struct seg_tr{int lc, rc; bitset<N> v;} tr[N*2];
bitset<N> f[22];

void add(int l, int r){g[++gtail] = (edge){r, ghead[l]}, ghead[l] = gtail;}
void dfs(int x, int fa){
	dfn[x] = ++dfntt, rk[dfntt] = x, sz[x] = 1;
	for (int p = ghead[x]; p; p = g[p].nxt){
		int v = g[p].to; if (v == fa) continue;
		dfs(v, x), sz[x] += sz[v];
	}
}
#define mid ((l + r) >> 1)
void update(int x){tr[x].v = tr[tr[x].lc].v | tr[tr[x].rc].v;}
void build(int x, int l, int r){
	if (l == r){tr[x].v[d[l]] = 1; return ;}
	tr[x].lc = ++tt, build(tt, l, mid), tr[x].rc = ++tt, build(tt, mid + 1, r);
	update(x);
}
void modify(int x, int l, int r, int p, int q, int k){
	if (l == r){tr[x].v[q] = k; return ;}
	if (p <= mid) modify(tr[x].lc, l, mid, p, q, k);
	else modify(tr[x].rc, mid + 1, r, p, q, k); update(x);
}
bitset<N> query(int x, int l, int r, int nl, int nr){
	if (nl <= l&&r <= nr) return tr[x].v;
	bitset<N> ans = 0;
	if (nl <= mid) ans |= query(tr[x].lc, l, mid, nl, nr);
	if (mid <  nr) ans |= query(tr[x].rc, mid + 1, r, nl, nr);
	return ans;
}
#undef mid
bitset<N> get(int x){
	bitset<N> ret = 0;
	for (int i = 20; i >= 0; --i)
		if (x - (1 << i) >= 0) ret = (ret << (1 << i)) | f[i];
	return ret;
}

int main(){
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	read(n), read(q), read(t);
	rep(i, 1, n) read(c[i]);
	rep(i, 1, n - 1) read(l), read(r), add(l, r), add(r, l);
	dfs(1, 0);
	rep(i, 1, n) d[dfn[i]] = c[i];
	f[0] = 1; rep(i, 1, 20) f[i] = (f[i-1] << (1 << i-1)) | f[i-1];
	build(1, 1, n);
	int lastans = 0;
	while(q--){
		read(opt);
		if (opt == 1){
			read(x), read(l), read(r);
			if (t) x ^= lastans, l ^= lastans, r ^= lastans;
			int s = dfn[x], t = dfn[x] + sz[x] - 1;
			bitset<N> cnt = query(1, 1, n, s, t);
//			rep(i, 1, n) cerr << cnt[i]; cerr << endl;
			bitset<N> p = get(r) ^ get(l - 1);
			printf("%d\n", lastans = (cnt & p).count());
		} else {
			read(x), read(y);
			if (t) x ^= lastans, y ^= lastans;
			modify(1, 1, n, dfn[x], d[x], 0);
			d[x] = y;
			modify(1, 1, n, dfn[x], y, 1);
		}
	}
	return 0;
}
