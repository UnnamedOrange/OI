#include <cstdio>
#define ll long long
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int M=1e5+5,N=351,mod=998244353;
int n,m,k,i,j,a[N],f1[351][41][41][41],f2[M][4][4];
int quickmi(int a,int n)
{
	int ret=1,bsc=a;
	for (;n>0;n>>=1,bsc=(ll)bsc*bsc%mod)
	  if (n&1) ret=(ll)ret*bsc%mod;
	return ret;
}
int dfs1(int x,int need,int lft,int fl)
{
	int tmp,flag=0;
	if (x>m) {
		if (need==0 && lft==0) return 0;
		return -1;
	}
	if (f1[x][need][lft][fl]) return f1[x][need][lft][fl];
    int ret=0;
	if (need>0) {
	  tmp=dfs1(x+1,need-1,lft+1,fl+1);
	  if (tmp!=-1) ret+=tmp+a[fl+1],flag=1;
    }
	if (lft>0) {
	  tmp=dfs1(x+1,need,lft-1,fl-1);
      if (tmp!=-1) ret+=tmp+a[fl-1],flag=1;
	}
	tmp=dfs1(x+1,need-1,lft,fl);
	if (tmp!=-1) ret+=tmp+a[fl],flag=1;
    tmp=dfs1(x+1,need,lft,fl);
    if (tmp!=-1) ret+=tmp,flag=1;
    if (flag==0) ret=-1;
    f1[x][need][lft][fl]=ret;
	return ret;
}
int dfs2(int x,int need,int lft,int fl,int s)
{

}
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	rep(i,1,n) a[i]=quickmi(i,k);
	if (n>m) { printf("0\n"); return 0;}
	if (n<1000) {
	  dfs1(1,n,0,0);
      printf("%d\n",f1[1][n][0][0]);
	}
	else {
	  dfs2(1,n,0,0,0);
	  printf("%d\n",f2[1][n][0]);
    }
	return 0;
}
