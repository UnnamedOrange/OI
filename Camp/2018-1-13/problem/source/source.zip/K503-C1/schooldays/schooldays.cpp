# include <bits/stdc++.h>
# define 	N 		1000100
# define 	inf 	1e9
# define 	P 		1000000007
using namespace std;
struct node{
	int pl,pr,mn,mx,mxid,ans,ansnum,l,r;
}T[N*3];
int c[N],d[N],g[N],f[N],num[N],place,rt,nowans,nownum,n,ti;
int read(){
	int tmp=0,fh=1; char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') fh=-1; ch=getchar();}
	while (ch>='0'&&ch<='9'){tmp=tmp*10+ch-'0'; ch=getchar();}
	return tmp*fh;
}
int build(int l, int r){
	int p=++place; T[p].l=l; T[p].r=r;
	T[p].ans=-inf; T[p].ansnum=0;
	if (l==r){ T[p].mn=d[l]; T[p].mx=c[l]; T[p].mxid=l;}
	else {
		int mid=(T[p].l+T[p].r)>>1;
		T[p].pl=build(l,mid); T[p].pr=build(mid+1,r);
		T[p].mn=min(T[T[p].pl].mn,T[T[p].pr].mn); T[p].mx=max(T[T[p].pl].mx,T[T[p].pr].mx);
		if (T[p].mx==T[T[p].pl].mx) T[p].mxid=T[T[p].pl].mxid; else T[p].mxid=T[T[p].pr].mxid;
	}
	return p;
}
int querymin(int p, int l, int r){
	if (T[p].l==l&&T[p].r==r) return T[p].mn;
	int mid=(T[p].l+T[p].r)>>1;
	if (r<=mid) return querymin(T[p].pl,l,r);
		else if (l>mid) return querymin(T[p].pr,l,r);
			else return min(querymin(T[p].pl,l,mid),querymin(T[p].pr,mid+1,r));
}
int query_max_id(int p, int l, int r){
	if (T[p].l==l&&T[p].r==r) return T[p].mxid;
	int mid=(T[p].l+T[p].r)>>1;
	if (r<=mid) return query_max_id(T[p].pl,l,r);
		else if (l>mid) return query_max_id(T[p].pr,l,r);
			else {
				int now1=query_max_id(T[p].pl,l,mid), now2=query_max_id(T[p].pr,mid+1,r);
				if (c[now1]>=c[now2]) return now1; else return now2;
			}
}
void modify(int p, int x, int ans, int ansnum){
	if (T[p].l==T[p].r){T[p].ans=ans; T[p].ansnum=ansnum; return;}
	int mid=(T[p].l+T[p].r)>>1;
	if (mid>=x) modify(T[p].pl,x,ans,ansnum); else modify(T[p].pr,x,ans,ansnum);
}
void modify_tag(int p, int l, int r, int ans, int ansnum){
	if (T[p].l==l&&T[p].r==r){
		if (T[p].ans<ans) T[p].ans=ans, T[p].ansnum=0;
		if (T[p].ans==ans) {
			T[p].ansnum=(T[p].ansnum+ansnum);
			if (T[p].ansnum>P) T[p].ansnum-=P;
		}
		return;
	}
	int mid=(T[p].l+T[p].r)/2;
	if (mid>=r) modify_tag(T[p].pl,l,r,ans,ansnum);
		else if(mid<l) modify_tag(T[p].pr,l,r,ans,ansnum);
			else {modify_tag(T[p].pl,l,mid,ans,ansnum); modify_tag(T[p].pr,mid+1,r,ans,ansnum);};
}
void query_tag(int p, int x){
	if (T[p].ans>f[x]) f[x]=T[p].ans, num[x]=0;
	if (T[p].ans==f[x]) {
		num[x]=(num[x]+T[p].ansnum);
		if (num[x]>P) num[x]-=P;
	}
	if (T[p].l==T[p].r) return;
	int mid=(T[p].l+T[p].r)>>1;
	if (mid>=x) query_tag(T[p].pl,x); else query_tag(T[p].pr,x);
}
void getans(int p, int l, int r){
	if (T[p].l==T[p].r){
		if (T[p].ans>nowans) nowans=T[p].ans, nownum=0;
		if (T[p].ans==nowans) nownum=(nownum+T[p].ansnum)%P;
		return;
	}
	int mid=(T[p].l+T[p].r)>>1;
	if (mid>=r) getans(T[p].pl,l,r);
		else if (mid<l) getans(T[p].pr,l,r);
			else {getans(T[p].pl,l,mid); getans(T[p].pr,mid+1,r);}
}
int find_big(int pl, int pr, int x){
	int num=pr+1;
	while (pl<=pr){
		int mid=(pl+pr)>>1;
		if (g[mid]>=x){
			pr=mid-1;
			num=mid;
		}
		else pl=mid+1;
	}
	return num;
}
void solve(int l, int r){
	if (l>r) return;
	int mid=query_max_id(rt,l,r);
	solve(l,mid-1);
	int s=max(c[mid]+l-1,mid),nowl=max(l,g[s]), nowr=min(s-c[mid]+1,mid),lar;
	nowans=-inf;
	bool flag=true;
	if (nowl<=nowr&&s<=r){
		getans(rt,nowl-1,nowr-1); 
		if (s<=r){
		if (f[s]<nowans+1) num[s]=0,f[s]=nowans+1;
		if (f[s]==nowans+1) num[s]=(num[s]+nownum)%P;
		}
	}
	else flag=false;
	for (s=s+1; s<=min(r,mid+c[mid]-2); s++){
		lar=nowr; nowr=min(nowr+1,mid);
		if (g[s]>nowl){
			nowl=g[s];
			nowans=-inf;
			if (nowl<=nowr) getans(rt,nowl-1,nowr-1); 
			else flag=false;
		}
		else {
			if (flag==false){
				if (nowl<=nowr){
					flag=true;
					nowans=f[nowl-1];
					nownum=num[nowl-1];
				}
			}
			else {
				if (nowr>lar){
					if (nowans<f[nowr-1]) nowans=f[nowr-1], nownum=0;
					if (nowans==f[nowr-1]) nownum=(nownum+num[nowr-1])%P; 
				}
			}
		}
		if (flag==false) continue;
		if (f[s]<nowans+1) num[s]=0, f[s]=nowans+1;
		if (f[s]==nowans+1) {
			num[s]=(num[s]+nownum); if (num[s]>P) num[s]-=P;
		}
	} 
	int b1=find_big(s,r,l), b2=find_big(s,r,mid+1);
	nowans=-inf, nownum=0; getans(rt,l-1,mid-1);
	if (s<=b1-1) modify_tag(rt,s,b1-1,nowans+1,nownum);
	for (int s=b1; s<b2; s++){
		nowans=-inf, nownum=0; getans(rt,g[s]-1,mid-1);
		if (f[s]<nowans+1) num[s]=0, f[s]=nowans+1;
		if (f[s]==nowans+1) {
			num[s]=(num[s]+nownum); if (num[s]>P) num[s]-=P;
		}
	}
	query_tag(rt,mid);
	if (f[mid]!=0) modify(rt,mid,f[mid],num[mid]);
	solve(mid+1,r);
}
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read();
	for (int i=1; i<=n; i++) 
		c[i]=read(), d[i]=read();
	for (int i=1; i<=n; i++) f[i]=-inf;
	rt=build(0,n); g[1]=1; modify(rt,0,0,1); f[0]=0; num[0]=1;
	for (int i=2; i<=n; i++){
		g[i]=g[i-1];
		while (querymin(rt,g[i],i)<i-g[i]+1) g[i]++;
	}	
	solve(1,n);
	if (f[n]<=0)
		printf("-1\n");
		else printf("%d %d\n",f[n],num[n]);
	return 0;
}

