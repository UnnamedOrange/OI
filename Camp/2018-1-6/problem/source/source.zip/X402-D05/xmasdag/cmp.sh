a=0
while true;do
	echo "Case $a :"
	a=`expr $a + 1`
	./gen
	./baoli
	./xmasdag
	if diff baoli.out xmasdag.out;then
		printf "Accepted!\n"
	else
		printf "Wrong Answer!\n"
		break
	fi
done
