cas=1 
while true; do
	./gen || break
	./xmasdag || break
	./xmasdag1 || break
	diff ./xmasdag.out ./xmasdag1.out || break
	echo $cas 
	cas=`expr $cas + 1`
done
