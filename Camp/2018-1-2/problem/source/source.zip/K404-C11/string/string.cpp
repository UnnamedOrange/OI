#include <bits/stdc++.h>

namespace {

inline char read() {
    static const int IN_LEN = 1 << 18 | 1;
    static char buf[IN_LEN], *s, *t;
    return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
            s == t ? -1 : *s++;
}

template <typename T>
inline void read(T &x) {
    static char c;
    static bool iosig;
    for (c = read(), iosig = false; !isdigit(c); c = read()) {
        if (c == -1) return;
        iosig |= c == '-';
    }
    for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
    iosig && (x = -x);
}

inline int read(char *buf) {
    register int s = 0;
    register char c;
    while (c = read(), isspace(c) && c != -1)
        ;
    if (c == -1) {
        *buf = 0;
        return -1;
    }
    do
        buf[s++] = c;
    while (c = read(), !isspace(c) && c != -1);
    buf[s] = 0;
    return s;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
    (oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
    *oh++ = c;
}

template <typename T>
inline void print(T x) {
    static int buf[21], cnt;
    if (x != 0) {
        (x < 0) && (print('-'), x = -x);
        for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
        while (cnt) print((char)buf[cnt--]);
    } else {
        print('-');
    }
}

inline void print(const char *s) {
    for (; *s; s++) print(*s);
}

struct InputOutputStream {
    ~InputOutputStream() {
        fwrite(obuf, 1, oh - obuf, stdout);
    }

    template <typename T>
    inline InputOutputStream &operator>>(T &x) {
        read(x);
        return *this;
    }

    template <typename T>
    inline InputOutputStream &operator<<(const T &x) {
        print(x);
        return *this;
    }
} io;

const int MAXN = 100000 + 9;

char s[MAXN];


namespace Force {

int ans;
std::string rev;

inline void dfs(std::string s, int step) {
    if (step > ans) return;
    if (s.empty()) {
        ans = std::min(ans, step);
        return;
    }
    for (register int l = 0; l < s.length(); l++) {
        for (register int r = l + 1; r < s.length(); r++) {
            std::string tmp = s.substr(l, r - l + 1);
            rev = tmp;
            std::reverse(rev.begin(), rev.end());
            if (tmp != rev) {
                dfs(s.substr(0, l) + s.substr(r + 1, s.length() - r - 1), 
                        step + 1);
            }
        }
    }
}

inline void solve() {
    ans = INT_MAX;
    dfs(s, 0);
    if (ans == INT_MAX) {
        io << "-1\n";
        return;
    }
    io << ans << '\n';
}
}

inline void solveCase() {
    register int n;
    io >> n >> s;
    if (0 && n <= 10) {
        Force::solve();
        return;
    }
    for (register int l = 0, r = n - 1; l < r;) {
        if (s[l] != s[r]) {
            io << "1\n";
            return;
        }
        l++;
        r--;
    }
    register bool flag = true;
    if (n & 1) {
        register bool tFlag = true, aFlag = true;
        register int mid = n / 2;
        register char c = s[mid];
        for (register int i = mid & 1; i < n; i += 2)
            tFlag &= s[i] == c;
        c = s[~mid & 1];
        for (register int i = ~mid & 1; i < n; i += 2)
            tFlag &= s[i] == c;
        c = s[0];
        for (register int i = 0; i < mid; i++)
            aFlag &= s[i] == c;
        for (register int i = mid + 1; i < n; i++)
            aFlag &= s[i] == c;
        flag &= aFlag | tFlag;
    } else {
        register char c = s[0];
        for (register int i = 0; i < n; i++)
            flag &= s[i] == c;
    }
    io << (flag ? "-1\n" : "2\n");
}

inline void solve() {
    register int T;
    io >> T;
    while (T--) solveCase();
}
}

int main() {
    freopen("string.in", "r", stdin);
    freopen("string.out", "w", stdout);
    solve();
    return 0;
}