#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxlen 105
const int mod=998244353;

int n,m;
char s[maxlen];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

int f[2][185][185][65];

struct ac_automaton{
	static const int maxn=185;
	int root,tot,state[maxn],ch[maxn][2],fail[maxn],val[maxn],fa[maxn];
	void insert(char *s,int len,int pps){
		int p=root;
		for (int i=1;i<=len;i++){
			int x=s[i]-'0';
			if (!ch[p][x]) ch[p][x]=++tot,fa[tot]=p,val[tot]=x;
			p=ch[p][x];
		}
		state[p]=1<<(pps-1);
	}
	int q[maxn];
	void get_fail(){
		int head=1,tail=1; q[1]=root;
		while (head<=tail){
			int x=q[head++];
			for (int i=0;i<2;i++)
				if (ch[x][i]){
					int y=fail[x];
					while (y&&!ch[y][i]) y=fail[y];
					if (!y) fail[ch[x][i]]=root;
					else fail[ch[x][i]]=ch[y][i];
					q[++tail]=ch[x][i];
				}
		}
	}
	int trans(int x,int y){
		int ret=x;
		while (ret&&!ch[ret][y]) ret=fail[ret];
		if (!ret) return root;
		else return ch[ret][y];
	}
}acm,racm;

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	n=read(),m=read();
	acm.root=acm.tot=1;
	racm.root=racm.tot=1;
	for (int i=1;i<=n;i++){
		scanf("%s",s+1); int len=strlen(s+1);
		acm.insert(s,len,i);
		reverse(s+1,s+len+1);
		racm.insert(s,len,i);
	}
	acm.get_fail(),racm.get_fail();
	f[0][1][1][0]=1; int now=1;
	for (int T=1;T<=m;T++){
		for (int i=1;i<=acm.tot;i++)
			for (int j=1;j<=racm.tot;j++)
				for (int k=0;k<(1<<n);k++)
					f[now][i][j][k]=0;
		now^=1;
		for (int i=1;i<=acm.tot;i++)
			for (int j=1;j<=racm.tot;j++)
				for (int k=0;k<(1<<n);k++)
					if (f[now][i][j][k]){
						int res=f[now][i][j][k];
						for (int x=0;x<2;x++){
							int nx=acm.trans(i,x),ny=racm.trans(j,x^1);
							(f[now^1][nx][ny][k|acm.state[nx]|racm.state[ny]]+=res)%=mod;
						}
					}
	}
	now^=1; int ans=0,all=(1<<n)-1;
	for (int i=1;i<=acm.tot;i++)
		for (int j=1;j<=racm.tot;j++)
			for (int k=0;k<(1<<n);k++){
				int nx=i,ny=j,s=k;
				while (ny!=racm.root) nx=acm.trans(nx,racm.val[ny]),ny=racm.fa[ny],s|=acm.state[nx];
				if (s==all) ans=(ans+f[now][i][j][k])%mod;
			}
	printf("%d\n",ans);
	return 0;
}
