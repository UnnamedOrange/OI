//2018-1-10
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000+5)
const int P = 998244353;

int n, dfn, ans, rp[N], vis[N];
bool use[N];

bool Dfs_cir(int now){
	++dfn;
	if(vis[now]) return !((dfn-vis[now])&1);
	
	vis[now] = dfn;
	if(!Dfs_cir(rp[now])) return false;
	return true;
}

bool Check(){
	dfn = 0;
	For(i, 1, n) vis[i] = 0;
//	For(i, 1, n) printf("%d ", rp[i]); puts("");
	
	For(i, 1, n) if(!vis[i]){
		if(!Dfs_cir(i)) return false;
	}
	return true;
}

void Dfs(int now){
	if(now > n){
		ans += Check(); return;
	}
	if(rp[now]){Dfs(now+1); return;}
	
	For(i, 1, n) if(!use[i]){
		rp[now] = i;
		use[i] = true; Dfs(now+1); use[i] = false;
	}
	rp[now] = 0;
}

int main(){
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	
	bool flag = true;

	scanf("%d", &n);
	For(i, 1, n){
		scanf("%d", &rp[i]), use[rp[i]] = true;
		if(rp[i]) flag = false;
	}

	if(n & 1){puts("0"); return 0;}
	if(n > 8 && flag){
		int ret = 1, cnt = n >> 1, now = -1;
		while(cnt--){
			now += 2;
			ret = 1ll * ret * now % P;
		}
		printf("%lld\n", 1ll * ret * ret % P);
		return 0;
	}

	Dfs(1);
	printf("%d\n", ans);

	return 0;
}
