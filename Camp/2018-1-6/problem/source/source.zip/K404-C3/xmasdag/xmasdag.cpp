#include <set>
#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 200010
#define ll long long
#define mod 998244353
#define inf 1000000000
using namespace std;
char xB[1<<15],*xS=xB,*xT=xB;
#define getchar() (xS==xT&&(xT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xT)?0:*xS++)
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
struct zgz
{
	int next,to;
}edge[N];
int head[N],cnt=1;
void add(int from,int to)
{
	edge[cnt].to=to;
	edge[cnt].next=head[from];
	head[from]=cnt++;
}
int n,m,k;
int deg[N];
ll quickmod(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)ret=ret*a%mod;
		a=a*a%mod,b>>=1;
	}
	return ret;
}
ll ans[N];
namespace subtask1
{
	#define NN 2010
	#define MM 5010
	int f[NN][MM];
	int mx[NN];
	queue<int> q;
	void main()
	{
		for(int i=1;i<=n;i++)
		if(!deg[i])q.push(i),f[i][0]=1,ans[i]=quickmod(0,k);
		while(!q.empty())
		{
			int x=q.front();q.pop();
			for(int i=head[x];i;i=edge[i].next)
			{
				int to=edge[i].to;
				deg[to]--;
				for(int j=0;j<=mx[x];j++)
				f[to][j+1]+=f[x][j],f[to][j+1]%=mod;
				mx[to]=max(mx[to],mx[x]+1);
				if(!deg[to])
				{
					q.push(to);
					
					for(int j=0;j<=mx[to];j++)
					ans[to]+=(ll)f[to][j]*quickmod(j,k)%mod,ans[to]%=mod;
				}
			}
		}
		for(int i=1;i<=n;i++)
		printf("%lld\n",ans[i]);
	}
}
namespace subtask2
{
	int f[N][31],C[520][520];
	queue<int> q;
	int a[N],tot;
	void main()
	{
		for(int i=0;i<=510;i++)
  		{
		    C[i][0]=1;
		    for(int j=1;j<=i;j++)
      		C[i][j]=C[i-1][j-1]+C[i-1][j],C[i][j]%=mod;
  		}
  		for(int i=1;i<=n;i++)
		if(!deg[i])q.push(i),f[i][0]=1,ans[i]=quickmod(0,k);
		while(!q.empty())
		{
			int x=q.front();q.pop();
			a[++tot]=x;
			for(int i=head[x];i;i=edge[i].next)
			{
				int to=edge[i].to;
				deg[to]--;
				if(!deg[to])q.push(to);
			}
		}
  		f[1][0]=1;
  		for(int i=1;i<=n;i++)
		{
			int x=a[i];
			for(int j=head[x];j;j=edge[j].next)
			{
				int to=edge[j].to;
				f[to][0]+=f[x][0],f[to][0]%=mod;
			}
		}
		for(int o=1;o<=k;o++)
		{
			for(int i=1;i<=n;i++)
			{
				int x=a[i];
				for(int j=head[x];j;j=edge[j].next)
				for(int l=0;l<=o;l++)
				{
					int to=edge[j].to;
					f[to][o]+=(ll)C[o][l]*f[x][l]%mod,f[to][o]%=mod;
				}
			}
		}
  		puts("0");
  		for(int i=2;i<=n;i++)
    	printf("%d\n",f[i][k]);
	}
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();
		add(x,y);deg[y]++;
	}
	if(n<=2000&&m<=5000)subtask1::main();
	else if(k<=30)subtask2::main();
}