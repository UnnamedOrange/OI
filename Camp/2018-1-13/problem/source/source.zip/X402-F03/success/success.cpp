#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;
const ll mod=1e9 +7;
ll f[1010][1010];
ll s,t,n,m,ans;
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
//	printf("a");
	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
	s-=m;
	t--;
	f[0][0]=1;
	for (ll i=1;i<=m;++i)
	{
		ll r=999999999;
		if (i<=n) r=t;
		for (ll j=0;j<=s;++j)
		{
			for (ll k=max((ll)0,j-r);k<=j;++k)
				f[i][j]=(f[i][j]+f[i-1][k])%mod;
		//	printf("%lld %lld %lld\n",i,j,f[i][j]);
		}
	}
	for (int i=0;i<=s;++i)
		ans=(ans+f[m][i])%mod;
	printf("%lld\n",ans);

	return 0;
}
