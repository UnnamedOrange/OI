#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=100010,INF=0x3f3f3f3f,Mod=998244353;
inline void file(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
}
int n,m,k;
void init(){
	scanf("%d%d%d",&n,&m,&k);
}
void solve(){
	if(n==1){
		ll ans=0;
		For(i,1,m-1)ans=(ans+i*(m-i))%Mod;
		printf("%lld\n",ans);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
