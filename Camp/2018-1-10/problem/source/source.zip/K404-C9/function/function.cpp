#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int T;
	cin>>T;
	while(T>0) { 
		T--;
	} 
	return 0;
} 
