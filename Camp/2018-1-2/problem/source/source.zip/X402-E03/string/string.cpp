#include <bits/stdc++.h>
using namespace std ;
const int maxn = 105, zhf = 0x3f3f3f3f ;
int n, f[maxn][maxn], c[maxn][maxn] ;
char s[100005] ;
bool vis[maxn][maxn] ;
int main() {
	freopen ( "string.in", "r", stdin ) ;
	freopen ( "string.out", "w", stdout ) ;

	register int _, i, j, l, r, k, len ;
	scanf ( "%d", &_ ) ;
	while (_--) {
		scanf ( "%d", &n ) ;
		scanf ( "%s", s+1 ) ;
		for ( i = 1 ; i <= n ; i ++ ) {
			f[i][i] = zhf ;
			if (s[i] ^ s[i+1]) f[i][i+1] = 1 ;
			else f[i][i+1] = zhf ;
			vis[i][i] = 0 ;
		}
		for ( len = 2 ; len <= n ; len ++ )
			for ( i = 1 ; (j = i+len-1) <= n ; i ++ ) {
				if (s[i] ^ s[j]) vis[i][j] = 1 ;
				else {
					if (vis[i+1][j-1]) vis[i][j] = 1 ;
					else vis[i][j] = 0 ;
				}
			}
		for ( len = 3 ; len <= n ; len ++ )
			for ( i = 1 ; (j = i+len-1) <= n ; i ++ ) {
				if (vis[i][j]) {
					f[i][j] = 1 ;
					continue ;
				}
				//printf ( "calc %d %d\n", i, j ) ;
				f[i][j] = zhf ;
				memset ( c, zhf, sizeof c ) ;
				c[i+1][j] = zhf ;
				c[i][j-1] = zhf ;
				for ( k = len-3 ; k ; k -- )
					for ( l = i ; (r = l+k-1) <= j ; l ++ ) {
						if (l == i) {
							if (vis[r+1][j]) c[l][r] = 1 ;
							else c[l][r] = zhf ;
						} else if (r == j) {
							if (vis[i][l-1]) c[l][r] = 1 ;
							else c[l][r] = zhf ;
						} else {
							if (s[l-1] ^ s[r+1]) c[l][r] = 1 ;
							else {
								if (c[l-1][r+1] == 1) c[l][r] = 1 ;
								else c[l][r] = zhf ;
							}
						}
						//printf ( "c[%d][%d] = %d\n", l, r, c[l][r] ) ;
					}
				for ( l = i+1 ; l <= j ; l ++ )
					for ( r = l ; r < j ; r ++ )
						f[i][j] = min(f[i][j], f[l][r] + c[l][r]) ;
				//printf ( "f[%d][%d]=%d\n", i, j, f[i][j] ) ;
			}
		/*for ( len = 1 ; len <= n ; len ++, puts("") )
			for ( i = 1 ; (j = i+len-1) <= n ; i ++ )
				printf ( "f[%d][%d] = %d\n", i, j, f[i][j] ) ;*/
		if (f[1][n] == zhf) f[1][n] = -1 ;
		printf ( "%d\n", f[1][n] ) ;
	}
	//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
