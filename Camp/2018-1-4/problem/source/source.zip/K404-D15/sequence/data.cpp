#include<map>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

int a[233];

int main(){
	srand(time(NULL)+clock());
	int T=50; printf("%d\n",T);
	while (T--){
		int n=10; printf("%d\n",n);
		for (int i=1;i<=n;i++) a[i]=i;
		random_shuffle(a+1,a+n+1);
		for (int i=1;i<=n;i++) printf("%d ",a[i]); puts("");
	}
	return 0;
}
