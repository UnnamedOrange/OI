//2018-1-12
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000+5)
const int P = 998244353;

int Mod(int a){return a >= P? a-P: a;}
inline int Mul(int a, int b){return 1ll * a * b % P;}

int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = Mul(ret, a);
		a = Mul(a, a); anum >>= 1;
	}
	return ret;
}

int ans;
int n, m, rk, a[N], ml[N], mr[N];

void Dfs(int L, int R, int dep, int sy){
	ml[dep] = L; mr[dep] = R;
	if(sy == 0){
		For(i, 1, m) a[i] = 0;
		For(i, 1, dep) For(j, ml[i], mr[i]-1) ++a[j];
		For(i, 1, m) ans = Mod(ans + Pow(a[i], rk));
		return;
	}
	For(l, L+1, m) For(r, max(l, R+1), m) Dfs(l, r, dep+1, sy-1);
}

int main(){
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &rk);
	For(l, 1, n) For(r, l, n){
		Dfs(l, r, 1, n-1);
	}
	printf("%d\n", ans);

	return 0;
}
