#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

const int N = 25;
struct D{int x, i;} b[N+N][N];
int n, ans, lim;
int a[N];

bool cmp(D a, D b) {return a.x < b.x;}

int get(int x) {
	int t = 0, i;
	rep(i, 1, n) {
		if(i <= x) t += abs(x + 1 - i - a[i]) * a[i];
		else t += abs(i - a[i]) * a[i];
	}
	return t;
}

void dfs(int dep, int need) {
	int i, t, tt;
	if(dep > lim) return;
	if(dep + need > lim) return;
	if(ans == lim) return;
	rep(i, 2, n) b[dep][i] = (D){get(i), i};
	sort(b[dep] + 2, b[dep] + n + 1, cmp);
	if(!b[dep][2].x) {ans = min(ans, dep); return;}
	
	rep(i, 2, n) {
		t = b[dep][i].i;
		reverse(a + 1, a + t + 1);
		tt = need;
		if(t < n && abs(a[1]-a[t+1]) > 1) --tt;
		if(t < n && abs(a[t]-a[t+1]) > 1) ++tt;
		dfs(dep + 1, tt);
		reverse(a + 1, a + t + 1);
	}
}

int main() {
	freopen("sequence.in", "r", stdin); freopen("sequence.out", "w", stdout);
	int T, i, t;
	scanf("%d", &T);
	while(T--) {
		scanf("%d", &n);
		ans = n + n - 2;
		for(i = 1; i <= n; ++i) scanf("%d", &a[i]);
		
		if(!get(1)) {puts("0"); continue;}
		t = 0; for(i = 1; i < n; ++i) if(abs(a[i]-a[i+1]) > 1) ++t;
		rep(lim, 1, n+n-2) {
			dfs(1, t);
			if(ans <= lim) break;
		}
		printf("%d\n", ans);
	}
	return 0;
}
