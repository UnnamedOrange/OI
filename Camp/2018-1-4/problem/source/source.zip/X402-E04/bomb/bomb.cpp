#include<bits/stdc++.h>
#define For(i,j,k) for(register int i=j;i<=k;++i)
#define Forr(i,j,k) for(register int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define rep(i,u) for(int i=Bgn[u],v=To[i];i;i=Nxt[i],v=To[i])
#define ll long long 
using namespace std;
const int N=1000100,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;register char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
int n,Begin[N],Next[N],to[N],e,m;
int Bgn[N],Nxt[N],To[N],E;
int sccno[N],scc[N],scc_cnt,dfs_cnt,pre[N],low[N],sz[N];
int s[N],top;
void dfs(int u){	
	pre[u]=low[u]=++dfs_cnt;
	sccno[u]=1;s[++top]=u;
	Rep(i,u){
		if(!pre[v])dfs(v),low[u]=min(low[u],low[v]);
		else if(sccno[v])low[u]=min(low[u],pre[v]);
	}
	if(pre[u]==low[u]){
		scc_cnt++;
		int x;
		do{
			x=s[top],top--;
			scc[x]=scc_cnt,sccno[x]=0;
			sz[scc_cnt]++;
		}while(x!=u);
	}
}
inline void add(int x,int y){
	to[++e]=y,Next[e]=Begin[x],Begin[x]=e;
}
inline void Add(int x,int y){
	To[++E]=y,Nxt[E]=Bgn[x],Bgn[x]=E;
}

int deg[N];
void Build(){
	For(u,1,n)
		Rep(i,u)
			if(scc[u]!=scc[v])
				Add(scc[u],scc[v]),deg[scc[v]]++;	
}
int dp[N],q[N],tail,head,ans;
void toposort(){
	For(i,1,scc_cnt)if(!deg[i])q[++tail]=i;
	while(head<tail){
		int r=q[++head];
		rep(i,r){
			deg[v]--;
			if(!deg[v])q[++tail]=v;
		}
	}
	reverse(q+1,q+scc_cnt+1);
}
void Dp(){
	For(u,1,scc_cnt){
		dp[u]=sz[u];
		rep(i,u)
			dp[u]=max(dp[u],sz[u]+dp[v]);
		ans=max(ans,dp[u]);
	}
	printf("%d\n",ans);
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	read(n);read(m);
	For(i,1,m){
		int u,v;
		read(u),read(v);
		add(u,v);
	}
	For(i,1,n)if(!pre[i])dfs(i);
	Build();
	toposort();
	Dp();
	return 0;
}
