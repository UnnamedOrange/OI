#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <queue>
using namespace std;

int t, n, a[30], x[30], rev[30];

struct item {
	int a[30], f, h;
	void clear() {
		f = 0;
		memset(a, 0, sizeof a);
	}
	int get() {
		int cnt = 0;
		for(int i = 1; i <= n; ++i)
			if(abs(a[i]-a[i-1]) != 1)
				cnt++;
		return cnt;
	}
	bool operator == (const item &that) const {
		for(int i = 1; i <= n; ++i)
			if(a[i] != that.a[i]) return 0;
		return 1;
	}
	bool operator < (const item &that) const {
		int xx = f+h;
		int yy = that.f+that.h;
		if(xx != yy) return xx < yy;
		for(int i = 1; i <= n; ++i)
			if(a[i] != that.a[i]) return a[i] < that.a[i];
		return 0;
	}	
};

priority_queue<item> s1;

int main() {
	//freopen("sequence.in", "r", stdin);
	//freopen("sequence.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		while(!s1.empty()) s1.pop();
		scanf("%d", &n);
		for(int i = 1; i <= n; ++i) scanf("%d", a+i);
		item x; x.clear();
		for(int i = 1; i <= n; ++i) x.a[i] = a[i];
		x.h = x.get();
		s1.push(x);
		while(!s1.empty()) {
			item now = s1.top(); s1.pop();
			printf("%d\n", now.h);
			if(!now.h) {
				printf("%d\n", now.f);
				goto end;
			}
			now.f++;
			for(int i = 2; i <= n; ++i) {
				reverse(now.a+1, now.a+i+1);
				now.h = now.get();
				s1.push(now); 
				reverse(now.a+1, now.a+i+1);
				now.h = now.get();
			} 
		}
		//puts("-1");
		end:;
	}
	return 0;
}
