while true; do
	./gen
	./string~
	./string
	if diff string.ans string.out; then
		echo "correct answer"
	else
		echo "wrong answer"
		exit
	fi
done
