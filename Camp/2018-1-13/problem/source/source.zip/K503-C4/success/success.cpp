#include<iostream>
#include<cstdio>
#define mod 1000000007
using namespace std;
int f[110][110],g[110][110];//ǰi��λ�÷�j�����ֵķ����� 
int s,t,n,m,ans;
int main(){
	freopen("Cola.txt","r",stdin); 
//	freopen("success.in","r",stdin);freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);t-=1;
	f[0][0]=g[0][0]=1;
	for(int i=1;i<=m;i++){
		f[i][0]=1;
		for(int j=1;j<=s;j++)
			for(int k=0;k<=min(j,t);k++)
				f[i][j]=(f[i][j]+f[i-1][j-k])%mod;
	}
	for(int i=1;i<=m;i++){
		g[i][0]=1;
		for(int j=1;j<=s;j++)
			for(int k=0;k<=j;k++)
				g[i][j]=(g[i][j]+g[i-1][j-k])%mod;
	}
	s-=m;
	for(int i=0;i<=s;i++)
		for(int j=0;j<=i;j++)
			ans=(ans+1LL*f[n][j]*g[m-n][i-j]%mod)%mod;
	printf("%d",ans);
	return 0;
}
