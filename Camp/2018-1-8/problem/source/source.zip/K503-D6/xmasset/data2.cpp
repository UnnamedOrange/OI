#include <cstdio>
#include <cstdlib>
#include <process.h>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

using namespace std;

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

int main()
{
    srand(_getpid()^(unsigned long long)new char);
    FILE *in1=fopen("xmasset1.in","r"),*out1=fopen("xmasset1.out","r");
    FILE *in2=fopen("xmasset2.in","w"),*ans=fopen("xmasset.ans","w");
    int n,tc;
    fscanf(in1,"%*d%d%d",&n,&tc);
    fprintf(in2,"2\n%d %d\n",n,tc);
    rep(i,1,tc)
    {
        int x,y,h;
        fscanf(in1,"%d%d",&x,&y);
        fscanf(out1,"%d",&h);
        int k=rand(2);
        fprintf(in2,"%d %d\n",k? x:y,h);
        fprintf(ans,k? "yes\n":"no\n");
    }
    return 0;
}
