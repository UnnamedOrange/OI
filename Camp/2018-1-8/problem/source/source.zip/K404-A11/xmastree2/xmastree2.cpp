#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;
struct lxy{
	int to,next;
}b[60005];
int n,head[30005],cnt,fa[30005];
long long w[30005];
long long ans;
bool vis[30005];
long long dp[30005];
long long num[30005];
long long sonnum[30005];
bool col[30005];

queue <int> root;

void add(int op,int ed)
{
	cnt++;
	b[cnt].next=head[op];
	b[cnt].to=ed;
	head[op]=cnt;
}

int readit()
{
	int a=0;
	char x;
	x=getchar();
	while(x<'0'||x>'9')
	  x=getchar();
	while(x>='0'&&x<='9')
	{
		a=a*10+x-'0';
		x=getchar();
	}
	return a;
}

void dfs(int u)
{
	vis[u]=1;
	sonnum[u]=1;
	num[u]=w[u];
	for(int i=head[u];i!=-1;i=b[i].next)
	  if(vis[b[i].to]==0)
	  {
	  	 fa[b[i].to]=u;
		 dfs(b[i].to);
		 sonnum[u]+=sonnum[b[i].to];
		 num[u]+=num[b[i].to];
	  }
	int t=sonnum[u];
	memset(col,0,sizeof(col));
	int y,k;
	do{
		y=0,k=0;
		for(int i=head[u];i!=-1;i=b[i].next)
		  if(b[i].to!=fa[u]&&col[b[i].to]==0)
		  {
		  	if(y<(sonnum[u]-sonnum[b[i].to])*num[b[i].to]||(y=(sonnum[u]-sonnum[b[i].to])*num[b[i].to]&&sonnum[b[i].to]<sonnum[k]))
		  	{
		  		k=b[i].to;
		  		y=(t-sonnum[b[i].to])*num[b[i].to];
			}
		  }
	    if(k!=0)
	    {
	    	col[k]=1;
	    	dp[u]+=dp[k]+(t-sonnum[k])*num[k];
	    	t-=sonnum[k];
		}
	}while(y!=0);
	dp[u]+=w[u];
	//cout<<u<<" "<<num[u]<<" "<<sonnum[u]<<" "<<dp[u]<<endl;
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	int x,y;
	for(int i=1;i<=n;i++)head[i]=-1;
	for(int i=1;i<n;i++)
	{
		x=readit();y=readit();
		add(x,y);add(y,x);
	}
	for(int i=1;i<=n;i++)
	{
	  w[i]=readit();
	  x=readit();
	  if(x==1)
	    root.push(i);
    }
    while(!root.empty())
    {
    	ans=0;
    	memset(vis,0,sizeof(vis));
    	memset(dp,0,sizeof(dp));
    	memset(num,0,sizeof(num));
    	memset(sonnum,0,sizeof(sonnum));
    	memset(fa,0,sizeof(fa));
    	dfs(root.front());
    	ans=max(ans,dp[root.front()]);
    	root.pop();
	}
	printf("%lld",ans);
} 
