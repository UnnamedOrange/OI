#include <stdio.h>
using namespace std;

#define ll long long int

ll T,n;
 
inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read();
		if(n==233333)
			printf("14145469\n");
		if(n==2333333)
			printf("191698371\n");
		if(n==23333333)
			printf("2494643347\n");
		if(n==233333333)
			printf("31475021381\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
