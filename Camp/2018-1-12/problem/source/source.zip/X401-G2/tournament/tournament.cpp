#include<bits/stdc++.h>
#define MO 998244353
using namespace std;
inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}

int p,o,ans,v[510],vi[100005],g,fl,n,h[305][305],k;

void dfsA(int p, int de)
{
	if(fl)return;
	if(p==g && de) //&& &
	{
		if(de==k)
		{
		    ++ans;
		    fl=1;
		    return;
		}
		return;
	}
	for(int i=1; i<=n; ++i)if(h[p][i] && !vi[i])  //()
	{
		vi[i]=1;
	    dfsA(i,de+1);
	    vi[i]=0;
	}
}

inline void check()
{
	fl=0;
	for(int g=1; g<=n; ++g)
	{
		if (fl)break;
	    dfsA(g,0);
    }
}

inline int ksm(int p, int k)
{
	v[0]=p;
	for(int i=1; i<=29; ++i)
		v[i]=(long long)v[i-1]*v[i-1]%MO; 
	int s=1;
	for(int i=29; i>=0; --i)
	{
		if(k>=1<<i)
		{
			s=(long long)s*v[i]%MO;
			k-=1<<i;
	    }
	}
	return s;
}

void dfs(int x, int y)
{
	if(x==n && y==n)
	{
		check();
		return;
	}
	//0 !0  -1 -2  1 2
	if(y<=x)
	{
		++y;
	    if(y>n)
	    {
		    ++x;
		    y=1;
	    }
	    dfs(x,y);
	    return;
	}
	++y;
	if(y>n)
	{
		++x;
		y=1;
	}
	dfs(x,y);
	h[x][y]=1;
	h[y][x]=1;
	dfs(x,y);
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	n=read(); k=read();
	if(k==3)
	{
		o=ksm(2,(long long)n*(n-1)/2%(MO-1)); p=1;
		for(int i=2; i<=n; ++i)p=(long long)p*i%MO;
		printf("%d\n",(o-p+MO)%MO);
		return 0;
	} 
	ans=0;
	dfs(1,0);
	printf("%d\n",ans);
}
