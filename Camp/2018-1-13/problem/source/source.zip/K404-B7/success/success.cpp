#include<bits/stdc++.h>
#define ll long long
using namespace std;

int getint()
{
    int i=0,f=1;char c;
    for(c=getchar();(c<'0'||c>'9')&&c!='-';c=getchar());
    if(c=='-')f=-1,c=getchar();
    for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
    return i*f;
}

const int N=105,p=1e9+7;
int s,t,n,m;
int f[N][N],g[N][N];

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	s=getint(),t=getint(),n=getint(),m=getint();
	f[0][0]=1;
	for(int i=1;i<=n;i++)
		for(int j=0;j<=s;j++)
			for(int k=1;k<=t;k++)
				if(j-k>=0)
					f[i][j]=(f[i][j]+f[i-1][j-k])%p;
	for(int i=n+1;i<=m;i++)
		for(int j=0;j<=s;j++)
			for(int k=1;k<=s;k++)
				if(j-k>=0)
					f[i][j]=(f[i][j]+f[i-1][j-k])%p;
	/*for(int i=0;i<=n;i++)
	{
		for(int j=i;j<=i*t;j++)
		printf("%d ",f[i][j]);
		putchar('\n');
	}*/
	int ans=0;
	for(int i=m;i<=s;i++)ans=(ans+f[m][i])%p;
	cout<<ans;
	return 0;
}
