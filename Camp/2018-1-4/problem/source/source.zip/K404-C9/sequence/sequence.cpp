#include<bits/stdc++.h>
using namespace std;
int T;
int n;
int malim;
int num[30];
int jcq[30];
int zy[30];
int lim;
bool comp=false;
void dfs(int step) { 
	if(comp==true) return;
	if(step>lim) return;
	int po=n;
	while(po>0) {
		if(num[po]==po) po--;
		else break;
	}
	if(po==0) {
		comp=1;
		return;
	}
	int cost=0;	
	for(int i=2;i<=n;++i) { 
		if(abs(num[i]-num[i-1])!=1) cost++;
	} 
	if(step+cost>lim) return;
	for(int r=2;r<=n;++r) { 
		for(int i=1;i<=n;++i) jcq[i]=num[i];
		for(int i=1;i<=r;++i) num[i]=jcq[r+1-i];
		dfs(step+1);
		for(int i=1;i<=n;++i) jcq[i]=num[i];
		for(int i=1;i<=r;++i) num[i]=jcq[r+1-i];
	} 
} 
int main() { 
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>T;
	while(T>0) { 
		T--;
		comp=false;
		scanf("%d",&n);
		for(int i=1;i<=n;++i) { 
			scanf("%d",&num[i]);
		} 
		while(n>1) {
			if(num[n]==n) n--;
			else break;
		}
		malim=n*2-2;
		int cost=0;
		for(int i=2;i<=n;++i) 
			if(abs(num[i]-num[i-1])!=1) cost++; 
		for(int i=cost;i<=malim;++i) { 
			lim=i;
			dfs(0);
			if(comp==1) { 
				printf("%d\n",i);
				break;
			}
		} 
	} 
	return 0;
} 
