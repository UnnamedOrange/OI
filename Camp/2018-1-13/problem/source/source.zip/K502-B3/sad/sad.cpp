#include <stdio.h>
#include <string.h>
using namespace std;

#define ll long long int

const int maxn=100001,mod=998244353;
char s[maxn];
ll first[maxn],nxt[2*maxn],to[2*maxn],d[maxn];
double ans=0;
ll n,cnt=0;

inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void add(ll u,ll v)
{
	nxt[cnt]=first[u];
	first[u]=cnt;
	to[cnt]=v;
	d[u]++;
	cnt++;
}

void dfs(ll x,ll fa,double p,ll sum)
{
	ll i,temp=0;
	for(i=first[x];i!=-1;i=nxt[i])
	{
		if(to[i]==fa)
			continue;
		temp++;
		dfs(to[i],x,p/d[x],sum+1); 
	} 
	if(temp==0)
	{
		ans=ans+p*sum;
		while(ans>=mod)
			ans=ans-mod;
	}
}

int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	memset(first,-1,sizeof(first));
	n=read();
	scanf("%s",s);
	ll i;
	for(i=1;i<=n-1;i++)
	{
		ll u,v;
		u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	dfs(1,0,1,1);
	printf("%lf",ans);
	fclose(stdin);
	fclose(stdout); 
	return 0;
} 
