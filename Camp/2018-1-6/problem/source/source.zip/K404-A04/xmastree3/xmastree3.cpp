#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
const int mod=998244353;
int n,k,f[55],dl[55],lst[55],d[55],rec[55][55];
ll dp[55][20],ans,cnt;
bool vis[55];
struct edge
{
	int t;
	edge *next;
}*con[55],*gra[55];
void ins(edge **a,int x,int y)
{
	edge *p=new edge;
	p->t=y;
	p->next=a[x];
	a[x]=p;
}
void dfs(int v,int fa,int *r,int &tot)
{
	r[++tot]=v;
	for(edge *p=con[v];p;p=p->next)
		if(p->t!=fa&&!vis[p->t]) dfs(p->t,v,r,tot); 
}
void DP(int v)
{
	for(int i=1;i<=k;i++) dp[v][i]=1;
	for(edge *p=gra[v];p;p=p->next)
	{
		DP(p->t);
		for(int i=1;i<=k;i++)
			(dp[v][i]*=dp[p->t][i+1])%=mod;
	}
	for(int i=k;i;i--)
		(dp[v][i]+=dp[v][i+1])%mod;		
}
void solve()
{
	int root;
	for(int i=1;i<=n;i++) gra[i]=NULL;
	for(int i=1;i<=n;i++) if(f[i]) ins(gra,f[i],i);else root=i;
//	puts("solve:");
//	for(int i=1;i<=n;i++)
//		cout<<i<<' '<<f[i]<<endl;
//	cnt++;
	memset(dp,0,sizeof(dp));
	DP(root);
	(ans+=dp[root][1])%=mod;
//	for(int i=1;i<=n;i++,puts(""))
//		for(int j=1;j<=k;j++)
//			cout<<dp[i][j]<<' ';
//		
//			
//	cout<<"res:"<<dp[root][1]<<endl;
//	puts("");		
//	if(f[2]==1) system("pause");
}
void work(int hd,int tl)
{
	if(d[lst[hd]]>=k) return;
	if(hd>tl){solve();return;}
	int tot=0,s=dl[hd]; 
//	cout<<s<<' '<<hd<<' '<<tl<<endl;
	dfs(s,-1,rec[hd],tot);
//	for(int i=1;i<=tot;i++)
//		cout<<rec[hd][i]<<' ';
//	cout<<endl;	
	for(int i=1;i<=tot;i++)
	{
		int u=rec[hd][i],ntl=tl;
		vis[u]=1;f[u]=lst[hd];d[u]=d[lst[hd]]+1;
		for(edge *p=con[u];p;p=p->next)
			if(!vis[p->t]) dl[++ntl]=p->t,lst[ntl]=u;
		work(hd+1,ntl);	
		vis[u]=0;f[u]=d[u]=0;
	}
}
int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(con,x,y);
		ins(con,y,x);
	}
	dl[1]=1;
	work(1,1);
	//cout<<cnt<<endl;
	printf("%lld",ans);
	return 0;
}
/*4 3
1 2
2 3
3 4*/

