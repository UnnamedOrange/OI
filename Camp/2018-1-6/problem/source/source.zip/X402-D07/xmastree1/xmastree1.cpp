#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=5010;
int n,q,t,c[maxn],sum[maxn][maxn],lstans;
int head[maxn],nxt[maxn<<1],to[maxn<<1],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}
int fa[maxn];
void dfs(int u){
    for(int i=head[u];i;i=nxt[i]){
        int v=to[i];
        if(v!=fa[u]) fa[v]=u,dfs(v);
    }
}
void change(int h,int w,bool op){
    for(int u=h;u;u=fa[u]){
        if(op) --sum[u][c[h]];
        ++sum[u][w];
    }
}
int query(int u,int l,int r){
    int ret=0;
    for(int i=l;i<=r;i++) ret+=(sum[u][i]>0);
    return ret;
}
int main(){
    freopen("xmastree1.in","r",stdin);
    freopen("xmastree1.out","w",stdout);
    read(n); read(q); read(t);
    for(int i=1;i<=n;i++) read(c[i]);
    for(int i=1;i<n;i++){
        int u,v;
        read(u); read(v);
        ae(u,v); ae(v,u);
    }
    dfs(1);
    for(int i=1;i<=n;i++) change(i,c[i],0);
    while(q--){
        int op; read(op);
        if(op==1){
            int u,l,r;
            read(u); read(l); read(r);
            if(t==1) u^=lstans,l^=lstans,r^=lstans;
            printf("%d\n",lstans=query(u,l,r));
        }
        if(op==2){
            int u,w;
            read(u); read(w);
            if(t==1) u^=lstans,w^=lstans;
            change(u,w,1);
        }
    }
    return 0;
}
