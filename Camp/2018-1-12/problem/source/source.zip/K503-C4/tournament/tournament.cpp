#include<iostream>
#include<cstdio>
#define mod 998244353
using namespace std;
int n,k;
long long Pow(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1)res=1LL*res*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return res;
} 
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("tournament.in","r",stdin);freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(k==n){
		long long a=1LL*n*(n-1)/2,b=2;
		long long w=Pow(2,a-n+1);
		cout<<w;
		return 0;
	}
	else{
		long long a=0,b=1;
		for(int i=2;i<=n;i++)a=(a+i-1)%(mod-1),b=1LL*b*i%mod;
		printf("%d",(Pow(2,a)-b+mod)%mod);
		return 0;
	} 
}
