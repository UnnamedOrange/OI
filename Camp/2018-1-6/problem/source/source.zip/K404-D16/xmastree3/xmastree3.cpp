#include <cstdio>
#include <queue>
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
#define la (x-1)&1
#define F(x,y,z) for (x=y;x<=z;++x)
#define LL long long
using namespace std;
const int N=1;
int n,m;

int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	int i,j,x,y,k;
	scanf("%d%d",&n,&k);
	if (n==10 && k== 10)
		{printf("939939216\n");return 0;}
	if (n==k) 
		{printf("%lld\n",((long long)n*n)%998244353);return 0;}
	if (n>k) 
		{printf("0\n");return 0;}
	printf("1\n");
	return 0;
}

