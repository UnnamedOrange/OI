#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=5000;
const int M=30;

int n;
char s[N];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("stone.in","w",stdout);
	
	int n=rand()%2+4,a=rand()%3+1,b=rand()%3+1;
	if(a>b)swap(a,b);
	printf("%d %d %d\n",n,a,b);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%5+1);
	puts("");
	return 0;
}
