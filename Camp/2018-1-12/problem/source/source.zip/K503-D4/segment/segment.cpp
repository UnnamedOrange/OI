#include<bits/stdc++.h>
#define maxn 360
#define ll long long
#define mod 998244353
using namespace std;
int l[maxn], r[maxn], a[maxn], k, n, m;
ll ans;
int f[maxn][maxn], g[maxn][maxn], sumf[maxn][maxn], sumg[maxn][maxn];
int tf[50][50][50], tg[50][50][50];
ll mi(ll a, int k)
{
	ll sum = 1;
	while (k)
	{
		if (k % 2) sum = sum * a % mod;
		a = a * a % mod;
		k /= 2;
	}
	return sum;
}
void sc()
{
	for (int i = 1; i <= m; i++)
		a[i] = 0;
	for (int i = 1; i <= n; i++)
	{
		a[l[i]]++;
		a[r[i]]--;
	}
	for (int i = 1; i <= m - 1; i++)
	{
		a[i] += a[i - 1];
		ans += mi(a[i], k);
	}
}
void work(int dep)
{
	if (dep > n) sc();
	else
	for (int tl = l[dep - 1] + 1; tl <= m; tl++)
		for (int tr = max(tl, r[dep - 1] + 1); tr <= m; tr++)
		{
			l[dep] = tl;
			r[dep] = tr;
			work(dep + 1);
		}
}
void subtask1()
{
	for (ll i = 1; i <= m; i++)
	{
		ans = ((ans - i * (m - i + 1) % mod) % mod + mod) % mod;
		ans = (ans + (i + m) * (m - i + 1) / 2 % mod) % mod;
	}
	printf("%lld\n", ans);
}
void subtask2()
{
	int ans = 0;
	for (int i = 0; i <= m; i++)
		for (int j = 0; j <= m; j++)
			sumg[i][j] = 1;
	for (int i = 1; i <= n; i++)
	{
		for (int j = 0; j <= m; j++)
			for (int k = 0; k <= m; k++)
				f[j][k] = g[j][k] = 0;
		for (int j = 1; j <= m; j++)
			for (int k = j; k <= m; k++)
			{
				g[j][k] = sumg[j - 1][k - 1];
				f[j][k] = (sumf[j - 1][k - 1] + (ll)sumg[j - 1][k - 1] * (k - j) % mod) % mod;
			}
		for (int j = 0; j <= m; j++)
			for (int k = 0; k <= m; k++)
				sumf[j][k] = sumg[j][k] = 0;
		for (int j = 1; j <= m; j++)
			for (int k = 1; k <= m; k++)
			{
				sumf[j][k] = ((sumf[j - 1][k] + sumf[j][k - 1] - sumf[j - 1][k - 1] + f[j][k]) %mod + mod) % mod;
				sumg[j][k] = ((sumg[j - 1][k] + sumg[j][k - 1] - sumg[j - 1][k - 1] + g[j][k]) %mod + mod) % mod;
			}
	}
	for (int i = 1; i <= m; i++)
		for (int j = i; j <= m; j++)
			ans = (ans + f[i][j]) % mod;
	printf("%d\n", ans);
}
void subtask3()
{
	tg[0][0][0] = 1;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			for (int k = j; k <= m; k++)
				for (int t1 = 0; t1 < j; t1++)
					for (int t2 = t1; t2 < k; t2++)
					{
						tf[i][j][k] = (tf[i][j][k] + tf[i - 1][t1][t2]) % mod;
						tf[i][j][k] = (tf[i][j][k] + (ll)tg[i - 1][t1][t2] * (j - max(i, t2)) % mod) % mod;
						tg[i][j][k] = (tg[i][j][k] + tg[i - 1][t1][t2]) % mod;
					}
	for (int i = 1; i <= m; i++)
		for (int j = i; j <= m; j++)
			ans = (ans + tf[n][i][j]) % mod;
	printf("%lld\n", ans);
}
int main()
{
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	if (n >= m) {puts("0"); return 0;}
	if (n == 1)
	{
		subtask1();
		return 0;
	}
	if (k == 1)
	{
		subtask2();
		return 0;
	}
	if (k == mod - 1)
	{
		subtask3();
		return 0;
	}
	work(1);
	printf("%lld\n", ans);
	return 0;
}
