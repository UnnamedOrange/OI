#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("xmasinterval.in","w",stdout);//look at here

	int n=2000,m=50000,lim=1000000000;
	int mx=0,mn=lim;
	printf("%d %d\n",n,m);

	for(int i=1;i<=n;i++)
	{
		int x=rand()%lim+1,y=rand()%lim+1;
		if(x>y)std::swap(x,y);
		mx=std::max(mx,y);
		mn=std::min(mn,x);
		printf("%d %d\n",x,y);
	}
	for(int i=1;i<=m;i++)
		printf("%d\n",rand()%(mx-mn+1)+mn);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
