#include<bits/stdc++.h>
using namespace std;
const int p=998244353;
int power(int a,int x){
	int ans=1;
	while (x){
		if (x&1) ans=(long long)ans*a%p;
		a=(long long)a*a%p;
		x>>=1;
	}
	return ans;
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	if (n==k){
		printf("%d\n",(power(2,(long long)n*(n-1)/2)-(long long)n*power(2,(long long)(n-1)*(n-2)/2)%p+p)%p);
		return 0;
	}
	int fac=1;
	for (int i=1;i<=n;i++)
		fac=(long long)fac*i%p;
	printf("%d\n",(power(2,(long long)n*(n-1)/2)-fac+p)%p);
	return 0;
}
