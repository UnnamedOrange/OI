/*******************************************
	File:xmasinterval.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-8 08:56:19
*******************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 500010
int n,m,p[N];
struct line
{
	int l,r;
}g[N];
bool cmp(line a,line b)
{
	return a.r==b.r?a.l>b.l:a.r<b.r;
}
int pos(int *a,int x,int n)
{
	int l=1,r=n+1;
	while(l<r)
	{
		int mid=(l+r)>>1;
		if(a[mid]<=x)
			l=mid+1;
		else
			r=mid;
	}
	return l-1;
}
#define B 2000010
int bit1[B];
#define mod 1000000009
void add(int *b,int x,int w)
{
	while(x<=m+m)
	{
		b[x]=(b[x]+w)%mod;
		x+=x&(-x);
	}
}
int query(int *b,int x)
{
	int r=0;
	while(x)
	{
		r=(r+b[x])%mod;
		x-=x&(-x);
	}
	return r;
}
long long pow2[N];
int ans,v[N],u[N];
void dfs(int x)
{
	if(x>n)
	{
//		putchar(10);
		fr(i,1,m)
			v[i]=1;
		fr(i,1,n)
			if(u[i])
				fr(j,1,m)
					if(v[j]&&p[j]>=g[i].l&&p[j]<=g[i].r)
					{
						v[j]=0;
//						printf("%d %d\n",i,j);
					}
//		fr(i,1,n)
//			printf("%d%c",u[i],i==n?'\n':' ');
		fr(i,1,m)
			if(v[i])
			{
//				printf("%d\n",i);
				return;
			}
//		fr(i,1,n)
//			printf("%d%c",u[i],i==n?'\n':' ');
		ans++;
		return;
	}
	u[x]=1;
	dfs(x+1);
	u[x]=0;
	dfs(x+1);
}
int main()
{
	freopen("xmasinterval.out","w",stdout);
	freopen("xmasinterval.in","r",stdin);
	n=read();
	m=read();
	fr(i,1,n)
	{
		g[i].l=read();
		g[i].r=read();
	}
	fr(i,1,m)
		p[i]=read();
	if(n<=20)
	{
		dfs(1);
		printf("%d\n",ans);
		return 0;
	}
	sort(p+1,p+m+1);
	fr(i,1,n)
	{
		int l=pos(p,g[i].l,m),r=pos(p,g[i].r,m);
		if(p[l]<g[i].l)
			l++;
		g[i].l=l;
		g[i].r=r;
	}
	sort(g+1,g+n+1,cmp);
	pow2[0]=1;
	fr(i,1,N)
		pow2[i]=(pow2[i-1]<<1)%mod;
	bit1[1]=1;
	g[n+1].l=m+1;
	g[n+1].r=m+1;
//	fr(i,1,n+1)
//		printf("%d %d\n",g[i].l,g[i].r);
//	putchar(10);
	fr(i,1,n+1)
	{
		long long ans=0;
		ans=(ans+query(bit1,g[i].l))%mod;
//		printf("%d %lld\n",i,ans);
		if(i==n+1)
			printf("%lld\n",ans);
		else
		{
			add(bit1,g[i].l,ans);
			add(bit1,g[i].r+2,-ans);
		}
	}
	return 0;
}