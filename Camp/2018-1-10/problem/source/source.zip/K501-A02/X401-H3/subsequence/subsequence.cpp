#include<bits/stdc++.h>
using namespace std;
const int N=4005;
int read(){
    int f=1,ret=0;
    char ch=getchar();
    while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
    while(ch<='9'&&ch>='0'){ret=ret*10+ch-'0';ch=getchar();}
    return f*ret;
}

int n,m,k,a[N][N],b[N][N];

struct node{
	int x,y;
}t[N],t2[N*N];
bool cmp(node xx,node yy){
	return xx.x==yy.x?xx.y>yy.y:xx.x>yy.x;
}

void work(){
	for(int i=1;i<=k;i++)a[i][++a[i][0]]=n+1,b[i][++b[i][0]]=m+1;
	int tot=1,tot2,cnt=0;
	t[tot].x=t[tot].y=0;
	while(1){
		cnt++;
		tot2=0;
		for(int i=1;i<=tot;i++){
			for(int j=1;j<=k;j++){
				int x,y;
				if(t[i].x==n+1)x=n+1;
				else x=a[j][lower_bound(a[j]+1,a[j]+a[j][0]+1,t[i].x+1)-a[j]];
				if(t[i].y==m+1)y=m+1;
				else y=b[j][lower_bound(b[j]+1,b[j]+b[j][0]+1,t[i].y+1)-b[j]];
				if(x>t2[tot2].x||y>t2[tot2].y){
					t2[++tot2].x=x;
					t2[tot2].y=y;
				}
			}
		}
		sort(t2+1,t2+tot2+1,cmp);
		tot=1;
		t[tot].x=t2[1].x;t[tot].y=t2[1].y;
		if(t[tot].x==n+1&&t[tot].y==m+1){cout<<cnt;return;}
		int maxr=t[tot].y;
		for(int i=2;i<=tot2;i++){
			if(t2[i].y>maxr){
				t[++tot].x=t2[i].x;
				t[tot].y=t2[i].y;
				maxr=t2[i].y;
			}
		}
	}
}

int main(){
	n=read();m=read();k=read();
	for(int i=1;i<=n;i++){
		int x=read();
		a[x][++a[x][0]]=i;
	}
	for(int i=1;i<=m;i++){
		int x=read();
		b[x][++b[x][0]]=i;
	}
	work();
	return 0;
}

