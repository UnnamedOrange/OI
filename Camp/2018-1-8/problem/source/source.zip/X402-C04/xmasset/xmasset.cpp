#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int pri[]={2,3,5,7,11};
int ty,n,stk[5];

int encode(int x,int y)
{
	return x;
	for(int i=0;i<=4;i++)
		if(x%pri[i]==0)
			stk[i]=1;
		else
			stk[i]=0;
	for(int i=0;i<=4;i++)
		if(y%pri[i]==0)
			stk[i]+=2;
	for(int i=0;i<=4;i++)
		if(stk[i]==1)
			return i+1;
		else if(stk[i]==2)
			return i+1+5;

	int f1=0,f2;
	for(int i=2;i*i<=x;i++)
		if(x%i==0)
			f1=1;
	for(int i=2;i*i<=x;i++)
		if(y%i==0)
			f2=1;
	if(!f1 && f2)
		return 0;
	else if(f1 && !f2)
		return 11;
	return x;
}

bool decode(int q,int h)
{
	return q==h;
	if(1<=h && h<=5)
		return q%pri[h-1]==0;
	else if(6<=h && h<=10)
		return q%pri[h-6]!=0;
	else if(h==0 || h==11)
	{
		for(int i=2;i*i<=q;i++)
			if(q%i==0)
				return (h==0?0:1);
		return (h==0?1:0);
	}
	else
		return q==h;
}

int main()
{
	if(fopen("vj.in","r"))
	{
		freopen("vj.in","r",stdin);
		freopen("vj.out","w",stdout);
	}
	int T;
	scanf("%d%d%d",&ty,&n,&T);
	while(T--)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		if(ty==1)
			printf("%d\n",encode(x,y));
		else
			puts(decode(x,y)?"yes":"no");
	}

	return 0;
}
