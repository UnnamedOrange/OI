#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MOD = 1e9 + 7;

int n, m, s, t;



void init ();
void input ();
void work ();

int qpow ( int a, int b )
{
	LL base = a, ans = 1;
	while ( b ){
		if ( b & 1 ) ( ans *= base ) %= MOD;
		( base *= base ) %= MOD;
		b >>= 1;
	}
	return ans;
}

int add ( int x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
	return x;
}

void addv ( int &x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
}

int dec ( int x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
	return x;
}

void decv ( int &x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
}



namespace task1
{
	const int MAXN = 107;
	
	int dp1[MAXN][MAXN], dp2[MAXN][MAXN];
	
	void work ()
	{
		dp1[0][0] = 1;
		lpi ( i, 1, m ){
			lpi ( j, 1, s ){
				lpi ( k, 1, qmin ( j, t ) ) addv ( dp1[i][j], dp1[i-1][j-k] );
			}
		}
		
//		lpi ( i, 1, s ) cerr << dp1[n][i] << " ";
//		cerr << endl;
		
		dp2[0][0] = 1;
		lpi ( i, 1, m ){
			lpi ( j, 1, s ){
				lp ( k, 0, j ) addv ( dp2[i][j], dp2[i-1][k] );
			}
		}
		
		int ans = 0;
		lpi ( i, 0, s ) lpi ( j, 0, i ) addv ( ans, SC ( LL, dp1[n][j] ) * dp2[m-n][i-j] % MOD );
		
		cout << ans << endl;
	}
}



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "success" );
}

void input ()
{
	scanf ( "%d%d%d%d", &s, &t, &n, &m );
}

void work ()
{
	if ( s <= 100 && t <= 100 && n <= 100 && m <= 100 ) task1::work ();
	else task1::work ();
}
