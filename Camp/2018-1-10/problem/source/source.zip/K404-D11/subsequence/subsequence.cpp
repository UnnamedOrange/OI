#include<cstdio>
#include<queue>
#include<cstring>
using namespace std;

const int maxn = 305;
int ini_a[maxn], ini_b[maxn];
bool flag[maxn][maxn][maxn], flag2[maxn][maxn][maxn];
bool re1[maxn], re2[maxn];
int rem1[maxn], rem2[maxn];
int n, m, k, w, f;

struct lpl
{
	int num, c;
}lin, qwe;

queue<lpl> q;

inline void putit()
{
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 1; i <= n; ++i)
	{
		scanf("%d", &ini_a[i]);
	}
	for(int i = 1; i <= m; ++i)
	{
		scanf("%d", &ini_b[i]);
	}
}

inline void build()
{	
	memset(flag, false, sizeof(flag)); memset(flag2, false, sizeof(flag2));
	for(int i = 1; i <= n; ++i)
	{
		if(flag[1][0][ini_a[i]] == false)
		{
			flag[1][0][ini_a[i]] = true; lin.num = i; lin.c = 0; q.push(lin);
		}
	}		
	while(!q.empty())
	{
		lin = q.front(); q.pop(); w = lin.c + 1; f = ini_a[lin.num];
		for(int i = lin.num + 1; i <= n; ++i)
		{
			if(flag[w][f][ini_a[i]] == false)
			{
				flag[w][f][ini_a[i]] = true; 
				qwe.num = i; qwe.c = w; q.push(qwe);
			}
		}
	}
	
	for(int i = 1; i <= m; ++i)
	{
		if(flag2[1][0][ini_b[i]] == false)
		{
			flag2[1][0][ini_b[i]] = true; flag[1][0][ini_b[i]] = true; lin.num = i; lin.c = 0; q.push(lin);
		}
	}		
	while(!q.empty())
	{
		lin = q.front(); q.pop(); w = lin.c + 1; f = ini_b[lin.num];
		for(int i = lin.num + 1; i <= m; ++i)
		{
			if(flag2[w][f][ini_b[i]] == false)
			{
				flag2[w][f][ini_b[i]] = true; flag[w][f][ini_b[i]] = true;
				qwe.num = i; qwe.c = w; q.push(qwe);
			}
		}
	}
	
//	for(int i = 1; i <= 3; ++i)
//	{
//		for(int j = 0; j <= 2; ++j)
//		{
//			for(int p = 1; p <= 2; ++p)
//			{
//				printf("trie[%d][%d][%d] = %d\n", i, j, p, flag[i][j][p]);
//			}
//		}
//	}
}

inline void workk()
{
	for(int i = 1; i <= k; ++i)
	{
		if(flag[1][0][i] == false)
		{
			printf("%d", i);
			return;
		}
	}
	for(int p = 1; p < maxn; ++p)
	{
		for(int i = 1; i <= k; ++i)
		{
			for(int j = 1; j <= k; ++j)
			{
				if(flag[p][i][j] == false)
				{
					printf("%d", p + 1);
					return;
				}
			}
		}
	}
}

int main()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	putit();
	build();
	workk();
	return 0;
}








