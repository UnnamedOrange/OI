#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0;char ch=getchar();
	while(ch<'0'||'9'<ch)ch=getchar();
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret;
}
#define p 1000000007
#define ll long long
#define N 125010
ll f[N],g[N];
int c[N],d[N];
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	int n=re();
	for(int i=1;i<=n;i++){c[i]=re();d[i]=re();}
	memset(g,0,sizeof(g));
	memset(f,0,sizeof(f));
	f[0]=1;g[0]=1;
	for(int i=1;i<=n;i++){
		int dow=c[i],upt=d[i];
		int z=i;
		for(int j=1;j<=i;j++){
			--z;
			if(upt<j)
				break;
			if(dow<=j){
				if(!g[i]||g[i]<g[z]+1){
					g[i]=g[z]+1;
					f[i]=f[z]%p;
				}else{
					if(g[i]==g[z]+1)
						f[i]=(f[i]+f[z])%p;
				}
			}
			dow=max(c[z],dow);
			upt=min(d[z],upt);
		}
	}
	if(g[n])
		cout<<g[n]-1<<' '<<f[n]<<endl;
	else
		cout<<-1<<endl;
	return 0;
}
