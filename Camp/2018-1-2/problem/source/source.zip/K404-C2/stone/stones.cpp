#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
const int N=100005,mod=1000000007;
int n,a,b,tot,p[N],c[N],A[2],B[2],f[2],ans[4];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

bool dfs(int tp)
{
	bool rt=0;
	int x=tp?b:a;
	rep(i,1,tot)
		if(p[i]>=x)
		{
			p[i]-=x;
			if(!dfs(tp^1)) rt=1;
			p[i]+=x;
			if(rt) return rt;
		}
	return rt;
}

void solve()
{
	A[0]=dfs(0),B[1]=A[0]^1;
	B[0]=dfs(1),A[1]=B[0]^1;
	if(A[0] && A[1]) ++ans[0];
	if(B[0] && B[1]) ++ans[1];
	if(A[0] && B[0]) ++ans[2];
	if(A[1] && B[1]) ++ans[3];
}

bool check1()
{
	rep(i,1,n) if(c[i]>5) return 0;
	return 1;
}

void task1()
{
	rep(i,1,(1<<n)-1)
	{
		tot=0;
		rep(j,1,n) if(i&(1<<j-1)) p[++tot]=c[j];
		solve();
	}
	rep(i,0,2) printf("%d ",ans[i]);
	printf("%d\n",ans[3]+1);
}

void inc(int &x,int y)
{
	if((x+=y)>=mod) x-=mod;
}

void task2()
{
	rep(i,1,n) c[i]/=a;
	printf("0 0");
	f[1]=1;
	rep(i,1,n)
	{
		int x=f[0],y=f[1];
		if(c[i]&1) inc(f[0],y),inc(f[1],x);
		else inc(f[0],x),inc(f[1],y);
	}
	printf(" %d %d\n",f[0],f[1]);
}

int main()
{
	freopen("stone.in","r",stdin);
//	freopen("stones.out","w",stdout);
	n=getint(),a=getint(),b=getint();
	rep(i,1,n) c[i]=getint();
	task1();
	return 0;
}
