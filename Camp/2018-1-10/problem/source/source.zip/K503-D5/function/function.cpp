#include <cstdio>
#define ll long long
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=1e6+5;
ll ans;
int n,i,j,k,T;
int pn,mu[N],sum[N],prime[N],notprime[N],fac[N],exp[N];
void Init()
{
	mu[1]=1; fac[1]=1;
	rep(i,2,N-1)
	{
		if (!notprime[i]) {
		  prime[++pn]=i; mu[i]=-1; fac[i]=2; exp[i]=i;
	    }
		rep(j,1,pn)
		{
			if ((ll)prime[j]*i>=N) break;
			k=prime[j]*i;
			notprime[k]=1;
			if (i%prime[j]==0) {
			  exp[k]=exp[i]*prime[j];
			  fac[k]=fac[i]+fac[i/exp[i]];
			  break;
            }
			mu[k]=mu[i]*(-1);
			fac[k]=fac[i]*2;
			exp[k]=prime[j];
		}
	}
	rep(i,1,N-1) sum[i]=sum[i-1]+mu[i];
}
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	Init();
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		ans=0;
		rep(i,1,n) ans+=(ll)fac[i]*fac[i]*sum[n/i];
		printf("%lld\n",ans);
	}
	return 0;
}
