#include<bits/stdc++.h>
using namespace std;
const int maxn=500010;
const int mod=(1e9)+9;
int n,m,mm,b[maxn],a[maxn],l,r,dp[10010][10010];
int i,j,k;
struct node{
	int x,y,l,r;
}f[maxn];
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
bool cmp(node a,node b){
	return (a.y<b.y);
}
int main(){
	freopen("masinterval.in","r",stdin);
	freopen("masinterval.out","w",stdout);
	n=read(); m=read();
	for (i=1;i<=n;i++){
		f[i].x=read(); f[i].y=read();
	}
	for (i=1;i<=m;i++){
		a[i]=read();
	}
	sort(f+1,f+n+1,cmp);
	sort(a+1,a+m+1);
	mm=1; b[mm]=a[1];
	for (i=2;i<=m;i++){
		if (a[i]!=a[i-1]){ mm++; b[mm]=a[i]; }
	}
	memset(a,0,sizeof(a)); m=mm;
	for (i=1;i<=m;i++) a[i]=b[i];
	memset(b,0,sizeof(b)); mm=0;
	for (i=1;i<=n;i++){
		f[i].l=1e9; f[i].r=0;
	}
	for (i=1;i<=n;i++){
		for (j=1;j<=m;j++){
			if (f[i].x<=a[j]) f[i].l=min(f[i].l,j);
			if (f[i].y>=a[j]) f[i].r=max(f[i].r,j);
		}
	}
	memset(dp,0,sizeof(dp)); dp[0][0]=1;
	for (i=1;i<=n;i++) dp[i][0]=(dp[i-1][0]*2)%mod;
	for (i=1;i<=m;i++) dp[0][i]=0;
	for (i=1;i<=n;i++){
		for (j=1;j<=f[i].r;j++){
			if (f[i].l>j) dp[i][j]=dp[i-1][j]*2;
			else dp[i][j]=dp[i-1][j]+dp[i-1][f[i].l-1];
			if (dp[i][j]>mod) dp[i][j]=dp[i][j]-mod;
		}
	}
	printf("%d\n",dp[n][m]);
	return 0;
}
