#include <bits/stdc++.h>
using namespace std ;
struct node {
	int x, id ;
	friend bool operator < ( node a, node b ) {
		return a.x < b.x ;
	}
} s[100005] ;
int main() {
	freopen ( "xmasdag.in", "w", stdout ) ;
	srand(time(0)) ;
	int i, u, x, k ;
	int n, m ;
	n = 2e3, m = 5e3, k = 30 ;
	printf ( "%d %d %d\n", n, m, rand()%k+1 ) ;
	for ( i = 1 ; i <= n ; i ++ )
		s[i] = (node){rand(), i} ;
	sort(s+1, s+n+1) ;
	for ( i = 2 ; i <= n ; i ++ ) {
		-- m ;
		printf ( "%d %d\n", 1, s[i].id ) ;
	}
	for ( i = 1 ; i <= m ; i ++ ) {
		x = rand()%n+1 ;
		u = rand()%n+1 ;
		if (x == u) x ++ ;
		if (x > u)swap(x, u) ;
		printf ( "%d %d\n", s[x].id, s[u].id ) ;
	}
	return 0 ;
}
