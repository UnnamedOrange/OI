/*problem:xmasset*/
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
#include<vector>
#include<set>
#include<map>
#include<queue>
#define ll long long
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
#define vi vector<int>
#define setfile(s) freopen(#s".in","r",stdin),freopen(#s".out","w",stdout)
using namespace std;
const int maxn=1010;
int t,n,T,a[maxn][maxn],x[maxn],s[maxn],cnt;
int encode(int x,int y){return a[x][y];}
int decode(int q,int h){return x[q]&(1<<(h-1));}
int main(){
	scanf("%d%d%d",&t,&n,&T);
	for(int i=0;i<(1<<12);++i){
		if(__builtin_popcount(i)==6)x[++cnt]=i;
	}
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j){
			for(int m=0;m<12;++m)
				if((x[i]&(1<<m))&&!(x[j]&(1<<m)))
					a[i][j]=m+1;
		}
	while(T--){
		int x,y;
		scanf("%d%d",&x,&y);
		if(t==1)printf("%d\n",encode(x,y));
		else puts(decode(x,y)?"yes":"no");
	}
	return 0;
}

