#include<bits/stdc++.h>
using namespace std;
struct node1{
	long long r,next;}side[70000];
struct node{
	long long v,num,zong,fa;}bee[50000];
long long sidetot,fa[50000],n,weizhi[50000],dui[50000],tot,now[50000],w[50000],r[50000];
long long ans;
double js(long long i){
	return bee[i].v*1.0/bee[i].num;}
void add(long long i,long long j){
	sidetot++;
	side[sidetot].r=j;
	side[sidetot].next=now[i];
	now[i]=sidetot;
}
void dfs(long long i){
	for (long long p=now[i];(p);p=side[p].next)
	if (fa[side[p].r]==0)
	{
		fa[side[p].r]=i;
		dfs(side[p].r);
	}
}
long long getfa(long long i){
	if (bee[i].fa==i) return i;
	bee[i].fa=getfa(bee[i].fa);
	return bee[i].fa;
}
void insert(long long i){
	tot++;
	dui[tot]=i;
	long long j=tot;
	while ((j>1)&&(js(dui[j])<js(dui[j>>1])))
	{
		swap(weizhi[dui[j]],weizhi[dui[j>>1]]);
		swap(dui[j],dui[j>>1]);
		j=j>>1;
	}
}
void tiao(long long i){
	long long j=i;
	while ((j>1)&&(js(dui[j])<js(dui[j>>1])))
	{
		swap(weizhi[dui[j]],weizhi[dui[j>>1]]);
		swap(dui[j],dui[j>>1]);
		j=j>>1;
	}
	j=i;
	long long k;
	while ((j*2)<=tot)
	{
		if ((j*2==tot)||(js(dui[j<<1])<js(dui[j*2+1])))
			k=0; else k=1;
		if (js(dui[j])>js(dui[j*2+k]))
		{
			swap(weizhi[dui[j]],weizhi[dui[j*2+k]]);
			swap(dui[j],dui[j*2+k]);
			j=j*2+k;
		}
		else break;
	}
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%lld",&n);
	for (long long i=1;i<n;i++)
	{
		long long x,y;
		scanf("%lld%lld",&x,&y);
		add(x,y);
		add(y,x);
	}
	for (long long i=1;i<=n;i++)
		scanf("%lld%lld",&w[i],&r[i]);
	for (long long i=1;i<=n;i++)
	if (r[i])
	{
		for (long long j=1;j<=n;j++) fa[j]=0;
		fa[i]=i;	dfs(i);
		for (long long j=1;j<=n;j++)
		if (i!=j)
		{
			weizhi[j]=tot+1;
		    bee[j].num=1;
		   	bee[j].v=w[j];
		   	bee[j].zong=w[j];
			bee[j].fa=j;
			insert(j);
		}else
		{
			bee[j].num=1;
		   	bee[j].v=w[j];
		   	bee[j].zong=w[j];
			bee[j].fa=j;
		}
		for (long long j=1;j<n;j++)
		{
			long long k=dui[1];
			getfa(k);
			getfa(fa[k]);
			bee[bee[fa[k]].fa].zong+=bee[bee[k].fa].zong+bee[bee[k].fa].v*bee[bee[fa[k]].fa].num;
			bee[bee[fa[k]].fa].v+=bee[bee[k].fa].v;
			bee[bee[fa[k]].fa].num+=bee[bee[k].fa].num;
			bee[bee[k].fa].fa=bee[fa[k]].fa;
			if (bee[fa[k]].fa!=i)
			{
				weizhi[dui[tot]]=1;
				dui[1]=dui[tot];
				tot--;
				tiao(1);
				tiao(weizhi[k]);
			}
			else 
			{
				weizhi[dui[tot]]=1;
				dui[1]=dui[tot];
				tot--;
				tiao(1);
			}
		}
		ans=max(ans,bee[i].zong);
	}
	cout<<ans;
}

