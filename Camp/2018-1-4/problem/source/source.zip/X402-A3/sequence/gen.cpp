#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#include<stdlib.h>
int n,f[30];
int main()
{
	freopen("sequence.in","w",stdout);
	n=8;
	printf("1\n%d\n",n);
	fr(i,1,n)
		f[i]=i;
	srand((unsigned long long)new char);
	fr(i,1,n*n)
	{
		int u=rand()%n+1,v=rand()%n+1;
		int k=f[u];
		f[u]=f[v];
		f[v]=k;
	}
	fr(i,1,n)
		printf("%d%c",f[i],i==n?'\n':' ');
	return 0;
}