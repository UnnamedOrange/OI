#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
const int mod=(1e9)+7;
int n,dp[2010][2010],f[2010][2010],a[maxn],b[maxn],f1[22][10010],f2[22][10010],get2n[40],ha[maxn],ans,anss;
int i,j,k;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
int check(int x,int y){
	int t1,t2,l,r;
	r=x; l=x-y+1;
	t1=max(f1[ha[y]][l],f1[ha[y]][r-get2n[ha[y]]+1]);
	t2=min(f2[ha[y]][l],f2[ha[y]][r-get2n[ha[y]]+1]);
	if (t1>t2) return -1;
	if ((t1<=y)&&(y<=t2)) return 1;
	return 0;
}
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read();
	for (i=1;i<=n;i++){
		a[i]=read(); b[i]=read();
		f1[0][i]=a[i];
		f2[0][i]=b[i];
	}
	get2n[0]=1; for (i=1;i<=25;i++) get2n[i]=get2n[i-1]*2;
	for (i=1;i<=13;i++) ha[get2n[i]]=i;
	for (i=1;i<=n;i++) if (ha[i]==0) ha[i]=ha[i-1];
	for (i=1;i<=13;i++){
		for (j=1;j<=n;j++){
			if (j+get2n[i-1]>n) break;
			f1[i][j]=max(f1[i-1][j],f1[i-1][j+get2n[i-1]]);
			f2[i][j]=min(f2[i-1][j],f2[i-1][j+get2n[i-1]]);
		}
	}
	dp[1][1]=1; f[1][1]=1;
	for (i=1;i<=n-1;i++){
		for (j=1;j<=i;j++){
			if (check(i,j)==1){
				if (dp[i+1][1]<dp[i][j]+1){ dp[i+1][1]=dp[i][j]+1; f[i+1][1]=f[i][j]; }
				else if (dp[i+1][1]==dp[i][j]+1) f[i+1][1]=(f[i+1][1]+f[i][j])%mod;
			}
			if (check(i,j)>=0){
				if (dp[i+1][j+1]<dp[i][j]){ dp[i+1][j+1]=dp[i][j]; f[i+1][j+1]=f[i][j]; }
				else if (dp[i+1][j+1]==dp[i][j]) f[i+1][j+1]=(f[i+1][j+1]+f[i][j])%mod;
			}
		}
	}
	ans=0; anss=0;
	for (i=1;i<=n;i++){
		if (check(n,i)==1){
			if (dp[n][i]>ans){ ans=dp[n][i]; anss=f[n][i]; }
			else{ if (dp[n][i]==ans) anss=(anss+f[n][i])%mod; }
		}
	}
	if (ans==0) printf("-1\n");
	else printf("%d %d\n",ans,anss);
	return 0;
}
