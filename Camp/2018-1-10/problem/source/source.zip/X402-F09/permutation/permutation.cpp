#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
int read(){
	int x=0,fh=1; char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') fh=-1;
	for (;isdigit(ch);ch=getchar()) x=x*10+(ch^48);
	return x*fh;
}
const int mo=998244353;
int a[100005];
int main(){
	freopen("permutation.in","r",stdin); freopen("permutation.out","w",stdout);
	int n=read(),b[11],x,cnt,ans=0; bool fl[9]; long long s=1;
	For(i,1,n) a[i]=read();
	if (n%2==1) {printf("0\n"); return 0;}
	if (n<=8){
		For(i,1,n) b[i]=i;
		do{
			memset(fl,0,sizeof(fl));
			For(i,1,n) if (b[i]!=a[i]&&a[i]) {fl[0]=1; break;}
			if (!fl[0])
				For(i,1,n) if (!fl[i]){
					fl[i]=1,x=i,cnt=1;
					while(b[x]!=i) x=b[x],fl[b[x]]=1,++cnt;
					if (cnt%2==1) {fl[0]=1; break;}
				}
			if (!fl[0]) ++ans;
		}while(next_permutation(b+1,b+1+n));
		printf("%d\n",ans); return 0;
	}
	for(int i=3;i<=n;i+=2) s=s*i%mo;
	printf("%lld\n",s*s%mo);
	return 0;
}
