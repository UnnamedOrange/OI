#include<bits/stdc++.h>
#include<tr1/unordered_map>
#include<map>
using namespace std::tr1;
using namespace std;
int power(int di,int top) {
	int ret=1;
	for(int i=0;i<top;++i) ret*=di;
	return ret;
}
struct area { 
	int l,r;
}; 
area a[123012];
int ans=0;
int nw=0,nv=1;
unordered_map<int,int>kk;
int ori[120000];
int point[120000];
int n,m;
int mp[300];
void dfs(int k) { 
	int comp=1;
	for(int i=0;i<m;++i) { 
		if(mp[point[i]]==0) { 
			comp=0;break;
		} 
	} 
	if(comp==1) { 
		ans+=power(2,n-k);
		return;
	} 
	if(k==n-1) return;
	for(int i=0;i<2;++i) { 
		if(i==1) { 
			for(int j=a[k].l;j<=a[k].r;++j) mp[j]++;
			dfs(k+1);
			for(int j=a[k].l;j<=a[k].r;++j) mp[j]--;
		} 
		else dfs(k+1);
	} 
} 
int main() { 
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;++i) { 
		scanf("%d%d",&a[i].l,&a[i].r);
		ori[nw]=a[i].l,nw++;
		ori[nw]=a[i].r,nw++;
	} 
	for(int i=0;i<m;++i) { 
		scanf("%d",&point[i]);
		ori[nw]=point[i],nw++;
	} 
	sort(ori,ori+nw);
	for(int i=0;i<nw;++i) 
		if(kk[ori[i]]==0)
			kk[ori[i]]=nv,nv++;
	for(int i=0;i<n;++i) a[i].l=kk[a[i].l],a[i].r=kk[a[i].r];
	for(int i=0;i<m;++i) point[i]=kk[point[i]];
	dfs(0);
	printf("%d",ans);
} 
