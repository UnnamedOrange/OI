#include <bits/stdc++.h>

#define REP(i, t) for(int i = 0, i##E = (t); i < i##E; ++i)

template <class T> inline T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = 1;
	for(;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 1e5 + 10;

int n, m, ty, color[N];

int e, Begin[N], to[N << 1], Next[N << 1];

void add_edge(int u, int v)
{
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
	to[++e] = u, Next[e] = Begin[v], Begin[v] = e;
}

int fa[N];

void dfs_INIT(int u)
{
	for(int i = Begin[u]; i; i = Next[i]){
		int v = to[i];
		if(v == fa[u]) continue;
		fa[v] = u; dfs_INIT(v);
	}
}

struct brute_force
{
	int vis[N], l, r;

	int dfs_CALC(int u)
	{
		int ret = 0;
		if(!vis[color[u]] && color[u] >= l && color[u] <= r) 
			++ ret, vis[color[u]] = 1;

		for(int i = Begin[u]; i; i = Next[i]){
			int v = to[i];
			if(v == fa[u]) continue;
			ret += dfs_CALC(v);
		}

		return ret;
	}

	void main()
	{
		dfs_INIT(1);

		int lstans = 0;
		for(int i = 1; i <= m; ++i){
			int opt; read(opt);
			if(opt == 1){
				int u; read(u), read(l), read(r);
				u ^= ty*lstans, l ^= ty*lstans, r ^= ty*lstans;
				for(int j = 1; j <= n; ++j) vis[j] = 0;
				printf("%d\n", lstans=dfs_CALC(u));
			}
			else{
				int u, c; read(u), read(c);
				u ^= ty*lstans, c ^= ty*lstans;
				color[u] = c;
			}
		}

		return ;
	}
}bfer;

//std::bitset<N> occur[N];

int main()
{
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);

	read(n), read(m), read(ty);
	for(int i = 1; i <= n; ++i) read(color[i]);
	for(int i = 1; i < n; ++i){
		int u, v; read(u), read(v);
		add_edge(u, v);
	}
	bfer.main();
//	std::cerr << sizeof(occur) << std::endl;
	return 0;
}
