#include <cstdio>
#include <cstdlib>
#include <process.h>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

using namespace std;

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

int main()
{
    srand(_getpid()^(unsigned long long)new char);
    freopen("xmasset1.in","w",stdout);
    puts("1");
    int n=rand(2,920),tc=2e6;
    printf("%d %d\n",n,tc);
    rep(i,1,tc)
    {
        int x=rand(1,n),y;
        while ((y=rand(1,n))==x);
        printf("%d %d\n",x,y);
    }
    return 0;
}
