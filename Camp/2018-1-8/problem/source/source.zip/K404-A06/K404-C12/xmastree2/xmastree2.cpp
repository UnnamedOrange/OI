#include <iostream>
#include <cstring>
#include <utility>
#include <cstdio>
#include <queue>
#define mp make_pair
using namespace std; 
typedef long long ll; 
int w[30005], lst[30005], to[60005], pre[60005], tot; 
int fa[30005], cnt[30005], r[30005]; 
inline void add_edge(int u, int v)
{
	to[tot] = v; 
	pre[tot] = lst[u]; 
	lst[u] = tot++; 
}
void dfs(int u)
{
	for (int i = lst[u]; ~i; i = pre[i])
	{
		if (to[i] == fa[u])
			continue; 
		cnt[u]++; 
		fa[to[i]] = u; 
		dfs(to[i]); 
	}
}
int main()
{
	freopen("xmastree2.in", "r", stdin); 
	freopen("xmastree2.out", "wt", stdout); 
	memset(lst, -1, sizeof(lst)); 
	int n; 
	scanf("%d", &n); 
	for (int i = 1; i < n; i++)
	{
		int u, v; 
		scanf("%d%d", &u, &v);
		add_edge(--u, --v); 
		add_edge(v, u); 
	}
	for (int i = 0; i < n; i++)
		scanf("%d%d", w + i, r + i); 
	ll ans = 0; 
	for (int i = 0; i < n; i++)
	{
		if (!r[i])
			continue; 
		memset(cnt, 0, sizeof(cnt)); 
		fa[i] = -1; 
		dfs(i); 
		priority_queue<pair<int, int> > que; 
		for (int j = 0; j < n; j++)
		{
			if (!cnt[j])
				que.push(mp(w[j], j)); 
		}
		int cur = n; 
		ll sum = 0; 
		while (!que.empty())
		{
			int u = que.top().second; 
			que.pop(); 
			sum += (ll)cur * w[u]; 
			cur--; 
			if (~fa[u] && !--cnt[fa[u]])
				que.push(mp(w[fa[u]], fa[u])); 
		}
		ans = max(ans, sum);
	}
	printf("%lld\n", ans); 
	return 0; 
}

