#include <cstdio>
#define LL long long
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=2e3+5,M=5e3+5,mod=998244353;
int En,fst[N],to[M],nxt[M];
int n,m,k,i,j,x,a,b,c,ans,val[N],deg[N],f[N][N],g[N],s[N];
int l,r,now,v,q[N];
int quickmi(int x,int n)
{
	int ret=1,bsc=x;
	for (;n>0;bsc=(LL)bsc*bsc%mod,n>>=1)
	  if (n&1) ret=(LL)ret*bsc%mod;
	return ret;
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	rep(i,1,n) val[i]=quickmi(i,k);
	rep(i,1,m)
	{
		scanf("%d%d",&a,&b);
	    En++; nxt[En]=fst[a]; fst[a]=En; to[En]=b;
	    deg[b]++;
	}
	q[l=r=1]=1; g[1]=1; s[1]=0;
	while (l<=r)
	{
		now=q[l];
		for (j=fst[now];j;j=nxt[j])
		{
			v=to[j];
			if (k==1) {
				g[v]=(g[v]+g[now])%mod;
				s[v]=((LL)s[v]+s[now]+g[now])%mod;
			}
			else {
			  if (now==1) f[v][1]++;
			  rep(x,2,n)
			    f[v][x]=(f[v][x]+f[now][x-1])%mod;
		    }
			deg[v]--;
			if (!deg[v]) q[++r]=v;
	    }
		l++;
	}
	if (k==1)
	  rep(i,1,n) printf("%d\n",s[i]);
	else
	  rep(i,1,n)
	  {
		ans=0;
		rep(j,1,n)
		  ans=(ans+(LL)f[i][j]*val[j]%mod)%mod;
	    if (k==0 && i==1) ans=1;
		printf("%d\n",ans);
	  }
	return 0;
}
