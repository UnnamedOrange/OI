#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<cstdio>
#define ull unsigned long long
using namespace std;

const int N=100005;
const int mod=998244853;
const ull p1=5557;
const int p2=2333;

struct hsh{
	ull s1; int s2;
	hsh(){}
	hsh(ull s1,int s2):s1(s1),s2(s2){}
	friend hsh operator+(hsh a,hsh b){
		return hsh(a.s1+b.s1,(a.s2+b.s2)%mod);
	}
	friend hsh operator*(hsh a,hsh b){
		return hsh(a.s1*b.s1,1ll*a.s2*b.s2%mod);
	}
	friend hsh operator-(hsh a,hsh b){
		return hsh(a.s1-b.s1,(a.s2-b.s2+mod)%mod);
	}
	friend bool operator==(hsh a,hsh b){
		return (a.s1==b.s1&&a.s2==b.s2);
	}
}hs1[N],hs2[N],p[N];
int n,T,ans;
char s[N];

void init(){
	int i;
	p[0]=hsh(1,1);
	for (i=1;i<=n;i++) p[i]=p[i-1]*hsh(p1,p2);
	for (i=1;i<=n;i++) hs1[i]=hs1[i-1]*hsh(p1,p2)+hsh(s[i],s[i]);
	for (i=1;i<=n;i++) hs2[i]=hs2[i-1]*hsh(p1,p2)+hsh(s[n-i+1],s[n-i+1]);
}

hsh get1(int l,int r){
	return hs1[r]-hs1[l-1]*p[r-l+1];
}

hsh get2(int l,int r){
	return hs2[r]-hs2[l-1]*p[r-l+1];
}

bool pd(int l,int r){
	return get1(l,r)==get2(n-r+1,n-l+1);
}

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int i;
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n);
		scanf("%s",s+1);
		init();
		ans=-1;
		for (i=1;i<n;i++)
			if (!pd(1,i)&&!pd(i+1,n)){
				ans=2; break;
			}
		if (!pd(1,n)) ans=1;
		printf("%d\n",ans);
	}
	return 0;
}
/*
2
7 
abcdcba
3
xxx
*/
