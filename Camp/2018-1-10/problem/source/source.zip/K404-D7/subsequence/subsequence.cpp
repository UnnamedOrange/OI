#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int a[5005], b[5005];
int dp[4005][4005];
int nxta[4005][4005], nxtb[4005][4005];
int cx[4005];
int vis[2][4005];
int n, m, k1;
int main() {
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	R(n), R(m), R(k1);
	for(int i = 1; i <= n; ++i) {
		R(a[i]);
//		a1[a[i]].insert(i);
	}
	for(int j = 1; j <= m; ++j) {
		R(b[j]);
//		b1[b[i]].insert(i);
	}
	for(int i = 1; i <= n; ++i) {
		++vis[0][a[i]];
	}
	for(int j = 1; j <= m; ++j) {
		++vis[1][b[j]];
	}
	for(int i = 1; i <= k1; ++i) {
		if(!max(vis[1][i], vis[0][i])) {
			puts("1");
			return 0;
		}
	}
	if((long long)n * m * k1 > 1000000000ll) {
		int mx = 0x3f3f3f3f;
		if(n + m <= k1 * 3) {
			puts("2");
			return 0;
		}
		for(int i = 1; i <= n; ++i) {
			mx = min(mx, max(vis[1][i], vis[0][i]));
		}
		printf("%d\n", min(3, mx + 1));
		return 0;
	}
	for(int i = 1; i <= k1; ++i) {
		cx[i] = n + 1;
		nxta[n + 1][i] = n + 1;
	}
	for(int i = n; i >= 0; --i) {
		for(int j = 1; j <= k1; ++j) {
			nxta[i][j] = cx[j];
		}
		cx[a[i]] = i;
	}
	for(int i = 1; i <= k1; ++i) {
		cx[i] = m + 1;
		nxtb[m + 1][i] = m + 1;
	}
	for(int i = m; i >= 0; --i) {
		for(int j = 1; j <= k1; ++j) {
			nxtb[i][j] = cx[j];
		}
		cx[b[i]] = i;
	}
	memset(dp, 0x3f, sizeof(dp));
	dp[0][0] = 0;
	int nxti, nxtj;
	for(int i = 0; i <= n + 1; ++i) {
		for(int j = 0; j <= m + 1; ++j) {
			if(dp[i][j] < 0x3f3f3f3f) {
				for(int k = 1; k <= k1; ++k) {
					nxti = nxta[i][k], nxtj = nxtb[j][k];
					dp[nxti][nxtj] = min(dp[nxti][nxtj], dp[i][j] + 1);
				}
			}
		}
	}
	printf("%d\n", dp[n + 1][m + 1]);
	return 0;
}
