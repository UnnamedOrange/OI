#include<bits/stdc++.h>
using namespace std;

int main(){
	srand(time(0));
	freopen("xmastree1.in","w",stdout);
	int n=5e3,q=5e3,t=0;
	n=q=1e5;
	printf("%d %d %d\n",n,q,t);
	for(int i=1;i<=n;++i)
		printf("%d ",rand()%n+1);
	puts("");
	for(int i=2;i<=n;++i)
		printf("%d %d\n",rand()%(i-1)+1,i);
	while(q--){
		if(rand()&1){
			int l=rand()%n+1,r=rand()%n+1;
			printf("1 %d %d %d\n",rand()%n+1,min(l,r),max(l,r));
		}
		else{
			printf("2 %d %d\n",rand()%n+1,rand()%n+1);
		}
	}
}
