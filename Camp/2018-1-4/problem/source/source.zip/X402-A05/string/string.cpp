#include <bits/stdc++.h>

#define REP(i, t) for(int i = 0, i##E = (t); i < i##E; ++i)

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	return 0;
}
