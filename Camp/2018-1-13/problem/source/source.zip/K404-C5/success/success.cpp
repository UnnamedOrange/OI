#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2e6,Mod=1e9+7;
long long s,t,n,m;
int fac[N+50],invfac[N+50];
inline int power(int a,int b){
	int rs=1;
	for(;b;b>>=1,a=(ll)a*a%Mod) if(b&1) rs=(ll)rs*a%Mod;
	return rs;
}
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	fac[0]=1; 
	for(int i=1;i<=N;i++) fac[i]=(ll)i*fac[i-1]%Mod;
	invfac[N]=power(fac[N],Mod-2);
	for(int i=N-1;i>=0;i--) invfac[i]=(ll)invfac[i+1]*(i+1)%Mod;
	cin>>s>>t>>n>>m; 
	if(s<m) {puts("0");return 0;}
	s-=m;
	int ans=0,sgn=1;
	for(int i=0;i<=n;i++) {
		if(i*t>s) break;
		int Cni=(ll)fac[n]*invfac[n-i]%Mod*invfac[i]%Mod;
		int Bni=(ll)fac[s+m-i*t]*invfac[s-i*t]%Mod*invfac[m]%Mod;
		ans=(ans+(ll)sgn*Cni*Bni%Mod)%Mod;
		ans=(ans+Mod)%Mod;
		sgn=-sgn;
	}
	printf("%d\n",ans);
}
