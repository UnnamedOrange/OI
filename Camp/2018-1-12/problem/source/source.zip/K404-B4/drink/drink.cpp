#include <bits/stdc++.h>
#define getchar() *(pp++)
using namespace std;
char buf[10000100],*pp=buf;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int n,w[1000001],a[1000001];
double ret;
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	fread(buf,sizeof(char),sizeof(buf),stdin);	
	n=read();
	for(int i=1;i<=n;i++)
	{
		w[i]=read();
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<=n;j++)
		{
			memcpy(a,w+i,sizeof(int)*(j-i+1));
			sort(a,a+j-i+1);
			double temp=0.5;
			for(int k=j-i;k>=0;k--,temp/=2.0)
			{
				ret+=a[k]*temp;
			}
		}
	}
	printf("%.8lf\n",ret/double(n*n));
	return 0;
}
