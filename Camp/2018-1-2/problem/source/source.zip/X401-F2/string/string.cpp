#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std;

template<class T>void read(T &x){
	x=0;int ff=0;char ch=getchar();
	while(ch<'0'||ch>'9'){ff|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=ff?-x:x;
	return ;
}

int len,f[30],con;
char cc[100010];

void init(){
	memset(f,0,sizeof(f));
	memset(cc,0,sizeof(cc));
	con=len=0;
}

bool check(){
	for(int i=1,j=len;i<=j&&j;j--,i++)
		if(cc[i]!=cc[j]) return false;
	return true;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;read(T);
	while(T--){
		read(len);
		for(int i=1;i<=len;i++) scanf("%c",&cc[i]),f[cc[i]-'a'+1]++;
		for(int i=1;i<=26;i++) if(f[i]==len) {puts("-1");con=1;break;}
		if(con) continue;
		if(check()) puts("2");
		else puts("1");
		init();
	}
	return 0;
}

