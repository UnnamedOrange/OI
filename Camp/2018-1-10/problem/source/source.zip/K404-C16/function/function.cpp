#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0;char ch=getchar();
	while(ch<'0'||'9'<ch)ch=getchar();
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret;
}
#define N 1000010
#define M 1000000
#define ll long long
ll mu[N];
ll xt[N],f[N],s[N];
void init(){
	memset(f,0,sizeof(f));
	memset(s,0,sizeof(s));
	memset(xt,0,sizeof(xt));
	memset(mu,0,sizeof(mu));
	mu[1]=1;
	int alg=0;
	for(int i=2;i<=M;i++){
		if(mu[i]==0){
			s[alg++]=i;
			for(int j=0;j<alg;j++){
				if(i*s[j]>M)
					break;
				mu[i*s[j]]=1;
				if(i%s[j]==0)
					break;
			}
		}else{
			for(int j=0;j<alg;j++){
				if(i*s[j]>M)
					break;
				mu[i*s[j]]=-1*mu[i];
				if(i%s[j]==0)
					break;
			}
		}
	}
	for(int i=1;i<=M;i++)
		for(int j=1;i*j<=M;j++)
			xt[i*j]++;
	for(int i=1;i<=M;i++)
		xt[i]=xt[i]*xt[i];
	for(int i=1;i<=M;i++)
		for(int j=1;i*j<=M;j++)
			f[i*j]+=mu[i]*xt[j];
	for(int i=2;i<=M;i++)
		f[i]+=f[i-1];
	return;
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int t=re();
	init();
	while(t--)
		printf("%lld\n",f[re()]);
	return 0;
}
