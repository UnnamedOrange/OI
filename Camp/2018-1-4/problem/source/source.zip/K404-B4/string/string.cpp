#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <ctime>
#include <sstream>
#define Nxt nxt[x]
#define Str str[x]
using namespace std;
inline int read()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch<='9'&&ch>='0')x=x*10+ch-'0',ch=getchar();
	return x;
}
int n,m,cnt,nxt[6][1000];
char s[1010],str[10][500];
void build(int x)
{
	for(int i=1,len=strlen(Str);i<len;i++)
	{
		int j=i;
		while(j)
		{
			j=Nxt[j];
			if(Str[i]==Str[j])
			{
				Nxt[i+1]=j+1;
				break;
			}
		}
	}
}
bool find(int x)
{ 
	for(int i=0,j=0,len=strlen(Str);i<2*m;i++)
	{
		if(j<len&&s[i]==Str[j])
		{
			j++;
		}
		else
		{
			while(j>0)
			{
				j=Nxt[j];
				if(s[i]==Str[j])
				{
					j++;
					break;
				}
			}
		}
		if(j==len)
		{
			return 1;
		}
	}
	return 0;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>str[i];
		build(i);
	}
	for(int i=0;i<(1<<m);i++)
	{
		int temp=i,j=0;
		for(j=0;j<m;j++)
		{
			s[j]=((temp&1)+'0');
			temp>>=1;
		}
		for(int k=m-1;k>=0;k--,j++)
		{
			s[j]=(s[k]=='0'?'1':'0');
		}
		bool flag=1;
		for(int i=1;i<=n;i++)
		{
			flag&=find(i);
		}
		cnt+=flag;
	}
	cout<<cnt<<endl;
	return 0;
}
/*
2 3
011
001
*/
