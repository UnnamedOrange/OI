#include<bits/stdc++.h>
using namespace std;

int check(char x[],int n)
{
	char y[110000],z[110000],zz[110000];
	for (int i=0;i<n;i++) 
	  y[n-i-1]=x[i];
	for (int i=0;i<n;i++) if (y[i]!=x[i]) return 1;
	for (int i=0;i<n-1;i++)
	  {
	  	if (x[i]!=x[i+1])
	  	  {
	  	  	for (int j=0;j<i;j++) z[j]=x[j];
	  	  	for (int j=i+2;j<n;j++) z[j-2]=x[j];
	  	  	for (int j=0;j<n-2;j++) zz[n-3-j]=z[j];
	  	  	for (int j=0;j<n-2;j++)
	  	  	  {
	  	  	  	if (z[j]!=zz[j]) return 2;
			  }
			if (i==0) return -1;
			return 2;  
		  }
	  }
	return -1;  
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int t;
	scanf("%d",&t);
	for (int i=1;i<=t;i++)
	  {
	  	char s[110000];
	  	int n;
	  	scanf("%d",&n);
	  	scanf("%s",s);
	  	printf("%d\n",check(s,n));
	  }
	return 0;  
}
