#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
const int maxn=1e5+5;
char s[maxn];
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int t,n;
	scanf("%d",&t);
	while(t--){
		int num=0,f=0;
		memset(s,0,sizeof(s));
		scanf("%d%s",&n,s);
		char x=s[0];//�ж�-1�� 
		for(int i=0;i<n;i++) if(x==s[i]) num++;
		if(num==n){
			printf("-1\n");
			continue;
		}
		int ans=0,ss=1,sss=1;
		for(int i=0;i<n-2;i+=2) if(s[i+2]==s[i]) ss++;
		for(int i=1;i<n-2;i+=2) if(s[i+2]==s[i]) sss++;
		if(ss==n/2&&sss==n/2){
			printf("%d",(n+1)/2);
			continue;
		}
		for(int i=0;i<n;i++){
			for(int j=n-1;j>=i;j--){
				if(j==i&&i!=n-1){
					f=1;
					break;
				}
				if(s[i]!=s[j]){
					i=j+1;
					j=n-1;
					ans++;
				}
				if(i==n-1) ans++;
			}
			if(f) break;
		}
		if(!f) printf("%d\n",ans);
		else printf("-1\n");
	}
	return 0;
}
