#include <bits/stdc++.h>

int type, N;

void init()
{
    
}

int encode(int x, int y)
{
	int tmp=x^y,tmp2;
	for(int i=0;(1<<i)<=tmp;i++) {
		if((1<<i)&tmp) {tmp2=i;break;}
	}
	int ans=0;
	if(x&(1<<tmp2)) ans=tmp2+1+10;
	else ans=tmp2+1;
    return ans;
}

bool decode(int q, int h)
{
	if(h>10) {
		h-=11;
		if(q&(1<<h)) return 1;
		return 0;
	} else {
		h--;
		if(q&(1<<h)) return 0;
		return 1;
	}
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
