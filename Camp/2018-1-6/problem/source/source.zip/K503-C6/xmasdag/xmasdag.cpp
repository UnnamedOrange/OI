#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <queue>

using namespace std;
typedef long long ll;
const ll mod = 998244353;

struct edge{
	int to, nxt;
}e[200005];

int h[100005], cnt;

void addedge(int x, int y){
	cnt++; e[cnt].to = y; e[cnt].nxt = h[x]; h[x] = cnt;
}
int n, m, K;
ll C[505][505];
void pre(){
	C[0][0] = 1;
	for(int i = 1; i <= K; i ++){
		C[i][0] = 1;
		for(int j = 1; j <= i; j ++){
			C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % mod;
		}
	}
}
int du[100005];
queue<int> q;
int f[100005][31];
int main(){
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &K);
	for(int i = 1; i <= m; i ++){
		int x, y;
		scanf("%d%d", &x, &y);
		//x = i, y = i + 1;
		addedge(x, y);
		du[y] ++;
	}
	q.push(1);
	f[1][0] = 1;
	pre();
	while(!q.empty()){
		int x = q.front();
		q.pop();
		for(int i = h[x]; i; i = e[i].nxt){
			for(int j = 0; j <= K; j ++){
				for(int k = 0; k <= j; k ++){
					f[e[i].to][j] = (f[e[i].to][j] + 1ll * f[x][k] * C[j][k]) % mod;
				}
			}
			du[e[i].to] --;
			if(du[e[i].to] == 0) q.push(e[i].to);
		}
	}
	for(int i = 1; i <= n; i ++){
		printf("%d\n", f[i][K]);
	}
	return 0;
}
