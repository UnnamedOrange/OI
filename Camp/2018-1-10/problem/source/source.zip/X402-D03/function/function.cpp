#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 1000010;
const ll MOD = 1000000007;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, r[MAXN];
int mu[MAXN], p[MAXN], cnt, Mu[MAXN];
ll sig[MAXN], f[MAXN], ans;
bool np[MAXN];

inline void getprime() {
	int i, j, x;
	mu[1] = sig[1] = 1;
	for(i = 2; i <= 1000000; i++) {
		if(!np[i]) {
			p[++cnt] = i, mu[i] = -1;
			sig[i] = 2, r[i] = 1;
		}
		for(j = 1; j <= cnt && (x = p[j]*i) <= 1000000; j++) {
			np[x] = true;
			if(i % p[j]) {
				mu[x] = -mu[i]; r[x] = i;
				sig[x] = sig[i]*2%MOD;
			}
			else {
				mu[x] = 0; r[x] = r[i];
				sig[x] = (sig[i]+sig[r[i]])%MOD;
				break;
			}
		}
	}
	for(i = 1; i <= 1000000; i++) {
		f[i] = (f[i-1]+sig[i]*sig[i]%MOD)%MOD;
		Mu[i] = (Mu[i-1]+mu[i]+MOD)%MOD;
		//printf("%lld\n", sig[i]);
	}
	/*for(i = 1; i <= 1000000; i++) 
		for(j = 1; j*i <= 1000000; j++) 
			tmp[i*j] = (tmp[i*j]+sig[i]*sig[i]%MOD)%MOD;*/
	/*for(i = 1; i <= 1000000; i++)
		for(j = 1; j*i <= 1000000; j++)
			t[i*j] = (t[i*j]+tmp[i])%MOD;*/
	/*for(i = 1; i <= 1000000; i++)
		printf("%lld\n", tmp[i]);*/
}

int main() {
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);

	int T = read(), i, j;
	getprime();
	while(T--) {
		n = read();
		ans = 0;
		for(i = 1; i <= n; i = j+1) {
			j = n/(n/i);
			ans = (ans + ((Mu[j]-Mu[i-1])%MOD+MOD)%MOD*f[n/i]%MOD)%MOD;
		}
		printf("%lld\n", ans);
	}
	return 0;
}
