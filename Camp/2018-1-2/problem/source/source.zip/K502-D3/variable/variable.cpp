#include <cstdio>
#include <cstring>
#include <algorithm>
#define ele long long
using namespace std;
#define maxn 25
ele n,W,p,q,ans,w[maxn],x[maxn],y[maxn],z[maxn],a[maxn],b[maxn],c[maxn],d[maxn],e[maxn],f[maxn];
ele rx[maxn],ry[maxn],rr[maxn];
inline bool chk(ele x,ele y,ele r){
	if (r==0) return w[x]<=w[y];
	if (r==1) return w[x]==w[y];
	if (r==2) return w[x]<w[y];
}
inline ele _abs(ele x){
	return (x<0)?-x:x;
}
void dfs(ele i){
	if (i==n){
		for (int j=0; j<q; ++j)
			if (!chk(rx[j],ry[j],rr[j])) return;
		ele tmp=0;
		for (int j=0; j<n; ++j) tmp+=w[j];
		for (int j=0; j<p; ++j){
			tmp+=a[j]*_abs(w[x[j]]-w[y[j]]);
			tmp+=b[j]*_abs(w[y[j]]-w[z[j]]);
			tmp+=c[j]*_abs(w[z[j]]-w[x[j]]);
			tmp+=d[j]*(w[x[j]]-w[y[j]]);
			tmp+=e[j]*(w[y[j]]-w[z[j]]);
			tmp+=f[j]*(w[z[j]]-w[x[j]]);
		}
		ans=min(ans,tmp);
		return;
	}
	w[i]=-1;
	dfs(i+1);
	w[i]=1;
	dfs(i+1);
}
int main(){
	freopen("variable.in","r",stdin); freopen("variable.out","w",stdout);
	ele T;
	scanf("%lld",&T);
	while (T--){
		scanf("%lld%lld%lld%lld",&n,&W,&p,&q);
		for (int i=0; i<p; ++i){
			scanf("%lld%lld%lld%lld%lld%lld%lld%lld%lld",x+i,y+i,z+i,a+i,b+i,c+i,d+i,e+i,f+i);
			--x[i],--y[i],--z[i];
		}
		for (int i=0; i<q; ++i) scanf("%lld%lld%lld",rx+i,ry+i,rr+i),--rx[i],--ry[i];
		ans=1000000000000000000LL;
		dfs(0);
		printf("%lld\n",ans*_abs(W));
	}
	return 0;
}