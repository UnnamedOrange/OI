#include<bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int miu[1000005], chu[1000005], mix[1000005];
long long g1[1000005], g0[1000005], f[1000005];
int prime[1000005];
bool heshu[1000005];
int cnt;
inline void init() {
	miu[1] = 1, chu[1] = 1, f[1] = 1;
	for(int i = 2; i <= 1000000; ++i) {
		if(!heshu[i]) prime[++cnt] = i, mix[i] = 1, chu[i] = 2, miu[i] = -1, f[i] = 3, g0[i] = 4, g1[i] = -1;
		for(int j = 1; i * prime[j] <= 1000000 && j <= cnt; ++j) {
			heshu[i * prime[j]] = 1;
			if(i % prime[j]) {
				miu[i * prime[j]] = -miu[i];
				chu[i * prime[j]] = chu[i] << 1;
				mix[i * prime[j]] = 1;
				f[i * prime[j]] = f[i] * 3;
				g0[i * prime[j]] = f[i] * 4;
				g1[i * prime[j]] = -f[i];
			} else {
				miu[i * prime[j]] = 0;
				chu[i * prime[j]] = (chu[i] / (mix[i] + 1)) * (mix[i] + 2);
				mix[i * prime[j]] = mix[i] + 1;
				g0[i * prime[j]] = (g0[i] / ((long long)mix[i] + 1)) * (mix[i] + 2) / ((long long)mix[i] + 1) * (mix[i] + 2);
				g1[i * prime[j]] = (g1[i] / ((long long)mix[i])) * (mix[i] + 1) / ((long long)mix[i]) * (mix[i] + 1);
				f[i * prime[j]] = g0[i * prime[j]] + g1[i * prime[j]];
			}
		}
	}
}
int main() {
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
//	long long st = clock();
	init();
//	cout << clock() - st<<'\n';
//	int a = 12;
//	printf("miu[%d] = %d, chu[%d] = %d\n", a, miu[a], a, chu[a]);
	int T;
	R(T);
	int n;
	while(T--) {
		R(n);
		long long ans = 0;
		for(int d = 1; d <= n; ++d) {
			ans += f[d];
		}
		cout<<ans<<'\n';
	}
}
