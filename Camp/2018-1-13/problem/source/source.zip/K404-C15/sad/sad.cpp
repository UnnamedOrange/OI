#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 100005, P = 998244353;
int n, col[N], d[N], black = 1;
int ecnt, adj[N], nxt[2*N], go[2*N];
ll k[N], b[N];
char s[N];

ll qpow(ll a, ll x){
	ll ret = 1;
	while(x){
		if(x & 1) ret = ret * a % P;
		a = a * a % P;
		x >>= 1;
	}
	return ret;
}
ll inv(ll x){
	return qpow(x, P - 2);
}
ll mo(ll x){
	x %= P;
	return x < 0 ? x + P : x;
}
void add(int u, int v){
	go[++ecnt] = v;
	nxt[ecnt] = adj[u];
	adj[u] = ecnt;
	d[u]++;
}
void dfs1(int u, int pre){
	if(d[u] == 1){
		k[u] = 0, b[u] = 1;
		return;
	}
	ll sumk = 1, sumb = 1, invd = inv(d[u]);
	for(int e = adj[u], v; e; e = nxt[e])
		if(v = go[e], v != pre){
			dfs1(v, u);
			sumk = mo(sumk - invd * k[v] % P);
			sumb = mo(sumb + invd * b[v] % P);
		}
	sumk = inv(sumk);
	k[u] = mo(invd * sumk);
	b[u] = mo(sumb * sumk);
}

int to[15][15];
ll magic = 2 * 5;
double cnt;
bool vis[15];

void solve1(){
	for(int i = 1, u, v; i < n; i++)
		read(u), read(v), to[u][++d[u]] = v, to[v][++d[v]] = u;
	int T = 1000000;
	for(int t = 1; t <= T; t++){
		int p = 1;
		memset(vis, 0, sizeof(vis));
		while(1){
			//printf("t = %d, p = %d\n", t, p);
			if(col[p] || !vis[p]) cnt += 1;
			vis[p] = 1;
			if(d[p] == 1) break;
			p = to[p][rand() % d[p] + 1];
		}
	}
	//printf("%lf\n", cnt / T);
	ll num = (ll)floor(cnt / T * magic + 0.5) % P;
	write(num * inv(magic) % P), enter;
}

int main(){
	
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	
	read(n);
	scanf("%s", s + 1);
	for(int i = 1; i <= n; i++){
		col[i] = s[i] - '0';
		if(!col[i]) black = 0;
	}
	if(!black){
		if(n <= 6) solve1();
		else puts("0");
		return 0;
	}
	for(int i = 1, u, v; i < n; i++)
		read(u), read(v), add(u, v), add(v, u);
	dfs1(1, 0);
	write(b[1]), enter;
	
	return 0;
}
