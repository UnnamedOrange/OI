#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=4e3+10;
int nexa[maxn][maxn],nexb[maxn][maxn],a[maxn],b[maxn],dp[maxn][maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,s;
#ifndef ONLINE_JUDGE
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
#endif
	n=read();m=read();k=read();
	for(i=1;i<=n;i++)a[i]=read();
	for(i=1;i<=m;i++)b[i]=read();
	for(i=1;i<=k;i++){
		int nexpos=n+1;
		for(j=n+1;j>=0;j--){
			nexa[j][i]=nexpos;
			if(a[j]==i)nexpos=j;
		}
	}
	for(i=1;i<=k;i++){
		int nexpos=m+1;
		for(j=m+1;j>=0;j--){
			nexb[j][i]=nexpos;
			if(b[j]==i)nexpos=j;
		}
	}
	memset(dp,63,sizeof(dp));
	dp[0][0]=0;
	for(i=0;i<=n+1;i++)
		for(j=0;j<=m+1;j++){
			if(dp[i][j]>INF)continue;
			for(s=1;s<=k;s++)
				dp[nexa[i][s]][nexb[j][s]]=min(dp[nexa[i][s]][nexb[j][s]],dp[i][j]+1);
		}
	printf("%d\n",dp[n+1][m+1]);
	return 0;
}

