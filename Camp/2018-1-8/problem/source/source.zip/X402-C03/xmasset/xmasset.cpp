#include<bits/stdc++.h>
using namespace std;

int casen,type,n,cnt3=5,cnt2=2;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}
inline void init(){
	for(int i=2;i<=n;++i){
		int c3,c2,maxn=1;
		if(i%3==0)
			c3=i/3,c2=0;
		else if(i%3==1)
			c3=i/3-1,c2=2;
		else
			c3=i/3,c2=1;
		for(int i=1;i<=c3;++i)
			maxn*=3;
		for(int i=1;i<=c2;++i)
			maxn*=2;
		if(maxn>=n){
			cnt3=c3;cnt2=c2;
			return;
		}
	}
}
inline int encode(int x,int y){
	int res=1;
	for(int i=0;i<cnt2;++i)
		if((x^y)&1)
			return res+(x&1);
		else
			x>>=1,y>>=1,res+=2;
	for(int i=0;i<cnt3;++i)
		if(x%3!=y%3)
			return res+x%3;
		else
			x/=3,y/=3,res+=3;
}
inline bool decode(int q,int h){
	for(int i=0;i<cnt2;++i)
		if(h<=2)
			return (q&1)==h-1;
		else
			q>>=1,h-=2;
	for(int i=0;i<cnt3;++i)
		if(h<=3)
			return q%3==h-1;
		else
			q/=3,h-=3;
}

int main(){
	type=read();n=read();casen=read();
	init();
    while(casen--){
        int x=read(),y=read();
        if(type==1)
            printf("%d\n",encode(x, y));
        else
            puts(decode(x,y)?"yes":"no");
    }
	return 0;
}
