#include <bits/stdc++.h>
using namespace std;

const int Maxn = 1111111, Max = 25;
struct Node {
	int w, id;
} a[Maxn];
inline bool cmp(const Node &i, const Node &j) {
	return (i.w > j.w);
}

int n, l[Max], r[Max];
double pow2[Max];
set<int> b;

int getint() {
	int c = getchar(), ret = 0;
	while (!isdigit(c)) {
		c = getchar();
	}
	do {
		ret = ret*10+c-48;
		c = getchar();
	} while (isdigit(c));
	return ret;
}

int main() {
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	n = getint();
	for (int i = 1; i <= n; ++i) {
		a[i].w = getint(), a[i].id = i;
	}
	sort(a+1, a+n+1, cmp);
	pow2[0] = 1;
	for (int i = 1; i < Max; ++i) {
		pow2[i] = pow2[i-1]*2;
	}
	double ans = 0;
	for (int i = 1, cntl, cntr; i <= n; ++i) {
		b.insert(a[i].id);
		cntr = 0;
		for (auto it = ++b.find(a[i].id); it != b.end(); ++it) {
			r[cntr++] = *it-*(--it), ++it;
			if (cntr == Max) {
				break;
			}
		}
		if (cntr != Max) {
			r[cntr++] = n-*b.rbegin()+1;
		}
		cntl = 0;
		set<int>::reverse_iterator it(b.find(a[i].id)), last;
		for (; it != b.rend(); ++it) {
			last = --it, ++it;
			l[cntl++] = *last-*it;
			if (cntl == Max) {
				break;
			}
		}
		if (cntl != Max) {
			l[cntl++] = *b.begin();
		}
		double suml = 0, sumr = 0;
		for (int j = 0; j < cntl; ++j) {
			suml += l[j]/pow2[j];
		}
		for (int j = 0; j < cntr; ++j) {
			sumr += r[j]/pow2[j];
		}
		ans += suml*sumr/2*a[i].w;
	}
	ans /= n, ans /= n;
	printf("%.10lf\n", ans);
	return 0;
}
