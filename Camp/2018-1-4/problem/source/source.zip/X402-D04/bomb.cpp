#include<bits/stdc++.h>
using namespace std;

const int maxn=1000010;
int n,m;
vector<int> g[maxn];
int dp[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}
void chkmax(int& x,int y){ if(x<y) x=y; }

int to[maxn], Next[maxn], Begin[maxn], e;
void add(int x,int y){
	to[++e]=y, Next[e]=Begin[x], Begin[x]=e;
}

int dfn[maxn], low[maxn], cnt, bel[maxn], c;
int st[maxn], top, size[maxn];
void dfs(int x){
	dfn[x]=low[x]=++cnt;
	st[++top]=x;
	for(int i=Begin[x];i;i=Next[i]){
		int v=to[i];
		if(!dfn[v]) dfs(v), low[x]=min(low[x], low[v]);
		else if(!bel[v]) low[x]=min(low[x], dfn[v]);
	}
	if(dfn[x]==low[x]){
		bel[x]=++c; size[c]=1;
		while(top && st[top]!=x){
			bel[st[top--]]=c; size[c]++;
		}
		top--;
	}
}

int a[maxn], tot, deg[maxn];
void topsort(){
	queue<int> q;
	for(int i=1;i<=c;i++) if(!deg[i]) q.push(i);
	while(!q.empty()){
		int u=q.front(); q.pop();
		a[++tot]=u;
		for(int i=0;i<g[u].size();i++){
			int v=g[u][i];
			if(!(--deg[v])) q.push(v);
		}
	}
}

int main(){
	freopen("bomb.in","r",stdin),freopen("bomb.out","w",stdout);

	read(n), read(m);
	int x, y;
	for(int i=1;i<=m;i++){
		read(x), read(y);
		add(x, y);
	}
	for(int i=1;i<=n;i++) if(!dfn[i]) dfs(i);
	int tmp=0;
	for(int i=1;i<=n;i++){
		for(int j=Begin[i];j;j=Next[j]){
			int v=to[j];
			if(bel[i]!=bel[v]) g[bel[i]].push_back(bel[v]), deg[bel[v]]++;
		}
	}
	topsort();
	int ans=0;
	for(int i=1;i<=c;i++){
		int now=a[i];
		chkmax(dp[now], size[now]);
		for(int j=0;j<g[now].size();j++) chkmax(dp[ g[now][j] ], dp[now]+size[ g[now][j] ]);
		chkmax(ans, dp[now]);
	}
	printf("%d\n", ans);
	return 0;
}
