#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while(!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while(isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n = n * sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int MOD = 998244353;
const int N = 122222;
int n, m, k;
int fac[N], inv[N];

int C(int n, int m){
	return (ll)fac[n] * inv[m] % MOD * inv[n-m] % MOD;
}
ll mut(ll a, ll b){
	ll y = 1, t = a;
	for (; b; b >>= 1, t = t * t % MOD)
		if (b & 1) y = y * t % MOD;
	return y; 
}
namespace bf{
	const int N = 15;
	int ans, vis[N];
	struct edge{int to, nxt;} g[N*N];
	int ghead[N], gtail;
	void add(int l, int r){g[++gtail] = (edge){r, ghead[l]}, ghead[l] = gtail;}
	bool dfs(int x, int d, int des){
		vis[x] = 1;
		int ans = false;
		for (int p = ghead[x]; p; p = g[p].nxt){
			int v = g[p].to;
			if (v == des&&d + 1 == k) return true;
			if (!vis[v]) ans |= dfs(v, d + 1, des);
		}
		return ans;
	}
	int main(){
		rep(s, 0, (1 << m) - 1){
			rep(i, 1, n) ghead[i] = 0; gtail = 0;
			int cnt = 0;
			rep(i, 1, n) rep(j, i + 1, n)
				if ((s >> (++cnt) - 1) & 1)
					add(i, j);
				else add(j, i);
			bool flg = false;
			rep(i, 1, n){
				memset(vis, 0, sizeof(vis));
				flg |= dfs(i, 0, i);
			}
			if (flg) ans++;
		}
		printf("%d\n", ans);
		return 0;
	}
};

int main(){
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	read(n), read(k); m = n * (n - 1) / 2;
	fac[0] = 1; rep(i, 1, n) fac[i] = (ll)fac[i-1] * i % MOD;
	inv[0] = inv[1] = 1; 
	rep(i, 2, n) inv[i] = ll(MOD - MOD / i) * inv[MOD%i] % MOD;
	rep(i, 2, n) inv[i] = (ll)inv[i-1] * inv[i] % MOD;
	if (n <= 10){bf::main(); return 0;}
	if (k == 3){
		printf("%d\n", (mut(2, m) - fac[n] + MOD) % MOD); 
		return 0;
	}
	cout << (ll)fac[n-1] * mut(2, m - n) % MOD << endl;
	return 0;
}

