#include <cctype>
#include <cstdio>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

using namespace std;

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;
}

const int p=1e9+7,N=1e5+10;
int n,a,b,cnt[4],ans[4],pw[N];
bool f;

void special()
{
    rep(i,1,n)
    {
        int x=get()%(a+b);
        ++cnt[(x>=a)+(x>=b)];
    }
    ans[0]=pw[cnt[0]];
    ans[3]=1ll*pw[cnt[0]]*cnt[2]%p;
    ans[2]=(1ll*pw[n]+p-ans[0]+p-ans[3])%p;
    if (f)
        swap(ans[1],ans[2]);
    printf("%d %d %d %d",ans[2],ans[1],ans[3],ans[0]);
}

int main()
{
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
    n=get(),a=get(),b=get();
    if (a>b)
        swap(a,b),f=1;
    pw[0]=1;
    rep(i,1,n)
        pw[i]=pw[i-1]<<1,pw[i]<p? 0:pw[i]-=p;
    if (a<<1<=b)
    {
        special();
        return 0;
    }
    rep(i,1,n)
    {
        int x=get()%(a+b);
        ++cnt[(x>=a)+(x>=b)+(x>=a<<1)];
    }
    int x=cnt[2]? 1ll*pw[cnt[0]]*pw[cnt[2]-1]%p:pw[cnt[0]];
    int y=1ll*x*cnt[3]%p;
    if (cnt[2])
        ans[0]=x,ans[2]=y,ans[3]=(x+y)%p;
    else
        ans[0]=x,ans[2]=ans[3]=y;
    int t=(1ll*pw[n]+p-ans[0]+p-ans[1]+p-ans[2]+p-ans[3])%p;
    ans[2]=(ans[2]+t)%p;
    if (f)
        swap(ans[1],ans[2]);
    printf("%d %d %d %d",ans[2],ans[1],ans[3],ans[0]);
    return 0;
}
