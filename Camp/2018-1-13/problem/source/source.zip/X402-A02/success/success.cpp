/*=============================================================================
#
# Author: Christopher - ljfcnyali@gmail.com
#
# QQ : 2358836981
#
# Last modified: 2018-01-13 10:02
#
# Filename: success.cpp
#
# CopyRight 
#
=============================================================================*/

#include<bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 
#define mem(a) memset ( (a), 0, sizeof (a) ) 
#define str(a) strlen ( a ) 
#define all(a) a.begin(), a.end()
typedef long long LL;
template<class T> int mmax(T a, T b) { return a > b ? a : b; }
template<class T> int mmin(T a, T b) { return a < b ? a : b; }
template<class T> int aabs(T a) { return a < 0 ? -a : a; }
#define max mmax
#define min mmin
#define abs aabs

#define mod 1000000007

const int maxn = 110;

int n, m, s, t, dp[maxn][maxn], ans;

int main()
{
    freopen("success.in", "r", stdin);
    freopen("success.out", "w", stdout);
    scanf("%d%d%d%d", &s, &t, &n, &m);    
    dp[0][0] = 1; 
    REP(i, 1, m)
    {
        REP(j, 1, s)
        {
            if ( i <= n )
            {
                REP(k, max(j - t, 0), j - 1)
                {
                    dp[i][j] = (dp[i][j] + dp[i - 1][k]) % mod;
                }
            }
            else 
            {
                REP(k, 0, j - 1)
                {
                    dp[i][j] = (dp[i][j] + dp[i - 1][k]) % mod;
                }
            }
            if ( i == m )
            {
                ans += dp[i][j];
            }
        }
    }
    printf("%d\n", ans);
    return 0;
}

