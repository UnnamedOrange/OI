#include<iostream>
#include<assert.h>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int N=100009;
const int md=1e9+7;

int n,a[2];
int x[N],s[N],ans[4];

inline bool dfss(int p,int d=0)
{
	for(int i=1;i<=n;i++)
	{
		if(s[i]>=a[p])
		{
			s[i]-=a[p];
			if(!dfss(p^1,d+1))
			{
				s[i]+=a[p];
				return 1;
			}
			s[i]+=a[p];
		}
	}
	return 0;
}

inline void chk(int &a)
{
	if(a>=md)a-=md;
}

inline void play()
{
	int fa=dfss(0),fb=dfss(1);
	if(fa && !fb)
		chk(++ans[0]);
	else if(!fa && fb)
		chk(++ans[1]);
	else if(fa && fb)
		chk(++ans[2]);
	else
		chk(++ans[3]);
}

inline void dfs(int pos)
{
	if(pos==n+1)
	{
		play();
		return;
	}

	s[pos]=x[pos];
	dfs(pos+1);
	s[pos]=0;
	dfs(pos+1);
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);

	scanf("%d%d%d",&n,&a[0],&a[1]);
	for(int i=1;i<=n;i++)
		scanf("%d",&x[i]);
	dfs(1);
	for(int i=0;i<=3;i++)
		printf("%d ",ans[i]);
	puts("");
	return 0;
}
