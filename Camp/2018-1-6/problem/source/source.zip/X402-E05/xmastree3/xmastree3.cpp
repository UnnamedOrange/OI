#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define bitcnt(x) __builtin_popcountll(x)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=110;
const int L=16;
const int mod=998244353;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
}
int n,K;
int bgn[N],nxt[N<<1],to[N<<1],E;
int dp[2000000][L],S[2000000][L];
vector<LL>G,St[N],T;
map<LL,int>mp;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void Add(int &x,int y){x=x+y<mod?x+y:x+y-mod;}
inline LL dfs(int u,int f,int x)
{
	LL now=1ll<<(u-1ll);
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		if((x>>(v-1ll))&1ll)now|=dfs(v,u,x);
	}
	return now;
}
inline void Solve()
{
	For(now,0,SZ(T)-1)
	{
		LL x=T[now]; 
		if(bitcnt(x)==1)For(j,1,K)dp[now][j]=1;
		else
		{
			For(u,1,n)
			if((x>>(u-1))&1)
			{
				for(int v,i=bgn[u];i;i=nxt[i])if((x>>((v=to[i])-1))&1)G.pb(mp[dfs(v,u,x)]);
				For(i,1,K)
				{
					LL ret=1;
					For(j,0,SZ(G)-1)ret=ret*S[G[j]][i-1]%mod;
					Add(dp[now][i],ret);
				}
				G.clear();
			}
		}
		For(i,1,K)Add(S[now][i]=dp[now][i],S[now][i-1]);
	}
	printf("%d\n",S[mp[(1<<n)-1]][K]);
}
inline void Get_st(int u,int f)
{
	St[u].pb(1<<(u-1));
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		Get_st(v,u);
		For(x,0,SZ(St[u])-1)
			For(y,0,SZ(St[v])-1)
				St[u].pb(St[u][x]|St[v][y]);
	}
}
int main()
{
	int x,y;
	file();
	read(n),read(K);
	For(i,2,n)read(x),read(y),add_edge(x,y),add_edge(y,x);
	Get_st(1,0);
	For(i,1,n)
	{
		For(j,0,SZ(St[i])-1)T.pb(St[i][j]);
		St[i].clear();
	}
	sort(T.begin(),T.end());
	For(i,0,SZ(T)-1)mp[T[i]]=i;
	//cerr<<SZ(T)<<endl;
	Solve();
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	//assert((double)clock()/CLOCKS_PER_SEC<=2.0);
	//cerr<<((sizeof(S)+sizeof(dp)+sizeof(mp)+sizeof(T))>>20ll)<<endl;
	return 0;
}
