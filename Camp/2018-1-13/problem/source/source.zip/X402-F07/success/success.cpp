#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1005,mod=1e9+7;
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1)res=1ll*res*x%mod;
		x=1ll*x*x%mod,y>>=1;
	}return res;
}
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
	if(x<0)x+=mod;
}
int fac[maxn],ifac[maxn];
void init(){
	int n=100;
	fac[0]=1;
	REP(i,1,n)fac[i]=1ll*fac[i-1]*i%mod;
	ifac[n]=ksm(fac[n],mod-2);
	DREP(i,n,1)ifac[i-1]=1ll*ifac[i]*i%mod;
}
int C(int x,int y){
	if(x<y)return 0;
	return 1ll*fac[x]*ifac[y]%mod*ifac[x-y]%mod;
}
int s,t,n,m;
int f[maxn][maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
#endif
	init();
	s=read(),t=read(),n=read(),m=read();
	f[0][0]=1;
	REP(i,1,n)REP(j,i,s){
		f[i][j]=(f[i][j-1]+f[i-1][j-1])%mod;
		if(j-t-1>=i-1)add(f[i][j],-f[i-1][j-t-1]);
	}
	int ans=0;
	REP(j,1,s)
		add(ans,1ll*f[n][j]*C(s-j,m-n)%mod);
	write(ans,'\n');
	return 0;
}
