#include<bits/stdc++.h>
#include <tr1/unordered_map>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-')p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v=-v;
}
int T;
int n;
int a[30], x[30], ans;
tr1::unordered_map<unsigned long long, int> ma;
inline void tanxin1(int p) {
	int ret = 1;
	reverse(x + 1, x + p + 1);
	for(int i = n; i; --i) {
		if(x[i] == i) continue;
		if(x[1] == i) {
			reverse(x + 1, x + i + 1);
			++ret;
		} else {
			for(int j = 2; j < i; ++j) {
				if(x[j] == i) {
					reverse(x + 1, x + j + 1);
					reverse(x + 1, x + i + 1);
					ret += 2;
					break;
				}
			}
		}
	}
	ans = min(ans, ret);
}
inline void tanxin() {
	int ret = 0;
	for(int i = n; i; --i) {
		if(x[i] == i) continue;
		if(x[1] == i) {
			reverse(x + 1, x + i + 1);
			++ret;
		} else {
			for(int j = 2; j < i; ++j) {
				if(x[j] == i) {
					reverse(x + 1, x + j + 1);
					reverse(x + 1, x + i + 1);
					ret += 2;
					break;
				}
			}
		}
	}
	ans = min(ans, ret);
}
inline bool check() {
	for(int i = 1; i <= n; ++i) {
		if(x[i] != i) return 0;
	}
	return 1;
}
unsigned long long now = 0;
inline void dfs(int ti) {
	if(check()) {
		ans = min(ans, ti);
	}
	if(ti >= ans) return;
	now = 0;
	for(int i = 1; i <= n; ++i) {
		now = (now << 4) + x[i];
	}
	if(ma.find(now) != ma.end()) {
		if(ma[now] <= ti) {
			return;
		} else ma[now] = ti;
	} else ma[now] = ti;
	for(int i = 2; i < n; ++i) {
		reverse(x + 1, x + i + 1);
		dfs(ti + 1);
		reverse(x + 1, x + i + 1);
	}
}
int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	R(T);
	int cnt = 0;
	while(T--) {
		ans = 0x3f3f3f3f;
		R(n);
		ma.clear();
		++cnt;
		for(int i = 1; i <= n; ++i) {
			R(a[i]);
			x[i] = a[i];
		}
		if(n <= 8) {
			for(int j = 2; j <= n; ++j) {
				tanxin1(j);
				for(int i = 1; i <= n; ++i) {
					x[i] = a[i];
				}
			}
			tanxin();
			/*for(int i = 1; i <= n; ++i) {
				printf("%d ", x[i]);
			}
			printf("\nans = %d\n", ans);*/
			for(int i = 1; i <= n; ++i) {
				x[i] = a[i];
			}
			int zong = n;
			for(int j = n; j; --j) {
				if(x[j] == j) --zong;
				else break;
			}
			dfs(0);
			printf("%d\n", ans);
		} else {
			for(int j = 2; j <= n; ++j) {
				tanxin1(j);
				for(int i = 1; i <= n; ++i) {
					x[i] = a[i];
				}
			}
			tanxin();
			printf("%d\n", ans);
		}
	}
}
