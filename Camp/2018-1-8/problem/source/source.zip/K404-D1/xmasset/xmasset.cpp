#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int type,N;
int encode(int x,int y)
{
    return x;
}
bool decode(int q,int h)
{
    return q == h;
}
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("xmasset.in","r",stdin);
    freopen("xmasset.out","w",stdout);
    int T;
    scanf("%d%d%d",&type,&N,&T);
    while (T--)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        if (type == 1)
            printf("%d\n",encode(x,y));
        else
            puts(decode(x,y)?"yes":"no");
    }
}
