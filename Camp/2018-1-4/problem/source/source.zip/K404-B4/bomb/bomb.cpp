#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <ctime>
using namespace std;
inline int read()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch<='9'&&ch>='0')x=x*10+ch-'0',ch=getchar();
	return x;
}
bool a[11][11];
int n,m;
int d[1<<10],b[1<<10];
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	memset(d,0x3f,sizeof(d));
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int t1=read(),t2=read();
		a[t1][t2]=1;
	}
	for(int k=1;k<=m;k++)
	{
		for(int i=1;i<=m;i++)
		{
			for(int j=1;j<=m;j++)
			{
				a[i][j]|=a[i][k]&&a[k][j];
			}
		}
	}
	for(int i=1;i<(1<<n);i++)
	{
		b[i]=1;
		for(int j=0;j<n;j++)
		{
			if(!(i&(1<<j)))continue;
			for(int k=0;k<n;k++)
			{
				if(a[j+1][k+1]&&(i&(1<<k))&&j!=k)
				{
					b[i]=0;
					goto label;
				}
			}
		}
//		cout<<i<<endl;
		label:;
	}
	d[0]=0;
	for(int i=0;i<(1<<n);i++)
	{
		if(d[i]==0x3f3f3f3f)continue;
		for(int j=0;j<(1<<n);j++)
		{
			if(b[j])d[i|j]=min(d[i|j],d[i]+1);
		}
	}
	cout<<d[(1<<n)-1]<<endl<<endl; 
	return 0;
}
/*
1 4
1 5
2 4
2 5
3 4
3 5

*/
