#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define MAXN 500000
#define MOD 1000000009
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
struct Seg{int l,r,c; Seg(){} Seg(int _l, int _r, int _c){l=_l,r=_r,c=_c;}}d[MAXN+5];
inline bool operator < (Seg a, Seg b){return a.r-b.r?a.r<b.r:a.l<b.l;}
inline bool cmplen(Seg a, Seg b){return a.r-a.l+1<b.r-b.l+1;}
int n, m, k, x[MAXN+5], o[(MAXN<<1)+5], f[MAXN+5], s[MAXN+5], num[MAXN+5], coe[MAXN+5], b[MAXN+5], Ans, Cur, E;
inline int Coe(int l, int r){return (MOD+b[r]-b[l])%MOD;}
void Trans(int i, int l, int r)
{
	for(; Cur < i; s[Cur] = s[Cur-1]+f[Cur], s[Cur]<MOD?:s[Cur]-=MOD, ++Cur); sort(d+l,d+r+1,cmplen);
	coe[l-1] = 0; for(rint j = l; j <= r; coe[j] = coe[j-1]+d[j].c, j++);
	for(rint j = r, p, tmp; j >= l; /*f[i] = (f[i]+1ll*Coe(coe[j-1],coe[j])*f[p]%MOD*b[num[i-1]-num[p]])%MOD, */j--)
		for(tmp = 0, k = i-(d[j].r-d[j].l+1); k < i; k++)
			;
}
int main()
{
	freopen("xmasinterval.in","r",stdin), freopen("xmasinterval.out","w",stdout);
	n = read(), m = read(); for(rint i = 1; i <= n; d[i].l = read(), d[i].r = read(), i++);
	for(rint i = 1; i <= m; o[++k] = (x[i]=read()), i++); sort(o+1,o+k+1), k = unique(o+1,o+k+1)-o-1;
	for(rint i = 1; i <= n; d[i].l = lower_bound(o+1,o+k+1,d[i].l)-o, d[i].r = upper_bound(o+1,o+k+1,d[i].r)-o-1, i++);
	sort(d+1,d+n+1), k = 0; for(rint i = 1; i <= n; d[i].l^d[i-1].l||d[i].r^d[i-1].r?d[++k]=d[i],d[k].c=1:++d[k].c, i++); n = k;
	b[0] = 1; for(rint i = 1; i <= m; b[i] = b[i-1]<<1, b[i]<MOD?:b[i]-=MOD, i++);
	//f[0] = s[0] = Cur = 1;
	//for(rint i = 1; i <= n; ++num[d[i].r], i++); for(rint i = 1; i <= m; num[i] += num[i-1], i++);
	//for(rint l = 1, r; l <= n; Trans(d[r].r,l,r), l = r+1)
	//	for(r = l; r<n && d[r+1].r==d[r].r; r++); printf("%d\n",f[m]);
	if(n <= 20)
	{
		E = ~-(1<<n);
		for(rint S = 0, i, r, c; S <= E; r > m ? Ans += c, Ans<MOD?:Ans-=MOD : 0, S++)
			for(i = r = c = 1; i <= n; (S>>~-i)&1 && (c = c*(b[d[i].c]+MOD-1ll)%MOD, r >= d[i].l) ? r = max(r,d[i].r+1) : 0, i++);
		printf("%d\n",Ans);
	}	return 0;
}
/*
6 5
1 8
1 3
4 4
5 6
6 7
8 8
1 3 4 6 8

*/
