#include<cstdio>
#define maxm(a,b) a>b?a:b
using namespace std;
int t,m,n;
int main(){
	scanf("%d%d%d",&t,&m,&n);
	while(n--){
		if(t==1){
			int x,y;
			int info=0;
			int cur=0;
			scanf("%d%d",&x,&y);
			while(1){
				int tx=x%2;
				int ty=y%2;
				x/=2;
				y/=2;
				if(tx!=ty){
					info=cur;
					info=info*2+tx;
					printf("%d\n",info);
					break;
				}
				cur++;
			}
		}
		else{
			int q,info;
			scanf("%d%d",&q,&info);
			int num=info%2;
			int loc=info/2;
			int cur=0;
			while(1){
				if(cur==loc){
					if(q%2==num) printf("yes\n");
					else printf("no\n");
					break;
				}
				q/=2;
				cur++;
			}
		}
	}
	return 0;
}
