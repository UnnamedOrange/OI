//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
#include<ctime>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const lovelive mod=1004535809;
void read(lovelive &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
int a[25];
int main()
{
  srand(time(0));
  freopen("sequence.in","w",stdout);
  int n=10,x,y;
  for(int i=1;i<=n;i++)
    a[i]=i;
  for(int i=1;i<=n*2;i++)
  {
  	x=(rand()-1)%n+1;
  	y=(rand()-1)%n+1;
  	swap(a[x],a[y]);
  }
  printf("%d\n",n);
  for(int i=1;i<=n;i++)
    printf("%d ",a[i]);
  return 0;
}
