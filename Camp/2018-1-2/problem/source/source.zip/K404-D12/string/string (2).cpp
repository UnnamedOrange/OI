#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define MAXN 100000
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int T, n; char s[MAXN+5]; int cnt[26]; bool flag, cur;
int main()
{
	freopen("string.in","r",stdin), freopen("string.out","w",stdout);
	for(T = read(); T--; )
	{
		n = read(), scanf("%s",s+1), memset(cnt,0,sizeof cnt), flag = true;
		for(rint i = (n>>1); flag && i; flag &= s[i]==s[n-i+1], i--); if(!flag){puts("1"); continue;}
		for(rint i = 1; i <= n; ++cnt[s[i]-'a'], i++); cur = true; for(rint i = 3; i <= n; cur &= s[i]==s[i-2], i += 2); for(rint i = 4; i <= n; cur &= s[i]==s[i-2], i += 2);
		flag = !cur; for(rint i = 0; flag && i < 26; flag &= (cnt[i]<n-1), i++); puts(flag?"2":"-1");
	}	return 0;
}
