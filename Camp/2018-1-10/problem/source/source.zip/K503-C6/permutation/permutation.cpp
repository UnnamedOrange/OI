#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#define MAXN 1000000
using namespace std;
typedef long long ll;
const ll mod = 998244353;
int ans = 0; int n;
int p[100005]; int vis[100005];
int v[11];
int dfs2(int x, int cur){
	if(v[x]) return cur;
	v[x] = 1;
	return dfs2(p[x], cur + 1);
}
int judge(){
	memset(v, 0, sizeof(v));
	int flag = 1;
	for(int i = 1; i <= n; i ++){
		if(!v[i]){
			flag &= (dfs2(i, 0) % 2 == 0);
		}
	}
	return flag;
}

void dfs(int cur){
	if(cur > n){
		ans += judge();
		return;
	}
	if(p[cur] != 0) dfs(cur + 1);
	else{
		for(int i = 1; i <= n; i ++){
			if(!vis[i]){
				vis[i] = 1;
				p[cur] = i;
				dfs(cur + 1);
				vis[i] = 0;
				p[cur] = 0;
			} 
		}
	}
}
int vi2[100005], vi3[100005];
int judge2(int x, int cur){
	if(vi2[x] && cur % 2 == 0) return 1;
	if(vi2[x] && cur % 2 == 1) return 0;
	if(x == 0) return 1;
	vi2[x] = 1;
	return judge2(p[x], cur + 1);
}

int main(){
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i ++){
		scanf("%d", &p[i]);
		vis[p[i]] = 1;
	}
	if(n <= 8){
		dfs(1);
		printf("%d\n", ans);
	}else{
		if(n % 2 == 1){
			printf("0\n");
			return 0;
		}
		ll Ans = 1;
		int flag = 1;
		for(int i = 1; i <= n; i ++){
			if(!vi2[i] && !vis[i] && p[i]){
				if(judge2(i, 0) == 0) flag = 0;
			}
		}
		for(int i = 1; i <= n; i ++){
			if(!vi2[i] && p[i]){
				if(judge2(i, 0) == 0) flag = 0;
			}
		}
		if(flag == 0){
			printf("0\n");
			return 0;	
		}
		int cnt = 0;
		for(int i = 1; i <= n; i ++){
			if(p[i]) cnt ++;
		}
		n -= cnt;
		for(int i = 1; i <= n; i ++){
			Ans = Ans * (((i - 1) / 2) * 2 + 1) % mod;
		}
		printf("%lld\n", Ans);
	}
	return 0;
}
