#include<bits/stdc++.h>
#define ll long long
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}
const int N=24000005;
int T,n,pn;
int mu[N],pri[N],s[N];
ll d[N];
bool prime[N];

void sieve()
{
	memset(mu,-1,sizeof(mu));
	memset(prime,true,sizeof(prime));
	mu[1]=d[1]=1;prime[1]=false;
	for(int i=2;i<N;i++)
	{
		if(prime[i])pri[++pn]=i,d[i]=2,s[i]=1;
		for(int j=1;j<=pn;j++)
		{
			int k=pri[j]*i;
			if(k>=N)break;
			prime[k]=false;
			if(i%pri[j]==0)
			{
				mu[k]=0;
				d[k]=d[i]/(s[i]+1)*(s[i]+2);
				s[k]=s[i]+1;
				break;
			}
			else mu[k]=-mu[i],d[k]=d[i]<<1,s[k]=1;
		}
	}
	for(int i=1;i<N;i++)mu[i]+=mu[i-1],d[i]=d[i-1]+d[i]*d[i];
}

ll calc(int n)
{
	ll res=0;
	for(int i=1,j;i<=n;i=j+1)
	{
		j=n/(n/i);
		res+=(mu[j]-mu[i-1])*d[n/i];
	}
	return res;
}

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	sieve();
	T=getint();
	while(T--)
	{
		n=getint();
		printf("%lld\n",calc(n));
	}
	return 0;
}
