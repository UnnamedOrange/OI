#include<cstdio>
#include<queue>
#include<algorithm>
#include<cstring>
#include<vector>
#define rep(i, s, t) for(i = s; i <= t; ++i)
#define isd(a) ((a) >= '0' && (a) <= '9')

using namespace std;

int re() {
	int x = 0; char c = getchar();
	for(; !isd(c); c = getchar());
	for(; isd(c); c = getchar())
		x = (x<<3) + (x<<1) + c - '0';
	return x;
}

const int N = 1000010, SN = 13;
int n, m;
vector<int> e[N];
bool vis[N];
int in[N];

int msk;
bool mp[SN][SN];
int s_f[1<<SN], s_num[1<<SN];

queue<int> q;
int lv[N];

void s_dfs(int f, int u) {
	vis[u] = 1; mp[f][u] = 1;
	for(int i = 0; i < e[u].size(); ++i)
	if(!vis[e[u][i]]) s_dfs(f, e[u][i]);
}

bool s_check(int x) {
	int i, j;
	rep(i, 1, n)
	if(x & (1<<i-1)) 
		rep(j, i+1, n)
		if((x & (1<<j-1)) && (mp[i][j] || mp[j][i])) return 0;
	return 1;
}

void s_solve() {
	int i, j, k;
	rep(i, 1, n) {
		rep(j, 1, n) vis[j] = 0;
		s_dfs(i, i); mp[i][i] = 0;
	}
	/*rep(i, 1, n) {
		rep(j, 1, n) printf("%d ", mp[i][j]);
		puts("");
	}*/
	
	msk = (1 << n) - 1;
	rep(i, 0, msk) s_num[i] = s_num[i>>1] + (i&1);
	//rep(i, 1, msk) printf("%d %d\n", i, s_num[i]);
	
	memset(s_f, 0x3f, sizeof(s_f)); s_f[0] = 0;
	rep(i, 1, n) {
		rep(j, 1, msk)
		if(s_num[j] == i) {
			for(k = j; k; k = (k-1)&j)
			if(s_check(k)) s_f[j] = min(s_f[j], s_f[j-k] + 1);
		}
	}
	printf("%d\n", s_f[msk]);
}

void dag_solve() {
	int i, u, ans = 0;
	rep(i, 1, n)
	if(!in[i]) {q.push(i); lv[i] = 1;}
	for(; !q.empty(); q.pop()) {
		u = q.front();
		for(i = 0; i < e[u].size(); ++i) {
			lv[e[u][i]] = max(lv[e[u][i]], lv[u] + 1);
			if(!--in[e[u][i]]) q.push(e[u][i]);
		}
	}
	rep(i, 1, n) ans = max(ans, lv[i]);
	printf("%d\n", ans);
}

int main() {
	freopen("bomb.in", "r", stdin); freopen("bomb.out", "w", stdout);
	int i, x, y;
	n = re(); m = re();
	rep(i, 1, m) {
		x = re(); y = re();
		e[x].push_back(y); ++in[y];
	}
	if(n <= 10) s_solve(); else
		dag_solve();
	return 0;
}
