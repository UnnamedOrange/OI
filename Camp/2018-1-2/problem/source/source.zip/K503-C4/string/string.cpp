#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 110
#define INF 0x7fffffff
using namespace std;
int ans;
struct node{
	string s;
	int len;
};
void solve(node now,int step){//�Ѿ�������step�� 
	if(step>=ans)return;
	for(int l=0;l<now.len;l++){
		for(int r=l+1;r<now.len;r++){
			int ll=l,rr=r;bool flag=0;
			while(ll<=rr){
				if(now.s[ll]!=now.s[rr]){flag=1;break;}
				else ll++,rr--;
			}
			if(flag==0)continue;
			node nxt;nxt.s="";nxt.len=0;
			for(int i=0;i<l;i++)nxt.s+=now.s[i],nxt.len++;
			for(int i=r+1;i<now.len;i++)nxt.s+=now.s[i],nxt.len++;
			if(nxt.len==0){
				ans=min(ans,step+1);
				return;
			}
			solve(nxt,step+1);
		}
	}
}
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("string.in","r",stdin);freopen("string.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		ans=INF;
		node str;
		scanf("%d",&str.len);cin>>str.s;
		solve(str,0);
		if(ans<INF)printf("%d\n",ans);
		else puts("-1");
	}
	return 0;
}
