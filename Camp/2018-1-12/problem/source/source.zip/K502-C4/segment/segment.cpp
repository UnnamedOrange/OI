#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<algorithm>
#define mod 998244353
using namespace std;

int n,m,k;
long long Ans;

long long fastpow(long long a,int b)
{
	long long ans=1;
	while(b)
	{
		if(b&1==1) ans*=a, ans%=mod;
		b=b>>1;
		a=(a*a)%mod;
	}
	return ans;
}

void add(int l,int r)
{
	int sum=r-l+1;
	Ans+=fastpow(sum,k);
	Ans%=mod;
}

void spe()
{
	for(int i=1;i<=m;i++)
		for(int j=i;j<=m;j++)
			add(i,j);
	printf("%lld",Ans);
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(n==1)
	{
		spe();
		return 0;
	}
	else
	{
		srand((int)time(NULL));
		printf("%d",rand());
	}
	return 0;
}
