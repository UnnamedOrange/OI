#include<bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
vector<int> q[1000005], nq[1000005];
int n, c[1000005], d[1000005];
int mac, mid;
const int inf = 0x3f3f3f3f;
int dis[1000005];
int f[1000005];
int stmc[22][1000005], stmd[22][1000005];
int Log[1000005];
inline void ST() {
	for(int i = 1; i <= n; ++i) {
		stmc[0][i] = c[i], stmd[0][i] = d[i];
	}
	for(int j = 1; j <= 20; ++j) {
		for(int i = 1; i + (1 << j) - 1  <= n; ++i) {
			stmc[j][i] = max(stmc[j - 1][i], stmc[j - 1][i + (1 << j - 1)]);
			stmd[j][i] = min(stmd[j - 1][i], stmd[j - 1][i + (1 << j - 1)]);
		}
	}
	Log[0] = -1;
	for(int i =1; i <= n; ++i) {
		Log[i] = Log[i >> 1] + 1;
	}
}
inline int getmax(int l, int r) {
	if(l != r)  {
		return max(stmc[Log[r - l]][l], stmc[Log[r - l]][r - (1 << Log[r - l]) + 1]);
	} else return c[l];
}

inline int getmin(int l, int r) {
	if(l != r)  {
		return min(stmd[Log[r - l]][l], stmd[Log[r - l]][r - (1 << Log[r - l]) + 1]);
	} else return d[l];
}
const int mod = 1000000007;
int main() {
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
	R(n);
	for(int i = 1; i <= n; ++i) {
		R(c[i]), R(d[i]);
	}
	ST();
	for(int i = 0; i <= n; ++i) {
		mac = 0, mid = inf;
		int j = i + 1;
		mac = c[j], mid = d[j];
		while(j <= n) {
			if(j - i >= mac && j - i <= mid) {
				q[i].push_back(j);
				++j;
				if(j <= n)
					mac = max(mac, c[j]), mid = min(mid, d[j]);
			} else {
				if(mid < j - i) {
					break;
				}
				j = i + mac;
				if(j <= n)
					mac = max(mac, getmax(i + 1, j)), mid = min(mid, getmin(i + 1, j));
			}
		}
	}
	int v;
	memset(dis, 0xc1, sizeof(dis));
	dis[n] = 0;
	for(int i = n - 1; i >= 0; --i) {
		for(int j = 0 ; j < q[i].size(); ++j) {
			v = q[i][j];
		//	printf("%d%d%d\n", i, j, q[i][j]);
			if(dis[v] + 1 > dis[i]) {
				nq[i].clear();
				nq[i].push_back(v);
				dis[i] = dis[v] + 1;
			} else {
				if(dis[v] + 1 == dis[i]) {
					nq[i].push_back(v);
				}
			}
		}
	}
	f[n] = 1;
	for(int i = n - 1; i >= 0; --i) {
		for(int j = 0; j < nq[i].size(); ++j) {
			v = nq[i][j];
			f[i] = (f[i] + f[v]) % mod;
		}
	}
	if(f[0] == 0) {
		puts("-1");
		return 0;
	}
	printf("%d %d\n", dis[0], f[0]);
}
