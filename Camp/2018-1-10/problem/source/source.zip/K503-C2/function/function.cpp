#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define maxn 1000000
int prime[maxn+10],a[maxn+10]={0},t,i,j,x,s,k=0;
long long ans[maxn+10];
bool mark[maxn+10];
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	memset(mark,true,sizeof(mark));
	for (i=2;i<=maxn;i++)
	{
		if (mark[i])
		{
			prime[k++]=i;
			a[i]=i;
		}
		for (j=0;(j<k) && (i*prime[j]<=maxn);j++)
		{
			mark[i*prime[j]]=false;
			if (!(i%prime[j]))
			{
				a[i]=prime[j];
				break;
			}
		}
		for (;!a[i];j++)
			if (!(i%prime[j]))
			{
				a[i]=prime[j];
				break;
			}
	}
	for (i=1;i<=maxn;i++)
	{
		ans[i]=1;
		s=1;
		x=1;
		for (j=i;j>1;j/=a[j])
			if (a[j]==x) s+=2;
				else
				{
					ans[i]=ans[i]*(long long)s;
					x=a[j];
					s=3;
				}
		ans[i]=ans[i]*(long long)s+ans[i-1];
	}
	for (scanf("%d",&t);t>0;t--)
	{
		scanf("%d",&x);
		printf("%lld\n",ans[x]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
