#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int N=100010,maxn=100000;
const int mod=998244353;
int p[N],cnt[N],inv[N],cj[N],f[N],c[2],vis[N];
int n;int flag;int ans;

void dfs(int i,int sum){
	vis[i]=1;
	if(!p[i]){c[sum]++;return;}
	if(vis[p[i]]){if(sum==1) flag=0;return;}
	dfs(p[i],sum^1);
}

int power(int x,int y){
	int ret=1;
	for(;y;y>>=1,x=1ll*x*x%mod){
		if(y&1)	ret=1ll*ret*x%mod;
	}
	return ret;
}

int C(int i,int j){return 1ll*cj[i]*inv[j]%mod*inv[i-j]%mod;}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int i;
	cj[0]=1;rep(i,1,maxn)	cj[i]=1ll*cj[i-1]*i%mod;
	inv[maxn]=power(cj[maxn],mod-2);inv[0]=1;
	for(i=maxn-1;i;i--)	inv[i]=1ll*inv[i+1]*(i+1)%mod;
	scanf("%d",&n);
	rep(i,1,n)	scanf("%d",&p[i]);
	rep(i,1,n)	cnt[p[i]]++;
	rep(i,1,n)	if(cnt[i]>1){printf("0\n");return 0;}
	flag=1;
	rep(i,1,n)	if(!vis[i])	dfs(i,1);
	//cerr<<c[0]<<' '<<c[1]<<endl;
	if(!flag){printf("0\n");return 0;}
	if(c[1]&1){printf("0\n");return 0;}
	if(!c[1]){printf("%d\n",cj[c[0]]);return 0;}
	f[0]=1;
	rep(i,1,c[1]){
		if(i&1)	f[i]=f[i-1];
		else {f[i]=1ll*inv[i]*cj[i-1]%mod*f[i-1]%mod;f[i]=(f[i]+f[i-1])%mod;}
	}
	rep(i,0,c[0]){
		ans=(ans+1ll*C(c[0],i)*cj[i]%mod*C(c[1]+i-1,c[1]-1)%mod*cj[c[0]-i])%mod;
	}
	ans=1ll*ans*(f[c[1]]-f[c[1]-1])%mod*cj[c[1]]%mod;
	ans=(ans+mod)%mod;
	printf("%d\n",ans);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
