#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>

using namespace std;
typedef long long ll;
const ll mod = 1e9 + 7;

ll s, t, n, m;
ll f[105][10005];
ll C[1005][1005];
void pre(){
	C[0][0] = 1;
	for(int i = 1; i <= s; i ++){
		C[i][0] = 1;
		for(int j = 1; j <= i; j ++){
			C[i][j] = C[i - 1][j] + C[i - 1][j - 1];
			if(C[i][j] >= mod) C[i][j] -= mod;
		}
	}
}
int main(){
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	scanf("%lld%lld%lld%lld", &s, &t, &n, &m);
	f[0][0] = 1;
	for(int i = 1; i <= n; i ++){
		for(int j = i; j <= i * t; j ++){
			for(int k = 1; k <= t; k ++){
				f[i][j] = (f[i][j] + f[i - 1][j - k]);
				if(f[i][j] >= mod) f[i][j] -= mod;
				if(j - k == 0) break;
			}
		}
	}
	ll ans = 0;
	pre();
	for(int i = n; i <= n * t; i ++){
		ans = (ans + f[n][i] * C[s - i][m - n]) % mod;
	}
	printf("%lld\n", ans);
	return 0;
}
