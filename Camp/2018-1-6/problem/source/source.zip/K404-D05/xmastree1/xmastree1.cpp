#include<bits/stdc++.h>
#define FE "xmastree1"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		c=='-'?p=-1:0;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
inline void putint(int x){
	x<0?putchar('-'),x=-x:0;
	static int buf[20];
	int tot=0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
#define LEN 500005
int n,on_line,q;
set<int>c[LEN*2];
inline int pre(int x,int p){
	set<int>::iterator i=c[p].lower_bound(x);
	if(i==c[p].begin())return 0;
	else return *(--i);
}
inline int suc(int x,int p){
	set<int>::iterator i=c[p].upper_bound(x);
	if(i==c[p].end())return n+1;
	else return *i;
}
struct tree{
	int c,fa[20],size,son,dep,top;
	int ld,rd;
	vector<int>edge;
}t[LEN];
int dfst=0;
int dfsorder[LEN];
inline void dfs1(int cur){
	dfsorder[t[cur].ld=++dfst]=cur;
	t[cur].dep=t[t[cur].fa[0]].dep+1;
	for(int i=0;i<t[cur].edge.size();++i){
		int v=t[cur].edge[i];
		if(v==t[cur].fa[0])continue;
		t[v].fa[0]=cur;
		dfs1(v);
		t[cur].size+=t[v].size;
		if(t[v].size>t[t[cur].son].size)t[cur].son=v;
	}
	t[cur].rd=dfst;
}
inline void dfs2(int cur){
	if(!t[cur].son)return;
	t[t[cur].son].top=t[cur].top;
	dfs2(t[cur].son);
	for(int i=0;i<t[cur].edge.size();++i){
		int v=t[cur].edge[i];
		if(v==t[cur].fa[0]||v==t[cur].son)continue;
		t[v].top=v;
		dfs2(v);
	}
}
int visit[LEN];
int main(){
//	freopen(FE".in","r",stdin);
//	freopen(FE".out","w",stdout);
	n=getint(),q=getint(),on_line=getint();
	for(int i=1;i<=n;++i){
		t[i].c=getint();
	}
	for(int i=1;i<n;++i){
		int a=getint(),b=getint();
		t[a].edge.push_back(b);
		t[b].edge.push_back(a);
	}
	dfs1(1);
	t[1].top=1;
	dfs2(1);
	int lastans=0;
	for(int i=1;i<=q;++i){
		int type,u,l,r,c,ans=0;
		type=getint(),u=getint();
		u^=lastans*on_line;
		if(type==1){
			l=getint()^(lastans*on_line),r=getint()^(lastans*on_line);
			for(int j=t[u].ld;j<=t[u].rd;++j){
				int v=dfsorder[j];
				if(t[v].c<=r&&t[v].c>=l&&visit[t[v].c]!=i){
					visit[t[v].c]=i;
					++ans;
				}
			}
			cout<<(lastans=ans)<<"\n";
		}
		else{
			c=getint()^(lastans*on_line);
			t[u].c=c;
		}
	}
	return 0;
}
