while true; do
echo ">>> gen"
python3 gen.py
echo ">>> bf"
./bf
echo ">>> xmasdag"
./xmasdag
if diff ./bf.out ./xmasdag.out;
then continue;
else break;
fi
done
