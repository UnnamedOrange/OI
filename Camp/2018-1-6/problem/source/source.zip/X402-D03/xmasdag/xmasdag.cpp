#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;
const int MAXN = 100010, MAXM = 200010;
const int MAXK = 510;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

namespace guo {
	int n, d = 0;
	int r[1030];
	ll w[1030][2], invn;
	inline void NTT_init(int m) {
		int i;
		for(n = 1; n <= 2*m; n <<= 1) d++;
		for(i = 0; i < n; i++) r[i] = (r[i>>1]>>1)|((i&1)<<(d-1));
		ll G = qpow(3, (MOD-1)>>d);
		invn = qpow(n, MOD-2);
		w[0][0] = w[n][0] = 1;
		for(i = 1; i < n; i++) w[i][0] = w[i-1][0]*G%MOD;
		for(i = 0; i <= n; i++) w[i][1] = w[n-i][0];
	}
	inline void NTT(ll a[], int t) {
		register int i, j, k, L, R;
		register ll val;
		for(i = 0; i < n; i++) if(i < r[i]) swap(a[i], a[r[i]]);
		for(i = 2; i <= n; i<<=1) 
			for(j = 0; j < n; j += i) 
				for(k = 0; k < (i>>1); k++) {
					L = j+k, R = L+(i>>1);
					val = a[R]*w[(n/i)*k][t]%MOD;
					a[R] = (a[L]-val+MOD)%MOD;
					update(a[L], val);
				}
	}
	inline void mul(ll a[], ll b[]) {
		int i;
		NTT(a, 0);
		for(i = 0; i < n; i++) a[i] = a[i]*b[i]%MOD;
		NTT(a, 1);
		for(i = 0; i < n; i++) a[i] = a[i]*invn%MOD;
	}
}

int st[MAXN], to[MAXM];
int nxt[MAXM], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

int n, m, K, q[MAXN]; 
int indeg[MAXN];
ll g[MAXN][MAXK], fac[MAXK], ifac[MAXK];
ll a[1030], b[1030];

inline void Topo() {
	int i, l = 0, r = 0;
	for(i = 1; i <= n; i++) 
		if(!indeg[i]) q[++r] = i;
	while(l < r) {
		int u = q[++l];
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			indeg[v]--;
			if(!indeg[v]) q[++r] = v;
		}
	}
}

int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);

	int i, j, l;

	n = read(), m = read(), K = read();
	guo::NTT_init(K);
	fac[0] = 1;
	for(i = 1; i <= K; i++) fac[i] = fac[i-1]*i%MOD;
	ifac[K] = qpow(fac[K], MOD-2);
	for(i = K; i >= 1; i--) ifac[i-1] = ifac[i]*i%MOD;
	for(i = 0; i <= K; i++) a[i] = ifac[i];
	/*for(i = 0; i <= K; i++) printf("%lld ", a[i]);
	printf("\n");*/
	guo::NTT(a, 0);
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		Add(u, v), indeg[v]++;
	}
	Topo();
	//cerr << clock() << endl;
	g[1][0] = 1;

	for(l = 1; l <= n; l++) {
		int u = q[l];
		for(i = 0; i <= K; i++) b[i] = g[u][i];
		for(i = K+1; i < 1024; i++) b[i] = 0;
		guo::mul(b, a);
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			for(j = 0; j <= K; j++) update(g[v][j], b[j]);
		}
	}
	for(i = 1; i <= n; i++) printf("%lld\n", g[i][K]*fac[K]%MOD);
	//cerr << clock() << endl;
	return 0;
}
