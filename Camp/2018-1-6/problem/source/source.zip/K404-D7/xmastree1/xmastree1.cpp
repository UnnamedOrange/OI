#include <bits/stdc++.h>
using namespace std;
inline char read() {
	static const int IN_LEN = 1 << 18 | 1;
	static char buf[IN_LEN], *s, *t;
	return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
	       s == t ? -1 : *s++;
}

template <typename T>
inline void read(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return;
		iosig |= c == '-';
	}
	for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
	iosig && (x = -x);
}

inline int read(char *buf) {
	register int s = 0;
	register char c;
	while (c = read(), isspace(c) && c != -1)
		;
	if (c == -1) {
		*buf = 0;
		return -1;
	}
	do
		buf[s++] = c;
	while (c = read(), !isspace(c) && c != -1);
	buf[s] = 0;
	return s;
}

inline void read(char &c) {
	while (c = read(), isspace(c) && c != -1)
		;
}

inline void read(double &t) {
	static char c;
	static bool iosig;
	register int x = 0;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return;
		c == '-' ? iosig = true : 0;
	}
	for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
	if (c == '.') {
		register long long y = 0, cnt = 1;
		for (c = read(); isdigit(c); c = read())
			y = y * 10 + (c ^ '0'), cnt *= 10;
		t = x + (double)y / cnt;
	} else {
		t = x;
	}
	iosig ? t = -t : 0;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
	(oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
	*oh++ = c;
}

template <typename T>
inline void print(T x) {
	static int buf[21], cnt;
	if (x != 0) {
		(x < 0) && (print('-'), x = -x);
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
		while (cnt) print((char)buf[cnt--]);
	} else {
		print('0');
	}
}

inline void print(const char *s) {
	for (; *s; s++) print(*s);
}

const double EPS = 1e-9;

inline int sign(const double x) {
	return (x > EPS) - (x < -EPS);
}

inline void print(double x) {
	register int sig = sign(x);
	if (sig == 0) {
		print('0');
		return;
	}
	(sig == -1) && (print('-'), x = -x);
	print((int)x);
	x = x - (int)x;
	print('.');
	static char buf[21], cnt;
	x *= 1000000000;
	register int t = round(x);
	for (cnt = 0; t; t /= 10) buf[++cnt] = t % 10 | 48;
	for (register int i = 9; i > cnt; i--) print('0');
	while (cnt) print((char)buf[cnt--]);
}

struct InputOutputStream {
	~InputOutputStream() {
		fwrite(obuf, 1, oh - obuf, stdout);
	}

	template <typename T>
	inline InputOutputStream &operator>>(T &x) {
		read(x);
		return *this;
	}

	template <typename T>
	inline InputOutputStream &operator<<(const T &x) {
		print(x);
		return *this;
	}
} io;
int n, Q, T;
int col[100005];
vector<int>q[100005];
struct xunwen {
	int kind, u, l, r, c;
} qe[100005];
int in[100005], out[100005], xulie[100005], indx;
int cnt;
inline void dfs(int x, int fa) {
//	io<<++cnt<< '\n';
	int v;
	in[x] = ++indx;
	xulie[indx] = x;
	for(int i = 0; i < q[x].size(); ++i) {
		v = q[x][i];
		if(v != fa) {
			dfs(v, x);
		}
	}
	out[x] = indx;
}
bool vis[50005];
/*struct tree {
	int ls, rs, sum;
}tr[3000005];
int zong;
int pre[100005];*/
int main() {
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	io>>n>>Q>>T;
	for(int i = 1; i <= n; ++i) io>>col[i];
	int x, y;
	for(int i = 1; i < n; ++i) {
		io>>x>>y;
		q[x].push_back(y);
		q[y].push_back(x);
	}
	bool wxg = 1;
	for(int i = 1; i <= Q; ++i) {
		io>>qe[i].kind;
		switch(qe[i].kind) {
			case 1:
				io>>qe[i].u>>qe[i].l>>qe[i].r;
				break;
			case 2:
				wxg = 0;
				io>>qe[i].u>>qe[i].c;
				break;
		}
	}
	// n * q ����
	dfs(1, 1);
	if(n <= 50000) {
		int ans = 0;
		int *ma, l, r, *up;
		int *now;
		for(int i = 1; i <= Q; ++i) {
			if(T == 1) {
				qe[i].l ^= ans, qe[i].r ^= ans, qe[i].u ^= ans, qe[i].c ^=ans;
			}
			switch(qe[i].kind) {
				case 1:
					ans = 0;
					ma = &xulie[out[qe[i].u]];
					up = ma - 15;
					now = &xulie[in[qe[i].u]];
					l = qe[i].l, r = qe[i].r;
					for(; now <= up; now += 16) {
						ans += ((!vis[col[*now]]) && col[*now] >= l && col[*now] <= r);
						vis[col[*now]] = 1;
						ans += ((!vis[col[*(now + 1)]]) && col[*(now + 1)] >= l && col[*(now + 1)] <= r);
						vis[col[*(now + 1)]] = 1;
						ans += ((!vis[col[*(now + 2)]]) && col[*(now + 2)] >= l && col[*(now + 2)] <= r);
						vis[col[*(now + 2)]] = 1;
						ans += ((!vis[col[*(now + 3)]]) && col[*(now + 3)] >= l && col[*(now + 3)] <= r);
						vis[col[*(now + 3)]] = 1;
						ans += ((!vis[col[*(now + 4)]]) && col[*(now + 4)] >= l && col[*(now + 4)] <= r);
						vis[col[*(now + 4)]] = 1;
						ans += ((!vis[col[*(now + 5)]]) && col[*(now + 5)] >= l && col[*(now + 5)] <= r);
						vis[col[*(now + 5)]] = 1;
						ans += ((!vis[col[*(now + 6)]]) && col[*(now + 6)] >= l && col[*(now + 6)] <= r);
						vis[col[*(now + 6)]] = 1;
						ans += ((!vis[col[*(now + 7)]]) && col[*(now + 7)] >= l && col[*(now + 7)] <= r);
						vis[col[*(now + 7)]] = 1;
						ans += ((!vis[col[*(now + 8)]]) && col[*(now + 8)] >= l && col[*(now + 8)] <= r);
						vis[col[*(now + 8)]] = 1;
						ans += ((!vis[col[*(now + 9)]]) && col[*(now + 9)] >= l && col[*(now + 9)] <= r);
						vis[col[*(now + 9)]] = 1;
						ans += ((!vis[col[*(now + 10)]]) && col[*(now + 10)] >= l && col[*(now + 10)] <= r);
						vis[col[*(now + 10)]] = 1;
						ans += ((!vis[col[*(now + 11)]]) && col[*(now + 11)] >= l && col[*(now + 11)] <= r);
						vis[col[*(now + 11)]] = 1;
						ans += ((!vis[col[*(now + 12)]]) && col[*(now + 12)] >= l && col[*(now + 12)] <= r);
						vis[col[*(now + 12)]] = 1;
						ans += ((!vis[col[*(now + 13)]]) && col[*(now + 13)] >= l && col[*(now + 13)] <= r);
						vis[col[*(now + 13)]] = 1;
						ans += ((!vis[col[*(now + 14)]]) && col[*(now + 14)] >= l && col[*(now + 14)] <= r);
						vis[col[*(now + 14)]] = 1;
						ans += ((!vis[col[*(now + 15)]]) && col[*(now + 15)] >= l && col[*(now + 15)] <= r);
						vis[col[*(now + 15)]] = 1;
						
					}
					for(;now <= ma; ++now) {
						ans += ((!vis[col[*now]]) && col[*now] >= l && col[*now] <= r);
						vis[col[*now]] = 1;
					}
					io<<ans<<'\n';
					memset(vis, 0, sizeof(vis));
					break;
				case 2:
					col[qe[i].u] = qe[i].c;
					break;
			}
		}
		return 0;
	} else {
		if(wxg == 1) {
			
		}
	}
}
