#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 20
int d,las,a[N],t,n;
void turn(int x)
{
	fr(i,1,x/2)
	{
		int k=a[i];
		a[i]=a[x-i+1];
		a[x-i+1]=k;
	}
}
bool dfs(int x,int th)
{
	if(th==las)
		return 1;
	if(!x)
		return 0;
	fr(i,1,n)
	{
		a[n-i+1]=th%10;
		th/=10;
	}
	int o=0;
	fd(i,n,2)
	{
		turn(i);
		int k=0;
		fr(j,1,n)
			k=(k<<1)+(k<<3)+a[j];
		if(dfs(x-1,k))
		{
//			printf("%d\n",k);
			o=1;
			break;
		}
		turn(i);
	}
	return o;
}
int main()
{
	freopen("sequence.out","w",stdout);
	freopen("sequence.in","r",stdin);
	t=read();
	while(t--)
	{
		n=read();
		fr(i,1,n)
			las=(las<<1)+(las<<3)+i;
		fr(i,1,n)
			d=(d<<1)+(d<<3)+read();
		fr(ans,1,n+n)
			if(dfs(ans,d))
			{
				printf("%d\n",ans);
				break;
			}
	}
	return 0;
}
/*#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 50
int n,t,a[N],ans;
void turn(int x)
{
	fr(i,1,x/2)
	{
		int k=a[i];
		a[i]=a[x-i+1];
		a[x-i+1]=k;
	}
}
int main()
{
	freopen("sequence.out","w",stdout);
	freopen("sequence.in","r",stdin);
	t=read();
	while(t--)
	{
		n=read();
		fr(i,1,n)
			a[i]=read();
		int k=n;
		while(a[k]==k&&k)
			k--;
		ans=0;
		while(k)
		{
			ans++;
			int o=0;
			fr(i,1,k)
				if(a[i]==k)
					o=i;
//			printf("%d %d\n",k,o);
			if(o==1)
				turn(k);
			else
				turn(o);
			while(a[k]==k&&k)
				k--;
//			fr(i,1,k)
//				printf("%d%c",a[i],i==k?'\n':' ');
//			if(ans>10)
//				break;
		}
		printf("%d\n",ans);
	}
	return 0;
}*/