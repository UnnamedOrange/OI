#include<bits/stdc++.h>
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb1.out","w",stdout);
}
int n,m,ans;
int deg[N];
int dfn[N],low[N],dfs_cnt;
int w[N],bel[N],scc_cnt;
int st[N],top,in[N];
int bgn[N],nxt[N],to[N],e;
int Bgn[N],Nxt[N],To[N],E;
int q[N],len;
inline void add_edge(int u,int v){nxt[++e]=bgn[u],bgn[u]=e,to[e]=v;}
inline void Add_edge(int u,int v){Nxt[++E]=Bgn[u],Bgn[u]=E,To[E]=v;}
inline void dfs(int u)
{
	dfn[u]=low[u]=++dfs_cnt;
	in[st[++top]=u]=1;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if(!dfn[v=to[i]])
		{
			dfs(v);
			chkmin(low[u],low[v]);
		}
		else
		if(in[v])
			chkmin(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int x;++scc_cnt;
		do
		{
			x=st[top--];
			in[x]=0;
			bel[x]=scc_cnt;
			w[scc_cnt]++;
		}while(x!=u);
	}
}
int main()
{
	int x,y;
	file();
	read(n),read(m);
	For(i,1,m)
	{
		read(x),read(y);
		add_edge(x,y);
	}
	For(i,1,n)if(!dfn[i])dfs(i);
	For(u,1,n)
		for(int v,i=bgn[u];i;i=nxt[i])
			if(bel[v=to[i]]!=bel[u])
			{
				Add_edge(bel[u],bel[v]);
				deg[bel[v]]++;
			}
	For(i,1,scc_cnt)if(!deg[i])q[++len]=i;
	while(len>0)
	{
		For(x,1,len)
			if(!--w[q[x]])
			{
				int u=q[x];
				for(int v,i=Bgn[u];i;i=Nxt[i])
					if(!--deg[v=To[i]])
						q[++len]=v;
			}
		ans++;
		int cnt=0;
		For(i,1,len)if(w[q[i]])q[++cnt]=q[i];
		len=cnt;
	}
	printf("%d\n",ans);
	return 0;
}
