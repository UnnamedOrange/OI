#include <cstdio>
#include <vector>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

namespace OUTBUFFER {
	char buf[1048576];
	int pt;
	inline void putch(register char ch) { buf[pt++] = ch; }
	inline void flush() { if(pt) fwrite(buf,sizeof(char),pt,stdout), pt = 0; }
	inline void check() { if(pt > 1000000) flush(); }
}

template <class T>
inline void put_int(register T x) {
	char temp[23];
	register int top;
	if(x == 0) return OUTBUFFER::putch('0');
	if(x < 0) OUTBUFFER::putch('-'), x = -x;
	for(top = 0; x; temp[++top] = x % 10, x /= 10);
	do OUTBUFFER::putch(temp[top] ^ '0'); while(--top);
	OUTBUFFER::check();
}

struct OUT {
	OUT() { OUTBUFFER::pt = 0; }
	~OUT() { OUTBUFFER::flush(); }
	const OUT &operator << (const char *str) const {
		while(*str) OUTBUFFER::putch(*str++);
		OUTBUFFER::check();
		return *this;
	}
	const OUT &operator << (register char ch) const {
		return OUTBUFFER::putch(ch), *this;
	}
	const OUT &operator << (register int x) const {
		return put_int<int>(x), *this;
	}
	const OUT &operator << (register long long x) const {
		return put_int<long long>(x), *this;
	}
} out;

typedef long long ll;
const int NON = 100005, MOD = 998244353;
int N, M, K, Head[NON], Next[NON], To[NON], Dis[NON], In[NON], Count[NON], gIndex;
std::vector<int> vec[NON];

inline void addTo(int &a, const int b){
	((a += b) >= MOD) ? a -= MOD : 0;
}

inline void addEdge(int u, int v) {
	Next[++gIndex] = Head[u]; To[Head[u] = gIndex] = v;
}

inline int fastPow(int a, int x) {
	int ret = 1;
	while(x) {
		(x & 1) ? (ret = (ret * (ll)a) % MOD) : 0;
		a = a * (ll)a % MOD;
		x >>= 1;
	}
	return ret;
}

inline void init() {
	N = get_int(), M = get_int(), K = get_int();
	for(int i = 1, u, v; i <= M; ++i) {
		u = get_int(), v = get_int();
		addEdge(u, v);
		++In[v];
	}
	vec[1].push_back(0);
	Dis[1] = 0;
	Count[1] = 1;
}

std::vector<int> Que;
inline void solve() {
	Que.push_back(1);
	for(int i = 0; i < Que.size(); ++i) {
		int u = Que[i];
		for(int e = Head[u], v; e; e = Next[e]) {
			addTo(Dis[v = To[e]], Dis[u] + Count[u]);
			Count[v] += Count[u];
			if(K > 1) {
				for(int c = 0, s = vec[u].size(); c < s; ++c)
					vec[v].push_back(vec[u][c] + 1);
			}
			if(!--In[v]) Que.push_back(v);
		}
	}
	if(K == 1)
		for(int i = 1; i <= N; ++i)
			out <<Dis[i] <<'\n';
	else
		for(int i = 1; i <= N; ++i) {
			int ans = 0;
			for(int c = 0, s = vec[i].size(); c < s; ++c)
				addTo(ans, fastPow(vec[i][c], K));
			out <<ans <<'\n';
		}
}

#define PROBLEM_NAME	"xmasdag"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	init();
	solve();
	return 0;
}
