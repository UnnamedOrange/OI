#include<bits/stdc++.h>
using namespace std;

const int maxn=52222;
const int maxm=maxn*2;
int n, q, t;
int c[maxn];
vector<int> g[maxn];
bitset<maxn> s[maxn*2], f[22]; 

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int st[maxn], ed[maxn], dfn, fa[maxn], id[maxn];
void dfs(int x){
	st[x]=++dfn; id[dfn]=x;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa[x]) continue;
		fa[v]=x; dfs(v);
	}
	ed[x]=dfn;
}

void modify(int o,int l,int r,int pos,int col,int val){
	if(l==r){ s[o][col]=val; return; }
	int mid=(l+r)>>1;
	if(pos<=mid) modify(o<<1,l,mid,pos,col,val); else modify(o<<1|1,mid+1,r,pos,col,val);
	s[o]=s[o<<1]|s[o<<1|1];
}
bitset<maxn> query(int o,int l,int r,int ql,int qr){
	if(ql<=l && qr>=r) return s[o];
	int mid=(l+r)>>1; bitset<maxn> ret;
	if(ql<=mid) ret=query(o<<1,l,mid,ql,qr); if(qr>mid) ret|=query(o<<1|1,mid+1,r,ql,qr);
	return ret;
}

bitset<maxn> get(int x){
	bitset<maxn> ret=0;
	for (int i=20;i>=0;--i)
		if(x-(1<<i)>=0) ret=(ret<<(1<<i)) | f[i];
	return ret;
}

int lstans;
int main(){
	freopen("xmastree1.in","r",stdin),freopen("xmastree1.out","w",stdout);

	read(n), read(q), read(t);
	for(int i=1;i<=n;i++) read(c[i]);
	int u, v, l, r, x, op;
	for(int i=1;i<n;i++){
		read(u), read(v);
		g[u].push_back(v), g[v].push_back(u);
	}
	dfs(1);
	f[0] = 1; 
	for(int i=1;i<=20;i++) f[i]=(f[i-1]<<(1<<i-1))|f[i-1];
	for(int i=1;i<=n;i++) modify(1,1,n,i,c[id[i]],1);
	while(q--){
		read(op);
		if(op==1){
			read(u), read(l), read(r);
			if(t) u^=lstans, l^=lstans, r^=lstans;
			bitset<maxn> cnt=query(1,1,n,st[u],ed[u]), t=get(r)^get(l-1);
			printf("%d\n", lstans=((cnt & t).count()));
		}else{
			read(u), read(x);
			if(t) u^=lstans, x^=lstans;
			 modify(1,1,n,st[u],c[u],0);
			 modify(1,1,n,st[u],x,1); c[u]=x;
		}
	}
	return 0;
}
