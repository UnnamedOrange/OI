#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

const int M = (int)1e5 + 5;

int T, n;
char str[M];

namespace Subtask1 {
	
	const int M = 105;
	
	int dp[M][M];
	bool can[M][M];
	
	void Check(int &a, int b) {
		if (a == -1 || b < a) a = b;
	}
	
	int dfs(int L, int R) {
		if (L > R) return 0;
		if (dp[L][R] < n + 1) return dp[L][R];
		dp[L][R] = -1;
		for (int i = L; i < R; i++) {
			int l = dfs(L, i), r = dfs(i + 1, R);
			if (~l && ~r) Check(dp[L][R], l + r);
		}
		bool flag = true;
		for (int d = 1; d * 2 <= R - L + 1; d++) {
			flag &= (str[L + d - 1] == str[R - d + 1]);
			for (int i = L + d - 1; i <= R - d; i++) {
				if (flag && can[L + d][i]) continue;
				int tmp = dfs(i + 1, R - d);
				if (~tmp) Check(dp[L][R], tmp + 1);
			}
			for (int i = R - d + 1; i >= L + d; i--) {
				if (flag && can[i][R - d]) continue;
				int tmp = dfs(L + d , i - 1);
				if (~tmp) Check(dp[L][R], tmp + 1);
			}
		}
		return dp[L][R];
	}
	
	void solve() {
		for (int i = 1; i <= n; i++)
			for (int j = i; j <= n; j++)
				dp[i][j] = n + 1;
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= n; j++)
				can[i][j] = true;
		for (int i = 1; i <= n; i++) {
			for (int j = i; j <= n; j++) {
				int l = i, r = j;
				while (l < r) {
					if (str[l] != str[r]) {
						can[i][j] = false;
						break;
					}
					l++, r--;
				}
			}
		}
		printf("%d\n", dfs(1, n));
	}
	
}

namespace XJB {
	
	void solve() {
		int l = 1, r = n;
		bool allsame = true;
		while (l < r) {
			if (str[l] != str[r]) {
				puts("1");
				return;
			}
			allsame &= (str[l] == str[1]);
			l++, r--;
		}
		if (allsame) puts("-1");
		else puts("2");
	}
	
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		scanf("%s", str + 1);
		if (n <= 100) Subtask1::solve();
		else XJB::solve();
	}
	return 0;
}
