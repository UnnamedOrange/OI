#include <iostream>
#include <cstdio>
using namespace std;
const int MOD = 998244353;
int n, a[13];
bool used[13];
int ans;
bool vis[100010];
int X, Y;
int head[100010], to[100010], nxt[100010], cnt, in[100010];
inline void addedge (int u, int v) { cnt++, to[cnt] = v, nxt[cnt] = head[u], head[u] = cnt, in[v]++; }
inline void dfs (int step) {
	if (step > n) {
		for (int i = 1; i <= n; i++) {
			int t = 1;
			for (int j = a[i]; j != i; j = a[j]) t++;
			if (t & 1) return;
		}
		ans++;
		return;
	}
	if (a[step]) {
		if (used[a[step]]) return;
		used[a[step]] = true;
		dfs (step + 1);
		used[a[step]] = false;
	} else {
		for (int i = 1; i <= n; i++) if (!used[i]) {
			used[i] = true;
			a[step] = i;
			dfs (step + 1);
			a[step] = 0;
			used[i] = false;
		}
	}
}
int main () {
	freopen ("permutation.in", "r", stdin);
	freopen ("permutation.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++) scanf ("%d", &a[i]);
	if (n <= 8) {
		dfs (1);
		printf ("%d\n", ans);
	} else {
		for (int i = 1; i <= n; i++) { if (a[i]) addedge (i, a[i]); }
		for (int i = 1; i <= n; i++) {
			if (in[i] > 1) { printf ("0\n"); return 0; }
			if (in[i] == 0) {
				vis[i] = true;
				if (a[i] == 0) { X++; continue; }
				int t = 0, j;
				for (j = a[i], vis[j] = true; a[j] != 0; j = a[j], vis[j] = true) t++;
				if (t & 1) X++;
				else Y++;
			}
		}
		for (int i = 1; i <= n; i++) if (!vis[i]) {
			int t = 1, j;
			vis[i] = true;
			for (j = a[i], vis[j] = true; j != i; j = a[j], vis[j] = true) t++;
			if (t & 1) { printf ("0\n"); return 0; }
		}
		if (X & 1) { printf ("0\n"); return 0; }
		int ans = 1;
		for (int i = 1; i < X; i += 2) ans = 1ll * ans * i % MOD;
		ans = 1ll * ans * ans % MOD;
		for (int i = 1; i <= Y; i++) ans = 1ll * ans * (i + X) % MOD;
		printf ("%d\n", ans);
	}
	return 0;
}
