#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#include<stdlib.h>
int n;
int main()
{
	freopen("string.in","w",stdout);
	n=5;
	srand((unsigned long long)new char);
	printf("1\n%d\n",n);
	fr(i,1,n)
		//putchar((i&1)+'a');
		putchar(rand()%2+'a');
	return 0;
}