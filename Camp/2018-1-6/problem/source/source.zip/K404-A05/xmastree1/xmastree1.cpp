//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
//My i/o stream
struct fastio
{
	char s[100000];
	int it,len;
	fastio(){it=len=0;}
	inline char get()
	{
		if(it<len)return s[it++];it=0;
		len=fread(s,1,100000,stdin);
		if(len==0)return EOF;else return s[it++];
	}
	bool notend()
	{
		char c=get();
		while(c==' '||c=='\n')c=get();
		if(it>0)it--;
		return c!=EOF;
	}
}_buff;
#define geti(x) x=getnum()
#define getii(x,y) geti(x),geti(y)
#define getiii(x,y,z) getii(x,y),geti(z)
#define puti(x) putnum(x),putchar(' ')
#define putii(x,y) puti(x),puti(y)
#define putiii(x,y,z) putii(x,y),puti(z)
#define putsi(x) putnum(x),putchar('\n')
#define putsii(x,y) puti(x),putsi(y)
#define putsiii(x,y,z) putii(x,y),putsi(z)
inline ll getnum()
{
	ll r=0;bool ng=0;char c;c=_buff.get();
	while(c!='-'&&(c<'0'||c>'9'))c=_buff.get();
	if(c=='-')ng=1,c=_buff.get();
	while(c>='0'&&c<='9')r=r*10+c-'0',c=_buff.get();
	return ng?-r:r;
}
template<class T> inline void putnum(T x)
{
	if(x<0)putchar('-'),x=-x;
	register short a[20]={},sz=0;
	while(x)a[sz++]=x%10,x/=10;
	if(sz==0)putchar('0');
	for(int i=sz-1;i>=0;i--)putchar('0'+a[i]);
}
inline char getreal(){char c=_buff.get();while(c<=32)c=_buff.get();return c;}
int n,q,T;
vector<int> con[100111];
int dfn[100111],dfnr[100111],dn;
void dfs(int x,int pre=-1)
{
	dfn[x]=++dn;
	for(int i=0;i<con[x].size();i++)
	{
		int u=con[x][i];
		if(u!=pre)dfs(u,x);
	}
	dfnr[x]=dn;
}
const int bcnt=30;
int bsz;
struct block
{
	int has[100111>>5];
	int sum[101111>>8];
	block()
	{
		memset(has,0,sizeof(has));
		memset(sum,0,sizeof(sum));
	}
	void change(int x,bool v)
	{
		bool cur=(has[x>>5]>>(x&31))&1;
		if(cur!=v)
		{
			sum[x>>8]+=cur==1?-1:1;
			has[x>>5]^=1<<(x&31);
		}
	}
	int query(int x)
	{
		if(x<0)return 0;
		int Bid=x>>8;
		int ret=0;
		for(int i=0;i<Bid;i++)ret+=sum[i];
		for(int i=Bid<<8;i<=x;i++)ret+=(has[i>>5]>>(i&31))&1;
		return ret;
	}
	bool gethas(int x){return (has[x>>5]>>(x&31))&1;}
	void out(int n)
	{
		for(int i=1;i<=n;i++)cerr<<gethas(i);cerr<<endl;
	}
}B[bcnt+2][bcnt+2];
int ia[100111],a[100111];
int cnt[bcnt+2][100111];
int id[100111];
bool hs[100111];
int query(int xl,int xr,int vl,int vr)
{
//	cerr<<"query:"<<xl<<" "<<xr<<" "<<vl<<" "<<vr<<endl;
	int ret=0;
	if(id[xl]+1>=id[xr])
	{
		for(int i=xl;i<=xr;i++)
		{
			if(a[i]>=vl&&a[i]<=vr&&!hs[a[i]])
			{
				hs[a[i]]=1;
				ret++;
			}
		}
		for(int i=xl;i<=xr;i++)if(a[i]>=vl&&a[i]<=vr)hs[a[i]]=0;
	}
	else
	{
		block &curb=B[id[xl]+1][id[xr]-1];
//		curb.out(n);
		ret+=curb.query(vr);
		ret-=curb.query(vl-1);
//		cerr<<"ret="<<ret<<endl;
		for(int i=xl;id[i]==id[xl];i++)
		{
			if(a[i]>=vl&&a[i]<=vr&&!hs[a[i]]&&!curb.gethas(a[i]))
			{
				hs[a[i]]=1;
				ret++;
			}
		}
		for(int i=xr;id[i]==id[xr];i--)
		{
			if(a[i]>=vl&&a[i]<=vr&&!hs[a[i]]&&!curb.gethas(a[i]))
			{
				hs[a[i]]=1;
				ret++;
			}
		}
		for(int i=xl;id[i]==id[xl];i++)if(a[i]>=vl&&a[i]<=vr)hs[a[i]]=0;
		for(int i=xr;id[i]==id[xr];i--)if(a[i]>=vl&&a[i]<=vr)hs[a[i]]=0;
	}
	return ret;
}
void add(int x)
{
	int v=a[x];
	int cid=id[x];
//	cerr<<"add:"<<x<<" "<<v<<endl;
	if((cnt[cid][v]++)==0)
	{
		for(int i=cid;i>=0;i--)
		{
			for(int j=cid;j<=id[n];j++)
			{
				B[i][j].change(v,1);
			}
		}
	}
}
void del(int x)
{
	int v=a[x];
//	cerr<<"del:"<<x<<" "<<v<<endl;
	int cid=id[x];
	if((--cnt[cid][v])==0)
	{
		for(int i=cid;i>=0;i--)
		{
			for(int j=cid;j<=id[n];j++)
			{
				if(i==j)B[i][j].change(v,0);
				else
				{
					bool f=B[i][j-1].gethas(v)|B[j][j].gethas(v);
					if(f)break;
					B[i][j].change(v,f);
				}
			}
		}
	}
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	getiii(n,q,T);
	bsz=(n/bcnt)+1;
	for(int i=1;i<=n;i++)geti(ia[i]),id[i]=i/bsz;
	for(int i=1;i<n;i++)
	{
		int x,y;
		getii(x,y);
		con[x].PB(y);
		con[y].PB(x);
	}
	dfs(1);
	for(int i=1;i<=n;i++)a[dfn[i]]=ia[i];
	for(int i=1;i<=n;i++)add(i);
	int lastans=0;
	for(int i=1;i<=q;i++)
	{
		int op,u,l,r;
		getiii(op,u,l);
		if(T)u^=lastans,l^=lastans;
		if(op==1)
		{
			geti(r);
			if(T)r^=lastans;
			int ans=query(dfn[u],dfnr[u],l,r);
			printf("%d\n",ans);
			lastans=ans;
		}
		else
		{
			del(dfn[u]);
			a[dfn[u]]=l;
			add(dfn[u]);
		}
	}
	return 0;
}
