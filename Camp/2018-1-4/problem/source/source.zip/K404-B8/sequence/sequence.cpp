#include<bits/stdc++.h>
using namespace std;
const int maxn = 29;

int a[maxn],t[maxn];
int n,T,ans;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

inline bool check(int *x)
{
	for(int i=2;i<=n;i++) if(x[i]<x[i-1]) return false;
	return true;
}
inline int calc(int *x)
{
	int res=0;
	for(int i=2;i<=n;i++) if(abs(x[i]-x[i-1])>1) res++;
	return res;
}

void dfs(int now,int nxt)
{
	if(now+nxt>=ans) return ;
	if(check(t)){ans=min(ans,now);return ;}
	for(int i=2;i<=n;i++)
	{
		reverse(t+1,t+1+i);
		dfs(now+1,calc(t));
		reverse(t+1,t+1+i);
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	T=read();
	while(T--)
	{
		ans=0;n=read();
		for(int i=1;i<=n;i++) t[i]=a[i]=read();
		for(int mx=n;mx>=1;mx--)
		{
			if(check(t)) break;
			if(t[mx]==mx) continue;
			int pos=0;
			for(pos=1;t[pos]!=mx;pos++);
			if(pos==1) reverse(t+1,t+1+mx),ans++;
			else
			{
				reverse(t+1,t+1+pos);ans++;
				reverse(t+1,t+1+mx);ans++;
			}
		}
		memcpy(t,a,sizeof a);
		dfs(0,calc(t));
		printf("%d\n",ans);
	}
	return 0;
}
