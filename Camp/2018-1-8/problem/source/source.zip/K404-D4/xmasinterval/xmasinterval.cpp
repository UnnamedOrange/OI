#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
const int MOD = 1000000009;
int n, m;
/*int head[500010], to[500010], nxt[500010], cnt;
inline void addedge (int u, int v) { cnt++, to[cnt] = v, nxt[cnt] = head[u], head[u] = cnt; }*/
struct interval {
	int l, r;
	inline bool operator < (const interval it) const { return l == it.l ? r < it.r : l < it.l; }
} it[500010];
int p[500010];
/*int f[500010], s[500010];*/
int f[10010][10010];
int main () {
	freopen ("xmasinterval.in", "r", stdin);
	freopen ("xmasinterval.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) scanf ("%d%d", &it[i].l, &it[i].r);
	for (int i = 1; i <= m; i++) scanf ("%d", &p[i]);
	sort (p + 1, p + m + 1);
	m = unique (p + 1, p + m + 1) - p - 1;
	//f[0] = 1;
	for (int i = 1; i <= n; i++) {
		it[i].l = lower_bound (p + 1, p + m + 1, it[i].l) - p;
		it[i].r = upper_bound (p + 1, p + m + 1, it[i].r) - p - 1;
		/*if (it[i].l > it[i].r) f[0] = 2ll * f[0] % MOD;
		else addedge (it[i].r, it[i].l - 1);*/
	}
	//for (int i = 1; i <= n; i++) printf ("%d %d\n", it[i].l, it[i].r);
	/*s[0] = f[0];
	for (int i = 1; i <= m; i++) {
		s[i] = s[i - 1];
		for (int e = head[i]; e; e = nxt[e]) {
			if (to[e] == 0) f[i] = (f[i] + s[i]) % MOD;
			else f[i] = (f[i] + s[i] - s[to[e] - 1]) % MOD;
			s[i] = (f[i] + s[i - 1]) % MOD;
		}
	}
	printf ("%d\n", f[m]);*/
	sort (it + 1, it + n + 1);
	f[0][0] = 1;
	for (int i = 1; i <= n; i++) {
		f[i][0] = 2ll * f[i - 1][0] % MOD;
		for (int j = 1; j <= m; j++) {
			f[i][j] = f[i - 1][j];
			if (it[i].r >= j) f[i][j] = (f[i][j] + f[i - 1][it[i].l - 1]) % MOD;
			else f[i][j] = (f[i][j] + f[i - 1][j]) % MOD;
		}
	}
	printf ("%d\n", f[n][m]);
	return 0;
}
