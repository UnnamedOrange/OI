#include<cstdio>
#include<iostream>
#include<queue>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
#define ll long long
using namespace std;
const int mod=998244353,N=1e5+5,M=2e5+5;
int dis[N],point[N],cnt,k;
struct edge{
	int u,nxt;
}e[M];
inline ll qpow(ll x,ll y){
	ll ans=1;
	while(y){
		if(y&1) ans=(ans*x)%mod;
		x=(x*x)%mod;
		y>>=1;
	}
	return ans;
}
inline void add(int x,int y){
	e[++cnt].u=y;
	e[cnt].nxt=point[x];
	point[x]=cnt;
}
queue<int>q;
queue<int>p;
void bfs(){
	q.push(1);
	p.push(0);
	while(!q.empty()){
		int s=q.front();
		int num=p.front();
		q.pop(),p.pop();
		dis[s]=(dis[s]+qpow(num,k))%mod;
		for(int i=point[s];i;i=e[i].nxt){
			q.push(e[i].u);
			p.push(num+1);
		}
	}
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	int n,m,x,y;
	scanf("%d%d%d",&n,&m,&k);
	while(m--){
		scanf("%d%d",&x,&y);
		add(x,y);
	}
	bfs();
	for(int i=1;i<=n;i++) printf("%d\n",dis[i]);
	return 0;
}
