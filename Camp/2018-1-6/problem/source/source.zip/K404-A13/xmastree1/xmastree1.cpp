#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn = 5e3 + 5;
const int maxq = 5e3 + 5;
struct edge {
	int v, next;
}e[maxn << 1];
int n, q, t, opt, cnt, c, a, b, ans, lastans;
int color[maxn], fa[maxn], cntc[maxn];
int head[maxn];
void adde(const int &u, const int &v) {
	e[++cnt] = (edge) {v, head[u]};
	head[u] = cnt;
}
void dfs(int u, int p) {
	fa[u] = p;
	for(register int i = head[u]; i; i = e[i].next) {
		int v = e[i].v;
		if(v == p) continue;
		dfs(v, u);
	}
}
void tot(int u) {
	cntc[color[u]] = 1;
	for(register int i = head[u]; i; i = e[i].next) {
		int v = e[i].v;
		if(v == fa[u]) continue;
		tot(v);
	}
}
void BruteForce() {
	dfs(1, 0);
	for(register int i = 1; i <= q; ++i) {
		scanf("%d", &opt);
		if(opt == 1) {
			scanf("%d%d%d", &c, &a, &b);
			if(t == 1) c ^= lastans, a ^= lastans, b ^= lastans;
			ans = 0, memset(cntc, 0, sizeof(cntc));
			tot(c);
			for(register int j = a; j <= b; ++j)
				ans += cntc[j];
			printf("%d\n", ans);
			lastans = ans;
		} else {
			scanf("%d%d", &a, &b);
			color[a] = b;
		}
	}
}
int main() {
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &t);
	for(register int i = 1; i <= n; ++i)
		scanf("%d", &color[i]);
	for(register int i = 1; i < n; ++i) {
		scanf("%d%d", &a, &b);
		adde(a, b), adde(b, a);
	}
	BruteForce();
	return 0;
}
