#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int Mod = 998244353;
const int maxn = int(1e5), maxm = int(4e5), maxk = 30;

struct edge
{
	int adj, nxt;

	edge() { }
	edge(int _adj, int _nxt): adj(_adj), nxt(_nxt) { }
}e[maxm + 5];

int st[maxn + 5], _cnt;

inline void add_edge(int u, int v)
{
	e[_cnt] = edge(v, st[u]), st[u] = _cnt++;
}

int n, m, k;

inline void input()
{
	n = read<int>(), m = read<int>(), k = read<int>();

	memset(st, -1, sizeof st), _cnt = 0;
	REP(i, 0, m)
	{
		int u = read<int>() - 1, v = read<int>() - 1;
		add_edge(u, v);
	}
}

inline int fpm(int x, int y)
{
	int res = 1;
	for(x %= Mod; y; y >>= 1, x = LL(x) * x % Mod) if(y & 1) res = LL(res) * x % Mod;
	return res;
}

int ans[maxn + 5];

inline void dfs(int u, int dep)
{
	(ans[u] += fpm(dep, k)) %= Mod;

	for(int i = st[u]; ~i; i = e[i].nxt)
	{
		int v = e[i].adj;
		dfs(v, dep + 1);
	}
}

namespace MATH
{
	const int maxv = 100;

	int fac[maxv + 5], inv[maxv + 5];

	inline void init()
	{
		fac[0] = 1;
		for(int i = 1; i <= maxv; ++i) fac[i] = LL(i) * fac[i - 1] % Mod;
		inv[maxv] = fpm(fac[maxv], Mod - 2);
		for(int i = maxv - 1; ~i; --i) inv[i] = LL(i + 1) * inv[i + 1] % Mod;
	}

	inline int C(int _n, int _m)
	{
		if(_n < _m) return 0;
		return LL(fac[_n]) * inv[_m] % Mod * inv[_n - _m] % Mod;
	}
}

int f[maxn + 5][maxk + 5], cnt[maxn + 5];

inline void trans(int x, int y)
{
	static int tmp[maxk + 5];
	tmp[0] = f[x][0];
	for(int i = 1; i <= k; ++i)
	{
		int res = f[x][i];
		for(int j = 0; j < i; ++j) (res += LL((i - j) & 1 ? 1  : -1) * MATH::C(i, j) % Mod * tmp[j] % Mod) %= Mod;
		tmp[i] = (res + Mod) % Mod;
	}

	for(int i = 0; i <= k; ++i) (f[y][i] += tmp[i]) %= Mod;
}

inline void bfs()
{
	static queue<int> q;
	static bool vis[maxn + 5];

	f[0][0] = 1;
	for(int i = 1; i <= k; ++i) f[0][i] = 0;
	q.push(0);
	while(!q.empty())
	{
		int u = q.front();
		q.pop();

		for(int i = st[u]; ~i; i = e[i].nxt)
		{
			int v = e[i].adj;
			trans(u, v);
			if(!vis[v]) q.push(v), vis[v] = 1;
		}
	}
}

inline void solve()
{
	MATH::init();
	if(k <= 30) bfs();
	else dfs(0, 0);
	REP(i, 0, n) printf("%d\n", k <= 30 ? f[i][k] : ans[i]);
}

int main()
{
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);

	input();
	solve();

	return 0;
}


