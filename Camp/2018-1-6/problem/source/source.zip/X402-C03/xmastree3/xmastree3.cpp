#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=50+5,maxk=15+5,mod=998244353;
int n,k,ans;
vector<int> g[maxn];
map<pair<ll,int>,int> mp;

ll dfss(int pos,ll tree){
	ll res=1ll<<pos;
	tree^=res;
	for(int i=0;i<g[pos].size();++i)
		if(tree>>g[pos][i]&1)
			res|=dfss(g[pos][i],tree);
	return res;
}
int dfs(ll tree,int label){
	if(mp.count(make_pair(tree,label)))
		return mp[make_pair(tree,label)];
	if((tree&-tree)==tree)
		return mp[make_pair(tree,label)]=k+1-label;
	ll res=0;
	for(int i=1;i<=n;++i)
		if(tree>>i&1)
			for(int kk=label;kk<=k;++kk){
				ll tmp=1;
				for(int j=0;j<g[i].size();++j)
					if(tree>>g[i][j]&1){
						ll temp=0;
						ll subtree=dfss(g[i][j],tree^(1ll<<i));
						if(kk<k)
							temp+=dfs(subtree,kk+1);
						tmp=temp%mod*tmp%mod;
					}
				if(tmp==0)break;
				res+=tmp;
			}
	return mp[make_pair(tree,label)]=res%mod;
}

int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1,u,v;i<n;++i){
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	ans=dfs((1ll<<n+1)-2,1);
	printf("%d\n",ans);
	return 0;
}

