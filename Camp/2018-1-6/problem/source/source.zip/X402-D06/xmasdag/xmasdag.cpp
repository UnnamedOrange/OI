#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e5+10;
const int maxm=2e5+10;
const int maxk=5e2+10;
const int mod=998244353;
const int MAXN=2e3+10;
int C[maxk][maxk],to[maxm],nex[maxm],beg[maxn],deg[maxn],q[maxn],dp[maxn][maxk],tmp[maxk];
int DP[MAXN][MAXN];
int e;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
inline void initialize(int n){
	int i,j;
	C[0][0]=1;
	for(i=1;i<=n;i++){
		C[i][0]=C[i][i]=1;
		for(j=1;j<i;j++)
			C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
	}
}
inline ll qpow(ll a,ll b){
	ll ans=1;
	while(b){
		if(b & 1)ans=ans*a%mod;
		a=a*a%mod;
		b/=2;
	}
	return ans;
}
inline int Mod(int x,int y){
	return x+y>=mod ? x+y-mod : x+y;
}
int main(){
	int i,j,k,m,n;
#ifndef ONLINE_JUDGE
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
#endif
	n=read();m=read();k=read();
	initialize(k);
	for(i=1;i<=m;i++){
		int x,y;
		x=read();y=read();
		add(x,y);deg[y]++;
	}
	int f=0,l=1;
	q[1]=1;dp[1][0]=1;
	if(n<=2000){
		DP[1][0]=1;
		while(f<l){
			int x=q[++f];
			for(i=beg[x];i;i=nex[i]){
				for(j=0;j<n;j++)
					DP[to[i]][j+1]=Mod(DP[to[i]][j+1],DP[x][j]);
				if(!(--deg[to[i]]))q[++l]=to[i];
			}
		}
		for(i=1;i<=n;i++){
			int ans=0;
			for(j=1;j<=n;j++)
				ans=Mod(ans,1ll*DP[i][j]*qpow(j,k)%mod);
			printf("%d\n",ans);
		}
		return 0;
	}
	else{
		while(f<l){
			int x=q[++f];
			memset(tmp,0,sizeof(tmp));
			for(i=0;i<=k;i++)
				for(j=0;j<=i;j++)
					tmp[i]=Mod(tmp[i],1ll*dp[x][j]*C[i][j]%mod);
			for(i=beg[x];i;i=nex[i]){
				for(j=0;j<=k;j++)
					dp[to[i]][j]=Mod(dp[to[i]][j],tmp[j]);
				if(!(--deg[to[i]]))q[++l]=to[i];
			}
		}
		for(i=1;i<=n;i++)printf("%d\n",dp[i][k]);
	}
	return 0;
}

