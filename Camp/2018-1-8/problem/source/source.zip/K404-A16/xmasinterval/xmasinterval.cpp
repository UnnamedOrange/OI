#include <cstdio>
#include <algorithm>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

typedef long long ll;
const int N = 500010;
const int mod = 1e9 + 9;

struct seg{int l, r;} p[N], q[N];
bool operator < (seg a, seg b) {return a.r == b.r ? a.l < b.l : a.r < b.r;}

int a[N];
ll F[N], h[N];
int n, m, tot, lst;
ll ans, tans;

void change(int x, int y)
{
	for(; x <= m + 1; x += x & -x) (h[x] += y) %= mod;
}

int find(int x)
{
	int ans = 0;
	for(; x; x -= x & -x) (ans += h[x]) %= mod;
	return ans;
}

int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	scanf("%d%d", &n, &m); ans = 1;
	FOR(i, 1, n) scanf("%d%d", &p[i].l, &p[i].r);
	FOR(i, 1, m) scanf("%d", &a[i]);
	sort(a + 1, a + m + 1);
	m = unique(a + 1, a + m + 1) - a - 1;
	
	FOR(i, 1, n)
	{
		if (p[i].l > a[m] || p[i].r < a[1]) {ans = ans * 2 % mod; continue;}
		p[i].l = lower_bound(a + 1, a + m + 1, p[i].l) - a;
		p[i].r = upper_bound(a + 1, a + m + 1, p[i].r) - a - 1;
		if (p[i].l > p[i].r) {ans = ans * 2 % mod; continue;}
		q[++tot] = p[i];
	}
	
	sort(q + 1, q + tot + 1);
	change(1, 1);
	FOR(i, 1, tot)
	{
		if (q[i].l > lst + 1) {ans = ans * 2 % mod; continue;}
		F[i] = (find(q[i].r + 1) - find(q[i].l - 1) + mod) % mod;
		change(q[i].r + 1, F[i]); lst = q[i].r;
	}
	
	FOR(i, 1, tot) if (q[i].r == m) (tans += F[i]) %= mod;
	printf("%lld\n", tans * ans % mod);
	return 0;
}
