#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 1000
using namespace std;
int n,w[maxn],head[maxn],num,a[maxn],cnt,root,fa[maxn];
long long ans=0;
bool vis[20];
struct node{int to,pre;}e[maxn*2];
void Insert(int from,int to){
	e[++num].to=to;
	e[num].pre=head[from];
	head[from]=num;
}
void dfs(int now,int father){
	fa[now]=father;
	for(int i=head[now];i;i=e[i].pre){
		int to=e[i].to;
		if(to==father)continue;
		dfs(to,now);
	}
}
void work(int pos,long long val){
	ans=max(ans,val);
	for(int i=1;i<=n;i++)
		if(!vis[i]&&vis[fa[i]]){
			vis[i]=1;
			work(pos+1,val+w[i]*pos);
			vis[i]=0;
		}
}
int main(){
	freopen("xmastree2.in","r",stdin);freopen("xmastree2.out","w",stdout);
//	freopen("Cola.txt","r",stdin);
	scanf("%d",&n);
	int x,y;
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		Insert(x,y);Insert(y,x);
	}
	for(int i=1;i<=n;i++){
		scanf("%d%d",&w[i],&x);
		if(x)a[++cnt]=i;
	}
	for(int i=1;i<=cnt;i++){
		root=a[i];
		dfs(root,0);
		vis[root]=1;
		work(2,w[root]);
		vis[root]=0;
	}
	cout<<ans;
	return 0;
}
