#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
using namespace std;
int n,w[1000010];
double ans;
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)scanf("%d",w+i);
	for(int i=1;i<=n;++i){
		double v=0,x=1;
		int la=i;
		for(int j=i-1;j;--j)
			if(w[j]>=w[i])
				v+=w[i]/x*(la-j),x*=2,la=j;
		v+=w[i]/x*la;
		x=1;la=i;double res=0;
		for(int j=i+1;j<=n;++j)
			if(w[j]>w[i])
				res+=v/x*(j-la),x*=2,la=j;
		res+=v/x*(n-la+1);
		ans+=res/2;
	}
	ans/=n;ans/=n;
	printf("%lf\n",ans);
	return 0;
}
