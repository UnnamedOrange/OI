#include<bits/stdc++.h>
typedef unsigned long long ll;
using namespace std;
const int maxn = 100009;
const int p = 31;

char str[maxn];
ll h1[maxn],h2[maxn],ft[maxn];
int n,T;

ll calc1(int l,int r){return h1[r]-h1[l-1]*ft[r-l+1];}
ll calc2(int l,int r){return h2[l]-h2[r+1]*ft[r-l+1];}
bool check(int l,int r)
{
	return calc1(l,r)==calc2(l,r);
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	ft[0]=1;
	for(int i=1;i<=maxn-9;i++) ft[i]=ft[i-1]*p;
	while(T--)
	{
		scanf("%d%s",&n,str+1);
		for(int i=1;i<=n;i++) h1[i]=h1[i-1]*p+str[i]-'a'+1;
		for(int i=n;i>=1;i--) h2[i]=h2[i+1]*p+str[i]-'a'+1;
		if(!check(1,n)) puts("1");
		else
		{
			bool flag=0;
			for(int i=1;i<n;i++)
				if(!check(1,i)&&!check(i+1,n))
				{
					flag=1;
					break;
				}
			if(flag) puts("2");
			else puts("-1");
		}
	}
	return 0;
}
