#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

typedef long long ll;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=1001000;

bool book[N];
int prime[N],mobius[N],D[N];
ll sum[N];

inline int divisor(int x,int y)
{//cout<<x<<" "<<y<<endl;
	int res=1;
	while(x%y==0) x/=y,res++;
	return res;
}

void initial()
{
	register int i,j,cnt(0),now;
	D[1]=mobius[1]=1;
	for(i=2;i<N;++i)
	{
		if(!book[i])
		{prime[++cnt]=i;mobius[i]=-1;D[i]=2;}
		for(j=1;j<=cnt && prime[j]*i<N;++j)
		{
			now=prime[j]*i;
			book[now]=1;
			mobius[now]-=mobius[i];
			if(i%prime[j]==0)
			{
				mobius[now]=0;
				int tmp=divisor(i,prime[j]);//cout<<tmp<<endl;
				D[now]=D[i]/tmp*(tmp+1);//if(now==4){cout<<D[now]<<" "<<D[i]<<" "<<tmp<<endl;exit(0);}
				break;
			}
			D[now]=D[i]<<1;
		}
	}
	for(i=1;i<N;++i)
		sum[i]=sum[i-1]+1ll*D[i]*D[i];
}

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	
	initial();
	register int i,j,d;
//	int n=read();
	/*
	for(i=1;i<=n;++i)
	{
		int res=0;
		for(j=1;j<=i;++j)
		{//res=0;
			for(d=1;d<=j;++d)
			{
				if(j%d==0)
				res+=D[d]*D[d];
			}
		//	cout<<j<<" "<<res<<endl;
		}
		cout<<i<<" "<<res<<endl;
	}
	*/
	int T=read();
	while(T--)
	{
		int n=read();
		ll ans(0);
		for(i=1;i<=n;++i)
			ans+=mobius[i]*sum[n/i];
		printf("%lld\n",ans);
	}
	return 0;
}
/*
4
233333
2333333
23333333
233333333

*/


