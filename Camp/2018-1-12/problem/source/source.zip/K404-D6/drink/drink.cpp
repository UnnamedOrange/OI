#include<cstdio>
#include<algorithm>
#include<queue>
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
#define pa pair<db,int>
#define mp(x,y) make_pair(x,y)
using namespace std;
const int maxn=1e6+11;
typedef double db;
priority_queue<pa>heap;
int n,pos,cnt;
db w[maxn],b[maxn],water,now,ans;
inline db max(db a,db b){
	return a>b?a:b;
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	FOR(i,1,n)
		scanf("%lf",&w[i]),heap.push(mp(-w[i],i));
	for(register int i=1;i<=n;++i){
		cnt=0;
		for(register int j=i;j<=n;++j){
			b[++cnt]=w[j];
			now=0;
			sort(b+1,b+cnt+1);
			for(register int k=1;k<=cnt;++k)
				now=1.00*(now+b[k])/2.00;
			ans+=1.00*now/(1.00*n*n);
		}
	}
	printf("%.15lf",ans);
	return 0;
}
