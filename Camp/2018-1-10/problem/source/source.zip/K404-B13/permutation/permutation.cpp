#include<bits/stdc++.h>
using namespace std;
#define mo 998244353
int x[100005],cnt,n;
bool vis[100005];

void dfs(int i){
//	vis[i]=1; cnt
}
void readit(){
	cin>>n;
	for(int i=1;i<=n;i++){
		scanf("%d",&x[i]);
		if(!x[i]) cnt++;
	}
	cnt=n;
	for(int i=1;i<=n;i++){
		if(!vis[i]&&x[i]) dfs(i);
	}
}
int per[100005];
long long jie(int v){
	long long ans=1;
	while(v) ans*=v,v--;
	return ans;
}
long long C(int a,int b){
	int ans=1;
	for(int i=1;i<=b;i++)
		ans*=(a-i+1),ans/=i;
	return ans;
}
int permu_(int p){
//	cout<<"permu:"<<p<<endl;
	if(per[p]) return per[p];
	long long ans=0;
	ans+=jie(p-1);
//	cout<<ans;
	int q=p/2;
	for(int i=2;i<p;i+=2){
		ans+=C(p,i)*permu_(i)*permu_(p-i)/2;
		ans%=mo;
	}
	per[p]=ans;
//	cout<<"    "<<ans<<endl;
	return ans;
}
void de_bug(){
	per[2]=1;
	for(int i=1;i<=4;i++)
	cout<<permu_(i*2)<<endl;
	cout<<C(4,2);
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
//	readit();
	de_bug();
	return 0;
}
