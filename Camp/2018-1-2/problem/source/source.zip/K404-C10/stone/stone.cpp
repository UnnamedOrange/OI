#include <cstdio>
using namespace std;
#define N 100050
#define Mod 1000000007
int c[N],cnt[10],n,a,b,i;
inline int qmi(int di,int zhi)
{
	int ret=1,x=di;
	while (zhi){
		if (zhi&1) ret=1LL*ret*x%Mod;x=1LL*x*x%Mod;zhi>>=1;
	}return ret;
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	for (i=1;i<=n;i++) scanf("%d",&c[i]),c[i]%=(a+b);
	if (a<b){
		for (i=1;i<=n;i++) if (c[i]<a) cnt[1]++;
		else if (c[i]<b) cnt[2]++;else cnt[3]++;
		printf("%d 0 %d %d\n",((qmi(2,n)-qmi(2,cnt[1]+cnt[3]))%Mod+Mod)%Mod,cnt[3]==0?0:qmi(2,cnt[1]+cnt[3]-1),cnt[3]==0?qmi(2,cnt[1]+cnt[3]):qmi(2,cnt[1]+cnt[3]-1));
	}else{
		for (i=1;i<=n;i++) if (c[i]<b) cnt[1]++;
		else if (c[i]<a) cnt[2]++;else cnt[3]++;
		printf("0 %d %d %d\n",((qmi(2,n)-qmi(2,cnt[1]+cnt[3]))%Mod+Mod)%Mod,cnt[3]==0?0:qmi(2,cnt[1]+cnt[3]-1),cnt[3]==0?qmi(2,cnt[1]+cnt[3]):qmi(2,cnt[1]+cnt[3]-1));
	}
	return 0;
}
