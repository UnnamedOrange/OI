#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=5e6+10;
int t,n;
int pcnt,prime[maxn/10],d[maxn],mu[maxn],minp[maxn];
ll sumd[maxn];
bool prm[maxn];

inline void init(){
	mu[1]=1;d[1]=1;minp[1]=0;sumd[1]=1;
	for(int i=2;i<maxn;++i){
		if(!prm[i]){
			prime[++pcnt]=i;
			mu[i]=-1;d[i]=2;minp[i]=1;
		}
		for(int j=1;j<=pcnt&&prime[j]*i<maxn;++j){
			prm[prime[j]*i]=true;
			if(i%prime[j]){
				mu[i*prime[j]]=-mu[i];
				d[i*prime[j]]=d[i]*2;
				minp[i*prime[j]]=1;
			}
			else{
				mu[i*prime[j]]=0;
				d[i*prime[j]]=d[i]/(minp[i]+1)*(minp[i]+2);
				minp[i*prime[j]]=minp[i]+1;
				break;
			}
		}
		sumd[i]=sumd[i-1]+d[i];
	}
}
ll calc(int n){
	if(n<maxn)
		return sumd[n];
	ll res=0;
	for(int i=1,j;i<=n;){
		j=n/(n/i)+1;
		res+=n/i*(j-i);
		i=j;
	}
	return res;
}

int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	init();
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		ll ans=0;
		for(int i=1;i*i<=n;++i){
			if(mu[i]==0)continue;
			int m=n/i/i;
			ll tmp=0;
			for(int j=1,k;j<=m;){
				k=m/(m/j)+1;
				tmp+=m/j*(calc(k-1)-calc(j-1));
				j=k;
			}
			ans+=tmp*mu[i];
		}
		printf("%lld\n",ans);
	}
	return 0;
}
