//ԭ������ 
#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#define ll long long
using namespace std;
vector<int> v[1000005];
int read()
{
	char ch=getchar();int x=0,f=1;
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
struct node
{
	int from;
	int to;
	int next;
}edge[1000005];
int n,m,head[1000005],q[1000005],s[1000005],top,tail,dis[1000005],tot;
int dfn[1000005];bool vis[1000005];
int du[1000005],low[1000005],size[1000005],tim,num,belong[1000005];
void add(int u,int v)
{
	edge[tot].from=u;
	edge[tot].to=v;
	edge[tot].next=head[u];
	head[u]=tot++;
}
void tarjan(int x)
{
	dfn[x]=low[x]=++tim;
	vis[x]=1;
	s[++top]=x;
	for(int i=head[x];i!=-1;i=edge[i].next)
	{
		if(!dfn[edge[i].to])
		{
			tarjan(edge[i].to);
			low[x]=min(low[x],low[edge[i].to]);
		}
		else if(vis[edge[i].to])
		{
			low[x]=min(low[x],dfn[edge[i].to]);
		}
	}
	if(low[x]==dfn[x])
	{
		num++;
		while(s[top]!=x)
		{
			vis[s[top]]=0;
			belong[s[top--]]=num;
			size[num]++;
		}
		size[num]++;
		belong[x]=num;
		top--;
		vis[x]=0;
	}
}
void topsort()
{
	while(top>=tail)
	{
		int x=q[tail++];
		int sz=v[x].size();
		for(int i=0;i<sz;i++)
		{
			int to=v[x][i];
			dis[to]=max(dis[to],dis[x]+size[to]);
			du[to]--;
			if(!du[to])
			q[++top]=edge[i].to;
		}
	}
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	memset(head,-1,sizeof(head));
	n=read();m=read();
	for(int i=1;i<=m;i++)
	{
		int u=read(),v=read();
		add(u,v);
	}
	for(int i=1;i<=n;i++)
	{
		if(!dfn[i])
		tarjan(i);
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=head[i];j!=-1;j=edge[j].next)
		{
			if(belong[i]!=belong[edge[j].to])
			{
				v[belong[i]].push_back(belong[edge[j].to]);
				du[belong[edge[j].to]]++;
			}
		}
	}
	top=0;tail=1;
	for(int i=1;i<=num;i++)
	{
		if(!du[i])
		{
			q[++top]=i;
			dis[i]=size[i];
		}
	}
	topsort();
	int ans=0;
	for(int i=1;i<=num;i++)
	{
		ans=max(ans,dis[i]);
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
