#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 505
#define maxm 300005
typedef long long ll;
const ll inf=1e15;

int n,w,p,q,s,t,tot=1;
int now[maxn],pre[maxm*2],son[maxm*2];
int dep[maxn],Q[maxn];
ll ans,c[maxm*2],v[maxn][maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

void fuck(int x,int y,int w,int a,int d){
	if (x==y) return; ans-=12*w*d;
	v[s][x]+=8*w*d,v[x][t]+=10*w*d,v[s][y]+=4*w*d,v[y][t]+=2*w*d;
	v[x][y]+=2*w*a,v[y][x]+=2*w*a;
}

void add(int a,int b,ll x){son[++tot]=b,pre[tot]=now[a],now[a]=tot,c[tot]=x;}
void link(int a,int b,ll x){add(a,b,x),add(b,a,0);}

bool bfs(){
	memset(dep,-1,sizeof(dep)),dep[s]=0;
	int head=1,tail=1; Q[1]=s;
	while (head<=tail){
		int x=Q[head++];
		for (int p=now[x];p;p=pre[p])
			if (c[p]&&dep[son[p]]==-1){
				dep[son[p]]=dep[x]+1;
				if (son[p]==t) return 1;
				Q[++tail]=son[p];
			}
	}
	return 0;
}

ll find(int x,ll flow){
	if (x==t) return flow;
	ll ret=0;
	for (int p=now[x];p;p=pre[p])
		if (c[p]&&dep[son[p]]==dep[x]+1){
			ll next=find(son[p],min(c[p],flow));
			c[p]-=next,c[p^1]+=next,flow-=next,ret+=next;
			if (!flow) break;
		}
	if (!ret) dep[x]=-1;
	return ret;
}

void clear(){
	tot=1,ans=0,memset(now,0,sizeof(now));
	memset(v,0,sizeof(v));
}

int main(){
	for (int T=read();T;T--){
		clear();
		n=read(),w=read(),p=read(),q=read(); s=0,t=n+1;
		for (int i=1;i<=n;i++){
			v[s][i]+=w,v[i][t]+=3*w;
			ans-=2*w;
		}
		for (int i=1;i<=p;i++){
			int x=read(),y=read(),z=read(),a=read(),b=read(),c=read(),d=read(),e=read(),f=read();
			fuck(x,y,w,a,d),fuck(y,z,w,b,e),fuck(z,x,w,c,f);
		}
		for (int i=1;i<=q;i++){
			int x=read(),y=read(),r=read();
			if (x==y) continue;
			if (r==0) v[x][y]=inf;
			else if (r==1) v[x][y]=inf,v[y][x]=inf;
			else if (r==2) v[x][t]=inf,v[s][y]=inf;
		}
		for (int i=1;i<=n;i++){
			if (v[s][i]) link(s,i,v[s][i]);
			if (v[i][t]) link(i,t,v[i][t]);
		}
		for (int i=1;i<=n;i++)
			for (int j=1;j<=n;j++)
				if (v[i][j]) link(i,j,v[i][j]);
		while (bfs()) ans+=find(s,inf);
		printf("%lld\n",ans);
	}
	return 0;
}
