#include<bits/stdc++.h>
using namespace std;

int n,a[10][10],mapp[10][10],vis[10],ans,k;

bool dfs(int noww,int x,int y)
{
	if (y==k)
	  {
	  	if (mapp[x][noww]) return true;
	  	else return false;
	  }
	vis[x]=1;
	for (int i=1;i<=n;i++)
	  {
	  	if (mapp[x][i]) 
		  {
		  	if (dfs(noww,i,y+1)) return true;
		  }
	  }
	return false;  
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	int cnt=1;
	for (int i=1;i<=n;i++)
	  for (int j=i+1;j<=n;j++)
	    {
	      a[i][j]=cnt;
	      cnt=cnt*2;
		}
	for (int emm=0;emm<cnt;emm++)
	  {
	  	int em=emm;
	  	memset(vis,0,sizeof(vis));
	  	for (int i=1;i<=n;i++) for (int j=i+1;j<=n;j++) mapp[i][j]=1,mapp[j][i]=0;
	  	for (int i=n;i>=1;i--)
	  	  for (int j=n;j>=i+1;j--)
	  	    {
	  	      if (!em) break;
	  	      if (a[i][j]<=em) em-=a[i][j],mapp[i][j]=0,mapp[j][i]=1;
			}  
		for (int i=1;i<=n;i++)
		  {
		  	memset(vis,0,sizeof(vis));
		  	if (dfs(i,i,1)) 
			  {
			  	ans++;
			  	break;
			  }
		  }	
	  }
	printf("%d",ans);
	return 0;  	
}
