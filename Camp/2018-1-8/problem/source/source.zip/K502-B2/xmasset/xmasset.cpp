#include <bits/stdc++.h>
using namespace std;
int type, N;
int vvv[925][13],psz;
int tmp[12];
void dfs(int x,int c){
	if(x==7){
		psz++;
		for(int i=1;i<=6;i++)vvv[psz][tmp[i]]=1;
		return;
	}
	for(int j=c;j<=12;j++){
		tmp[x]=j;
		dfs(x+1,j+1);
	}
}
void init(){
	dfs(1,1);
}
int encode(int x, int y){
	for(int i=1;i<=12;i++)if(vvv[x][i]&&!vvv[y][i])return i;
	return x;
}
bool decode(int q, int h){
	return vvv[q][h];
	return q == h;
}
int main(){
	int T;
	scanf("%d%d%d", &type, &N, &T);
	init();
	while (T--) {
		int x, y;
		scanf("%d%d", &x, &y);
		if (type == 1)
			printf("%d\n", encode(x, y));
		else
			puts(decode(x, y) ? "yes" : "no");
	}
	return 0;
}
