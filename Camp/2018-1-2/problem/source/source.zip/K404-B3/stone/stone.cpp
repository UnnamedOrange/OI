#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define mod 1000000007
#define ll long long
#define N 100010
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
ll ksm(ll a,ll b)
{
	ll sum=1;
	while(b)
	{
		if(b&1) sum=sum*a%mod;
		a=a*a%mod;b>>=1;
	}
	return sum;
}
int n,a,b,x[N];
namespace sub1
{
	int win,los;
	ll s1,ni[N],mi[N],s2;
	ll C(ll x,ll y)
	{
		if(x==y) return 1;
		return mi[y]*ni[x]%mod*ni[y-x]%mod;
	}
	void Main()
	{
		for(int i=1;i<=n;i++)
			if((x[i]/a)&1) win++;
		los=n-win;mi[1]=1;
		for(int i=2;i<=n;i++) mi[i]=mi[i-1]*i%mod;
		for(int i=1;i<=n;i++) ni[i]=ksm(mi[i],mod-2);
		ll tp=ksm(2,los);
		for(int i=1;i<=win;i+=2)
		{
			s1+=C(i,win)*tp%mod;
		}
		s1%=mod;
		s2=(ksm(2,n)+mod-s1)%mod;
		printf("0 0 %lld %lld\n",s1,s2);
	}
};
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n=rd();a=rd();b=rd();
	for(int i=1;i<=n;i++) x[i]=rd();
	if(a==b) sub1::Main();
	return 0;
}