#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<< " = "<<(x)<<" "
#define debug(x) cerr<<#x<< " = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e5+5,M=N<<1,mod=998244353;

void add_mod(int &a,int b){if((a+=b)>=mod)a-=mod;}
int Pow(int x,int y){
	int res=1;
	for(;y;y>>=1,x=(ll)x*x%mod)
		if(y&1)res=(ll)res*x%mod;
	return res;
}
int n,m,K;
int head[N],cnt[N],deg[N],que[N];
pii G[M];
struct P_0{
	int dp[2005][2005];
	void work(){
		dp[1][0]=cnt[1]=1;
		int l=0,r=0,i,x,y;
		que[r++]=1;
		while(l<r){
			for(x=que[l++],i=head[x];i;i=G[i].se){
				y=G[i].fi;
				--deg[y];
				if(!deg[y])que[r++]=y;
				rep(i,0,n)if(dp[x][i])add_mod(dp[y][i+1],dp[x][i]);
			}
		}
		rep(x,1,n+1){
			int ans=0;
			rep(j,1,n)ans=(ans+dp[x][j]*(ll)Pow(j,K))%mod;
			ptn(ans);
		}
	}
}P0;
int dp[N][502];
struct P_1{
	int a[32],C[32][32];
	void work(){
		rep(i,0,K+1){
			C[i][0]=1;
			rep(j,1,i+1)add_mod(C[i][j]=C[i-1][j],C[i-1][j-1]);
		}
		int l=0,r=0,x,y,i,j;
		que[r++]=1;
		dp[1][0]=1;
		while(l<r){
			x=que[l++];
			for(i=0;i<=K;++i){
				a[i]=0;
				for(j=0;j<=i;++j)a[i]=(a[i]+(ll)dp[x][j]*C[i][j])%mod;
			}
			for(i=head[x];i;i=G[i].se){
				y=G[i].fi;
				--deg[y];
				if(!deg[y])que[r++]=y;
				for(j=0;j<=K;++j)add_mod(dp[y][j],a[j]);
			}
		}
		--dp[1][0];
		rep(i,1,n+1)ptn(dp[i][K]);
	}
}P1;
struct P_2{
	int fac[502],ifac[502],rev[1050],len,inv;
	void NTT(int *A,int flag){
		static int x[1050],i,j,k,a,b,gm,g,delta;
		for(i=0;i<len;++i)x[rev[i]]=A[i];
		for(i=1;i<len;i<<=1){
			gm=Pow(3,(mod-1)/i/2);
			if(flag)gm=Pow(gm,mod-2);
			for(j=0,delta=i<<1;j<len;j+=delta){
				g=1;
				for(k=0;k<i;++k){
					a=x[j+k],b=(ll)x[j+k+i]*g%mod;
					add_mod(x[j+k]=a,b);
					add_mod(x[j+k+i]=a,mod-b);
					g=(ll)g*gm%mod;
				}
			}
		}
		if(flag){
			for(i=0;i<len;++i)x[i]=(ll)x[i]*inv%mod;
		}
		memcpy(A,x,len<<2);
	}
	void work(){
		fac[0]=1;
		rep(i,1,K+1)fac[i]=(ll)fac[i-1]*i%mod;
		ifac[K]=Pow(fac[K],mod-2);
		per(i,1,K+1)ifac[i-1]=(ll)ifac[i]*i%mod;
		len=1;
		while(len<=(K<<1))len<<=1;
		rep(i,1,len)rev[i]=(rev[i>>1]>>1)|((i&1)*(len>>1));
		inv=Pow(len,mod-2);
		rep(i,0,len)dp[1][i]=1;
		static int NTTfac[1050];
		memcpy(NTTfac,ifac,len<<2);
		NTT(NTTfac,0);
		int l=0,r=0,x,y,i,j,_K=K+1,_len=len-_K;
		que[r++]=1;
		dp[1][0]=1;
		while(l<r){
			x=que[l++];
			static int a[1050];
			NTT(dp[x],1);
			if(!head[x])continue;
			memcpy(a,dp[x],_K<<2);
			memset(a+_K,0,_len<<2);
			NTT(a,0);
			for(i=0;i<len;++i)a[i]=(ll)a[i]*NTTfac[i]%mod;
			for(i=head[x];i;i=G[i].se){
				y=G[i].fi;
				--deg[y];
				if(!deg[y])que[r++]=y;
				for(j=0;j<len;++j)add_mod(dp[y][j],a[j]);
			}
		}
		{//output 
			--dp[1][0];
			rep(i,1,n+1){
				ptn((ll)dp[i][K]*fac[K]%mod);
			}
		}
	}
}P2;
int main(){
//	debug((sizeof (P0)+sizeof (P1))>>20);
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	rd(n),rd(m),rd(K);
	for(int x,y,tot_edge=0;m--;){
		rd(x),rd(y);
		++deg[y];
		G[++tot_edge]=pii(y,head[x]);head[x]=tot_edge;
	}
	if(0);
	else if(n<=2000&&m<=5000)P0.work();
	else if(K<=30)P1.work();
	else P2.work();
	return 0;
}
