#include<cstdio>
using namespace std;
const int maxn=1000005,mod=1000000007;
struct cp{
	int num,l,r;
}e[maxn];
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	int n,num=0,ans=1,cnt=0,fan=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		e[i].num=i;
		scanf("%d%d",&e[i].l,&e[i].r);
	}
	num=e[1].l;
	for(int i=1;i<=n;i++){
		if(num==0) cnt=0,ans++,num=e[i].l;
		if(ans>mod) ans-=mod;
		cnt++;
		if(e[i].l>num) num=e[i].l-cnt+1;
		if(e[i].r<cnt||(e[i].r>cnt&&i==n)){printf("-1\n");return 0;}
		num--;
	}
	fan=ans%100/2;
	printf("%d %d\n",ans,fan);
	return 0;
}
