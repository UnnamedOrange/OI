#include <bits/stdc++.h>

#define lc k << 1
#define rc k << 1 | 1

#define eps 1e-10

using namespace std;
typedef long long ll;
const ll mod = 998244353;

ll qpow(ll a, ll b){
	ll ret = 1;
	for(; b; b >>= 1, a = a * a % mod){
		if(b & 1) ret = ret * a % mod;
	}
	return ret;
}

ll n, k;
ll ans;
ll fac[1000005];
int main(){
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	scanf("%lld%lld", &n, &k);
	if(k < 3 || k > n){
		printf("0\n");
		return 0;
	}
	fac[0] = 1;
	for(int i = 1; i <= n; i ++){
		fac[i] = fac[i - 1] * i % mod;
	}
    ans = (fac[n] % mod * qpow(fac[k - 1], mod - 2) % mod * qpow(2, (k - 1) * (k - 2) / 2) % mod + mod) % mod;

	printf("%d\n", (qpow(2, n * (n - 1) / 2) - ans + mod) % mod);
	return 0;
}
