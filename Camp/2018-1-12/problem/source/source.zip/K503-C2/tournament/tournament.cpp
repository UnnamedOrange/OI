#include <stdio.h>
#define maxn 100010
#define modn 998244353
int f[maxn],n,k,i,ans,s1=0,s2=1;
int power(int x,int y)
{
	int i=x,s=1;
	for (;y;y=(y>>1))
	{
		if (y&1) s=(long long)s*(long long)i%modn;
		i=(long long)i*(long long)i%modn;
	}
	return s;
}
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	if	(k==3)
	{
		for (i=2;i<=n;i++)
		{
			s1=(s1+i-1)%(modn-1);
			s2=(long long)s2*(long long)i%modn;
		}
		printf("%d",(power(2,s1)-s2+modn)%modn);
	}
	else
	{
		for (i=2;i<=n;i++)
		{
			s1=(s1+i-1)%(modn-1);
			if (i<n) s2=(long long)s2*(long long)i%modn;
		}
		s1=(s1-n+modn)%modn;
		printf("%d",(long long)s2*(long long)power(2,s1)%modn);
	}
	fclose(stdin);
	fclose(stdout);
}
