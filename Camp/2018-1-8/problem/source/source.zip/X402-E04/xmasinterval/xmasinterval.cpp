#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
using namespace std;
const int N=500100,INF=0x3f3f3f3f,Mod=1e9+9;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
template<class T>inline bool chmx(T &a,T b){return a<b?a=b,1:0;}
template<class T>inline bool chmi(T &a,T b){return a>b?a=b,1:0;}
inline void file(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
}
struct node{
	int l,r;
	bool operator <(const node &A)const {
		return l<A.l||(l==A.l&&r>A.r);
	}
}P[N];
int n,m,x[N];
int dp[N],s[N];
ll pw[N];
int t=1;

void init(){
	read(n),read(m);
	pw[0]=1;
	For(i,1,n)read(P[i].l),read(P[i].r),pw[i]=pw[i-1]*2%Mod;
	For(i,1,m)read(x[i]);
	sort(x+1,x+m+1);
	int p=1;
	For(i,2,m)if(x[i]!=x[i-1])x[++p]=x[i];
	m=p;
	p=0;
	For(i,1,n){
		int L=lower_bound(x+1,x+m+1,P[i].l)-x,R=upper_bound(x+1,x+m+1,P[i].r)-x-1;
		if(L>R)t=t*2ll%Mod;
		if(L<=R)P[++p]=(node){L,R};
	}
	n=p;
	sort(P+1,P+n+1);
}
struct Segment_tree{
    #define Mid ((l+r)>>1)
    #define Lc h<<1,l,Mid
    #define Rc h<<1|1,Mid+1,r
    ll Sum[N<<2],Mul[N<<2];
    inline void Pushup(int h){Sum[h]=Sum[h<<1]+Sum[h<<1|1];}
    inline void Pushdown(int h){
        int lc=h<<1,rc=h<<1|1;
        if(Mul[h]!=1){
            Sum[lc]=Sum[lc]*Mul[h]%Mod;
            Sum[rc]=Sum[rc]*Mul[h]%Mod;
            Mul[lc]=Mul[lc]*Mul[h]%Mod;
            Mul[rc]=Mul[rc]*Mul[h]%Mod;
            Mul[h]=1;
		}
    }
	void Build(int h,int l,int r){
		Mul[h]=1;
		if(l==r)return ;
		Build(Lc),Build(Rc);
	}
    void Multi(int h,int l,int r,int L,int R){
        if(l>=L&&r<=R){
            Sum[h]=Sum[h]*2%Mod,Mul[h]=Mul[h]*2%Mod;
            return ;
        }
        Pushdown(h);
        if(L<=Mid)Multi(Lc,L,R);
        if(R>Mid)Multi(Rc,L,R);
        Pushup(h);
    }
    void add(int h,int l,int r,int pos,ll val){
        if(l==r){
            Sum[h]=(Sum[h]+val)%Mod;
            return ;
        }
        Pushdown(h);
        if(pos<=Mid)add(Lc,pos,val);
		else add(Rc,pos,val);
        Pushup(h);
    }
    ll Query(int h,int l,int r,int L,int R){
        if(l>=L&&r<=R)return Sum[h];
        Pushdown(h);
        ll ans=0;
        if(L<=Mid)ans+=Query(Lc,L,R);
        if(R>Mid)ans+=Query(Rc,L,R);
        return ans%Mod;
    }
}T;
void solve(){
	T.Build(1,0,m);
	T.add(1,0,m,0,1);
	For(i,1,n){
		ll val=T.Query(1,0,m,P[i].l-1,P[i].r-1);
		T.Multi(1,0,m,P[i].r,m);
		T.add(1,0,m,P[i].r,val);
	}
	printf("%lld\n",T.Query(1,0,m,m,m)*t%Mod);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
