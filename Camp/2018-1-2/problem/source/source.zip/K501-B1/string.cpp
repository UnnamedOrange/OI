#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define N 100010
using namespace std;
int T,n;
char s[N];
bool ch(int L,int R)
{
	int p1=L,p2=R;
	while(p1<p2) if(s[p1++]!=s[p2--])return 0;
	return 1;
}
void tp()
{
	if(n==4&&s[1]!=s[2])puts("2");
	else puts("-1");
}
void sol1()
{
	int p=n-1;
	while(p>0&&s[p]==s[n])--p;
	if(!p||p==(n+1)/2){puts("-1");return;}
	puts("2");
}
void sol2()
{
	if(ch(1,n-2))puts("-1");
	else puts("2");
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d%s",&n,s+1);
		if(!ch(1,n)){puts("1");continue;}
		if(n<=4)tp();
		else if(s[n]==s[n-1])sol1();
		else sol2();
	}
	return 0;
}