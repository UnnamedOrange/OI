#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
const int maxn=100100;
void solve(){
	int n=2000,m=5000,k=rand()%500+1;
//	int n=100000,m=200000,k=500;
	printf("%d %d %d\n",n,m,k);
	int s,t;
	for(int i=2;i<=n;i++){
		printf("%d %d\n",rand()%(i-1)+1,i);
		m--;
	}
	while(m--){
		s=rand()%n+1,t=rand()%n+1;
		while(s==t) s=rand()%n+1,t=rand()%n+1;
		if(s>t) swap(s,t);
		printf("%d %d\n",s,t);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("xmasdag.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
