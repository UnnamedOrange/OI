#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
const int maxm=maxn*300;
int n, q, t;
int c[maxn], id[maxn];
vector<int> g[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int st[maxn], ed[maxn], dfn, fa[maxn];
void dfs(int x){
	st[x]=++dfn; id[dfn]=x;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa[x]) continue;
		fa[v]=x; dfs(v);
	}
	ed[x]=dfn;
}

int lstans, cnt[maxn];
int main(){
	freopen("xmastree1.in","r",stdin),freopen("xmastree1.ans","w",stdout);

	read(n), read(q), read(t);
	for(int i=1;i<=n;i++) read(c[i]);
	int u, v, l, r, x;
	for(int i=1;i<n;i++){
		read(u), read(v);
		g[u].push_back(v), g[v].push_back(u);
	}
	dfs(1);
	int op;
	while(q--){
		read(op);
		if(op==1){
			read(u), read(l), read(r);
			if(t) u^=lstans, l^=lstans, r^=lstans;
			for(int i=st[u];i<=ed[u];i++){
				cnt[c[id[i]]]++;
			}
			lstans=0;
			for(int i=l;i<=r;i++) if(cnt[i]) lstans++;
			printf("%d\n", lstans);
			for(int i=st[u];i<=ed[u];i++) cnt[c[id[i]]]--;
		}else{
			read(u), read(x);
			if(t) u^=lstans, x^=lstans;
			// c[u]=x;
		}
	}
	return 0;
}
