#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e6+10;
const int maxm=1e6+10;
int to[maxm],nex[maxm],beg[maxn],vis[maxn],low[maxn],dfn[maxn],stack[maxn],ins[maxn];
int scc[maxn],size[maxn],deg[maxn],q[maxn],dp[maxn];
int dfs_clock,scc_cnt,e,top;
struct Edge{
	int x,y;
};
struct Edge G[maxm];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void add(int x,int y){
	to[++e]=y;
	nex[e]=beg[x];
	beg[x]=e;
}
void tarjan(int x){
	int i;
	low[x]=dfn[x]=++dfs_clock;
	stack[++top]=x;ins[x]=1;vis[x]=1;
	for(i=beg[x];i;i=nex[i]){
		if(!vis[to[i]]){
			tarjan(to[i]);
			low[x]=min(low[x],low[to[i]]);
		}
		else if(ins[to[i]])low[x]=min(low[x],dfn[to[i]]);
	}
	if(low[x]==dfn[x]){
		scc[x]=++scc_cnt;
		size[scc_cnt]=1;
		ins[x]=0;
		while(stack[top]!=x){
			scc[stack[top]]=scc_cnt;
			size[scc_cnt]++;
			ins[stack[top]]=0;
			top--;
		}
		top--;
	}
}
int main(){
	int i,m,n;
#ifndef ONLINE_JUDGE
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
#endif
	n=read();m=read();
	for(i=1;i<=m;i++){
		int x,y;
		x=read();y=read();
		G[i].x=x;G[i].y=y;
		add(x,y);
	}
	for(i=1;i<=n;i++)
		if(!vis[i])
			tarjan(i);
	e=0;
	memset(beg,0,sizeof(beg));
	for(i=1;i<=m;i++)
		if(scc[G[i].x]!=scc[G[i].y]){
			add(scc[G[i].x],scc[G[i].y]);
			deg[scc[G[i].y]]++;
		}
	int f=0,l=0;
	for(i=1;i<=scc_cnt;i++)if(deg[i]==0)q[++l]=i,dp[i]=size[i];
	int maxans=0;
	while(f<l){
		f++;
		int x=q[f];
		for(i=beg[x];i;i=nex[i]){
			dp[to[i]]=max(dp[to[i]],dp[x]+size[to[i]]);
			deg[to[i]]--;
			if(!deg[to[i]])q[++l]=to[i];
		}
		maxans=max(maxans,dp[x]);
	}
	printf("%d\n",maxans);
	return 0;
}
