#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define N 1010
using namespace std;
//���ݷ�Χ��������������
typedef long long LL; 
int T,n,p,q;
LL x[N],W,y[N],z[N],a[N],b[N],c[N],d[N],e[N],f[N];
LL p1[N],p2[N],w[N],val[N];
LL ans=1e15;
void cal()
{
	LL tp=0;
	for(int i=1;i<=p;i++)
	{
		tp+=a[i]*abs(val[x[i]]-val[y[i]])+b[i]*abs(val[y[i]]-val[z[i]])+c[i]*abs(val[z[i]]-val[x[i]]);
		tp+=d[i]*(val[x[i]]-val[y[i]])+e[i]*(val[y[i]]-val[z[i]])+f[i]*(val[z[i]]-val[x[i]]);
	}
	for(int i=1;i<=n;i++)tp+=val[i];
	ans=min(ans,tp);
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d%lld%d%d",&n,&W,&p,&q);
		ans=1e15;
		for(int i=1;i<=p;i++)
		scanf("%lld%lld%lld%lld%lld%lld%lld%lld%lld",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for(int i=1;i<=q;i++)
		scanf("%lld%lld%lld",&p1[i],&p2[i],&w[i]);
		for(int i=0;i<(1<<n);i++)
		{
			for(int j=0;j<n;j++)
			if((i>>j)&1)val[j+1]=W;
			else val[j+1]=-W;
			bool flag=1;
			for(int j=1;j<=q;j++)
			{
				if(w[j]==0)
				{
					if(val[p1[j]]>val[p2[j]])flag=0;
				}
				else if(w[j]==1)
				{
					if(val[p1[j]]!=val[p2[j]])flag=0;
				}
				else if(val[p1[j]]>=val[p2[j]])flag=0;
				if(!flag)break;
			}
			if(!flag)continue;
			cal();
		}
		printf("%lld\n",ans);
	}
	return 0;
}