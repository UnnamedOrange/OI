#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=100100,mod=998244353;

int last[N],ecnt;
struct EDGE{int fr,to,nt;}e[N<<1];
inline void add(int u,int v)
{e[++ecnt]=(EDGE){u,v,last[u]};last[u]=ecnt;}

int n,m,K;

int C[505][505];
int f[N][505];

void initial()
{
	register int i,j;
	C[0][0]=1;
	for(i=1;i<=K;++i)
	{
		C[i][0]=1;
		for(j=1;j<=K;++j)
			C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
	}
}

inline void get(int u,int v)
{
	for(int i=0;i<=K;++i)
		for(int j=0;j<=i;++j)
			(f[v][i]+=(1ll*f[u][j]*C[i][j]%mod))%=mod;
}

bool book[N];
int ind[N],q[N];

void topo()
{
	register int i,u,v,head(0),tail(1);
	q[0]=1;f[1][0]=1;
	while(head<tail)
	{
		u=q[head++];
		for(i=last[u];i;i=e[i].nt)
		{
			ind[v=e[i].to]--;
			if(!ind[v]) q[tail++]=v;
			if(book[v]) continue;
			get(u,v);
		}
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	
	n=read();m=read();K=read();
	register int i,u,v;
	while(m--)
	{
		u=read();v=read();
		add(u,v);ind[v]++;
	}
	initial();
	topo();
	for(i=1;i<=n;++i) print(f[i][K]),putchar('\n');
	return 0;
}
/*
6 8 2
1 2
1 3
1 5
2 4
3 2
3 4
3 6
4 6

0
5
1
17
1
38
*/ 


/*

use f[N][K]
to get the sum of l^k
with erxiangshi ditui

*/
