#include <bits/stdc++.h>

namespace {

const int MAXN = 1000000 + 9;
const int MOD = 1000000007;

inline int add(const int x, const int v) {
    return x + v >= MOD ? x + v - MOD : x + v;
}

int n, c[MAXN], d[MAXN], f[MAXN], g[MAXN];
int a[4 * MAXN + 1][2], M;

inline bool check(int s, int t, int len) {
    register int max = INT_MIN, min = INT_MAX;
    for (s = s + M - 1, t = t + M + 1; s ^ t ^ 1; s >>= 1, t >>= 1) {
        if (~s & 1) {
            max = std::max(max, a[s ^ 1][0]);
            min = std::min(min, a[s ^ 1][1]);
        }
        if (t & 1) {
            max = std::max(max, a[t ^ 1][0]);
            min = std::min(min, a[t ^ 1][1]);
        }
    }
    return max <= len && min >= len;
}

inline int query(int s, int t) {
    register int max = INT_MIN;
    for (s = s + M - 1, t = t + M + 1; s ^ t ^ 1; s >>= 1, t >>= 1) {
        if (~s & 1) max = std::max(max, a[s ^ 1][0]);
        if (t & 1) max = std::max(max, a[t ^ 1][0]);
    }
    return max;
}

inline void solve() {
    std::cin >> n;
    for (register int i = 1; i <= n; i++) std::cin >> c[i] >> d[i];
    for (M = 1; M < n + 2;) M <<= 1;
    for (register int i = 0; i < M + M; i++) {
        a[i][0] = INT_MIN;
        a[i][1] = INT_MAX;
    }
    for (register int i = 1; i <= n; i++) {
        a[i + M][0] = c[i];
        a[i + M][1] = d[i];
    }
    for (register int i = M - 1; i; i--) {
        a[i][0] = std::max(a[i << 1][0], a[i << 1 | 1][0]);
        a[i][1] = std::min(a[i << 1][1], a[i << 1 | 1][1]);
    }
    for (register int i = 1; i <= n; i++) {
        for (register int j = 0; j < i; j++) {
            if (check(j + 1, i, i - j)) {
                if (f[i] < f[j] + 1) {
                    f[i] = f[j] + 1;
                    g[i] = g[j];
                } else {
                    g[i] = add(g[i], g[j] + 1);
                }
            }
        }
    }
    if (!f[n]) {
        std::cout << "-1";
    } else {
        std::cout << f[n] << ' ' << g[n];
    }
}
}  // namespace

int main() {
    freopen("schooldays.in", "r", stdin);
    freopen("schooldays.out", "w", stdout);
    solve();
    return 0;
}