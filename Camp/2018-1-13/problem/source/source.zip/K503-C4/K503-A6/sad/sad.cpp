#include<cstdio>
#include<cstring>
using namespace std;
#define N 100005
#define LL long long
#define mod 998244353
#define rep(i,j,k) for(i=j;i<=k;++i)
struct E{
	int to,nxt;
}ed[N<<1];
int n,m,i,j,k,top,u,v;
int head[N],E[N];
char s[N];
void read(int &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
	return p;
}
void add(int u,int v){
	top++; ed[top].to=v; ed[top].nxt=head[u]; head[u]=top;
}
LL quick_mi(LL a,int b){
	LL sum=1;
	for(;b;b>>=1){
		if(b&1) sum=(sum*a)%mod;
		a=(a*a)%mod;
	}
	return sum;
}
void getdp(int x,int fa){
	int inv,i,son=0;
	for(i=head[x];i;i=ed[i].nxt)
	if(ed[i].to!=fa){
		son++;
		getdp(ed[i].to,x);
		
	}
	if(!son) E[x]=1;
}
void init(){
	read(n);
	scanf("%s",s);
	rep(i,1,n-1){
		read(u); read(v);
		add(u,v); add(v,u);
	}
	getdp(1,0);
	printf("%d\n",E[1]);
}
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	return 0;
}
