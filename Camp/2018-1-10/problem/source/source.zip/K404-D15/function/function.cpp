#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 1000005
typedef long long ll;

int n,cnt;
int prime[maxn],d[maxn];
ll f[maxn];
bool vis[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	f[1]=1;
	for (int i=2;i<=1000000;i++){
		if (!vis[i]) prime[++cnt]=i,f[i]=3,d[i]=i;
		for (int j=1;j<=cnt&&i*prime[j]<=1000000;j++){
			vis[i*prime[j]]=1;
			if (i%prime[j]==0){
				d[i*prime[j]]=d[i]*prime[j];
				f[i*prime[j]]=f[i/d[i]]*(f[d[i]]+2);
				break;
			}
			d[i*prime[j]]=prime[j];
			f[i*prime[j]]=f[i]*3;
		}
	}
	for (int i=2;i<=1000000;i++) f[i]+=f[i-1];
	for (int T=read();T;T--) printf("%lld\n",f[read()]);
	return 0;
}
