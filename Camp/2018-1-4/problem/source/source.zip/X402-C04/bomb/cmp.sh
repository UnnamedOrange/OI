while true
do
	./gen
	./bomb
	./bombs
	if diff bomb.out bombs.out
	then
		printf "#"
	else
		printf "Wa"
		exit 0
	fi
done
