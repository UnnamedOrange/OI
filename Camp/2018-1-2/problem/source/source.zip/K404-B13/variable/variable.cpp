#include<bits/stdc++.h>
using namespace std;
int times[55],he[50][55],a[55];
int n,W,p,q;
void intalize(){
	memset(times,0,sizeof(times));
	memset(he,0,sizeof(he));
	memset(a,0,sizeof(a));
}
long long powe(int v){
	int x=1;
	while(v--)	x=x<<1;
	return x;
}
vector<int> G[40],P[40],U[40];
void readit(){
	intalize();
	cin>>n>>W>>p>>q;
	int x,y,z,a,b,c,d,e,f;
	while(p--){
		scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&e,&f);
		he[x][y]+=a;he[y][z]+=b;he[z][x]+=c;
		times[x]+=d-f;times[y]+=e-d;times[z]+=f-e;
	}
	int r;
	while(q--){
		scanf("%d%d%d",&a,&b,&r);
		if(r==0) G[a].push_back(b);
		else if(r==1) P[a].push_back(b);
		else if(r==2) U[a].push_back(b);
	}
	
}
void output(int p){
	for(int j=1;j<=n;j++){
		if(p&1) a[j]=1;		else a[j]=-1;
			p>>=1;
	}
}
bool is_ok(){
	for(int i=1;i<=n;i++){
		for(int j=G[i].size()-1;j>=0;j--){
			int e=G[i][j];
			if(a[i]>a[e]) return false;
		}
		for(int j=P[i].size()-1;j>=0;j--){
			int e=P[i][j];
			if(a[i]!=a[e]) return false;
		}
		for(int j=U[i].size()-1;j>=0;j--){
			int e=U[i][j];
			if(a[i]>=a[e]) return false;
		}
	}
	return true;
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int t;cin>>t;
	int ans=10000000;
	while(t--){
		readit();
		int mi=powe(n);
		for(int i=0;i<mi;i++){
			output(i);
			if(!is_ok()) continue;
			//for(int i=1;i<=n;i++)	printf("%d ",a[i]);	printf("\n");
			int sum=0;
			for(int i=1;i<=n;i++){
				sum+=(times[i]+1)*a[i];
				for(int j=1;j<=n;j++){
					sum+=he[i][j]*(a[i]-a[j]<0?a[j]-a[i]:a[i]-a[j]);
				}
			}
			ans=min(ans,sum);	
		}
		printf("%d\n",ans*W);
	}
	return 0;
}
