#include <bits/stdc++.h>
using namespace std;

int n, m;

namespace bf {

const int Max = 1111;

int l[Max], r[Max], x[Max];

void main() {
	for (int i = 0; i < n; ++i) {
		cin >> l[i] >> r[i];
	}
	for (int i = 0; i < m; ++i) {
		cin >> x[i];
	}
	int ans = 0;
	for (int S = 0; S < 1<<n; ++S) {
		bool ok = true;
		for (int i = 0; i < m; ++i) {
			bool covered = false;
			for (int j = 0; j < n; ++j) {
				if (S>>j&1 && l[j] <= x[i] && x[i] <= r[j]) {
					covered = true;
					break;
				}
			}
			if (!covered) {
				ok = false;
				break;
			}
		}
		ans += ok;
	}
	printf("%d\n", ans);
}

} // namespace bf

namespace dp {

const int Max = 555555, Mod = 1000000009;
struct Node {
	int l, r;
} a[Max];
inline bool cmp(const Node &i, const Node &j) {
	return (i.r < j.r);
}

int x[Max], dp[Max], pre[Max];

void main() {
	for (int i = 1; i <= n; ++i) {
		scanf("%d%d", &a[i].l, &a[i].r);
	}
	a[++n] = {0, 0};
	sort(a+1, a+n+1, cmp);
	for (int i = 1; i <= m; ++i) {
		scanf("%d", &x[i]);
	}
	sort(x+1, x+m+1);
	dp[1] = pre[1] = 1;
	for (int i = 2, p; i <= n; ++i) {
		p = lower_bound(x+1, x+m+1, a[i].l) - x - 1;
		int left = 0, right = n;
		while (right-left > 1) {
			int mid = (left+right)/2;
			if (a[mid].r >= x[p]) {
				right = mid;
			} else {
				left = mid;
			}
		}
		dp[i] = ((pre[i-1]-pre[right-1])%Mod+Mod)%Mod;
		pre[i] = (pre[i-1]+dp[i])%Mod;
	}
	int ans = 0;
	for (int i = 1; i <= n; ++i) {
		if (a[i].r >= x[m]) {
			ans = (ans+dp[i])%Mod;
		}
	}
	printf("%d\n", ans);
}

} // namespace dp

int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	scanf("%d%d", &n, &m);
	if (n <= 20) {
		bf::main();
	} else {
		dp::main();
	}
	return 0;
}
