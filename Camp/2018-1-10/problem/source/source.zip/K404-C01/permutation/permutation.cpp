//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
typedef long long LL;
using namespace std;
int ans,n,lim[10],a[10],vis[10],ok[10];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

void dfs(int x) {
	if(x==n+1) {
		memset(ok,0,sizeof(ok));
		int cnt;
		for(int i=1;i<=n;i++) if(!ok[i]) {
			cnt=1;
			for(int j=a[i];j!=i;j=a[j]) {
				ok[j]=1; cnt++;
			}
			if(cnt&1) return;
		}
		ans++;
		return;
	}
	if(lim[x]) dfs(x+1);
	else for(int i=1;i<=n;i++) {
		if(!vis[i]) {
			a[x]=i;
			vis[i]=1;
			dfs(x+1);
			vis[i]=0;
		}
	} 
	return;
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
#endif
	read(n);
	for(int i=1;i<=n;i++) {
		read(lim[i]);
		if(lim[i]) {
			a[i]=lim[i];
			vis[lim[i]]=1;
		}
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
