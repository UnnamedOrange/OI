#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxm=5e3+10,mod=998244353;
int n,m,k,powk[maxm];
ll dp[maxm][maxm],dpp[maxm][maxm],ans;

inline ll qpow(ll a,ll n){
	ll res=1;
	while(n){
		if(n&1ll)
			res=res*a%mod;
		a=a*a%mod;
		n>>=1;
	}
	return res;
}

int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&m,&n,&k);
	for(int i=0;i<=m;++i)
		powk[i]=qpow(i,k);
	dp[1][1]=1;
	for(int i=1;i<=n;++i)for(int j=m+1;j;--j)for(int k=j;k;--k){
		dp[j][k]=(dp[j][k]+dp[j][k-1]+dp[j-1][k]+dp[j-1][k-1])%mod;
		dpp[j][k]=(dpp[j][k]+dpp[j][k-1]+dpp[j-1][k]+dpp[j-1][k-1]+dp[j][k]*powk[j-k])%mod;
	}
	printf("%lld\n",dpp[m+1][m+1]);
	return 0;
}
