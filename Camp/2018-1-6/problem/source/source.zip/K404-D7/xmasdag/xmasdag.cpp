#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
const int mod = 998244353;
int delt[505];
int C[505][505];
int n, m, k;
vector<int>q[100005];
int ru[100005];
int f[100005][505];
int temp[505];
int dp[2005][2005];
int ma[2005];
int mi[2005];
int ans[2005];
inline int ksm(int x, int y) {
	int ret = 1;
	while(y) {
		if(y & 1) ret = (long long)ret * x % mod;
		x = (long long) x * x % mod;
		y >>= 1;
	}
	return ret;
}
queue<int> que;
int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	R(n), R(m), R(k);
	memset(delt, -1, sizeof(delt));
	delt[1] = 1;
	for(int i = 0; i <= k; ++i) {
		C[i][i] = C[i][0] = 1;
		for(int j = 1; j < i; ++j) {
			C[i][j] = C[i - 1][j] + C[i - 1][j - 1];
			(C[i][j] >= mod) ? (C[i][j] -= mod) : (0);
		}
	}
	int x, y;
	for(int i = 1; i <= m; ++i) {
		R(x), R(y);
		q[x].push_back(y);
		++ru[y];
	}
	for(int i = 1; i <= n; ++i) {
		if(!ru[i]) que.push(i);
	}
	int v;
	if(k <= 30) {
		f[1][0] = 1;
		while(!que.empty()) {
			x = que.front();
			que.pop();
			for(int j = k; j >= 0; --j) {
				temp[j] = f[x][j];
				for(int o = j - 1; o >= 0; --o) {
					temp[j] = ((long long)temp[j] + (long long)C[j][o] * f[x][o]) % mod;
				}
			}
			for(int i = 0; i < q[x].size(); ++i) {
				v = q[x][i];
				for(int j = k; j >= 0; --j) {
					f[v][j] += temp[j];
					(f[v][j] >= mod) ? (f[v][j] -= mod) : (0);
				}
				--ru[v];
				if(!ru[v]) que.push(v);
			}
		}
		for(int i = 1; i <= n; ++i) {
			printf("%d\n", f[i][k]);
		}
		return 0;
	} else {
		dp[1][0] = 1;
		while(!que.empty()) {
			x = que.front();
			que.pop();
			for(int i = 0; i < q[x].size(); ++i) {
				v = q[x][i];
				for(int j = 0; j <= ma[x]; ++j) {
					dp[v][j + 1] += dp[x][j];
					(dp[v][j + 1] >= mod) ? (dp[v][j + 1] -= mod) : (0);
					ma[v] = max(ma[v], ma[x] + 1);  
				}
				--ru[v];
				if(!ru[v]) que.push(v);
			}
		}
		for(int i = 0; i <= n; ++i) {
			mi[i] = ksm(i, k);
		}
		for(int i = 1; i <= n; ++i) {
			for(int j = 1; j <= ma[i]; ++j) {
				ans[i] = ((long long) ans[i] + (long long)mi[j] * dp[i][j]) % mod;
			}
			printf("%d\n", ans[i]);
		}
	}
	return 0;
}
