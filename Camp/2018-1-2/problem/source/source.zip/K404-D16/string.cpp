#include <cstdio>
#include <queue>
#include <algorithm>
#include <map>
#define F(x,y,z) for (x=y;x<=z;++x)
using namespace std;
int len,ll;
char s[1000100];

bool hh(){
	int l=1,r=len;
	while (l<=r)
	{
		if (s[l]!=s[r])return 0;
		++l;--r;
	}
	return 1;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int x,y,z,i,j,k,T,an;
	scanf("%d",&T);
	while (T--)
	{
		F(i,0,len+1) s[i]='\0';
		bool flag=1;
		++ll;
		scanf("%d",&len);
		if (len==0){printf("0\n");continue;}
		scanf("%s",s+1);
		s[0]='~';s[len+1]='`';
	//	printf("%s\n",s);
		if (len%2==0)
		{
			F(i,2,len) 
				if (s[i]!=s[i-1]) flag=0;
			if (flag){printf("-1\n");continue;}
			if (hh())printf("2\n");
				else printf("1\n");
		}
		else
		{			
			F(i,2,len/2) 
				if (s[i]!=s[i-1]) flag=0;
			F(i,len/2+3,len)
				if (s[i]!=s[i-1]) flag=0;
			if (s[1]!=s[len]) flag=0;
			if (flag){printf("-1\n");continue;}
			
			flag=1;
			for (i=3;i<=len;i+=2)
				if (s[i]!=s[i-2]) flag=0;
			for (i=4;i<=len;i+=2)
				if (s[i]!=s[i-2]) flag=0;
			if (flag){printf("-1\n");continue;}
			if (hh())printf("2\n");
				else printf("1\n");
		}
	}
	return 0;
}
