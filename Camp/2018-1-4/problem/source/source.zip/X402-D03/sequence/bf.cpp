#include<bits/stdc++.h>
using namespace std;

const int MAXN = 25;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, x[MAXN], ans;

bool dfs(int res) {
	int i, j, val = 0;
	if(res == ans) {
		for(i = 1; i < n; i++) 
			if(x[i+1] < x[i]) return false;
		return true;
	}
	for(i = 2; i <= n; i++) {
		for(j = 1; j <= (i>>1); j++) swap(x[j], x[i-j+1]);
		if(dfs(res+1)) return true;
		for(j = 1; j <= (i>>1); j++) swap(x[j], x[i-j+1]);
	}
	return false;
}

int main() {
	freopen("sequence.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int T = read(), i;
	while(T--) {
		n = read();
		for(i = 1; i <= n; i++) x[i] = read();

		for(ans = 0; !dfs(0); ans++);
		printf("%d\n", ans);
	}
	//cerr << clock() << endl;
	return 0;
}
