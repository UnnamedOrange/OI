#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

int main()
{
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);

	//f@ck you!

	return 0;
}

