#include <bits/stdc++.h>

using namespace std;

const int ha = 19260817;

ifstream fin;
ofstream fout;
int n;
int a[33], q[1111111][24], f[1111111];
bool h[ha];

inline int gethash(int a[])
{
	int tmp = 0;
	for (int i = 1; i <= n; i++)
	{
		tmp = (tmp * n + a[i]) % ha;
	}
	return tmp;
}

int main()
{
	ios::sync_with_stdio(false);
	fin.open("sequence.in");
	fout.open("sequence.out");

	int T;
	fin >> T;
	while (T--)
	{
		fin >> n;
		for (int i = 1; i <= n; i++)
		{
			fin >> a[i];
		}
		memset(h, false, sizeof(h));
		h[gethash(a)] = true;
		int head = 1, tail = 1;
		f[1] = 0;
		for (int i = 1; i <= n; i++)
		{
			q[1][i] = a[i];
		}
		int Final = 0;
		for (int i = 1; i <= n; i++)
		{
			Final = (Final * n + i) % ha;
		}
		bool flag = false;
		while (head <= tail)
		{
			int tmp[25];
			for (int i = 1; i <= n; i++)
			{
				tmp[i] = q[head][i];
			}
			for (int i = 2; i <= n; i++)
			{
                for (int j = 1; j <= i / 2; j++)
				{
					swap(tmp[j], tmp[i - j + 1]);
				}
				int tt = gethash(tmp);
				if (tt == Final)
				{
					flag = true;
					fout << f[head] + 1 << endl;/*
for (int j = 1; j <= n; j++)
{
	cout << tmp[j] << " ";
}
cout << endl;
int cur = head;
while (cur != 0)
{
for (int j = 1; j <= n; j++)
{
	cout << q[cur][j] << " ";
}
cout << endl;
	cur = f[cur];
}*/
					break;
				}
				if (h[tt] == false)
				{
					tail++;
					h[tt] = true;
					for (int j = 1; j <= n; j++)
					{
						q[tail][j] = tmp[j];
					}
					f[tail] = f[head] + 1;
				}
                for (int j = 1; j <= i / 2; j++)
				{
					swap(tmp[j], tmp[i - j + 1]);
				}
			}
			if (flag)
			{
				break;
			}
			head++;
		}
	}

	fin.close();
	fout.close();
	return 0;
}
