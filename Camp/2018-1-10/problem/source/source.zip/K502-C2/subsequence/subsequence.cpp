#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

const int M = 4005;

int n, m, k, A[M], B[M];

namespace Subtask1 {
	
	int C[M];
	
	bool check(int l) {
		int p = 1;
		for (int i = 1; i <= n; i++)
			if (p <= l && C[p] == A[i]) p++;
		if (p > l) return false;
		p = 1;
		for (int i = 1; i <= m; i++)
			if (p <= l && C[p] == B[i]) p++;
		return p <= l;
	}
	
	void solve() {
		for (int len = 1; len <= max(n, m) + 1; len++) {
			bool flag = false;
			for (int i = 0; i < (1 << len); i++) {
				int x = i;
				for (int j = 1; j <= len; j++) {
					C[j] = (x & 1) + 1;
					x >>= 1;
				}
				if (check(len)) {
					flag = true;
					break;
				}
			}
			if (flag) {
				printf("%d\n", len);
				break;
			}
		}
	}
	
}

void Check(int &a, int b) {
	if (a == -1 || b < a) a = b;
}

int dp[M][M], nxtA[M][M], nxtB[M][M];

namespace Subtask2 {
	
	void solve() {
		for (int i = 0; i <= n + 1; i++) {
			for (int j = 1; j <= k; j++) {
				nxtA[i][j] = n + 1;
				for (int t = i + 1; t <= n; t++)
					if (A[t] == j) {nxtA[i][j] = t; break;}
			}
		}
		for (int i = 0; i <= m + 1; i++) {
			for (int j = 1; j <= k; j++) {
				nxtB[i][j] = m + 1;
				for (int t = i + 1; t <= m; t++)
					if (B[t] == j) {nxtB[i][j] = t; break;}
			}
		}
		memset(dp, -1, sizeof(dp));
		dp[0][0] = 0;
		for (int i = 0; i <= n + 1; i++) {
			for (int j = 0; j <= m + 1; j++) {
				if (dp[i][j] == -1) continue;
				for (int t = 1; t <= k; t++)
					Check(dp[nxtA[i][t]][nxtB[j][t]], dp[i][j] + 1);
			}
		}
		printf("%d\n", dp[n + 1][m + 1]);
	}
	
}

/*namespace Subtask3 {
	
	const int M = 4005;
	
	void solve() {
		for (int i = 1; i <= n + 1; i++) {
			if (i <= n) {
				nxtA[i][A[i]] = 0;
				for (int t = i - 1; t >= 1; t--)
					if (A[t] == A[i]) {nxtA[i][A[i]] = t; break;}
			} else {
				for (int j = 1; j <= k; j++) {
					nxtA[i][j] = 0;
					for (int t = i - 1; t >= 1; t--)
						if (A[t] == j) {nxtA[i][j] = t; break;}
				}
			}
		}
		for (int i = 1; i <= m + 1; i++) {
			if (i <= m) {
				nxtB[i][B[i]] = 0;
				for (int t = i - 1; t >= 1; t--)
					if (B[t] == B[i]) {nxtB[i][B[i]] = t; break;}
			} else {
				for (int j = 1; j <= k; j++) {
					nxtB[i][j] = 0;
					for (int t = i - 1; t >= 1; t--)
						if (B[t] == j) {nxtB[i][j] = t; break;}
				}
			}
		}
		memset(dp, -1, sizeof(dp));
		dp[0][0] = 0;
		for (int i = 0; i <= n + 1; i++) {
			for (int j = 0; j <= m + 1; j++) {
				if (i > n && j > m) {
					for (int t = 1; t <= k; t++)
						if (~dp[nxtA[i][t]][nxtB[j][t]]) Check(dp[i][j], dp[nxtA[i][t]][nxtB[j][t]] + 1);
				} else if (i > n) {
					for (int t = 1; t <= k; t++)
						if (~dp[nxtA[i][t]][nxtB[j][B[j]]]) Check(dp[i][j], dp[nxtA[i][t]][nxtB[j][B[j]]] + 1);
				} else if (j > m) {
					for (int t = 1; t <= k; t++)
						if (~dp[nxtA[i][A[i]]][nxtB[j][t]]) Check(dp[i][j], dp[nxtA[i][A[i]]][nxtB[j][t]] + 1);
				} else if (~dp[nxtA[i][A[i]]][nxtB[j][B[j]]]) Check(dp[i][j], dp[nxtA[i][A[i]]][nxtB[j][B[j]]] + 1);
				if (~dp[i - 1][j]) Check(dp[i][j], dp[i - 1][j] + 1);
				if (~dp[i][j - 1]) Check(dp[i][j], dp[i][j - 1] + 1);
				if (~dp[i - 1][j - 1]) Check(dp[i][j], dp[i - 1][j - 1] + 1);
			}
		}
		printf("%d\n", dp[n + 1][m + 1]);
	}
	
}*/

int main() {
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	scanf("%d %d %d", &n, &m, &k);
	for (int i = 1; i <= n; i++) scanf("%d", &A[i]);
	for (int i = 1; i <= m; i++) scanf("%d", &B[i]);
	if (n <= 18 && m <= 18 && k == 2) Subtask1::solve();
	else Subtask2::solve();
	return 0;
}
