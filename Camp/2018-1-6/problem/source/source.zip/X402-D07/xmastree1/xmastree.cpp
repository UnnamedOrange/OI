#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=100010;
int n,q,t,c[maxn],lstans;
int head[maxn],nxt[maxn<<1],to[maxn<<1],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}
namespace SGT{
#define ls h<<1
#define rs h<<1|1
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r
    struct node{
        int Ls,Rs,sum;
    } T[40000000];
    int rt[maxn*3],cur;
    void pushup(int h,int l,int r){
        T[h].sum=0;
        if(l==mid) T[h].sum+=(T[T[h].Ls].sum>0);
        else T[h].sum+=T[T[h].Ls].sum;
        if(mid+1==r) T[h].sum+=(T[T[h].Rs].sum>0);
        else T[h].sum+=T[T[h].Rs].sum;
    }
    void updy(int& h,int l,int r,int p,bool op){
        if(!h) h=++cur;
        if(l==r){
            if(op) ++T[h].sum;
            else --T[h].sum;
            return;
        }
        if(p<=mid) updy(T[h].Ls,lc,p,op);
        if(p>mid) updy(T[h].Rs,rc,p,op);
        pushup(h,l,r);
    }
    void update(int h,int l,int r,int L,int R,int p,bool op){
        if(L<=l&&r<=R) return void(updy(rt[h],1,n,p,op));
        if(L<=mid) update(ls,lc,L,R,p,op);
        if(R>mid) update(rs,rc,L,R,p,op);
    }
    int qryy(int& h,int l,int r,int L,int R){
        if(L<=l&&r<=R) return l==r?T[h].sum>0:T[h].sum;
        int res=0;
        if(L<=mid) res+=qryy(T[h].Ls,lc,L,R);
        if(R>mid) res+=qryy(T[h].Rs,rc,L,R);
        return res;
    }
    void merge(int& h1,int h2,int l,int r){
        if(!h1) return void(h1=h2);
        if(!h2) return;
        if(l==r) return void(T[h1].sum+=T[h2].sum);
        merge(T[h1].Ls,T[h2].Ls,lc);
        merge(T[h1].Rs,T[h2].Rs,rc);
        pushup(h1,l,r);
    }
    int query(int h,int l,int r,int p,int L,int R){
        if(l==r) return qryy(rt[h],1,n,L,R);
        merge(rt[ls],rt[h],1,n);
        merge(rt[rs],rt[h],1,n);
        rt[h]=0;
        if(p<=mid) return query(ls,lc,p,L,R);
        else return query(rs,rc,p,L,R);
    }
}
using namespace SGT;
namespace HLD{
    int dfn[maxn],cur,top[maxn],sz[maxn],son[maxn],fa[maxn],dep[maxn];
    void dfs1(int u){
        sz[u]=1; son[u]=0;
        for(int i=head[u];i;i=nxt[i]){
            int v=to[i];
            if(v!=fa[u]){
                fa[v]=u; dep[v]=dep[u]+1;
                dfs1(v); if(sz[v]>sz[son[u]]) son[u]=v;
                sz[u]+=sz[v];
           }
        }
    }
    void dfs2(int u,int g){
        dfn[u]=++cur; top[u]=g;
        if(son[u]) dfs2(son[u],g);
        for(int i=head[u];i;i=nxt[i]){
            int v=to[i];
            if(v!=fa[u]&&v!=son[u]) dfs2(v,v);
        }
    }
    void change(int h,int w,bool op){
        int u=h;
        while(u){
            if(op) update(1,1,n,dfn[top[u]],dfn[u],c[h],0);
            update(1,1,n,dfn[top[u]],dfn[u],w,1);
            u=fa[top[u]];
        }
        c[h]=w;
    }
}
using namespace HLD;
int main(){
    freopen("xmastree1.in","r",stdin);
    freopen("xmastree1.out","w",stdout);
    read(n); read(q); read(t);
    for(int i=1;i<=n;i++) read(c[i]);
    for(int i=1;i<n;i++){
        int u,v;
        read(u); read(v);
        ae(u,v); ae(v,u);
    }
    dfs1(1); dfs2(1,1);
    for(int i=1;i<=n;i++) change(i,c[i],0);
    while(q--){
        int op; read(op);
        if(op==1){
            int u,l,r;
            read(u); read(l); read(r);
            if(t==1) u^=lstans,l^=lstans,r^=lstans;
            printf("%d\n",lstans=query(1,1,n,dfn[u],l,r));
        }
        if(op==2){
            int u,w;
            read(u); read(w);
            if(t==1) u^=lstans,w^=lstans;
            change(u,w,1);
        }
    }
    return 0;
}
