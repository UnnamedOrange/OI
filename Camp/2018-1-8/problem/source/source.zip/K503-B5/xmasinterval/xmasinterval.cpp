#include<bits/stdc++.h>
using namespace std;
const int p=1e9+7;
pair<int,int> a[1000000];
int x[1000000],f[1000000],sum[1000000];
inline bool cmp(pair<int,int> a,pair<int,int> b){
	return make_pair(a.second,a.first)<make_pair(b.second,b.first);
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
		scanf("%d%d",&a[i].first,&a[i].second);
	sort(a+1,a+n+1);
	for (int i=1;i<=m;i++)
		scanf("%d",x+i);
	sort(x+1,x+m+1);
	f[0]=sum[0]=1;
	for (int i=1;i<=n;i++){
		int t=lower_bound(x+1,x+m+1,a[i].first)-x-1,q=lower_bound(a+1,a+n+1,make_pair(0,x[t]),cmp)-a-1;
		f[i]=(sum[i-1]-sum[q]+p)%p;
		if (!t) f[i]++;
		sum[i]=(sum[i-1]+f[i])%p;
	}
	int t=1,ans=0;
	for (int i=n;i>=1;i--)
		if (a[i].second>=x[m]) ans=(ans+(long long)f[i]*t%p)%p;
		else t=(t<<1)%p;
	printf("%d\n",ans);
	return 0;
}
