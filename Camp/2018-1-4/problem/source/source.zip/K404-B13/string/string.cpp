#include<bits/stdc++.h>
using namespace std;
char a[30][100];
int x[100];int n,m;
#define e a[i]
int pow(int v){
	int x=1;
	while(v--) x*=2;
	return x;
}
void doit(int v){
	memset(x,0,sizeof(x));
	for(int i=1;i<=m;i++){
		x[i]=v&1; x[2*m-i+1]=x[i]^1;
		v>>=1;
	}
//	for(int i=1;i<=2*m;i++)
//	printf("%d",x[i]);
//	cout<<endl;
}
bool is_ok(){
	for(int i=1;i<=n;i++){
		int ok=0;
		for(int j=1;j<=2*m;j++){
			int k=0;
			for(;k<strlen(e);k++)	if(e[k]-'0'!=x[j+k]||j+k>2*m) break;
			if(k==strlen(e)) {ok=1;break;}
		}
		if(!ok) return false;
	}
	for(int i=1;i<=2*m;i++)
	printf("%d",x[i]);
	cout<<endl;
	return true;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){	scanf("%s",a[i]);	}
	int total=pow(m);
	int ans=0;
	for(int i=0;i<total;i++){
		doit(i);
		if(is_ok()) ans++;
	}
	printf("%d",ans);
	return 0;
}
