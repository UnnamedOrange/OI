#include<cstdio>
#include<iostream>
using namespace std;
int a[100010];
int b[100010];
int used[100010];
bool vis[100];
int n,ans;
const int mod=998244353;
void pan()
{
	for (int i=1;i<=n;i++) vis[i]=0;
	for (int i=1;i<=n;i++)
	{
		if (!vis[i])
		{
			vis[i]=1;
			int len=1,nw=b[i];
			while (nw!=i)
			{
				vis[nw]=1;
				nw=b[nw];
				len++;
			}
			if (len&1) return;
		}
	}
	ans++;
}
void dfs(int deep)
{
	if (deep==n+1) pan();
	if (a[deep]) dfs(deep+1);
	for (int i=1;i<=n;i++)
	{
		if (!used[i])
		{
			b[deep]=i;
			used[i]=1;
			dfs(deep+1);
			used[i]=0;
		}
	}
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	if (n<=8)
	{
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]),used[a[i]]=1,b[i]=a[i];
		dfs(1);
		printf("%d\n",ans);
	}
	else
	{
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		if (n&1) {printf("0\n");return 0;}
		ans=1;
		for (int i=1;i<=n/2;i++)
			ans=(1ll*ans*(2*i-1))%mod*1ll*(2*i-1)%mod;
		printf("%d\n",ans);
	}
}
