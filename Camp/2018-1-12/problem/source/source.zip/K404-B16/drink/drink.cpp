#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)
#define dep(i, s, t) for(i = s; i >= t; --i)
#define isd(a) (a >= '0' && a <= '9')

using namespace std;

const int N = 1000010;
const int MAXS = 128 * 1024 * 1024;
int n;
double ans;
double a[N], b[N];
char buf[MAXS], *p = buf;

int re() {
	int x = 0; char c = *p++;
	for(; !isd(c); c = *p++);
	for(; isd(c); c = *p++) x = (x<<3) + (x<<1) + c - '0';
	return x;
}

int main() {
	freopen("drink.in", "r", stdin); freopen("drink.out", "w", stdout);
	fread(buf, 1, MAXS, stdin);
	int i, j, n1, n2; double t1, t2;
	n = re();
	b[0] = 1.; rep(i, 1, n) b[i] = b[i-1] * 2.;
	rep(i, 1, n) a[i] = re();
	rep(i, 1, n) {
		t1 = 1.; n1 = 0;
		rep(j, i+1, n) {
			if(a[j] > a[i]) ++n1;
			t1 = t1 + 1. / b[n1];
			if(n1 > 40) break;
		}
		t2 = 1.; n2 = 0;
		dep(j, i-1, 1) {
			if(a[j] >= a[i]) ++n2;
			t2 = t2 + 1. / b[n2];
			if(n2 > 40) break;
		}
		ans += t1 * t2 * a[i] / 2.;
		//printf("%.6lf\n", t1 * t2 * a[i] / 2.);
	}
	printf("%.12lf\n", ans / n / n);
	return 0;
}
