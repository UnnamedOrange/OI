#include <bits/stdc++.h>

using namespace std;

int type, N;

int encode(int x, int y)
{
	for(int i = 0; i < 10; ++i) if(((x >> i) & 1) ^ ((y >> i) & 1)) return i + ((x >> i) & 1) * 10;
	return 0;
}

bool decode(int q, int h)
{
	if(((q >> (h % 10)) & 1) ^ (h / 10)) return 0;
	else return 1;
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1) printf("%d\n", encode(x, y));
        else puts(decode(x, y) ? "yes" : "no");
    }

	return 0;
}

