#include<vector>
#include<string>
#include<algorithm>
#include<cstdio>
#include<ctime>
#include<cmath>
#include<cstdlib>
#include<set>
#include<iostream>
#include<map>
#include<cstring>
#include<cassert>
#include<utility>
using namespace std;
namespace whatever{
	int readu(){
		char ch=getchar();
		while(ch<'0'||ch>'9')
			ch=getchar();
		int value=ch-'0';
		ch=getchar();
		while(ch>='0'&&ch<='9'){
			value=value*10+ch-'0';
			ch=getchar();
		}
		return value;
	}
	char readc(){
		char ch=getchar();
		while(ch==' '||ch=='\n')
			ch=getchar();
		return ch;
	}
	char str[110000];
	int len;
	bool is_same(){
		char first=str[0];
		for(int i=1;i<len;++i)
			if(str[i]!=first)
				return false;
		return true;
	}
	bool is_palindrome(){
		int i=0,j=len-1;
		for(;i!=len;++i,--j)
			if(str[i]!=str[j])
				return false;
		assert(j==-1);
		return true;
	}
	bool is_alternating(){
		char first=str[0];
		for(int i=2;i<len;i+=2)
			if(str[i]!=first)
				return false;
		char second=str[1];
		for(int i=3;i<len;i+=2)
			if(str[i]!=second)
				return false;
		return true;
	}
	bool is_standalone(){
		assert(len%2==1);
		char first=str[0];
		int i=0,j=len-1;
		for(;i!=j;++i,--j)
			if(str[i]!=first||str[j]!=first)
				return false;
		assert(i==len/2);
		assert(i==j);
		assert(str[i]!=first);//same
		return true;
	}
	void solve(){
		len=readu();
		for(int i=0;i<len;++i)
			str[i]=readc();
		str[len]=0;
		if(is_same()){
			printf("-1\n");
			return;
		}
		if(len==1){
			printf("-1\n");
			return;
		}
		if(len==2){
			if(str[0]==str[1])
				printf("-1\n");
			else
				printf("1\n");
			return;
		}
		if(len==3){
			if(str[0]==str[2])
				printf("-1\n");
			else
				printf("1\n");
			return;
		}
		if(!is_palindrome()){
			printf("1\n");
			return;
		}
		if(is_alternating()){
			if(len%2==0)
				printf("1\n");//shouldn't be here
			else
				printf("-1\n");
			return;
		}
		if(len%2==1&&is_standalone()){
			printf("-1\n");
			return;
		}
		printf("2\n");
	}
	void run(){
		freopen("string.in","r",stdin);
		freopen("string.out","w",stdout);
		int t=readu();
		while(--t!=-1)
			/*cout<<"afed"<<t<<endl,*/solve();
		fclose(stdin);
		fclose(stdout);
	}
}
int main(){
	whatever::run();
}
