#include<bits/stdc++.h>
#define mo 1000000007
using namespace std;
long long a[100010],pp,an1=0,an2=0;
int n,an,x,bn,sum1=0,sum2=0;
long long p(long long x,long long y){
	long long z=1;
	while (y){
		if (y % 2==1) z=(x*z)%mo;
		x=(x*x)%mo;
		y/=2;
	}
	return z;
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d %d %d",&n,&an,&bn);
	for (int i=1;i<=n;i++){
		scanf("%d",&x);
		if ((x/bn)%2==0)sum1++;else sum2++;
	}
	cout<<"0 0";
	a[0]=1;
	for (int i=1;i<=sum2;i++)a[i]=(((a[i-1]*(sum2-i+1))%mo)*p(i,mo-2))%mo;
	pp=p(2,sum1);
	for (int i=0;i<=sum2;i++){
		if (i % 2==0)an1=(an1+(a[i]*pp))%mo;else an2=(an2+(a[i]*pp)%mo)%mo;
	}
	cout<<' '<<an1<<' '<<an2<<endl;
	return 0;
}
