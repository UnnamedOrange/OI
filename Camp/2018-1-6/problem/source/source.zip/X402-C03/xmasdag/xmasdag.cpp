#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=2e3+10,maxm=5e3+10,mod=998244353;
int n,m,k,deg[maxn],x[maxn][maxn],kpow[maxn];
vector<int> g[maxn];

inline ll qpow(ll a,ll n){
	ll res=1;
	while(n){
		if(n&1ll)res=res*a%mod;
		a=a*a%mod;
		n>>=1;
	}
	return res;
}

int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;++i)
		kpow[i]=qpow(i,k);
	for(int i=1,u,v;i<=m;++i){
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		++deg[v];
	}
	x[1][0]=1;
	queue<int> q;
	q.push(1);
	while(!q.empty()){
		int pos=q.front();q.pop();
		for(int i=0;i<g[pos].size();++i){
			for(int j=0;j<n;++j)
				x[g[pos][i]][j+1]+=x[pos][j];
			if(!(--deg[g[pos][i]]))
				q.push(g[pos][i]);
		}
	}
	for(int i=1;i<=n;++i){
		int res=0;
		for(int j=1;j<=n;++j)
			res=(res+(ll)kpow[j]*x[i][j])%mod;
		printf("%d\n",res);
	}
	return 0;
}
