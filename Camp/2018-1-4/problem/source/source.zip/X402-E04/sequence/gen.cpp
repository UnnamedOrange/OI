#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=100010,INF=0x3f3f3f3f;
int a[N];
int main(){
	int n=10,T;
	freopen("sequence.in","w",stdout);
	T=rand()%5+1;
	srand(time(0));
	printf("%d\n",T);
	For(j,1,T){
		int n=rand()%20+3;
		printf("%d\n",n);
		For(i,1,n)a[i]=i;
		For(i,2,n)swap(a[i],a[rand()%(i-1)+1]);
		For(i,1,n)printf("%d ",a[i]);
		puts("");
	}
	return 0;
}
