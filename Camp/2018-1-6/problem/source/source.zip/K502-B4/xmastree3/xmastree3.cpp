#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,k,cnt,vis[100],ans;
struct node 
{
	int v;
	node *next_;
}pool[50010],*h[110];
void addedge(int u,int v)
{
	node *p=&pool[++cnt];
	p->v=v;p->next_=h[u];h[u]=p;
	p=&pool[++cnt];
	p->v=u;p->next_=h[v];h[v]=p;
}
bool check()
{
	for(int i=1;i<=n;i++) if(!vis[i]) return false;
	return true;
}
void dfs(int u,int dep)
{
	vis[u]=1;
	if(check())
	{
		ans++;
		ans%=998244353;
		return ;
	}
	for(node *p=h[u];p;p=p->next_)
	{
		int v=p->v;
		if(!vis[v]) for(int i=1;i+dep<=k;i++) dfs(v,dep+i);
	}
	vis[u]=0;
}
int main()
{
	
	freopen("xmastree3.in","r",stdin);
	freopen("xmaxtree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	int u,v;
	for(int i=1;i<n;i++) scanf("%d%d",&u,&v),addedge(u,v);
	for(int i=1;i<=n;i++) 
	{
		memset(vis,0,sizeof(vis)),dfs(i,0);
	}
	printf("%d",ans%998244353);
	return 0;
}
