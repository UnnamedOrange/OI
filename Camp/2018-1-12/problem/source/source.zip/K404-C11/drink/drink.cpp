#include <bits/stdc++.h>

namespace {

const int SIZE = 50;
const int MAXN = 1000000 + 9;

typedef std::pair<int, int> Pair;
typedef long double DecimalType;

Pair a[MAXN];
DecimalType bin[MAXN];
int ld[MAXN], rd[MAXN], pre[MAXN], next[MAXN];

inline char read() {
    static const int IN_LEN = 1 << 18 | 1;
    static char buf[IN_LEN], *s, *t;
    return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
           s == t ? -1 : *s++;
}

struct InputStream {
    inline InputStream &operator>>(int &x) {
        static char c;
        for (c = read(); !isdigit(c); c = read())
            ;
        for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
        return *this;
    }
} io;

inline void solve() {
    register int n;
    io >> n;
    for (register int i = 1; i <= n; i++) {
        io >> a[i].first;
        a[i].second = i;
        pre[i] = i - 1;
        next[i] = i + 1;
    }
    std::sort(a + 1, a + n + 1);
    bin[0] = 1;
    for (register int i = 1; i <= n; i++) bin[i] = bin[i - 1] * 2;
    register DecimalType ans = 0;
    for (register int i = 1, x; i <= n; i++) {
        x = a[i].second;
        register int l = 0, r = 0;
        for (register int p = x; p && l < SIZE; p = pre[p])
            ld[l++] = p - pre[p];
        for (register int p = x; p <= n && r < SIZE; p = next[p])
            rd[r++] = next[p] - p;
        register DecimalType sumL = 0, sumR = 0;
        for (register int j = 0; j < l; j++) sumL += ld[j] / bin[j];
        for (register int j = 0; j < r; j++) sumR += rd[j] / bin[j];
        ans += a[i].first * sumL * sumR / 2;
        if (pre[x]) next[pre[x]] = next[x];
        if (next[x] <= n) pre[next[x]] = pre[x];
    }
    std::cout << std::fixed << std::setprecision(12) << ans / n / n;
}
}  // namespace

int main() {
    freopen("drink.in", "r", stdin);
    freopen("drink.out", "w", stdout);
    solve();
    return 0;
}