#include <cstdio>

const int MAXN = 10000000 + 10;
int T, N;
int prime[MAXN], tot;
bool notprime[MAXN];
int mu[MAXN], sigma[MAXN], d[MAXN];
int ans;

inline void getprime() {
	register int i, j;
	notprime[1] = 1;
	mu[1] = 1; sigma[1] = 1;
	for( i = 2; i <= 10000000; ++i ) {
		if( notprime[i] )
			prime[++tot] = i,
			mu[i] = -1, sigma[i] = 2;
		for( j = 1; j <= tot && i * prime[j] <= 10000000; ++j ) {
			notprime[i * prime[j]] = 1;
			mu[i * prime[j]] = -mu[i];
			if( i % prime[j] == 0 ) {
				d[i * prime[j]] = d[i] + 1;
				sigma[i * prime[j]] = sigma[i] / ( d[i] + 1 ) * ( d[i] + 2 );
				break;
			}
			d[i * prime[j]] = 1;
			sigma[i * prime[j]] = sigma[i] * 2;
		}
	}
}

int main() {
	freopen( "function.in", "r", stdin );
	freopen( "function.out", "w", stdout );
	register int i;
	scanf( "%d", &T );
	getprime();
	while( T-- ) {
		ans = 0;
		scanf( "%d", &N );
		for( i = 1; i <= N; ++i )
			ans += sigma[i] * sigma[i] * mu[i];
		printf( "%d\n", ans );
	}
	return 0;
}
