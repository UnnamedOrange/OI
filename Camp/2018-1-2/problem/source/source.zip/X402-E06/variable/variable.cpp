#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 500;

struct lim {
    int x, y, r;
    lim() { }
    lim(int x_, int y_, int r_): x(x_), y(y_), r(r_) {}
};

lim l[N + 5];
int w[N + 5];
int n, W, p, q;
int x[N + 5], y[N + 5], z[N + 5];
int a[N + 5], b[N + 5], c[N + 5];
int d[N + 5], e[N + 5], f[N + 5];

bool chk() {
    for(int i = 1; i <= q; ++i) {
        if(l[i].r == 0 && w[l[i].x] > w[l[i].y]) return false; 
        if(l[i].r == 1 && w[l[i].x] !=w[l[i].y]) return false;
        if(l[i].r == 2 && w[l[i].x] >=w[l[i].y]) return false;
    }
    return true;
}

ll calc() {
    ll res = 0;
    if(!chk()) return LLONG_MAX;

    for(int i = 1; i <= n; ++i) res += w[i];
    for(int i = 1; i <= p; ++i) {
        res += a[i] * std::abs(w[x[i]] - w[y[i]]);
        res += b[i] * std::abs(w[y[i]] - w[z[i]]);
        res += c[i] * std::abs(w[z[i]] - w[x[i]]);

        res += d[i] * (w[x[i]] - w[y[i]]);
        res += e[i] * (w[y[i]] - w[z[i]]);
        res += f[i] * (w[z[i]] - w[x[i]]);
    }
    return res;
}

ll ans;
void dfs(int u) {
    if(u == n+1) {
        chkmin(ans, calc());
        return;
    }

    w[u] = W; dfs(u+1);
    w[u] = -W; dfs(u+1);
}

void random_shuffle() {
    const int LIM = 50000;
    for(int i = 1; i <= n; ++i) w[i] = (rand()&1) ? W : -W;
    for(int i = 1; i <= q; ++i) if(l[i].r == 2) w[l[i].x] = -W, w[l[i].y] = W;

    for(int i = 1; i <= LIM; ++i) {
        for(int j = 1; j <= q; ++j) {
            while(l[j].r == 1 && w[l[j].x] !=w[l[j].y]) w[l[j].x] = w[l[j].y] = (rand()&1) ? W : -W;
            while(l[j].r == 2 && w[l[j].x] >=w[l[j].y]) w[l[j].x] = (rand()&1) ? W : -W, w[l[j].y] = (rand()&1) ? W : -W;
            while(l[j].r == 0 && w[l[j].x] > w[l[j].y]) w[l[j].x] = (rand()&1) ? W : -W, w[l[j].y] = (rand()&1) ? W : -W;
        }
        for(int j = 1; j <= 20; ++j) w[rand() % n + 1] = (rand()&1) ? W : -W;
        if(chk()) chkmin(ans, calc()); 
    }
}

int main() {
    freopen("variable.in", "r", stdin);
    freopen("variable.out", "w", stdout);

    int t;
    read(t);

    while(t--) {
        read(n), read(W), read(p), read(q);
        for(int i = 1; i <= p; ++i) {
            read(x[i]), read(y[i]), read(z[i]);
            read(a[i]), read(b[i]), read(c[i]);
            read(d[i]), read(e[i]), read(f[i]);
        }
        for(int i = 1; i <= q; ++i) {
            static int xi, yi, r;
            read(xi), read(yi), read(r);
            l[i] = lim(xi, yi, r);
        }

        ans = LLONG_MAX;
        if(n <= 22) dfs(1); else random_shuffle();

        printf("%lld\n", ans);
    }

    return 0;
}
