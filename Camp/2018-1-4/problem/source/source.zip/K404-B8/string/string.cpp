#include<bits/stdc++.h>
using namespace std;
const int maxn = 6000;
const int mod = 998244353;

int f[109][maxn][1<<7];
int a[20][maxn],b[maxn];
int n,m,ans;
char str[maxn];
inline void update(int &x,int y)
{
	x += y;
	x -= x >= mod ? mod : 0;
}
struct Aho_Corasick
{
	int son[maxn][2],fail[maxn],sta[maxn],ed[maxn];
	int tot;
	void insert(int *s,int len,int idx)
	{
		int now=0;
		for(int i=1;i<=len;i++)
		{
			if(!son[now][s[i]]) son[now][s[i]]=++tot;
			now=son[now][s[i]];
		}
		sta[now]|=(1<<idx);
	}
	void insert2(int x,int y)
	{
		if(2*y<a[x][0])
		{
			int now=0;
			for(int i=a[x][0];i>y;i--)
			{
				int t=a[x][i]^1;
				if(!son[now][t]) son[now][t]=++tot;
				now=son[now][t];
			}
			ed[now]|=(1<<x);
		}
		else
		{
			int now=0;
			for(int i=1;i<=y;i++)
			{
				int t=a[x][i];
				if(!son[now][t]) son[now][t]=++tot;
				now=son[now][t];
			}
			ed[now]|=(1<<x);
		}
	}
	void build()
	{
		queue<int>q;
		for(int i=0;i<=1;i++) if(son[0][i])
		{
			q.push(son[0][i]);
			fail[son[0][i]]=0;
		}
		while(!q.empty())
		{
			int x=q.front();q.pop();
			sta[x]|=sta[fail[x]];
			ed[x]|=ed[fail[x]];
			for(int i=0;i<=1;i++)
			{
				if(!son[x][i]) son[x][i]=son[fail[x]][i];
				else
				{
					fail[son[x][i]]=son[fail[x]][i];
					q.push(son[x][i]);
				}
			}
		}
	}
	void dp(int len)
	{
		f[0][0][0]=1;
		int mr=(1<<n)-1;
		for(int i=0;i<len;i++)
			for(int j=0;j<=tot;j++)
				for(int k=0;k<=mr;k++)
					if(f[i][j][k])
						for(int p=0;p<=1;p++)
						{
							int nxt=son[j][p];
							update(f[i+1][nxt][k|sta[nxt]],f[i][j][k]);
						}
		for(int i=0;i<=tot;i++)
			for(int j=0;j<=mr;j++)
				if((ed[i]|j)==mr) update(ans,f[len][i][j]);
		cout<<ans<<endl;
	}
}ac;

bool check()
{
	for(int i=1;i<=n;i++)
	{
		bool flag=0;
		for(int j=1;j<=2*m-a[i][0]+1;j++)
		{
			bool ok=1;
			for(int p=1,k=j;p<=a[i][0];p++,k++)
				if(b[k]!=a[i][p]){ok=0;break;}
			if(ok){flag=1;break;}
		}
		if(flag==0) return 0;
	}
	return 1;
}
void work1() // brute for whhole string
{
	int mr=(1<<m)-1;
	for(int i=0;i<=mr;i++)
	{
		for(int j=1;j<=m;j++) b[j]=(bool)(i&(1<<j>>1));
		for(int j=1;j<=m;j++) b[m*2-j+1]=b[j]^1;
		if(check()) update(ans,1);
	}
	cout<<ans<<endl;
}
void work2() // brute for mid & dp for border
{
	ac.dp(m);
}

bool pd(int x,int y)
{
	for(int i=y+1,p=1;i<=a[x][0]&&y-p+1>=1;i++,p++)
		if(a[x][i]==a[x][y-p+1]) return false;
	return true;
}


int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++)
	{
		scanf("%s",str+1);
		a[i][0]=strlen(str+1);
		for(int j=1;j<=a[i][0];j++) a[i][j]=str[j]-'0';
		ac.insert(a[i],a[i][0],i);
	}
	for(int i=0;i<n;i++)
	{
		a[i+n][0]=a[i][0];
		for(int j=1;j<=a[i][0];j++) a[i+n][j]=a[i][j]^1;
		reverse(a[i+n]+1,a[i+n]+1+a[i][0]);
		ac.insert(a[i+n],a[i][0],i);
	}
//	cout<<pd(0,1)<<endl;
//	system("pause");
	for(int i=0;i<n;i++)
		for(int j=1;j<a[i][0];j++)
			if(pd(i,j))
			{
//k				printf("%d %d\n",i,j);
				ac.insert2(i,j);
			}
//	ac.insert2(0,1);
	ac.build();
//	work1();ans=0;
	work2();
	return 0;
}
