#include <bits/stdc++.h>

typedef long long int int64;
static const int64 mod = 1000000007LL;
int64 inv[3000003],fac[3000003],invfac[3000003];
int64 choose(int64 a,int64 b) {
	return fac[a] * invfac[b] % mod * invfac[a - b] % mod;
}

int s,t,n,m;
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	inv[1] = fac[1] = invfac[1] = fac[0] = invfac[0] = 1;
	for(int i = 2;i <= std::max(s + m,n);++i) {
		inv[i] = (mod - mod / i) * inv[mod % i] % mod;
		fac[i] = (i * fac[i - 1]) % mod;
		invfac[i] = (inv[i] * invfac[i - 1]) % mod;
	}
	int64 ans = 0;
	s -= m;
	for(int i = 0;i <= n;++i) {
		int64 val = choose(n,i) * ((i & 1) == 0 ? 1 : -1);
		int64 power = s - i * t;
		if(power < 0) continue;
		int64 val2 = choose(m+power,power);
		ans = (ans + val * val2) % mod;
	}
	if(ans < 0) ans += mod;
	printf("%lld\n",ans);
}
