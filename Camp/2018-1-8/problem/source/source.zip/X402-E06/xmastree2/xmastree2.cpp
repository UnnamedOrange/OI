#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 30000;

int n;
int w[N + 5], r[N + 5];

namespace cheat {
    ll ans = 0;
    vector<int> C[N + 5];
    vector<int> G[N + 5];

    void dfs(int u, int f) {
        for(int i = 0; i < int(G[u].size()); ++i) {
            if(G[u][i] != f) {
                dfs(G[u][i], u);
                C[u].pb(G[u][i]);
            }
        }
    }

    ll calc(int rt) {
        ll res = 0, cur = 1;
        std::priority_queue<pii> q;

        q.push(mp(w[rt], rt));
        while(!q.empty()) {
            res += q.top().fst * (cur++);
            int x = q.top().snd; q.pop();

            for(int i = 0; i < (int) C[x].size(); ++i) 
                q.push(mp(w[C[x][i]], C[x][i]));
        }
        return res;
    }

    void solve() {
        for(int i = 1; i < n; ++i) {
            static int x, y;
            read(x), read(y);
            G[x].pb(y), G[y].pb(x);
        }
        for(int i = 1; i <= n; ++i) read(w[i]), read(r[i]);
        for(int i = 1; i <= n; ++i) {
            if(r[i]) {
                for(int j = 1; j <= n; ++j) C[j].clear();
                dfs(i, 0);
                chkmax(ans, calc(i));
            }
        }
        printf("%lld\n", ans);
    }
}

namespace bf {
    const int N = 1000;

    int ans = 0;
    bool vis[N + 5];
    int G[N + 5][N + 5];

    bool chk(int x) {
        bool flag = false;
        for(int i = 1; i <= n; ++i) 
            if(vis[i]) {
                flag = true;
                if(G[i][x]) return true;
            }
        if(!flag) return r[x];
        return false;
    }

    void dfs(int cur, int res) {
        if(cur == n) { 
            chkmax(ans, res);
            return;
        }

        for(int i = 1; i <= n; ++i) if(!vis[i] && chk(i)) {
            vis[i] = true; 
            dfs(cur + 1, res + w[i] * (cur+1));
            vis[i] = false;
        }
    }

    void solve() {
        for(int i = 1; i < n; ++i) {
            static int x, y;
            read(x), read(y);
            G[x][y] = G[y][x] = true;
        }
        for(int i = 1; i <= n; ++i) read(w[i]), read(r[i]);

        dfs(0, 0);
        printf("%d\n", ans);
    }
}

int main() {
    freopen("xmastree2.in", "r", stdin);
    freopen("xmastree2.out", "w", stdout);

    read(n);
    if(n <= 10) bf::solve(); else 
        cheat::solve();

    return 0;
}
