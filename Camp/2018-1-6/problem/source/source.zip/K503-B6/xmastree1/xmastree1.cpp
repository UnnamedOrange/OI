#include<iostream>
#include<cstdio>
#include<cctype>
#include<algorithm>
#include<cstring>
#include<string>
#include<queue>
#include<map>
#include<vector>
#define size(x) (((int)z[x].size()) - 1)
#define rep(i,x,y) for(register int i = x ;i <= y; ++ i)
using namespace std;
typedef long long ll;
template<typename T>inline void read(T&x)
{
	x = 0;char c;int sign = 1;
	do { c = getchar(); if(c == '-') sign = -1; }while(!isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); }while(isdigit(c));
	x *= sign ;
}
inline void init(string name )
{
	string in = name + ".in",out = name + ".out";
	freopen(in.c_str(),"r",stdin);
	freopen(out.c_str(),"w",stdout);
}

const int N = 1e5+500;
int lst,n,q,t,f[N],color[N];
int head[N],to[N << 1],nxt[N << 1],tot;
int sz,rt[N],ls[10000000],rs[10000000],val[10000000],w[10000000];
struct Segment_tree
{
	void insert(int&id,int x,int y,int l,int r)
	{
		if(!id) id = ++sz;
		if(l == r)
		{
			val[id] += y;
			w[id] = val[id] > 0;
			return;
		}
		int mid = l + r >> 1;
		if(x <= mid) insert(ls[id],x,y,l,mid);
		else insert(rs[id],x,y,mid + 1,r);
		w[id] = w[ls[id]] + w[rs[id]];
	}
	
	int query(int id,int l,int r,int L,int R)
	{
		if(!id) return 0;
		if(l <= L && r >= R)
		{
			return w[id];
		}
		
		int mid = l + r >> 1;
		if(r <= mid) return query(ls[id],l,r,L,mid);
		else if (l > mid) return query(rs[id],l,r,mid + 1,R);
		else return query(ls[id],l,r,L,mid) + query(rs[id],l,r,mid + 1, R);
	}	
}seg;

inline void add(int x,int y) { nxt[tot] = head[x]; to[tot] = y; head[x] = tot ++; }

void dfs(int x)
{
	for(register int i = head[x];~i;i = nxt[i])
		if(to[i] != f[x]) 
		{
			f[to[i]] = x;
			dfs(to[i]);
		}
}

int main()
{
	init("xmastree1");
	memset(head,-1,sizeof head);
	read(n);read(q);read(t);
	rep(i,1,n) read(color[i]);
	rep(i,2,n)
	{
		int u,v;
		read(u);read(v);
		add(u,v); add(v,u);
	}
	
	dfs(1);
	rep(i,1,n)
	{
		int x = i;
		while(x)
		{
			seg.insert(rt[x],color[i],1,1,n);
			x = f[x];
		}
	}
	
	int op,u,l,r,c;
	
	rep(i,1,q)
	{
		read(op);
		if(op == 1)
		{
			read(u);read(l);read(r);
			if(t) u^= lst,l ^= lst,r ^= lst;
			printf("%d\n",lst = seg.query(rt[u],l,r,1,n));
		}else
		{
			read(u);read(c);
			if(t) u ^= lst,c ^= lst;
			while(u)
			{
				seg.insert(rt[u],color[u],-1,1,n),
				seg.insert(rt[u],c,1,1,n);
				u = f[u];
			}
			color[u] = c;
		}
	}
	return 0;
}
