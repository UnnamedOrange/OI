#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1e5+10,mod=1e9+7;
int n,a,b;
ll resa,resb,resf,resl;

inline ll qpow(ll a,ll n){
	ll res=1;
	while(n){
		if(n&1ll)
			res=res*a%mod;
		a=a*a%mod;
		n>>=1;
	}
	return res;
}
inline void solve(){
	int x1=0,x2=0,x3=0,x4=0;
	for(int i=1,x;i<=n;++i){
		scanf("%d",&x);
		x%=a+b;
		if(x<a)
			++x1;
		else if(x<b)
			++x2;
		else if(x<2*a)
			++x3;
		else
			++x4;
	}
	if(x3)
		resf=resl=qpow(2,x1+x3-1);
	else
		resl=qpow(2,x1);
	resa=(qpow(2,x1+x2+x3)-qpow(2,x1+x3)+mod)%mod;
	resa=(resa*(x4+1)+resf*x4)%mod;
	resf=(resf+resl*x4)%mod;
	resa=(resa+(qpow(2,x4)-1-x4+mod)%mod*qpow(2,x1+x2+x3))%mod;
}

int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	if(a>b){
		swap(a,b);
		solve();
		swap(resa,resb);
	}
	else
		solve();
	printf("%lld %lld %lld %lld\n",resa,resb,resf,resl);
	return 0;
}
