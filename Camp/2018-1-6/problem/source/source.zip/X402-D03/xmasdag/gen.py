import sys
from random import *

sys.stdout = open("xmasdag.in", "w")

n = randint(2, 2000)
m = randint(1, 5000)
k = randint(0, 300)

print(n, m, k)

l = list(range(1, n+1))

shuffle(l)
while l[n-1] == 1:
	shuffle(l)

for i in range(n):
	if l[i] == 1 : 
		while m > n/2 :
			print(1, l[randint(i+1, n-1)])
			m = m-1
		break
for i in range(m):
	x = randint(0, n-2)
	y = randint(x+1, n-1)

	print(l[x], l[y])

