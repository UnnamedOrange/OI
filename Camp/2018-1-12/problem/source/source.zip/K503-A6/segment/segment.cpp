#include<cstdio>
using namespace std;
#define LL long long
#define mod 998244353 
#define rep(i,j,k) for(i=j;i<=k;++i)
int n,m,i,j,K,pw,ans,sum;
int c[100005],f[3][100005];
void read(int &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
}
int quick_mi(LL a,int b){
	LL sum=1;
	for(;b;b>>=1){
		if(b&1) sum=(sum*a)%mod;
		a=(a*a)%mod;
	}
	return sum;
}
void solve1(){
	rep(i,1,m){
		ans=(ans+((i*1LL*(m-i))%mod))%mod;
	}
	printf("%d\n",ans);
}
void solve2(){
	LL i,j;
	rep(i,1,m) c[i]=(c[i-1]+((((i+1LL)*1LL*i)/2LL)%mod))%mod;
	rep(i,0,m) f[1][i]=1+i;
	rep(i,2,2){
		sum=0;
		rep(j,i-1,m){
			sum+=f[i-1][j-1];
			f[i][j]=sum;
		}
	}
	pw=quick_mi(2,K);
	rep(i,1,m){
		ans=(ans+((c[i-1]*1LL*(m-i))%mod))%mod;
		j=m-i;
		ans=(ans+((c[j]*1LL*(m-j))%mod))%mod;
		ans=(ans+((pw*((f[2][m-1-i]*1LL*f[2][i])%mod))%mod))%mod;
	}
	printf("%d\n",ans);
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	read(n); read(m); read(K);
	if(n==1) solve1();
	if(n==2) solve2();
	return 0;
}
