#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while (c = getchar(), c >= '0');
}

const int M = (int) 1e6 + 5;

struct Node {int to, nxt;} Edge[M];
int n, m, Head[M], deg[M], tot;

inline void Addedge(int a, int b) {
	Edge[tot] = (Node) {b, Head[a]}; Head[a] = tot++; deg[b]++;
}

namespace Subtask1 {
	
	bool mark[M];
	int ans = 0, mxdis[M], Stk[M], top;
	
	void dfs(int x) {
		Stk[++top] = x; mark[x] = true;
		ans = max(ans, top);
		for (int i = Head[x]; ~i; i = Edge[i].nxt) {
			int to = Edge[i].to;
			if (mark[to] || top + 1 <= mxdis[to]) continue;
			mxdis[to] = top + 1;
			dfs(to);
		}
		mark[x] = false; top--;
	}
	
	void solve() {
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) mxdis[j] = 0;
			dfs(i);
		}
		printf("%d\n", ans);
	}
	
}

namespace Subtask2 {
	
	int Q[M], L, R, dis[M];
	
	void solve() {
		L = 0, R = -1;
		for (int i = 1; i <= n; i++)
			if (!deg[i]) Q[++R] = i, dis[i] = 1;
		while (L <= R) {
			int now = Q[L++];
			for (int i = Head[now]; ~i; i = Edge[i].nxt) {
				int to = Edge[i].to;
				deg[to]--;
				dis[to] = max(dis[to], dis[now] + 1);
				if (!deg[to]) Q[++R] = to;
			}
		}
		if (R != n - 1) Subtask1::solve();
		else {
			int ans = 0;
			for (int i = 1; i <= n; i++) ans = max(ans, dis[i]);
			printf("%d\n", ans);
		}
	}
	
}

int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	Rd(n), Rd(m);
	memset(Head, -1, sizeof(Head));
	for (int i = 1; i <= m; i++) {
		int a, b;
		Rd(a), Rd(b);
		Addedge(a, b);
	}
	if (n <= 1000 && m <= 1000) Subtask1::solve();
	else Subtask2::solve();
	return 0;
}
