#include<cstdio>
#include<vector>
#include<queue>
#include<cstring>
using namespace std;
vector<int> p[31000];
int n;
int w[31000]={0},ok[31000]={0};
struct cmp{
	bool operator () (int a,int b){
		return w[a]>w[b];
	}
};
priority_queue<int,vector<int>,cmp>q;
void initi(){
	scanf("%d",&n);
	int a,b;
	for(int i=1;i<n;++i){
		scanf("%d%d",&a,&b);
		p[a].push_back(b);
		p[b].push_back(a);
	}
	for(int i=1;i<=n;++i){
		scanf("%d%d",&w[i],&ok[i]);
	}
}
bool fl[31000]={0};
long long solve(int root){
	long long ans=0;
	q.push(root);
	memset(fl,0,sizeof fl);
	fl[root]=1;
	for(int i=1;i<=n;++i){
		int cur=q.top();
		q.pop();
		ans+=i*w[cur];
		for(int i=0;i<p[cur].size();++i){
			if(!fl[p[cur][i]]){
				q.push(p[cur][i]);
				fl[p[cur][i]]=1;
			}
		}
	}
	return ans;
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	initi();
	long long ans=0;
	for(int i=1;i<=n;++i){
		if(ok[i]){
			ans=max(ans,solve(i));
		}
	}
	printf("%lld\n",ans);
}
