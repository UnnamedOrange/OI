#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
using namespace std;

const int N=100005;
const int mod=1000000007;

int can,n,a,b,m,b1,b2,s1,s2,s3,s4;
int c[N],d[N],dp[N][2];

bool dfs(int a,int b,int step){
	int i; bool tag=0;
	if (!step){
		for (i=1;i<=m;i++)
			if (d[i]>=a){
				d[i]-=a;
				tag|=dfs(a,b,step^1);
				d[i]+=a;
			}
		return tag;
	}
	else{
		for (i=1;i<=m;i++)
			if (d[i]>=b){
				d[i]-=b;
				tag|=(dfs(a,b,step^1)^1);
				d[i]+=b;
			}
		return tag^1;
	}
}

bool pd(int a,int b){
	return dfs(a,b,0);
}

void solve(){
	int i;
	dp[0][0]=1;
	for (i=1;i<=n;i++) c[i]=(c[i]/a)&1;
	for (i=1;i<=n;i++){
		dp[i][0]=dp[i-1][0];
		dp[i][1]=dp[i-1][1];
		if (c[i]){
			dp[i][0]=(dp[i][0]+dp[i-1][1])%mod;
			dp[i][1]=(dp[i][1]+dp[i-1][0])%mod;
		}
		else{
			dp[i][0]=(dp[i][0]+dp[i-1][0])%mod;
			dp[i][1]=(dp[i][1]+dp[i-1][1])%mod;
		}
	}
	printf("0 0 %d %d\n",dp[n][1],dp[n][0]);
}

int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int i,s;
	scanf("%d%d%d",&n,&a,&b);
	for (i=1;i<=n;i++) scanf("%d",&c[i]);
	if (a==b){
		solve();
		return 0;
	}
	for (s=0;s<(1<<n);s++){
		m=0;
		for (i=1;i<=n;i++)
			if ((s>>i-1)&1) d[++m]=c[i];
		b1=pd(a,b);
		b2=pd(b,a);
		if (b1&&b2) s3++;
		if (!b1&&!b2) s4++;
		if (b1&&!b2) s1++;
		if (!b1&&b2) s2++;
	}
	printf("%d %d %d %d\n",s1,s2,s3,s4);
	return 0;
}
/*
2 2 3
2 3
*/
