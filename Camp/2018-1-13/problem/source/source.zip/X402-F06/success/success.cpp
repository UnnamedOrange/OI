#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
int n,m,s,t;
const int mod=1e9+7;
inline void add(int &x,int y){
	x+=y;
	if(x>mod) x-=mod;
}
int ksm(int x,int y){
	int num=1;
	while(y){
		if(y&1) num=1ll*num*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return num;
}
namespace bf{
	 const int maxn=100+10;
	 int dp[maxn][maxn],fac[maxn<<1],ifac[maxn<<1];
	 void init(){
		 memset(dp,0,sizeof(dp));
		 int N=200;
		 fac[0]=1;
		 REP(i,1,N) fac[i]=1ll*fac[i-1]*i%mod;
		 ifac[N]=ksm(fac[N],mod-2);
		 DREP(i,N-1,0) ifac[i]=1ll*ifac[i+1]*(i+1)%mod;
	 }
	 int C(int x,int y){
		 if(y>x) return 0;
		 return 1ll*fac[x]*ifac[y]%mod*ifac[x-y]%mod;
	 }
	 void work(){
		 init();
		 dp[0][0]=1;
		 REP(i,1,n)
			 REP(j,1,s){
				REP(k,max(0,j-t),j-1)
					add(dp[i][j],dp[i-1][k]);
			 }
		 int ans=0;
		 if(m==n){
			 REP(i,0,s) add(ans,dp[n][i]);
			 printf("%d\n",ans);
			 return;
		 }
		 REP(i,0,s)
			 REP(j,1,s-i)
				add(ans,1ll*dp[n][i]*C(j-1,m-n-1));
		 printf("%d\n",ans);
	 }
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
#endif
	s=read(),t=read(),n=read(),m=read();
	if(n<=100 && m<=100 && t<=100 && s<=100){
		bf::work();
		return 0;
	}
	return 0;
}
