#include <iostream>
#include <cstdio>
#include <queue>
#include <cstring>
using namespace std;
const int MOD = 998244353;
int n, k;
int head[60], to[110], nxt[110], cnt;
inline void addedge (int u, int v) { cnt++, to[cnt] = v, nxt[cnt] = head[u], head[u] = cnt; }
bool used[60];
queue <int> q;
inline int dfs (int s, int x) {
	bool b[60];
	memset (b, 0, sizeof (b));
	q.push (s); b[s] = true;
	while (!q.empty ()) {
		int u = q.front (); q.pop ();
		for (int e = head[u]; e; e = nxt[e]) {
			int v = to[e];
			if (used[v] || b[v]) continue;
			b[v] = true;
			q.push (v);
		}
	}
	int ans = 0;
	for (int u = 1; u <= n; u++) if (b[u]) {
		int r = 1;
		used[u] = true;
		for (int e = head[u]; e; e = nxt[e]) {
			int v = to[e];
			if (used[v]) continue;
			int f = 0;
			for (int i = x + 1; i <= k; i++) f = (f + dfs (v, i)) % MOD;
			r = 1ll * r * f % MOD;
		}
		ans = (ans + r) % MOD;
		used[u] = false;
	}
	return ans;
}
int main () {
	freopen ("xmastree3.in", "r", stdin);
	freopen ("xmastree3.out", "w", stdout);
	scanf ("%d%d", &n, &k);
	for (int i = 1; i < n; i++) {
		int u, v;
		scanf ("%d%d", &u, &v);
		addedge (u, v);
		addedge (v, u);
	}
	int ans = 0;
	for (int i = 1; i <= k; i++) ans = (ans + dfs (1, i)) % MOD;
	printf ("%d\n", ans);
	return 0;
}
