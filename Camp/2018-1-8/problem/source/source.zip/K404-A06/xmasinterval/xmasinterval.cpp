/*problem:xmasinterval*/
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
#include<vector>
#include<set>
#include<map>
#include<queue>
#define ll long long
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
#define vi vector<int>
#define setfile(s) freopen(#s".in","r",stdin),freopen(#s".out","w",stdout)
using namespace std;
const int mod=1e9+9;
int n,m,x[500010];
struct seg{
	int l,r;bool operator<(const seg&that)const{return l<that.l||(l==that.l&&r<that.r);}
}a[500010],t[500010];
int f[2000010],cnt;
void build(){
	for(cnt=1;cnt<m+3;cnt<<=1);cnt--;
}
void add(int l,int r,int v){
	l++,r++;
	for(l+=cnt-1,r+=cnt+1;l^r^1;l>>=1,r>>=1){
		if(~l&1)(f[l^1]+=v)%=mod;
		if(r&1)(f[r^1]+=v)%=mod;
	}
}
int query(int pos){
	pos++;int v=0;pos+=cnt;
	for(;pos;pos>>=1)v=(v+f[pos])%mod;
	return v;
}
char B[1<<24],*S=B;
int F(){
	int x;
	for(;*S<48;S++);x=*S++-48;
	for(;*S>=48;)x=(x<<1)+(x<<3)+*S++-48;
	return x;
}
int main(){
	setfile(xmasinterval);
	fread(B,1,1<<24,stdin);
	n=F(),m=F();
	for(int i=1;i<=n;++i)a[i].l=F(),a[i].r=F();
	for(int i=1;i<=m;++i)x[i]=F();
	sort(x+1,x+m+1);
	m=unique(x+1,x+m+1)-x-1;
	int it=0;
	for(int i=1;i<=n;++i){
		a[i].l=std::lower_bound(x+1,x+m+1,a[i].l)-x;
		a[i].r=std::upper_bound(x+1,x+m+1,a[i].r)-x-1;
		if(a[i].l<=a[i].r)t[++it]=a[i];
	}
	n=it;
	std::sort(t+1,t+n+1);
	build();
	add(0,0,1);
	for(int i=1;i<=n;++i){
		int v=query(t[i].l-1);
		add(0,t[i].r,v);
	}
	printf("%d\n",query(m));
	return 0;
}

