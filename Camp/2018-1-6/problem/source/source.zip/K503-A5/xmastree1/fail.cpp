#include <bits/stdc++.h>
using namespace std;
template <typename T> void read(T &x) {
	x=0;char c=getchar();
	while (!isdigit(c)) {c=getchar();}
	while (isdigit(c)) {x=x*10+c-'0';c=getchar();}
	return;
}
struct Edge {
	int to; Edge *nxt;
} pool[100100], *tail=pool, *G[100100];
struct Node {
	int sum, lc, rc;
} t[20000100], *tot=t;
int root[400100], clr[100100];
int n, c[100100], clk, dfn[100100], low[100100];
void build() {
	for (int i=1;i<=n;i++) {
		modify(dfn[i])
	}
}
void add(int u, int v) {
	(++tail)->to=v, tail->nxt=G[u], G[u]=tail;
	(++tail)->to=u, tail->nxt=G[v], G[v]=tail;
}
void dfs(int x) {
	if (dfn[x]) return;
	dfn[x]=++clk;
	for (Edge *p=G[x];p;p=p->nxt) {
		dfs(p->to);
	}
	low[x]=clk;
}
int main() {
//	freopen("xmastree1.in","r",stdin);
//	freopen("xmastree1.out","w",stdout);
	int q, t;
	read(n), read(q), read(t);
	for (int i=1;i<=n;i++) {
		read(c[i]);
	}
	for (int i=1;i<n;i++) {
		int u, v;
		read(u), read(v);
		add(u,v);
	}
	dfs(1);
	build();
	while (q--) {
		
	}
	return 0;
}

