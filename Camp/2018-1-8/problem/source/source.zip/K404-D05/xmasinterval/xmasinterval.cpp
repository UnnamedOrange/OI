#include<bits/stdc++.h>
#define FE "xmasinterval"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		c=='-'?p=-1:0;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
typedef long long ll;
inline void putint(int x){
	x<0?putchar('-'),x=-x:0;
	static int buf[20];
	int tot=0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
const int MOD = 1000000009;
int n,m;
int a[1000005];
struct interval{
	int l,r;
	bool operator < (const interval &b)const{
		if(l!=b.l)return l<b.l;
		return r<b.r;
	}
}b[1000005];
int seg[3000005],tag[3000005];
inline void change(int k,int x){
	seg[k]=(ll)seg[k]*x%MOD;
	tag[k]=(ll)tag[k]*x%MOD;
}
inline void pushdown(int k){
	if(tag[k]==1)return;
	change(k<<1,tag[k]);
	change(k<<1|1,tag[k]);
	tag[k]=1;
}
inline void updata(int k){
	seg[k]=seg[k<<1]+seg[k<<1|1];
	seg[k]>=MOD?seg[k]-=MOD:0;
}
inline void modify1(int k,int l,int r,int s,int t,int x){
	if(s<=l&&r<=t){
		change(k,x);
		return;
	}
	pushdown(k);
	int mid=l+r>>1;
	if(s<=mid)modify1(k<<1,l,mid,s,t,x);
	if(mid<t)modify1(k<<1|1,mid+1,r,s,t,x);
	updata(k);
}
inline void modify2(int k,int l,int r,int p,int x){
	if(l==r){
		tag[k]=1;
		seg[k]=x;
		return;
	}
	pushdown(k);
	int mid=l+r>>1;
	if(p<=mid)modify2(k<<1,l,mid,p,x);
	else modify2(k<<1|1,mid+1,r,p,x);
	updata(k);
}
inline int query(int k,int l,int r,int s,int t){
	if(s<=l&&r<=t){
//		if(s==4&&t==4){
//			cout<<k<<" "<<l<<" "<<r<<" "<<seg[k]<<endl;
//		}
		return seg[k];
	}
	pushdown(k);
	int mid=l+r>>1,ans=0;
	if(s<=mid)ans+=query(k<<1,l,mid,s,t);
	if(mid<t)ans+=query(k<<1|1,mid+1,r,s,t),ans>=MOD?ans-=MOD:0;
	updata(k);
//	if(s==4&&t==4){
//		cout<<k<<" "<<l<<" "<<r<<endl;
//		cout<<ans<<endl;
//	}
	return ans;
}
inline void build(int k,int l,int r){
	tag[k]=1;
	if(l==r){
		if(l==0)seg[k]=1;
		return;
	}
	int mid=l+r>>1;
	build(k<<1,l,mid);
	build(k<<1|1,mid+1,r);
	updata(k);
}
inline void print(int k,int l,int r){
	cout<<k<<" "<<l<<" "<<r<<endl;
	cout<<seg[k]<<" "<<tag[k]<<endl;
	if(l==r)return;
	int mid=l+r>>1;
	print(k<<1,l,mid);
	print(k<<1|1,mid+1,r);
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	n=getint(),m=getint();
	for(int i=1;i<=n;++i){
		b[i].l=getint(),b[i].r=getint();
	}
	for(int i=1;i<=m;++i){
		a[i]=getint();
	}
	sort(a+1,a+m+1);
	for(int i=1;i<=n;++i){
		b[i].l=lower_bound(a+1,a+m+1,b[i].l)-a;
		b[i].r=upper_bound(a+1,a+m+1,b[i].r)-a-1;
	}
	sort(b+1,b+n+1);
	build(1,0,m);
	for(int i=1;i<=n;++i){
		if(b[i].r+1<=m)modify1(1,0,m,b[i].r+1,m,2);
		int ans1=query(1,0,m,b[i].l-1,b[i].r),ans2=query(1,0,m,b[i].r,b[i].r);
		modify2(1,0,m,b[i].r,(ans1+ans2)%MOD);
//		cout<<"************\n";
//		cout<<b[i].l<<" "<<b[i].r<<endl;
//		cout<<ans1<<" "<<ans2<<endl;
//		print(1,0,m);
//		cout<<endl;
	}
	cout<<query(1,0,m,m,m);
	return 0;
}
