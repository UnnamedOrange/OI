#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);

	int T, N;
	cin>>T;
	while(T--) {
		cin>>N;
		cout<<19260817<<endl;
	}
	return 0;
}
