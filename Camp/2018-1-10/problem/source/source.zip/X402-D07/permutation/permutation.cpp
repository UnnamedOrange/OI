#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=100010,mo=998244353;
int n,p[maxn],ans;
bool book[maxn],vis[maxn];
bool check(){
    memset(book,0,sizeof book);
    for(int i=1;i<=n;i++) if(!book[i]){
        book[i]=1; int cnt=1;
        for(int j=p[i];j!=i;j=p[j]) book[j]=1,++cnt;
        if(cnt&1) return 0;
    }
    return 1;
}
void dfs(int u){
    if(u==n+1) return void(ans+=check());
    if(!p[u]){
        for(int i=1;i<=n;i++) if(!vis[i]){
            p[u]=i; vis[i]=1;
            dfs(u+1);
            p[u]=0; vis[i]=0;
        }
    }
    else dfs(u+1);
}
int main(){
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
    read(n); bool flag=1;
    if(n&1) puts("0"),exit(0);
    for(int i=1;i<=n;i++){
        read(p[i]);
        if(p[i]) vis[p[i]]=1,flag=0;
    }
    if(flag){
        ans=1;
        for(int i=1;i<n;i+=2) ans=1ll*ans*i%mo;
        ans=1ll*ans*ans%mo;
    }
    else dfs(1);
    printf("%d\n",ans);
    return 0;
}
