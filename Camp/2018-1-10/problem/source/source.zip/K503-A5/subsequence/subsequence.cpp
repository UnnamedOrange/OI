#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	int n,m,k;
	cin >> n >> m >> k;
	cout << min(n,m)+1 << endl;
	return 0;
}
