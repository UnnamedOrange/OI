//laji�����˿��ҳ��� 
#include<bits/stdc++.h>
#define N 1000005
using namespace std;
inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}

struct node
{
	int x, i;
	bool operator < (const node & a)
	{
		if(x!=a.x)return x<a.x;
		return i>a.i; 
	}
}op[N];

int o,i,n,a[N],c,p[N],e[N];
double s1,s2,ans,g; 
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for(int i=1; i<=n; ++i)
	{
	    op[i].x=a[i]=read();
	    op[i].i=i;
	}
	sort(op+1,op+n+1);
	for(int i=1; i<=n; ++i)e[i]=i+1,p[i]=i-1;
	for(int t=1; t<=n; ++t)
	{
		i=op[t].i; 
	    g=0.5; s1=0; c=i; o=0;
		for(int j=p[i]; j; j=p[j])
		{
			s1+=g*(c-j);
			c=j;
			g*=0.5; 
			++o; 
			if(o>40)goto lll;   
		}
		s1+=g*c;
		
		lll:;
		
		g=1; s2=0; c=i; o=0;  
		for(int j=e[i]; j<=n; j=e[j])
		{
			s2+=g*(j-c); 
			c=j;
			g*=0.5;
			++o;
			if(o>40)goto llll;  
		}
		
		s2+=g*(n-c+1);
		llll:;
		ans+=s1*s2*a[i];
		e[p[i]]=e[i];
		p[e[i]]=p[i];
	}
	ans/=((double)n*n);
	printf("%.9lf\n",ans);  
}
