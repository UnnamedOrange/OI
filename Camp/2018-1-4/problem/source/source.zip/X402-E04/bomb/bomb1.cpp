#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N=1000100,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
template<class T>inline bool chmi(T &a,T b){return a>b?a=b,1:0;}
template<class T>inline bool chmx(T &a,T b){return a<b?a=b,1:0;}
inline void file(){
	freopen("bomb.in","r",stdin);
	freopen("bomb1.out","w",stdout);
}
int n,Begin[N],Next[N<<1],to[N<<1],e,scc[N],sccno[N],pre[N],low[N],scc_cnt,dfs_cnt,sz[N],m,dp[N];
stack<int>S;
inline void add(int x,int y){
	to[++e]=y,Next[e]=Begin[x],Begin[x]=e;
}
void dfs(int u){
	pre[u]=low[u]=++dfs_cnt;
	sccno[u]=1;S.push(u);
	Rep(i,u)
		if(!pre[v])dfs(v),chmi(low[u],low[v]);
		else if(sccno[v])chmi(low[u],pre[v]);
	if(low[u]==pre[u]){
		int x;scc_cnt++;
		do{
			x=S.top();S.pop();scc[x]=scc_cnt,sccno[x]=0;sz[scc_cnt]++;
		}while(x!=u);
	}
} 
inline void tarjan(){
	For(i,1,n)if(!pre[i])dfs(i);
}
vector<int>G[N];
int deg[N];
void init(){
	read(n),read(m);
	For(i,1,m){
		int x,y;
		read(x),read(y);
		add(x,y);
	}
	tarjan();
	For(u,1,n)
		Rep(i,u)
			if(scc[v]!=scc[u])G[scc[u]].push_back(scc[v]),deg[scc[v]]++;
}
int h,t,q[N];
void toposort(){
	For(i,1,scc_cnt)if(!deg[i])q[++t]=i;
	while(h<t){
		int r=q[++h],s=G[r].size();
		For(i,0,s-1){
			int v=G[r][i];
			if(!(--deg[v]))q[++t]=v;
		}
	}
}
void solve(){
	int ans=0;
	toposort();
	Forr(i,scc_cnt,1){
		int u=q[i],s=G[u].size();
		dp[u]=sz[u];
		For(j,0,s-1){
			int v=G[u][j];
			chmx(dp[u],dp[v]+sz[u]);
		}
		chmx(ans,dp[u]);
	}
	printf("%d\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
