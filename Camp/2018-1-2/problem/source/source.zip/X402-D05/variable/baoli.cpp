#include<bits/stdc++.h>
using namespace std;
const int INF=1e9;
int Abs(int x){
	return x>0?x:-x;
}
struct nodep{
	int x,y,z;
	int a,b,c,d,e,f;
	void readl(){
		scanf("%d%d%d",&x,&y,&z);
		scanf("%d%d%d%d%d%d",&a,&b,&c,&d,&e,&f);
	}
}A[1010];
struct nodeq{
	int x,y,r;
	void readl(){
		scanf("%d%d%d",&x,&y,&r);
	}
}B[1010];
int n,W,p,q;
int val[10100];
int ans;
void solve(){
	for(int i=1;i<=q;i++){
		if(B[i].r==0&&!(val[B[i].x]<=val[B[i].y])) return;
		if(B[i].r==1&&!(val[B[i].x]==val[B[i].y])) return;
		if(B[i].r==2&&!(val[B[i].x]< val[B[i].y])) return;
	}
	int sum=0;
	for(int i=1;i<=n;i++)
		sum=sum+val[i];
	for(int i=1;i<=p;i++){
		sum=sum+Abs(val[A[i].x]-val[A[i].y])*A[i].a;
		sum=sum+Abs(val[A[i].y]-val[A[i].z])*A[i].b;
		sum=sum+Abs(val[A[i].z]-val[A[i].x])*A[i].c;
		sum=sum+(val[A[i].x]-val[A[i].y])*A[i].d;
		sum=sum+(val[A[i].y]-val[A[i].z])*A[i].e;
		sum=sum+(val[A[i].z]-val[A[i].x])*A[i].f;
	}
	if(sum<ans) ans=sum;
}
void dfs(int ps){
	if(ps>n){
		solve();
		return;
	}
	val[ps]=W;
	dfs(ps+1);
	val[ps]=-W;
	dfs(ps+1);
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		ans=INF;
		scanf("%d%d%d%d",&n,&W,&p,&q);
		for(int i=1;i<=p;i++)
			A[i].readl();
		for(int i=1;i<=q;i++)
			B[i].readl();
		dfs(1);
		printf("%d\n",ans);
	}
	return 0;
}
