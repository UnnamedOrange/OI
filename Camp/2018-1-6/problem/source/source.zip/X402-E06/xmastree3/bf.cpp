#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 50;
const int K = 15;
const int mo = 998244353;

int n, k;
bool g[N + 5][N + 5];
int dp[1 << K][N + 5][K + 5];

int chk(int u, int s, int f = -1) {
    int res = 1 << u;
    for(int i = 0; i < n; ++i) if(g[u][i] && i != f) {
        if(!(s >> i & 1)) { res |= chk(i, s, u); }
    }
    return res;
}

int dfs(int s, int u, int l) {
    int ap = chk(u, s);
    int &ans = dp[s][u][l];

    if(ans >= 0) return ans;
    if(ap == (1 << u)) return k-l;

    ans = 0;
    for(int v = 0; v < n; ++v) if(ap >> v & 1) {
        for(int _l = l+1; _l <= k; ++_l) {
            int res = 1;
            for(int w = 0; w < n; ++w) if((ap >> w & 1) && g[v][w]) {
                res = (1ll * res * dfs(s | (1 << v), w, _l)) % mo;
            } ans = (ans + res) % mo;
        }
    }
    return ans;
}

int main() {
    freopen("xmastree3.in", "r", stdin);
    freopen("xmastree3.out", "w", stdout);

    memset(dp, -1, sizeof dp);

    read(n), read(k);
    for(int i = 1; i < n; ++i) {
        static int u, v;
        read(u), read(v); -- u, -- v; 
        g[u][v] = g[v][u] = 1;
    }

    printf("%d\n", dfs(0, 0, 0));

    return 0;
}
