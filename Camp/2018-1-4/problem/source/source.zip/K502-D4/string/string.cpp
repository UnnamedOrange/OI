#include<bits/stdc++.h>
#define rep(a,b,c) for(int a=b;a<=c;a++)
#define per(a,b,c) for(int a=b;a>=c;a--)
#define mo 998244353
using namespace std;
typedef long long LL;
int n,m;
char s[7][1005];
bool pin[7][7][1005];
LL ans;
LL ksm(LL base,LL loc) {
	if(loc==0) return 1;
	if(loc==1) return base;
	LL ks=ksm(base,loc/2);
	if(loc%2==0) return (ks*ks)%mo;
	return (((ks*ks)%mo)*base)%mo; }
bool palim(char ts[]) {
	rep(i,0,m-1)
	if((ts[i]!='\0'&&ts[2*m-1-i]!='\0')&&(ts[i]==ts[2*m-1-i]))
		return true;
	return false; }
void dfs(int u,bool select[7],int len,char pined[],int lastse) {
	if(u>n) {
		rep(i,0,2*m-len) {
			char newpin[1005]= {'\0' };
			rep(j,0,len-1) newpin[i+j]=pined[j];
			if(palim(newpin)) continue;
			int plank=0;
			rep(j,0,m-1) if(newpin[j]=='\0'&&newpin[2*m-j-1]=='\0') plank++;
			ans=(ans+ksm(2,plank))%mo; }
		return; }
	rep(i,1,n) {
		if(!select[i]) {
			select[i]=1;
			if(!lastse) {
				char newpin[1005]= {'\0' };
				strcpy(newpin,pined);
				rep(j,0,strlen(s[i])) newpin[j]=s[i][j];
				dfs(u+1,select,strlen(s[i]),newpin,i); }
			else {
				rep(j,0,strlen(s[i])) {
					if(pin[lastse][i][j]) {
						char newpin[1005]= {'\0' };
						strcpy(newpin,pined);
						rep(k,len,len-j+strlen(s[i])-1)
						newpin[k]=s[i][k+j-len];
						dfs(u+1,select,len-j+strlen(s[i]),newpin,i); } } }
			select[i]=0; } } }
int main() {
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n) scanf("%s",s[i]);
	rep(i,1,n) rep(j,1,n) if(i!=j) {
		pin[i][j][0]=1;
		rep(k,1,min(strlen(s[i]),strlen(s[j]))) {
			bool flag=1;
			rep(w,1,k) {
				int cur=strlen(s[i])-w;
				if(s[i][cur]!=s[j][cur+k-strlen(s[i])]) {
					flag=0;
					break; } }
			pin[i][j][k]=flag; } }
	bool ts[7]= {0 };
	char tp[1005]= {'\0' };
	dfs(1,ts,0,tp,0);
	printf("%lld\n",ans);
	return 0; }
