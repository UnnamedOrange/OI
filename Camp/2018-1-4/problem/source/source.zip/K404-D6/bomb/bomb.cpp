#include<cstdio>
#include<queue>
#define gc getchar()
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
using namespace std;
queue<int>q;
inline int read(){
	char c;while(c=gc,c==' '||c=='\n');int data=c-48;
	while(c=gc,c>='0'&&c<='9')data=(data<<1)+(data<<3)+c-48;return data;
}
const int N=2000011;
int n,m,x[N],y[N];
int nxt[N],las[N],to[N];
int low[N],dfn[N],st[N];
int bel[N],sz[N],deg[N],ans[N];
bool ins[N];
int times,top,hv,tot,maxans;
inline int min(int a,int b){
	return a<b?a:b;
}
inline int max(int a,int b){
	return a>b?a:b;
}
inline void add(int x,int y){
	nxt[++tot]=las[x];
	las[x]=tot;
	to[tot]=y;
}
inline void tarjan(int now){
	low[now]=dfn[now]=++times;
	ins[st[++top]=now]=1;
	for(register int e=las[now];e;e=nxt[e])
		if(!dfn[to[e]]){
			tarjan(to[e]);
			low[now]=min(low[now],low[to[e]]);
		}
		else
			if(ins[to[e]])
				low[now]=min(low[now],dfn[to[e]]);
	int u;
	if(low[now]==dfn[now]){
		bel[now]=++hv;
		++sz[hv];
		ins[now]=0;
		while(u=st[top--],u!=now){
			bel[u]=hv;
			++sz[hv];
			ins[u]=0;
		}
	}
}
inline void topsort(){
	FOR(i,1,hv)
		if(!deg[i])
			q.push(i);
	int now;
	while(!q.empty()){
		now=q.front();q.pop();
		ans[now]+=sz[now];
		for(register int e=las[now];e;e=nxt[e]){
			--deg[to[e]];
			if(!deg[to[e]])
				q.push(to[e]);
			ans[to[e]]=max(ans[to[e]],ans[now]);
		}
	}
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read();m=read();
	FOR(i,1,m){
		x[i]=read();y[i]=read();
		add(x[i],y[i]);
	}
	FOR(i,1,n)
		if(!dfn[i])
			tarjan(i);
	tot=0;
	FOR(i,1,n)
		las[i]=0;
	
	FOR(i,1,m)
		if(bel[x[i]]!=bel[y[i]]){
			add(bel[x[i]],bel[y[i]]);
			++deg[bel[y[i]]];
		}
	topsort();
	FOR(i,1,hv)
		maxans=max(maxans,ans[i]);
	printf("%d\n",maxans);
	return 0;
}
/*
5 4
1 2
2 3
3 1 
4 5
*/
