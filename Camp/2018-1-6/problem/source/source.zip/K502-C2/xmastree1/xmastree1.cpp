#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while (c = getchar(), c >= '0');
}

const int M = (int) 1e5 + 5;

int n, q, t, C[M], Head[M], tot, L[M], R[M], P[M], dfscnt;
struct Node {int to, nxt;} Edge[M << 1];

inline void Addedge(int a, int b) {
	Edge[tot] = (Node) {b, Head[a]}; Head[a] = tot++;
	Edge[tot] = (Node) {a, Head[b]}; Head[b] = tot++;
}

void dfs(int x, int f) {
	L[x] = ++dfscnt; P[dfscnt] = x;
	for (int i = Head[x]; ~i; i = Edge[i].nxt) {
		int to = Edge[i].to;
		if (to == f) continue;
		dfs(to, x);
	}
	R[x] = dfscnt;
}

namespace Subtask1 {
	
	int cnt[M];
	
	void solve() {
		int lastans = 0;
		while (q--) {
			int op; Rd(op);
			if (op == 1) {
				int x, l, r, ans = 0;
				Rd(x), Rd(l), Rd(r);
				if (t) x ^= lastans, l ^=lastans, r ^= lastans;
				for (int i = L[x]; i <= R[x]; i++) {
					cnt[C[P[i]]]++;
					if (l <= C[P[i]] && C[P[i]] <= r && cnt[C[P[i]]] == 1) ans++;
				}
				for (int i = L[x]; i <= R[x]; i++) cnt[C[P[i]]]--;
				printf("%d\n", lastans = ans);
			} else {
				int x, c;
				Rd(x), Rd(c);
				if (t) x ^= lastans, c ^= lastans;
				C[x] = c;
			}
		}
	}
	
}

namespace Subtask2 {
	
	void solve() {
		
	}
	
}

int main() {
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	Rd(n), Rd(q), Rd(t);
	for (int i = 1; i <= n; i++) Rd(C[i]);
	memset(Head, -1, sizeof(Head));
	for (int i = 1; i < n; i++) {
		int a, b;
		Rd(a), Rd(b);
		Addedge(a, b);
	}
	dfs(1, 0);
	Subtask1::solve();
	return 0;
}
