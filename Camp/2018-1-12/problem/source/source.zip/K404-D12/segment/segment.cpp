#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define MOD 998244353
#define MAXN 100000
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int n, m, k, ans, A[15], B[15];
inline int fastpow(int s, int n){int a = 1; for(; n; n&1 ? a = 1ll*a*s%MOD : 0, s = 1ll*s*s%MOD, n >>= 1); return a;}
void Robot(int i, int j, int o)
{
	if(!o){B[0] = 0; for(rint i = 1; i <= m; B[i] = B[i-1]+A[i], ans = (ans+fastpow(B[i],k))%MOD, i++); return;}
	for(rint l = i, r; l <= m; --A[l], l++)
		for(++A[l], r = max(l,j); r <= m; --A[r], Robot(l+1,r+1,o-1), ++A[r], r++);
}
/*
namespace k_1
{
	int f[355][355], g[355][355], s[355][355], t[355][355];
	void Calc()
	{
		for(rint o = 1, i, j; o <= n; o++)
		{
			for(i = m; i; i--)
			{
				for(j = m; j; s[i][j] = (f[i+1][j+1]+max(j-i,0)+s[i][j+1])%MOD, t[i][j] = (f[i+1][j+1]+max(j-i,0)+s[i][j+1])%MOD j--);
				for(j = m; j; s[i][j] = (s[i][j]+s[i+1][j])%MOD, j--);
			}
			for(i = 1; i <= m; cerr << endl, i++)	
				for(j = 1; j <= m; cerr << f[i][j] << ' ', j++);
			for(i = m; i; i--) for(j = m; j >= i; f[i][j] = s[i][j], g[i][j] = t[i][j], j--);
		}	printf("%d\n",f[1][1]);
	}
}*/
int main()
{
	freopen("segment.in","r",stdin), freopen("segment.out","w",stdout);
	n = read(), m = read(), k = read(); if(n > m) return puts("0"),0;
	if(n == 1){for(rint i = 0, j = m; i < m; ans = (ans+1ll*i*j)%MOD, i++, j--); printf("%d\n",ans); return 0;}
	else if(m <= 6){Robot(1,1,n); printf("%d\n",ans); return 0;}
	return 0;
}
