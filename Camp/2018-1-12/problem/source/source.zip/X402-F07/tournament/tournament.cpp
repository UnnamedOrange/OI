#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
int ans=0;
int n,m;
bool p[1005][1005],vis[1005][1005];
void DFS(int u,int d){
	if(d>n)return;
	else if(vis[u][d])return;
	vis[u][d]=1;
	REP(v,1,n)if(p[u][v])DFS(v,d+1);
}
bool check(){
	REP(i,1,n){
		memset(vis,0,sizeof(vis));
		DFS(i,0);
		if(vis[i][m])return 1;
	}
	return 0;
}
void dfs(int u){
	if(u>n){ans+=check();return;}
	REP(i,0,(1<<n)-1){
		bool flag=1;
		REP(j,1,n){
			p[u][j]=(i>>(j-1))&1;
			if((j<u)&&(p[j][u]^p[u][j]==0))flag=0;
		}
		if((p[u][u])||(!flag))continue;
		dfs(u+1);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
#endif
	n=read(),m=read();
	dfs(1);
	write(ans,'\n');
	return 0;
}
