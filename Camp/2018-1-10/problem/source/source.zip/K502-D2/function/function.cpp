#include <queue>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

int T, n;

namespace file{
	inline void open()
	{
		freopen("function.in", "r", stdin);
		freopen("function.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	} 
}
using namespace file;

inline int read()
{
	int a = 0;
	char ch;
	int f = 1;
	while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
	if(ch == '-')
		f = -1;
	else
	{
		a = a * 10;
		a += ch - '0';
	}
	while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
	{
		a = a * 10;
		a += ch - '0';
	}
	return a * f;
}

inline void momomo()
{
	printf("19260817\n");
}

int main()
{
	open();
	T = read();
	while(T--)
		momomo();
	close();
} 
