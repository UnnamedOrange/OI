#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<queue>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}
const int maxn=100010;
const double lxn=998244353;

int n,ecnt;

int w[maxn],out[maxn],in[maxn],head[maxn],ANS[maxn],las[maxn];

double ans;

bool vis[maxn];

struct edge{
	int u,v,next;
}E[maxn];

void addedge(int u,int v){
	E[++ecnt].u=u;
	out[u]++;in[v]++;
	E[ecnt].v=v;
	E[ecnt].next=head[u];
	head[u]=ecnt;
}

void dfs(int s){
	for(int i=head[s];i;i=E[i].next){ int v=E[i].v;
		if(!vis[v]) vis[v]=1;
		if(!ANS[E[i].u])ANS[E[i].u]++;
		if(w[v]) ANS[v]=ANS[E[i].u]+1;
		else ANS[v]=ANS[E[i].u];
		dfs(v);
	}
}

void bfs(int s){
	queue<int>q;q.push(s);
	memset(vis,0,sizeof(vis));vis[s]=1;
	while(!q.empty()){
		int x=q.front();q.pop();
		int tot=0;for(int i=head[x];i;i=E[i].next) tot++;//tot表示这个点往下总共有的边数
		for(int i=head[x];i;i=E[i].next){
			int v=E[i].v;
			las[v]=tot;
			if(!vis[v]||w[v]==1){
				double cc=(1/(double)tot);int ff=0;
				if(las[E[i].u]) cc=cc*(1/(double)las[E[i].u]);
				while(ANS[v]*cc>lxn) ff++;
				ans=ans+ANS[v]*cc-ff*lxn;
				while(ans>lxn) ans-=lxn;
				vis[v]=1;
			}
			if(in[v]+out[v]==1) break;
			q.push(v);
		}
	}
}

int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++){
		char ch=getchar();
		w[i]=ch-'0';
	}
	for(int i=1;i<n;i++){
		int u,v;
		read(u),read(v);
		addedge(u,v);
	}
	dfs(1);bfs(1);
	printf("%.0lf\n",ans);
	return 0;
}
