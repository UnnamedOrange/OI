#include<bits/stdc++.h>
using namespace std;
char s[105];
int ok[105][105];
int a;
bool search(int v,int l,int r){
	if(l==r) return false;
	if(ok[l][r]>0&&ok[l][r]<=v) return 1;
	if(ok[l][r]==-1) return 0;
	if(v==1){
		for(int i=l;i<=r;i++){
			if(s[i]!=s[r-(i-l)]) {
			ok[l][r]=v;return 1;
			}
			if(i>(l+r)/2+1) break;
		}
	}else{
		for(int i=l;i<=r;i++){
			int ans=-1;
			ans+=search(v/2,l,i);
			ans+=search(v/2,i,r);
			if(ans!=1) continue;
			ok[l][r]=v;return 1;
		}
	}
	ok[l][r]=-1;
	return false;
}
bool doit(int v){
	return search(v,0,a-1);
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int t;cin>>t;
	while(t--){
		for(int i=0;i<=105;i++) s[i]=' ';
		memset(ok,0,sizeof(ok));
		scanf("%d\n",&a);
		scanf("%s",s);
		int i;
		for( i=1;i<=10;i++){
			if(!doit(i)) continue;
			printf("%d\n",i);
			break;
		}
		if(i>10)	printf("-1\n");	
	}
	return 0;
}
