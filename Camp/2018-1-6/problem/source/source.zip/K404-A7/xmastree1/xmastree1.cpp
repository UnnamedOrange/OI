/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 100000 + 10;

int n, q, t, x, y, ind;
int c[MAXN], in[MAXN], out[MAXN], rk[MAXN], tag[MAXN];
std::vector<int> edge[MAXN];

inline void add_edge(int x, int y) {
	edge[x].push_back(y);
	edge[y].push_back(x);
}

inline void read_in() {
	R(n), R(q), R(t);
	for (int i = 1; i <= n; ++i) R(c[i]);
	for (int i = 1; i < n; ++i) R(x), R(y), add_edge(x, y);
}

inline void dfs(int cur) {
	in[cur] = ++ind, rk[ind] = cur;
	for (int p = 0; p < edge[cur].size(); ++p) {
		int v = edge[cur][p];
		if (in[v] == 0) dfs(v);
	}
	out[cur] = ind;
}

inline void solve() {
	dfs(1), memset(tag, -1, sizeof(tag));
	int ans = 0, type, u, l, r, c;
	while (q--) {
		R(type);
		if (type == 1) {
			int cnt = 0;
			R(u), R(l), R(r), (t ? (u ^= ans, l ^= ans, r ^= ans) : (0));
			for (int i = in[u]; i <= out[u]; ++i) tag[::c[rk[i]]] = q;
			for (int i = l; i <= r; ++i) if (tag[i] == q) cnt++;
			W(ans = cnt), write_char('\n');
		} else R(u), R(c), (t ? (u ^= ans, c ^= ans) : (0)), ::c[u] = c;
	}
}

int main() {
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	read_in();
	solve();
	flush();
	return 0;	
}
