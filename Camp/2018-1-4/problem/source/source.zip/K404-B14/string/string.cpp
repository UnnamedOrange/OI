#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int MAXN = 1010;
const int p = 998244353;
int n, m, ans;
char a[MAXN];
char s[6][110];
int len[6];
void check(){
	int i, j, k;
	for(i = 0; i < n; i++){
		for(j = 0; j < 2 * m; j++){
			int k;
			for(k = 0; k < len[i]; k++)
				if(s[i][k] != a[j + k]) break;
			if(k == len[i]) break;
		}
		if(j == 2 * m) break;
	}
	if(i == n) ans = (ans + 1) % p;
}
void dfs(int x){
	if(x == m) check();
	else{
		a[x] = '0'; a[2 * m - x - 1] = '1';
		dfs(x + 1);
		a[x] = '1'; a[2 * m - x - 1] = '0';
		dfs(x + 1);
	}
}
int main(){
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 0; i < n; i++) scanf("%s", s + i), len[i] = strlen(s[i]);
	check();
	dfs(0);
	printf("%d\n", ans);
	return 0;
}
