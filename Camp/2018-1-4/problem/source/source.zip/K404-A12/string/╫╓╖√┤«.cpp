#include <iostream>
#include <cstdio>
#include <cstring>
#define mod 998244353
using namespace std;
int n,m,len[15],id[15],f[1005][70][15],pl[15][15][105],tot[15][15];
bool used[15];
char a[15][105];
void upd(int &a,int &b){
	a=(a+b>=mod)?a+b-mod:a+b;
}
int main(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",a[i]+1);
		len[i]=len[i+n]=strlen(a[i]+1);
		for(int p=1;p<=len[i];p++)
			a[i+n][p]=(a[i][len[i]-p+1]=='0')?'1':'0';
	}
	for(int i=1;i<=n+n;i++){
		for(int p=1;p<=n+n;p++){
			if(i==p||i==p+n||i+n==p) continue;
			for(int j=1;j<=len[i];j++){
				if(len[i]-j+1>len[p]) continue;
				bool t=1;
				for(int k=j;k<=len[i];k++){
					if(a[i][k]!=a[p][k-j+1]){
						t=0;break;
					}
				}
				if(t) pl[i][p][++tot[i][p]]=j;
			}
			pl[i][p][++tot[i][p]]=len[i]+1;
			if(pl[i][p][1]==1&&(len[i]!=len[p]||i<p)) used[i]=used[i+n]=1;
		}
	}
	for(int i=1;i<=n+n;i++) id[i]=i,tot[0][i]=1,pl[0][i][1]=1;
	for(int i=1,o=n+n;i<=o;i++){
		if(used[i]){
			for(int p=i;p<=o;p++) id[p]=id[p+1];
			if(i<=n) n--;
		}
	}
	f[0][0][0]=1;
	for(int i=0;i<m;i++){
		for(int p=0;p<(1<<n);p++){
			for(int j=0;j<=n+n;j++){
				if(!f[i][p][j]) continue;
				for(int k=1;k<=n+n;k++){
					int x=(k>n)?k-n:k;
					if(!(p&(1<<x-1))){
						for(int P=1;P<=tot[id[j]][id[k]];P++){
							int pos=i+len[id[k]]-(len[id[j]]-pl[id[j]][id[k]][P]+1);
							upd(f[pos][p|(1<<x-1)][k],f[i][p][j]);
						}
					}
				}
			}
		}
	}
	int sum=0;
	for(int i=1;i<=n+n;i++) upd(sum,f[m][(1<<n)-1][i]);
	printf("%d\n",sum);
	return 0;
}
