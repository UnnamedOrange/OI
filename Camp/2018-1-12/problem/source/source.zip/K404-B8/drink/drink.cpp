#include<bits/stdc++.h>
#define debug(x) cerr<<#x<<"="<<x<<endl
using namespace std;
const int maxn = 2000009;

struct node{int val,idx;}b[maxn];
int pre[maxn],nxt[maxn],a[maxn];
double ans;
int n;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
bool cmp(const node &x,const node &y)
{
	if(x.val==y.val) return x.idx>y.idx;
	return x.val<y.val;
}

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","r",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read(),b[i]=(node){a[i],i};
	sort(b+1,b+1+n,cmp);
	for(int i=1;i<=n;i++) pre[i]=i-1,nxt[i]=i+1;
/*	ans=0;
	for(int i=1;i<=n;i++)
	{
		double s1=0,s2=0,p1=1,p2=1;
		for(int j=i;j>=1;j--)
		{
			if(a[j]>=a[i]) p1/=2;
			s1+=p1;
		}
		for(int j=i;j<=n;j++)
		{
			if(a[j]>a[i]) p2/=2;
			s2+=p2;
		}
		ans+=a[i]*s1*s2;
//		debug(s1);debug(s2);
	}
	ans/=(n*n);
	printf("%.10lf\n",ans);*/
	ans=0;
	for(int i=1;i<=n;i++)
	{
		double p1=1,s1=0;
		int now=b[i].idx,last;
		for(int j=1;j<=50&&now>=1;j++)
		{
			p1/=2;
			last=now;now=pre[now];
			s1+=(last-now)*p1;
		}s1+=now*p1;
		double p2=1,s2=(nxt[b[i].idx]-b[i].idx);//debug(nxt[b[i].idx]);
		now=nxt[b[i].idx];
		for(int j=1;j<=50&&now<=n;j++)
		{
			p2/=2;
			last=now;now=nxt[now];//debug(now);debug(last);
			s2+=(now-last)*p2;
		}s2+=(n-now+1)*p2;
		ans+=1.0*b[i].val*s1*s2;
		int x=b[i].idx;
		pre[nxt[x]]=pre[x];
		nxt[pre[x]]=nxt[x];
		pre[x]=nxt[x]=0;
	}
	ans/=(1.0*n*n);
	printf("%.10lf\n",ans);
	return 0;
	
}
