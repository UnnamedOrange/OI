#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<vector>
#define ll long long

using namespace std;

const int P = 998244353;

int n, k;
bool mark[55];
vector <int> G[55];

inline void Add(int &a, int b) {
	a += b;
	if (a >= P) a -= P;
}

void predfs(int x, int f, vector <int> &vec) {
	vec.push_back(x);
	for (int i = 0; i < (int) G[x].size(); i++) {
		int to = G[x][i];
		if (to == f || mark[to]) continue;
		predfs(to, x, vec);
	}
}

int dfs(int x, int v) {
	vector <int> vec; vec.clear();
	predfs(x, 0, vec);
	if (vec.size() == 1) return 1;
	int rs = 0;
	for (int i = 0; i < (int) vec.size(); i++) {
		int rt = vec[i];
		mark[rt] = true;
		int s = 1;
		for (int t = 0; t < (int) G[rt].size(); t++) {
			int to = G[rt][t];
			if (mark[to]) continue;
			int tmp = 0;
			for (int j = 1; v + j <= k; j++)
				Add(tmp, dfs(to, v + j));
			s = (ll) s * tmp % P;
		}
		Add(rs, s);
		mark[rt] = false;
	}
	return rs;
}

int main() {
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
	scanf("%d %d", &n, &k);
	for (int i = 1; i < n; i++) {
		int a, b;
		scanf("%d %d", &a, &b);
		G[a].push_back(b);
		G[b].push_back(a);
	}
	int ans = 0;
	for (int i = 1; i <= k; i++)
		Add(ans, dfs(1, i));
	printf("%d\n", ans);
	return 0;
}
