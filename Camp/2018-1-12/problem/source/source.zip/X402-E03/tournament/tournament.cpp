#include <bits/stdc++.h>
using namespace std ;
const int maxn = 10 ;
int n, m, k, deg[maxn] ;
bool g[maxn][maxn], vis[maxn], fg ;
void dfs ( int x, int stp ) {
	if (stp == k && vis[x]) {
		fg = 1 ;
		return ;
	}
	if (fg || vis[x] || stp == k) return ;
	vis[x] = 1 ;
	for ( int u = 1 ; u <= n ; u ++ )
		if (g[x][u]) dfs(u, stp+1) ;
	vis[x] = 0 ;
}
bool judge ( int x ) {
	int i, j ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = i+1 ; j <= n ; j ++, x >>= 1 )
			if (x&1) g[i][j] = 1, g[j][i] = 0 ;
			else g[i][j] = 0, g[j][i] = 1 ;
	for ( i = 1 ; i <= n ; i ++ ) {
		memset ( vis, 0, sizeof vis ) ;
		fg = 0 ;
		dfs(i, 0) ;
		if (fg) break ;
	}
	return fg ;
}
int main() {
	freopen ( "tournament.in", "r", stdin ) ;
	freopen ( "tournament.out", "w", stdout ) ;
	while (cin >> n >> k) {
		m = n*(n-1)/2 ;
		int i, S = (1<<m)-1, ans = 0 ;
		for ( i = 0 ; i <= S ; i ++ )
			if (judge(i)) ++ ans ;
		printf ( "%d\n", ans ) ;
	}
	return 0 ;
}
