#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 10;
const ll MOD = 998244353;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

ll ans;
int n, K;
bool g[MAXN][MAXN];

ll dfs(int s, int x) {
	//printf("dfs(%d, %d) {\n", s, x);
	if(x > K) {
		//printf("}0\n");
		return 0;
	}
	int i, j, k, u, v;
	bool t[10][10];
	for(i = 1; i <= n; i++) 
		for(j = 1; j <= n; j++) t[i][j] = g[i][j];
	for(k = 1; k <= n; k++) 
		for(i = 1; i <= n; i++) 
			for(j = 1; j <= n; j++) t[i][j] |= t[i][k]&t[k][j];
	ll res = 0;
	/*for(i = 1; i <= n; i++) printf("%d ", t[s][i]);
	printf("\n");*/
	for(u = 1; u <= n; u++) if(t[s][u]) {
		/*printf(">>> ");
		for(i = 1; i <= n; i++) printf("%d ", g[u][i]);
		printf("\n");*/
		/*for(i = 1; i <= n; i++) if(g[u][i] && i != u) break;
		if(i > n) continue;*/
		//printf(":%d\n", u);
		ll val = 1;
		for(v = 1; v <= n; v++) {
			if(v == u || !g[u][v]) continue;
			g[u][v] = g[v][u] = false;
			ll cnt = 0;
			for(k = 1; k+x <= K; k++) 
				cnt = (cnt+dfs(v, x+k))%MOD;
			g[u][v] = g[v][u] = true;
			val = val * cnt % MOD;
		}
		res = (res+val)%MOD;
		//printf("??? %d\n", u);
	}
	//printf("}%lld\n", res);
	return res;
}

int main() {
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);

	int i, j;

	n = read(), K = read();

	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		g[u][v] = g[v][u] = true;
	}
	for(i = 1; i <= n; i++) g[i][i] = true;

	for(j = 1; j <= K; j++) {
		ll val = dfs(1, j);
		ans = (ans+val)%MOD;
		//printf("%lld, ", val);
	}
	printf("%lld\n",  ans);
	return 0;
}
