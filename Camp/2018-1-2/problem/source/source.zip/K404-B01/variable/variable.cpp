#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <sstream>
#include <cctype>
#include <cmath>
#include <algorithm>
#define THE_BRST_PONY "Rainbow Dash"

using namespace std;
const int N=15,P=1100,INF=~0u>>1;

int T,n,W,p,q,ans;
int w[N],x[P],y[P],z[P];
int a[P],b[P],c[P],d[P],e[P],f[P];
int X[P],Y[P],R[P];

int main() {
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&T);
	while(T--) {
		ans=INF;
		scanf("%d%d%d%d",&n,&W,&p,&q);
		for(int i=0;i<p;i++)
			scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for(int i=0;i<q;i++) scanf("%d%d%d",&X[i],&Y[i],&R[i]);
		for(int s=0;s<(1<<n);s++) {
			int sum=0,ok=1;
			for(int i=0;i<n;i++) {
				if(s&(1<<i)) w[i+1]=W;
				else w[i+1]=-W;
				sum+=w[i+1];
			}
			for(int i=0;i<q&&ok;i++) {
				if(R[i]==0&&!(w[X[i]]<=w[Y[i]])) ok=0;
				if(R[i]==1&&!(w[X[i]]==w[Y[i]])) ok=0;
				if(R[i]==2&&!(w[X[i]]<w[Y[i]]))  ok=0;
			}
			for(int i=0;i<p&&ok;i++)
				sum+=a[i]*abs(w[x[i]]-w[y[i]])+b[i]*abs(w[y[i]]-w[z[i]])+c[i]*abs(w[z[i]]-w[x[i]])+d[i]*(w[x[i]]-w[y[i]])+e[i]*(w[y[i]]-w[z[i]])+f[i]*(w[z[i]]-w[x[i]]);
			if(ok) ans=min(ans,sum);
		}
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

