#include <cstdio>
#include <algorithm>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

typedef long long ll;
const int mod = 998244353;
const int N = 100010;
int n, m, k;
ll s[N], ans;

ll pow(ll a, int b)
{
	ll ans = 1;
	for(; b; b >>= 1)
	{
		if (b & 1) ans = ans * a % mod;
		a = a * a % mod;
	}
	return ans;
}

void check()
{
	FOR(i, 1, m) ans = (ans + pow(s[i], k)) % mod;
}

void dfs(int L, int R, int dep)
{
	if (dep > n) {check(); return;}
	FOR(i, L + 1, m) FOR(j, max(i, R + 1), m)
	{
		FOR(k, i, j - 1) ++s[k];
		dfs(i, j, dep + 1);
		FOR(k, i, j - 1) --s[k];
	}
}

void work1()
{
	dfs(0, 0, 1);
	printf("%lld\n", ans);
}

void work2()
{
	FOR(i, 1, m) (ans += (ll) i * (ll) (m - i)) %= mod;
	printf("%lld\n", ans);
}

ll yuu(int x)
{
	ll x1 = x + 1, x2 = x, x3 = x - 1;
	return x1 * x2 * x3 / 3 % mod;
}

ll C(int x)
{
	ll x1 = x, x2 = x - 1;
	return x1 * x2 / 2 % mod;
}

void work3()
{
	FOR(i, 1, m) (ans += C(i) * C(m - i) % mod * pow(2LL, k)) %= mod;
	FOR(i, 1, m) (ans += (ll) (m - i) * yuu(i)) %= mod;
	FOR(i, 1, m) (ans += (ll) i * yuu(m - i)) % mod;
	printf("%lld\n", ans);
}

int main()
{
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	if (n > m) {puts("0"); return 0;}
	if (m <= 6) {work1(); return 0;}
	if (n == 1) {work2(); return 0;}
	if (n == 2) {work3(); return 0;}
	return 0;
}
