#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#define ll long long
using namespace std;
int read()
{
	char ch=getchar();int x=0,f=1;
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
struct data
{
	int temp[11];
	int step;
};
data q[3700005];
int temp[55][55],n,ans,top,tail;
bool vis[55];
void out(int now)
{
	//for(int i=1;i<=n;i++)
	//{
		//cout<<temp[now][i]<<" ";
	//}
	//cout<<endl;
}

void dfs(int now,int step)
{
	//cout<<now<<" "<<step<<endl;
	if(now>n||now>=ans) return;
	int pur=0;
	for(int i=n;i;i--)
	{
		if(temp[now][i]!=i)
		{
			pur=i;
			break;
		}
	}
	if(temp[now][1]==pur)
	{
		for(int i=1;i<=pur;i++)
		{
			temp[now+1][i]=temp[now][pur-i+1];
		}
		for(int i=pur+1;i<=n;i++)
		{
			temp[now+1][i]=temp[now][i];
		}
		out(now+1);
		bool ac=1;
		for(int i=1;i<=pur;i++)
		{
			if(temp[now+1][i]!=i)
			{
				ac=0;
				break;
			}
		}
		if(ac)
		{
			ans=min(ans,step+1);
			return;
		}
		else
		dfs(now+1,step+1);
	}
	else
	{
		int pla;
		for(int i=1;i<=pur;i++)
		{
			if(temp[now][i]==pur)
			{
				pla=i;
				break;
			}
		}
		for(int i=pur+1;i<=n;i++)
		temp[now+1][i]=temp[now][i];
		for(int i=pur;i>pla;i--)
		{
			temp[now+1][pur-i+1]=temp[now][i];
		}
		for(int i=1;i<=pla;i++)
		{
			temp[now+1][pur-pla+i]=temp[now][i];
		}
		out(now+1);
		bool ac=1;
		for(int i=1;i<=pur;i++)
		{
			if(temp[now+1][i]!=i)
			{
				ac=0;
				break;
			}
		}
		if(ac)
		{
			ans=min(ans,step+2);
			return;
		}
		else
		dfs(now+1,step+2);
		for(int i=1;i<pla;i++)
		{
			temp[now+1][i]=temp[now][i];
		}
		for(int i=pla;i<=pur;i++)
		{
			temp[now+1][i]=temp[now][pur+pla-i];
		}
		out(now+1);
		ac=1;
		for(int i=1;i<=pur;i++)
		{
			if(temp[now+1][i]!=i)
			{
				ac=0;
				break;
			}
		}
		if(ac)
		{
			ans=min(ans,step+3);
			return;
		}
		else
		dfs(now+1,step+3);
	}
}
void bfs()
{
	while(top>=tail)
	{
		data x=q[tail++];
		bool ac=1;
		for(int i=1;i<=n;i++)
		{
			if(x.temp[i]!=i)
			{
				ac=0;
				break;
			}
		}
		//for(int i=1;i<=n;i++)
		//cout<<x.temp[i]<<" ";
		//cout<<endl;
		if(ac)
		{
			ans=x.step;
			return;
		}
		data t;
		for(int i=2;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				t.temp[j]=x.temp[i-j+1];
			}
			for(int j=i+1;j<=n;j++)
			{
				t.temp[j]=x.temp[j];
			}
			t.step=x.step+1;
			q[++top]=t;
		}
	}
}
int tmp[105];
void dfs2(int x)
{
	for(int i=0;i<=1;i++)
	{
		vis[x]=i;
		if(x==n)
		{
			int sum=0;
			for(int i=1;i<=n;i++)
			tmp[i]=temp[0][i];
			for(int i=1;i<=n;i++)
			{
				if(vis[i]==1)
				{
					sum++;
					for(int j=1;j<=i;j++)
					{
						tmp[j]=tmp[i-j+1];
					}
				}
			}
			bool ac=1;
			for(int i=1;i<=n;i++)
			{
				if(tmp[i]!=i)
				{
					ac=0;
					break;
				}
			}
			if(ac)
			ans=min(ans,sum);
		}
		else
		{
			dfs2(x+1);
		}
	}
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int T=read();
	while(T--)
	{
		n=read();
		data x;
		for(int i=1;i<=n;i++)
		{
			x.temp[i]=temp[0][i]=read();
		}
		ans=1000000000;top=0,tail=1;
		x.step=0;
		q[++top]=x;
		if(n>=10)
		{
			dfs(0,0);
			if(n<=16)
			dfs2(2);
		}
		else 
		{
			bfs();
		}
		cout<<ans<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
1
11
2 5 3 10 4 8 11 7 1 9 6
*/
/*253487196
2
625348719
843526719
176253489
3
143526789

*/
