#include <bits/stdc++.h>
using namespace std;

const int MAXN = 10;

struct Edge {
	int v, next;
};

int N, e_ptr, Cur, Ans, A[MAXN+10], head[MAXN+10], w[MAXN+10], r[MAXN+10]; Edge E[(MAXN<<2)+10];

template<typename T>
inline void readint(T& x) {
	T f=1, r=0; char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	x=f*r;
}

void AddEdge(int u, int v) {
	E[++e_ptr] = (Edge) { v, head[u] }; head[u] = e_ptr;
}

void AddPair(int u, int v) {
	AddEdge(u, v); AddEdge(v, u);
}

int pos(int x) {
	if(x==-1) return -1;
	for(int i=1; i<=N; i++) if(A[i]==x) return i;
	assert(false);
	return -1;
}

bool dfs(int u, int fa) {
	if(pos(fa) > pos(u)) return false;
	for(int j=head[u]; j; j=E[j].next) {
		int v = E[j].v;
		if(v == fa) continue;
		if(!dfs(v, u)) return false;
	}
	return true;
}

int main() {
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	
	int u, v;
	readint(N);
	for(int i=1; i<=N-1; i++) {
		readint(u); readint(v);
		AddPair(u, v);
	}
	for(int i=1; i<=N; i++) {
		readint(w[i]); readint(r[i]);
	}
	for(int i=1; i<=N; i++) A[i]=i;
	do {
		Cur = 0;
		for(int i=1; i<=N; i++) Cur += w[A[i]] * i;
		for(int i=1; i<=N; i++) if(r[i] && dfs(i, -1))
			Ans = max(Ans, Cur);
	} while(next_permutation(A+1, A+N+1));
	cout<<Ans;
	return 0;
}
