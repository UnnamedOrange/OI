#include <cstdio>

const int MAXN = 100000 + 10;
const int Mod = 998244353;
int N, M, K;
int A[MAXN];
int ans;

inline int fastpow_mod( int a, int b ) {
	int x = 1;
	while( b ) {
		if( b & 1 ) x = ( x * a ) % Mod;
		a = ( a * a ) % Mod, b >>= 1;
	}
	return x;
}

int main() {
	freopen( "segment.in", "r", stdin );
	freopen( "segment.out", "w", stdout );
	register int i;
	scanf( "%d%d%d", &N, &M, &K );
	for( i = 1; i < M; ++i )
		ans = ( ans + M - i ) % Mod;
	printf( "%d\n", ans );
	return 0;
}
