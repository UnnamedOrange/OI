#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>

#define minm(a,b) a<b?a:b

using namespace std;

struct rule
{
	int t1,t2;
	int kind;
}ruled[100005];

int t;
int n;
long long W;
int p;
int q;
long long a[100005],b[100005],c[100005],d[100005],e[100005],f[100005],x[100005],y[100005],z[100005];
long long h[100005];
long long w[100005];
long long ans;

bool cmp(rule r1,rule r2)
{
	return r1.t1<r2.t1;
}

long long acs(long long t1)
{
	return t1>0?t1:-t1;
}

void dfs(int loc,long long sum,int next)
{
	if(loc>n)
	{
		long long sum2=0;
		for(int i=1;i<=p;i++)
		{
			sum2+=a[i]*acs(w[x[i]]+w[y[i]])+b[i]*acs(w[y[i]]+w[z[i]])+c[i]*acs(w[z[i]]+w[x[i]]);
			sum2+=d[i]*(w[x[i]]+w[y[i]])+e[i]*(w[y[i]]+w[z[i]])+f[i]*(w[z[i]]+w[x[i]]);
		}
		if(sum+sum2<ans)
		{
			ans=sum+sum2;
		}
		return;
	}
	if(ruled[next].t1==loc)
	{
		if(ruled[next].kind==0)
		{
			if(w[ruled[next].t2]==-W)
			{
				w[loc]=-W;
				dfs(loc+1,sum-W,next+1);
				w[loc]=0;
			}
			else	
			{
				w[loc]=W;
				dfs(loc+1,sum+W,next+1);
				w[loc]=-W;
				dfs(loc+1,sum-W,next+1);
				w[loc]=0;
			}
		}
		else if(ruled[next].kind==1)
		{
			w[loc]=w[ruled[next].t2];
			dfs(loc+1,sum+w[loc],next+1);
			w[loc]=0;
		}
		else if(ruled[next].kind==2)
		{
			if(w[ruled[next].t2]==-W)
				return;
			w[loc]=-W;
			dfs(loc+1,sum-W,next+1);
			w[loc]=0;
		}
		else if(ruled[next].kind==3)
		{
			if(w[ruled[next].t2]==W)
			{
				w[loc]=W;
				dfs(loc+1,sum+W,next+1);
				w[loc]=0;
			}
			else
			{
				w[loc]=W;
				dfs(loc+1,sum+W,next+1);
				w[loc]=-W;
				dfs(loc+1,sum-W,next+1);
				w[loc]=0;
			}
		}
		else
		{
			if(w[ruled[next].t2]==W)
				return;
			w[loc]=W;
			dfs(loc+1,sum+W,next+1);
			w[loc]=0;
		}
	}
	else
		{
		w[loc]=W;
		dfs(loc+1,sum+W,next);
		w[loc]=-W;
		dfs(loc+1,sum-W,next);
		w[loc]=0;
	}

}

void ran(int loc,long long sum,int next)
{
	if(loc>n)
	{
		long long sum2=0;
		for(int i=1;i<=p;i++)
		{
			sum2+=a[i]*abs(w[x[i]]+w[y[i]])+b[i]*abs(w[y[i]]+w[z[i]])+c[i]*abs(w[z[i]]+w[x[i]]);
			sum2+=d[i]*(w[x[i]]+w[y[i]])+e[i]*(w[y[i]]+w[z[i]])+f[i]*(w[z[i]]+w[x[i]]);
		}
		if(sum+sum2<ans)
			ans=sum+sum2;
		return;
	}
	if(ruled[next].t1==loc)
	{
		if(ruled[next].kind==0)
		{
			if(w[ruled[next].t2]==-W)
			{
				w[loc]=-W;
				ran(loc+1,sum-W,next+1);
				w[loc]=0;
			}
			else	
			{
			w[loc]=((rand()%2)*2-1)*W;
			ran(loc+1,sum+w[loc],next+1);
			w[loc]=0;
			}
		}
		else if(ruled[next].kind==1)
		{
			w[loc]=w[ruled[next].t2];
			ran(loc+1,sum+w[loc],next+1);
			w[loc]=0;
		}
		else if(ruled[next].kind==2)
		{
			if(w[ruled[next].t2]==-W)
				return;
			w[loc]=-W;
			ran(loc+1,sum-W,next+1);
			w[loc]=0;
		}
		else if(ruled[next].kind==3)
		{
			if(w[ruled[next].t2]==W)
			{
				w[loc]=W;
				dfs(loc+1,sum+W,next+1);
				w[loc]=0;
			}
			else
			{
				w[loc]=((rand()%2)*2-1)*W;
				dfs(loc+1,sum+w[loc],next+1);
				w[loc]=0;
			}
		}
		else
		{
			if(w[ruled[next].t2]==W)
				return;
			w[loc]=W;
			ran(loc+1,sum+W,next+1);
			w[loc]=0;
		}
	}
	else
	{
		w[loc]=((rand()%2)*2-1)*W;
		ran(loc+1,sum+w[loc],next);
		w[loc]=0;
	}

}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	srand((int)new char);
	scanf("%d",&t);
	while(t--)
	{
		ans=99999999999999;
		scanf("%d%lld%d%d",&n,&W,&p,&q);
		for(int i=1;i<=p;i++)
			scanf("%lld%lld%lld%lld%lld%lld%lld%lld%lld",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for(int i=1;i<=q;i++)
		{
			scanf("%d%d%d",&ruled[i].t1,&ruled[i].t2,&ruled[i].kind);
			if(ruled[i].t1<ruled[i].t2)
			{
				int tem=ruled[i].t1;
				ruled[i].t1=ruled[i].t2;
				ruled[i].t2=tem;
				if(ruled[i].kind!=1)
					ruled[i].kind+=3;
			}
		
		}
		sort(ruled+1,ruled+1+q,cmp);
		if(n<=1)
		{
			dfs(1,0,1);
			printf("%lld\n",ans);
		}
		else
		{
			for(int i=0;i<1000;i++)
				ran(1,0,1);
			printf("%lld\n",ans);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
