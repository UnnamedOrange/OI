#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cstdio>
#include <queue>
#include <cmath>
using namespace std;

struct edge
{
	int v;
	int next;
};

const int MOD = 998244353;
long long ans;
int n, k;
int first[20], fa[20], lab[20]; 
bool visit[100000000];
bool del[20], ok;
edge e[120];

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

void addedge(int u, int v)
{
	static int ctr = 0;
	e[ctr] = (edge){v, first[u]};
	first[u] = ctr;
	++ctr;
}

int Random(int x)
{
	return rand() % (k + 1) + x + 1;
}

void dfs(int s, int f, int x)
{
	//cerr << s << " " << f << endl;
	if (ok)
		return;
	vector<int> U;
	for (int i = first[s]; i != -1; i = e[i].next)
	{
		if (del[i])
			continue;
		U.push_back(e[i].v);
	}
	if (U.empty())
		return;
	int u = rand() % U.size();
	u = U[u];
	fa[u] = f;
	lab[u] = x;
	for (int i = first[u]; i != -1; i = e[i].next)
	{
		if (ok)
			return;
		if (del[i])
			continue;
		del[i] = del[i ^ 1] = true;
		if (x < k)
			dfs(e[i].v, u, Random(x));
		else
		{
			ok = true;
			return;
		}
	}
}

int main()
{
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
	memset(first, -1, sizeof first);
	srand((unsigned long long)(new char));
	n = read();
	k = read();
	for (int i = 1; i < n; ++i)
	{
		int u = read(), v = read();
		addedge(u, v);
		addedge(v, u);
	}
	int limit;
	if (n <= 4)
		limit = 80000;
	else if (n + k <= 11)
		limit = 60000;
	else
		limit = 35000;
	for (int i = 0; i < limit; ++i)
	{
		NEW:;
		ok = false;
		memset(del, 0, sizeof del);
		memset(fa, 0, sizeof fa);
		memset(lab, 0, sizeof lab);
		dfs(rand() % n + 1, 0, Random(0));
		long long hashval = 0;
		for (int i = 1; i < n + 1; ++i)
			hashval = (hashval + 65535 + fa[i] * 10007 % MOD) % MOD;
		for (int i = 1; i < n + 1; ++i)
		{
			if (lab[i] > k)
				goto NEW;
			hashval = (hashval + 10492 + lab[i] * 50003 % MOD) % MOD;
		}
		hashval = (hashval + 99957) % 100000000;
		if (!visit[hashval])
		{
			++ans;
			if (ans > MOD)
				ans -= MOD;
			visit[hashval] = true;
		}
	}
	printf("%lld\n", ans % MOD);
	fclose(stdin);
	fclose(stdout);
}
