#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while(c = getchar(), c >= '0');
}

const int M = (int) 1e6 + 5;
const int P = (int) 1e9 + 7;

struct Node {
	int mx, cnt;
	Node() {
		mx = -1, cnt = 0;
	}
} dp[M];

int n, C[M], D[M], mx[M];

inline void Add(int &a, int b) {
	a += b;
	if (a >= P) a -= P;
}

inline void Check(Node &a, Node b) {
	if (b.mx + 1 > a.mx) a.mx = b.mx + 1, a.cnt = b.cnt;
	else if (b.mx + 1 == a.mx) Add(a.cnt, b.cnt);
}

namespace Subtask1 {
	
	void solve() {
		dp[0].mx = 0, dp[0].cnt = 1;
		for (int i = 1; i <= n; i++) {
			int mxc = C[i], mid = D[i];
			mx[i] = n + 1;
			for (int j = i; j >= 1; j--) {
				mxc = max(mxc, C[j]), mid = min(mid, D[j]);
				if (mxc > mid || i - j + 1 > mid) break;
				if (mx[j] < dp[i].mx - 1) break;
				if (mxc > i) break;
				if (mxc <= i - j + 1 && i - j + 1 <= mid) Check(dp[i], dp[j - 1]);
			}
			mx[i] = max(mx[i - 1], dp[i].mx);
		}
		if (~dp[n].mx) printf("%d %d\n", dp[n].mx, dp[n].cnt);
		else puts("-1");
	}
	
}

int main() {
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
	Rd(n);
	for (int i = 1; i <= n; i++) Rd(C[i]), Rd(D[i]);
	Subtask1::solve();
	return 0;
}
