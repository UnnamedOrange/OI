#include <bits/stdc++.h>

typedef long long int int64;
static const int64 mod = 998244353LL;
int perm[100003],inv[100003];
bool vis[100003];
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n % 2 != 0) {
		printf("0\n");
		return 0;
	}
	int a = 0,b = 0;
	for(int i = 1;i <= n;++i) {
		scanf("%d",&perm[i]);
		if(perm[i] == 0) {
			continue;
		}
		if(inv[perm[i]] != 0) {
			printf("0\n");
			return 0;
		}
		inv[perm[i]] = i;
	}
	for(int i = 1;i <= n;++i) if(!vis[i]) {
		vis[i] = true;
		int cnt = 1;
		int j;
		for(j = perm[i];!vis[j] && j != 0;j = perm[j]) {
			vis[j] = true;
			++cnt;
		}
		if(j == i) {
			if(cnt % 2 != 0) {
				printf("0\n");
				return 0;
			} else
				continue;
		} else {
			for(j = inv[i];j != 0 && !vis[j];j = inv[j]) {
				vis[j] = true;
				++cnt;
			}
			if(cnt % 2 == 0)
				++a;
			else
				++b;
		}
	}
	int64 ans = 1;
	while(a > 0) {
		ans = ans * (a + b) % mod;
		--a;
	}
	while(b > 0) {
		ans = ans * (b - 1) % mod * (b - 1) % mod;
		b -= 2;
	}
	printf("%lld\n",ans);
}
