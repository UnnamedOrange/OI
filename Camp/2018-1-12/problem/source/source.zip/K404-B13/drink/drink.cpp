#include<bits/stdc++.h>
using namespace std;
#define N 1005
int n,x[N];
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		scanf("%d",&x[i]);
	double ans=0;

	for(int i=1;i<=n;i++)
	for(int j=i;j<=n;j++){
		int y[N],cnt=0;
		double sum=0;
		for(int p=i;p<=j;p++)
		 y[++cnt]=x[p];
		sort(y+1,y+cnt+1);
		for(int k=1;k<=cnt;k++){
			sum=(sum+y[k])/	2;
		}
		ans+=sum;			
	}
	printf("%lf",ans/n/n);
	return 0;
}
