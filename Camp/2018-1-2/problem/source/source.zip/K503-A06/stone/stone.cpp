#include<cstdio>
#include<cstring>
using namespace std;
#define N 7
#define rep(i,j,k) for(i=j;i<=k;++i)
int n,m,i,j,k,a,b;
int x[N],y[N],pw[N],p[2],f[10000][2],ans[5];//0��ʾ��û�з��ʣ�1��ʾ����˱�ʤ��2��ʾ����˱ذ� 
void read(int &p){
	p=0; char x=getchar(); 
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
}
int getpos(int s,int k){
	return (s/pw[k-1])%6;
}
int dp(int s,int psn){
	int i;
	if(f[s][psn]) return f[s][psn];
	rep(i,1,n)
	if(getpos(s,i)>=p[psn]){
		int tmp=dp(s-pw[i-1]*p[psn],psn^1);
		if(tmp==2) {
			f[s][psn]=1;
			return 1;
		}
	}
	return f[s][psn]=2;
} 
void work(int k,int sta){
	if(k>n){//5λ��6������
		int re1,re2; 
		p[0]=a; p[1]=b;
		memset(f,0,sizeof(f));
		re1=dp(sta,0);
		p[0]=b; p[1]=a;
		memset(f,0,sizeof(f));
		re2=dp(sta,0);
		if((re1==1)&&(re2==1)){
			ans[3]++;
		}else
		if((re1==1)&&(re2==2)){
			ans[1]++;
		}else
		if((re1==2)&&(re2==1)){
			ans[2]++;
		}else
		if((re1==2)&&(re1==2)){
			ans[4]++;
		}
		return ;
	}
	work(k+1,sta*6);
	work(k+1,sta*6+x[k]);
} 
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	read(n); read(a); read(b);
	pw[0]=1; 
	rep(i,1,6) pw[i]=pw[i-1]*6;
	rep(i,1,n) read(x[i]);
	work(1,0);
	printf("%d %d %d %d\n",ans[1],ans[2],ans[3],ans[4]);
	return 0;
} 
