#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
#define begin Begin
#define next Next
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10;
int begin[maxn],next[maxn<<1],to[maxn<<1],e;
void add_edge(int x,int y){
	to[++e]=y;
	next[e]=begin[x];
	begin[x]=e;
}
int c[maxn];
int fa[maxn];
int dfs_prepare(int x,int ff){
	fa[x]=ff;
	for(int i=begin[x];i;i=next[i]){
		if(to[i]==ff) continue;
		dfs_prepare(to[i],x);
	}
}
bool vis[maxn];
int dfs(int x){
	vis[c[x]]=1;
	for(int i=begin[x];i;i=next[i]){
		if(to[i]==fa[x]) continue;
		dfs(to[i]);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
#endif
	int n=read(),q=read(),t=read();
	REP(i,1,n) c[i]=read();
	REP(i,1,n-1){
		int x=read(),y=read();
		add_edge(x,y);
		add_edge(y,x);
	}
	int lstans=0;
	dfs_prepare(1,0);
	while(q--){
		int ty=read();
		if(ty==1){
			int x=read(),l=read(),r=read();
			if(t) x^=lstans,l^=lstans,r^=lstans;
			REP(i,l,r) vis[i]=0;
			dfs(x);
			int ans=0;
			REP(i,l,r) ans+=vis[i];
			printf("%d\n",ans);
			lstans=ans;
		}
		else if(ty==2){
			int x=read(),v=read();
			if(t) x^=lstans,t^=lstans;
			c[x]=v;
		}
	}
	return 0;
}
