#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const int mod=1e9+7;
const int maxn=5e5+5;
struct node
{
	int l,r;
	bool operator<(const node &tmp)const
	{
		return l<=tmp.l;
	}
};
struct node ai[maxn];
int n,m,xi[maxn],bi[maxn],num,bit[25],val[maxn];
ll ans;
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
inline int getl(int x)
{
	int l=1,r=m,res=m+1,mid;
	while(l<=r)
	{
		mid=l+r>>1;
		if(xi[mid]>=x)
		{
			res=mid;
			r=mid-1;
		}
		else
			l=mid+1;
	}
	return res;
}
inline int getr(int x)
{
	int l=1,r=m,res=0,mid;
	while(l<=r)
	{
		mid=l+r>>1;
		if(xi[mid]<=x)
		{
			res=mid;
			l=mid+1;
		}
		else
			r=mid-1;
	}
	return res;
}
inline int check(int x)
{
	int res=0;
	for(short i=1;i<=n;i++)
		if(bit[i]&x)
			res|=val[i];
	return res==((1<<n)-1);
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	read(n);
	read(m);
	for(int i=1;i<=n;i++)
	{
		read(ai[i].l);
		read(ai[i].r);
	}
	for(int i=1;i<=m;i++)
		read(xi[i]);
	std::sort(xi+1,xi+m+1);
	m=std::unique(xi+1,xi+m+1)-xi-1;
	for(int i=1;i<=n;i++)
	{
		ai[i].l=getl(ai[i].l);
		ai[i].r=getr(ai[i].r);
		if(ai[i].l<=ai[i].r)
			ai[++num]=ai[i];
	}
	n=num;
	std::sort(ai+1,ai+n+1);
	if(n<=20)
	{
		bit[1]=1;
		for(int i=2;i<=20;i++)
			bit[i]=bit[i-1]<<1;
		for(int i=1;i<=n;i++)
			val[i]=(1<<ai[i].r)-(1<<(ai[i].l-1));
		for(int S=1;S<(1<<n);++S)
			if(check(S))
				++ans;
		printf("%lld\n",ans);
	}
	else
	{
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
