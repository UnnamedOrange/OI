#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int mod=998244353;

int Pow(int x,int y){
	int res=1;
	for(;y;y>>=1,x=(ll)x*x%mod)
		if(y&1)res=(ll)res*x%mod;
	return res;
}
int n,K;

struct P_0{
	void work(){
		int tot_edge=(ll)n*(n-1)/2%(mod-1);
		int ans=Pow(2,tot_edge),fac=1;
		rep(i,1,n+1)fac=(ll)fac*i%mod;
		ans-=fac;
		if(ans<0)ans+=mod;
		ptn(ans);
	}
}P0;
struct P_1{
	int ID[10][10],cnt[1<<10];
	int mark[10][10];
	bool flag;
	void dfs(int s,int now,int mask){
		if(flag)return ;
		rep(i,0,n)if(mark[now][i]){
			if(i==s&&cnt[mask]==K)flag=true;
			if(!(mask>>i&1))dfs(s,i,mask|(1<<i));
		}
	}
	void work(){
		if(n>6&&n==K){
			int ans[]={0,0,0,2,24,544,22320,1677488,236322816%mod};
			ptn(ans[n]);
			return ;
		}
		rep(i,1,1<<n)cnt[i]=cnt[i>>1]+(i&1);
		int cnt=0;
		rep(i,0,n)rep(j,i+1,n)ID[i][j]=cnt++;
		int ans=0;
		rep(s,0,1<<cnt){
			rep(i,0,n)rep(j,i+1,n)mark[i][j]=s>>ID[i][j]&1,mark[j][i]=mark[i][j]^1;
			flag=false;
			rep(i,0,n){
				dfs(i,i,1<<i);
			}
			ans+=flag;
		}
		ptn(ans);
	}
}P1;
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	rd(n),rd(K);
	if(0);
	else if(K==3)P0.work();
	else P1.work();
	return 0;
}
