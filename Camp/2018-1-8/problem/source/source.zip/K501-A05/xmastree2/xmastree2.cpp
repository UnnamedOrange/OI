#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MAXN = 10;

int n, m;

vector<int> adj[MAXN + 5];

int w[MAXN + 5], r[MAXN + 5];

inline void input()
{
	n = read<int>();
	for(int i = 1; i < n; ++i)
	{
		int u = read<int>() - 1, v = read<int>() - 1;
		adj[u].push_back(v), adj[v].push_back(u);
	}

	for(int i = 0; i < n; ++i) w[i] = read<int>(), r[i] = read<int>();
}

int f[1 << MAXN];

inline int dfs(int S)
{
	if(S == (1 << MAXN) - 1) return 0;
	if(~f[S]) return f[S];

	f[S] = 0;
	for(int i = 0; i < n; ++i)
		if((S >> i) & 1)
			for(auto j : adj[i])
				if(!((S >> j) & 1))
					chkmax(f[S], dfs(S | (1 << j)) + (__builtin_popcount(S) + 1) * w[j]);
	return f[S];
}

inline void solve()
{
	int ans = 0;
	memset(f, -1, sizeof f);
	for(int i = 0; i < n; ++i)
		if(r[i]) chkmax(ans, dfs(1 << i) + w[i]);
	printf("%d\n", ans);
}

int main()
{
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);

	input();
	solve();

	return 0;
}

