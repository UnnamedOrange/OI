#include<bits/stdc++.h>
using namespace std;
bool h[8000];
int n,q,t,fir[50000],size,fa[50000],col[50000];
struct edge{int u,v,nex;}e[220000];
void add(int u,int v){e[++size].u=u;e[size].v=v;e[size].nex=fir[u];fir[u]=size;}
void build(int x,int fath){
	fa[x]=fath;
	for (int i=fir[x];i;i=e[i].nex)
	if (e[i].v!=fath) build(e[i].v,x);
}
void work(int x){
	h[col[x]]=1;
	for (int i=fir[x];i;i=e[i].nex)
	if (e[i].v!=fa[x]) work(e[i].v);
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d %d %d",&n,&q,&t);
	int lasans=0;
	for (int i=1;i<=n;i++)
	scanf("%d",col+i);
	for (int i=1;i<n;i++){
		int x,y;
		scanf("%d %d",&x,&y);
		add(x,y);add(y,x);
	}
	build(1,0);
	for (int i=1;i<=q;i++){
		int typ,l,r,x,c,ans=0;;
		scanf("%d",&typ);
		if (typ==1) scanf("%d%d%d",&x,&l,&r);
		else scanf("%d%d",&x,&c);
		if (t){l^=lasans;r^=lasans;x^=lasans;c^=lasans;}
		if (typ==1){
			memset(h,0,sizeof(h));
			work(x);
			for (int i=l;i<=r;i++) ans+=h[i];
			printf("%d\n",ans);
		}
		else col[x]=c;
		if (typ==1) lasans=ans;
	}
	return 0;
}
