#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while(!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while(isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n = n * sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 1222222;
int n, m, l, r;
int pa[N][22], dep[N], vis[N], deg[N], d[N];
struct edge{int to, nxt;} g[N], ng[N], tg[N];
int ghead[N], gtail, nghead[N], ngtail, tghead[N], tgtail;
vector<int> in[N];

void add(int l, int r){g[++gtail] = (edge){r, ghead[l]}, ghead[l] = gtail;}
void add2(int l, int r){ng[++ngtail] = (edge){r, nghead[l]}, nghead[l] = ngtail;}
void add3(int l, int r){tg[++tgtail] = (edge){r, tghead[l]}, tghead[l] = tgtail;}
void dfs(int x, int fa){
	pa[x][0] = fa, dep[x] = dep[fa] + 1, vis[x] = 1;
	rep(i, 1, 20) pa[x][i] = pa[pa[x][i-1]][i-1];
	for (int p = ghead[x]; p; p = g[p].nxt){
		int v = g[p].to;
		if (!vis[v]) add3(x, v), dfs(v, x);
	}
}
int depth(vector<int>& v){
	queue<int> que;
	for (int i = 0; i < v.size(); ++i) d[v[i]] = 0;
	for (int i = 0; i < v.size(); ++i)
		if (!deg[v[i]]) que.push(v[i]), d[v[i]] = 1;
	while(!que.empty()){
		int h = que.front(); que.pop();
		for (int p = nghead[h]; p; p = ng[p].nxt){
			int v = ng[p].to;
			if (!--deg[v]) que.push(v), d[v] = d[h] + 1;
		}
	}
	int ret = -INF;
	for (int i = 0; i < v.size(); ++i) ret = max(ret, d[v[i]]);
	return ret;
}
int jump(int x, int d){
	per(i, 20, 0) if (dep[x] - (1 << i) >= d) x = pa[x][i];
	return x;
}
int bfs(int x){
	queue<int> que; que.push(x); 
	int ret = 0; vis[x] = 1;
	while(!que.empty()){
		int t = dep[que.front()];
		vector<int> v; ngtail = 0;
		for (; !que.empty()&&dep[que.front()] == t; que.pop())
			v.pb(que.front());
//		for (int i = 0; i < v.size(); ++i) cerr << v[i] << ' '; cerr << endl;
		for (int i = 0; i < v.size(); ++i)
			nghead[v[i]] = 0, deg[v[i]] = 0;
		for (int i = 0; i < v.size(); ++i){
			int x = v[i];
			for (int p = 0; p < in[x].size(); ++p){
				int y = in[x][p]; if (vis[y]) continue;
				int z = jump(y, t);
				if (z != x) add2(z, x), deg[x]++;
			}
		}
		ret += depth(v);
		for (int i = 0; i < v.size(); ++i) vis[v[i]] = 1;
		for (int i = 0; i < v.size(); ++i){
			int x = v[i];
			for (int p = tghead[x]; p; p = tg[p].nxt){
				int y = tg[p].to;
				if (!vis[y]) que.push(y);
			}
		}
	}
	return ret;
}

int main(){
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	read(n), read(m);
	rep(i, 1, m) read(l), read(r), add(l, r), in[r].pb(l);
	rep(i, 1, n) if (!vis[i])
		add(0, i), add3(0, i), dfs(i, 0);
	memset(vis, 0, sizeof(vis));
	printf("%d\n", bfs(0) - 1);
	return 0;
}

