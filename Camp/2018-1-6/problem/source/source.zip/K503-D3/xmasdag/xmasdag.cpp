#include <cstdio>

inline int read(){
    char ch=getchar(); int x=0,sgn=1;
    for (;ch<'0'||ch>'9';ch=getchar())
        if (ch=='-') sgn=-1;
    while (ch>='0'&&ch<='9')
        x=x*10+ch-'0',ch=getchar();
    return x*sgn;
}

#define N (int)1e5+10
#define P 998244353

int f[5010][5010];
int f1[N],ans[N],q[N];

struct DAG{
	int head[N],to[N<<1],next[N<<1],ind[N],cnt;
	void addedge(int x, int y){
		to[++cnt]=y,next[cnt]=head[x],
		head[x]=cnt,ind[y]++;
	}
}G;

int power(int x, int p){
	long long s=1,k=x;
	for (;p;k=k*k%P,p>>=1)
		if (p&1) s=s*k%P;
	return s%P;
}

int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	int n=read(),m=read(),k=read();
	while (m--){
		int x=read(),y=read();
		G.addedge(x,y);
	}
	if (k==1){
		int l=0,r=-1;
		for (int i=1;i<=n;i++)
			if (!G.ind[i]) q[++r]=i,f1[i]=1;
		for (;l<=r;l++)
			for (int i=G.head[q[l]];i;i=G.next[i])
				if (G.ind[G.to[i]]){
					G.ind[G.to[i]]--;
					f1[G.to[i]]+=f1[q[l]];
					ans[G.to[i]]+=f1[q[l]]+ans[q[l]];
					if (!G.ind[G.to[i]]) q[++r]=G.to[i];
				}
		for (int i=1;i<=n;i++)
			printf("%d\n",ans[i]);
	}
	else if (n<=5000){
		int l=0,r=-1;
		for (int i=1;i<=n;i++)
			if (!G.ind[i]) q[++r]=i,f[i][0]=1;
		for (;l<=r;l++)
			for (int i=G.head[q[l]];i;i=G.next[i])
				if (G.ind[G.to[i]]){
					G.ind[G.to[i]]--;
					for (int j=0;j<=n;j++)
						f[G.to[i]][j+1]+=f[q[l]][j];
					if (!G.ind[G.to[i]]) q[++r]=G.to[i];
				}
		for (int i=1;i<=n;i++)
			for (int j=1;j<=n;j++)
				if (f[i][j])
					ans[i]=((long long)ans[i]+(long long)f[i][j]*power(j,k))%P;
		for (int i=1;i<=n;i++)
			printf("%d\n",ans[i]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

