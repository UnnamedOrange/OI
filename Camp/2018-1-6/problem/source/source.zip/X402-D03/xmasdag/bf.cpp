#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;
const int MAXN = 2010, MAXM = 5010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int st[MAXN], to[MAXM];
int nxt[MAXM], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

int n, m, k, q[MAXN];
int indeg[MAXN];
ll dp[MAXN][MAXM], pk[MAXM];

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i, j, l = 0, r = 0;

	n = read(), m = read(), k = read();
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		Add(u, v), indeg[v]++;
	}
	dp[1][0] = 1;
	for(i = 1; i <= n; i++) 
		if(!indeg[i]) q[++r] = i;
	while(l < r) {
		int u = q[++l];
		for(i = st[u]; i; i = nxt[i]) {
			int v = to[i];
			for(j = 0; j < m; j++) 
				update(dp[v][j+1], dp[u][j]);
			indeg[v]--;
			if(!indeg[v]) q[++r] = v;
		}
	}

	for(j = 0; j <= m; j++) pk[j] = qpow(j, k);
	for(i = 1; i <= n; i++) {
		ll res = 0;
		for(j = 0; j <= m; j++) 
			res = (res+pk[j]*dp[i][j]%MOD)%MOD;
		printf("%lld\n", res);
	}
	return 0;
}
