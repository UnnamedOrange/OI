#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int T;
int len;
char s[100010];

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	while(T!=0)
	{
		T--;
		bool vis=0;
		int num=0;
		scanf("%d",&len);
		scanf("%s",s+1);
		for(int i=1;i<=len;i++)
		  if(s[i]==s[1])
		    num++;
		int mid=(len+1)/2;
		for(int i=1;i<=mid;i++)
		  if(s[i]!=s[len-i+1])
		  {
		  	vis=1;
		  	break;
		  }
		if(vis==1)
		{
		  printf("1\n");
		  continue;
	    }
	    vis=0;
	    for(int i=1;i<=len-2;i++)
	      if(s[i]!=s[i+2])
	      {
	      	vis=1;
	      	break;
		  }
		if(vis==1&&num!=len-1)
		  printf("2\n");
		else
		  printf("-1\n");
	}
	fclose(stdin);
	fclose(stdout);
}
