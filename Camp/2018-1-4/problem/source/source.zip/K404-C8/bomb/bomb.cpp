#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=1000005;

int n,m;
int hd[N],tot,pr[N],to[N];
void addedge(int u,int v) {to[++tot]=v;pr[tot]=hd[u];hd[u]=tot;}

int id[N],cnt,dfn[N],low[N],tt,s[N],top,num[N];bool in[N];

void dfs(int u) 
{
	in[u]=true;
	dfn[u]=low[u]=++tt;
	s[++top]=u;
	
	for (int i=hd[u];i;i=pr[i]) 
	if (dfn[to[i]]==0) 
	{
		dfs(to[i]);
		low[u]=min(low[u],low[to[i]]);
	}else if (in[to[i]]) low[u]=min(low[u],dfn[to[i]]);
	if (low[u]==dfn[u]) 
	{
		++cnt;
		int t;
		do
		{
			t=s[top--];
			id[t]=cnt;
			num[cnt]++;
			in[t]=false;
		}while (t!=u);
	}
}

int HD[N],TO[N],PR[N],TT;
void ADD(int u,int v) {TO[++TT]=v;PR[TT]=HD[u];HD[u]=TT;}
int f[N];
int work(int u)
{
//	printf("%d\n",u);
	if(f[u]) return f[u];
	f[u]=num[u]; 
	for (int i=HD[u];i;i=PR[i]) 
	f[u]=max(f[u],work(TO[i])+num[u]);
	return f[u];
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);;
	scanf("%d%d",&n,&m);
	for (int u,v,i=1;i<=m;i++) 
	{
		scanf("%d%d",&u,&v);
		addedge(u,v);
	}
	for (int i=1;i<=n;i++) if (dfn[i]==0) dfs(i);
	
//	for (int i=1;i<=n;i++) printf("id[%d]=%d\n",i,id[i]);
	
	for (int u=1;u<=n;u++) 
		for (int i=hd[u];i;i=pr[i]) 
		if (id[u]!=id[to[i]]) ADD(id[u],id[to[i]]);
	
	int ans=0;
	for (int i=1;i<=cnt;i++) ans=max(ans,work(i));
	printf("%d\n",ans);
	return 0;
}
/*
8 9
1 2
2 3
3 4
1 5
5 3
5 6
6 4
6 7
7 8

10 12
1 2
1 3
2 4
3 4
4 5
4 6
6 7
5 7
7 8
7 9
8 10
9 10
*/
