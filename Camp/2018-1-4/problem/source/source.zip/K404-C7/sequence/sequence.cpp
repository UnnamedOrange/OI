#include <bits/stdc++.h>
using namespace std;

int Encode(int n, const int* d) {
	int r = 0;
	for (int i = n - 1; i; --i) {
		r = r * n + d[i] - 1;
	}
	return r;
}

void Decode(int n, int v, int* d) {
	int f[30];
	for (int i = 1; i <= n; ++i) {
		f[i] = 1;
	}
	for (int i = 1; i < n; ++i) {
		d[i] = v % n + 1;
		v /= n;
		f[d[i]] = 0;
	}
	d[n] = find(f + 1, f + n + 1, 1) - f;
}

int Eval(int n, const int* d) {
	int v = 0;
	for (int i = n; i; --i) {
		if (d[i] == i) {
			++v;
		} else {
			break;
		}
	}
	return v;
}

int Mini(int n, const int* d) {
	int ans = 0;
	for (int i = 1; i < n; ++i) {
		ans += (abs(d[i] - d[i + 1]) != 1);
	}
	return ans;
}

int n;

struct Node {
	int value;
	int eval;
	int cnt;
	int mini;
	Node(int v, int c) {
		value = v;
		int arr[30];
		Decode(n, v, arr);
		eval = Eval(n, arr);
		cnt = c;
		mini = Mini(n, arr);
	}
	Node(const int* d, int c) {
		value = Encode(n, d);
		eval = Eval(n, d);
		cnt = c;
		mini = Mini(n, d);
	}
};

inline bool operator<(const Node& a, const Node& b) {
	return a.eval == b.eval ? a.cnt > b.cnt : a.eval < b.eval;
}

int guess(int n, const int* d) {
	int dat[30];
	for (int i = 1; i <= n; ++i) {
		dat[i] = d[i];
	}
	int ans = 0;
	for (int i = n; i; --i) {
		if (dat[i] != i) {
			if (dat[1] != i) {
				reverse(dat + 1, find(dat + 1, dat + n + 1, i));
				++ans;
			}
			reverse(dat + 1, dat + i + 1);
			++ans;
		}
	}
	return ans;
}

int fact(int n) {
	return n == 1 ? 1 : n * fact(n - 1);
}

int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t;
	cin >> t;
	cerr << fixed << setprecision(8);
	while (t--) {
		cin >> n;
		int target = 0;
		for (int i = n - 2; ~i; --i) {
			target = target * n + i;
		}
		int dat[30];
		for (int i = 1; i <= n; ++i) {
			cin >> dat[i];
		}
		priority_queue<Node> pq;
		pq.push(Node(dat, 0));
		int ans = n << 1;
		map<int, int> mp;
		
		int cnt = 0;
		int fct = fact(n);
		
		while (pq.size()) {
			Node nd = pq.top();
			pq.pop();
			//cerr << nd.eval << ' ' << flush;
			if (target == nd.value) {
				ans = nd.cnt;
				continue;
			}
			if (nd.cnt + nd.mini >= ans) {
				continue;
			}
			map<int, int>::iterator it = mp.find(nd.value);
			if (it != mp.end()) {
				if (it->second < nd.cnt) {
					continue;
				} else {
					it->second = nd.cnt;
				}
			} else {
				mp[nd.value] = nd.cnt;
				++cnt;
				if (cnt % 1000 == 0) {
					cerr << '\r' << (double)cnt / fct;
				}
			}
			int g = guess(n, dat);
			if (g + nd.cnt < ans) {
				ans = g + nd.cnt;
			}
			if (nd.cnt < ans) {
				Decode(n, nd.value, dat);
				int k = n - nd.eval;
				for (int i = 1; i <= k; ++i) {
					reverse(dat + 1, dat + i + 1);
					pq.push(Node(dat, nd.cnt + 1));
					reverse(dat + 1, dat + i + 1);
				}
			}
		}
		cout << ans << '\n';
	}
}
