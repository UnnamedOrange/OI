#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const int inf=0x3f3f3f3f;
const LL mod=1e9+7;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
}
int n,mn[N],mx[N];
int dp[N],ans[N];
inline void Add(int&x,int y){x=x+y<mod?x+y:x+y-mod;}
int main()
{
	file();
	read(n);
	For(i,1,n)read(mn[i]),read(mx[i]);
	mem(dp,-1);
	dp[0]=0;ans[0]=1;
	For(i,1,n)
	{
		int Min=mn[i],Max=mx[i],cnt=0;
		rFor(j,i-1,0)
		{
			cnt++;
			if(Min<=cnt&&cnt<=Max&&dp[j]!=-1)
			{
				if(chkmax(dp[i],dp[j]+1))
					ans[i]=ans[j];
				else if(dp[i]==dp[j]+1)
					Add(ans[i],ans[j]);
			}
			chkmax(Min,mn[j]),chkmin(Max,mx[j]);
			if(cnt>Max)break;
		}
	}
	printf("%d ",dp[n]);
	if(dp[n]!=-1)printf("%d\n",ans[n]);
	return 0;
}
