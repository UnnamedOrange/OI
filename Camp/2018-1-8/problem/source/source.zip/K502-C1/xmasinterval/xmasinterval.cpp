#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
using namespace std;

struct inter
{
	int l;
	int r;
	int ctr;
};

const int MAXN = 5e5 + 100, MOD = 1e9 + 9;
int n, m;
long long ans = 0;
int b[MAXN], s[MAXN], d[MAXN];
long long f[MAXN], two[MAXN];
inter a[MAXN], c[MAXN];

namespace Force
{
	bool check()
	{
		int g[22];
		memset(g, 0, sizeof g);
		g[1] = s[1];
		for (int i = 2; i < m + 1; ++i)
			g[i] = s[i] + g[i - 1];
		for (int i = 1; i < m + 1; ++i)
		{
			if (g[i] <= 0)
				return false;
		}
		return true;
	}
	void dfs(int p)
	{
		if (p == n + 1)
		{
			ans += check();
			if (ans > MOD)
				ans -= MOD;
		}
		else if (p < n + 1)
		{
			++s[a[p].l];
			--s[a[p].r + 1];
			dfs(p + 1);
			--s[a[p].l];
			++s[a[p].r + 1];
			dfs(p + 1);
		}
	}
	void main()
	{
		dfs(1);
		printf("%lld\n", ans);
	}
}

namespace Dp
{
	bool compare(const inter &u, const inter &v)
	{
		if (u.l == v.l)
			return u.r < v.r;
		else
			return u.l < v.l;
	}
	int binary(int x)
	{
		int l = 0, r = n - 1;
		while (l < r)
		{
			int mid = (l + r + 1) / 2;
			if (a[mid].l <= x)
				l = mid;
			else
				r = mid - 1;
		}
		return l;
	}
	void main()
	{
		sort(a + 1, a + n + 1, compare);
		int sz = 0;
		for (int i = 1; i < n + 1; ++i)
		{
			if (a[i].l == a[i - 1].l && a[i].r == a[i - 1].r)
				++c[sz].ctr;
			else
			{
				++sz;
				c[sz].l = a[i].l;
				c[sz].r = a[i].r;
				c[sz].ctr = 1;
			}
		}
		f[0] = 1;
		for (int i = 0; i < m + 1; ++i)
		{
			for (int j = 1; c[j].l <= i + 1 && j < sz + 1; ++j)
			{
				if (c[j].r > i)
				{
					f[c[j].r] += (two[c[j].ctr] - 1) * f[i] % MOD;
					f[c[j].r] %= MOD;
				}
			}
		}
		printf("%lld\n", f[m]);
	}
}

int binary(int l, int r, int x)
{
	while (l < r)
	{
		int mid = (l + r + 1) / 2;
		if (b[mid] <= x)
			l = mid;
		else
			r = mid - 1;
	}
	return l;
}

void init()
{
	sort(b + 1, b + m + 1);
/*	int sz = 0;
	for (int i = 1; i < m + 1; ++i)
	{
		if (b[i] != b[i - 1])
		{
			++sz;
			d[sz] = b[i];
		}
	}
	m = sz;
	for (int i = 1; i < m + 1; ++i)
		b[i] = d[i];*/
	for (int i = 1; i < n + 1; ++i)
	{
		int l = binary(1, m, a[i].l - 1), r = binary(1, m, a[i].r);
		a[i].l = l;
		a[i].r = r;
	}
	two[0] = 1;
	for (int i = 1; i < n + 1; ++i)
		two[i] = two[i - 1] * 2 % MOD;
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	n = read();
	m = read();
	for (int i = 1; i < n + 1; ++i)
	{
		a[i].l = read();
		a[i].r = read();
	}
	for (int i = 1; i < m + 1; ++i)
		b[i] = read();
	init();
	if (n <= 20)
		Force::main();
	else
		Dp::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
