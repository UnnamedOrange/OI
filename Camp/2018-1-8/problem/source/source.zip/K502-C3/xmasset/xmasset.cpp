#include<cstdio>
#include<cstdlib>
int read(){
	int fl=1,x=0;
	char c;
	for(c=getchar();(c<'0'||c>'9')&&c!='-';c=getchar());
	if(c=='-'){fl=-1;c=getchar();}
	for(x=0;c>='0'&&c<='9';c=getchar()){
		x=x*10+c-'0';
	}
	return x*fl;
}
int type, N;
int code[10][10]={
//x\y0 1 2 3 4 5 6 7 8 9
	{0,1,2,1,1,1,2,3,2,3},
	{5,0,2,2,4,5,2,5,2,4},
	{4,3,0,1,4,1,4,3,3,4},
	{5,3,5,0,4,5,4,5,3,4},
	{5,3,5,2,0,5,2,3,3,3},
	{4,3,2,2,4,0,4,3,2,4},
	{5,1,5,1,1,1,0,5,3,3},
	{4,1,2,1,4,1,4,0,2,4},
	{4,1,5,1,1,1,4,5,0,4},
	{5,1,5,1,1,1,2,5,2,0}
};
bool to_x[11][6]={0};
void init(){
    for(int i=0;i<10;++i){
    	for(int j=0;j<10;++j){
    		to_x[i][code[i][j]]=1;
    	}
    }
}

int encode(int x, int y){
	int res=0;
	while(x%10==y%10){
		++res;
		x/=10;
		y/=10;
	}
	x%=10;
	y%=10;
	return res*5+code[x][y];
}

bool decode(int q, int h){
    int tp=(h-1)/5;
    h=(h-1)%5+1;
    while(tp--){
    	q/=10;
    }
    q%=10;
    return to_x[q][h];
}

int main()
{
    int T;
    scanf("%d%d%d",&type,&N,&T);
    init();
    while(T--){
        int x,y;
        x=read(),y=read();
        if(type==1)
            printf("%d\n", encode(x,y));
        else
        	if(decode(x,y)){
        		printf("yes\n");
        	} else{
        		printf("no\n");
        	}
    }
}
