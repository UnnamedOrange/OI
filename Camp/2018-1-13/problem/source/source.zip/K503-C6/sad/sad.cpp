#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>

using namespace std;
typedef long long ll;
const ll mod = 998244353;
struct edge{
	int to, nxt;
}e[100005];

int h[100005], cnt;    

void addedge(int x, int y){
	cnt++; e[cnt].to = y; e[cnt].nxt = h[x]; h[x] = cnt;
	cnt++; e[cnt].to = x; e[cnt].nxt = h[y]; h[y] = cnt;
}

int n;
char ch[100005];

ll f[100005], g[100005];
ll inv[100005];
ll qpow(ll x, ll y){
	ll ret = 1;
	for(; y; y >>= 1, x = x * x % mod){
		if(y & 1) ret = ret * x % mod;
	}
	return ret;
}

void dfs(int x, int fa){
	int flag = 0;
	for(int i = h[x]; i; i = e[i].nxt){
		if(e[i].to == fa) continue;
		flag ++;
	}
	if(flag == 0){
		f[x] = 1; g[x] = 0;
		return;
	}
	ll df = 0, dg = 0;
	for(int i = h[x]; i; i = e[i].nxt){
		if(e[i].to == fa) continue;
		dfs(e[i].to, x);
		df = df + f[e[i].to]; dg += g[e[i].to];
	}
	if(x == 1){
		df = df % mod * inv[flag] % mod;
		dg = dg % mod * inv[flag] % mod;
	}else{
		df = df * inv[flag + 1] % mod;
		dg = dg * inv[flag + 1] % mod;
	}
	ll t = 1;
//	printf("%lld %lld\n", df, dg);
	t = (t - dg + mod) % mod;
	f[x] = (df + 1) % mod * qpow(t, mod - 2) % mod;
	g[x] = 0;
	if(x != 1) g[x] = inv[flag + 1] * qpow(t, mod - 2) % mod;
//	printf("%d %lld %lld\n", x, f[x], g[x]);
}

int main(){
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	
	scanf("%d", &n);
	scanf("%s", ch + 1);
	for(int i = 1; i < n; i ++){
		int x, y;
		scanf("%d%d", &x, &y);
		addedge(x, y);
	}
	inv[1] = 1;
	for(int i = 2; i <= n; i ++){
		inv[i] = (-(mod / i) * inv[mod % i] % mod + mod) % mod;
	}
	dfs(1, 0);
	printf("%lld\n", f[1]);
	return 0;
}
