﻿《算法竞赛入门经典》代码仓库

第八章习题代码

注意：有些题目并没有在书中出现，但是仍然有一定的启发意义，所以一并放在这里，供读者参考。

所有代码中都写了题目大意。

UVa11100 The Trip, 2007
UVa10905 Children's Game
UVa10718 Bit Mask
UVa11054 Wine trading in Gergovia
UVa10954 Add All
UVa10763 Foreign Exchange
UVa10340 All in All
UVa10391 Compound Words
UVa10487 Closest Sums
UVa270   Lining Up
UVa10714 Ants
UVa10041 Vito's Family
UVa10026 Shoemaker's Problem
UVa10670 Work Reduction
UVa10700 Camel trading
UVa108   Maximum Sum
UVa507   Jill Rides Again
