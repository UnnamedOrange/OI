#include<iostream>
#include<cstdio>
#define LL long long
using namespace std;
int gcd(int a,int b){
	while(b^=a^=b^=a%=b);
	return a;
}
#ifdef __Brute__
LL solve(LL n){
	LL ans=0;
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n/i;++j){
			if(gcd(i,j)==1){
				ans+=n/i/j;
			}
		}
	}
	return ans;
}
#endif
#ifndef __AC__
int p[1500000+10]={0};
void proc(int n){
	for(int i=2;i<=n;++i){
		if(!p[i]){
			for(int j=i;j<=n;j+=i){
				++p[j];
			}
		}
	}
}
LL solve(LL n){
	long long ans=0;
	for(int i=1;i<=n;++i){
		 ans+=(n/i)*(1<<p[i]);
	}
	return ans;
}
#endif
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int Ti;
	scanf("%d",&Ti);
	LL N;
	if(Ti==0){
		printf("\n");
		return 0;
	}
	proc(1001000);
	while(Ti--){
		scanf("%d",&N);
		printf("%lld\n",solve(N));
	}
}
