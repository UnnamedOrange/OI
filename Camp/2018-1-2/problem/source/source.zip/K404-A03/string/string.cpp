//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
const int maxn=100+7;
int T,n,dp[maxn][maxn];
char s[maxn*1000];

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

int main() {
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	T=read();
	while(T--) {
		n=read();
		scanf("%s",s+1);
		memset(dp,-1,sizeof(dp));
		for(int i=1;i<=n;++i) for(int j=i+1;j<=n;++j) {
			for(int k=0;i+k<j-k;++k) if(s[i+k]!=s[j-k]) {
				dp[i][j]=1; break;
			}
		}
		for(int len=2;len<n;++len) for(int i=1;i<=n-len;++i) {
			int j=i+len;
			if(dp[i][j]==1) continue;
			for(int k=i+1;k<j-1;++k) if((~dp[i][k])&&(~dp[k+1][j])){
				if(dp[i][j]==-1||dp[i][j]>dp[i][k]+dp[k+1][j]) dp[i][j]=dp[i][k]+dp[k+1][j];
			}
		}
		printf("%d\n",dp[1][n]);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
2
7
abcdcba
3
xxx
*/
