#include <cstdio>
#include <algorithm>

using namespace std;

int read(){
	int x=0,sgn=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar())
		if (ch=='-') sgn=-1;
	while (ch>='0'&&ch<='9')
		x=x*10+ch-'0',ch=getchar();
	return x*sgn;
}

int a[10000],b[10000];

int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int n=read();
	for (int i=1;i<=n;i++)
		a[i]=read();
	double ans=0;
	for (int i=1;i<=n;i++)
		for (int j=i;j<=n;j++){
			for (int k=i;k<=j;k++)
				b[k]=a[k];
			sort(b+i,b+j+1);
			double x=0;
			for (int k=i;k<=j;k++)
				x=(x+b[k])/2;
			ans+=x;
		}
	printf("%.12lf",ans/(n*n));
	fclose(stdin);
	fclose(stdout);
	return 0;
}

