#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MOD = 998244353;

int n, m, K;



int qpow ( int a, int b )
{
	LL base = a, ans = 1;
	while ( b ){
		if ( b & 1 ) ( ans *= base ) %= MOD;
		( base *= base ) %= MOD;
		b >>= 1;
	}
	return ans;
}

int add ( int x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
	return x;
}

void addv ( int &x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
}

int dec ( int x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
	return x;
}

void decv ( int &x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
}



namespace task1
{
	const int MAXN = 357;
	
	int itc[MAXN][MAXN][MAXN], cl[MAXN], cr[MAXN];
	int C[MAXN][MAXN];
	
	void work ()
	{
		lp ( i, 0, MAXN ){
			C[i][0] = C[i][i] = 1;
			lp ( j, 1, i ) C[i][j] = add ( C[i-1][j], C[i-1][j-1] );
		}
		
		lpi ( i, 0, n ) lpi ( j, 0, n ) itc[i][j][0] = 1;
		lpi ( k, 1, m ){
			lpi ( i, 1, n ){
				lpi ( j, i, n ){
					addv ( itc[i][j][k], itc[i-1][j-1][k-1] );
				}
			}
			lpi ( i, 1, n ){
				lpi ( j, 1, n ){
					addv ( itc[i][j][k], dec ( add ( itc[i-1][j][k], itc[i][j-1][k] ), itc[i-1][j-1][k] ) );
				}
			}
//			lpi ( i, 0, n ){
//				lpi ( j, 0, n ){
//					cout << i << " " << j << " " << k << " " << itc[i][j][k] << endl;
//				}
//			}
		}
		
		int ans = 0;
		lpi ( i, 1, n ){
			lpi ( j, 1, m ){
				lpi ( l, 0, m-j ){
					cl[l] = cr[l] = 0;
					lpi ( k, 1, i-j+1 ){
//						cerr << "L : " << i << " " << j << " " << k << " " << l << " " << C[i-k+1][j] << " " << itc[k-1][i][l] << endl;
						addv ( cl[l], SC ( LL, C[i-k][j-1] ) * itc[k-1][i][l] % MOD );
					}
					lpi ( k, i+j, n ){
//						cerr << "R : " << i << " " << j << " " << k << " " << l << " " << C[k-i][j] << " " << itc[n-k][n-i][l] << endl;
						addv ( cr[l], SC ( LL, C[k-i-1][j-1] ) * itc[n-k][n-i][l] % MOD );
					}
				}
				lpi ( k, 0, m-j ){
//					cerr << "A : " << i << " " << j << " " << k << " " << cl[k] << " " << cr[m-j-k] << endl;
					addv ( ans, SC ( LL, cl[k] ) * cr[m-j-k] % MOD * qpow ( j, K ) % MOD );
				}
			}
		}
		
		cout << ans << endl;
	}
}

namespace task2
{
	void work ()
	{
		--n;
		LL ans = 0;
		lpi ( i, 1, n ) ans += SC ( LL, i ) * ( n - i + 1 );
		cout << ans % MOD << endl;
	}
}

namespace task3
{
	const int MAXN = 100007;
	
	LL pv[MAXN], val[MAXN];
	
	void work ()
	{
		cerr << "task3" << endl;
		
		lpi ( i, 1, n ){
			pv[i] = ( pv[i-1] + ( - SC ( LL, i ) * ( i + 1 ) / 2 + i ) % MOD + MOD ) % MOD;
			val[i] = ( pv[i] + i * i * ( i + 1 ) / 2 ) % MOD;
		}
		
		lpi ( i, 1, n ) cerr << i << " " << pv[i] << " " << val[i] << endl;
		
		int ans = 0;
		lpi ( i, 1, n ){
			addv ( ans, qpow ( 2, K ) * ( ( SC ( LL, i ) * ( i - 1 ) / 2 % MOD ) * ( SC ( LL, n - i + 1 ) * ( n - i ) / 2 % MOD ) % MOD ) % MOD );
			addv ( ans, ( val[i-1] * ( n - i + 1 ) + val[n-i] * i ) % MOD );
		}
		
		cout << ans << endl;
	}
}



void init ();
void input ();
void work ();



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "segment" );
}

void input ()
{
	scanf ( "%d%d%d", &m, &n, &K );
}

void work ()
{
	if ( m > n ){
		printf ( "0\n" );
		return;
	}
	
	if ( m == 1 ) task2::work ();
//	else if ( m == 2 ) task3::work ();
	else task1::work ();
}
