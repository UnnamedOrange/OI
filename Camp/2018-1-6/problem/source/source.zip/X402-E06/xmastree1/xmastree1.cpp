#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 100000;

int n, q, t;
vector<int> G[N + 5];

int col[N + 5], seq[N + 5];
int dfn[N + 5], efn[N + 5], dfs_clock;

void dfs(int u, int f) {
    seq[dfn[u] = ++ dfs_clock] = col[u];
    for(int i = 0; i < int(G[u].size()); ++i) if(G[u][i] ^ f) dfs(G[u][i], u);
    efn[u] = dfs_clock;
}

namespace no_modify {

    const int SZ = N * 20;

    int rt[N + 5], cnt;
    int lc[SZ + 5], rc[SZ + 5], sum[SZ + 5];

#define mid ((l+r) >> 1)

    int query(int x, int l, int r, int s, int t) {
        if(s <= l && r <= t) { return sum[x]; }
        
        int ans = 0;
        if(s <= mid) ans += query(lc[x], l, mid, s, t);
        if(mid < t) ans += query(rc[x], mid+1, r, s, t);

        return ans;
    }
    int merge(int x, int y, int l, int r) {
        if(!x || !y) return x | y;

        if(l == r) {
            sum[x] = (sum[x] | sum[y]);
            return x;
        }

        lc[x] = merge(lc[x], lc[y], l, mid);
        rc[x] = merge(rc[x], rc[y], mid+1, r);
        sum[x] = sum[lc[x]] + sum[rc[x]];
        return x;
    }
    void modify(int& x, int l, int r, int c) {
        if(!x) x = ++ cnt;
        if(l == r) { sum[x] |= 1; return; }

        if(c <= mid) 
            modify(lc[x], l, mid, c);
        else 
            modify(rc[x], mid+1, r, c);

        sum[x] = sum[lc[x]] + sum[rc[x]];
    }

    void Dfs(int u, int f = 0) {
        modify(rt[u], 1, n, col[u]);
        for(int i = 0; i < int(G[u].size()); ++i) if(G[u][i] ^ f) {
            Dfs(G[u][i], u);
            rt[u] = merge(rt[u], rt[G[u][i]], 1, n);    
        } 
    }

    void solve() {
        Dfs(1, 0);
        for(int i = 1; i <= q; ++i) {
            static int op, u, l, r, lans = 0;
            read(op);

            if(op == 1) {
                read(u); u ^= t * lans;
                read(l); l ^= t * lans;
                read(r); r ^= t * lans; lans = 0;
                printf("%d\n", lans = query(rt[u], 1, n, l, r));
            } 
        }
    }
}

void bf() {
    dfs(1, 0);
    static int vis[N + 5];
    for(int i = 1; i <= q; ++i) {
        static int op, u, l, r, lans = 0;
        read(op);

        if(op == 1) {
            read(u); u ^= t * lans;
            read(l); l ^= t * lans;
            read(r); r ^= t * lans; lans = 0;
            for(int j = dfn[u]; j <= efn[u]; ++j) if(vis[seq[j]] != i) {
                vis[seq[j]] = i;
                if(seq[j] >= l && seq[j] <= r) ++ lans;
            }
            printf("%d\n", lans);
        } else {
            read(u); u ^= t * lans;
            read(l); l ^= t * lans; seq[dfn[u]] = l;
        }
    }
}

int main() {
    freopen("xmastree1.in", "r", stdin);
    freopen("xmastree1.out", "w", stdout);

    read(n), read(q), read(t);
    for(int i = 1; i <= n; ++i) read(col[i]);
    for(int i = 1; i < n; ++i) {
        static int x, y;
        read(x), read(y);
        G[x].pb(y), G[y].pb(x);
    }

    if(n <= 8000) bf(); else no_modify::solve();

    return 0;
}
