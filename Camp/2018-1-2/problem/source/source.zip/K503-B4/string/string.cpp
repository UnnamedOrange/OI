#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
const int maxn=1e5+5;
int T,n,tag;
char str[maxn],str1[maxn],str2[maxn];
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
inline bool check(char *s,int num)
{
	if(num==0)
		return false;
	int mid=num>>1;
	for(int i=1;i<=mid;i++)
		if(s[i]!=s[num-i+1])
			return false;
	return true;
}
void dfs(int deep,int n1,int n2)
{
	if(deep==n+1)
	{
		if(!check(str1,n1)&&!check(str2,n2))
			tag=true;
		return;
	}
	str1[n1+1]=str[deep];
	dfs(deep+1,n1+1,n2);
	if(tag)
		return;
	str2[n2+1]=str[deep];
	dfs(deep+1,n1,n2+1);
	if(tag)
		return;
}
void solve1()
{
	if(!check(str,n))
	{
		puts("1");
		return;
	}
	tag=false;
	dfs(1,0,0);
	if(tag)
		puts("2");
	else
		puts("-1");
}
bool All()
{
	char tmp=str[1];
	for(int i=1;i<=n;i++)
		if(tmp!=str[i])
			return false;
	return true;
}
void solve2()
{
	if(!check(str,n))
		puts("1");
	else if(All())
		puts("-1");
	else if(n%2)
	{
		char tmp=str[1];
		int k=n>>1,res=1;
		for(int i=1;i<=k;i++)
			if(tmp!=str[k]||str[k]!=str[n-k+1])
			{
				res=0;
				break;
			}
		if(res&&tmp!=str[k+1])
			puts("-1");
		else
			puts("2");
	}
	else
		puts("2");
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	read(T);
	while(T--)
	{
		read(n);
		scanf("%s",str+1);
		if(n<=10)
			solve1();
		else
			solve2();
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
