#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int t,n;
int pre[3628810];
int x[30],fac[11],tmp[11],q[3628810][11];
bool flag;
bool vis[3628810],mark[11];
int cal()
{
    int ret=0;
    memset(mark,0,sizeof(mark));
    for(int i=1; i<=n; i++)
    {
        int cnt=0;
        for(int j=1; j<tmp[i]; j++)
            if(!mark[j])
                cnt++;
        ret+=cnt*fac[n-i];
        mark[tmp[i]]=true;
    }
    return ret;
}
int solve()
{
    memset(vis,0,sizeof(vis));
    cin>>n;
    for(int i=1; i<=n; i++)
        cin>>q[1][i],tmp[i]=q[1][i];
    vis[cal()]=true;
    int hd=1,tl=1;
    while(hd<=tl)
    {
        for(int i=1; i<=n; i++)
            tmp[i]=q[hd][i];
        for(int i=2; i<=n; i++)
        {
            reverse(&tmp[1],&tmp[i+1]);
            int id=cal();
            if(!id)
                return q[hd][0]+1;
            if(!vis[id])
            {
                vis[id]=true;
                tl++;
                pre[tl]=hd;
                q[tl][0]=q[hd][0]+1;
                for(int i=1; i<=n; i++)
                    q[tl][i]=tmp[i];
            }
            reverse(&tmp[1],&tmp[i+1]);
        }
        hd++;
    }
    return -1;
}
int main()
{
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
    fac[0]=1;
    for(int i=1; i<=10; i++)
        fac[i]=fac[i-1]*i;
    cin>>t;
    while(t--)
        printf("%d\n",solve());
    return 0;
}
