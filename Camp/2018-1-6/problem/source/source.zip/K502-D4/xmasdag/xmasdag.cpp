#include<bits/stdc++.h>
#define N 100005
#define mo 998244353
using namespace std;
int n,m;
long long ans[N];
int k;
int qd[5*N];
int qc[5*N];
int head[N],tot;
struct E{
	int to,next;
}edge[N*2];
long long ksm(long long base,int loc){
	if(loc==0) return 1;
	else if(loc==1) return base;
	long long ks=ksm(base,loc/2);
	if(loc%2==0) return (ks*ks)%mo;
	return (((ks*ks)%mo)*base)%mo;
}
void addedge(int t1,int t2){
	tot++;
	edge[tot].to=t2;
	edge[tot].next=head[t1];
	head[t1]=tot;
}
void work(){
	int h,t;
	qd[h=t=1]=1;
	qc[1]=0;
	while(h<=t){
		int u=qd[h];
		int tc=qc[h++];
		for(int i=head[u];i;i=edge[i].next){
			int v=edge[i].to;
			t++;
			qd[t]=v;
			qc[t]=tc+1;
			ans[v]=(ans[v]+ksm(tc+1,k))%mo;
		}
	}
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%lld",&n,&m,&k);
	while(m--){
		int t1,t2;
		scanf("%d%d",&t1,&t2);
		addedge(t1,t2);
	}
	work();
	for(int i=1;i<=n;i++)
		printf("%lld\n",ans[i]);
	return 0;
}
