#include<queue>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=100005,mod=998244353,inf=2147483647;
typedef long long LL;
int head[maxn],dis[maxn],Ans[maxn],cnt[maxn];
bool INQ[maxn];
int num,n,m,k,F,G;
queue<int> q;
struct cp{
	int to,next;
}edge[maxn<<1];
LL ksm(LL a,LL b){
	if(a==b&&a==0) return 1;
	LL ans=1;
	a%=mod;
	while(b>0){
		if(b%2==1) ans=(ans*a)%mod;
		b>>=1,a=(a*a)%mod;
	}
	return ans;
}
inline void add(int u,int v){
	edge[++num].to=v;
	edge[num].next=head[u];
	head[u]=num;
}
void BFS(){
	for(int i=1;i<=n;i++) dis[i]=inf>>1;
	INQ[1]=1;
	q.push(1);
	dis[1]=0;
	while(!q.empty()){
		int u=q.front();
		q.pop();
		INQ[u]=0;
		for(int i=head[u];i;i=edge[i].next){
			int v=edge[i].to;
			cnt[v]++;
			Ans[v]+=ksm(Ans[u]+cnt[u],k);
			if(!INQ[v]){
				q.push(v);
				INQ[v]=1;
			}
		}
	}
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&F,&G);
		add(F,G);
	}
	BFS();
	for(int i=1;i<=n;i++) printf("%d\n",Ans[i]);
	return 0;
}
