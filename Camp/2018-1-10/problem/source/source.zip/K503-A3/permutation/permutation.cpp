#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
#define pr pair<int, int>
#define x first
#define y second
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while (!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while (isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n *= sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 122222;
const int MOD = 998244353;
int n, ans;
int a[N], p[N], vis[N];

void upd(int& a, int b){a += b; if (a >= MOD) a -= MOD;}
namespace sp{
	int main(){
		if (n & 1){puts("0"); return 0;}
		int s = 1;
		for (int i = 2; i <= n; i += 2){
			s = (ll)s * (i - 1) % MOD;
		}
		cout << (ll)s * s % MOD << endl;
		return 0;
	}
};

int main(){
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	read(n);
	bool flg = true;
	rep(i, 1, n) read(a[i]), p[i] = i, flg &= !a[i];
	if (flg){sp::main(); return 0;}
	int ans = 0;
	do{
		bool flg = true;
		rep(i, 1, n) if (a[i]&&p[i] != a[i]) flg = false;
		if (!flg) continue;
		memset(vis, 0, sizeof(vis)); flg = true;
		rep(i, 1, n) if (!vis[i]){
			int cnt = 1; vis[i] = 1;
			for (int j = p[i]; j != i; j = p[j])
				cnt++, vis[j] = 1;
			if (cnt & 1) flg = false;
		}
		if (flg) upd(ans, 1);
	} while(next_permutation(p + 1, p + n + 1));
	printf("%d\n", ans);
	return 0;
}
