#include<iostream>
#include<cstdio>
#include<cstring>

namespace nym
{
	typedef long long ll;
	const int N=101010,MOD=998244353;
	ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}

	int begin[N],next[N*2],to[N*2];
	int w[N];
	int n,e;

	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}
	
	void initialize()
	{
		static char tmp[N];
		scanf("%d",&n);
		scanf("%s",tmp+1);
		for(int i=1;i<=n;i++)
			w[i]=tmp[i]-'0';
		for(int i=1,u,v;i<n;i++)
			scanf("%d%d",&u,&v),add(u,v);
	}

	int Pb[N],Pe[N],Eb[N],Ee[N];

	void dfs(int p=1,int h=0)
	{
		int cnts=0;
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h)dfs(q,p),cnts++;
		ll pb,pe,eb,ee,x=inv(cnts);

		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h)
			{
				pb=(pb+Pb[q])%MOD;
				pe=(pe+Pe[q])%MOD;
			}
		pb=pb*x%MOD,pe=pe*x%MOD;
	}
}

int main()
{
	
}
