cas=1
while true; do
	./gen || break
	./sequence1 || break
	./sequence || break
	diff ./sequence.out ./sequence1.out || break
	echo $cas
	cas=`expr $cas + 1`
done
