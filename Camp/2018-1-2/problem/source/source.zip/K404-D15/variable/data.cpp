#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

int v[233333];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

int s[233];

int main(){
	srand(time(NULL)+clock());
	int cases=10; printf("%d\n",cases);
	while (cases--){
		int n=15,w=rand()%1000+1,p=20,q=20;
		printf("%d %d %d %d\n",n,w,p,q);
		for (int i=1;i<=n;i++) v[i]=(rand()%2?1:-1)*w;
		for (int i=1;i<=p;i++){
			int x=rand()%n+1,y=rand()%n+1,z=rand()%n+1;
			int a=rand()%1000+1,b=rand()%1000+1,c=rand()%1000+1;
			int d=rand()%1000+1,e=rand()%1000+1,f=rand()%1000+1;
			printf("%d %d %d %d %d %d %d %d %d\n",x,y,z,a,b,c,d,e,f);
		}
		for (int i=1;i<=q;i++){
			int x=rand()%n+1,y=rand()%n+1;
			if (v[x]>v[y]) swap(x,y);
			printf("%d %d ",x,y); int cnt=0;
			if (v[x]<=v[y]) s[++cnt]=0;
			if (v[x]==v[y]) s[++cnt]=1;
			if (v[x]<v[y]) s[++cnt]=2;
			printf("%d\n",s[rand()%cnt+1]);
		}
	}
	return 0;
}
