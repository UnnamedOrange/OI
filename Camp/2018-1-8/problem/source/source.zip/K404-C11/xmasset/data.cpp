#include <bits/stdc++.h>
#include <windows.h>

struct InputOutputStream {
    FILE *fin, *fout;
    static const int IN_LEN = 1 << 18 | 1;
    char ibuf[IN_LEN], *is, *it;
    inline char read() {
        return (is == it) && (it = (is = ibuf) + fread(ibuf, 1, IN_LEN, fin)),
                is == it ? -1 : *is++;
    }

    template <typename T>
    inline void read(T &x) {
        static char c;
        static bool iosig;
        for (c = read(), iosig = false; !isdigit(c); c = read()) {
            if (c == -1) return;
            iosig |= c == '-';
        }
        for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
        iosig && (x = -x);
    }

    inline int read(char *buf) {
        register int s = 0;
        register char c;
        while (c = read(), isspace(c) && c != -1)
            ;
        if (c == -1) {
            *buf = 0;
            return -1;
        }
        do
            buf[s++] = c;
        while (c = read(), !isspace(c) && c != -1);
        buf[s] = 0;
        return s;
    }

    static const int OUT_LEN = 1 << 18 | 1;

    char obuf[OUT_LEN], *oh;

    inline void print(char c) {
        (oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, fout), oh = obuf);
        *oh++ = c;
    }

    template <typename T>
    inline void print(T x) {
        static int buf[21], cnt;
        if (x != 0) {
            (x < 0) && (print('-'), x = -x);
            for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
            while (cnt) print((char)buf[cnt--]);
        } else {
            print('0');
        }
    }

    inline void print(const char *s) {
        for (; *s; s++) print(*s);
    }

    inline void flush() {
        fwrite(obuf, 1, oh - obuf, fout);
    }

    ~InputOutputStream() {
        flush();
    }

    template <typename T>
    inline InputOutputStream &operator>>(T &x) {
        read(x);
        return *this;
    }

    template <typename T>
    inline InputOutputStream &operator<<(const T &x) {
        print(x);
        return *this;
    }

    inline void init() {
        is = it = NULL;
        oh = obuf;
    }
} io1, io2;

int a[2000000 + 9];

int main() {
    io1.fout = fopen("xmasset.in", "w");
    io2.fout = fopen("xmasset.ans", "w");
    io1.init();
    io2.init();
    char *t = new char;
    srand((long long)t * GetTickCount() ^ time(0));
    delete t;
    io1 << "1\n920 2000000\n";
    for (register int i = 1, x, y; i <= 2000000; i++) {
        do {
            x = rand() % 920 + 1, y = rand() % 920 + 1;
        } while (x == y);
        if (rand() & 1) {

            io1 << x << ' ' << (a[i] = y) << '\n';
            io2 << "no\n";
        } else {
            io1 << (a[i] = x) << ' ' << y << '\n';
            io2 << "yes\n";
        }
        
    }
    io1.flush();
    io2.flush();
    fclose(io1.fout);
    fclose(io2.fout);
    io1.init();
    io2.init();
    system("xmasset.exe < xmasset.in > xmassettmp.out");
    io1.fin = fopen("xmassettmp.out", "r");
    io1.fout = fopen("xmasset2.in", "w");
    io1 << "2\n920 2000000\n";
    for (register int i = 1, x; i <= 2000000; i++) {
        io1 >> x;
        if (x > 20) {
            std::cerr << "NO";
            exit(0);
        }
        io1 << a[i] << ' ' << x << '\n';
    }
}