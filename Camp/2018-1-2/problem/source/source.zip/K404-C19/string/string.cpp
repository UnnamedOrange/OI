#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define o 300005
using namespace std;
char s[o],s1[o];
int len,r[o],T,n;
void init(){
	len=2*n+1;
	s[0]='@';
	for(int i=1;i<=2*n;i+=2){
		s[i]='$';
		s[i+1]=s1[i/2];
	}
	s[2*n+1]='$';
	s[2*n+2]='&';
}
void solve(){
	int right=0,mid=0;
	for(int i=1;i<=len;i++){
		int x;
		if(right<i) x=1;
		else x=min(right-i,r[2*mid-i]);
		while(s[i+x]==s[i-x]) x++;
		if(x+i>right){
			right=i;
			mid=i;
		}
		r[i]=x;
	}
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		scanf("%s",s1);
		init();
		solve();
		int pos=(len+1)>>1,ans=-1;
		if(r[pos]+pos-1==len){	
			for(int i=3;i<len;i+=2){
				int a=(i+1)>>1,b=(i+len)>>1;
				if(a-r[a]>0&&(b+r[b]-1<len)){
					ans=2;
					break;
				}
			}
			printf("%d\n",ans);
		}
		else printf("1\n");
	}
}

