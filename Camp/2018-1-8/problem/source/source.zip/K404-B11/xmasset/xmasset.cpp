#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;

int encode(int x,int y){ 
	int t=1;
	while(x&&x%2==y%2)t++,x/=2,y/=2;
	return (x%2)*10+t;
}
bool decode(int q,int h){
	int m1=h%10,m2=h/10;
	for(int i=1;i<=m1;i++){
		if(!q)return 0;
		if(i==m1){
			if(q%2==m2)return 1;
			return 0;
		}
		q/=2;
	}
}

int main()
{
	int t,n,T,a,b;
	scanf("%d%d%d",&t,&n,&T);
	while(T--){
		scanf("%d%d",&a,&b);
		if(t==1)printf("%d\n",encode(a,b));
		else puts(decode(a,b)?"yes":"no");
	}
	return 0;
}
