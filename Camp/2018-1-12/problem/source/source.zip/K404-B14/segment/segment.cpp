#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int INF = 0x3f3f3f3f;
const int p = 998244353;
inline void gmin(int &x, int y){x = x < y ? x : y;}
inline void gmax(int &x, int y){x = x > y ? x : y;}
inline int inc(int a, int b){a += b; if(a >= p) a -= p; return a;}
inline int dec(int a, int b){a -= b; if(a < 0) a += p; return a;}
inline int mul(int a, int b){return (LL)a * b % p;}
int n, m, k, ans;
namespace n1{
	void solve(){
		ans = 0;
		for(int i = 0; i <= m; i++) ans = inc(ans, mul(i, m - i));
		printf("%d\n", ans);
	}
}
namespace amusement{
	void amuse(){while(true) putchar(7);}
}
int main(){
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	if(n == 1) n1::solve();
	else amusement::amuse();
	return 0;
}
