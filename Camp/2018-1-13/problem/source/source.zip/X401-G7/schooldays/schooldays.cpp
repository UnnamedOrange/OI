#include<cstdio>
#include<algorithm>
#define P 1000000007
using namespace std;
int f[1000010],g[1000010],u[1000010],d[1000010];
int n;

int main()
{
  int i,j,tm,sma,big,pd=0;
  freopen("schooldays.in","r",stdin);
  freopen("schooldays.out","w",stdout);
  scanf("%d",&n);
  for(i=1;i<=n;i++) 
   {
    scanf("%d%d",&d[i],&u[i]);
    if(d[i]>u[i]) {pd=1;break;}
   }
  if(pd) {printf("-1\n");return 0;}
  g[0]=1;
  for(i=1;i<=n;i++)
    {
      sma=d[i],big=u[i],tm=1,f[i]=-1;
	  for(j=i;j>=1;j--,tm++)
	    {
		  sma=max(sma,d[j]),big=min(big,u[j]);
		  if(tm>=sma && tm<=big) 
		    {
			  if(f[j-1]>=0 && f[j-1]+1>f[i]) f[i]=f[j-1]+1,g[i]=g[j-1];
			  else if(f[j-1]+1==f[i]) g[i]+=g[j-1],g[i]%=P;
			}
		}
	}
  if(f[n]==-1) {printf("-1\n");return 0;}
  printf("%d %d\n",f[n],g[n]);
}
