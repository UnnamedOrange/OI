#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
int n,m,k,a[4010],b[4010],fa[4010][4010],fb[4010][4010],pa[4010],pb[4010];
void solve()
{
	int mx=max(n,m);
	for (int l=1;l<=mx;l++)
	{
		for (int mask=0;mask<1<<l;mask++)
		{
			bool f=true;
			int j=0;
			//cout<<mask<<":";
			for (int i=0;i<l;i++)
			{
				int now=((mask&(1<<i))>0);
				//cout<<now<<" ";
				while (j<n && a[j]!=now)
				{
					j++;
				}
				if (j==n)
				{
					f=false;
					break;
				}
				j++;
			}
			//cout<<endl;
			if (f)
			{
				continue;
			}
			f=true;
			j=0;
			for (int i=0;i<l;i++)
			{
				int now=((mask&(1<<i))>0);
				while (j<m && b[j]!=now)
				{
					j++;
				}
				if (j==m)
				{
					f=false;
					break;
				}
				j++;
			}
			if (!f)
			{
				printf("%d\n",l);
				return;
			}
		}
	}
	printf("%d\n",mx+1);
}
int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		a[i]--;
	}
	for (int i=0;i<m;i++)
	{
		scanf("%d",&b[i]);
		b[i]--;
	}
	if (k==2 && n<=18 && m<=18)
	{
		solve();
		return 0;
	}
	for (int i=n;i;i--)
	{
		a[i]=a[i-1];
	}
	for (int i=m;i;i--)
	{
		b[i]=b[i-1];
	}
	for (int i=1;i<=n;i++)
	{
		for (int j=0;j<k;j++)
		{
			fa[i][j]=fa[i-1][j];
		}
		fa[i][a[i]]++;
		if (!pa[a[i]])
		{
			pa[a[i]]=i;
		}
	}
	for (int i=1;i<=m;i++)
	{
		for (int j=0;j<k;j++)
		{
			fb[i][j]=fb[i-1][j];
		}
		fb[i][b[i]]++;
		if (!pb[b[i]])
		{
			pb[b[i]]=i;
		}
	}
	int ans=max(n,m);
	for (int i=0;i<k;i++)
	{
		ans=min(ans,max(fa[n][i],fb[m][i])+1);
		//cout<<fa[n][i]<<" "<<fb[m][i]<<endl;
	}
	if (ans==1)
	{
		printf("%d\n",ans);
		return 0;
	}
	for (int i=0;i<k;i++)
	{
		for (int j=0;j<k;j++)
		{
			ans=min(ans,max(fa[n][j]-fa[pa[i]-1][j],fb[m][j]-fb[pb[i]-1][j])+2);
		}
	}
	printf("%d\n",ans);
	return 0;
}
