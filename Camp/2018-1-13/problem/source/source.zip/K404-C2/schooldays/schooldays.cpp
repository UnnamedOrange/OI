#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
const int N=1000005,mod=1000000007;
int n,f[N],g[N],bin[N],lst[N],pow[25],mn[25][N],mx[25][N];
struct data{int l,r;} dat[N];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void inc(int &x,int y)
{
	if((x+=y)>=mod) x-=mod;
}

void task1()
{
	g[0]=1;
	rep(i,1,n) dat[i].l=getint(),dat[i].r=getint(),f[i]=-1;
	rep(i,1,n)
	{
		int l=1,r=n;
		repd(j,i,1)
		{
			l=max(l,i-dat[j].r+1);
			r=min(r,i-dat[j].l+1);
			if(l>r) break;
			if(l<=j && j<=r && f[j-1]>=0)
			{
				if(f[j-1]+1>f[i]) f[i]=f[j-1]+1,g[i]=g[j-1];
				else if(f[j-1]+1==f[i]) inc(g[i],g[j-1]);
			}
		}
	}
//	rep(i,1,n) printf("%d %d\n",f[i],g[i]);
	if(f[n]==-1) puts("-1");
	else printf("%d %d\n",f[n],g[n]);
}

void prepare()
{
	rep(i,2,n) bin[i]=bin[i>>1]+1;
	pow[0]=1;
	rep(i,1,20) pow[i]=pow[i-1]<<1;
	rep(i,1,n) mn[0][i]=dat[i].r,mx[0][i]=dat[i].l;
	rep(j,1,bin[n])
		rep(i,1,n)
		{
			mn[j][i]=min(mn[j-1][i],mn[j-1][i+pow[j-1]]);
			mx[j][i]=max(mx[j-1][i],mx[j-1][i+pow[j-1]]);
		}
}

int getmin(int l,int r)
{
	int len=bin[r-l+1];
	return min(mn[len][l],mn[len][r-pow[len]+1]);
}

int getmax(int l,int r)
{
	int len=bin[r-l+1];
	return max(mx[len][l],mx[len][r-pow[len]+1]);
}

void task2()
{
	g[0]=1;
	rep(i,1,n) dat[i].l=getint(),dat[i].r=getint(),f[i]=-1;
	prepare();
	rep(i,1,n)
	{
		int l,r;
		for(int j=lst[i-1]+1,cnt=0; j>=1 && cnt<=30; ++cnt)
		{
			l=i-getmin(j,i)+1;
			r=i-getmax(j,i)+1;
			if(l>r) break;
			if(f[j-1]==-1) {j=lst[j-1]+1; continue;}
			if(l<=j && j<=r)
			{
				if(f[j-1]+1>f[i]) f[i]=f[j-1]+1,g[i]=g[j-1];
				else if(f[j-1]+1==f[i]) inc(g[i],g[j-1]);
			}
			--j;
		}
		if(f[i]==-1) lst[i]=lst[i-1];
		else lst[i]=i;
	}
//	rep(i,1,n) printf("%d %d\n",f[i],g[i]);
	if(f[n]==-1) puts("-1");
	else printf("%d %d\n",f[n],g[n]);
}

int main()
{
	freopen("schooldays.in","r",stdin);
 	freopen("schooldays.out","w",stdout);
	n=getint();
	if(n<=2000) task1();
	else task2();
	return 0;
}
