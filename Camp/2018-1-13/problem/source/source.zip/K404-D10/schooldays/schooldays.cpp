//© 2018 Jazengm/ZengXiangru, AllRightsReserved

#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;
#define fst first
#define snd second
#define mP make_pair

const int p=1000000007, mxn=1<<11;

In void mxe(int& a, int b){a<b? a=b: 0;}
In void mne(int& a, int b){a>b? a=b: 0;}
In void upd(int& a, int b){a=((ll)a+b)%p;}

int main()
{
    freopen("schooldays.in", "r", stdin);
    freopen("schooldays.out", "w", stdout);
    St int n;
    scanf("%d", &n);
    St int c[mxn], d[mxn];
    inc(1, i, n+1)
        scanf("%d%d", c+i, d+i);
    St pair<int, int> f[mxn];
    f[0]=mP(0, 1);
    inc(1, i, n+1)
    {
        Rg int mxc=0, mnd=mxn;
        dec(0, k, i)
        {
            mxe(mxc, c[k]);
            mne(mnd, d[k]);
            if(mxc<=i-k+1 && i-k+1<=mnd && f[k-1].snd)
                if(f[i].fst<=f[k-1].fst)
                    f[i]=mP(f[k-1].fst+1, f[k-1].snd);
                else if(f[i].fst==f[k-1].fst+1)
                    f[i]=mP(f[i].fst, (f[i].snd+f[k-1].snd)%p);
        }
    }
    if(f[n].fst)
        printf("%d %d\n", f[n].fst, f[n].snd);
    else
        puts("-1");
    Re 0;
}
