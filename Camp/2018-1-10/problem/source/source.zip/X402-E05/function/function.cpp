#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=3000010;
const int MAX=3000000;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
}
int T,n;
int p[N],pr[N],cnt;
int mu[N],s[N],s2[N],ans[N],Mu[N];
tr1::unordered_map<int,LL>M,S1,S2,S3,S4;
inline void init(int n)
{
	mu[1]=1;
	For(i,2,n)
	{
		if(!p[i])mu[i]=-1,pr[++cnt]=i;
		for(int j=1;j<=cnt&&i*pr[j]<=n;++j)
		{
			p[i*pr[j]]=1;
			if(i%pr[j]==0)break;
			mu[i*pr[j]]=-mu[i];
		}
	}
	For(i,1,n)for(int j=i;j<=n;j+=i)++s[j];
	For(i,1,n)s[i]=s[i]*s[i];
	For(i,1,n)Mu[i]=Mu[i-1]+mu[i],s[i]+=s[i-1];
}
inline LL Get_S4(int n)
{
	LL ret=0;
	for(int l=1,r=0;l<=n;l=r+1)
	{
		r=n/(n/l);
		ret+=(r-l+1)*(n/l);
	}
	return ret;
}
inline LL Get_S3(int n)
{
	LL ret=0;
	for(int l=1,r=0;l<=n;l=r+1)
	{
		r=n/(n/l);
		ret+=(r-l+1)*Get_S4(n/l);
	}
	return ret;
}
inline LL Get_S2(int n)
{
	LL ret=0;
	for(int l=1,r=0;l<=n;l=r+1)
	{
		r=n/(n/l);
		ret+=(r-l+1)*Get_S3(n/l);
	}
	return ret;
}
inline LL Get_Mu(int n)
{
	if(n<=MAX)return Mu[n];
	int ret=1;
	for(int l=2,r=0;l<=n;l=r+1)
	{
		r=n/(n/l);
		ret-=(r-l+1)*Get_Mu(n/l);
	}
	return ret;
}
inline LL Get_S(int n)
{
	LL ret=0;
	for(int l=1;l*l<=n;l++)ret+=(Get_Mu(l)-Get_Mu(l-1))*Get_S2(n/l/l);
	return ret;
}
int main()
{
	file();
	read(T);
	init(3000000);
	while(T--)
	{
		read(n);
		LL ans=0;
		for(int l=1,r=0;l<=n;l=r+1)
		{
			r=n/(n/l);
			ans+=(Mu[r]-Mu[l-1])*s[n/l];
		}
		printf("%lld\n",ans);
	}
	return 0;
}
