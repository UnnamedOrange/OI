#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>
#define ele int
using namespace std;
#define maxn 400010
#define D 3
#define alpha 0.7
struct edge{
	ele v;
	edge *nxt;
}ep[maxn<<1],*ecnt;
struct node{
	ele s,s1,mn[D],mx[D],x[D];
	bool flag;
	node *l,*r;
}np[maxn],*ncnt;
ele n,q,t,tcnt,K,c[maxn],pos[maxn],seq[maxn],size[maxn];
node *tmp[maxn],*root,*p[maxn];
edge *h[maxn];
set<ele> S[maxn];
inline void addedge(ele u,ele v){
	edge *p=ecnt++;
	p->v=v; p->nxt=h[u];
	h[u]=p;
}
void dfs(ele p,ele i){
	pos[i]=tcnt; seq[tcnt++]=i; size[i]=1;
	for (edge *j=h[i]; j; j=j->nxt)
		if (j->v!=p) dfs(i,j->v),size[i]+=size[j->v];
}
inline bool cmp(node *a,node *b){
	return a->x[K]<b->x[K];
}
inline void maintain(node *x){
	x->s=1; x->s1=!x->flag;
	if (x->l) x->s+=x->l->s,x->s1+=x->l->s1;
	if (x->r) x->s+=x->r->s,x->s1+=x->r->s1;
	for (int i=0; i<D; ++i){
		x->mn[i]=x->mx[i]=x->x[i];
		if (x->l){
			x->mn[i]=min(x->mn[i],x->l->mn[i]),x->mx[i]=max(x->mx[i],x->l->mx[i]);
		}
		if (x->r){
			x->mn[i]=min(x->mn[i],x->r->mn[i]),x->mx[i]=max(x->mx[i],x->r->mx[i]);
		}
	}
}
node* build(node **a,ele l,ele r,ele d){
	if (l>r) return NULL;
	if (l==r){
		a[l]->l=a[l]->r=NULL;
		maintain(a[l]);
		return a[l];
	}
	K=d;
	ele mid=(l+r)>>1;
	nth_element(a+l,a+mid,a+r+1,cmp);
	a[mid]->l=build(a,l,mid-1,(d+1)%D);
	a[mid]->r=build(a,mid+1,r,(d+1)%D);
	maintain(a[mid]);
	return a[mid];
}
void expt(node *x,node **a,ele i){
	if (!x) return;
	expt(x->l,a,i);
	if (x->l) i+=x->l->s1;
	if (!x->flag) a[i++]=x;
	expt(x->r,a,i);
}
node* ins(node *x,node *y,ele d){
	if (!x){
		y->l=y->r=NULL;
		maintain(y);
		return y;
	}
	K=d;
	if (cmp(y,x)) x->l=ins(x->l,y,(d+1)%D);
	else x->r=ins(x->r,y,(d+1)%D);
	maintain(x);
	if ((x->l && x->l->s>alpha*x->s) || (x->r && x->r->s>alpha*x->s)){
		ele s=x->s1;
		expt(x,tmp,0);
		x=build(tmp,0,s-1,d);
	}
	return x;
}
node* del(node *x,node *y,ele d){
	if (!x) return NULL;
	K=d;
	if (x==y) x->flag=true;
	else{
		if (!cmp(x,y)) x->l=del(x->l,y,(d+1)%D);
		K=d;
		if (!cmp(y,x)) x->r=del(x->r,y,(d+1)%D);
	}
	maintain(x);
	if (x->s1*2<x->s){
		ele s=x->s1;
		expt(x,tmp,0);
		x=build(tmp,0,s-1,d);
	}
	return x;
}
inline bool init(ele a[],ele b[],ele c[],ele d[]){
	for (int i=0; i<D; ++i)
		if (a[i]<c[i] || b[i]>d[i]) return false;
	return true;
}
inline bool outit(ele a[],ele b[],ele c[],ele d[]){
	for (int i=0; i<D; ++i)
		if (b[i]<c[i] || a[i]>d[i]) return true;
	return false;
}
ele qry(node *x,ele qmn[],ele qmx[]){
	if (!x) return 0;
	if (init(x->mn,x->mx,qmn,qmx)) return x->s1;
	if (outit(x->mn,x->mx,qmn,qmx)) return 0;
	ele ans=0;
	if (init(x->x,x->x,qmn,qmx)) ans+=!x->flag;
	ans+=qry(x->l,qmn,qmx);
	ans+=qry(x->r,qmn,qmx);
	return ans;
}
int main(){
	freopen("xmastree1.in","r",stdin); freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for (int i=0; i<n; ++i) S[i].insert(-1);
	for (int i=0; i<n; ++i) scanf("%d",c+i),--c[i];
	ecnt=ep; memset(h,0,sizeof(h));
	for (int i=0; i<n-1; ++i){
		ele x,y;
		scanf("%d%d",&x,&y); --x,--y;
		addedge(x,y); addedge(y,x);
	}
	tcnt=0;
	dfs(-1,0);
	ncnt=np;
	for (int i=0; i<n; ++i){
		S[c[seq[i]]].insert(i);
		tmp[i]=ncnt++;
		tmp[i]->x[0]=i; tmp[i]->x[1]=c[seq[i]]; tmp[i]->x[2]=*--S[c[seq[i]]].lower_bound(i);
		tmp[i]->flag=false; tmp[i]->l=tmp[i]->r=NULL;
		maintain(tmp[i]);
		p[seq[i]]=tmp[i];
	}
	root=build(tmp,0,n-1,0);
	ele lastans=0;
	while (q--){
		ele op,x,y,z;
		scanf("%d%d%d",&op,&x,&y);
		if (op==1) scanf("%d",&z);
		if (t) x^=lastans,y^=lastans,z^=lastans;
		--x,--y,--z;
		if (op==1){
			ele qmn[D]={pos[x],y,-1};
			ele qmx[D]={pos[x]+size[x]-1,z,pos[x]-1};
			printf("%d\n",lastans=qry(root,qmn,qmx));
		}
		else{
			*ncnt=*p[x];
			root=del(root,p[x],0);
			p[x]=ncnt++;
			set<ele>::iterator it=S[c[x]].upper_bound(pos[x]);
			if (it!=S[c[x]].end()){
				ele j=*it;
				*ncnt=*p[seq[j]];
				root=del(root,p[seq[j]],0);
				p[seq[j]]=ncnt++;
				p[seq[j]]->x[2]=p[x]->x[2];
				root=ins(root,p[seq[j]],0);
			}
			S[c[x]].erase(pos[x]);
			c[x]=y; p[x]->x[1]=y;
			S[c[x]].insert(pos[x]);
			it=S[c[x]].upper_bound(pos[x]);
			if (it!=S[c[x]].end()){
				ele j=*it;
				*ncnt=*p[seq[j]];
				root=del(root,p[seq[j]],0);
				p[seq[j]]=ncnt++;
				p[seq[j]]->x[2]=pos[x];
				root=ins(root,p[seq[j]],0);
			}
			p[x]->x[2]=*--S[c[x]].lower_bound(pos[x]);
			root=ins(root,p[x],0);
		}
	}
	return 0;
}