#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <deque>
#include <map>
#include <set>
#include <bitset>
#include <list>
typedef long long INT;
using std::cin;
using std::cout;
using std::endl;
INT readIn()
{
	INT a = 0;
	bool minus = false;
	char ch = getchar();
	while (!(ch == '-' || (ch >= '0' && ch <= '9'))) ch = getchar();
	if (ch == '-')
	{
		minus = true;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9')
	{
		a = a * 10 + (ch - '0');
		ch = getchar();
	}
	if (minus) a = -a;
	return a;
}
void printOut(INT x)
{
	char buffer[20];
	INT length = 0;
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	do
	{
		buffer[length++] = x % 10 + '0';
		x /= 10;
	}
	while (x);
	do
	{
		putchar(buffer[--length]);
	}
	while (length);
	putchar('\n');
}

const INT mod = 998244353;
const INT maxn = INT(1e5) + 5;
INT n, m, k;
INT power(INT x, INT y)
{
	INT ret = 1;
	while(y)
	{
		if(y & 1) ret = ret * x % mod;
		x = x * x % mod;
		y >>= 1;
	}
	return ret;
}

#define RunInstance(x) delete new x
struct brute
{
	static const INT maxN = 10;
	INT pwr[maxN];
	INT a[maxN];
	INT ans;

	void search(INT remain, INT preL, INT preR)
	{
		if(remain == 0)
		{
			for(int i = 1; i <= n; i++)
				ans = (ans + pwr[a[i]]) % mod;
			return;
		}
		for(int l = preL + 1; l <= n; l++)
		{
			for(int r = std::max(l, int(preR + 1)); r <= n; r++)
			{
				for(int i = l; i < r; i++)
					a[i]++;
				search(remain - 1, l, r);
				for(int i = l; i < r; i++)
					a[i]--;
			}
		}
	}

	brute() : a(), ans()
	{
		pwr[0] = 0;
		for(int i = 1; i <= n; i++)
			pwr[i] = power(i, k);
		search(m, 0, 0);
		printOut(ans);
	}
};

void run()
{
	m = readIn();
	n = readIn();
	k = readIn();

	if(n <= 6)
		RunInstance(brute);
}

int main()
{
#ifndef LOCAL
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
#endif
	run();
	return 0;
}
