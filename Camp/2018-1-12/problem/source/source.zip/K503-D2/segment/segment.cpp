#include<bits/stdc++.h>
#define mo 998244353
using namespace std;
int m,n,kk,ansn=0,f[10010];
int p(long long x,long long y){
	long long z=1;
	while (y){
		if (y % 2==1) z=(z*x)%mo;
		x=(x*x)%mo;
		y/=2;
	}
	return z;
}
void dfs(int lastl,int lastr,int k){
	if (k==0){
		for (int i=1;i<=m;i++){
			ansn=(ansn+p(f[i],kk))%mo;
		}
	}else{
		for (int l=lastl+1;l<=m-k+1;l++){
			for (int r=max(lastr+1,l);r<=m-k+1;r++){
				for (int p=l;p<r;p++){
					f[p]++;
				}
				dfs(l,r,k-1);
				for (int p=l;p<r;p++){
					f[p]--;
				}
			}
		}
	}
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	cin>>n>>m>>kk;
	if (n==1){
		long long sum=0;
		for (long long i=1;i<n;i++){
			sum+=i*(i+1)/2;
			sum%=mo;
		}
		cout<<sum<<endl;
		return 0;
	}
	dfs(0,0,n);
	cout<<ansn<<endl;
}
