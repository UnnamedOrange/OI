//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const ll maxn=7,maxm=500+7,mod=998244353;
ll n,m,len[maxn],num[maxn][2],ans;
char s[maxn];

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

void ins(int p,int len) {
	for(int i=1;i<=len;++i) {
		num[p][0]<<=1;
		num[p][0]|=(s[i]-'0');
	}
	for(int i=len;i>=1;--i) {
		num[p][1]<<=1;
		num[p][1]|=(s[i]-'0')^1;
	}
}

bool check1(ll t,int x) {
	ll r=(1<<len[x])-1;
	for(int i=0;i<=m-len[x];++i) {
		if((t&r)==num[x][0]) return 1;
		if((t&r)==num[x][1]) return 1;
		t>>=1;
	}
	return 0;
}

bool check2(ll t,int x) {
	ll r;
	for(int i=1;i<len[x]&&i<=m;++i) if(len[x]-i<=m){
		r=len[x]-i;
		if((num[x][0]>>r)!=(t&((1<<i)-1))) continue;
		if((num[x][1]>>i)==(t&((1<<r)-1))) return 1;
	}
	return 0;
}

bool ok(ll x) {
	for(int i=1;i<=n;++i) 
		if((!check1(x,i))&&(!check2(x,i))) return 0;
	return 1;
}

void doit() {
	ans=0;
	for(int i=1;i<=n;++i) {
		scanf("%s",s+1);
		len[i]=strlen(s+1);
		ins(i,len[i]);
	}
	for(int i=1;i<=n;++i) if(len[i]>2*m) return;
	for(int i=0;i<(1<<m);++i) 
		if(ok(i)) ++ans;
}

int main() {
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	n=read(); m=read();
	if(m<=15) doit();
	printf("%lld",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
2 3
011
001
*/
