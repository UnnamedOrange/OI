#include <bits/stdc++.h>

namespace {

using ulong = unsigned long long;

constexpr int MAXN = 100000;
constexpr int G = 3;
constexpr int MOD = 998244353;

inline int modPow(register int a, register int b) {
    register int ret = 1;
    for (; b; b >>= 1, a = (ulong)a * a % MOD)
        if (b & 1) ret = (ulong)ret * a % MOD;
    return ret;
}

int w[MAXN];

inline void init(const int k) {
    register int n = k >> 1;
    w[n] = 1;
    w[n + 1] = modPow(G, k / (MOD - 1));
    for (register int i = 2; i < n; i++)
        w[n + i] = (ulong)w[n + i - 1] * w[n + 1] % MOD;
    for (register int i = n - 1; i > 0; i--) w[i] = w[i << 1];
}

inline void ntt(int *a, const int n, const int f) {
    for (register int i = 0, j = 0; i < n; i++) {
        if (i > j) std::swap(a[i], a[j]);
        for (register int k = n >> 1; (j ^= k) < k; k >>= 1)
            ;
    }
    for (register int i = 1; i < n; i <<= 1) {
        const register int *w = ::w + i;
        for (register int j = 0; j < n; j += i << 1) {
            register int *x = a + j, *y = a + i + j, t;
            for (register int k = 0; k < i; k++) {
                t = (ulong)w[k] * y[k] % MOD;
                y[k] = (x[k] - t < 0 ? x[k] + MOD - t : x[k] - t);
                x[k] = (x[k] + t >= MOD ? x[k] + t - MOD : x[k] + t);
            }
        }
    }
    if (f == -1) {
        std::reverse(a + 1, a + n);
        const int inv = modPow(n, MOD - 2);
        for (register int i = 0; i < n; i++) a[i] = (ulong)a[i] * inv % MOD;
    }
}

struct Polynomial {
    int deg, a[MAXN];

    inline void inverse(const int k) {
        if (k == 1) {
            a[0] = 0;
            return;
        }
        static int tmp[MAXN];
    }

    inline int &operator[](const int i) { return a[i]; }
} f, g, h;

inline void solve() {
    long long ans = 1;
    for (int i = 1; i <= n; i++) ans = ans * i % MOD;
    std::cout << (modPow(2, (long long)n * (n - 1) / 2) - ans + MOD) % MOD;
}
}  // namespace

int main() {
    freopen("tournament.in", "r", stdin);
    freopen("tournament.out", "w", stdout);
    solve();
    return 0;
}