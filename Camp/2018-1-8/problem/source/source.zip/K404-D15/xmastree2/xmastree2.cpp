#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 30005
typedef long long ll;

int n,tot;
int now[maxn],pre[maxn*2],son[maxn*2],val[maxn];
bool can[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

void add(int a,int b){son[++tot]=b,pre[tot]=now[a],now[a]=tot;}
void link(int a,int b){add(a,b),add(b,a);}

namespace task1{
	int a[maxn]; bool flag,fuckpps;
	void dfs(int x,int fa){
		if (!fuckpps) return;
		for (int p=now[x];p;p=pre[p])
			if (son[p]!=fa){
				if (a[son[p]]<a[x]){fuckpps=0; return;}
				dfs(son[p],x);
			}
	}
	bool check(){
		flag=0;
		for (int i=1;i<=n;i++)
			if (can[i]){fuckpps=1,dfs(i,0); if (fuckpps){flag=1; break;}}
	    return flag;
	}
	void solve(){
		for (int i=1;i<=n;i++) a[i]=i;
		int ans=0;
		do{
			if (!check()) continue;
			int res=0;
			for (int i=1;i<=n;i++) res+=val[i]*a[i];
			ans=max(ans,res);
		}while (next_permutation(a+1,a+n+1));
		cout<<ans<<endl;
	}
}

namespace task2{
	int size[maxn],sum[maxn]; ll f[maxn];
	bool cmp(int a,int b){return sum[a]<sum[b];}
	void dfs(int x,int fa){
		size[x]=1,sum[x]=val[x];
		for (int p=now[x];p;p=pre[p])
			if (son[p]!=fa) dfs(son[p],x),size[x]+=size[son[p]],sum[x]+=sum[son[p]];
	}
	int top,stack[maxn];
	void tree_dp(int x,int fa){
		for (int p=now[x];p;p=pre[p])
			if (son[p]!=fa) tree_dp(son[p],x);
		top=0;
		for (int p=now[x];p;p=pre[p])
			if (son[p]!=fa) stack[++top]=son[p];
		sort(stack+1,stack+top+1,cmp);
		int pps=0;
		for (int i=top;i;i--){
			f[x]+=f[stack[i]]-sum[stack[i]]*pps;
			pps+=size[stack[i]];
		}
		f[x]+=(n-size[x]+1)*val[x];
	}
	void solve(){
		ll ans=0;
		for (int i=1;i<=n;i++)
			if (can[i]){
				dfs(i,0);
				tree_dp(i,0);
				ans=max(ans,f[i]);
			}
		cout<<ans<<endl;
	}
}

int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	n=read();
	for (int i=1,x,y;i<n;i++) x=read(),y=read(),link(x,y);
	for (int i=1;i<=n;i++) val[i]=read(),can[i]=read();
	if (n<=10) task1::solve();
	else task2::solve();
	return 0;
}
