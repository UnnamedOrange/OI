#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
int a[30];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,T=5;
	srand(time(0));
	freopen("sequence.in","w",stdout);
	printf("%d\n",T);
	while(T--){
		n=23;
		printf("%d\n",n);
		for(i=1;i<=n;i++)a[i]=i;
		random_shuffle(a+1,a+n+1);
		for(i=1;i<=n;i++)printf("%d%c",a[i],i==n?'\n':' ');
	}
	return 0;
}
