from sys import stdin
print len(stdin.readline().strip())
