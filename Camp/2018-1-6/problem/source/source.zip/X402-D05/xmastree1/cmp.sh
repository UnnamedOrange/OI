a=0
while true;do
	echo "Case $a :"
	a=`expr $a + 1`
	./gen
	./baoli
	./xmastree1
	if diff baoli.out xmastree1.out;then
		printf "Accepted!\n"
	else
		printf "Wrong Answer!\n"
		break
	fi
done
