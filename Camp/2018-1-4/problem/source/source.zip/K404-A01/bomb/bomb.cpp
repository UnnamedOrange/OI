//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const int N=1e6+10;
void read(int &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
int fir[N],nxt[N*2],to[N*2],siz[N],tot;
void add_edge(int x,int y)
{
  nxt[++tot]=fir[x];
  to[tot]=y;
  fir[x]=tot;
}
int dnf[N],low[N],f[N],tim,cnt;
stack<int> sp;
void tarjar(int i)
{
  dnf[i]=low[i]=++tim;
  sp.push(i);
  for(int j=fir[i];j;j=nxt[j])
  {
    if(!dnf[to[j]])
      tarjar(to[j]),low[i]=min(low[i],low[to[j]]);
    else
      low[i]=min(low[i],dnf[to[j]]);
  }
  if(dnf[i]==low[i])
  {
  	++cnt;
  	while(sp.top()!=i)
  	  f[sp.top()]=cnt,siz[cnt]++,sp.pop();
  	f[sp.top()]=cnt;siz[cnt]++;sp.pop();
  }
}
int a[N],b[N],rd[N];
queue<int> sp1;
void tpsort()
{
  int p;
  for(int i=1;i<=cnt;i++)
    if(!rd[i])
      sp1.push(i);
  while(!sp1.empty())
  {
  	p=sp1.front();
  	sp1.pop();
  	for(int j=fir[p];j;j=nxt[j])
  	{
  	  --rd[to[j]];
  	  siz[to[j]]+=siz[p];
  	  if(!rd[to[j]])
  	    sp1.push(to[j]);
	}
  }
}
int main()
{
  freopen("bomb.in","r",stdin);
  freopen("bomb.out","w",stdout);
  int n,m,x,y,ans=0;
  read(n);read(m);
  for(int i=1;i<=m;i++)
  {
  	read(a[i]);read(b[i]);
  	add_edge(a[i],b[i]);
  }
  for(int i=1;i<=n;i++)
    if(!dnf[i])
      tarjar(i);
  tot=0;
  memset(fir,0,sizeof(fir));
  for(int i=1;i<=m;i++)
    if(f[a[i]]!=f[b[i]])
    {
  	  add_edge(f[a[i]],f[b[i]]);
  	  rd[f[b[i]]]++;
    }
  tpsort();
  for(int i=1;i<=cnt;i++)
    ans=max(ans,siz[i]);
  cout<<ans<<"\n";
  return 0;
}
/*
5 4
1 2
2 3
3 1
4 5
*/
