#include<cstdio>
#include<iostream>
#include<algorithm>
#define NN 500000+100
#define MM 500000+100
#define MOD 1000000009
using namespace std;
struct interval{
	int l,r;
}a[NN]={0};
bool cmp(interval a,interval b){
	return a.r<b.r;
}
int read(){
	int fl=1,x=0;
	char c;
	for(c=getchar();(c<'0'||c>'9')&&c!='-';c=getchar());
	if(c=='-'){fl=-1;c=getchar();}
	for(x=0;c>='0'&&c<='9';c=getchar()){
		x=x*10+c-'0';
	}
	return x*fl;
}
int n,m;
int p[MM]={0};
long long dp[MM]={0};
long long pow2[MM]={0};
void get_len(interval &x){
	int l=1,r=m,mid;
	while(l!=r){
		int mid=(l+r)/2;
		if(p[mid]>=x.l){
			r=mid;
		}
		else {
			l=mid+1;
		}
	}
	x.l=l;
	l=1,r=m;
	while(l!=r){
		int mid=(l+r)/2+1;
		if(p[mid]<=x.r){
			l=mid;
		}
		else {
			r=mid-1;
		}
	}
	x.r=l;
}
int after[MM]={0};
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	dp[0]=1;
	for(int i=1;i<=n;++i){
		a[i].l=read();
		a[i].r=read();
	}
	for(int i=1;i<=m;++i){
		p[i]=read();
	}
	sort(p+1,p+m+1);
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;++i){
		get_len(a[i]);
		after[a[i].l]++;
	}
	int pos=1;
	for(int i=1;i<=m;++i){
		dp[i]+=dp[i-1];
		while(a[pos].r==i){
			dp[a[pos].r]+=(dp[a[pos].r]-(a[pos].l>1?dp[a[pos].l-2]:0));
			(dp[a[pos].r]+=MOD)%=MOD;
			++pos;
		}
	}
	for(int i=n;i>=0;--i){
		after[i]+=after[i+1];
	}
	pow2[0]=1;
	for(int i=1;i<=n;++i){
		pow2[i]=(pow2[i-1]*2)%MOD;
	}
	long long ans=pow2[n];
	ans-=pow2[after[2]];
	(ans+=MOD)%=MOD;
	for(int i=1;i<n;++i){
		ans-=(((dp[i]-dp[i-1])%MOD)*pow2[after[i+2]])%MOD;
		(ans+=MOD)%=MOD;
	}
	printf("%lld\n",ans);
}
	
	
