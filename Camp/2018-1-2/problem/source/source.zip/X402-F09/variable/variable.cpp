#include<cstdio>
#include<cctype>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int fl,s,q[505],ans,n,w,a[1005][11],x[1005],y[1005],z[1005],l,r;
int ab(int x){return x>=0?x:-x;}
void dfs(int d,int cnt){
	if (d==n+1){
		fl=0;
		For(i,1,r){
			if (!z[i]&&q[x[i]]>q[y[i]]) {fl=1; break;}
			if (z[i]==1&&q[x[i]]!=q[y[i]]) {fl=1; break;}
			if (z[i]==2&&q[x[i]]>=q[y[i]]) {fl=1; break;}
		}
		if (fl) return; s=cnt;
		For(i,1,l)
			For(j,1,3) s+=a[i][3+j]*(ab(q[a[i][j]]-q[a[i][j+1>3?1:j+1]]));
		For(i,1,l)
			For(j,1,3) s+=a[i][6+j]*(q[a[i][j]]-q[a[i][j+1>3?1:j+1]]);
		if (s<ans) ans=s;
		return;
	}
	q[d]=-1; dfs(d+1,cnt-1);
	q[d]=1; dfs(d+1,cnt+1);
}
int main(){
	freopen("variable.in","r",stdin); freopen("variable.out","w",stdout);
	int _=read();
	while(_--){
		n=read(),w=read(),l=read(),r=read();
		For(i,1,l)
			For(j,1,9) a[i][j]=read();
		For(i,1,r) x[i]=read(),y[i]=read(),z[i]=read();
		ans=2147483646; dfs(1,0); printf("%lld\n",(long long)ans*w);
	}
	return 0;
}
