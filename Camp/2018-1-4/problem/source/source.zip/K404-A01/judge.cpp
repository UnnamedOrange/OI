//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const lovelive mod=1004535809;
void read(lovelive &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
int main()
{
  int T=0,x;
  while(1)
  {
  	system("rand.exe");
    system("sequence.exe");
    system("test2.exe");
    if(system("fc sequence.out test2.out"))
      break;
	cout<<++T<<"\n";  
  }
  return 0;
}
