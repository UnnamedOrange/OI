#include<bits/stdc++.h>
using namespace std;
const int maxn=200100;
int Min(int x,int y){
	return x<y?x:y;
}
int Max(int x,int y){
	return x>y?x:y;
}
char str[maxn];
int A[maxn],B[maxn];
int n;
void trans(){
	for(int i=n;i>=1;i--){
		str[i<<1|1]='#';
		str[i<<1]=str[i];
	}
	str[1]='#';
	str[0]='&',str[(n<<1)+2]='^';
}
void geta(int *a){
	static int len[maxn];
	memset(len,0,sizeof(len));
	int id=1,p=1;
	for(int i=1;i<=(n<<1|1);i++){
		len[i]=Min(p-i+1,len[id*2-i]);
		while(str[i-len[i]]==str[i+len[i]]) len[i]++;
		if(i+len[i]-1>p) id=i,p=i+len[i]-1;
		if(len[i]==i) a[(i+len[i]-1)>>1]=1;
	}
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		scanf("%s",str+1);

		memset(A,0,sizeof(A));
		memset(B,0,sizeof(B));

		trans();
		geta(A);
		for(int i=1;i<=n;i++)
			swap(str[i],str[(n+1)*2-i]);
		geta(B);
		for(int i=1;i<=n/2;i++)
			swap(B[i],B[n+1-i]);
		if(!A[n])
			printf("1\n");
		else{
			bool bo=0;
			for(int i=1;i<n;i++)
				if(!A[i]&&!B[i+1]){
					bo=1;
					break;
				}
			if(bo)
				printf("2\n");
			else
				printf("-1\n");
		}
	}
	return 0;
}
