#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
int t,n,mu[1000010],pri[1000010],cnt;
bool used[1000010];
long long o[1000010],sum[1000010],ans;
void getmu()
{
	mu[1]=1;
	for (int i=2;i<=1000000;i++)
	{
		if (!used[i])
		{
			mu[i]=-1;
			pri[cnt]=i;
			cnt++;
		}
		for (int j=0;j<cnt;j++)
		{
			int m=pri[j]*i;
			if (m>1000000)
			{
				break;
			}
			used[m]=true;
			if (i%pri[j]==0)
			{
				mu[m]=0;
				break;
			}
			mu[m]=mu[pri[j]]*mu[i];
		}
	}
}
void geto()
{
	o[1]=1;
	for (int i=2;i<=1000000;i++)
	{
		if (!used[i])
		{
			o[i]=2;
			continue;
		}
		int tmp=i;
		for (int j=0;j<cnt;j++)
		{
			if (pri[j]*pri[j]>1000000)
			{
				break;
			}
			if (tmp%pri[j]==0)
			{
				int pc=1;
				while (tmp%pri[j]==0)
				{
					pc*=pri[j];
					tmp/=pri[j];
				}
				if (tmp==1)
				{
					pc/=pri[j];
					o[i]=o[pc]+1;
					break;
				}
				o[i]=o[tmp]*o[pc];
				break;
			}
		}
	}
	for (int i=1;i<=1000000;i++)
	{
		sum[i]=sum[i-1]+o[i]*o[i];
	}
}
void solve()
{
	ans=0;
	for (int i=1;i<=n;i++)
	{
		int m=n/i;
		ans+=mu[i]*sum[m];
	}
}
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	scanf("%d",&t);
	if (t==0)
	{
		return 0;
	}
	getmu();
	geto();
	/*
	for (int i=1;i<=100;i++)
	{
		printf("mu(%d):%d      o(%d):%d\n",i,mu[i],i,o[i]);
	}
	*/
	while (t--)
	{
		scanf("%d",&n);
		solve();
		printf("%lld\n",ans);
	}
	return 0;
}
/*
10
233333
999992
999993
999994
999995
999996
999997
999998
999999
1000000
*/
