#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int inf = 2147483647;
const int N = 1010;

int T, n, W, p, q, ans = inf;
int H[N], w[N >> 1], Y[N];
int xi[N], yi[N], zi[N], ai[N], bi[N], ci[N], di[N], ei[N], fi[N];
int x[N], y[N], r[N];

inline void open()
{
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
}

inline void close()
{
	fclose(stdin);
	fclose(stdout);
}

inline int read()
{
	int a = 0;
	char ch;
	int f = 1;
	while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
	if(ch == '-')
		f = -1;
	else
	{
		a = a * 10;
		a += ch - '0';
	}
	while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
	{
		a = a * 10;
		a += ch - '0';
	}
	return a * f;
}

inline int CH(int i)
{
	return ai[i] * abs(w[xi[i]] - w[yi[i]]) + bi[i] * abs(w[yi[i]] - w[zi[i]]) + ci[i] * abs(w[zi[i]] - w[xi[i]]) + di[i] * (w[xi[i]] - w[yi[i]]) + ei[i] * (w[yi[i]] - w[zi[i]]) + fi[i] * (w[zi[i]] - w[xi[i]]);
}

inline bool check()
{
	for(int i = 1;i <= q;++i)
	{
		if(r[i] == 0)
			if(w[x[i]] > w[y[i]])
				return false;
		if(r[i] == 1)
			if(w[x[i]] != w[y[i]])
				return false;
		if(r[i] == 2)
			if(w[x[i]] >= w[y[i]])
				return false;
	}
	return true;
}

inline void dfs(int o)
{
	if(o == n + 1)
	{
		if(check())
		{
			int cur = 0;
			for(int i = 1;i <= n;++i)
				cur += w[i];
			for(int i = 1;i <= p;++i)
				cur += CH(i);
			if(cur < ans)
			{
				ans = cur;
				/*printf("%d\n", cur);
				for(int i = 1;i <= n;++i)
					printf("%d ", w[i]);
				printf("\n");
				for(int i = 1;i <= p;++i)
					printf("%d ", CH(i));
				printf("\n");*/
			}
		}
		return;
	}
	w[o] = W;
	dfs(o + 1);
	w[o] = -W;
	dfs(o + 1);
	w[o] = 0;
	return;
}

inline void brute()
{
	dfs(1);
	printf("%d\n", ans);
}

inline void solve()
{
	T = read();
	while(T--)
	{
		ans = inf;
		n = read(), W = read(), p = read(), q = read();
		for(int i = 1;i <= p;++i)
			xi[i] = read(), yi[i] = read(), zi[i] = read(), ai[i] = read(), bi[i] = read(), ci[i] = read(), di[i] = read(), ei[i] = read(), fi[i] = read();
		for(int i = 1;i <= q;++i)
			x[i] = read(), y[i] = read(), r[i] = read();
		if(n <= 15)
			brute();
		else
			printf("%d\n", 0);
	}
}

int main()
{
	open();
	solve();
	close();
	return 0;
}
