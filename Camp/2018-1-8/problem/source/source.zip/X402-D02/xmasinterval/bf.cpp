#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define x first
#define y second

inline void read(int &x)
{
	char c=x=0; for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
}

typedef std::pair<int,int> pii;
const int N=501000,MOD=1000000009;
inline void inc(int a,int &b){b=(a+b)%MOD;}
int mw[N],tot;
inline int id_l(int x){return std::lower_bound(mw+1,mw+tot+1,x)-mw;}
inline int id_r(int x){return std::upper_bound(mw+1,mw+tot+1,x)-mw-1;}

pii s[N];
int n,m;
void initialize()
{
	read(n),read(m);
	for(int i=1;i<=n;i++)read(s[i].x),read(s[i].y);
	tot=m;
	for(int i=1;i<=m;i++)read(mw[i]);
	std::sort(mw+1,mw+tot+1);
	tot=std::unique(mw+1,mw+tot+1)-mw-1;
	m=tot;

	for(int i=1;i<=n;i++)
		s[i].x=id_l(s[i].x),s[i].y=id_r(s[i].y);
}

int cnt[N];
int ans;

bool check()
{
	for(int i=1;i<=m;i++)
		if(!cnt[i])return 0;
	return 1;
}

void dfs(int p=1)
{
	if(p>n)
	{
		ans+=check();
		return;
	}
	for(int i=s[p].x;i<=s[p].y;i++)
		cnt[i]++;
	dfs(p+1);
	for(int i=s[p].x;i<=s[p].y;i++)
		cnt[i]--;
	dfs(p+1);
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.ans","w",stdout);
	initialize();
	ans=0,dfs();
	printf("%d\n",ans);
	return 0;
}
