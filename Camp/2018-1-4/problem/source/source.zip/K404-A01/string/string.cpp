//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const lovelive mod=1004535809;
void read(int &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
char s[10][220],sp[1010];
int len[10];
int main()
{
  freopen("string.in","r",stdin);
  freopen("string.out","w",stdout);
  int n,m,ans=0;
  bool p;
  read(n);read(m);
  for(int i=1;i<=n;i++)
  	scanf("%s",s[i]+1),len[i]=strlen(s[i]+1);
  for(int i=0;i<(1<<m);i++)
  {
  	for(int j=1;j<=m;j++)
  	  if(i>>(j-1)&1)
  	    sp[j]='1',sp[(m<<1|1)-j]='0';
  	  else
  	    sp[j]='0',sp[(m<<1|1)-j]='1';
  	for(int j=1;j<=n;j++)
  	{
  	  p=false;
	  for(int p2=0;p2<=2*m-len[j];p2++)
	  {
  	    for(int p1=1;p1<=len[j];p1++)
  	    {
  	      if(sp[p2+p1]!=s[j][p1])
  	        break;
  	      else
  	        if(p1==len[j])
  	          p=true;
  	    }
  	    if(p)
  	      break;
  	  }
  	  if(!p)
  	    break;
	}
	if(p)
	  ++ans;
  }
  cout<<ans<<"\n";
  return 0;
}

