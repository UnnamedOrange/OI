//大暴力，25pts
#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1e6;
int N, A[MAXN+10], T[MAXN+10]; double Ans;
int main() {
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	scanf("%d", &N);
	for(int i=1; i<=N; i++) scanf("%d", A+i);
	
	for(int i=1; i<=N; i++)
		for(int j=i; j<=N; j++) {
			double Cur = 0; T[0] = 0;
			for(int k=i; k<=j; k++) T[++T[0]] = A[k];
			sort(T+1, T+T[0]+1);
			for(int i=1; i<=T[0]; i++)
				Cur = (Cur + T[i]) / 2;
			Ans += Cur;
		}
	printf("%.10lf", Ans / N / N);
	return 0;
}
