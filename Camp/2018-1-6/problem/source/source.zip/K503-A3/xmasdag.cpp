#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
#define pr pair<int, int>
#define x first
#define y second
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while (!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while (isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n *= sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int MOD = 998244353;
const int N = 122222;
const int K = 501;
int n, m, k, l, r;
int dp[N][K], seq[N], deg[N];
struct edge{int to, nxt;} g[N*4];
int ghead[N], gtail;
vector<int> in[N], f[K][K];

ll mut(ll a, ll b){
	ll y = 1, t = a;
	for (; b; b >>= 1, t = t * t % MOD)
		if (b & 1) y = y * t % MOD;
	return y;
}
void upd(int& a, int b){a += b; if (a >= MOD) a -= MOD;}
void add(int l, int r){g[++gtail] = (edge){r, ghead[l]}, ghead[l] = gtail;}
void gauss(int n){
	rep(i, 0, n){
		int pos = i;
		for (; !f[n][pos][i]&&pos <= n; pos++);
		if (pos > n) break;
		rep(j, 0, n + 1) swap(f[n][i][j], f[n][pos][j]);
		rep(j, i + 1, n){
			int t = (ll)f[n][j][i] * mut(f[n][i][i], MOD - 2) % MOD;
			rep(k, i, n + 1) f[n][j][k] = (f[n][j][k] - (ll)t * f[n][i][k] % MOD + MOD) % MOD;
		}
	}
	per(i, n, 0){
		rep(j, i + 1, n) f[n][i][n+1] = (f[n][i][n+1] - (ll)f[n][j][n+1] * f[n][i][j] % MOD + MOD) % MOD;
		f[n][i][n+1] = (ll)f[n][i][n+1] * mut(f[n][i][i], MOD - 2) % MOD;
	}
}
void topsort(int seq[]){
	queue<int> que; que.push(1); *seq = 0;
	while(!que.empty()){
		int h = que.front(); que.pop(); seq[++*seq] = h;
		for (int p = ghead[h]; p; p = g[p].nxt){
			int v = g[p].to;
			if (!--deg[v]) que.push(v);
		}
	}
}

int main(){
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	read(n), read(m), read(k);
	rep(i, 1, m) read(l), read(r), add(l, r), in[r].pb(l), deg[r]++;
	rep(p, 0, k){
		rep(i, 0, p) rep(j, 0, p + 1) f[p][i].pb(0);
		rep(i, 0, p){
			rep(j, 0, p) upd(f[p][i][j], mut(i + 1, j));
			upd(f[p][i][p+1], mut(i + 2, p));
		}
		gauss(p);
	}
	topsort(seq);
//	rep(i, 1, *seq) cerr << seq[i] << ' '; cerr << endl;
	dp[1][0] = 1;
	rep(i, 1, *seq){
		int x = seq[i];
		for (int p = 0; p < in[x].size(); ++p){
			int v = in[x][p], t = 0;
			rep(j, 0, k) rep(t, 0, j)
				upd(dp[x][j], (ll)dp[v][t] * f[j][t][j+1] % MOD);
		}
	}
	rep(i, 1, n){
		printf("%d\n", dp[i][k]);
	}
	return 0;
}
