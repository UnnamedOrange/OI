#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int INF = 0x3f3f3f3f;
const int MAXN = 30010;
int n, ans;
vector<int> G[MAXN];
int w[MAXN], sum[MAXN];
queue<int> r;
priority_queue<PII> pq;
int fa[MAXN];
void dfs(int x, int f){
	fa[x] = f;
	sum[x] = w[x];
	for(register unsigned int i = 0; i < G[x].size(); i++){
		int y = G[x][i];
		if(y == f) continue;
		dfs(y, x);
		sum[x] += sum[y];
	}
}
int main(){
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i < n; i++){
		int x, y;
		scanf("%d%d", &x, &y);
		G[x].PB(y);
		G[y].PB(x);
	}
	for(int i = 1; i <= n; i++){
		int x;
		scanf("%d%d", &w[i], &x);
		if(x) r.push(i);
	}
	ans = 0;
	while(!r.empty()){
		register int rt = r.front(); r.pop();
		dfs(rt, 0);
		register int tmp = 0, s = 0;
		pq.push(MP(0, rt));
		for(register int i = 1; i <= n; i++){
			register int x = pq.top().S; pq.pop();
			s += w[x];
			tmp += w[x] * i;
			for(register unsigned int j = 0; j < G[x].size(); j++){
				register int y = G[x][j];
				if(y != fa[x]) pq.push(MP((sum[rt] - sum[y]), y));
			}
		}
		if(tmp > ans) ans = tmp;
	}
	cout << ans << endl;
	return 0;
}
