#include<bits/stdc++.h>
#define N 500100
#define MO 1000000009
using namespace std;

inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar(); 
	return ret;
}

struct node
{
	int l, r;
}a[N];

//_
int now,x[N],n,m,dp[2][N];

bool cmp(const node & a, const node &b)
{
	if(a.l!=b.l)return a.l<b.l;
	return a.r<b.r;
}

//inline
inline void upt(int & a, int b)
{
	a=(a+b)%MO;
}

int main()
{
//	freopen("xmasinterval.in","r",stdin);
//	freopen("xmasinterval.out","w",stdout);
	n=read(); m=read();
//	if(n<=10000 && m<=10000)
//	{
	for(int i=1; i<=n; ++i)a[i].l=read(),a[i].r=read();
	for(int i=1; i<=m; ++i)x[i]=read();
	sort(x+1,x+m+1);
	m=unique(x+1,x+m+1)-x-1;
	sort(a+1,a+n+1,cmp);
	dp[0][0]=1; now=0;
	for(int i=1; i<=n; ++i)
	{
		now^=1;
//	    dp[now][0]=dp[now^1][0];
		for(int j=0; j<=m; ++j)
	    {
	    	dp[now][j]=dp[now^1][j];
	    	if(a[i].l<=x[i] && a[i].r>=x[i])
			{
				if(j) upt(dp[now][j],dp[now^1][j-1]); 
			}else upt(dp[now][j],dp[now^1][j]);
	    }
	}
	printf("%d\n",dp[now][m]);
//	}
}//jisou zhuangya

