#include<iostream>
#include<cstdio>
#define NN 1001000+1000
#define eps 5e-7
using namespace std;
double pow[NN]={0};
double ans[NN]={0};
int a[NN]={0};
double brute_solve(int n){
	double res;
	double ans=0;
	for(int i=1;i<=n;++i){
		res=0.5;
		int cnt=1;
		for(int j=i-1;j>0;--j){
			if(a[j]>=a[i]){
				++cnt;
				res+=pow[cnt];
			}
			else res+=pow[cnt];
		}
		double multi=1;
		cnt=0;
		for(int j=i+1;j<=n;++j){
			if(a[j]>a[i]){
				++cnt;
				multi+=pow[cnt];
			}
			else multi+=pow[cnt];
		}
		ans+=a[i]*multi*res;
	}
	return ans/n/n;
}
double about_solve(int n){
	double test=0;
	for(int i=1;i<=n;++i){
		if(a[i]>test)test=a[i];
	}
	test=2*test/n;
	double res=0,ans=0;
	for(int i=1;i<=n;++i){
		res=0.5;
		int cnt=1;
		for(int j=i-1;j>0;--j){
			if(a[j]>=a[i]){
				++cnt;
				res+=pow[cnt];
			}
			else res+=pow[cnt];
			if(test*pow[cnt]*res<eps){
				break;
			}
		}
		double multi=1;
		cnt=0;
		for(int j=i+1;j<=n;++j){
			if(a[j]>a[i]){
				++cnt;
				multi+=pow[cnt];
			}
			else multi+=pow[cnt];
			if(test*multi*pow[cnt]<eps){
				break;
			}
		}
		ans+=a[i]*multi*res;
	}
	return ans/n/n;
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int n;
	scanf("%d",&n);
	pow[0]=1;
	for(int i=1;i<=n+10;++i){
		pow[i]=pow[i-1]/2;
	}
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
	}
	if(n<=10100){
		printf("%.10lf\n",brute_solve(n));
		return 0;
	}
	else printf("%.10lf\n",about_solve(n));
	
}
