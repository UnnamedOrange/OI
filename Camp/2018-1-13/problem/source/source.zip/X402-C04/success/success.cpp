#include<iostream>
#include<map>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

//9876 93 32 45
//296102618
using namespace std;

typedef long long ll;
typedef pair<int,int> pr;
const ll md=1e9+7;
const ll N=1e6+9;

ll s,t,n,m;
ll fac[N],inv[N],pows[N];
map<pr,ll> f;

inline void chk(ll &a){if(a>=md)a-=md;}

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)
			ret=ret*a%md;
		a=a*a%md;
		b>>=1;
	}
	return ret;
}

inline ll c(ll a,ll b)
{
	return fac[a]*inv[b]%md*inv[a-b]%md;
}

inline void init()
{
	fac[0]=1;
	for(ll i=1;i<N;i++)
		fac[i]=fac[i-1]*i%md;
	inv[N-1]=qpow(fac[N-1],md-2);
	for(ll i=N-1;i>=1;i--)
		inv[i-1]=inv[i]*i%md;
	for(ll i=1;i<N;i++)
		chk(pows[i]=c(i,m-n-1)+pows[i-1]);
}

inline ll dfs(int id,ll res)
{
	pr cur=pr(id,res);
	if(f.find(cur)!=f.end())
		return f[cur];
	if(id==n+1)
	{
		if(m==n)return 1;
		if(m==n+1)return s-res;
		return pows[s-res-1];
	}

	ll ret=0;
	for(ll i=1;i<=min(t,s-res);i++)
		chk(ret+=dfs(id+1,res+i));
	return f[cur]=ret;
}

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);

	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
	init();
	
	printf("%lld\n",dfs(1,0));
	return 0;
}
