#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n,m,L[50005],R[50005],pos[50005],w[50005],cnt,sum[25];
pair<int,int> b[50005];
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d%d",&L[i],&R[i]);
	for(int i=1;i<=m;i++) scanf("%d",&pos[i]),b[i]=make_pair(pos[i],i);
	sort(b+1,b+m+1);
	for(int i=1;i<=m;i++){
		if(i==1||b[i].first!=b[i-1].first) w[++cnt]=b[i].first;
		pos[b[i].second]=cnt;
	}
	for(int i=1;i<=n;i++){
		int x=n+1,y=-1;
		for(int j=1;j<=cnt;j++){
			if(L[i]<=w[j]){
				x=j;break;
			}
		}
		for(int j=cnt;j;j--){
			if(R[i]>=w[j]){
				y=j;break;
			}
		}
		L[i]=x;R[i]=y;
	}
	int ans=0;
	for(int i=0;i<(1<<n);i++){
		memset(sum,0,sizeof(sum));
		for(int p=1;p<=n;p++){
			if(i&(1<<p-1)){
				if(L[p]>R[p]) continue;
				sum[L[p]]++;sum[R[p]+1]--;
			}
		}
		for(int p=1;p<=cnt;p++) sum[p]+=sum[p-1];
		bool t=1;
		for(int p=1;p<=m;p++){
			if(!sum[pos[p]]){
				t=0;break;
			}
		}
		if(t) ans++;
	}
	printf("%d",ans);
	return 0;
}