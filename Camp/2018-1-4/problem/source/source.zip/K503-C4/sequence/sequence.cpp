#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#define maxn 25
using namespace std;
int n,a[maxn],ans,pos;
bool check(){
	for(int i=1;i<=n;i++)
		if(a[i]!=i)return 0;
	return 1;
}
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("sequence.in","r",stdin);freopen("sequence.out","w",stdout);
	int T;scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		pos=n;ans=0;
		while(!check()){
			while(a[pos]==pos)pos--;
			int p;
			for(int i=1;i<=pos;i++)
				if(a[i]==pos){p=i;break;}
			if(p!=1){
				ans++;
				reverse(a+1,a+p+1);
			}
			ans++;
			reverse(a+1,a+pos+1);
		}
		printf("%d\n",ans);
	}
	return 0;
}
