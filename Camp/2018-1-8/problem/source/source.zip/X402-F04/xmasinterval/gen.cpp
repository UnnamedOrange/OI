//2018-1-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int main(){
	freopen("xmasinterval.in", "w", stdout);

	srand(time(NULL));
	int n = rand()%5 + 2, m = rand() % 3 + 2, V = 10;
	printf("%d %d\n", n, m);

	int l, r, len;
	For(i, 1, n){
		l = rand()%V + 1; len = V - l + 1;
		r = l + rand()%len;
		printf("%d %d\n", l, r);
	}

	For(i, 1, m) printf("%d\n", rand()%V + 1);

	return 0;
}
