#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 500010;
//rem
const int mod = 1000000009;

int n, m, x[maxn], dp[maxn];

struct node{
	int l, r;
}a[maxn];

bool cmp(node c, node d){
	return c.l == d.l ? c.r > d.r : c.l < d.l;
}

void Get(){
	n = read(), m = read();
	For(i, 1, n) a[i].l = read(), a[i].r = read();
	For(i, 1, m) x[i] = read();

	sort(a+1, a+n+1, cmp);
	sort(x+1, x+m+1);
}

int lp[maxn], rp[maxn], vis[maxn];

void solve_bf(){
	For(i, 1, n){
		lp[i] = lower_bound(x+1, x+m+1, a[i].l) - x;
		rp[i] = upper_bound(x+1, x+m+1, a[i].r) - x;
	}

	int tmp = (1 << n) - 1, Ans = 0;
	For(i, 0, tmp){
		For(j, 1, m) vis[j] = 0;
		For(j, 1, n){
			if(i & (1 << j-1)){
				++ vis[lp[j]];
				-- vis[rp[j]];
			}
		}

		int sum = 0, flag = 0;
		For(j, 1, m){
			sum += vis[j];
			if(sum < 1) {flag = 1; break;}
		}

		if(!flag) ++ Ans;
	}

	printf("%d\n", Ans);
}

void solve_higher_bf(){
	dp[0] = 1;
	For(i, 1, n){
		int lpos = lower_bound(x+1, x+m+1, a[i].l) - x - 1;
		int rpos = upper_bound(x+1, x+m+1, a[i].r) - x - 1;

		For(j, rpos, m) (dp[j] += dp[j]) %= mod;
		For(j, lpos, rpos-1) (dp[rpos] += dp[j]) %= mod;
	}

	printf("%d\n", dp[m]);
}

int mo(int x){
	if(x >= mod) x -= mod;
	return x;
}

int tree[maxn << 2], tag[maxn << 2];

void pushdown(int h,int l,int r){
	if(tag[h] == 1) return;
	tree[h] = 1ll * tree[h] * tag[h] % mod;
	if(l == r){
		tag[h] = 1;
		return;
	}

	tag[h<<1] = 1ll * tag[h<<1] * tag[h] % mod;
	tag[h<<1|1] = 1ll * tag[h<<1|1] * tag[h] % mod;
	
	tag[h] = 1;
}

void pushup(int h){tree[h] = mo(tree[h<<1] + tree[h<<1|1]);}

void build(int h,int l,int r){
	tag[h] = 1;
	if(l == r) return;

	int mid = l+r >> 1;
	build(h<<1, l, mid);
	build(h<<1|1, mid+1, r);
}

void insert(int h,int l,int r,int pos,int val){
	pushdown(h, l, r);
	if(l == r){
		tree[h] += val;
		tree[h] = mo(tree[h]);
		return ;
	}

	int mid = l+r >> 1;
	if(pos <= mid) insert(h<<1, l, mid, pos, val);
	else insert(h<<1|1, mid+1, r, pos, val);

	pushdown(h<<1, l, mid);
	pushdown(h<<1|1, mid+1, r);

	pushup(h);
}

void updamul(int h,int l,int r,int s,int e,int mul){
	pushdown(h, l, r);
	if(l == s && r == e){
		tag[h] = 1ll * tag[h] * mul % mod;
		pushdown(h, l, r);
		return;
	}

	int mid = l+r >> 1;
	if(e <= mid) updamul(h<<1, l, mid, s, e, mul);
	else if(s > mid) updamul(h<<1|1, mid+1, r, s, e, mul);
	else updamul(h<<1, l, mid, s, mid, mul), updamul(h<<1|1, mid+1, r, mid+1, e, mul);

	pushdown(h<<1, l, mid);
	pushdown(h<<1|1, mid+1, r);

	pushup(h);
}

int query(int h,int l,int r,int s,int e){
	pushdown(h, l, r);
	if(l == s && r == e){
		return tree[h];
	}

	int mid = l+r >> 1, nowans = 0;
	if(e <= mid) nowans = query(h<<1, l, mid, s, e);
	else if(s > mid) nowans = query(h<<1|1, mid+1, r, s, e);
	else nowans = mo(query(h<<1, l, mid, s, mid) + query(h<<1|1, mid+1, r, mid+1, e));

	pushdown(h<<1, l, mid);
	pushdown(h<<1|1, mid+1, r);

	pushup(h);
	return nowans;
}

void solve(){
	build(1, 0, m);
	insert(1, 0, m, 0, 1);
	For(i, 1, n){
		int lpos = lower_bound(x+1, x+m+1, a[i].l) - x - 1;
		int rpos = upper_bound(x+1, x+m+1, a[i].r) - x - 1;

		updamul(1, 0, m, rpos, m, 2);
		if(lpos <= rpos-1){
			int nowans = query(1, 0, m, lpos, rpos-1);
			insert(1, 0, m, rpos, nowans);
		}
	}

	printf("%d\n", query(1, 0, m, m, m));
}

int main(){

//	freopen("xmasinterval.in", "r", stdin);
//	freopen("xmasinterval.out", "w", stdout);
	
	Get();
	solve();

	return 0;
}
