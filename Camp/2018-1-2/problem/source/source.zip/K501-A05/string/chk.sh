g++ gen.cpp -o ./gen -lm -static
g++ string.cpp -o ./string -lm -static
g++ cxr.cpp -o ./cxr -lm -static
g++ BF.cpp -o ./BF -lm -static

((cnt = 0))

while true; do
	./gen
	./string
	./cxr
	./BF

	diff string.out string.ans || break;
	diff string.cxr string.ans || break;

	((cnt = cnt + 1))
	echo Correct $cnt times.
done;
