#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for(int i = j; i <= k; i++)
#define Forr(i, j, k) for(int i = j; i >= k; i--)

using namespace std;

int Read(){
	char c = getchar();
	while(c > '9' || c < '0') c = getchar();
	int x = c - '0'; c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

int type, N;

void init(){
    
}

int encode(int x, int y){
	int s = 5;
    For(i, 0, 9) if((x & (1 << i)) && !(y & (1 << i))) return s + i; 
	int bx = 0, by = 0;
	For(i, 0, 9) if(x & (1 << i)) ++bx;
	For(i, 0, 9) if(y & (1 << i)) ++by;
	assert(bx < by);
	For(i, 0, 3) if((by & (1 << i)) && !(bx & (1 << i))) return i + 1;
	return -1;
}

bool decode(int q, int h){
	if(h >= 5){
		h -= 5;
		return bool(q & (1 << h));
	}
	else{
		int b = 0;
		For(i, 0, 9) if(q & (1 << i)) ++b;
		return !(b & (1 << (h - 1)));
	}
}

int main(){
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x = Read(), y = Read();
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
