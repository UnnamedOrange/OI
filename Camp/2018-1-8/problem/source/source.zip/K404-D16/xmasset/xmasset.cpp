#include <cstdio>
#include <string.h>
#define F(x,y,z) for (x=y;x<=z;++x)
#define Min(x,y) x<y?x:y
using namespace std;
int n,m,ans,t,T;

int main()
{
	int i,j,x,y,q,h;
	scanf("%d",&t);scanf("%d%d",&n,&T);
	if (t==1)
	{
		F(i,1,T)
		{
			ans=1;
			scanf("%d%d",&x,&y);
			while ((x&1)==(y&1)) ++ans,x=x>>1,y=y>>1;
			printf("%d\n",(ans<<1)+(x&1)-1);
		}
	}
	else
	{
		F(i,1,T)
		{
			scanf("%d%d",&q,&h);
			h++;
			int w=h>>1,p=h&1;
			if (((q>>(w-1))&1)==p) printf("yes\n");
						else   printf("no\n");
		}
	}
	return 0;
}


