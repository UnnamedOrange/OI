#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<map>
#include<set>
#include<iomanip>
#include<ctime>
using namespace std;
typedef long long ll;
char xB[1<<15],*xT=xB,*xS=xB;
//#define getchar() (xS==xT&&(xT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xT)?0:*xS++)
inline int read()
{
    int X=0,w=0; char ch=0;
    while(!isdigit(ch)) w|=ch=='-',ch=getchar();
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}
int t,n,x,y,q,h,T,l,r,mid,cnt;
bool flag;
void doit1(int a,int b)
{
	cnt=0;
	l=0;r=n;
	if(a>b)
	{
		cnt+=10;
		swap(a,b);
	}
	while(1)
	{
		++cnt;
		mid=(l+r)>>1;
		if(mid>=a&&mid<b)break;
		if(mid<a)l=mid;
		if(mid>=b)r=mid;
	}
	printf("%d\n",cnt);
	
}
void doit2(int a,int b)
{
	l=0;r=n;flag=0;
	if(b>10)
	{
		b-=10;
		flag=1;
	}
	while(b--)
	{
		mid=(l+r)>>1;
		if(mid<a)l=mid;
		if(mid>=a)r=mid;
	}
	if(flag==0){if(mid<a)puts("no");
	else puts("yes");}
	else 
	{
		if(mid<a)puts("yes");
	else puts("no");
	}
}
int main()
{
	register int i;
	t=read();n=read();T=read();
	if(t==1)
	{
		for(i=1;i<=T;++i)
		{
			x=read();y=read();
			doit1(x,y);
		}
	}
	else if(t==2)
	{
		for(i=1;i<=T;++i)
		{
			q=read();h=read();
			doit2(q,h);
		}
	}
}