//2018-1-2
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1000+5)

int n, p, q, val[N];

struct node{
	int x, y, z, a, b, c, d, e, f;
	
	void read(){
		scanf("%d%d%d%d%d%d%d%d%d", &x, &y, &z, &a, &b, &c, &d, &e, &f);
	}

	LL calc(){
		return 1ll*a*abs(val[x]-val[y]) + 1ll*b*abs(val[y]-val[z]) + 1ll*c*abs(val[z]-val[x]) +
			   1ll*d*(val[x]-val[y]) + 1ll*e*(val[y]-val[z]) + 1ll*f*(val[z]-val[x]);
	}
}h[N];

struct tnode{
	int x, y, r;

	void read(){
		scanf("%d%d%d", &x, &y, &r);
	}

	bool check(){
		if(r == 0) return val[x] <= val[y];
		if(r == 1) return val[x] == val[y];
		return val[x] < val[y];
	}
}con[N];

LL Calc(){
	LL ret = 0;
	For(i, 1, n) ret += val[i];	
	For(i, 1, p) ret += h[i].calc();
	return ret;
}

int main(){
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);

	int T, w;
	LL ans, tans;

	scanf("%d", &T);

	while(T--){
		scanf("%d%d%d%d", &n, &w, &p, &q);
		For(i, 1, p) h[i].read();
		For(i, 1, q) con[i].read();		
		
		ans = 1ll << 60;
		For(i, 0, (1<<n)-1){
			For(j, 1, n)
				if(i & (1<<(j-1))) val[j] = -w; else val[j] = w;
		
			bool flag = true;
			For(j, 1, q) if(!con[j].check()){
				flag = false; break;
			}
			if(!flag) continue;

			ans = min(ans, tans = Calc());
		}

		printf("%lld\n", ans);
	}

	return 0;
}
