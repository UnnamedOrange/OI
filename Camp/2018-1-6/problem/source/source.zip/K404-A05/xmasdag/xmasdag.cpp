//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
typedef long long ll;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
//My i/o stream
struct fastio
{
	char s[100000];
	int it,len;
	fastio(){it=len=0;}
	inline char get()
	{
		if(it<len)return s[it++];it=0;
		len=fread(s,1,100000,stdin);
		if(len==0)return EOF;else return s[it++];
	}
	bool notend()
	{
		char c=get();
		while(c==' '||c=='\n')c=get();
		if(it>0)it--;
		return c!=EOF;
	}
}_buff;
#define geti(x) x=getnum()
#define getii(x,y) geti(x),geti(y)
#define getiii(x,y,z) getii(x,y),geti(z)
#define puti(x) putnum(x),putchar(' ')
#define putii(x,y) puti(x),puti(y)
#define putiii(x,y,z) putii(x,y),puti(z)
#define putsi(x) putnum(x),putchar('\n')
#define putsii(x,y) puti(x),putsi(y)
#define putsiii(x,y,z) putii(x,y),putsi(z)
inline ll getnum()
{
	ll r=0;bool ng=0;char c;c=_buff.get();
	while(c!='-'&&(c<'0'||c>'9'))c=_buff.get();
	if(c=='-')ng=1,c=_buff.get();
	while(c>='0'&&c<='9')r=r*10+c-'0',c=_buff.get();
	return ng?-r:r;
}
template<class T> inline void putnum(T x)
{
	if(x<0)putchar('-'),x=-x;
	register short a[20]={},sz=0;
	while(x)a[sz++]=x%10,x/=10;
	if(sz==0)putchar('0');
	for(int i=sz-1;i>=0;i--)putchar('0'+a[i]);
}
inline char getreal(){char c=_buff.get();while(c<=32)c=_buff.get();return c;}

const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=998244353;
const int maxn=100111;
ll qpow(ll x,ll k){return k==0?1:qpow(x*x%mod,k>>1)*(k&1?x:1)%mod;}
int n,m,K;
int dp[maxn][511];
vector<int> con[maxn];
inline void upd(int &x,int v){x=x+v>=mod?x+v-mod:x+v;}
bool vis[maxn];
ll c[511][511];
ll pw[511][511];
ll f[511];
int ans[maxn];
void dfs(int x)
{
	vis[x]=1;
	for(int i=0;i<con[x].size();i++)
	{
		int u=con[x][i];
		if(!vis[u])dfs(u);
		for(int j=0;j<=K;j++)upd(dp[x][j+1],dp[u][j]);
	}
	if(dp[x][K+1])
	{
		for(int i=0;i<=K;i++)upd(dp[x][i],f[i]*dp[x][K+1]%mod);
		dp[x][K+1]=0;
	}
	for(int i=0;i<=K;i++)upd(ans[x],1ll*dp[x][i]*pw[i][K]%mod);
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	getiii(n,m,K);
//	cerr<<n<<" "<<m<<" "<<K<<endl;
	for(int i=0;i<=K+1;i++)
	{
		pw[i][0]=1;
		for(int j=1;j<=K+1;j++)pw[i][j]=pw[i][j-1]*i%mod;
	}
	for(int i=0;i<=K+1;i++)
	{
		c[i][0]=1;
		for(int j=1;j<=i;j++)
		{
			c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
		}
	}
	for(int i=0;i<=K;i++)
	{
		if((i+K)&1)f[i]=(mod-c[K+1][i])%mod;
		else f[i]=c[K+1][i];
	}
	for(int i=1;i<=m;i++)
	{
		int x,y;
		getii(x,y);
		con[y].PB(x);
	}
	upd(dp[1][0],1);
	for(int i=2;i<=n;i++)
	{
		if(vis[i])continue;
		dfs(i);
	}
	for(int i=1;i<=n;i++)printf("%d\n",ans[i]);
	return 0;
}
