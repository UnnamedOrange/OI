#include<bits/stdc++.h>
#define maxn 200000
using namespace std;
int head[maxn], nxt[maxn], a[maxn], edge, in[maxn], out[maxn], now, lastans;
int v[maxn], c[maxn], h[maxn], right[maxn], first[maxn];
void create(int u, int v)
{
	edge++; a[edge] = v; nxt[edge] = head[u]; head[u] = edge;
}
void dfs(int u, int fa)
{
	in[u] = ++now; v[now] = c[u];
	for (int i = head[u]; i; i = nxt[i])
	{
		int v = a[i];
		if (v != fa) dfs(v, u);
	}
	out[u] = now;
}
int main()
{
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	int n, m, t;
	scanf("%d%d%d", &n, &m, &t);
	for (int i = 1; i <= n; i++)
		scanf("%d", &c[i]);
	for (int i = 1; i <= n - 1; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		create(u, v); create(v, u);
	}
	dfs(1, 0);
	while (m)
	{
		int cz;
		scanf("%d", &cz);
		if (cz == 1)
		{
			int u, l, r, ans = 0;
			scanf("%d%d%d", &u, &l, &r);
			if (t) {u ^= lastans; l ^= lastans; r ^= lastans;}
			for (int i = in[u]; i <= out[u]; i++)
				if (h[v[i]] != m)
				{
					if (v[i] >= l && v[i] <= r) ans++;
					h[v[i]] = m;
				}
			lastans = ans;
			printf("%d\n", ans);
		}
		else
		{
			int x, y;
			scanf("%d%d", &x, &y);
			x ^= lastans; y ^= lastans;
			v[in[x]] = y;
		}
		m--;
	}
	return 0;
}
