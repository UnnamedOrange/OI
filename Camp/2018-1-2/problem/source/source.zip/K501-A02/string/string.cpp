#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
char s[200010],c[100010];
int p[200010],pos,mx,n;
void solve(){
	mx=0;pos=0;
	memset(p,0,sizeof(p));
	for (int i=1;i<=n;++i){
		if (mx>i){
			if (p[pos*2-i]<mx-i) p[i]=p[pos*2-i];
			else p[i]=mx-i;			
		}else p[i]=1;
		while (s[i+p[i]]==s[i-p[i]] && i-p[i]>0 && i+p[i]<=n)
			p[i]++;
		if (p[i]>mx){
			mx=p[i];
			pos=i;	
		}
	}
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T=read();
	while (T--){
		int k=read(); 
		scanf("%s",&c);
		n=0;
		if (k==1){
			printf("-1\n");
			continue;	
		}
		for (int i=0;i<k;++i){
			s[++n]='#';
			s[++n]=c[i];	
		}
		s[++n]='#';
		solve();
		if (p[(n+1)/2]+(n+1)/2<n){
			printf("1\n");
			continue;	
		} 
		int flag=-1;
		for (int i=1;i<=n;i+=2){
			int x=(i-1)/2+1;
			int y=(n-i)/2+i;
			if (x+p[x]<i && y-p[y]>i){
				flag=2;
				break;	
			}
		}
		printf("%d\n",flag);
	} 
	return 0;
}

