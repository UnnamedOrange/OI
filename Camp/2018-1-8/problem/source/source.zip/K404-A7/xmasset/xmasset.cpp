#include <bits/stdc++.h>

int type, N;

int encode(int x, int y)
{
	for (int i = 0; i <= 9; ++i)
		if ((x & (1 << i)) != (y & (1 << i)))
			return ((x & (1 << i)) ? 1 : 0) * 10 + i;
}

bool decode(int q, int h)
{
	int pos = h % 10, mark = h / 10;
	return (((q >> pos) & 1) == mark);
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
    return 0;
}

