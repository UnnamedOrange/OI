#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=30100;

int n;

int last[N],ecnt;
struct EDGE{int to,nt;}e[N<<1];
inline void add(int u,int v)
{e[++ecnt]=(EDGE){v,last[u]};last[u]=ecnt;}

int w[N],r[N];

namespace violence
{
	int a[N];
	int fa[N];
	int ans=0;
	
	void dfs(int u)
	{
		for(int i=last[u],v;i;i=e[i].nt)
			if(fa[u]!=(v=e[i].to))
				fa[v]=u,dfs(v);
	}
	
	void solve(int u)
	{
		bool book[12];
		register int i,j,res;
		do
		{
			if(a[1]!=u) break;
			bool flag=0;
			memset(book,0,sizeof(book));
			book[a[1]]=1;
			for(i=2;i<=n;++i)
			{
				j=a[i];
				while(fa[j])
				{
					j=fa[j];
					if(!book[j]){flag=1;break;}
				}
				if(flag)break;
				book[a[i]]=1;
			}
			if(flag) continue;
			
			res=0;
			for(i=1;i<=n;++i) res+=i*w[a[i]];
			ans=max(ans,res);
		}while(next_permutation(a+2,a+1+n));
	}
	
	void Main()
	{
		register int i,j;
		for(i=1;i<=n;++i)
		{
			if(r[i])
			{
				fa[i]=0,dfs(i),a[1]=i;
				for(int j=2;j<=i;++j) a[j]=j-1;
				for(int j=i+1;j<=n;++j) a[j]=j;
				solve(i);
			}
		}
		cout<<ans<<endl;
	}
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	
	n=read();
	register int i,u,v;
	for(i=1;i<n;++i)
		u=read(),v=read(),
		add(u,v),add(v,u);
	for(i=1;i<=n;++i)
		w[i]=read(),r[i]=read();
	violence::Main();
	return 0;
}
/*
5
1 2
1 3
2 4
3 5
4 1
3 0
4 0
3 0
1 0

42
*/

