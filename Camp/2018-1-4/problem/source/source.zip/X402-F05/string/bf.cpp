#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

int n, m;
char S[35], T[7][35];
int l[7];

int main(){

	freopen("string.in", "r", stdin);
	freopen("string.ans", "w", stdout);

	scanf("%d%d", &n, &m);

	For(i, 1, n) scanf("%s", T[i]), l[i] = strlen(T[i]);

	int ans = 0;

	For(i, 0, (1 << m) - 1){
		For(j, 0, m - 1){
			bool c = i & (1 << j);
			S[j] = c + '0', S[2 * m - j - 1] = (c ^ 1) + '0';
		}
		S[2 * m] = '\0';
		bool ok = true;
		For(j, 1, n){
			bool match = false;
			For(k, 0, 2 * m - l[j])
				if(!strncmp(S + k, T[j], l[j])){
					match = true;
					break;
				}
			if(!match){
				ok = false; break;
			}
		}
		if(ok) ++ans;
	}

	printf("%d\n", ans);

	return 0;
}
