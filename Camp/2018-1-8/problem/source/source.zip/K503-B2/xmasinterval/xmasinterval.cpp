#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=5e5+5,mod=1e9+9;
int f[maxn],num[maxn],ans=0;
int n,m,s=0;
struct cp{
	int l,r;
}e[maxn];
bool cmp(cp a,cp b){
	if(a.l==b.l) return a.r<b.r;
	return a.l<b.l;
}
void dfs(){
	for(int i=1;i<=m;i++)
		if(e[i].r==f[n]){
			ans++;
			return ;
		}
	for(int i=1;i<=n;i++){
		dfs();
	}
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d%d",&e[i].l,&e[i].r);
	for(int i=1;i<=m;i++) scanf("%d",&f[i]);
	sort(e+1,e+n+1,cmp);
	sort(f+1,f+n+1);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(e[i].l<=f[j]&&e[i].r>=f[j]) num[f[j]]++;
			else break;
	for(int i=1;i<=m;i++) if(num[f[i]]==1) s++;
	if(s==m){
		printf("1\n");
		return 0;
	}
	printf("0\n");
/*	for(int i=1;i<=n;i++){
		if(e[i].l<=f[n]&&e[i].r>=f[n]) e[i].r=f[n];
		if(e[i].l<=f[1]&&e[i].r>=f[1]) e[i].l=f[1];
	}*/
///	memset(num,0,sizeof(num));
///	dfs();
//	printf("%d\n",ans);
	return 0;
}
