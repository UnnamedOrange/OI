#include<cstdio>
#include<stack>
#include<algorithm>
#include<vector>
using namespace std;

const int maxn = 1e6 + 5;
int n, m, cnt = 0, nnt = 0, ans = 0;
int pre[maxn], num[maxn], mim[maxn], n_size[maxn], dpp[maxn];  
bool flag[maxn], qwe[maxn];
vector<int> chu[maxn];
vector<int> jin[maxn];
vector<int> edge[maxn];
stack<int> s;

inline void putit()
{
	int a, b;
	scanf("%d%d", &n, &m);
	for(register int i = 1; i <= m; ++i)
	{
		scanf("%d%d", &a, &b);
		chu[a].push_back(b); jin[b].push_back(a);
	}
}

inline void tarjan(int t)
{
	s.push(t);
	cnt++; pre[t] = cnt; mim[t] = cnt;
	for(register int i = chu[t].size() - 1; i >= 0; --i)
	{
		int now = chu[t][i];
		if(pre[now] == 0)	tarjan(now);
		if(num[now] == 0)
			mim[t] = min(mim[t], mim[now]);
	}
	if(mim[t] == pre[t])
	{
		nnt++;
		for(;;)
		{
			int now = s.top(); s.pop();
			num[now] = nnt;
			n_size[nnt]++;
			if(pre[now] == mim[now])	break;
		}
	}
}

inline void prepare()
{
	for(int i = 1; i <= n; ++i)
	{
		if(pre[i] == 0)	tarjan(i);
	}
	for(int i = 1; i <= n; ++i)
	{
		for(int j = chu[i].size() - 1; j >= 0; --j)
		{
			int now = num[chu[i][j]];
			if(num[i] == now) continue;
			edge[num[i]].push_back(now);
			flag[now] = true;
		}
	}
}

int dp(int t)
{
	if(qwe[t] == true)	return dpp[t];
	qwe[t] = false;
	dpp[t] = n_size[t]; int ret = 0;
	for(int i = edge[t].size() - 1; i >= 0; --i)
	{
		ret = max(ret, dp(edge[t][i]));
	}
	dpp[t] += ret;
//	printf("t == %d dp == %d\n", t, dpp[t]);
	return dpp[t];
}

inline void workk()
{
	for(int i = 1; i <= nnt; ++i)
	{
		if(flag[i] == false)
		{
			ans = max(ans, dp(i));
		}
	}
	printf("%d", ans);
}

int main()
{
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	putit();
	prepare();
	workk();
	return 0;
//	printf("\n");
//	for(int i = 1; i <= nnt; ++i)
//	{
//		printf("nnti == %d dp == %d\n", i, dpp[i]);
//	}
//	for(int i = 1; i <= n; ++i)
//	{
//		printf("i == %d num == %d size == %d\n", i, num[i], n_size[num[i]]);
//	}
//	for(int i = 1; i <= nnt; ++i)
//	{
//		printf("i == %d  ", i);
//		for(int j = edge[i].size() - 1; j >= 0; --j)
//		{
//			printf("%d ", edge[i][j]);
//		}
//		printf("\n");
//	}
}
