#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cctype>
#include<set>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)
#define mid (l+r>>1)
#define lch (rt<<1)
#define rch (rt<<1|1)

using namespace std;
const int N=100005,M=4000005,K=20000005;
int n,q,T,ans,cnt,h[N],tp,x,ql,qr,cur;
int a[N],c[N],lst[N],nxt[N],tot2,tot3;
int nw_lst,nw_nxt,l[N],r[N],dfn,root[N<<2];
set <int> st[N];
set <int> :: iterator it;
struct edge{int v,n;} e[N<<1];
struct seg{int l,r,s;} t2[M],t3[K];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void addedge(int u,int v)
{
	e[cnt]=(edge){v,h[u]},h[u]=cnt++;
	e[cnt]=(edge){u,h[v]},h[v]=cnt++;
}

void dfs(int x,int fa)
{
	l[x]=++dfn;
	for(int i=h[x]; i!=-1; i=e[i].n)
		if(e[i].v!=fa) dfs(e[i].v,x);
	r[x]=dfn;
}

void modify3(int l,int r,int &rt,int x3,int c)
{
	if(!rt) rt=++tot3;
	if(l==r)
	{
		t3[rt].s+=c;
		return;
	}
	if(x3<=mid) modify3(l,mid,t3[rt].l,x3,c);
	else modify3(mid+1,r,t3[rt].r,x3,c);
	t3[rt].s=t3[t3[rt].l].s+t3[t3[rt].r].s;
}

void modify2(int l,int r,int &rt,int x2,int x3,int c)
{
	if(!rt) rt=++tot2;
	if(l==r)
	{
		modify3(0,n-1,t2[rt].s,x3,c);
		return;
	}
	if(x2<=mid) modify2(l,mid,t2[rt].l,x2,x3,c);
	else modify2(mid+1,r,t2[rt].r,x2,x3,c);
	modify3(0,n-1,t2[rt].s,x3,c);
}

void modify1(int l,int r,int rt,int x1,int x2,int x3,int c)
{
	if(l==r)
	{
		modify2(1,n,root[rt],x2,x3,c);
		return;
	}
	if(x1<=mid) modify1(l,mid,lch,x1,x2,x3,c);
	else modify1(mid+1,r,rch,x1,x2,x3,c);
	modify2(1,n,root[rt],x2,x3,c);
}

int query3(int l,int r,int rt,int ql3,int qr3)
{
	if(!rt) return 0;
	if(ql3<=l && r<=qr3) return t3[rt].s;
	if(qr3<=mid) return query3(l,mid,t3[rt].l,ql3,qr3);
	if(mid<ql3) return query3(mid+1,r,t3[rt].r,ql3,qr3);
	return query3(l,mid,t3[rt].l,ql3,qr3)+query3(mid+1,r,t3[rt].r,ql3,qr3);
}

int query2(int l,int r,int rt,int ql2,int qr2)
{
	if(!rt) return 0;
	if(ql2<=l && r<=qr2) return query3(0,n-1,t2[rt].s,0,::l[x]-1);
	if(qr2<=mid) return query2(l,mid,t2[rt].l,ql2,qr2);
	if(mid<ql2) return query2(mid+1,r,t2[rt].r,ql2,qr2);
	return query2(l,mid,t2[rt].l,ql2,qr2)+query2(mid+1,r,t2[rt].r,ql2,qr2);
}

int query1(int l,int r,int rt,int ql1,int qr1)
{
	if(ql1<=l && r<=qr1) return query2(1,n,root[rt],ql,qr);
	if(qr1<=mid) return query1(l,mid,lch,ql1,qr1);
	if(mid<ql1) return query1(mid+1,r,rch,ql1,qr1);
	return query1(l,mid,lch,ql1,qr1)+query1(mid+1,r,rch,ql1,qr1);
}
	
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1s.out","w",stdout);
	n=getint(),q=getint(),T=getint();
	memset(h,-1,sizeof(h));
	rep(i,1,n) c[i]=getint();
	rep(i,1,n-1) addedge(getint(),getint());
	dfs(1,0);
	rep(i,1,n) a[l[i]]=c[i],c[i]=0,st[i].insert(0),st[i].insert(n+1);
	rep(i,1,n) lst[i]=c[a[i]],c[a[i]]=i;
	rep(i,1,n) c[i]=n+1;
	repd(i,n,1) nxt[i]=c[a[i]],c[a[i]]=i;
	rep(i,1,n)
	{
	//	printf("%d %d %d\n",i,tot2,tot3);
		modify1(1,n,1,i,a[i],lst[i],1),st[a[i]].insert(i);
	}
	while(q--)
	{
	//	printf("%d %d\n",tot2,tot3);
		tp=getint();
		if(tp==1)
		{
			x=getint()^(ans*T),ql=getint()^(ans*T),qr=getint()^(ans*T);
			printf("%d\n",ans=query1(1,n,1,l[x],r[x]));
		}
		else
		{
			x=l[getint()^(ans*T)],cur=a[x];
			modify1(1,n,1,x,cur,lst[x],-1);
			if(lst[x]) nxt[lst[x]]=nxt[x];
			if(nxt[x]<=n)
			{
				modify1(1,n,1,nxt[x],a[nxt[x]],x,-1);
				modify1(1,n,1,nxt[x],a[nxt[x]],lst[x],1);
				lst[nxt[x]]=lst[x];
			}
			
			st[cur].erase(x),a[x]=cur=getint()^(ans*T);
			it=st[cur].lower_bound(x);
			nw_nxt=*it,nw_lst=*(--it);
			st[a[x]].insert(x);
			
			modify1(1,n,1,x,a[x],nw_lst,1);
			if(nw_lst) nxt[nw_lst]=x;
			if(nw_nxt<=n)
			{
				modify1(1,n,1,nw_nxt,a[nw_nxt],nw_lst,-1);
				modify1(1,n,1,nw_nxt,a[nw_nxt],x,1);
				lst[nw_nxt]=x;
			}
			nxt[x]=nw_nxt,lst[x]=nw_lst;
		}
	}
//	printf("%d %d\n",tot2,tot3);
	return 0;
}
