#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int MAXN = 20;
int n;
int ans = 0;
int r[MAXN];
int head[MAXN];
int w[MAXN];
int fa[MAXN];
int cnt = 0;
int status[MAXN];
int num[MAXN];
int dfn[MAXN];
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

struct edge {
	int v;
	int next;
} g[MAXN * 2];

void addedge(int u, int v)
{
	g[++cnt].v = v;
	g[cnt].next = head[u];
	head[u] = cnt;
}
void open()
{
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}

void DFS(int x)
{
	dfn[++cnt] = x;
	for(int j = head[x]; j; j = g[j].next) {
		int to = g[j].v;
		if(!fa[to] && to != 1) {
			fa[to] = x;
			DFS(to);
		}
	}
}

void DFS2(int x, int sum)
{
	if(x == n + 1) {
	//	cout<<sum<<endl;
		ans = max(ans, sum);
		return ;
	}
	int t = dfn[x];
	for(int i = status[fa[t]] + 1; i <= n; i++) {
		if(!num[i]) {
			num[i] = 1;
			status[t] = i;
			DFS2(x + 1, sum + i * w[t]);
			num[i] = 0;
		}
	}
}
int main()
{
	open();
	n = read();
	for(int i = 1; i < n; i++) {
		int u = read(), v = read();
		addedge(u, v);
		addedge(v, u);
	}
	for(int i = 1; i <= n; i++) {
		w[i] = read(), r[i] = read();
	}
	for(int i = 1; i <= n; i++) {
		if(r[i]) {
			cnt = 0;
			memset(dfn, 0, sizeof dfn);
			memset(fa, 0, sizeof fa);
			memset(status, 0, sizeof status);
			memset(num, 0, sizeof num);
			fa[i] = n + 1;
			DFS(i);
			DFS2(1, 0);
		}
	}
	printf("%d\n", ans);
	close();
	return 0;
}
