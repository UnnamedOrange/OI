#include<bits/stdc++.h>
using namespace std;
const int kcz=1000000007;
int s,t,n,m,dp[3][519615],ans; 
void add(int &x,int y){
	 x=(x+y)%kcz;}
int fastmi(int i,int j){
	int ans=1;
	long long now=i;
	while (j){
		if (j&1) ans=ans*now%kcz;
		now=now*now%kcz;
		j>>=1;
	}
	return ans;
}
int cal(int i,int j){
	long long ans=1;
	for (int k=1;k<=i;k++)
	  ans=ans*(j-k+1)%kcz;
	for (int k=1;k<=i;k++)
	  ans=ans*fastmi(k,kcz-2)%kcz;
	return ans;
}
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	 
	scanf("%d%d%d%d",&s,&t,&n,&m);
	dp[0][0]=1;
	for (int i=1;i<=n;i++)
	{
		dp[i&1][0]=0;
		int now=0;
		for (int j=0;j<=(n*t);j++)
		{
			add(now,dp[1-(i&1)][j-1]);
			if (j>t)
				add(now,kcz-dp[1-(i&1)][j-t-1]);
			dp[i&1][j]=now;
		}
	}
	for (int i=n;i<=(n*t);i++)
		for (int j=(m-n)+i;j<=s;j++)
		 add(ans,(long long)(dp[n&1][i])*cal(m-n-1,j-i-1)%kcz);
	cout<<ans;
}
	
