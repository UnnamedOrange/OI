#include <cstdio>

typedef long long ll;
const ll Mod = 1000000007;
ll N, M, S, T;
ll ans;

inline ll fastpow_mod( ll a, ll b ) {
	ll x = 1;
	while( b ) {
		if( b & 1ll ) x = ( x * a ) % Mod;
		a = ( a * a ) % Mod, b >>= 1ll;
	}
	return x;
}

inline ll C( ll n, ll k ) {
	register ll i;
	ll x = 1, y = 1;
	if( n < k )
		return 0;
	for( i = k + 1; i <= n; ++i ) x = ( x * i ) % Mod;
	for( i = 1; i <= n - k; ++i ) y = ( y * i ) % Mod;
	return x * fastpow_mod( y, Mod - 2 ) % Mod;
}

int main() {
	freopen( "success.in", "r", stdin );
	freopen( "success.out", "w", stdout );
	register ll i, j;
	ll res;
	scanf( "%lld%lld%lld%lld", &S, &T, &N, &M );
	ans = C( S, M );
	for( i = M - N; i <= S - N - T + 1; ++i )
		ans = ( ans - C( i, M - N ) + Mod ) % Mod;
	printf( "%lld\n", ( ans + Mod ) % Mod );
	return 0;
}
