#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

long long mod = 998244353;
int n, m, K;
long long ans = 0;
int num[10000];
long long fast(int x, int k)
{
	long long cnt = x % mod;
	long long res = 1;
	while(k) {
		if(k % 2 == 1) {
			res = res * cnt % mod;
			k--;
		}
		else {
			cnt = cnt * cnt % mod;
			k = k / 2;
		}
	}
	return res % mod;
}
void DFS(int l, int r, int k)
{
	if(k == n + 1) {
		for(int i = 1; i <= m; i++) {
		//	cout<<num[i]<<" ";
			ans = (ans + fast(num[i], K)) % mod; 
		}
		//cout<<endl;
		return;
	}
	for(int i = l + 1; i <= m; i++) {
		for(int j = max(i, r + 1); j <= m; j++) {
			for(int t = i; t < j; t++) {
				num[t]++;
			}
			DFS(i, j, k + 1);
			for(int t = i; t < j; t++) {
				num[t]--;
			}
		}
	}
}
void open()
{
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

int main()
{
	open();
 	n = read(), m = read(), K = read();
	n = min(n, m);
	DFS(0, 0, 1);
	printf("%lld\n", ans);
	close();
	return 0;
}
