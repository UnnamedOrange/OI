#include <cstdio>
#include <vector>
using namespace std;
#define N 100050
int st[N],ed[N],euler[N],id,n,q,i,a[N],b[N];
vector<int> g[N];
void dfs(int now,int lst)
{
	st[now]=++id;euler[id]=now;
	for (int ii=0;ii<g[now].size();ii++) if (g[now][ii]!=lst) dfs(g[now][ii],now);
	ed[now]=id;
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree11.out","w",stdout);
	scanf("%d%d%*d",&n,&q);
	for (i=1;i<=n;i++) scanf("%d",&a[i]);
	for (i=1;i<n;i++){
		int x,y;scanf("%d%d",&x,&y);
		g[x].push_back(y);g[y].push_back(x);
	}dfs(1,0);
	while (q--){
		int opt;scanf("%d",&opt);
		if (opt==1){
			int x,y,z,ans=0;scanf("%d%d%d",&x,&y,&z);int l=st[x],r=ed[x];
			for (i=l;i<=r;i++){
				if (!b[a[euler[i]]]&&a[euler[i]]>=y&&a[euler[i]]<=z) ans++;
				b[a[euler[i]]]++;
			}
			for (i=l;i<=r;i++) b[a[euler[i]]]--;
			printf("%d\n",ans);
		}else{
			int x,y;scanf("%d%d",&x,&y);a[x]=y;
		}
	}
	return 0;
}
