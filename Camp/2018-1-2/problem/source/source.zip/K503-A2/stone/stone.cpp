#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<stack>
using namespace std;
int st1[100005],now[100005],st2[100005],ans[4]={0,0,0,1};
int n,a,b;
inline bool cmp(int a,int b){
	return a>b;
}
inline void check(int k){
	int s1=0,s2=0,q1=0,q2=0;
	for(int i=1;i<=k;i++) now[i]=st2[i];
	sort(now+1,now+k+1,cmp);
	for(int i=1;i<=k;i++){
		if(i&1) s1+=now[i]/a,q1+=now[i]/b;
		else s2+=now[i]/b,q2+=now[i]/a;
	}
	if(s1==s2) s2++;
	if(q1==q2) q2++;
	if(s1>s2&&q1<q2) ans[0]++;
	if(s1<s2&&q1>q2) ans[1]++;
	if(s1>s2&&q1>q2) ans[2]++;
	if(s1<s2&&q1<q2) ans[3]++;
}
void dfs(int k,int i){
	if(i>n) return;
	st2[k]=st1[i];
	check(k);
	dfs(k+1,i+1);
	dfs(k,i+1);
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int x;
	scanf("%d%d%d",&n,&a,&b);
	for(int i=1;i<=n;i++) scanf("%d",&x),st1[i]=x%(a+b);
	dfs(1,1);
	printf("%d %d %d %d",ans[0],ans[1],ans[2],ans[3]);
	return 0;
}
