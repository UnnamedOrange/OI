#include<iostream>
#include<cstdio>
#include<vector>
#define NN 6000
using namespace std;
int col[NN]={0};
int p[NN]={0};
int n,m;
int fa[NN]={0};
struct node{
	int to;
	int xt;
}e[2*NN];
int cnt=1;
void add_E(int a,int b){
	e[cnt].to=b;
	e[cnt].xt=p[a];
	p[a]=cnt++;
}
void build(int x){
	for(int i=p[x];i;i=e[i].xt){
		if(fa[x]!=e[i].to){
			fa[e[i].to]=x;
			build(e[i].to);
		}
	}
}
int find(int x,int l,int r){
	int ans=0;
	if(col[x]>=l&&col[x]<=r)ans+=1;
	for(int i=p[x];i;i=e[i].xt){
		if(fa[x]!=e[i].to)ans+=find(e[i].to,l,r);
	}
	return ans;
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int ti;
	scanf("%d%d%d",&n,&m,&ti);
	int last_ans=0;
	for(int i=1;i<=n;++i){
		scanf("%d",&col[i]);
	}
	int a,b;
	for(int i=1;i<n;++i){
		scanf("%d%d",&a,&b);
		add_E(a,b);
		add_E(b,a);
	}
	build(1);
	int kd;
	int node,l,r;
	while(scanf("%d",&kd)==1){
		if(kd==1){
			scanf("%d%d%d",&node,&l,&r);
			if(ti==1){
				node^=last_ans;
				l^=last_ans;
				r^=last_ans;
			}
			printf("%d\n",last_ans=find(node,l,r));
		}
		if(kd==2){
			scanf("%d%d",&node,&r);
			if(ti==1){
				node^=last_ans;
				r^=last_ans;
			}
			col[node]=r;
		}
	}
}
