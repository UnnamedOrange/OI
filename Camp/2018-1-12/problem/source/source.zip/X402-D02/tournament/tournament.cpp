#include<iostream>
#include<cstdio>
#include<cstring>

typedef long long ll;
const int N=310,MOD=998244353;
ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}
ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}

ll fact[N],ifact[N];
ll C(int n,int m){return fact[n]*ifact[m]%MOD*ifact[n-m]%MOD;}

void initialize()
{
	fact[0]=1;
	for(int i=1;i<N;i++)fact[i]=fact[i-1]*i%MOD;
	ifact[N-1]=inv(fact[N-1]);
	for(int i=N-1;i;i--)ifact[i-1]=ifact[i]*i%MOD;
}

int f[N],g[N];

int F[N][N];

ll calc(int n,int x)
{
	memset(f,0,sizeof(f));
	f[0]=1;
	for(int i=1;i<=n;i++)
	{
		f[i]=0;
		for(int j=1;j<=x;j++)
		{
			if(i<j)break;

			ll cnt=f[i-j]*C(n-i+j,j)%MOD*g[j]%MOD;

			f[i]=((f[i]+cnt)%MOD+MOD)%MOD;
		}
	}

	ll ret=(f[n]-F[n][x-1])%MOD;

	F[n][x]=(F[n][x-1]+ret)%MOD;

	return ret;
}

int n,k;

void getg()
{
	g[1]=1,g[2]=0;

	for(int i=1;i<=n;i++)F[i][0]=F[i][1]=F[i][2]=fact[i];

	for(int i=3;i<=n;i++)
	{
		ll ans=qpow(2,(ll)i*(i-1)/2);
		ans=(ans-fact[i])%MOD;
		int tmp=3;

		for(;tmp<i;tmp++)
			ans=(ans-calc(i,tmp))%MOD;

		g[i]=(ans%MOD+MOD)%MOD;
		F[i][i]=(g[i]+F[i][i-1])%MOD;
	}
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	initialize();
	scanf("%d%d",&n,&k);

	getg();

	ll ans=((F[n][n]-F[n][k-1])%MOD+MOD)%MOD;

	printf("%lld\n",ans);

	return 0;
}
