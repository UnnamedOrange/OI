#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
# include<algorithm>
using namespace std;
int f[110][10010],a[10010]; 
long long find(long long x,long long y){
	long long ans=1,i;
	for(i=0;i<y;i++){
		if(x-i<=0)return 0;
	    ans=(ans*(x-i))%1000000007;
	}
	return ans;
}
long long max(long long x,long long y){
	return x>y?x:y;
}
long long min(long long x,long long y){
	return x<y?x:y;
}
int main(){
	long long i,j,k,m,n,s,t,ans=0;
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
    for(i=1;i<=t;i++)
         f[1][i]=1;
    for(i=1;i<=t;i++)
         a[i]=(a[i-1]+f[1][i])%1000000007;
	for(i=1;i<=n;i++){
		for(j=i;j<=min(n*i,s);j++){
			 long long g=j-t;
			 g=max(g,0); 
		     f[i][j]=(a[j-1]-a[g]+1000000007)%1000000007;
		     if(a[j-1]!=0)f[i][j]=(f[i][j]+1)%1000000007;
		 }
		 a[0]=0;
		 for(j=1;j<=min(n*i,s);j++)
		     a[j]=(a[j-1]+f[i][j])%1000000007;
		 }
	 for(i=1;i<=min(n*t,s);i++){
	 	ans=(ans+(find(s-i,m-n)*f[n][i])%1000000007)%1000000007;
	 }
     printf("%lld\n",ans);	 
	 
	    
	return 0;
}
/*
1 1 1 1 
*/
