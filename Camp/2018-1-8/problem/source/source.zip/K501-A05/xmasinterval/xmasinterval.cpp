#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int Mod = int(1e9 + 7);
const int MAXN = int(5e5), MAXV = 3 * MAXN;

int n, m;

int p[MAXN + 5];
pii seg[MAXN + 5];

inline void input()
{
	n = read<int>(), m = read<int>();
	for(int i = 0; i < n; ++i) seg[i].fst = read<int>(), seg[i].snd = read<int>();
	for(int i = 0; i < m; ++i) p[i] = read<int>();
}

int len;

inline void Discret()
{
	static vector<int> tmp;
	tmp.clear();

	for(int i = 0; i < n; ++i)
	{
		tmp.push_back(seg[i].fst);
		tmp.push_back(seg[i].snd);
	}
	for(int i = 0; i < m; ++i) tmp.push_back(p[i]);
	sort(ALL(tmp)), tmp.erase(unique(ALL(tmp)), tmp.end());

	for(int i = 0; i < n; ++i)
	{
		seg[i].fst = lower_bound(ALL(tmp), seg[i].fst) - tmp.begin() + 1;
		seg[i].snd = lower_bound(ALL(tmp), seg[i].snd) - tmp.begin() + 1;
	}
	for(int i = 0; i < m; ++i) p[i] = lower_bound(ALL(tmp), p[i]) - tmp.begin() + 1;
	len = SZ(tmp);
}

int f[MAXV + 5];

namespace SEGT
{
	int sum[(MAXV << 2) + 5];

	inline void push_up(const int &u)
	{
		sum[u] = (sum[u << 1] + sum[u << 1 | 1]) % Mod;
	}

	inline void add(int u, int l, int r, int pos, int val)
	{
		if(l == r)
		{
			(sum[u] += val) %= Mod;
			return;
		}

		int mid = (l + r) >> 1;
		if(pos <= mid) add(u << 1, l, mid, pos, val);
		else add(u << 1 | 1, mid + 1, r, pos, val);
		push_up(u);
	}

	inline int query(int u, int l, int r, int ql, int qr)
	{
		if(ql > qr) return 0;
		if(ql <= l && r <= qr) return sum[u];

		int mid = (l + r) >> 1, res = 0;
		if(ql <= mid) (res += query(u << 1, l, mid, ql, qr)) %= Mod;
		if(mid < qr) (res += query(u << 1 | 1, mid + 1, r, ql, qr)) %= Mod;
		return res;
	}
}

inline int cmp(const pii &x, const pii &y) { return x.snd == y.snd ? x.fst > y.fst : x.snd < y.snd; }

vector<int> cnt[MAXV + 5];

inline void solve()
{
	Discret();

	set< int, greater<int> > pos;
	pos.insert(-1);
	for(int i = 0; i < m; ++i) pos.insert(p[i]);

	vector<pii> Right;
	for(int i = 0; i < n; ++i)
	{
		auto it = pos.lower_bound(seg[i].fst);
		if(it != pos.end() && *it <= seg[i].snd) Right.push_back(mp(seg[i].snd, seg[i].fst));
	}
	sort(ALL(Right), cmp);

	f[0] = 1, SEGT::add(1, 0, len, 0, 1);
	for(auto i : Right)
	{
		int delta = SEGT::query(1, 0, len, min(*pos.upper_bound(i.snd) + 1, i.snd - 1), i.fst);
		(f[i.fst] += delta) %= Mod, SEGT::add(1, 0, len, i.fst, delta);
	}

	int ans = 0;
	for(int i = *pos.lower_bound(len); i <= len; ++i) (ans += f[i]) %= Mod;
	printf("%d\n", ans);
}

int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);

	input();
	solve();

	return 0;
}

