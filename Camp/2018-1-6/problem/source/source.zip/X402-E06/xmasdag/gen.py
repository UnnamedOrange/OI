import sys
from random import *

sys.stdout = open("xmasdag.in", "w")

n = 1000
m = 2000
k = 500

print (n, m, k)

rev = []
for i in range(2, n+1): 
    rev.append(i)
shuffle (rev)

for i in range(2, n+1):
    m = m - 1
    print (1, rev[i-2]) 

for i in range(m):
    l = randint(1, n-1)
    r = randint(l+1, n)

    if(l == 1):
        print (1, rev[r-2])
    else:
        print (rev[l-2], rev[r-2])
