#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

const int N = 30;

int Begin[N], Next[N], to[N], fa[N], e;

void add(int u, int v){
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int P[N], pos[N], r[N], w[N], n;
bool vis[N];

void DFS(int o){
	for(int i = Begin[o]; i; i = Next[i])
		if(to[i] ^ fa[o]) fa[to[i]] = o, DFS(to[i]);
}

int main(){

	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);

	scanf("%d", &n);
	For(i, 2, n){
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}
	For(i, 1, n) scanf("%d%d", &w[i], &r[i]);

	int x = 1;
	For(i, 1, n) x *= i, P[i] = i;

	int mx = 0;
	while(x--){

		if(r[P[1]]){
			if(!vis[P[1]]) fa[P[1]] = 0, DFS(P[1]), vis[P[1]] = true;
			int ans = 0;
			For(i, 1, n) pos[P[i]] = i;
			For(i, 1, n){
				if(pos[fa[P[i]]] > i) { ans = -1; break; }
				ans += i * w[P[i]];
			}
			mx = max(mx, ans);
		}

		next_permutation(P + 1, P + n + 1);
	}
	printf("%d\n", mx);

	return 0;
}
