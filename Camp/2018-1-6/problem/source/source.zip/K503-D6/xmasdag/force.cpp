#include <map>
#include <set>
#include <cmath>
#include <queue>
#include <cctype>
#include <cstdio>
#include <vector>
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <functional>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)
#define repe(i,x) for (edge *i=fst[x]; i; i=i->nxt)

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;
}

using namespace std;
typedef long long ll;
const int N=1e5+10,M=2e5+10,K=510,p=998244353;
struct edge
{
	int v;
	edge *nxt;
} pool[M],*tp=pool,*fst[N];
int n,m,pw,c[K][K],sum[N][K];
bool vis[N];

void dfs(int x)
{
	if (vis[x])
		return;
	vis[x]=1;
	repe(i,x)
	{
		dfs(i->v);
		rep(j,0,pw)
			rep(k,0,j)
				sum[x][j]=(sum[x][j]+1ll*sum[i->v][k]*c[j][k])%p;
	}
}

int main()
{
    freopen("xmasdag.in","r",stdin);
    freopen("force.out","w",stdout);
    n=get(),m=get(),pw=get();
    rep(i,0,pw)
    {
    	c[i][0]=c[i][i]=1;
    	rep(j,1,i-1)
    		c[i][j]=(c[i-1][j-1]+c[i-1][j])%p;
    }
    rep(i,1,m)
    {
    	int u=get(),v=get();
    	*tp=(edge){u,fst[v]},fst[v]=tp++;
    }
    vis[1]=1,sum[1][0]=1;
    rep(i,1,n)
    	dfs(i),printf("%d\n",sum[i][pw]);
    return 0;
}
