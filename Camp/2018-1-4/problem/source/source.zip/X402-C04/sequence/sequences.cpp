#include<iostream>
#include<queue>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

const int N=29;
int n,ans,a[N];

inline void dfs(int dep)
{
	if(dep>=ans)return;
	for(int i=1;i<=n;i++)
		if(a[i]!=i)
			goto nxt;
	ans=dep;return;
	nxt:;

	for(int i=2;i<=n;i++)
	{
		reverse(a+1,a+i+1);
		dfs(dep+1);
		reverse(a+1,a+i+1);
	}
}

int mian()
{
	n=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	
	ans=2*n;
	dfs(0);
	printf("%d\n",ans);
	return 0;
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequences.out","w",stdout);

	int T=read();
	while(T--)
		mian();

	return 0;
}
