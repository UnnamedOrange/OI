/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 1000 + 20;

int n, p, q, t, val, final;
int a[MAXN], b[MAXN], c[MAXN], d[MAXN], e[MAXN], f[MAXN];
int x[MAXN], y[MAXN], z[MAXN], w[MAXN];

struct limit {
	int x, y, r;
} l[MAXN];

inline void dfs(int cur, int sum) {
	if (cur == n + 1) {
		for (int i = 1; i <= q; ++i) {
			switch (l[i].r) {
				case 0: if (w[l[i].x] > w[l[i].y]) return ;
						break ;
				case 1: if (w[l[i].x] != w[l[i].y]) return ;
						break ;
				case 2: if (w[l[i].x] >= w[l[i].y]) return ;
						break ;
			}
		}
		int ans = sum;
		for (int i = 1; i <= p; ++i)
			ans += a[i] * abs(w[x[i]] - w[y[i]]) + b[i] * abs(w[y[i]] - w[z[i]])
				 + c[i] * abs(w[z[i]] - w[x[i]]) + d[i] * (w[x[i]] - w[y[i]]) 
				 + e[i] * (w[y[i]] - w[z[i]]) + f[i] * (w[z[i]] - w[x[i]]);
		final = std::min(final, ans);
		return ; 
	}
	w[cur] = -1, dfs(cur + 1, sum - 1), w[cur] = 1, dfs(cur + 1, sum + 1); 
}

inline void solve() {
	R(n), R(val), R(p), R(q);
	for (int i = 1; i <= p; ++i) {
		R(x[i]), R(y[i]), R(z[i]);
		R(a[i]), R(b[i]), R(c[i]), R(d[i]), R(e[i]), R(f[i]);
	}
	for (int i = 1; i <= q; ++i) R(l[i].x), R(l[i].y), R(l[i].r);
	final = (~0u >> 1), dfs(1, 0), std::cout << (long long)final * val << '\n';
}

int main() {
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	R(t);
	while (t--) solve();
	return 0;
}
