#include <cstdio>
#include <algorithm>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

const int N = 1010, M = 1000010, inf = 1e9;
struct edge{int to, next, v;} e[M];
int n, p, q, xi, yi, zi, ai, bi, ci, di, ei, fi, cnt, S, T, ans, Td;
int head[N], mut[N], mu[N][N], d[N], h[N], f[N];
long long w;

int read()
{
	int x = 0, f = 1; char c = getchar();
	while (c < '0' || c > '9') {if (c == '-') f = -1; c = getchar();}
	while (c >= '0' && c <= '9') {x = x * 10 + c - '0'; c = getchar();}
	return x * f;
}

void ins(int x, int y, int z1, int z2)
{
	e[++cnt].to = y; e[cnt].next = head[x]; e[cnt].v = z1; head[x] = cnt;
	e[++cnt].to = x; e[cnt].next = head[y]; e[cnt].v = z2; head[y] = cnt;
}

void ready()
{
	S = 0, T = 2 * n + 1; ans = 0; cnt = 1;
	FOR(i, 1, n) FOR(j, 1, n) mu[i][j] = 0;
	FOR(i, 1, n) mut[i] = 0;
	FOR(i, S, T) head[i] = 0;
}

bool bfs()
{
	FOR(i, S, T) d[i] = inf;
	int l = 0, r = 1; h[1] = S; d[S] = 0;
	while (l < r)
	{
		int x = h[++l];
		for(int i = head[x]; i; i = e[i].next)
			if (e[i].v && d[e[i].to] > d[x] + 1)
			{
				d[e[i].to] = d[x] + 1;
				h[++r] = e[i].to;
			}
	}
	return d[T] != inf;
}

int dfs(int x, int flow)
{
	if (x == T) return flow; int i = f[x], tt = 0;
	for(; i && tt < flow; i = e[i].next)
		if (e[i].v && d[e[i].to] == d[x] + 1)
		{
			int tmp = dfs(e[i].to, min(flow - tt, e[i].v));
			e[i].v -= tmp; e[i ^ 1].v += tmp; tt += tmp;
			if (e[i].v) f[x] = i;
		}
	if (!tt) f[x] = -1;
	return tt;
}

void work()
{
	// ��ȥ S-i ��ʾ i ȡ -1����֮ i ȡ 1 
	n = read(); w = read(); p = read(); q = read();
	ready();
	FOR(i, 1, p)
	{
		xi = read(); yi = read(); zi = read();
		ai = read(); bi = read(); ci = read(); di = read(); ei = read(); fi = read();
		mu[xi][yi] += ai; mu[yi][zi] += bi; mu[zi][xi] += ci;
		mut[xi] += di - fi; mut[yi] += ei - di; mut[zi] += fi - ei;
	}
	FOR(i, 1, n)
	{
		++mut[i]; ans += abs(mut[i]);
		if (mut[i] > 0) ins(n + i, T, mut[i] * 2, 0); else //ϵ��Ϊ����ȡ1 ans -= 2 * ϵ�� 
		if (mut[i] < 0) ins(S, i, -mut[i] * 2, 0); //ϵ��Ϊ����ȡ-1 ans -= -2 * ϵ�� 
		ins(i, n + i, inf, inf);
	}
	FOR(i, 1, n) FOR(j, 1, i - 1)
	{
		mu[i][j] += mu[j][i];
		if (mu[i][j]) ins(i, n + j, 2 * mu[i][j], 0), ins(j, n + i, 2 * mu[i][j], 0); // ��������ţ�ans -= 2 * ϵ�� 
	}
	FOR(i, 1, q)
	{
		xi = read(); yi = read(); zi = read();
		if (zi == 0) ins(xi, n + yi, inf, 0); else //������ x=1 �� y=-1 
		if (zi == 1) ins(xi, n + yi, inf, 0), ins(yi, n + xi, inf, 0); else //ȡ����ǲ��е� 
			ins(S, yi, inf, 0), ins(n + xi, T, inf, 0); // y ֻ����1��xֻ����-1 
	}
	while (bfs())
	{
		FOR(i, S, T) f[i] = head[i];
		ans -= dfs(S, inf);
	}
	w *= -ans;
	printf("%lld\n", w);
}

int main()
{
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	Td = read();
	while (Td--) work();
	return 0;
}
