#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 1e6+1e3 ;
int e, Begin[maxn], Next[maxn], To[maxn] ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
int n, m, clk, tot, dfn[maxn], sz[maxn], b[maxn] ;
vector <int> c[maxn] ;
vector <int> g[maxn] ;
int stk[maxn], tp, rd[maxn] ;
int dfs ( int x ) {
	stk[++tp] = x ;
	int i, u, lowx = dfn[x] = ++clk ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (b[u]) continue ;
		if (dfn[u]) lowx = min(lowx, dfn[u]) ;
		else lowx = min(lowx, dfs(u)) ;
	}
	if (lowx == dfn[x]) {
		++ tot ;
		do {
			u = stk[tp--] ;
			c[tot].push_back(u) ;
			b[u] = tot ;
			++ sz[tot] ;
		} while (x ^ u) ;
	}
	return lowx ;
}
bool vis[maxn] ;
int f[maxn] ;
int bfs ( int x ) {
	int &rec = f[x] ;
	if (rec) return rec ;
	int i, u, maxx = 0 ;
	rec = sz[x] ;
	for ( i = 0 ; i < (int)g[x].size() ; i ++ ) {
		u = g[x][i] ;
		maxx = max(maxx, bfs(u)) ;
	}
	return rec += maxx ;
}
int main() {
	freopen ( "bomb.in", "r", stdin ) ;
	freopen ( "bomb.out", "w", stdout ) ;

	Read(n) ; Read(m) ;
	int i, j, x, u, v ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(x) ; Read(u) ;
		add(x, u) ;
	}
	for ( i = 1 ; i <= n ; i ++ )
		if (!dfn[i]) dfs(i) ;
	/*for ( i = 1 ; i <= tot ; i ++, puts("") ) {
		printf ( "%d : ", i ) ;
		for ( x = 0 ; x < (int)c[i].size() ; x ++ )
			printf ( "%d ", c[i][x] ) ;
	}*/
	for ( v = 1 ; v <= tot ; v ++ ) {
		for ( j = 0 ; j < (int)c[v].size() ; j ++ ) {
			x = c[v][j] ;
			for ( i = Begin[x] ; i ; i = Next[i] ) {
				u = To[i] ;
				if (!vis[b[u]]) {
					vis[b[u]] = 1 ;
					if (b[u] ^ v)g[v].push_back(b[u]) ;
				}
			}
		}
		vis[v] = 0 ;
		for ( j = 0 ; j < (int)g[v].size() ; j ++ ) {
			vis[g[v][j]] = 0 ;
			++ rd[g[v][j]] ;
		}
	}
	/*for ( v = 1 ; v <= tot ; v ++, puts("") ) {
		printf ( "sz[%d]=%d : ", v, sz[v] ) ;
		for ( j = 0 ; j < (int)g[v].size() ; j ++ )
			printf ( "%d ", g[v][j] ) ;
	}*/
	int ans = 0 ;
	for ( i = 1 ; i <= tot ; i ++ )
		if (!rd[i]) ans = max(bfs(i), ans) ;
	/*for ( i = 1 ; i <= tot ; i ++ )
		printf ( "f[%d] = %d\n", i, f[i] ) ;*/
	printf ( "%d\n", ans ) ;
	return 0 ;
}
