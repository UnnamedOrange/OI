#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=2e3+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
template<typename T>void write(T x,char y)
{
	if(x==0)
	{
		putchar('0');putchar(y);
		return;
	}
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	static char wr[20];
	int top=0;
	for(;x;x/=10)wr[++top]=x%10+'0';
	while(top)putchar(wr[top--]);
	putchar(y);
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("schooldays.in","r",stdin);
		freopen("schooldays.out","w",stdout);
	#endif
}
int n;
int lef[N],rig[N];
void input()
{
	n=read<int>();
	For(i,1,n)
	{
		lef[i]=read<int>();
		rig[i]=read<int>();
	}
}
int dp[N][2];
const int mo=1e9+7;
void add(int &a,int b)
{
	a+=b;
	if(a>=mo)a-=mo;
}
const int inf=0x3f3f3f3f;
void work()
{
	int l,r;
	dp[0][1]=1;
	For(i,0,n-1)
	{
		r=rig[i+1];l=lef[i+1];
		For(j,i+1,n)
		{
			cmin(r,rig[j]);cmax(l,lef[j]);
			if(l>r||j-i>r)break;
			if(j-i<l)continue;
			if(dp[j][0]==dp[i][0]+1)add(dp[j][1],dp[i][1]);
			else  if(dp[j][0]<dp[i][0]+1)
			{
				dp[j][0]=dp[i][0]+1;
				dp[j][1]=dp[i][1];
			}
		}
	}
	if(!dp[n][0])
	{
		puts("-1");
	}
	else 
	{
		write(dp[n][0],' ');
		write(dp[n][1],'\n');
	}
}
int main()
{
	file();
	input();
	work();
	return 0;
}
