#include<iostream>
#include<cstdio>
#include<cstring>
#include<stack>

template<typename T>inline void read(T &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
}

namespace Gua_Fen_Ti
{
	inline void check_min(int a,int &b){if(a<b)b=a;}
	inline void check_max(int a,int &b){if(a>b)b=a;}
	const int N=1000100,M=N;

	struct DAG
	{
		int begin[N],next[M],to[M];
		int w[N];
		int n,e;

		void add(int x,int y)
		{
			to[++e]=y;
			next[e]=begin[x];
			begin[x]=e;
		}

		int f[N];
		int dfs(int p)
		{
			if(f[p]>=0)return f[p];
			f[p]=w[p];
			for(int i=begin[p];i;i=next[i])
				check_max(dfs(to[i])+w[p],f[p]);
			return f[p];
		}
		int calc()
		{
			memset(f,-1,sizeof(f));
			int ret=0;
			for(int i=1;i<=n;i++)
			{
				if(f[i]<0)f[i]=dfs(i);
				check_max(f[i],ret);
			}
			return ret;
		}
	}d;

	int begin[N],next[M],to[M];
	int n,m,e;
	void add(int x,int y)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
	}
	
	std::stack<int> S;
	int dfn[N],inq[N],blg[N];
	int clk,tot;
	int tarjan(int p)
	{
		S.push(p);inq[p]=1;
		int lowp=dfn[p]=++clk;
		
		for(int i=begin[p],q;i;i=next[i])
		{
			if(dfn[q=to[i]])
			{
				if(inq[q])check_min(dfn[q],lowp);
				continue;
			}
			check_min(tarjan(q),lowp);
		}

		if(lowp==dfn[p])
		{
			tot++;
			for(int x;;)
			{
				x=S.top();S.pop();
				blg[x]=tot;
				d.w[tot]++;
				inq[x]=0;
				if(x==p)break;
			}
		}

		return lowp;
	}

	void initialize()
	{
		read(n),read(m);
		for(int u,v;m--;)
		{
			read(u),read(v);
			add(u,v);
		}
		while(!S.empty())S.pop();
		tarjan(1);
		d.n=tot;

		for(int p=1;p<=n;p++)
			for(int i=begin[p],q;i;i=next[i])
			{
				if(blg[p]!=blg[q=to[i]])
					d.add(blg[p],blg[q]);
			}
	}

	void solve()
	{
		initialize();
		printf("%d\n",d.calc());
	}
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	Gua_Fen_Ti::solve();
	return 0;
}
