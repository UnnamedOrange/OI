#include <algorithm>
#include <iostream>
#include <iomanip>
#include <utility>
#include <cstdio>
#define mp make_pair
using namespace std; 
typedef long long ll; 
typedef double decimal; 
const int off = 40;
int pre[1000005], nxt[1000005], arr[1000005], ldis[105], rdis[105]; 
pair<int, int> app[1000005]; 
inline int getint()
{
	int res = 0, ch = getchar(); 
	for (; ch < 48; ch = getchar());
	for (; ch >= 48; ch = getchar())
		res = res * 10 + ch - 48;
	return res; 
}
int main()
{
	freopen("drink.in", "r", stdin); 
	freopen("drink.out", "wt", stdout); 
	int n = getint(); 
	for (int i = 0; i < n; i++)
	{
		arr[i] = getint(); 
		pre[i] = i - 1; 
		nxt[i] = i + 1; 
		app[i] = mp(arr[i], i); 
	}
	sort(app, app + n); 
	decimal ans = 0; 
	for (int i = 0; i < n; i++)
	{
		int x = app[i].second, l = 0, r = 0; 
		while (~x && l < off)
		{
			ldis[l++] = x - pre[x]; 
			x = pre[x]; 
		}
		x = app[i].second; 
		while (x < n && r < off)
		{
			rdis[r++] = nxt[x] - x; 
			x = nxt[x]; 
		}
		decimal suml = 0, sumr = 0; 
		for (int j = 0; j < l; j++)
			suml += (decimal)ldis[j] / (1ll << j); 
		for (int j = 0; j < r; j++)
			sumr += (decimal)rdis[j] / (1ll << j); 
		ans += suml * sumr * app[i].first / 2; 
		x = app[i].second; 
		if (~pre[x])
			nxt[pre[x]] = nxt[x]; 
		if (nxt[x] < n)
			pre[nxt[x]] = pre[x]; 
	}
	cout << fixed << setprecision(15) << ans / n / n << endl; 
	return 0; 
}

