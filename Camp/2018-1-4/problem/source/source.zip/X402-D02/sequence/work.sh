a=1
while $ture ; do 
	echo Case : $a
	let a++
	./gen
	./bf
	./sequence
	if diff ./sequence.out ./sequence.ans ; then echo AC ;
	else echo wa ; exit 1 ; fi
done
