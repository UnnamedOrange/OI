#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

typedef double db;
const int N=1e6+9;
const int W=1e5+9;
const int WW=100000;
int n,w[N];
int mv[N<<2];
db t[W<<2],tag[W<<2],ans;

#define mid ((l+r)>>1)

inline int maxx(int a,int b){if(a>b)return a;return b;}

inline void build(int x,int l,int r)
{
	t[x]=0;tag[x]=1;
	if(l==r)return;
	build(x<<1,l,mid);
	build(x<<1|1,mid+1,r);
}

inline void upd(int x)
{
	t[x]=t[x<<1]+t[x<<1|1];
}

inline void push(int x)
{
	if(tag[x]!=1)
	{
		tag[x<<1]*=tag[x];
		tag[x<<1|1]*=tag[x];
		t[x<<1]*=tag[x];
		t[x<<1|1]*=tag[x];
		tag[x]=1;
	}
}

inline void mul(int x,int l,int r,int dl,int dr)
{
	if(dl==l && r==dr){tag[x]*=0.5,t[x]*=0.5;return;}
	push(x);
	if(dr<=mid)
		mul(x<<1,l,mid,dl,dr);
	else if(mid<dl)
		mul(x<<1|1,mid+1,r,dl,dr);
	else
	{
		mul(x<<1,l,mid,dl,mid);
		mul(x<<1|1,mid+1,r,mid+1,dr);
	}
	upd(x);
}

inline void add(int x,int l,int r,int p,db v)
{
	if(l==r){t[x]+=v;return;}
	push(x);
	if(p<=mid)add(x<<1,l,mid,p,v);
	else add(x<<1|1,mid+1,r,p,v);
	upd(x);
}

inline void builds(int x,int l,int r)
{
	if(l==r){mv[x]=w[l];return;}
	builds(x<<1,l,mid);
	builds(x<<1|1,mid+1,r);
	mv[x]=maxx(mv[x<<1],mv[x<<1|1]);
}

inline int pre(int x,int l,int r,int dl,int dr,int v)
{
	if(mv[x]<v || dr==0)return 0;
	if(l==r)return l;
	if(dr<=mid)
		return pre(x<<1,l,mid,dl,dr,v);
	int ret=0;
	if(v<=mv[x<<1|1])
		ret=pre(x<<1|1,mid+1,r,mid+1,dr,v);
	if(!ret && v<=mv[x<<1])
		ret=pre(x<<1,l,mid,dl,mid,v);
	return ret;
}

#undef mid

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);

	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&w[i]);

	build(1,1,WW);
	builds(1,1,n);
	for(int i=1;i<=n;i++)
	{
		db cans=0,cmul=0.5;
		
		for(int j=i,k;j>=1;j=k)
		{
			if(j>1 && w[i]<=w[j-1])
				k=j-1;
			else if(j>2 && w[i]<=w[j-2])
				k=j-2;
			else if(j>3 && w[i]<=w[j-3])
				k=j-3;
			else
				k=pre(1,1,n,1,j-1,w[i]);
			//printf("%d:(%d,%d]\n",i,k,j);
			cans+=(db)w[i]*cmul*(j-k);
			cmul/=2.0;
		}

		/*
		for(int j=i;j>=1;j--)
		{
			if(w[i]<=w[j])
				cmul/=2.0;
			cans+=(db)w[i]*cmul;
		}*/

		if(1<w[i])
			mul(1,1,WW,1,w[i]-1);
		add(1,1,WW,w[i],cans);
		ans+=t[1];
	}

	printf("%.4f\n",ans/((db)n*n));
	return 0;
}
