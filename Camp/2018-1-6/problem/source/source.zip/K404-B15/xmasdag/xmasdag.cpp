#include<iostream>
#include<cstdio>
#include<cstring>
#define LL long long
#define MOD (998244353)
using namespace std;
struct node
{
	LL to,next;
}edge[5010];
LL ans[2010],head[2010],num_edge;
LL n,m,k,sum;

void add(int u,int v)
{
	edge[++num_edge].to=v;
	edge[num_edge].next=head[u];
	head[u]=num_edge;
}

LL Qpow(LL a,LL b,LL p)
{
    LL ans=1,base=a;
    while (b!=0)
    {
        if (b&1!=0)
            ans=ans*base%p;
        base=base*base%p;
        b=b>>1;
    }
    return ans;
}

void Dfs(LL step,LL x)
{
	++sum;
	ans[x]=(ans[x]+Qpow(step,k,MOD))%MOD;
	for (int i=head[x];i!=0;i=edge[i].next)
		Dfs(step+1,edge[i].to);
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	LL u,v;
	scanf("%lld%lld%lld",&n,&m,&k);
	for (int i=1;i<=m;++i)
	{
		scanf("%lld%lld",&u,&v);
		add(u,v);
	}
	Dfs(0,1);
	for (int i=1;i<=n;++i)
		printf("%lld\n",ans[i]);
}
/*

*/
