#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>
#include <cmath>
#include <queue>
#include <map> 
using namespace std;

char str[200]; 
long long ans;
int g[200][200];
long long f[200][200];
struct status {
	int step;
	int len;
	char s[200];
} t, front;
queue<status> q;
map<long long, int> m;
long long n, T; 
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

void open()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}

void BFS()
{
	while(!q.empty()) {
		q.pop();
	}
	t.step = 0;
	t.len = n;
	for(int i = 0; i < n; i++) {
		t.s[i] = str[i];
	}
	q.push(t);
	while(!q.empty()) {
		t = q.front();
		q.pop();
	//	if(!m.count(num)) {
	//		m[num] = 1;
			int flag = 0;
			for(int i = 0; i < t.len; i++) {
			//E	cout<<t.s[i]; 
				if(t.s[i] != t.s[t.len - i - 1]) {
					flag = 1;
					break;
				}
			}
			//cout<<endl;
			if(flag) {
				ans = t.step + 1;
				return;
			}
			for(int i = 0; i < t.len; i++) {
				for(int j = i + 1; j < t.len; j++) {
					int k;
					char temp[200]; 
					for(k = 0; k < i; k++) {
						temp[k] = t.s[k];
					}
					for(int l = j + 1; l < t.len; l++) {
						temp[k] = t.s[l];
						k++;
					}
					int flag = 0;
					for(int l = 0; l <= j - i; l++) {
						if(t.s[i + l] != t.s[j - l]) {
							flag = 1;
							break;
						}
					}
					if(flag) {
						front.step = t.step + 1;
						front.len = k;
						for(int l = 0; l < front.len; l++) {
							front.s[l] = temp[l];
						//	cout<<temp[l];
						}
					//	cout<<endl;
						long long num = 0;
						for(int l = 0; l < front.len; l++) {
							num = num * 27 + (front.s[l] - '0');
						}
						if(!m.count(num)) {
							m[num] = 1;
							q.push(front);
						}
					}
				}
			}
		}
	//}
}
int main()
{
	open(); 
	T = read();
	while(T--) {
		ans = -1;
		m.clear();
		n = read();
		//scanf("%s", str);
		if(n <= 10) { 
			scanf("%s", str); 
			BFS();
			printf("%lld\n", ans);
		} else {
			scanf("%s", str + 1); 
			memset(g, -1, sizeof g);
			for(int i = 1; i < n; i++) {
				for(int j = i + 1; j <= n; j++) {
					int flag = 0;
					for(int l = 0; l <= j - i; l++) {
						if(str[i + l] != str[j - l]) {
							flag = 1;
							break;
						}
					}
					if(flag) {
						g[i][j] = 1;
					}
				}
			}
			for(int k = 1; k <= n; k++) {
				for(int i = 1; i + k - 1 <= n; i++) {
					for(int l = i + 1; l < i + k - 1; l++) {
						if((g[i][l] != -1) && (g[l + 1][i + k - 1] != -1)) {
							if(g[i][i + k - 1] == -1) {
								g[i][i + k - 1] = g[i][l] + g[l + 1][i + k - 1];
							}
							g[i][i + k - 1] = min(g[i][i + k - 1], g[i][l] + g[l + 1][i + k - 1]);
						}
					}
				}
			} 
			/*for(int i = 1; i <= n; i++) {
				for(int j = 1; j <= n; j++) {
					cout<<g[i][j]<<" ";
				}
				cout<<endl;
			}*/
			printf("%d\n", g[1][n]);
		}
	}
	close();
	return 0;
}
