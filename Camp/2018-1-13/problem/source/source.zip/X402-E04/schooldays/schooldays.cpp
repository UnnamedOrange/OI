#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=101010,INF=0x3f3f3f3f,Mod=1000000007;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
}
int n,c[N],d[N],dp[N],g[N];
void init(){
	read(n);
	For(i,1,n)read(c[i]),read(d[i]);
}
void solve(){
	dp[0]=0,g[0]=1;
	For(i,1,n){
		int maxc=0,mind=INF;
		dp[i]=-INF,g[i]=0;
		Forr(j,i,1){
			maxc=max(c[j],maxc),mind=min(mind,d[j]);
			if(maxc<=i-j+1&&i-j+1<=mind){
				if(dp[i]<dp[j-1]+1){
					dp[i]=dp[j-1]+1;
					g[i]=g[j-1];
				}else if(dp[i]==dp[j-1]+1){
					g[i]=(g[i]+g[j-1])%Mod;
				}
			}
			if(i-j+1>mind)break;
		}	
	}
	if(dp[n]!=-INF){
		printf("%d %d\n",dp[n],g[n]);
	}else puts("-1");
}
int main(){
	file();
	init();
	solve();
	return 0;
}
