#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>
#include<set>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<< " = "<<(x)<<" "
#define debug(x) cerr<<#x<< " = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e5+5,S=410,SZ=S*N;

int n,Q,T,c[N];
int head[N],tot_edge;
pii G[N<<1];
struct ss{
	int a,b,c,d;
}arr[N];
int dfn[N],post[N],dfn_clock,Mp[N];
struct P_0{
	void dfs(int x,int par){
		Mp[dfn[x]=++dfn_clock]=x;
		for(int i=head[x];i;i=G[i].se){
			int y=G[i].fi;
			if(y==par)continue;
			dfs(y,x);
		}
		post[x]=dfn_clock;
	}
	void work(){
		dfs(1,0);
		int ans=0;
		rep(i,1,Q+1){
			if(T)arr[i].b^=ans,arr[i].c^=ans,arr[i].d^=ans;
			if(arr[i].a==1){
				ans=0;
				static int l,r,mark[N],tar,C;
				++tar;l=arr[i].c,r=arr[i].d;
				rep(j,dfn[arr[i].b],post[arr[i].b]+1){
					C=c[Mp[j]];
					if(mark[C]!=tar){
						mark[C]=tar;
						if(l<=C&&C<=r)++ans;
					}
				}
				ptn(ans);
			}else {
				c[arr[i].b]=arr[i].c;
			}
		}
	}
}P0;
int allc,lson[SZ],rson[SZ],cnt[SZ],rt[N<<2];
struct P_1{
	void ins(int l,int r,int &p,int c){
		p=++allc;cnt[p]=1;
		if(l==r)return ;
		int mid=(l+r)>>1;
		if(c<=mid)ins(l,mid,lson[p],c);
		else ins(mid+1,r,rson[p],c);
	}
	int Merge(int l,int r,int x,int y){
		if(!x||!y)return x|y;
		if(l==r)return x;
		int p=++allc,mid=(l+r)>>1;
		lson[p]=Merge(l,mid,lson[x],lson[y]);
		rson[p]=Merge(mid+1,r,rson[x],rson[y]);
		cnt[p]=cnt[lson[p]]+cnt[rson[p]];
		return p;
	}
	void dfs(int x,int par){
		ins(1,n,rt[x],c[x]);
		for(int i=head[x];i;i=G[i].se){
			int y=G[i].fi;
			if(y==par)continue;
			dfs(y,x);
			rt[x]=Merge(1,n,rt[x],rt[y]);
		}
	}
	int query(int l,int r,int L,int R,int p){
		if((l==L&&r==R)||!p)return cnt[p];
		int mid=(L+R)>>1;
		if(r<=mid)return query(l,r,L,mid,lson[p]);
		else if(mid<l)return query(l,r,mid+1,R,rson[p]);
		else return query(l,mid,L,mid,lson[p])+query(mid+1,r,mid+1,R,rson[p]);
	}
	void work(){
		dfs(1,0);
		int ans=0;
		rep(i,1,Q+1){
			if(T)arr[i].b^=ans,arr[i].c^=ans,arr[i].d^=ans;
			ans=query(arr[i].c,arr[i].d,1,n,rt[arr[i].b]);
			ptn(ans);
		}
	}
}P1;
int dep[N];
bool cmp(const int &a,const int &b){
	return dep[a]<dep[b];
}
struct P_2{
	int par[N],ST[20][N],lg[N];
	set<int>st[N];
	void dfs(int x){
		Mp[dfn[x]=++dfn_clock]=x;
		ST[0][dfn_clock]=x;
//		bug(x),debug(dfn_clock);
		for(int i=head[x];i;i=G[i].se){
			int y=G[i].fi;
			if(y==par[x])continue;
			dep[y]=dep[x]+1;
			par[y]=x;
			dfs(y);
		}
		post[x]=dfn_clock;
	}
	int LCA(int x,int y){
		if(dfn[x]>dfn[y])swap(x,y);
		if(dfn[y]<=post[x])return x;
		int p=lg[dfn[y]-dfn[x]+1];
		return par[min(ST[p][dfn[x]],ST[p][dfn[y]-(1<<p)+1],cmp)];
	}
	void upd(int l,int r,int &p,int pos,int v){
		if(!p)p=++allc;
		cnt[p]+=v;
		if(l==r)return ;
		int mid=(l+r)>>1;
		if(pos<=mid)upd(l,mid,lson[p],pos,v);
		else upd(mid+1,r,rson[p],pos,v);
	}
	int qry(int l,int r,int L,int R,int p){
		if(!p||(l==L&&r==R))return cnt[p];
		int mid=(L+R)>>1;
		if(r<=mid)return qry(l,r,L,mid,lson[p]);
		else if(mid<l)return qry(l,r,mid+1,R,rson[p]);
		return qry(l,mid,L,mid,lson[p])+qry(mid+1,r,mid+1,R,rson[p]);
	}
	void update(int x,int pos,int v){
		for(;x<=n;x+=x&-x)
			upd(1,n,rt[x],dfn[pos],v);
	}
	int query(int x,int pos){
		int res=0;
		for(;x;x-=x&-x)
			res+=qry(dfn[pos],post[pos],1,n,rt[x]);
		return res;
	}
	void work(){
		dfs(1);
		rep(i,2,n+1)lg[i]=lg[i>>1]+1;
		rep(j,0,19)
			rep(i,1,n+2-(1<<(j+1)))
				ST[j+1][i]=min(ST[j][i],ST[j][i+(1<<j)],cmp);
		rep(i,1,n+1)st[c[i]].insert(dfn[i]);
		set<int>::iterator it,pre,nxt;
		rep(i,1,n+1){
			bool c=false;
			for(it=st[i].begin();it!=st[i].end();pre=it,++it,c=true){
				update(i,Mp[*it],1);
				if(c)
					update(i,LCA(Mp[*pre],Mp[*it]),-1);
			}
		}
		int ans=0;
		rep(i,1,Q+1){
			if(T)arr[i].b^=ans,arr[i].c^=ans,arr[i].d^=ans;
			if(arr[i].a==1){
				ans=query(arr[i].d,arr[i].b)-query(arr[i].c-1,arr[i].b);
				ptn(ans);
			}else {
				static int x,nc;
				x=arr[i].b;nc=arr[i].c;
				if(c[x]!=nc){
					it=st[c[x]].find(dfn[x]);
					update(c[x],Mp[*it],-1);
					pre=nxt=it;++nxt;
					if(pre!=st[c[x]].begin()&&nxt!=st[c[x]].end()){
						--pre;
						update(c[x],LCA(Mp[*pre],Mp[*it]),1);
						update(c[x],LCA(Mp[*it],Mp[*nxt]),1);
						update(c[x],LCA(Mp[*pre],Mp[*nxt]),-1);
					}else {
						if(pre!=st[c[x]].begin()){
							--pre;
							update(c[x],LCA(Mp[*pre],Mp[*it]),1);
						}else if(nxt!=st[c[x]].end()){
							update(c[x],LCA(Mp[*it],Mp[*nxt]),1);
						}
					}
					st[c[x]].erase(it);
					c[x]=nc;
					it=st[c[x]].insert(dfn[x]).fi;
					update(c[x],Mp[*it],1);
					pre=nxt=it;++nxt;
					if(pre!=st[c[x]].begin()&&nxt!=st[c[x]].end()){
						--pre;
						update(c[x],LCA(Mp[*pre],Mp[*it]),-1);
						update(c[x],LCA(Mp[*it],Mp[*nxt]),-1);
						update(c[x],LCA(Mp[*pre],Mp[*nxt]),1);
					}else {
						if(pre!=st[c[x]].begin()){
							--pre;
							update(c[x],LCA(Mp[*pre],Mp[*it]),-1);
						}else if(nxt!=st[c[x]].end()){
							update(c[x],LCA(Mp[*it],Mp[*nxt]),-1);
						}
					}
				}
			}
		}
	}
}P2;
int main(){
//	debug((sizeof(P0)+sizeof(P1)+sizeof(P2)+(sizeof(lson)*3))>>20);
//	freopen("data.in","r",stdin);
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	rd(n),rd(Q),rd(T);
	rep(i,1,n+1)rd(c[i]);
	for(int x,y,i=1;i<n;++i){
		rd(x),rd(y);
		G[++tot_edge]=pii(y,head[x]);head[x]=tot_edge;
		G[++tot_edge]=pii(x,head[y]);head[y]=tot_edge;
	}
	bool flag=true;
	rep(i,1,Q+1){
		rd(arr[i].a),rd(arr[i].b),rd(arr[i].c);
		if(arr[i].a==1)rd(arr[i].d);
		else flag=false;
	}
	if(0);
	else if(n<=5000&&Q<=5000)P0.work();
	else if(flag)P1.work();
	else P2.work();
	return 0;
}
