#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<< " = "<<(x)<<" "
#define debug(x) cerr<<#x<< " = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=105,mod=998244353;
void add_mod(int &a,int b){if((a+=b)>=mod)a-=mod;}
int Pow(int x,int y){
	int res=1;
	for(;y;y>>=1,x=(ll)x*x%mod)
		if(y&1)res=(ll)res*x%mod;
	return res;
}
int n,m,a[8][N],len[8];
char str[N];
struct P_0{
	int mm,fail[8][N];
	void build_fail(int *fail,int *a,int len){
		int j=0;
		rep(i,2,len+1){
			while(j&&a[j+1]!=a[i])j=fail[j];
			j+=a[j+1]==a[i];
			fail[i]=j;
		}
	}
	bool judge(int s){
		static bool mark[40];
		static int i,j,k;
		for(i=0;i<mm;++i)mark[i]=s>>i&1;
		for(i=0;i<n;++i){
			for(k=j=0;k<mm;++k){
				while(j&&a[i][j+1]!=mark[k])j=fail[i][j];
				j+=a[i][j+1]==mark[k];
				if(j==len[i])break;
			}
			if(j!=len[i])return false;
		}
		return true;
	}
	void work(){
		int ans=0,full=(1<<m)-1;mm=m<<1;
		rep(i,0,n)build_fail(fail[i],a[i],len[i]);
		static int inv[1<<15];
		rep(i,0,1<<m){
			inv[i]=(inv[i>>1]>>1)|((i&1)<<(m-1));
			ans+=judge(i<<m|(full&(~inv[i])));
		}
		ptn(ans);
	}
}P0;
//struct P_1{
//	int zfail[105],ffail[105],dp[2][105][105];
//	int ztrans[105][2],ftrans[105][2],pow2[505];
//	void work(){
//		int l=len[0];
//		{
//			int j=0;
//			rep(i,2,l+1){
//				while(j&&a[0][i]!=a[0][j+1])j=zfail[j];
//				j+=a[0][i]==a[0][j+1];
//				zfail[i]=j;
//			}
//			rep(i,0,l){
//				rep(c,0,2){
//					int j=i;
//					while(j&&a[0][j+1]!=c)j=zfail[j];
//					j+=a[0][j+1]==c;
//					ztrans[i][c]=j;
//				}
//			}
//		}
//		{
//			int j=ffail[l]=l+1;
//			per(i,1,l){
//				while(j<=l&&a[0][i]!=a[0][j-1])j=ffail[j];
//				j-=a[0][i]==a[0][j-1];
//				ffail[i]=j;
//			}
//			per(i,2,l+2){
//				rep(c,0,2){
//					int j=i;
//					while(j<=l&&a[0][j-1]!=c)j=ffail[j];
//					j-=a[0][j-1]==c;
//					ftrans[i][c]=j;
//				}
//			}
//		}
//		pow2[0]=1;
//		rep(i,1,m+1)add_mod(pow2[i]=pow2[i-1],pow2[i-1]);
//		int ans=0,cur=0;
//		dp[cur][0][l+1]=1;
//		per(t,0,m){
//			int nxt=cur^1;
//			memset(dp[nxt],0,sizeof dp[nxt]);
//			rep(i,0,l)rep(j,2,l+2){
//				int&res=dp[cur][i][j];
//				if(res){
//					add_mod(dp[nxt][ztrans[i][0]][ftrans[j][1]],res);
//					add_mod(dp[nxt][ztrans[i][1]][ftrans[j][0]],res);
//				}
//			}
//			cur=nxt;
//			rep(i,1,l+2)
//				ans=(ans+(ll)dp[cur][l][i]*pow2[t])%mod;
//			rep(i,0,l)
//				ans=(ans+(ll)dp[cur][i][1]*pow2[t])%mod;
//		}
//		rep(i,1,l)
//			add_mod(ans,dp[cur][i][i+1]);
//		ptn(ans);
//	}
//}P1;
struct P_2{
	int que[607],zallc,ztrans[607][2],zfail[607];
	int fallc,ftrans[607][2],ffail[607];
	bool zmark[607];
	bool fmark[607];
	int dp[2][607][607],pre[607],fa[607];
	int work(int s){
		memset(ztrans,0,sizeof ztrans);
		memset(ftrans,0,sizeof ftrans);
		memset(zfail,0,sizeof zfail);
		memset(ffail,0,sizeof ffail);
		zallc=fallc=0;
		memset(zmark,0,sizeof zmark);
		memset(fmark,0,sizeof fmark);
		{
			rep(i,0,n){
				if(!(s>>i&1))continue;
				int cur=0;
				rep(j,1,len[i]+1){
					int c=a[i][j];
					if(!ztrans[cur][c])ztrans[cur][c]=++zallc;
					cur=ztrans[cur][c];
				}
				zmark[cur]=1;
			}
			int l=0,r=0;
			rep(i,0,2)if(ztrans[0][i])que[r++]=ztrans[0][i];
			while(l<r){
				int x=que[l++];
				zmark[x]|=zmark[zfail[x]];
				rep(i,0,2){
					int t=ztrans[x][i];
					if(t)zfail[t]=ztrans[zfail[x]][i],que[r++]=t;
					else ztrans[x][i]=ztrans[zfail[x]][i];
				}
			}
		}
		{
			rep(i,0,n){
				if(!(s>>i&1))continue;
				int cur=0;
				per(j,1,len[i]+1){
					int c=a[i][j];
					if(!ftrans[cur][c])
						ftrans[cur][c]=++fallc,fa[fallc]=cur,pre[fallc]=c;
					cur=ftrans[cur][c];
				}
				fmark[cur]=1;
			}
			int l=0,r=0;
			rep(i,0,2)if(ftrans[0][i])que[r++]=ftrans[0][i];
			while(l<r){
				int x=que[l++];
				fmark[x]|=fmark[ffail[x]];
				rep(i,0,2){
					int t=ftrans[x][i];
					if(t)ffail[t]=ftrans[ffail[x]][i],que[r++]=t;
					else ftrans[x][i]=ftrans[ffail[x]][i];
				}
			}
		}
		int cur=0;
		memset(dp,0,sizeof dp);
		dp[cur][0][0]=1;
		zallc++;fallc++;
		rep(t,0,m){
			int nxt=cur^1;
			rep(i,0,zallc)if(!zmark[i])rep(j,0,fallc)
				if(!fmark[j]){
					int &res=dp[cur][i][j];
					if(res){
						add_mod(dp[nxt][ztrans[i][0]][ftrans[j][1]],res);
						add_mod(dp[nxt][ztrans[i][1]][ftrans[j][0]],res);
						res=0;
					}
				}
			cur=nxt;
		}
		int ans=0;
		rep(i,0,zallc)if(!zmark[i])rep(j,0,fallc)if(!fmark[j]){
			if(!dp[cur][i][j])continue;
			bool flag=true;
			for(int p=i,q=j;q;q=fa[q]){
				p=ztrans[p][pre[q]];
				if(zmark[p]){
					flag=false;
					break;
				}
			}
			if(flag)add_mod(ans,dp[cur][i][j]);
		}
		return ans;
	}
	void solve(){
		int ans=Pow(2,m);
		static int cnt[1<<7];
//		rep(i,0,n)P0.build_fail(P0.fail[i],a[i],len[i]);
		rep(i,1,1<<n){
			cnt[i]=cnt[i>>1]+(i&1);
			if(cnt[i]&1)ans=(ans-work(i))%mod;
			else ans=(ans+work(i))%mod;
		}
		if(ans<0)ans+=mod;
		ptn(ans);
	}
}P2;
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	rd(n),rd(m);
	rep(i,0,n){
		scanf("%s",str+1);
		int l=len[i]=strlen(str+1);
		rep(j,1,l+1)a[i][j]=str[j]&15;
	}
	if(0);
	else if(m<=15)P0.work();
//	else if(n==1)P1.work();
	else P2.solve();
	return 0;
}
