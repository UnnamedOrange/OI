#include <bits/stdc++.h>
#define N 11
using namespace std;
int n,m,a[N][N],b[N][N],ans,c[N];

void search(int dep,int cnt){
	if (cnt>=ans) return;
	if (dep>n){
		ans=cnt;
	/*	printf("%d\n",ans);
		for (int i=1;i<=n;i++)
			printf("%d ",c[i]);
		puts("");*/
		return;
	}
	int ok[N];
	for (int i=1;i<=cnt;i++)
		ok[i]=1;
	for (int i=1;i<dep;i++)
		if (b[i][dep] || b[dep][i])
			ok[c[i]]=0;
	for (int i=1;i<=cnt;i++)
		if (ok[i]){
			c[dep]=i; search(dep+1,cnt);
		}
	c[dep]=++cnt; search(dep+1,cnt);
}

void dfs(int s,int x){
	b[s][x]=1;
	for (int i=1;i<=n;i++)
		if (a[x][i] && !b[s][i])
			dfs(s,i);
}

int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v;
	for (int i=1;i<=m;i++)
		scanf("%d%d",&u,&v),a[u][v]=1;
	for (int i=1;i<=n;i++)
		dfs(i,i);
	ans=n;
	search(1,0);
	printf("%d\n",ans);
	return 0;
}
