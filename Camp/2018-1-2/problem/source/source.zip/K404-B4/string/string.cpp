#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
using namespace std;
template<class T>
inline T read(T& x)
{
	x=0;char ch=getchar();int w=1;
	while(ch>'9'||ch<'0'){if(ch=='-')w=-1;ch=getchar();};
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();};
	x*=w;
}
int t,n;
char str[100010];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d\n",&t);
	while(t--)
	{
		memset(str,0,sizeof(str));
		scanf("%d\n%s",&n,str+1);
		int flag=1;
		for(int i=1,j=n;i<j;i++,j--)
		{
			flag&=(str[i]==str[j]);
		}
		if(!flag)
		{
			cout<<1<<endl;
			continue;
		}
		flag=1;
		for(int i=1;i<=n;i++)
		{
			flag&=(i%2?(str[i]==str[1]):(str[i]==str[2]));
		}
		if(flag)
		{
			cout<<-1<<endl;
		}
		else
		{
			cout<<2<<endl;
		}
	}
	return 0;
}
/*
abababcbababa
*/
