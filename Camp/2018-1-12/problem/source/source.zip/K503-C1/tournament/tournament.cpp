# include <bits/stdc++.h>
# define 	N 		11
# define 	N3 		100010
# define 	P 		998244353
# define 	ll 		long long
bool mp[N][N],f[N][N],use[N*N];
ll n,k,ans,m,mul[N3];
using namespace std;
ll mypow(ll x, ll y){
	ll i=x; x=1;
	while (y>0){
		if (y%2==1) x=x*i%P;
		i=i*i%P;
		y/=2;
	}
	return x;
}
ll C(ll n, ll m){
	return mul[n]*mypow(mul[m],P-2)%P*mypow(mul[n-m],P-2)%P;
}
void check(){
	ll num=1;
	memset(mp,0,sizeof(mp));
	for (ll i=1; i<=n; i++)
		for (ll j=1; j<i; j++)
			if (use[num++]==0)
				mp[i][j]=1; else mp[j][i]=1;
	for (ll i=1; i<=n; i++){
		memset(f,0,sizeof(f));
		f[i][0]=true;
		for (ll j=1; j<=k; j++)
			for (ll t=1; t<=n; t++)
				for (ll to=1; to<=n; to++)
					if (mp[to][t]==true&&f[to][j-1]==true){
						f[t][j]=true; break;
					}
		if (f[i][k]==true){
			ans++;
			return;
		}
	}
}
void dfs(ll k){
	if (k>m){
		check();
		return;
	}
	use[k]=1; dfs(k+1);
	use[k]=0; dfs(k+1);
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	mul[0]=1;
	for (ll i=1; i<=n; i++) mul[i]=mul[i-1]*i%P;
	m=C(n,2);
	if (k==3){
		printf("%lld\n",(mypow(2,m)-mul[n]+P)%P);
		return 0;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}

