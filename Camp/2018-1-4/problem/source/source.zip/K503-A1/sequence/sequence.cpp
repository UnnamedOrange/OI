#include<bits/stdc++.h>
using namespace std;
const int hs=12000000;
typedef long long ll;
struct hash{
	const int p=8000009;
	int size=p,h[hs];
	long long s[hs];
	void clear(){
		size=p;
		memset(h,0,sizeof(h));
		memset(s,0,sizeof(s));
	}
	int find(ll x){
		int i=(ll)x%p;
		while ((s[i]!=x)&&(s[i]!=0)) i=h[i]%hs;
		return i;
	}
	void add(ll x,int i,int t){
		h[i]=++size+t*hs;
		s[i]=x;
	}
} h;
int a[15],T,n,ans;
long long calc(){
	ll t=0;
	for (int i=1;i<=n;i++) t=t*n+a[i]-1;
	return t+1;
}
void release(ll t){
	t--;
	for (int i=n;i;i--){
		a[i]=t%n+1;
		t/=n;
	}
}
void rev(int x){
	for (int i=1;i+i<=x;i++)
	swap(a[i],a[x-i+1]);
}
/*void work(int dep){
	ll t=calc();
	int x=h.find(t);
	if (h.s[x]==t){if (h.h[x]%hs+dep*hs<h.h[x]) h.h[x]=h.h[x]%hs+dep*hs;}
	else h.add(t,x,dep);
	if (dep==5) return;
	for (int i=1;i<=n;i++){
		rev(i);
		work(dep+1);
		rev(i);
	}
}*/
ll que[3000000];
int depth[3000000];
void work(){
	int l=1,r=1;
	que[1]=calc();
	h.add(que[1],h.find(que[1]),0);
	while ((l<=r)&&(r<=2999980)&&(depth[r]<=6)){
		release(que[l]);
		for (int i=1;i<=n;i++){
			rev(i);
			ll t=calc();
			int x=h.find(t);
			if (h.s[x]==0) {h.add(t,x,depth[l]+1);que[++r]=t;depth[r]=depth[l]+1;}
			rev(i);
		}
		l++;
	}
}

void work2(int dep){
	if (dep>=ans) return;
	long long t=calc();
	int x=h.find(t);
	if (h.s[x]==t){ans=min(ans,dep+h.h[x]/hs);return;}
	if (dep==6) return;
	for (int i=1;i<=n;i++){
		rev(i);
		work2(dep+1);
		rev(i);
	}
}
int main(){
	freopen("sequence.in","r",stdin);
//	freopen("sequence.out","w",stdout);
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n);ans=n;
		h.clear();
		for (int i=1;i<=n;i++) a[i]=i;
		work();
		for (int i=1;i<=n;i++) scanf("%d",a+i);
		work2(0);
		printf("%d\n",ans);
	}
	return 0;
}
