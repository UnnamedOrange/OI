#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#define MAXN 1000000
using namespace std;
typedef long long ll;
ll p[100005]; int cnt;
bool vis[1000005]; ll res[1000005], pw[1000005];
ll f[1000005], sumf[1000005];int sump[1000005];
void shai(){
	vis[1] = 0; f[1] = 1;
	for(int i = 2; i <= MAXN; i ++){
		if(!vis[i]){
			p[++cnt] = i; res[i] = i; pw[i] = 1;
			f[i] = 3;
		}
		for(int j = 1; j <= cnt && i * p[j] <= MAXN; j ++){
			if(i % p[j] == 0){
				vis[i * p[j]] = 1;
				res[i * p[j]] = res[i] * p[j];
				pw[i * p[j]] = pw[i] + 1;
				if(res[i] == i){
					f[i * p[j]] = (pw[i] + 2) * (pw[i] + 2) - (pw[i] + 1) * (pw[i] + 1);
				}else{
					f[i * p[j]] = f[i / res[i]] * f[p[j] * res[i]];
				}
				break;
			}else{
				vis[i * p[j]] = 1;
				res[i * p[j]] = p[j];
				pw[i * p[j]] = 1;
				f[i * p[j]] = f[i] * f[p[j]];
			}
		}
	}
	for(int i = 1; i <= MAXN; i ++){
		sumf[i] = sumf[i - 1] + f[i];
	}
	int pos = 0;
	for(int i = 1; i <= MAXN; i ++){
		while(p[pos + 1] <= i && pos <= cnt){
			pos++;
		}
		sump[i] = pos;
	}
}
ll g1[100005], g2[100005], f1[100005], f2[100005];
int l1[100005], l2[100005];
int m, c;

void calcG(ll n){
	for(int i = 1; i < m; i ++){
		g1[i] = i;
	}
	for(int i = m - 1; i >= 1; i --){
		g2[i] = n / i;
	}
	for(int i = 1; i < c; i ++){
		int P = p[i];
		for(int j = 1; j < m && i < l2[j]; j ++){
			ll y = (n / j) / P;
			if(y < m) g2[j] -= (g1[y] - max(0, min(i, sump[y]) - l1[y]));
			else g2[j] -= g2[n / y] - max(0, i - l2[n / y]);
		}
		for(int j = m - 1; j && i < l1[j]; j --){
			ll y = j / P;
			g1[j] -= (g1[y] - max(0, min(i, sump[y]) - l1[y]));
		}
	//	printf("%d\n", P);
	
	}
	for(int i = 1; i < m; i ++){
		//g1[i] -= (sump[i] - l1[i] + 1);
		g2[i] -= max(c - l2[i], 0) + 1;
	}
	
}
void calcF(ll n){
	for(int i = 1; i < m; i ++){
		f1[i] = f2[i] = 1;
	}
	for(int i = c - 1; i >= 1; i --){
		int P = p[i];
		for(int j = 1; j < m && i < l2[j]; j ++){
			ll y = (n / j) / P;
			for(int z = 1; y; ++z, y /= P){
				if(y < m){
					f2[j] += (ll)(2 * z + 1) * (f1[y] + 3 * max(0, sump[y] - max(l1[y] - 1, i)));
				}else{
					f2[j] += (ll)(2 * z + 1) * (f2[n / y] + 3 * (c - max(l2[n / y], i + 1)));
				}
			}
		}
		for(int j = m - 1; j && i < l1[j]; j --){
			ll y = j / P;
			for(int z = 1; y; ++z, y /= P){
				f1[j] += (ll)(2 * z + 1) * (f1[y] + 3 * max(0, sump[y] - max(l1[y] - 1, i)));
			}
		}
		
	}
	for(int i = 1; i < m; i ++){
		f2[i] += 4 * (c - l2[i]);
	}
}


ll fuck(ll n){
	m = 1; while((ll)m * m <= n) m ++;
	c = 1; while((ll)p[c] * p[c] <= n) c ++;
	for(int i = 1; i < m; i ++){
		l1[i] = l1[i - 1];
		while(p[l1[i]] * p[l1[i]] <= i) ++l1[i];
	}
	l2[m] = 0;
	for(int i = m - 1; i; i --){
		ll x = n / i;
		l2[i] = l2[i + 1];
		while(p[l2[i]] * p[l2[i]] <= x) ++l2[i];
	}
	calcG(n);
	calcF(n);
	ll ret = f2[1];
	for(int i = 1; i < m; i ++){
		ret += f[i] * 3 * g2[i];
	}
	return ret;
}

int main(){
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	
	int T;
	shai();
	scanf("%d", &T);
	while(T--){
		ll n;
		scanf("%lld", &n);
		printf("%lld\n", fuck(n));
	}
	return 0;
}
