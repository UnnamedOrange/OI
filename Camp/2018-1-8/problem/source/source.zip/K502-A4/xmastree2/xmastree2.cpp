#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>
#include<queue>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=30005,inf=(int)1e10;

int head[N],tot_edge,n,w[N],is_rt[N],par[N];
ll ans;
pii G[N<<1];
struct P_0{
	void dfs(int x){
		for(int i=head[x];i;i=G[i].se){
			int y=G[i].fi;
			if(y==par[x])continue;
			par[y]=x;
			dfs(y);
		}
	}
	int mark[11],tar;
	void work(){
		rep(rt,1,n+1)if(is_rt[rt]){
			par[rt]=0;dfs(rt);
			int a[11],cnt=0,res;
			a[++cnt]=rt;
			rep(i,1,n+1)if(i!=rt)a[++cnt]=i;
			do{
				mark[a[1]]=++tar;
				res=w[a[1]];
				rep(i,2,n+1){
					if(mark[par[a[i]]]!=tar)res=-inf;
					res+=i*w[a[i]];
					mark[a[i]]=tar;
				}
				if(ans<res)ans=res;
			}while(next_permutation(a+2,a+n+1));
		}
		ptn(ans);
	}
}P0;
//struct P_1{
//	int que[1005][1005],sz[1005];
//	void dfs(int x){
//		sz[x]=0;
//		for(int i=head[x];i;i=G[i].se){
//			int y=G[i].fi;
//			if(y==par[x])continue;
//			par[y]=x;
//			dfs(y);
//			static int tmp[1005];
//			int cnt=0,l=1,r=1;
//			while(l<=sz[x]&&r<=sz[y]){
//				if(que[x][l]<que[y][r])tmp[++cnt]=que[y][r++];
//				else tmp[++cnt]=que[x][l++];
//			}
//			while(l<=sz[x])tmp[++cnt]=que[x][l++];
//			while(r<=sz[y])tmp[++cnt]=que[y][r++];
//			sz[x]+=sz[y];
//			memcpy(que[x],tmp,(sz[x]+1)<<2);
//		}
//		que[x][++sz[x]]=w[x];
////		rep(i,1,sz[x]+1)ptk(que[x][i]);
////		puts("");
//	}
//	void work(){
//		rep(rt,1,n+1)if(is_rt[rt]){
//			par[rt]=0;
//			dfs(rt);
//			ll res=0;
//			rep(i,1,n+1)res+=(ll)(n-i+1)*que[rt][i];
//			Max(ans,res);
//		}
//		ptn(ans);
//	}
//}P1;
struct P_2{
	priority_queue<pii>Q;
	int deg[N],sum[N];
	void dfs(int x){
		deg[x]=0;sum[x]=w[x]+sum[par[x]];
		for(int i=head[x];i;i=G[i].se){
			int y=G[i].fi;
			if(y==par[x])continue;
			par[y]=x;++deg[x];
			dfs(y);
		}
		if(!deg[x])Q.push(pii(sum[x]-w[x],x));
	}
	void work(){
		rep(rt,1,n+1)if(is_rt[rt]){
			par[rt]=0;
			while(!Q.empty())Q.pop();
			dfs(rt);
			ll res=0,t=n;
			while(t){
				pii q=Q.top();Q.pop();
				res+=w[q.se]*t;
				--deg[par[q.se]];
				if(!deg[par[q.se]])Q.push(pii(w[par[q.se]],par[q.se]));
				t--;
			}
			Max(ans,res);
		}
		ptn(ans);
	}
}P2;
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	rd(n);
	for(int x,y,i=1;i<n;++i){
		rd(x),rd(y);
		G[++tot_edge]=pii(y,head[x]);head[x]=tot_edge;
		G[++tot_edge]=pii(x,head[y]);head[y]=tot_edge;
	}
	rep(i,1,n+1)rd(w[i]),rd(is_rt[i]);
	if(0);
	else if(n<=10)P0.work();
//	else if(n<=1000)P1.work();
	else P2.work();
	return 0;
}
