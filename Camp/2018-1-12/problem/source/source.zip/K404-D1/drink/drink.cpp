#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <set>
#define N 1000010
#define ll long long
using namespace std;
int n,cntl,cntr;
int lft[50],rgt[50];
set<int>s;
pair<int,int>w[N];
double ans;
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("drink.in","r",stdin);
    freopen("drink.out","w",stdout);
    n=read();
    for(int i=1; i<=n; i++)
        w[i].first=read(),w[i].second=i;
    sort(&w[1],&w[n+1]);
    reverse(&w[1],&w[n+1]);
    for(int i=1; i<=n; i++)
    {
        cntl=cntr=0;
        set<int>::iterator it,now;
        it=s.insert(w[i].second).first;
        for(now=it; now!=s.begin()&&cntl<=25; )
            lft[++cntl]=*(--now);
        for(now=it,now++; now!=s.end()&&cntr<=25; now++)
            rgt[++cntr]=*now;
        lft[0]=rgt[0]=w[i].second;
        lft[++cntl]=0,rgt[++cntr]=n+1;
        for(int rk=1; rk<=i&&rk<=25; rk++)
        {
            ll cnt=0;
            for(int j=min(rk,cntl); j&&rk-j+1<=cntr; j--)
                cnt+=(ll)(lft[j-1]-lft[j])*(rgt[rk-j+1]-rgt[rk-j]);
            ans+=(double)w[i].first*cnt/(1<<rk);
        }
    }
    printf("%.10f\n",ans/n/n);
    return 0;
}
