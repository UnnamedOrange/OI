#include <bits/stdc++.h>

struct trie {
	int next[2];
	int fail;
	int mask;
	void init() {
		next[0] = next[1] = -1;
		fail = -1;
		mask = 0;
	}
} t[100003];int tn;
int n,m;
typedef long long int int64;
static const int64 mod = 998244353;
int64 dp[2][100003][32];
char str[12][103];int lenstr[6];bool ok[12][103];
int64 ans;
void dfs(int i,char *sstr,int stri,int found)
{
	char mystr[503];
	if(i == n) {
		/*int len = strlen(sstr);
		int cur = 1;
		for(int j = 0;j < len;++j) {
			if(t[cur].next[sstr[j]-'0'] == -1)
				t[t[cur].next[sstr[j]-'0'] = tn++].init();
			cur = t[cur].next[sstr[j]-'0'];
		}
		t[cur].mask |= found;*/
		t[stri].mask |= found;
	} else {
		bool checked = false;
		for(int tt = 0;tt < 2 && !checked;++tt) {
			for(int j = lenstr[i] - 1;j >= 0;--j) if(ok[i*2+tt][j]) {
				assert((lenstr[i] - j) % 2 == 0);
				int s = (lenstr[i] - j) >> 1;
				bool succ = true,changed = false;
				for(int k = 0;k < m;++k)
					mystr[k] = sstr[k];
				int sstri = stri;
				for(int k = s;k < lenstr[i];++k) {
					if(sstr[k-s] == 0) {
						mystr[k-s] = str[i*2+1-tt][k];
						if(t[sstri].next[str[i*2+1-tt][k]-'0'] == -1) {
							t[t[sstri].next[str[i*2+1-tt][k]-'0'] = tn++].init();
						}
						sstri = t[sstri].next[str[i*2+1-tt][k]-'0'];
						changed = true;
					} else if(sstr[k-s] != str[i*2+1-tt][k]) {
						succ = false;
						break;
					}
				}
				if(!succ) continue;
				if(!changed) {
					checked = true;
					break;
				}
				dfs(i+1,mystr,sstri,found|(1<<i));
			}
		}
		for(int k = 0;k < m;++k)
			mystr[k] = sstr[k];
		if(checked) found |= (1 << i);
		dfs(i+1,mystr,stri,found);
	}
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 0;i < n;++i) {
		scanf(" %s",str[i*2]);
		int len = lenstr[i] = strlen(str[i*2]);
		for(int j = 0;j < len;++j) str[i*2+1][len-1-j] = '1' - str[i*2][j] + '0';
		//printf("%s\n%s\n",str[i*2],str[i*2+1]);
	}
	
	// preprocess by brute force
	for(int i = 0;i < 2 * n;++i) {
		int len = lenstr[i>>1];
		for(int j = 0;j < len;++j) {
			bool a = true;
			for(int k = 0;j + k < len;++k) if(str[i][j+k] != str[i^1][k]) {a=false;break;}
			ok[i][j] = a;
			//printf("%d",ok[i][j]);
		}
		//printf("\n");
	}
	
	tn = 2;t[0].init();t[1].init();
	for(int i = 0;i < 2 * n;++i) {
		int cur = 0,len = lenstr[i>>1];
		for(int j = 0;j < len;++j) {
			int ch = str[i][j] - '0';
			if(t[cur].next[ch] == -1)
				t[t[cur].next[ch] = tn++].init();
			cur = t[cur].next[ch];
		}
		t[cur].mask |= (1 << (i >> 1));
	}
	
	char curstr[503];
	memset(curstr,0,sizeof(curstr));
	dfs(0,curstr,1,0);
	
	std::queue<int> processed;
	t[1].fail = 0;processed.push(1);
	for(int i = 0;i < 2;++i) {
		if(t[0].next[i] != -1) {
			t[t[0].next[i]].fail = 0;
			processed.push(t[0].next[i]);
		} else {
			t[0].next[i] = 0;
		}
	}
	while(!processed.empty()) {
		int cur = processed.front();processed.pop();
		for(int i = 0;i < 2;++i) {
			if(t[cur].next[i] != -1) {
				t[t[cur].next[i]].fail = t[t[cur].fail].next[i];
				processed.push(t[cur].next[i]);
			} else {
				t[cur].next[i] = t[t[cur].fail].next[i];
			}
		}
	}
	ans = 0;
	
	int base = (1 << n) - 1;
	memset(dp,0,sizeof(dp));
	dp[0][t[1].next[0]][t[t[1].next[0]].mask] = 1;
	dp[0][t[1].next[1]][t[t[1].next[1]].mask] = 1;
	for(int si = 0;si < m - 1;++si) {
		for(int j = 0;j < tn;++j) {
			for(int k = 0;k <= base;++k) {
				dp[(si+1)&1][t[j].next[0]][k|t[t[j].next[0]].mask] += dp[si&1][j][k];
				dp[(si+1)&1][t[j].next[0]][k|t[t[j].next[0]].mask] %= mod;
				dp[(si+1)&1][t[j].next[1]][k|t[t[j].next[1]].mask] += dp[si&1][j][k];
				dp[(si+1)&1][t[j].next[1]][k|t[t[j].next[1]].mask] %= mod;
				dp[si&1][j][k] = 0;
			}
		}
	}
	
	int64 ans = 0;
	for(int j = 0;j < tn;++j) {
		ans += dp[(m-1)&1][j][base];
	}
	printf("%lld\n",ans%mod);
}
