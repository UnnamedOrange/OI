#include<cstdio>
#include<algorithm>
using namespace std;
#define N 103
#define M 100005
#define rep(i,j,k) for(i=j;i<=k;++i)
int tes,n,i,j,k,m;
char s[M];
int f[N][N];
bool vis[N][N];
void read(int &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
}
int dp(int l,int r){
	int i;
	if(l>r) return 0;
	if(l==r) return -1;
	if(vis[l][r]) return f[l][r];
	rep(i,l,r-1) {
		int tmp1=dp(l,i);
		int tmp2=dp(i+1,r);
		if((tmp1!=-1)&&(tmp2!=-1)){
			if((f[l][r]==-1)||(f[l][r]>tmp1+tmp2)){
				f[l][r]=tmp1+tmp2;
			}
		} 
	}
	bool flag=true;
	rep(i,1,(r-l+1)>>1){
		if(s[l+i-1]!=s[r-i+1]) flag=false;
		if(!flag){
			int tmp=dp(l+i,r-i);
			if(tmp!=-1){
				if((f[l][r]==-1)||(f[l][r]>tmp+1))
					f[l][r]=tmp+1;
			}
			if(2*i+1<=r-l+1){
				int tmp=dp(l+i,r-i-1);
				if(tmp!=-1){
				if((f[l][r]==-1)||(f[l][r]>tmp+1))
					f[l][r]=tmp+1;
				}
			} 
		}
	}
	vis[l][r]=1;
	return f[l][r];
}
void init(){
	read(n);
	scanf("%s",s+1);
	if(n<=100)
	{
		rep(i,0,n)
	 	rep(j,0,n) vis[i][j]=0,f[i][j]=-1;
		printf("%d\n",dp(1,n));
	}else
	{
		bool flag=true,pln=true;
		rep(i,1,n>>1)
		if(s[i]!=s[n-i+1]){
			pln=false;
			break ;
		}else{
			if(s[1]!=s[i]) flag=false;
		}
		if(!pln) puts("1");
		else{
			if(flag) puts("-1");
			else printf("2\n");
		}
	} 
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	read(tes);
	while(tes--){
		init();
	}
	return 0;
} 
