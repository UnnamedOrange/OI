#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 1000005;
int n, a[N];
double ans;
void solve1(){
	for(int i = 1; i <= n; i++){
		int b[105] = {0};
		for(int j = i; j <= n; j++){
			b[j - i + 1] = a[j];
			sort(b + 1, b + j - i + 2);
			double res = 0;
			for(int k = 1; k <= j - i + 1; k++)
				res = (res + b[k]) / 2;
			ans += res / n / n;
		}
	}
	printf("%lf\n", ans);
}
int cnt[4 * N], lst[N], idx;
double pw[N], sum[4 * N];
void build(int k, int l, int r){
	sum[k] = cnt[k] = 0;
	if(l == r) return;
	int mid = (l + r) >> 1;
	build(k << 1, l, mid);
	build(k << 1 | 1, mid + 1, r);
}
void change(int k, int l, int r, int p, int x){
	if(l == r){
		cnt[k] += x;
		sum[k] = (pw[cnt[k]] - 1) * lst[p] / pw[cnt[k]];
		return;
	}
	int mid = (l + r) >> 1;
	if(p <= mid) change(k << 1, l, mid, p, x);
	else change(k << 1 | 1, mid + 1, r, p, x);
	cnt[k] = cnt[k << 1] + cnt[k << 1 | 1];
	sum[k] = sum[k << 1] / pw[cnt[k << 1 | 1]] + sum[k << 1 | 1];
}
void solve2(){
	pw[0] = 1;
	for(int i = 1; i <= n; i++)
		pw[i] = pw[i - 1] * 2, lst[i] = a[i];
	sort(lst + 1, lst + n + 1);
	idx = unique(lst + 1, lst + n + 1) - lst - 1;
	for(int i = 1; i <= n; i++)
		a[i] = lower_bound(lst + 1, lst + idx + 1, a[i]) - lst;
	for(int i = 1; i <= n; i++){
		build(1, 1, idx);
		for(int j = i; j <= n; j++){
			change(1, 1, idx, a[j], 1);
			ans += sum[1] / n / n;
		}
	}
	printf("%lf\n", ans);
}

int main(){
	
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	
	read(n);
	for(int i = 1; i <= n; i++) read(a[i]);
	if(n <= 100){
		solve1();
		return 0;
	}
	if(n <= 1500){
		//puts("?");
		solve2();
		return 0;
	}

	return 0;
}
