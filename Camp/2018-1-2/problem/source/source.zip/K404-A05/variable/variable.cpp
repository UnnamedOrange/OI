//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
int head[511],nxt[100011],to[100011],cap[100011],tot=1;
void adde(int x,int y,int c)
{
//	cerr<<"adde:"<<x<<","<<y<<" "<<c<<endl;
	nxt[++tot]=head[x];
	head[x]=tot;
	to[tot]=y;
	cap[tot]=c;
	nxt[++tot]=head[y];
	head[y]=tot;
	to[tot]=x;
	cap[tot]=0;
}
void adde2(int x,int y,int c)
{
//	cerr<<"adde2:"<<x<<","<<y<<" "<<c<<endl;
	nxt[++tot]=head[x];
	head[x]=tot;
	to[tot]=y;
	cap[tot]=c;
	nxt[++tot]=head[y];
	head[y]=tot;
	to[tot]=x;
	cap[tot]=c;
}
int lv[511],q[511],qn;
void bfs(int S)
{
	qn=0;
	memset(lv,-1,sizeof(lv));
	lv[S]=0;
	q[qn++]=S;
	for(int i=0;i<qn;i++)
	{
		int u=q[i];
		for(int j=head[u];j;j=nxt[j])
		{
			if(cap[j]&&lv[to[j]]==-1)
			{
				lv[to[j]]=lv[u]+1;
				q[qn++]=to[j];
			}
		}
	}
}
int it[511];
int dfs(int x,int T,int f)
{
	if(x==T)return f;
	int of=f;
	for(int &i=it[x];i&&f;i=nxt[i])
	{
		int u=to[i];
		if(cap[i]&&lv[u]==lv[x]+1)
		{
			int d=dfs(u,T,min(f,cap[i]));
			if(d)
			{
				cap[i]-=d;
				cap[i^1]+=d;
				f-=d;
			}
		}
	}
	return of-f;
}
ll solve(int S,int T,int tn)
{
	ll ans=0;
	while(true)
	{
		bfs(S);
		if(lv[T]==-1)return ans;
		for(int i=0;i<=tn;i++)it[i]=head[i];
		int f;
		while(f=dfs(S,T,mod))ans+=f;
	}
}
int Tn,n,W,n1,n2;
int coef[511];
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&Tn);
	while(Tn--)
	{
		tot=1;
		memset(head,0,sizeof(head));
		scanf("%d%d%d%d",&n,&W,&n1,&n2);
		memset(coef,0,sizeof(coef));
		for(int i=1;i<=n;i++)coef[i]=1;
		int S=n+1,T=n+2;
		for(int i=1;i<=n1;i++)
		{
			int x,y,z,a,b,c,d,e,f;
			scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&e,&f);
			adde2(x,y,2*a);
			adde2(y,z,2*b);
			adde2(z,x,2*c);
			coef[x]+=d-f;
			coef[y]+=e-d;
			coef[z]+=f-e;
		}
		for(int i=1;i<=n2;i++)
		{
			int x,y,r;
			scanf("%d%d%d",&x,&y,&r);
			if(r==0)adde(y,x,mod);
			if(r==1)adde(x,y,mod),adde(y,x,mod);
			if(r==2)adde(S,x,mod),adde(y,T,mod);
		}
		ll bsans=0;
		for(int i=1;i<=n;i++)
		{
			ll c0=-coef[i],c1=coef[i];
			if(c0<=c1)
			{
				bsans+=c0;
				adde(S,i,c1-c0);
			}
			else
			{
				bsans+=c1;
				adde(i,T,c0-c1);
			}
		}
		ll ans=solve(S,T,T);
//		cerr<<"ans="<<ans<<endl;
		if(ans>=mod)puts("impossible");
		else cout<<(bsans+ans)*W<<endl;
	}
	return 0;
}
