#include<bits/stdc++.h>
using namespace std;

const int maxn = 1000000 + 10;

int n,m,f[maxn],e[maxn];

int fa(int x)
{
	if(f[x]==-1) return x;
	return f[x]=fa(f[x]);
}
bool merge(int x,int y)
{
	x=fa(x);y=fa(y);
	if(x==y) return false;
	f[x]=y;
}

void solve1()
{
	int i,j,S,x,y,t;
	int cnt,ans=1;
	
	for(i=0;i<n;i++) e[i]=1<<i;
	for(i=0;i<m;i++) 
	{
		scanf("%d%d",&x,&y);x--,y--;
		e[x]|=1<<y;
		e[y]|=1<<x;
	}/*
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++) cout<<((e[i]&1<<j)!=0);
		cout<<endl;
	}*/
	
	for(S=0;S<(1<<n);S++)
	{
		t=(1<<n)-1;cnt=0;
		for(i=0;i<n;i++) if(S&1<<i) t&=e[i],cnt++;
		if((t&S)==S) ans=max(ans,cnt);
	}
	cout<<ans;
}

void solve()
{
	int i,x,y;
	
	scanf("%d%d",&n,&m);
	if(!m) {cout<<1;return;}
	
	if(n<=20) {solve1();return;}
	
	memset(f,-1,sizeof(f));
	for(i=0;i<m;i++)
	{
		scanf("%d%d",&x,&y);
		if(!merge(x,y)) {cout<<4;return;}
	}
	cout<<2;
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	
	solve();
	
	return 0;
}
