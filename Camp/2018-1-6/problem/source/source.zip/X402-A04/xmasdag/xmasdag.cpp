#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=998244353;
const int N=100050;
const int M=200050;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int head[N],cnt=0;
struct node
{
	int to,next;
}e[M];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
}

int f[2050][2050],n,m,k,deg[N];
int ans[N],pwk[N],fac[N],finv[N];
void dp()
{
	f[0][1]=1;
	for(int i=0;i<n;++i) for(int u=1;u<=n;++u) 
	{
		ans[u]=(ans[u]+f[i][u]*pwk[i])%mod;
		for(int j=head[u];j;j=e[j].next)
		{
			int v=e[j].to;
			f[i+1][v]=(f[i+1][v]+f[i][u])%mod;
		}
	}
}

int stk[N],top=0,g[N];
void dpk1()
{
	g[1]=1; ans[1]=0;
	stk[++top]=1;
	while(top)
	{
		int u=stk[top]; top--;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			deg[v]--;
			g[v]+=g[u];
			ans[v]=((ll)ans[v]+ans[u]+g[u])%mod;
			if(!deg[v]) stk[++top]=v;
		}
	}
}

int pw[N],h[N][505];
void dpel()
{
	h[1][0]=1;
	stk[++top]=1;
	while(top)
	{
		int u=stk[top]; top--;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			deg[v]--;
			h[v][0]=(h[v][0]+h[u][0])%mod;
			for(int j=1;j<=k;++j) for(int l=0;l<=j;++l)
			{
				h[v][j]=((ll)h[v][j]+1ll*fac[j]*finv[l]%mod*finv[j-l]%mod
				*h[u][l]%mod)%mod;
			}
			if(!deg[v]) stk[++top]=v;
		}
	}
	for(int i=1;i<=n;++i) ans[i]=h[i][k];
}

void wj()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read(); m=read(); k=read();
	for(i=1;i<=m;++i)
	{
		int x=read(),y=read();
		add(x,y); deg[y]++;
	}
	for(i=0;i<=n;++i) pwk[i]=qpow(i,k);

	fac[0]=1; finv[0]=1;
	for(i=1;i<=k;++i) fac[i]=1ll*fac[i-1]*i%mod;
	finv[k]=qpow(fac[k],mod-2);
	for(i=k-1;i>=1;--i) finv[i]=1ll*finv[i+1]*(i+1)%mod;

	if(n<=2001&&m<=5001) dp();
	else if(k==1) dpk1();
	else dpel();
	for(i=1;i<=n;++i) printf("%d\n",ans[i]);
	return 0;
}
