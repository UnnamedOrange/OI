#include <cmath> 
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

#define LL long long

const int mod = 1000000007;
const int N = 1000000 + 1000;

int n;

namespace file{
	inline void open()
	{
		freopen("sad.in", "r", stdin);
		freopen("sad.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

namespace input{
	inline LL read()
	{
		LL a = 0;
		char ch;
		LL f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}
	
	inline void Get()
	{
		n = read();
	}
}

namespace print{
	inline void solve()
	{
		printf("%lld\n", 1ll * n * 19260817);
	}
}

int main()
{
	open();
	print::solve();
	close();
	return 0;
}
