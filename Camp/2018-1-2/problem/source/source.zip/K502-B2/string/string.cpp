#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)1e5+5,MM=M+M;
int n;
char S[M];
struct SHUI{
	int dp[(1<<10)],bin[10],CA[(1<<10)];
	SHUI(){
		for(int i=0;i<10;i++)bin[i]=(1<<i);
	}
	int dfs(int S){
		int &re=dp[S];
		if(re!=-1)return re;
		int stk[15],sz=0;
		for(int i=0;i<n;i++)if(bin[i]&S)stk[sz++]=i;
		for(int i=0,tmp,tmpans;i<sz;i++){
			tmp=bin[stk[i]];
			for(int j=i+1;j<sz;j++){
				tmp|=bin[stk[j]];
				if(CA[tmp]){
					tmpans=dfs(S^tmp);
					if(tmpans==-1)continue;
					tmpans++;
					if(tmpans<re||re==-1)re=tmpans;
				}
			}
		}
		return re;
	}
	void solve(){
		for(int i=(1<<n)-1;i>0;i--){
			static int a[15],sz;
			static bool f;
			sz=0;
			f=false;
			for(int j=0;j<n;j++)if(i&bin[j])a[sz++]=S[j];
			for(int l=0,r=sz-1;l<r;l++,r--)
				if(a[l]!=a[r]){
					f=true;
					break;
				}
			CA[i]=f;
			dp[i]=-1;
		}
		printf("%d\n",dfs((1<<n)-1));
	}
}P30;
struct IHSU{
	int md[MM],a[MM];
	void init(){
		for(int i=0;i<n;i++)a[2*i+1]=S[i],a[2*i]='#';
		a[2*n]='#';
		int len=2*n+1;
		int x=0;
		md[0]=1;
		for(int i=1;i<len;i++){
			md[i]=0;
			if(x+md[x]>i){
				md[i]=md[2*x-i];
				while(md[i]<=i&&i+md[i]<len&&a[i-md[i]]==a[i+md[i]])md[i]++;
				if(i+md[i]>x+md[x])x=i;
			}else {
				x=i;
				while(md[x]<=x&&x+md[x]<len&&a[x-md[x]]==a[x+md[x]])md[x]++;
			}
		}
	}
	bool check(int l,int r){
		l=2*l+1,r=2*r+1;
		int mid=(l+r)>>1;
		return mid-md[mid]<l;
	}
	void solve(){
		init();
		if(check(0,n-1)==0)puts("1");
		else {
			for(int i=0,n1=n-1;i<n;i++)
				if(check(0,i)==0&&check(i+1,n1)==0){
					puts("2");
					return;
				}
			puts("-1");
		}
	}
}PPP;
void solve(){
	scanf("%d",&n);
	scanf("%s",S);
//	if(0);
	if(n<=10)P30.solve();
	else PPP.solve();
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int cas;scanf("%d",&cas);
	while(cas--)solve();
	return 0;
}
