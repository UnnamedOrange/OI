#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 1000005
const int mod=1e9+7;

int n,a,b;
int x[maxn];
int f[maxn][2];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

int main(){
	n=read(),a=read(),a=read();
	for (int i=1;i<=n;i++) x[i]=read()/a;
	f[0][0]=1;
	for (int i=1;i<=n;i++){
		f[i][0]=f[i-1][0],f[i][1]=f[i-1][1];
		if (x[i]&1) f[i][0]=(f[i][0]+f[i-1][1])%mod,f[i][1]=(f[i][1]+f[i-1][0])%mod;
		else f[i][1]=(f[i][1]+f[i-1][1])%mod,f[i][0]=(f[i][0]+f[i-1][0])%mod;
	}
	printf("0 0 %d %d\n",f[n][1],f[n][0]);
	return 0;
}
