#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
using namespace std;

int n;
int nx[10], ny[10];

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

namespace Work1
{
	int spawn(int x, int y)
	{
		memset(nx, 0, sizeof nx);
		memset(ny, 0, sizeof ny);
		int sx = 0, sy = 0, tx = x, ty = y;
		while (tx > 0)
		{
			nx[sx] = tx % 2;
			tx /= 2;
			++sx;
		}
		while (ty > 0)
		{
			ny[sy] = ty % 2;
			ty /= 2;
			++sy;
		}
		sx = max(sx, sy);
		for (int i = sx - 1; i > -1; --i)
		{
			if (nx[i] != ny[i])
			{
			//	cerr << i << endl;
				if (nx[i] == 1)
					return i + 1;
				else
					return i + 11;
			}
		}
	}
	void main()
	{
		n = read();
		int T = read();
		while (T--)
		{
			int x = read(), y = read();
			printf("%d\n", spawn(x, y));
		}
	}
}

namespace Work2
{
	int nq[10];
	bool decode(int q, int h)
	{
		int qs = 0, tq = q;
		memset(nq, 0, sizeof nq);
		while (tq > 0)
		{
			nq[qs] = tq % 2;
			++qs;
			tq /= 2;			
		}
	//	cerr << q << " " << qs << endl;
		if (h > 10)
		{
			h -= 11;
			return nq[h] == 0;
		} 
		else
			return nq[h - 1] == 1;
	}
	void main()
	{
		n = read();
		int T = read();
		while (T--)
		{
			int q = read(), h = read();
			if (decode(q, h))
				printf("yes\n");
			else
				printf("no\n");
		}
	}
}


int main()
{
	int t = read();
	if (t == 1)
		Work1::main();
	else
		Work2::main();
	return 0;
}
