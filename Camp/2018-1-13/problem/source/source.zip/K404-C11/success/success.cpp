#include <bits/stdc++.h>

namespace {

typedef unsigned long long ulong;

int t, m;
ulong n, s;

const int MAXI = 1000000 + 9;
const int MOD = 1000000007;

int fac[MAXI], inv[MAXI];

inline int modPow(register int a, register int b) {
    register int ret = 1;
    for (; b; b >>= 1, a = (ulong)a * a % MOD)
        if (b & 1) ret = (ulong)ret * a % MOD;
    return ret;
}

inline int add(const int x, const int v) {
    return x + v >= MOD ? x + v - MOD : x + v;
}

inline int dec(const int x, const int v) {
    return x - v < 0 ? x - v + MOD : x - v;
}

inline int nCr(const int n, const int r) {
    return (n < r) ? 0 : (ulong)fac[n] * inv[r] % MOD * inv[n - r] % MOD;
}

namespace Task12 {

inline void solve() {
    if (n > m) n = m;
    const register int k = std::max(n, s);
    fac[0] = 1;
    for (register int i = 1; i <= k; i++) fac[i] = (ulong)fac[i - 1] * i % MOD;
    inv[k] = modPow(fac[k], MOD - 2);
    for (register int i = k - 1; i >= 0; i--)
        inv[i] = inv[i + 1] * (i + 1ull) % MOD;
    int ans = 0;
    for (int i = 0; i <= n; i++) {
        if (i & 1) {
            ans = dec(ans, (ulong)nCr(n, i) * nCr(s - i * t, m) % MOD);
        } else {
            ans = (ans + (ulong)nCr(n, i) * nCr(s - i * t, m)) % MOD;
        }
    }
    std::cout << ans;
}
}  // namespace Task12

inline void solve() {
    std::cin >> s >> t >> n >> m;
    if (m > s) {
        std::cout << "0";
        return;
    }
    if (n <= 100 || (m <= 1000000 && s <= 1000000)) {
        Task12::solve();
        return;
    }
}
}  // namespace

int main() {
    freopen("success.in", "r", stdin);
    freopen("success.out", "w", stdout);
    solve();
    return 0;
}