#include<bits/stdc++.h>
using namespace std;
char c[123000];
struct condi{
	char c[340];
	int step;
};
int ap[300];
int n;
void bfs() {
	queue<condi>sth;
	map<string,int>kk;
	condi ori;
	for(int i=0;i<n;++i) {
		ori.c[i]=c[i];
	}
	ori.step=0;
	sth.push(ori);
	while(!sth.empty()) { 
		condi nw=sth.front();
		sth.pop();
		int n=strlen(nw.c);
		if(n==0) {
			printf("%d\n",nw.step);
			return;
		}
		for(int i=0;i<n;++i) { 
			for(int j=i;j<n;++j) { 
				int hw=1;
				for(int k=i;k<=j;++k) { 
					if(nw.c[k]!=nw.c[j+i-k]) 
						hw=0;
				} 
				if(hw==1)
					continue;
				condi ne;
				int cnt=0;
				for(int k=0;k<n;++k) {
					if(k<i||k>j) {
						ne.c[cnt]=nw.c[k];
						cnt++;
					}
				}
				if(cnt==0) {
					printf("%d\n",nw.step+1);
					return;
				}
				ne.step=nw.step+1;
				if(kk[nw.c]==0)
					sth.push(ne);
				kk[ne.c]=1;
			} 
		} 
	}
	printf("%d\n",-1);
	return; 
}
bool tri,spe1,spe2,bac,spe3;
void judge() { 
	memset(ap,0,sizeof(ap)); 
	bac=1;
	spe2=1;
	spe1=1;
	spe3=1;
	int cnt=0;
	for(int i=0;i<n;++i) { 
		if(c[i]!=c[n-i-1]) {
			bac=0;
			tri=1;
			spe1=0;
			spe2=0;
			spe3=0;
			return;
		} 
	} 
	for(int i=0;i<n;++i) { 
		if(ap[c[i]]==0) 
			cnt++;
		ap[c[i]]++;
		if(cnt>=3) { 
			tri=1;
			spe1=0;
			spe2=0;
			spe3=0;
			return;
		} 
	} 
	for(int i=1;i<n;++i) { 
		if(c[i]!=c[i-1])
			spe2=false;
		if(i>3) { 
			if(c[i-3]!=c[i-1]||c[i-2]!=c[i])
				spe1=false;
		} 
	} 
	if(c[0]!=c[n-1])
		spe1=false;
	if(n%2==0||ap[c[0]]!=n-1||ap[c[n/2]]!=1)
		spe3=false;
	return;
} 	
int main() { 
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T>0) { 
		T--;
		scanf("%d",&n);
		scanf("%s",c);
		n=strlen(c);
		if(n>10) {
			judge();
			if(bac==0) { 
				printf("1\n");
			} 
			else if(spe1==1||spe2==1||spe3==1) { 
				printf("-1\n");
			} 
			else 
				printf("2\n");
		}
		else {
			bfs();
		}
	} 
	return 0;
} 
