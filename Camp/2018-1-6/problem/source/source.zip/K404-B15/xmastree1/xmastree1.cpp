#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
struct node
{
	int to,next;
}edge[100010];
int ans,lastans;
int c[50010],Father[50010];
int head[50010],num_edge;
int n,q,t;
bool used[50010];
void add(int u,int v)
{
	edge[++num_edge].to=v;
	edge[num_edge].next=head[u];
	head[u]=num_edge;
}

void Build(int x)
{
	for (int i=head[x];i!=0;i=edge[i].next)
		if (edge[i].to!=Father[x])
		{
			Father[edge[i].to]=x;
			Build(edge[i].to);
		}
}

void Query(int x,int l,int r)
{
	if (c[x]>=l && c[x]<=r && !used[c[x]])
	{
		++ans;
		used[c[x]]=true;
	}
	for (int i=head[x];i!=0;i=edge[i].next)
		if (edge[i].to!=Father[x])
		{
			Query(edge[i].to,l,r);
		}
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for (int i=1;i<=n;++i)
		scanf("%d",&c[i]);
	for (int i=1;i<=n-1;++i)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	Build(1);
	for (int i=1;i<=q;++i)
	{
		int p,u,l,r;
		scanf("%d",&p);
		if (p==1)
		{
			scanf("%d%d%d",&u,&l,&r);
			u^=lastans;
			l^=lastans;
			r^=lastans;
			ans=0;
			if (l>r) swap(l,r);
			memset(used,false,sizeof(used));
			Query(u,l,r);
			printf("%d\n",ans);
			if (t==1)
				lastans=ans;
		}
		if (p==2)
		{
			scanf("%d%d",&u,&l);
			u^=lastans;
			l^=lastans;
			c[u]=l;
		}
	}
}

