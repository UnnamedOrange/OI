#include<cstdio>
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
int n,a,b;
int x[101];
const int mod=1e9+7;
inline int fp(int a,int b){
	int ret=1;
	if(b<0)
		return 0;
	while(b){
		if(b&1)ret=1ll*ret*a%mod;
		a=1ll*a*a%mod;
		b>>=1;
	}
	return ret;
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	FOR(i,1,n)
		scanf("%d",x+i);
	a>b?printf("0 %d ",fp(2,n-1)):printf("%d 0 ",fp(2,n-1));
	printf("%d %d\n",fp(2,n-2),fp(2,n-2));
	return 0;
}
