#include<bits/stdc++.h>
using namespace std;
const int p=998244353;
char s[1000];
int nxt[1000][5],nxt2[1000][5],pos[10][1000],p2[10][1000],fail[1000],fail2[1000],danger[1000],danger2[1000],q[1000],f[600][1000][50],g[600][1000][50],l[1000],n,m,tot=0,tot2=0;
inline void ins(char *s,int id){
	int len=strlen(s+1),u=0;
	for (int i=1;i<=len;i++){
		if (!nxt[u][s[i]-48]) nxt[u][s[i]-48]=++tot;
		pos[id][i]=u=nxt[u][s[i]-48];
	}
	danger[u]|=1<<id-1;
}
inline void ins2(char *s,int id){
	int len=strlen(s+1),u=0;
	for (int i=1;i<=len;i++){
		if (!nxt2[u][49-s[i]]) nxt2[u][49-s[i]]=++tot2;
		p2[id][i]=u=nxt2[u][49-s[i]];
	}
	danger2[u]|=1<<id-1;
}
void getfail(){
	int l=1,r=1;
	for (int i=0;i<2;i++)
		if (nxt[0][i]){
			fail[nxt[0][i]]=0;
			q[r++]=nxt[0][i];
		}
	while (l<r){
		int u=q[l++];
		for (int i=0;i<2;i++)
			if (nxt[u][i]){
				fail[nxt[u][i]]=nxt[fail[u]][i];
				danger[nxt[u][i]]|=danger[fail[nxt[u][i]]];
				q[r++]=nxt[u][i];
			}
			else nxt[u][i]=nxt[fail[u]][i];
	}
	f[0][0][0]=1;
	for (int i=1;i<=m;i++)
		for (int j=0;j<r;j++)
			for (int k=0;k<1<<n;k++){
				f[i][nxt[q[j]][0]][k|danger[nxt[q[j]][0]]]=(f[i][nxt[q[j]][0]][k|danger[nxt[q[j]][0]]]+f[i-1][q[j]][k])%p;
				f[i][nxt[q[j]][1]][k|danger[nxt[q[j]][1]]]=(f[i][nxt[q[j]][1]][k|danger[nxt[q[j]][1]]]+f[i-1][q[j]][k])%p;
			}
}
void getfail2(){
	int l=1,r=1;
	for (int i=0;i<2;i++)
		if (nxt2[0][i]){
			fail2[nxt2[0][i]]=0;
			q[r++]=nxt2[0][i];
		}
	while (l<r){
		int u=q[l++];
		for (int i=0;i<2;i++)
			if (nxt2[u][i]){
				fail2[nxt2[u][i]]=nxt2[fail2[u]][i];
				danger2[nxt2[u][i]]|=danger2[fail2[nxt2[u][i]]];
				q[r++]=nxt2[u][i];
			}
			else nxt2[u][i]=nxt2[fail2[u]][i];
	}
	g[0][0][0]=1;
	for (int i=1;i<=m;i++)
		for (int j=0;j<r;j++)
			for (int k=0;k<1<<n;k++){
				g[i][nxt[q[j]][0]][k|danger[nxt[q[j]][0]]]=(g[i][nxt[q[j]][0]][k|danger[nxt[q[j]][0]]]+g[i-1][q[j]][k])%p;
				g[i][nxt[q[j]][1]][k|danger[nxt[q[j]][1]]]=(g[i][nxt[q[j]][1]][k|danger[nxt[q[j]][1]]]+g[i-1][q[j]][k])%p;
			}
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++){
		scanf("%s",s+1);
		l[i]=strlen(s+1);
		ins(s,i);
		reverse(s+1,s+l[i]+1);
		ins2(s,i);
	}
	getfail();
	getfail2();
	int ans=0;
	for (int i=1;i<=n;i++)
		for (int j=1;j<l[i];j++)
			for (int k=0;k<1<<n;k++)
				if (~f[m][pos[i][j]][k]&&~g[m][p2[i][l[i]-j]][(1<<n)-1^k]) ans=(ans+f[m][pos[i][j]][k]*g[m][p2[i][l[i]-j]][(1<<n)-1^k])%p;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			for (int k=0;k<1<<n;k++)
				if (~f[m][pos[i][l[i]]][k]&&~g[m][p2[j][l[j]]][(1<<n)-1^k]) ans=(ans+f[m][pos[i][l[i]]][k]*g[m][p2[j][l[j]]][(1<<n)-1^k])%p;
	printf("%d\n",ans);
	return 0;
}
