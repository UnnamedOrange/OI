#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0*clock()/CLOCKS_PER_SEC << std::endl
#define fst first
#define snd second

typedef long long LL;
typedef std::pair<int, int> Pii;

#ifndef __linux__
#define getchar getchar_unlocked
#endif
template <typename T> inline bool maximum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T> inline bool minimum(T &a, T b) { return a > b? a = b, 1 : 0; }
template <typename T> 
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 1e2 + 10, mod = 998244353;

int n, k;

bool vis[N];
int Ans, G[N][N];

bool dfs_check(int u, int len, int Top)
{
	if(vis[u]) return len == k && u == Top;
	vis[u] = 1;
	for(int i = 1; i <= n; ++i)
		if(G[u][i]){
			if(dfs_check(i, len + 1, Top)){
			//	printf("%d<-", u);
				return true;
			}
		}
	vis[u] = 0;
	return false;
}

void dfs(int x, int y)
{
	if(x > n){
		bool flag = 0;
		for(int i = 1; i <= n; ++i){
			for(int j = 1; j <= n; ++j) vis[j] = 0;
			if(dfs_check(i, 0, i)){
				flag = 1;
				break;
			}
		}
		Ans += flag;
		return ;
	}

	if(y > n){
		dfs(x + 1, x + 2);
		return ;
	}

	G[x][y] = 1;
	dfs(x, y + 1);
	G[x][y] = 0;

	G[y][x] = 1;
	dfs(x, y + 1);
	G[y][x] = 0;
}

int main()
{
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);

	read(n), read(k);
	dfs(1, 2);
	printf("%d\n", Ans);

	return 0;
}
//TODO GKKAK
