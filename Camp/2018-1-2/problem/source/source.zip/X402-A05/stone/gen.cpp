#include <bits/stdc++.h>

int main()
{
	freopen("stone.in", "w", stdout);
	srand(time(0));
	int n = 5, a = rand() % 8 + 1;
	printf("%d %d %d\n", n, a, a);
	for(int i = 1; i <= n; ++i)
		printf("%d%c", rand() % 12 + 1, i == n? '\n' : ' ');
	return 0;
}
