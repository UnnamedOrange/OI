#include <iostream>

using namespace std;

void open()
{
	freopen("sad.in" , "r", stdin);
	freopen("sad.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}
int main()
{
	open();
	cout<<3<<endl;
	close();
	return 0;
}
