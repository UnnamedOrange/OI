#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#define ele long long
using namespace std;
#define maxn 100010
ele n,pcnt,plst[maxn],mu[maxn];
bool flag[maxn];
inline ele g(ele n,ele r){
	ele ans=0;
	for (int i=n; i>=r;){
		ele j=max(n/(n/i+1),r-1);
		ans+=n/i*(i-j);
		i=j;
	}
	return ans;
}
inline ele f(ele n){
	ele ans=0;
	for (int j=1; j*j<=n; ++j){
		ans+=g(n/j,j+1)*2;
		ans+=n/j/j;
	}
	return ans;
}
int main(){
	freopen("function.in","r",stdin); freopen("function.out","w",stdout);
	memset(flag,0,sizeof(flag));
	pcnt=0; mu[1]=1;
	for (int i=2; i<maxn; ++i){
		if (!flag[i]) plst[pcnt++]=i,mu[i]=-1;
		for (int j=0; j<pcnt && i*plst[j]<maxn; ++j){
			flag[i*plst[j]]=true;
			if (i%plst[j]) mu[i*plst[j]]=-mu[i];
			else{
				mu[i*plst[j]]=0;
				break;
			}
		}
	}
	ele T;
	scanf("%lld",&T);
	while (T--){
		ele n;
		scanf("%lld",&n);
		ele ans=0;
		for (int i=1; i*i<=n; ++i) ans+=mu[i]*f(n/i/i);
		printf("%lld\n",ans);
	}
	return 0;
}