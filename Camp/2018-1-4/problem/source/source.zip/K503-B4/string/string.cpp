#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const int maxn=505;
const int mod=998244353;
int n,m,ai[7][maxn],ans,len[7],bit[25],fail[7][maxn];
int bi[maxn],next[7][maxn][2],fail1[maxn],fail2[maxn];
int ci1[maxn],next1[maxn][2],next2[maxn][2],ci2[maxn];
int tmp1[maxn],tmp2[maxn];
ll dp[maxn][105][105][2],Ans;
char str[maxn];
bool can[maxn][maxn];
inline void add(ll &x,ll b)
{
	if((x+=b)>=mod)
		x-=mod;
}
inline bool check(int s)
{
	for(int i=1;i<=m;i++)
	{
		if(s&bit[i])
		{
			bi[i]=1;
			bi[m*2-i+1]=0;
		}
		else
		{
			bi[i]=0;
			bi[m*2-i+1]=1;
		}
	}
	for(int i=1;i<=n;i++)
	{
		int k=0,t=0;
		for(int v=1;v<=m*2;v++)
		{
			if(ai[i][t+1]==bi[v])
				t++;
			else
				t=next[i][t][bi[v]];
			if(t==len[i])
			{
				k=1;
				break;
			}
		}
		if(k)
			return false;
	}
	return true;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",str+1);
		len[i]=strlen(str+1);
		for(int v=1;v<=len[i];v++)
			if(str[v]=='0')
				ai[i][v]=0;
			else
				ai[i][v]=1;
	}
	for(int i=1;i<=n;i++)
	{
		for(int v=1,t=0;v<=len[i];v++)
		{
			if(!t||ai[i][t]==ai[i][v])
				fail[i][v]=t++;
			else
			{
				t--;
				while(t&&ai[i][t+1]!=ai[i][v])
					t=fail[i][t];
				if(ai[i][t+1]==ai[i][v])
					fail[i][v]=t+1;
				else
					fail[i][v]=0;
			}
		}
		for(int v=0;v<len[i];v++)
		{
			for(int e=0;e<=1;e++)
				if(ai[i][v+1]==e)
					next[i][v][e]=v+1;
				else
					next[i][v][e]=next[i][fail[i][v]][e];
		}
	}
	if(m<=15)
	{
		bit[1]=1;
		for(int i=2;i<=m;i++)
			bit[i]=bit[i-1]<<1;
		for(int s=0;s<(1<<m);s++)
			if(check(s))
				++ans;
		printf("%d\n",ans);
	}
	else if(n==1)
	{
		int le=len[1];
		for(int i=1;i<=le;i++)
		{
			ci1[i]=ai[1][i];
			ci2[le-i+1]=ai[1][i];
		}
		int t;
		for(int v=1,t=0;v<=le;v++)
		{
			if(!t||ci1[t]==ci1[v])
				fail1[v]=t++;
			else
			{
				t--;
				while(t&&ci1[t+1]!=ci1[v])
					t=fail1[t];
				if(ci1[t+1]==ci1[v])
					fail1[v]=t+1;
				else
					fail1[v]=0;
			}
		}
		for(int v=1,t=0;v<=le;v++)
		{
			if(!t||ci2[t]==ci2[v])
				fail2[v]=t++;
			else
			{
				t--;
				while(t&&ci2[t+1]!=ci2[v])
					t=fail1[t];
				if(ci2[t+1]==ci2[v])
					fail2[v]=t+1;
				else
					fail2[v]=0;
			}
		}
		for(int v=0;v<le;v++)
		{
			for(int e=0;e<=1;e++)
				if(ci1[v+1]==e)
					next1[v][e]=v+1;
				else
					next1[v][e]=next1[fail1[v]][e];
		}
		for(short i=1,t1,t2,k1,k2,e1,e2,e;i<le;i++)
			for(e=1;e<le;e++)
			{
				t1=0;
				t2=0;
				k1=i;
				k2=e;
				while(k1)
				{
					tmp1[++t1]=k1;
					k1=fail1[k1];
				}
				while(k2)
				{
					tmp2[++t2]=k2;
					k2=fail2[k2];
				}
				for(e1=0;e1<=t1;e1++)
					for(e2=0;e2<=t2;e2++)
						if(tmp1[e1]+tmp2[e2]==le)
						{
							can[i][e]=true;
							break;
						}
			}
		next1[le][0]=next1[fail1[le]][0];
		next1[le][1]=next1[fail1[le]][1];
		for(int v=0;v<le;v++)
		{
			for(int e=0;e<=1;e++)
				if(ci2[v+1]==e)
					next2[v][e]=v+1;
				else
					next2[v][e]=next2[fail2[v]][e];
		}
		next2[le][0]=next1[fail2[le]][0];
		next2[le][1]=next1[fail2[le]][1];
		dp[0][0][0][0]=1;
		for(short i=0,v,e,z;i<m;i++)
			for(v=0;v<=le;v++)
				for(e=0;e<=le;e++)
					for(z=0;z<=1;z++)
					{
						add(dp[i+1][next1[v][z]][next2[e][!z]][1],dp[i][v][e][1]);
						if(next1[v][z]==le||next2[e][!z]==le)
							add(dp[i+1][next1[v][z]][next2[e][!z]][1],dp[i][v][e][0]);
						else
							add(dp[i+1][next1[v][z]][next2[e][!z]][0],dp[i][v][e][0]);
					}
		for(int i=0;i<=le;i++)
			for(int v=0;v<=le;v++)
				add(Ans,dp[m][i][v][1]);
		for(int i=0;i<le;i++)
			for(int v=0;v<le;v++)
				if(can[i][v])
				add(Ans,dp[m][i][v][0]);
		std::cout<<Ans;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
