#include<bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;
const int maxn=1010;
const int base=23;
const int inf=0x3f3f3f;
int n;
char s[maxn];
int dp[maxn][maxn];
ull a[maxn], b[maxn], Pow[maxn];
void chkmin(int& x,int y){ if(x>y) x=y; }

bool check(int x,int y,int xx,int yy){
	ull fr=(a[y]-a[x-1]*Pow[y-x+1])*Pow[yy-xx+1] + a[yy]-a[xx-1]*Pow[yy-xx+1];
	ull ed=(b[xx]-b[yy+1]*Pow[yy-xx+1])*Pow[y-x+1] + b[x]-b[y+1]*Pow[y-x+1];
	// printf("%llu %llu\n", fr, ed);
	return fr!=ed;
}
bool check1(int x,int y){
	ull fr=a[y]-a[x-1]*Pow[y-x+1]; ull ed=b[x]-b[y+1]*Pow[y-x+1];
	// printf("check1 = %llu %llu\n", fr, ed);
	return fr!=ed;
	return a[y]-a[x-1]*Pow[y-x+1] != b[x]-b[y+1]*Pow[y-x+1];
}

void solve(){
	int flag=1;
	for(int i=1;i<=n;i++) if(s[i]!=s[n-i+1]){ puts("1"); return; }
	for(int i=1;i<=n-2;i++) if(s[i]!=s[i+2]){ flag=0; break; }
	if(flag){ puts("-1"); return; }
	puts("2");
}

int main(){
	freopen("string.in","r",stdin),freopen("string.out","w",stdout);

	Pow[0]=1;
	for(int i=1;i<maxn;i++) Pow[i]=Pow[i-1]*base;
	/*
	scanf("%s", s+1); n=strlen(s+1);
	for(int i=1;i<=n;i++) a[i]=a[i-1]*base+s[i]-'a'+1;
	for(int i=n;i>=1;i--) b[i]=b[i+1]*base+s[i]-'a'+1;
	printf("check1 = %d\n", check1(2,3));
	printf("%d\n", check(1,2,3,3));
	return 0;
	*/
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%d%s",&n,s+1);
		if(n>50 | 1){ solve(); continue; }
		memset(dp,0x3f,sizeof(dp));
		for(int i=1;i<=n;i++) a[i]=a[i-1]*base+s[i]-'a';
		for(int i=n;i>=1;i--) b[i]=b[i+1]*base+s[i]-'a';
		int flag=0;
		for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++) if(check1(i, j)) dp[i][j]=1, flag=1;
		if(!flag){ puts("-1"); continue; }
		for(int len=3;len<=n;len++) for(int i=1;i+len-1<=n;i++){
				int j=i+len-1;
				for(int ii=i+1;ii<j;ii++) for(int jj=ii;jj+1<=j;jj++){
					if(check(i,ii-1,jj+1,j)) chkmin(dp[i][j], dp[ii][jj]+1);
				}
			}
		printf("%d\n", dp[1][n]<inf?dp[1][n]:-1);
	}
	return 0;
}
