#include <bits/stdc++.h>
using namespace std ;
const int maxn = 1e6+5 ;
int s[maxn], t[maxn], n, m ;
int main() {
	freopen ( "drink.in", "r", stdin ) ;
	freopen ( "drink.out", "w", stdout ) ;

	int i, j, l, r ;
	scanf ( "%d", &n ) ;
	double ans, tot = 0.0 ;
	for ( i = 1 ; i <= n ; i ++ )
		scanf ( "%d", s+i ) ;
	for ( i = 1 ; i <= n ; i ++ )
		for ( j = 1 ; j <= n ; j ++ ) {
			for ( l = i, r = 0 ; l <= j ; l ++ )
				t[++r] = s[l] ;
			sort(t+1, t+r+1) ;
			ans = 0.0 ;
			for ( l = 1 ; l <= r ; l ++ )
				ans = (t[l]+ans)/2.0 ;
			ans /= n*n ;
			tot += ans ;
		}
	printf ( "%.7lf\n", tot ) ;
	return 0 ;
}
