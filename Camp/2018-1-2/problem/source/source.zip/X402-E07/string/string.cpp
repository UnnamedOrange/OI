#include <bits/stdc++.h>
using namespace std;
const int maxn = 100000 +10;
char str[maxn];
bool chk(int l,int r){
	for(int i=l,j=r;i<j;i++,j--)
		if(str[i]!=str[j])return 0;
	return 1;
}
int main(){
	freopen("string.in","r",stdin),freopen("string.out","w",stdout);
	int T;scanf("%d",&T);
	for(int cas=1;cas<=T;cas++){
		int flag=0,m,m2;
		scanf("%d",&m);m2=m;
		scanf("%s",str+1);str[0]='*';
		if(!chk(1,m))printf("1\n");
		else{
			while(m){
				int tmp = (m+1)/2;
				if(!chk(1,tmp)){
					if(!chk(tmp+1,m2))printf("2\n"),flag=1;
				}
				else m/=2;
			}
			if(!flag)printf("-1\n");
		}
	}
	return 0;
}
