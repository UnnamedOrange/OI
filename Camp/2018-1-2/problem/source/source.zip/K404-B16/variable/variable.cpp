#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

int n, ans, W;
int w[20];
struct QQ{int r, x, y;} Q[25]; int q;
struct PP{int x, y, z, a, b, c, d, e, f;} P[25]; int p;

bool check() {
	int i;
	rep(i, 1, q)
		if(Q[i].r == 0 && w[Q[i].x] > w[Q[i].y]) return 0; else
		if(Q[i].r == 1 && w[Q[i].x] != w[Q[i].y]) return 0; else
		if(Q[i].r == 2 && w[Q[i].x] >= w[Q[i].y]) return 0;
	return 1;
}

int calc() {
	int i;
	int ans = 0;
	rep(i, 1, n) ans += w[i] ;
	rep(i, 1, p) {
		ans += abs(w[P[i].x] - w[P[i].y]) * P[i].a + abs(w[P[i].y] - w[P[i].z]) * P[i].b + abs(w[P[i].z] - w[P[i].x]) * P[i].c
			+ (w[P[i].x] - w[P[i].y]) * P[i].d + (w[P[i].y] - w[P[i].z]) * P[i].e + (w[P[i].z] - w[P[i].x]) * P[i].f;
	}
	return ans;
}

void dfs(int dep) {
	if(dep > n) {
		if(check()) ans = min(ans, calc());
		return;
	}
	w[dep] = W;
	dfs(dep+1);
	w[dep] = -W;
	dfs(dep+1);
}

int main() {
	freopen("variable.in", "r", stdin); freopen("variable.out", "w", stdout);
	int T, i;
	scanf("%d", &T);
	while(T--) {
		scanf("%d %d %d %d", &n, &W, &p, &q);
		ans = 0x3f3f3f3f;
		rep(i, 1, p) scanf("%d %d %d %d %d %d %d %d %d", &P[i].x, &P[i].y, &P[i].z, &P[i].a, &P[i].b, &P[i].c, &P[i].d, &P[i].e, &P[i].f);
		rep(i, 1, q) scanf("%d %d %d", &Q[i].x, &Q[i].y, &Q[i].r);
		dfs(1);
		printf("%d\n", ans);
	}
	return 0;
}
