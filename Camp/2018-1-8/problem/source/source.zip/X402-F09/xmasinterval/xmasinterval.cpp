#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=500005;
int l[N],r[N],x[N],an[25],ans,n,m;
void dfs(int y,int z){
	if (y==n+1){
		if (z==an[0]) ++ans;
		return;
	}
	dfs(y+1,z); dfs(y+1,z|an[y]);
}
int main(){
	freopen("xmasinterval.in","r",stdin); freopen("xmasinterval.out","w",stdout);
	n=read(),m=read();
	For(i,1,n) l[i]=read(),r[i]=read();
	For(i,1,m) x[i]=read();
	sort(x+1,x+1+m);
	if (n<=20&&m<=20){
		an[0]=(1<<m)-1;
		For(i,1,n)
			For(j,1,m) if (x[j]>=l[i]&&x[j]<=r[i]) an[i]^=(1<<j-1);
		dfs(1,0); printf("%d\n",ans);
	}
	return 0;
}
/*
4 3
3 8
1 6
3 8
2 7
8 2 7
*/
