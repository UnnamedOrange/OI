#include <iostream>
#include <cstdio>
#include <cstring>
#define mod 1000000007
using namespace std;
typedef long long ll;
ll s,t,n,m,f[1000005],inv[1000005];
ll C(ll n,ll m){
	if(n<m) return 0;
	return f[n]*inv[m]%mod*inv[n-m]%mod;
}
ll quick_pow(ll a,ll b){
	ll ans=1;a%=mod;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1) ans=ans*a%mod;
	return ans;
}
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
	f[0]=inv[0]=1;
	for(int i=1;i<=1000002;i++) f[i]=f[i-1]*i%mod,inv[i]=quick_pow(f[i],mod-2);
	ll ans=0;
	for(int i=0,j=1;i<=n;i++,j=-j){
		ans=(ans+C(n,i)*C(s-t*i,m)*j)%mod;
	}
	ans=(ans+mod)%mod;
	printf("%lld",ans);
	return 0;
}
