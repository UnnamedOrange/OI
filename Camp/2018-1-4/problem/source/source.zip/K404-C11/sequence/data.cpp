#include <bits/stdc++.h>
#include <windows.h>

int a[27];

int main() {
    char *t = new char;
    srand((long long)t * GetTickCount() ^ time(0));
    delete t;
    register int T = 2;
    std::cout << T << '\n';
    while (T--) {
        register int n = rand() % 11 + 1;
        std::cout << n << '\n';
        for (register int i = 1; i <= n; i++) a[i] = i;
        std::random_shuffle(a + 1, a + n + 1);
        for (register int i = 1; i <= n; i++) std::cout << a[i] << ' ';
        std::cout << std::endl;
    }
}