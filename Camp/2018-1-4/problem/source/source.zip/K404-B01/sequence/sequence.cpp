#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <sstream>
#include <cctype>
#include <cmath>
#include <algorithm>
#define THE_BRST_PONY "Rainbow Dash"

using namespace std;
const int N=30;

int T,n,ans;
int x[N],p[N];

void SeqRev(int pos) {
	ans++;
	for(int i=1,j=pos;i<j;i++,j--) {
		swap(p[x[i]],p[x[j]]);
		swap(x[i],x[j]);
	}
	return;
}

int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&T);
	while(T--) {
		ans=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++) {
			scanf("%d",&x[i]);
			p[x[i]]=i;
		}
		for(int i=n;i;i--) {
			if(p[i]==i) continue;
			if(p[i]!=1) SeqRev(p[i]);
			SeqRev(i);
		}
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

