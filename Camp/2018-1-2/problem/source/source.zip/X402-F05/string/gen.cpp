#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

int randint(int l, int r){
	return rand() % (r - l + 1) + l;
}

char S[20];

int main(){

	freopen("string.in", "w", stdout);

	int Case = 10000;
	printf("%d\n", Case);

	while(Case--){
		int n = randint(9, 12);
		printf("%d\n", n);

		int m = randint(1, 3);
		For(i, 1, n / 2 + 1) S[i] = S[n + 1 - i] = randint(0, m) + 'a';
		S[n + 1] = '\0';
		puts(S + 1);
	}

	return 0;
}
