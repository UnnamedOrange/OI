#include<bits/stdc++.h>
using namespace std;

const int MAXN = 5010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], to[MAXN<<1];
int nxt[MAXN<<1], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

int n, q, t, c[MAXN];
int d[MAXN], cnt, lans;
int L[MAXN], R[MAXN];
bool p[MAXN];

void dfs(int u, int fa) {
	d[++cnt] = u;
	L[u] = cnt;
	int i;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		dfs(v, u);
	}
	R[u] = cnt;
}

int main() {
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);

	int i;

	n = read(), q = read(), t = read();

	for(i = 1; i <= n; i++) c[i] = read();
	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		Add(u, v), Add(v, u);
	}

	dfs(1, 0);

	while(q--) {
		int op = read(), u, l, r, col;
		if(op == 1) {
			u = read(), l = read(), r = read();
			if(t) u ^= lans, l ^= lans, r ^= lans;
			for(i = 1; i <= n; i++) p[i] = false;
			for(i = L[u]; i <= R[u]; i++) {
				if(c[d[i]] < l || c[d[i]] > r) continue;
				p[c[d[i]]] = true;
			}
			lans = 0;
			for(i = 1; i <= n; i++) lans += p[i];
			printf("%d\n", lans);
		}
		else {
			u = read(), col = read();
			if(t) u ^= lans, col ^= lans;
			c[u] = col;
		}
	}
	return 0;
}
