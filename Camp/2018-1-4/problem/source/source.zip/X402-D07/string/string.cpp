#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=7,maxlen=110,maxm=510,mo=998244353;
int n,m,ans;
char s[maxlen];
int a[maxn<<1][maxlen],len[maxn<<1];
bool book[maxn<<1][maxlen];
void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}
namespace ACauto{
    int ch[maxn*2*maxlen][2],t[maxn*2*maxlen][2],cnt;
    int fail[maxn*2*maxlen],f[maxm][maxn*maxlen][1<<6];
    void debug(int u){
        puts("BEGIN:");
        printf("t[%d][0]=%d,t[%d][1]=%d\n",u,t[u][0],u,t[u][1]);
        printf("lson=%d,rson=%d\n",ch[u][0],ch[u][1]);
        puts("to:lson");
        if(ch[u][0]) debug(ch[u][0]);
        else puts("null");
        puts("to:rson");
        if(ch[u][1]) debug(ch[u][1]);
        else puts("null");
        puts("END.");
    }
    void insert(int u){
        int h=0;
        for(int i=1;i<=len[u];i++){
            if(!ch[h][a[u][i]]) ch[h][a[u][i]]=++cnt;
            h=ch[h][a[u][i]];
            if(book[u][i]) t[h][1]|=1<<((u>n?u-n:u)-1);
        }
        t[h][0]|=1<<((u>n?u-n:u)-1);
    }
    void getfail(){
        queue<int> q;
        for(int i=0;i<=1;i++) if(ch[0][i]) q.push(ch[0][i]);
        while(!q.empty()){
            int u=q.front(); q.pop();
            t[u][0]|=t[fail[u]][0];
            t[u][1]|=t[fail[u]][1];
            for(int i=0;i<=1;i++){
                if(ch[u][i]){
                    int v=fail[u];
                    while(v&&!ch[v][i]) v=fail[v];
                    fail[ch[u][i]]=ch[v][i];
                    q.push(ch[u][i]);
                }
                else ch[u][i]=ch[fail[u]][i];
            }
        }
    }
    void DP(){
        f[0][0][0]=1;
        for(int i=0;i<m;i++)
            for(int j=0;j<=cnt;j++)
                for(int k=0;k<(1<<n);k++){
                    int nk=k|t[ch[j][0]][0];
                    if(i+1==m) nk|=t[ch[j][0]][1];
                    Add(f[i+1][ch[j][0]][nk],f[i][j][k]);
                    nk=k|t[ch[j][1]][0];
                    if(i+1==m) nk|=t[ch[j][1]][1];
                    Add(f[i+1][ch[j][1]][nk],f[i][j][k]);
                }
    }
}
using namespace ACauto;
int main(){
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    read(n); read(m);
    for(int i=1;i<=n;i++){
        scanf("%s",s+1);
        len[i]=len[n+i]=strlen(s+1);
        for(int j=1;j<=len[i];j++){
            a[i][j]=(s[j]=='1');
            a[n+i][len[i]-j+1]=a[i][j]^1;
        }
        for(int j=len[i];j>(len[i]+1)/2;j--){
            bool flag=1;
            for(int L=j-1,R=j;R<=len[i];R++,L--) if(a[i][L]==a[i][R]){ flag=0; break; }
            if(flag) book[i][j-1]=1;
            flag=1;
            for(int L=j-1,R=j;R<=len[i];R++,L--) if(a[n+i][L]==a[n+i][R]){ flag=0; break; }
            if(flag) book[n+i][j-1]=1;
        }
        insert(i); insert(n+i);
    }
    getfail(); DP();
    for(int i=0;i<=cnt;i++) Add(ans,f[m][i][(1<<n)-1]);
    printf("%d\n",ans);
    return 0;
}
