#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n;
int head[15], to[15], nxt[15], cnt;
inline void addedge (int u, int v) { cnt++, to[cnt] = v, nxt[cnt] = head[u], head[u] = cnt; }
int w[15], r[15], p[15];
int f[15];
bool cs[15];
int ans;
inline void dfs (int u, int p) {
	f[u] = p;
	for (int e = head[u]; e; e = nxt[e]) {
		int v = to[e];
		if (v == p) continue;
		dfs (v, u);
	}
}
int main () {
	freopen ("xmastree2.in", "r", stdin);
	freopen ("xmastree2.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i < n; i++) {
		int u, v;
		scanf ("%d%d", &u, &v);
		addedge (u, v);
	}
	for (int i = 1; i <= n; i++) scanf ("%d%d", &w[i], &r[i]);
	for (int i = 1; i <= n; i++) p[i] = i;
	do {
		if (!r[p[1]]) continue;
		dfs (p[1], 0);
		memset (cs, 0, sizeof (cs));
		int rs = w[p[1]];
		cs[p[1]] = 1;
		for (int i = 2; i <= n; i++) {
			if (!cs[f[p[i]]]) { rs = 0; break; }
			rs += i * w[p[i]];
			cs[p[i]] = true;
		}
		ans = max (ans, rs);
	} while (next_permutation (p + 1, p + n + 1));
	printf ("%d\n", ans);
	return 0;
}
