#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
#define rep(i,l,r) for(int i=l;i<=r;++i)
const int N=1e5+5,D=998244353;
ll mi(ll x,int y)
{
	ll ans=1;
	while(y)
	{
		if(y&1)ans=ans*x%D;
		x=x*x%D;y>>=1;
	}
	return ans;
}
int n,m,k;
ll jie[N];

int main()
{
	freopen("tournament.in","r",stdin);freopen("tournament.out","w",stdout);
	int n,k;
	cin>>n>>k;
	jie[0]=1;rep(i,1,n)jie[i]=jie[i-1]*i%D;
	if(k==3)
	{
		cout<<(((mi(2,(ll)n*(n-1)/2%(D-1))-jie[n])%D)+D)%D;
		exit(0);
	}
 	ll ans=jie[n-1]*mi(2,n*(n-1)/2-n);
	cout<<(ans%D+D)%D;	
}
