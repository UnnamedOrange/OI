#include<bits/stdc++.h>
using namespace std;
string a[10];
int n,m;
char s[233];
void sol1(){
	
}
void sol2(){
	int ans=0;
	for(int i=0;i<(1<<m);i++){
		int num=i;
		for(int z=1;z<=m;z++){
			if(num&1){
				s[z]='1';
				s[2*m-z+1]='0';
			}else{
				s[z]='0';
				s[2*m-z+1]='1';
			}	
			num=num>>1;
		}
		bool alg=true;
		for(int j=0;j<n;j++){
			bool g;
			for(int k=1;k<=2*m-a[j].size();k++){
				g=true;
				for(int l=0;l<a[j].size();l++){
					if(s[l+k]!=a[j][l]){
						g=false;
						break;
					}
				}
				if(g)
					break;
			}
			if(!g){
				alg=false;
				break;
			}
		}
		if(alg)
			ans++;
	}
	cout<<ans<<endl;
	return;
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin>>n>>m;
	for(int i=0;i<n;i++)
		cin>>a[i];
	if(n==1)
		sol1();
	else
		sol2();
	return 0;
}
