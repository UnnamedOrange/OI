#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	#endif
}
static int n;
const int mod=1e9+7;
#define Chkmax(a,b) a=a>b?a:b
#define Chkmin(a,b) a=a<b?a:b
inline void plu(int &a,int b){a+=b;if(a>mod)a-=mod;}
namespace subtask1//30pt
{
    int main()
    {
        const int MAXN=2017;
        static int dp[MAXN][2]={0},mi[MAXN],ma[MAXN];
        Rep(i,1,n)read(mi[i]),read(ma[i]);
        dp[0][1]=1;
        static int qma,qmi;
        Rep(i,0,n-1)
        {
            qma=ma[i+1];qmi=mi[i+1];
            Rep(j,i+1,n)
            {
                Chkmin(qma,ma[j]);Chkmax(qmi,mi[j]);
                if(qma<j-i||qmi>n-i||qmi>qma)break;
                if(qmi>j-i)continue;
                if(dp[j][0]<dp[i][0]+1)dp[j][0]=dp[i][0]+1,dp[j][1]=dp[i][1];
                else if(dp[j][0]==dp[i][0]+1)plu(dp[j][1],dp[i][1]);
            }
        }
        if(!dp[n][0])printf("-1\n");
        else printf("%d %d\n",dp[n][0],dp[n][1]);
        return 0;
    }
}
namespace subtask2
{
    const int MAXN=1e6+7;
    static int ma[MAXN],mi[MAXN],aa[MAXN<<2],ii[MAXN<<2],dp[MAXN][2];
    void make_tree(int h,int l,int r)
    {
        if(l==r){aa[h]=ma[l],ii[h]=mi[l];return;}
        int mid=(l+r)>>1;
        make_tree(h<<1,l,mid);
        make_tree(h<<1|1,mid+1,r);
    }
    static int gas,gis;
    void queryma(int h,int l,int r,int x,int y)
    {
        if(aa[h]>=gas)return;
        if(l>=x&&r<=y){Chkmin(gas,aa[h]);return;}
        int mid=(l+r)>>1;
        if(x<=mid)queryma(h<<1,l,mid,x,y);
        if(y>mid)queryma(h<<1|1,mid+1,r,x,y);
    }
    void querymi(int h,int l,int r,int x,int y)
    {
        if(ii[h]<=gis)return;
        if(l>=x&&r<=y){Chkmax(gis,ii[h]);return;}
        int mid=(l+r)>>1;
        if(x<=mid)querymi(h<<1,l,mid,x,y);
        if(y>mid)querymi(h<<1|1,mid+1,r,x,y);
    }
    int main()
    {
        Rep(i,1,n)read(mi[i]),read(ma[i]);
        make_tree(1,1,n);
        static int qma,qmi,lasl,lasr,lll,nowl,nowr;
        dp[0][1]=1;
        lasl=n+1,lasr=n+1;
        Rep(i,0,n-1)
        {
            qma=ma[i+1];qmi=mi[i+1];
            nowl=n;nowr=0;
            if(i&&dp[i][0]!=dp[i-1][0])lasl=n+1,lasr=n+1;
            lll=i+1;
            Rep(j,i+1,lasl-1)
            {
                lll=j;
                Chkmin(qma,ma[j]);Chkmax(qmi,mi[j]);
                if(qma<j-i||qmi>n-i||qmi>qma)break;
                if(qmi>j-i)
                {
                    gas=n;gis=0;
                    queryma(1,1,n,j+1,qmi+i-1);
                    querymi(1,1,n,j+1,qmi+i-1);
                    j=qmi+i;
                    Chkmax(qmi,gis);Chkmax(qma,gas);
                    continue;
                }
                Chkmin(nowl,j);Chkmax(nowr,j);
                if(dp[j][0]<dp[i][0]+1)dp[j][0]=dp[i][0]+1,dp[j][1]=dp[i][1];
                else if(dp[j][0]==dp[i][0]+1)plu(dp[j][1],dp[i][1]);
            }
            if(lasl>n){lasl=nowl;lasr=nowr;continue;}
            if(lll+1<=lasr)
            {
                gas=n;gis=0;
                queryma(1,1,n,lll+1,lasr);
                querymi(1,1,n,lll+1,lasr);
                Chkmax(qmi,gis);Chkmin(qma,gas);
            }
            Rep(j,lasr,n)
            {
                Chkmin(qma,ma[j]);Chkmax(qmi,mi[j]);
                if(qma<j-i||qmi>n-i||qmi>qma)break;
                if(qmi>j-i)
                {
                    gas=n;gis=0;
                    queryma(1,1,n,j+1,qmi+i-1);
                    querymi(1,1,n,j+1,qmi+i-1);
                    j=qmi+i;
                    Chkmax(qmi,gis);Chkmax(qma,gas);
                    continue;
                }
                Chkmin(nowl,j);Chkmax(nowr,j);
                if(dp[j][0]<dp[i][0]+1)dp[j][0]=dp[i][0]+1,dp[j][1]=dp[i][1];
                else if(dp[j][0]==dp[i][0]+1)plu(dp[j][1],dp[i][1]);
            }
            lasl=nowl;lasr=nowr;
        }
        if(!dp[n][0])printf("-1\n");
        else printf("%d %d\n",dp[n][0],dp[n][1]);
        return 0;
    }
}
int main(void){
	file();
	read(n);
    if(n<=2000)return subtask1::main();
    else return subtask2::main();
    return 0;
}

