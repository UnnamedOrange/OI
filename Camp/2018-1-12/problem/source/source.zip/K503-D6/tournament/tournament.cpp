#include <cctype>
#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)

using namespace std;
const int p=998244353,N=1e5+10;
int n,m,fac[N],ifac[N];

int power(int a,int b)
{
    int t=1;
    for (; b>0; b>>=1,a=1ll*a*a%p)
        b&1? t=1ll*t*a%p:0;
    return t;
}

int c(int n,int m)
{
    return 1ll*fac[n]*ifac[m]%p*ifac[n-m]%p;
}

int main()
{
//    freopen("tournament.in","r",stdin);
//    freopen("tournament.out","w",stdout);
    scanf("%d%d",&n,&m);
    fac[0]=1;
    rep(i,1,n)
        fac[i]=1ll*fac[i-1]*i%p;
    ifac[n]=power(fac[n],p-2);
    repd(i,n,1)
        ifac[i-1]=1ll*ifac[i]*i%p;
    if (m==3)
    {
        printf("%d",(power(2,c(n,2))+p-fac[n])%p);
        return 0;
    }
    return 0;
}
