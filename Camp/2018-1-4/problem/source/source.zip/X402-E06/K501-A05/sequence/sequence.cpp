#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int maxn = int(25);

int n;

int a[maxn + 5];

inline void input()
{
	n = read<int>();
	REP(i, 0, n) a[i] = read<int>();
}

inline int E()
{
	int sum = 0;
	REP(i, 1, n) if(abs(a[i] - a[i - 1]) > 1) ++sum;
	return sum;
}

inline bool check()
{
	REP(i, 1, n) if(a[i] < a[i - 1]) return 0;
	return 1;
}

inline bool dfs(int x, int depth)
{
	if(x > depth) return 0;
	if(check()) return 1;
	if(x + E() > depth) return 0;

	for(int i = 1; i <= n; ++i)
	{
		reverse(a, a + i);
		if(dfs(x + 1, depth)) return 1;
		reverse(a, a + i);
	}

	return 0;
}

inline void solve()
{
	int lim = 0;
	while(!dfs(0, lim)) ++lim;
	printf("%d\n", lim);
}

int main()
{
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);

	int T = read<int>();
	while(T--)
	{
		input();
		solve();
	}

	return 0;
}

