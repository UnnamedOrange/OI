#include<cstdio>
#include<algorithm>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
using namespace std;
const int maxn = 25;
int n, m, k;
int a[maxn], b[maxn], c[maxn], mn = 0x3f3f3f3f;
bool inSeq(int len, int step, int * a) {
	int pos = 1;
	for(register int i = 1; i <= step; ++i) {
		while(a[pos] != c[i]) {
			++pos;
			if(pos > len) return false;
		}
		++pos;
	}
	return true;
}
void dfs(int step) {
	if(step > mn) return;
	if(!inSeq(n, step, a) && !inSeq(m, step, b))
		mn = min(mn, step);
	for(register int i = 1; i <= k; ++i)
		c[step + 1] = i, dfs(step + 1);
}
int main() {
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	mn = max(n, m) + 1;
	For(i, 1, n) scanf("%d", &a[i]);
	For(i, 1, m) scanf("%d", &b[i]);
	dfs(0);
	printf("%d", mn);
	return 0;
}
