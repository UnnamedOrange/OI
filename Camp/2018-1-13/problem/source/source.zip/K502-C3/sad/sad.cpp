#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<cstring>
#define reseed srand((unsigned long long)(new char))
#define random rand()%1000
#define NN 100000+10
using namespace std;
int cnt=0;
double ex[11]={0}; 
int rand_int(){
	++cnt;
	if(cnt==3071){
		cnt=0;
		reseed;
	}
	return random*1000000+random*1000+random;
}
char get_c(){
	char c=getchar();
	while(c!='1'&&c!='0'){
		c=getchar();
	}
	return c;
}
vector<int>p[NN];
bool fl[NN]={0};
bool col[NN]={0};
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	int Ti=40000000;
	int n;
	scanf("%d",&n);
	int p1,p2;
	for(int i=1;i<=n;++i){
		col[i]=get_c()-'0';
	}
	for(int i=1;i<n;++i){
		scanf("%d%d",&p1,&p2);
		p[p1].push_back(p2);
		p[p2].push_back(p1);
	}
	double ans=0;
	register int cnt=0,now=1;
	Ti/=n;
	Ti/=n;
	for(register int i=1;i<=Ti;++i){
		memset(fl,0,n+10);
		cnt=0;
		now=1;
		while(true){
			if(col[now]||!fl[now]){
				fl[now]=1;
				++cnt;
			}
			ex[now]+=cnt;
			if(p[now].size()==1)break;
			now=p[now][rand_int()%p[now].size()]; 
		}
		ans+=cnt;
	}
	printf("%d\n",int(ans/Ti));
/*	for(int i=1;i<=n;++i){
		printf("%d: %.10lf\n",i,ex[i]/Ti);
	}*/
}
	
