#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
const long long Mod=1e9+7;
int n,a,b,w[100010],s0,s1;
long long fac[100010],inv[100010],ans;
long long pw(long long x,long long y)
{
	long long res=1;
	while (y)
	{
		if (y&1)
		{
			res=res*x%Mod;
		}
		y>>=1;
		x=x*x%Mod;
	}
	return res;
}
void solve1()
{
	fac[0]=1;
	for (int i=1;i<=n;i++)
	{
		fac[i]=fac[i-1]*i%Mod;
	}
	inv[n]=pw(fac[n],Mod-2);
	for (int i=n-1;i>=0;i--)
	{
		inv[i]=inv[i+1]*(i+1)%Mod;
	}
	for (int i=1;i<=n;i++)
	{
		if ((w[i]/a)&1)
		{
			s1++;
		}
		else
		{
			s0++;
		}
	}
	long long p=pw(2,s0);
	long long q[2];
	q[0]=q[1]=0;
	for (int i=0;i<=s1;i++)
	{
		q[i&1]=(q[i&1]+fac[s1]*inv[s1-i]%Mod*inv[i]%Mod)%Mod;
	}
	printf("0 0 %lld %lld\n",p*q[1]%Mod,p*q[0]%Mod);
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&w[i]);
	}
	if (a==b)
	{
		solve1();
	}
	return 0;
}
