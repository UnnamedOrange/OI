#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for(int i = j; i <= k; i++)
#define Forr(i, j, k) for(int i = j; i >= k; i--)

int Read(){
	char c = getchar();
	while(c > '9' || c < '0') c = getchar();
	int x = c - '0'; c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

using namespace std;

const int N = 1e5 + 10;

int Begin[N], Next[N << 1], to[N << 1], e;

void add(int u, int v){
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int fa[N][18], n, q, type, col[N];
int idl[N], idr[N];

void DFS_init(int o){
	static int dfs_clock = 0;
	idl[o] = ++dfs_clock;

	for(int i = Begin[o]; i; i = Next[i]){
		int u = to[i];
		if(u == fa[o][0]) continue;
		
		fa[u][0] = o;
		For(j, 1, 17) fa[u][j] = fa[fa[u][j - 1]][j - 1];

		DFS_init(u);
	}

	idr[o] = dfs_clock;
}

int vis[N], oc[N];

int main(){

	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.ans", "w", stdout);

	n = Read(), q = Read(), type = Read();
	For(i, 1, n) oc[i] = Read();
	For(i, 2, n){
		int u = Read(), v = Read();
		add(u, v), add(v, u);
	}
	DFS_init(1);
	For(i, 1, n) col[idl[i]] = oc[i];

	int lstans = 0;

	while(q--){
		int ty = Read(), u = Read();

		if(ty == 1){
			int l = Read(), r = Read();
			if(type) u ^= lstans, l ^= lstans, r ^= lstans;

			lstans = 0;
			For(i, idl[u], idr[u]) if(!vis[col[i]] && col[i] >= l && col[i] <= r) 
				vis[col[i]] = 1, ++lstans;
			For(i, idl[u], idr[u]) vis[col[i]] = 0;
			printf("%d\n", lstans);
		}
		else{
			int c = Read();
			if(type) u ^= lstans, c ^= lstans;
			col[idl[u]] = c;
		}
	}

	return 0;
}
