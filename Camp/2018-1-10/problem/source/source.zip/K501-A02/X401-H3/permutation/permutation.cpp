#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mod=998244353;
ll read(){
    ll f=1,ret=0;
    char ch=getchar();
    while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
    while(ch<='9'&&ch>='0'){ret=ret*10+ch-'0';ch=getchar();}
    return f*ret;
}

ll p[100005],n,vst[15],ans;
bool ok[15];
bool calc(){
	memset(ok,0,sizeof(ok));
	for(int i=1;i<=n;i++){
		if(!ok[i]){
			ok[i]=1;
			int cnt=1,x=p[i];
			while(x!=i)ok[x]=1,cnt++,x=p[x];
			if(cnt&1)return false;
		}
	}
	return true;
}

void dfs(int dep){
	if(dep==n+1){if(calc())ans++;return;}
	if(p[dep])dfs(dep+1);
	for(int i=1;i<=n;i++){
		if(!vst[i]){
			p[dep]=i;
			vst[i]=1;
			dfs(dep+1);
			vst[i]=0;
			p[dep]=0;
		}
	}
}

int main(){
	n=read();
	for(int i=1;i<=n;i++)p[i]=read(),vst[p[i]]=1;
	if(n&1){cout<<0;return 0;}
	if(n<=10)dfs(1);
	else {
		int flag=1;
		for(int i=1;i<=n;i++)if(p[i]!=0)flag=0;
		if(flag){
			ans=1;
			for(int i=1;i<=n/2;i++)ans=(ans*(2*i-1))%mod;
			ans=(ans*ans)%mod;
		}
	}
	cout<<ans;
	return 0;
}

