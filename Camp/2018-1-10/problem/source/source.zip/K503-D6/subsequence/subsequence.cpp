#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)
#define repd(i,x,y) for (int i=x; i>=(y); --i)

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;
}

int rand(int x)
{
    return rand()%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

using namespace std;

const int N=4010;
int n,m,k,a[N],b[N],f[N],g[N],h[N];

int main()
{
    srand((unsigned long long)new char);
    freopen("subsequence.in","r",stdin);
    freopen("subsequence.out","w",stdout);
    n=get(),m=get(),k=get();
    rep(i,1,n)
    {
        int x=get(),mn=N;
        rep(i,1,k)
            mn=min(mn,f[i]);
        f[x]=h[x]=mn+1;
    }
    rep(i,1,m)
    {
        int x=get(),mn=N;
        rep(i,1,k)
            mn=min(mn,g[i]);
        g[x]=mn+1;
        mn=N;
        rep(i,1,k)
            mn=min(mn,h[i]);
        h[x]=mn+1;
    }
    int l=N,r=N;
    rep(i,1,k)
        l=min(l,max(f[i],g[i])),r=min(r,h[i]);
    printf("%d",rand(l,r)+1);
    return 0;
}
