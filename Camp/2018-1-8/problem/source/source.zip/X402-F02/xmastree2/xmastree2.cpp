#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=3e4+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("xmastree2.in","r",stdin);
		freopen("xmastree2.out","w",stdout);
	#endif
}
struct edge
{
	int v,nex;
}e[N<<1];
int n;
int head[N],tt;
int w[N],r[N];
int size[N];
void add(int x,int y)
{
	++tt;e[tt].v=y;e[tt].nex=head[x];head[x]=tt;
}
	void input()
{
	int x,y;
	n=read<int>();
	For(i,1,n-1)
	{
		x=read<int>();y=read<int>();
		add(x,y);add(y,x);
	}
	For(i,1,n)
	{
		w[i]=read<int>();r[i]=read<int>();
	}
}
int fa[N];
void dfs(int u,int pre)
{
	int v;
	size[u]=1;fa[u]=pre;
	for(register int i=head[u];i;i=e[i].nex)
	{
		v=e[i].v;
		if(v^pre)
		{
			dfs(v,u);
			size[u]+=size[v];
		}
	}
}
int ans,p[N],res,las,l[N],top;
int lef[N],rig[N];
int cal()
{
	int res=0;
	For(i,1,n)
	{
		res+=w[lef[i]]*i;
		//printf("%d %d\n",lef[i],rig[i]);
	}
	//puts("");
	return res;
}
bool cmp(int x,int y){return w[x]>w[y];}
void work()
{
	For(i,1,n)p[i]=i;
	sort(p+1,p+n+1,cmp);
	//puts("");
	For(i,1,n)
	{
		if(r[i])
		{
			memset(fa,0,sizeof fa);
			memset(lef,0,sizeof lef);
			memset(rig,0,sizeof rig);
			dfs(i,0);res=0;las=n;
			For(j,1,n)
			{
				static int now;
				now=p[j];top=0;
				if(!lef[now])
				{while(now)
				{
					l[++top]=now;
					now=fa[now];
					if(lef[now])break;
				}}
				if(lef[now])
				{
					Fordown(i,top,1)
					{
						rig[l[i]]=rig[now];
						lef[l[i]]=rig[now]-size[l[i]]+1;
						rig[fa[l[i]]]=lef[l[i]]-1;
					}
				}
				else
				{
					lef[p[j]]=las-size[p[j]]+1;
					rig[p[j]]=las;
					las=lef[p[j]]-1;
					now=fa[p[j]];int pre=p[j];
					while(!lef[now])
					{
						lef[now]=lef[pre];
						pre=now;
						now=fa[now];
					}
				}
			}
			cmax(ans,cal());
		}
	}
	printf("%d\n",ans);
}
int main()
{
	file();
	input();
	work();
	return 0;
}
