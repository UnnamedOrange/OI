#include <bits/stdc++.h>
#define MOD 998244353
#define getchar() *(pp++)
using namespace std;
char buf[10000100],*pp=buf;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int n,k,cnt,fac[1000000];
bool b[10][10],vis[10];
bool dfs(int x,int beg,int u)
{
	if((u==beg)&&(x==k))
	{
		return 1;
	}
	if(vis[u]||(x==k))
	{
		return 0;
	}
	vis[u]=1;
	for(int i=1;i<=n;i++)
	{
		if(b[u][i]&&dfs(x+1,beg,i))
		{
			vis[u]=0;
			return 1;
		}
	}
	vis[u]=0;
	return 0;
}
bool judge(int x)
{
	memset(b,0,sizeof(b)); 
	for(int i=1,k=0;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++,k++)
		{
			b[i][j]=((x>>k)&1);
			b[j][i]=!b[i][j];
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(dfs(0,i,i))
		{
//			cout<<x<<endl;
//			for(int i=1;i<=n;i++)
//			{
//				for(int j=1;j<=n;j++)
//				{
//					cout<<b[i][j]<<' ';
//				}
//				cout<<endl;
//			}
			return 1;
		}
	}
	return 0;
}
inline int qpow(int x,long long y)
{
	int ans=1,temp=x;
	while(y)
	{
		if(y&1)
		{
			ans=1LL*ans*temp%MOD;
		}
		temp=1LL*temp*temp%MOD;
		y>>=1;
	}	
	return ans;
} 
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	fread(buf,sizeof(char),sizeof(buf),stdin);	
	n=read();
	k=read();
	if(n<=6)
	{
		for(int i=0;i<(1<<(n*(n-1)/2));i++)
		{
			cnt+=judge(i);
		}
		cout<<cnt<<endl; 
	}
	else
	{
		fac[0]=1;
		for(int i=1;i<=n;i++)
		{
			fac[i]=1LL*fac[i-1]*i%MOD;
		}
		if(k==3)
		{
			cout<<(MOD+qpow(2,1LL*n*(n-1)/2)-fac[n])%MOD<<endl;
		}
	}
	return 0;
}
/*

*/
