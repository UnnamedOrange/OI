#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;
#define llz cerr << "老恶心" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 1000010;

int n, m;

int Begin[maxn], to[maxn], e, Next[maxn], val[maxn], st[maxn], top, pre[maxn], low[maxn];

int dfs_clock, cnt, circle[maxn], be[maxn], ne[maxn], E, t[maxn];

vector<int> cir[maxn];

void add(int x,int y){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get(){
	n = read(), m = read();
	For(i, 1, m){
		int x = read(), y = read();
		add(x, y);
	}
}

void dfs(int h){
	pre[h] = low[h] = ++ dfs_clock;
	st[++top] = h;

	for(int i = Begin[h];i ;i = Next[i]){
		int v = to[i];
		if(!pre[v]){
			dfs(v);
			low[h] = min(low[h], low[v]);
		}
		else if(!circle[v]){
			low[h] = min(low[h], pre[v]);
		}
	}

	if(pre[h] == low[h]){
		++ cnt;

		while(1){
			int now = st[top --];

			cir[cnt].push_back(now);
			circle[now] = cnt;
			val[cnt] ++;

			if(now == h) break;
		}
	}
}
//remember to check the tarjan
void Add(int x,int y){
	t[++E] = y;
	ne[E] = be[x];
	be[x] = E;
}

int rd[maxn], Ans, dp[maxn];

queue<int> q;

void add_edge(){
	For(i, 1, n){
		for(int j = Begin[i];j ;j = Next[j]){
			int v = to[j];

			if(circle[v] != circle[i]){
				Add(circle[i], circle[v]);
				++ rd[circle[v]];
			}
		}
	}

	For(i, 1, cnt){
		if(!rd[i]){
			dp[i] = val[i];
			q.push(i);
			Ans = max(Ans, dp[i]);
		}
	}
}

void pre_work(){
	For(i, 1, n){
		if(!pre[i]) dfs(i);
	}

	add_edge();
}

void solve(){
	while(!q.empty()){
		int now = q.front();
		q.pop();

		for(int i = be[now];i ;i = ne[i]){
			int v = t[i];

			dp[v] = max(dp[v], dp[now] + val[v]);
			Ans = max(dp[v], Ans);

			-- rd[v];
			if(!rd[v]) q.push(v);
		}
	}

	printf("%d\n", Ans);
}

int main(){
	
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);

	Get();
	pre_work();
	solve();

	return 0;
}
