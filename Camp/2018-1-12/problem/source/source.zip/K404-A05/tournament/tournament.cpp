//by yjz
#include<bits/stdc++.h>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=998244353;
const int proot=3;
const int FFTmx=300111;
const int FFTmxb=18;
const int FFTpmx=1<<FFTmxb;

ll qpow(ll x,ll k){return k==0?1:qpow(x*x%mod,k>>1)*(k&1?x:1)%mod;}
int pre_w[FFTmx],pre_br[FFTmx];
void FFTprecalc()
{
	pre_w[0]=1;
	int w=qpow(proot,(mod-1)/FFTpmx);
	for(int i=1;i<=FFTpmx;i++)pre_w[i]=1ll*pre_w[i-1]*w%mod;
	for(int i=0,j=0;i<FFTpmx;i++)
	{
		pre_br[i]=j;
		for(int l=(FFTpmx>>1);(j^=l)<l;l>>=1);
	}
}
int fsz;
int br[FFTmx];
void FFTinit(int sz)
{
	fsz=1;
	int tmp=FFTmxb;
	while(fsz<sz)fsz<<=1,tmp--;
	for(int i=0;i<fsz;i++)br[i]=pre_br[i]>>tmp;
}
int w[FFTmx];
void FFT(int a[],int coef)
{
	for(int i=0;i<fsz;i++)if(i<br[i])swap(a[i],a[br[i]]);
	for(int l=1,t=1;l<fsz;l<<=1,t++)
	{
		int l2=l<<1;
		if(coef==1)for(int j=0;j<=l;j++)w[j]=pre_w[j<<(FFTmxb-t)];
		else for(int j=0;j<=l;j++)w[j]=pre_w[FFTpmx-(j<<(FFTmxb-t))];
		for(int i=0;i<fsz;i+=l2)
		{
			for(int j=0;j<l;j++)
			{
				int tmp=1ll*w[j]*a[i+j+l]%mod;
				a[i+j+l]=a[i+j]-tmp<0?a[i+j]-tmp+mod:a[i+j]-tmp;
				a[i+j]=a[i+j]+tmp>=mod?a[i+j]+tmp-mod:a[i+j]+tmp;
			}
		}
	}
	if(coef==-1)
	{
		ll inv=qpow(fsz,mod-2);
		for(int i=0;i<fsz;i++)a[i]=a[i]*inv%mod;
	}
}
int mul_a[FFTmx],mul_b[FFTmx];
void polymul(int a[],int an,int b[],int bn,int c[],int cn=-1)
{
	if(cn==-1)cn=an+bn;
	FFTinit(an+bn);
	for(int i=0;i<fsz;i++)mul_a[i]=i<an?(a[i]%mod+mod)%mod:0;
	for(int i=0;i<fsz;i++)mul_b[i]=i<bn?(b[i]%mod+mod)%mod:0;
	FFT(mul_a,1);
	FFT(mul_b,1);
	for(int i=0;i<fsz;i++)mul_a[i]=1ll*mul_a[i]*mul_b[i]%mod;
	FFT(mul_a,-1);
	for(int i=0;i<cn;i++)c[i]=mul_a[i];
}
int inv_a[FFTmx];
void polyinv(int a[],int n,int b[])
{
	if(n==1)
	{
		b[0]=qpow(a[0],mod-2);
		return;
	}
	polyinv(a,n>>1,b);
	polymul(a,n,b,n>>1,inv_a,n);
	
	for(int i=0;i<n;i++)inv_a[i]=(mod-inv_a[i])%mod;
	inv_a[0]=(inv_a[0]+2)%mod;
	polymul(inv_a,n,b,n>>1,b,n);
}
int n,k;
ll fac[FFTmx],ifac[FFTmx];
ll C(int x,int y){return x<y?0:fac[x]*ifac[y]%mod*ifac[x-y]%mod;}
int f[FFTmx],dp[FFTmx];
int a[FFTmx];
ll pw2[FFTmx];
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	fac[0]=1;
	for(int i=1;i<FFTmx;i++)fac[i]=fac[i-1]*i%mod;
	ifac[FFTmx-1]=qpow(fac[FFTmx-1],mod-2);
	for(int i=FFTmx-2;i>=0;i--)ifac[i]=ifac[i+1]*(i+1)%mod;
	pw2[0]=1;
	for(int i=1;i<FFTmx;i++)pw2[i]=pw2[i-1]*2%mod;
	a[0]=1;
	for(int i=1;i<=100005;i++)a[i]=1ll*a[i-1]*pw2[i-1]%mod;
	for(int i=0;i<FFTmx;i++)a[i]=1ll*a[i]*ifac[i]%mod;
	FFTprecalc();
	
/*	int a[20]={1,mod-1,mod-1},b[20]={};
	polyinv(a,8,b);
	for(int i=0;i<8;i++)cout<<b[i]<<" ";cout<<endl;
	return 0;
*/
	
	cin>>n>>k;
//	for(int i=0;i<FFTmx;i++)a[i]=(mod-a[i])%mod;
	f[0]=1;
	int t=1;
	while(t<=n)t<<=1;
//	for(int i=0;i<t;i++)cout<<a[i]<<" ";cout<<endl;
	polyinv(a,t,f);
//	for(int i=0;i<t;i++)cout<<f[i]<<" ";cout<<endl;
	
	dp[0]=1;
	for(int i=k;i<FFTmx;i++)f[i]=0;
	polyinv(f,t,dp);
	
//	for(int i=1;i<=n;i++)cerr<<f[i]<<" ";cerr<<endl;
//	for(int i=1;i<=n;i++)cerr<<dp[i]<<" ";cerr<<endl;
	cout<<(a[n]-dp[n]+mod)%mod*fac[n]%mod;
	return 0;
}
