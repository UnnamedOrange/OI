#include <bits/stdc++.h>
using namespace std ;
int main() {
	srand(time(0)) ;
	freopen ( "string.in", "w", stdout ) ;
	int i, _, n, maxn ;
	maxn = 10, _ = 20 ;
	printf ( "%d\n", _ ) ;
	while (_--) {
		n = maxn ;
		printf ( "%d\n", n ) ;
		for ( i = 1 ; i <= n ; i ++ )
			putchar('a'+rand()%2) ;
		puts("") ;
	}
	return 0 ;
}
