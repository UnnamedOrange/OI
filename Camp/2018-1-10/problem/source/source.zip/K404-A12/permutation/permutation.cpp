#include <iostream>
#include <cstdio>
#include <cstring>
#define mod 998244353
using namespace std;
typedef long long ll;
int n,a[100005],m;
ll sum,f[100005],inv[100005],F[100005];
bool vis[100005];
ll quick_pow(ll a,ll b){
	ll ans=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1) ans=ans*a%mod;
	return ans;
}
ll C(ll n,ll m){
	if(n<m) return 0;
	return F[n]*inv[m]%mod*inv[n-m]%mod;
}
int s[100005],top,IN[100005];
void topsort(){
	for(int i=1;i<=n;i++) IN[a[i]]++;
	for(int i=1;i<=n;i++) if(!IN[i]) s[++top]=i;
	for(int i=1;i<=top;i++){
		if(!a[s[i]]) continue;
		IN[a[s[i]]]--;
		if(IN[a[s[i]]]==0) s[++top]=a[s[i]];
	}
	for(int i=1;i<=n;i++) if(IN[i]) s[++top]=i;
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	F[0]=inv[0]=1;
	for(int i=1;i<=n;i++) F[i]=F[i-1]*i%mod,inv[i]=quick_pow(F[i],mod-2);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	if(n&1) return puts("0"),0;
	topsort();
	for(int ii=1,i,o=n;ii<=o;ii++){
		i=s[ii];
		if(a[i]){
			int g=i,tot=0;
			while(!vis[g]){
				vis[g]=1;tot++;
				if(!a[g]){
					tot=-tot;break;
				}
				g=a[g];
			}
			if(tot>=0){
				n-=tot;
				if(tot&1) return puts("0"),0;
				continue;
			}
			else{
				tot=-tot;
				n=n-tot;
				if(tot&1) n++;
				else m++;
			}
		}
	}
	ll sum=1;f[0]=1;
	for(int i=1;i<=n+m;i++){
		if(i<=n&&(i&1)) continue;
		f[i]=sum*F[i-1]%mod;
		sum=(sum+f[i]*inv[i])%mod;
	}
	/*ll ans=0;
	for(int i=0;i<=m;i++){
		ans=(ans+f[n]*C(m,i)%mod*F[m-i]%mod*quick_pow(n,i)*F[max(i-1,0)]%mod)%mod;
	}*/
	printf("%lld",f[n+m]);
	return 0;
}
