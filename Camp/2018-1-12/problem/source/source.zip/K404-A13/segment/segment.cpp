#include<cstdio>
#include<algorithm>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
#define LL long long
using namespace std;
const int maxn = 1e2 + 5, mod = 998244353;
int num[maxn], m, n, k;
LL ans;

LL fpow(LL a, int b, LL c) {
	LL ans = 1;
	while(b) {
		if(b & 1) ans = ans * a % c;
		a = a * a % c, b >>= 1;
	}
	return ans;
}

void dfs(int step, int l, int r) {
	if(step == n) {
		For(i, 1, m) (ans += fpow(num[i], k, mod)) %= mod;
		return ;
	}
	For(i, l + 1, m) For(j, max(r + 1, i), m) {
		For(p, i, j - 1) ++num[p];
		dfs(step + 1, i, j);
		For(p, i, j - 1) --num[p];
	}
}

int main() {
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	dfs(0, 0, 0);
	printf("%lld\n", ans);
	return 0;
}
