#include <bits/stdc++.h>
using namespace std;
const int Mod = 998244353;
int N, Ans;
int A[110], P[110], Q[110], Vis[110];
inline void Check()
{
	for (int i = 1; i <= N; ++i)
		if (A[i] && Q[i] != A[i]) return ;
	for (int i = 1; i <= N; ++i)
	{
		if (Vis[i]) continue;
		int now = i, st = i, cnt = 0;
		while (1)
		{
			cnt++;
			now = Q[now];
			if (now == st) break;
		}
		if (cnt % 2) return ;
	}
	(Ans += 1) %= Mod;
}
inline void dfs(int x)
{
	if (x == N)
	{
		Check();
		return ;
	}
	for (int i = 1; i <= N; ++i)
	{
		if (!P[i])
		{
			P[i] = 1;
			Q[x + 1] = i;
			dfs(x + 1);
			P[i] = 0;
		}
	}
}
int main()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	scanf("%d", &N);
	for (int i = 1; i <= N; ++i) scanf("%d", &A[i]);
	if (N <= 8)
	{
		dfs(0);
		cout<<Ans<<endl;
	}
	return 0;
}
