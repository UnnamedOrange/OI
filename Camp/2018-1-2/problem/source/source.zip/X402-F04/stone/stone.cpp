//2018-1-2
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N (100000+5)

const int P = 1e9 + 7;

inline int Mod(int a){
	if(a < 0) a += P;
	return a >= P? a-P: a;
}

inline int Mul(int a, int b){
	return 1ll * a * b % P;
}

int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = Mul(ret, a);
		a = Mul(a, a); anum >>= 1;
	}
	return ret;
}

int x[N], fac[N], rfac[N];

void Init(int n){
	fac[0] = rfac[0] = 1;
	For(i, 1, n){
		fac[i] = Mul(fac[i-1], i);
		rfac[i] = Pow(fac[i], P-2);
	}
}

inline int C(int a, int b){
	return Mul(Mul(fac[a], rfac[b]), rfac[a-b]);
}

int main(){
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);

	int n, a, b;
	bool chg = false;

	scanf("%d%d%d", &n, &a, &b);
	Init(n);

	For(i, 1, n) scanf("%d", &x[i]), x[i] %= a+b;
	if(a > b) swap(a, b), chg = true;

	int u = 0, v = 0, a1 = 0, a2 = 0, oth, ans;
	For(i, 1, n){
		if(x[i] < a) ++u;
		else if(x[i]>=a && x[i]<=b-1) ++v;
		else if(x[i]>=b && x[i]<=b+a-1) ++a1;
		else ++a2;
	}

	u = Pow(2, u);	
	ans = Mul(Mul(Mod(Pow(2, v)-1), u), Pow(2, a1+a2));
	printf("%d %d ", chg? 0: ans, chg? ans: 0);
	
	oth = Pow(2, n) - ans;
	ans = 0;
	for(int i = 1; i <= a1; i += 2) ans = Mod(ans+C(a1, i));
	ans = Mul(Mul(ans, u), Pow(2, a2));
	printf("%d %d\n", ans, Mod(oth - ans));

	return 0;
}
