#include <bits/stdc++.h>
using namespace std;

int MOD = 998244353;

int n;
int req[100010];
int num[100010];

int main() {
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	cin >> n;
	if (n & 1) {
		cout << 0;
		return 0;
	}
	bool nor = true;
	for (int i = 1; i <= n; ++i) {
		num[i] = i;
		cin >> req[i];
		if (req[i]) {
			nor = false;
		}
	}
	if (nor) {
		int ans = 1;
		for (int i = 2; i <= n; i += 2) {
			ans = (long long)ans * (i - 1) % MOD;
		}
		cout << (long long)ans * ans % MOD << endl;
	} else if (n == 8) {
		int ans = 0;
		do {
			bool ok = true;
			for (int i = 1; i <= n; ++i) {
				if (req[i] && req[i] != num[i]) {
					ok = false;
					break;
				}
			}
			if (!ok) {
				continue;
			}
			ok = true;
			for (int i = 1; i <= n; ++i) {
				int x = 0, p = i;
				while (true) {
					x ^= 1;
					if (num[p] != i) {
						p = num[p];
					} else {
						break;
					}
				}
				if (x) {
					ok = false;
					break;
				}
			}
			if (ok) {
				++ans;
			}
		} while (next_permutation(num + 1, num + n + 1));
		cout << ans << endl;
	} else {
		bool ok = true;
		for (int i = 1; i <= n; ++i) {
			int x = 0, p = i;
			while (true) {
				x ^= 1;
				if (req[p] != i) {
					if (req[p]) {
						p = req[p];
					} else {
						x = 0;
						break;
					}
				} else {
					break;
				}
			}
			if (x) {
				ok = false;
				break;
			}
		}
		if (!ok) {
			cout << "0\n";
		} else {
			int ans = 1, x = 1, m = 0;
			for (int i = 1; i <= n; ++i) {
				if (req[i] == 0) {
					ans = (long long)ans * x % MOD;
					m ^= 1;
					if (m == 0) {
						x += 2;
					}
				}
			}
			cout << ans << endl;
		}
	}
}
