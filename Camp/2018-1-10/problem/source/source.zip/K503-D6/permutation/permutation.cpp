#include <cctype>
#include <cstdio>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)
#define repd(i,x,y) for (int i=x; i>=(y); --i)

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;
}

using namespace std;

const int N=1e5+10,mod=998244353;
int n,s[2],in[N],p[N],inv[N],f[N],ans;
bool flag[N];

int main()
{
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
    n=get();
    rep(i,1,n)
        ++in[p[i]=get()];
    inv[1]=1;
    rep(i,2,n)
        inv[i]=1ll*(mod-mod/i)*inv[mod%i]%mod;
    rep(i,1,n)
        if (!in[i])
        {
            int x=i,t=1;
            for (; flag[x]=1,p[x]; x=p[x],++t);
            ++s[t&1];
        }
    rep(i,1,n)
        if (!flag[i])
        {
            int x=i,t=1;
            for (; flag[x]=1,!flag[p[x]]; x=p[x],++t);
            if (t&1)
            {
                puts("0");
                return 0;
            }
        }
    if (s[1]&1)
    {
        puts("0");
        return 0;
    }
    f[0]=1,s[1]>>=1;
    rep(i,1,s[1])
        f[i]=f[i-1]*(inv[i<<1]+1ll)%mod;
    ans=(f[s[1]]+mod-f[s[1]-1])%mod;
    s[1]<<=1;
    rep(i,1,s[1])
        ans=1ll*ans*i%mod;
    rep(i,1,s[0])
        ans=1ll*ans*(s[1]+i)%mod;
    printf("%d",ans);
    return 0;
}
