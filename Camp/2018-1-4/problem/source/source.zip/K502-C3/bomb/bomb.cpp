#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<vector>
#include<cstring>
#define rand_1() rand()%1000
#define NN 1000000+1000
using namespace std;
int rand_cnt=0;
int rand_int(){
	if(++rand_cnt==5100){
		rand_cnt=0;
		srand((unsigned long long)(new char));
	}
	return (rand_1()*1000+rand())*1000+rand();
}
int p[NN];
struct node{
	int to,xt;
}e[2*NN];
int E=0;
void add_edge(int a,int b){
	++E;
	e[E].to=b;
	e[E].xt=p[a];
	p[a]=E;
}
int col[NN]={0};
bool paint(int x){
	for(int pos=p[x];pos;pos=e[pos].xt){
		int cur=e[pos].to;
		if(col[cur]==col[x]){
			return false;
		}
		if(!col[cur]){
			col[cur]=3-col[x];
			if(!paint(cur))return false;
		}
	}
	return true;
}
int n,m;
bool no_circle(){
	for(int i=1;i<=n;++i){
		if(!col[i]){
			col[i]=1;
			if(!paint(i))return false;
		}
	}
	return true;
}
int DEG[NN]={0};
int q[10000]={0},h=0,t=0;
void get_deg(){
	memset(DEG,0,sizeof DEG);
	for(int i=1;i<=n;++i){
		if(!col[i]){
			for(int pos=p[i];pos;pos=e[pos].xt){
				++DEG[e[pos].to];
			}
		}
	}
}
void boom(int x){
	h=0,t=0;
	q[t++]=x;
	while(h!=t){
		int x=q[h++];
		col[x]=1;
		for(int pos=p[x];pos;pos=e[pos].xt){
			int cur=e[pos].to;
			if(!col[cur]){
				col[cur]=2;
				for(int pp=p[cur];pp;pp=e[pp].xt){
					--DEG[e[pp].to];
					if(!DEG[e[pp].to]&&!col[e[pp].to]){
						q[t++]=e[pp].to;
					}
				}
			}
		}
	}
}
			
int Dream(){
	int ans=0;
	bool fl=1;
	memset(col,0,sizeof col);
	while(fl){
		for(int i=1;i<=n;++i){
			if(col[i]==2)col[i]=0;
		}
		
		get_deg();
		int cur=0;
		fl=0;
		for(int i=1;i<=n;++i){
			if(col[i]==0){
				fl=1;
				boom(i);
			}
		}
		if(fl)++ans;
	}
	return ans;
}
void open(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
}
void close(){
	fclose(stdin);
	fclose(stdout);
}
int main(){
	open();
	int a,b;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i){
		scanf("%d%d",&a,&b);
		add_edge(a,b);
		add_edge(b,a);
		++DEG[a];
		++DEG[b];
	}
	if(no_circle()){
		if(m==0)printf("1");
		else{
			printf("2");
		}
	}
	else{
		int ans=n;
		if(n<=1000){
			printf("%d",Dream());
		}
		else{
			printf("%d",min(12,9));
		}
	}
	close();
}
				
	
	
