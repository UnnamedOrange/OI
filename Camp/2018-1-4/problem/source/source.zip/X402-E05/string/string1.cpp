#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int M=510;
const int N=1210;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("string.in","r",stdin);
	freopen("string1.out","w",stdout);
}
int m,n,a[N],ans;
char s[N];
int c[N][2],rt,tot,w[N],f[N];
inline bool check()
{
	int now=rt,ret=0;
	For(i,1,m<<1)
	{
		now=c[now][a[i]];
		ret|=w[now];
	}
	return ret==(1<<n)-1;
}
inline void dfs(int now)
{
	if(now==m+1)
	{
		if(check())
		{
			//For(i,1,m<<1)printf("%d",a[i]);puts("");
			ans++;
		}
		return;
	}
	a[now]=1;a[2*m-now+1]=0;
	dfs(now+1);
	a[now]=0;a[2*m-now+1]=1;
	dfs(now+1);
}
inline void init(){c[0][0]=c[0][1]=1;rt=tot=f[0]=1;}
inline void insert(char *s,int val)
{
	int p=rt;
	For(i,0,strlen(s)-1)
	{
		int x=s[i]-'0';
		p=c[p][x]?c[p][x]:c[p][x]=++tot;
	}
	w[p]|=val;
}
inline void Get_f(int x)
{
	For(i,0,1)
	{
		int ret=c[f[x]][i];
		if(c[x][i])f[c[x][i]]=ret,w[c[x][i]]|=w[ret];
		else c[x][i]=ret;
	}
}
inline void Get_fail()
{
	queue<int>q;int x;
	for(q.push(rt);!q.empty();Get_f(x))
	{
		x=q.front();q.pop();
		For(i,0,1)if(c[x][i])q.push(c[x][i]);
	}
	//For(i,1,tot)printf("%d w:%d f:%d 0:%d 1:%d\n",i,w[i],f[i],c[i][0],c[i][1]);
}
int main()
{
	file();
	init();
	read(n),read(m);
	For(i,1,n)
	{
		scanf("%s",s);
		insert(s,1<<(i-1));
	}
	Get_fail();
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
