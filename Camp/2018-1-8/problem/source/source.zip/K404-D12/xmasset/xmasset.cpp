#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;

#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
int TYPE, N, T, t, _x[2000005], _y[2000005], c[1024]; string s; bool flag = true;
int encode(int x, int y)
{for(t = 0; t < 10 && !(((x^y)>>t)&1); t++); return (t<<1|1)+((x>>t)&1);}
int encode()
{
	for(rint i = 1, x, y; i <= T; i++)
	{
		x = _x[i], y = _y[i];
		if((c[x]^c[y])&1) s += "11", s += (char)('0'+(c[x]&1));
		else
		{
			for(t = 0; t < 10 && !(((x^y)>>t)&1); t++); t = (t<<1|1)+((x>>t)&1);
			s += (char)('0'+((t>>4)&1)); s += (char)('0'+((t>>3)&1)); s += (char)('0'+((t>>2)&1)); s += (char)('0'+((t>>1)&1)); s += (char)('0'+(t&1));
		}
	}
	if(s.length() <= 4*T)
		for(rint i = 0; i < s.length(); i += 4)
			printf("%d\n",(s[i]-'0')<<3|(s[i+1]-'0')<<2|(s[i+2]-'0')<<1|(s[i+3]-'0'));	
	else
		for(rint i = 1; i <= T; printf("%d\n",encode(_x[i],_y[i])), i++);
}
inline void O(int x){puts(x?"yes":"no");}
void decode()
{
	for(rint i = 1; i <= T && flag; i++)
		if(_y[i] >= 16) flag = false;
	if(!flag)
	{
		for(rint i = 1, q; i <= T; i++)
		switch(q = _x[i], _y[i])
		{
		case  1: O(!((q>>0)&1)); break;
		case  2: O((q>>0)&1); break;
		case  3: O(!((q>>1)&1)); break;
		case  4: O((q>>1)&1); break;
		case  5: O(!((q>>2)&1)); break;
		case  6: O((q>>2)&1); break;
		case  7: O(!((q>>3)&1)); break;
		case  8: O((q>>3)&1); break;
		case  9: O(!((q>>4)&1)); break;
		case 10: O((q>>4)&1); break;
		case 11: O(!((q>>5)&1)); break;
		case 12: O((q>>5)&1); break;
		case 13: O(!((q>>6)&1)); break;
		case 14: O((q>>6)&1); break;
		case 15: O(!((q>>7)&1)); break;
		case 16: O((q>>7)&1); break;
		case 17: O(!((q>>8)&1)); break;
		case 18: O((q>>8)&1); break;
		case 19: O(!((q>>9)&1)); break;
		case 20: O((q>>9)&1); break;
		}
	}
	else
	{
	for(rint i = 1, t; i <= T; i++)
		{t = _y[i], s += (char)('0'+((t>>3)&1)); s += (char)('0'+((t>>2)&1)); s += (char)('0'+((t>>1)&1)); s += (char)('0'+(t&1));}
	for(rint i = 0, j = 1, q, k; i < s.length(); )
	{
		if(s[i] == '1' && s[i+1] == '1') O((c[_x[j]]&1)==(s[i+2]-'0')), i = i+3, j++;
		else
		{
			k = (s[i]-'0')<<4|(s[i+1]-'0')<<3|(s[i+2]-'0')<<2|(s[i+3]-'0')<<1|(s[i+4]-'0'), q = _x[j];
			switch(k)
			{
			case  1: O(!((q>>0)&1)); break;
			case  2: O((q>>0)&1); break;
			case  3: O(!((q>>1)&1)); break;
			case  4: O((q>>1)&1); break;
			case  5: O(!((q>>2)&1)); break;
			case  6: O((q>>2)&1); break;
			case  7: O(!((q>>3)&1)); break;
			case  8: O((q>>3)&1); break;
			case  9: O(!((q>>4)&1)); break;
			case 10: O((q>>4)&1); break;
			case 11: O(!((q>>5)&1)); break;
			case 12: O((q>>5)&1); break;
			case 13: O(!((q>>6)&1)); break;
			case 14: O((q>>6)&1); break;
			case 15: O(!((q>>7)&1)); break;
			case 16: O((q>>7)&1); break;
			case 17: O(!((q>>8)&1)); break;
			case 18: O((q>>8)&1); break;
			case 19: O(!((q>>9)&1)); break;
			case 20: O((q>>9)&1); break;
			}	i = i+5, j++;
		}
	}
	}
}
int main()
{
	TYPE = read(), N = read(), T = read();
	for(rint i = 1; i <= N; c[i] = -~c[i-(i&-i)], i++);
	for(rint i = 1; i <= T; _x[i] = read(), _y[i] = read(), i++);
	TYPE<2 ? encode(),0 : (decode(),0); return 0;
}
