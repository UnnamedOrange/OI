#include<cstdio>
#include<algorithm>
using namespace std;
#define N 100005
#define LL long long
#define mod 998244353 
#define rep(i,j,k) for(i=j;i<=k;++i)
struct E{
	int to,nxt;
}ed[N];
LL timing,n,m,i,j,k,cnt,x,fx,fy,top,scc,num;
int head[N],f[N],sz[N],dfn[N],ru[N],id[N],stap[N],low[N],vis[N],size[N];
LL dp[N],c[N],p[N],fac[N],inv[N];
bool flag=false;
void read(LL &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
}
LL quick_mi(LL a,int b){
	LL sum=1;
	for(;b;b>>=1){
		if(b&1) sum=(sum*a)%mod;
		a=(a*a)%mod;
	}
	return sum;
}
int find(int x){
	if(x==f[x]) return x;
	return f[x]=find(f[x]);
}
void add(int u,int v){
	top++; ed[top].to=v; ed[top].nxt=head[u]; head[u]=top;
}
void tarjan(int x){
	int i;
	timing++; dfn[x]=low[x]=timing; vis[x]=1; top++; stap[top]=x;
	for(i=head[x];i;i=ed[i].nxt)
	if(!dfn[ed[i].to]){
		tarjan(ed[i].to);
		low[x]=min(low[x],low[ed[i].to]);
	}else
	if(vis[ed[i].to]){
		low[x]=min(low[x],dfn[ed[i].to]);
	}
	if(low[x]==dfn[x]){
		scc++; size[scc]=0; int u;
		do{
			u=stap[top]; top--; vis[u]=0;
			id[u]=scc; size[scc]++;
		}while(u!=x);
		if((size[scc]&1)&&(size[scc]>1)) flag=true;
	}
}
void upadd(int x,LL val){
	x++;
	for(;x<=cnt+1;x+=(x&(-x))){
		c[x]=(c[x]+val)%mod;
	}
}
LL getsum(int x){
	LL tmp=0;
	x++;
	for(;x;x-=(x&(-x))){
		tmp=(tmp+c[x])%mod;
	}
	return tmp;
} 
void dynamic(){
	upadd(0,1); fac[0]=dp[0]=1;
	rep(i,1,cnt){
		fac[i]=(fac[i-1]*i)%mod;
		inv[i]=quick_mi(fac[i],mod-2);
		if(i&1) continue ;
		LL tmp=getsum(i-1);
		dp[i]=(tmp*fac[i-1])%mod;
		upadd(i,(dp[i]*inv[i])%mod);
	}
	LL ans=dp[cnt];
	rep(i,cnt+1,cnt+num) ans=(ans*i)%mod;
	printf("%lld\n",ans);
}
void init(){
	read(n);
	rep(i,1,n){
		read(p[i]);
		if(p[i]==i) {puts("0"); return ;}
		if(p[i]){ 
			ru[p[i]]++; 
			if(ru[p[i]]>1) {
				puts("0"); return ;
			}
			add(i,p[i]);	
		}
	}
	top=0;
	rep(i,1,n)
	if(!dfn[i]){
		tarjan(i);
		if(flag) {puts("0"); return ;} 
	}
	rep(i,1,scc) 
	if(size[i]==1){f[i]=i,sz[i]=1;}
	rep(i,1,n) 
	if(p[i]){
		if(id[i]!=id[p[i]]){
			fx=find(id[i]); fy=find(id[p[i]]);
			f[fx]=fy; sz[fy]+=sz[fx];
		}
	}
	rep(i,1,scc)
	if(f[i]==i){
		if(sz[i]&1) {
			cnt++; size[cnt]=sz[i];
		}else num++;
	}
	dynamic();
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	init();
	return 0;
}
