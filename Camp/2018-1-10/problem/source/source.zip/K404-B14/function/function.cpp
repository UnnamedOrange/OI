#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int INF = 0x3f3f3f3f;
inline void gmin(int &x, int y){x = x < y ? x : y;}
inline void gmax(int &x, int y){x = x > y ? x : y;}
const int MAXN23 = 1000010;
int mu[MAXN23], tau[MAXN23], pri[MAXN23], cnt, pa[MAXN23], pc[MAXN23];
LL tau2[MAXN23];
bool isnp[MAXN23];
void init(int N){
	mu[1] = 1;
	tau[1] = 1;
	pa[1] = 1;
	pc[1] = 0;
	for(int i = 2; i <= N; i++){
		if(!isnp[i]){
			pri[cnt++] = i;
			mu[i] = -1;
			tau[i] = 2;
			pa[i] = i;
			pc[i] = 1;
		}
		for(int j = 0; j < cnt && i * pri[j] <= N; j++){
			isnp[i * pri[j]] = true;
			if(i % pri[j] == 0){
				mu[i * pri[j]] = 0;
				pa[i * pri[j]] = pa[i] * pri[j];
				pc[i * pri[j]] = pc[i] + 1;
				tau[i * pri[j]] = tau[i / pa[i]] * (pc[i] + 2);
				break;
			}
			mu[i * pri[j]] = -mu[i];
			tau[i * pri[j]] = tau[i] * 2;
			pa[i * pri[j]] = pri[j];
			pc[i * pri[j]] = 1;
		}
	}
	for(int i = 1; i <= N; i++) mu[i] += mu[i - 1], tau2[i] = tau2[i - 1] + (LL)tau[i] * tau[i];
}
int n, T;
LL solve(int n){
	LL ans = 0;
	for(int i = 1, last; i <= n; i = last + 1){
		last = n / (n / i);
		ans += (tau2[last] - tau2[i - 1]) * mu[n / i];
	}
	return ans;
}
int main(){
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	init(1000001);
	scanf("%d", &T);
	while(T--){
		scanf("%d", &n);
		printf("%lld\n", solve(n));
	}
	return 0;
}
