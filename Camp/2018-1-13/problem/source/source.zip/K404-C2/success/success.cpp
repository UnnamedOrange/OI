#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
const int N=105,mod=1000000007;
typedef long long LL;
LL s;
int t,n,m,f[N][N],ans;

void inc(int &x,int y)
{
	if((x+=y)>=mod) x-=mod;
}

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%lld%d%d%d",&s,&t,&n,&m);
	f[0][0]=1;
	rep(i,0,m-1)
		rep(j,0,s-1)
			if(f[i][j])
			{
				int lim=i+1<=n?t:s;
				rep(k,1,lim)
				{
					if(j+k>s) break;
					inc(f[i+1][j+k],f[i][j]);
				}
			}
	rep(i,1,s) inc(ans,f[m][i]);
	printf("%d\n",ans);
	return 0;
}
