#include<iostream>
#include<vector>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}

const int N=1009;

struct cond
{
	int x,y,r;
}co[N];

int n,ww,p,q,ctop,ans;
int x[N],y[N],z[N],a[N],b[N],c[N],d[N],e[N],f[N];
int w[N],fa[N];
vector<int> le[N],leq[N],ge[N],geq[N];

inline int find(int x)
{
	if(fa[x]==x)return x;
	return fa[x]=find(fa[x]);
}

inline int calc()
{
	int ret=0;
	for(int i=1;i<=p;i++)
	{
		ret+=a[i]*abs(w[x[i]]-w[y[i]]);
		ret+=b[i]*abs(w[y[i]]-w[z[i]]);
		ret+=c[i]*abs(w[z[i]]-w[x[i]]);
		ret+=d[i]*(w[x[i]]-w[y[i]]);
		ret+=e[i]*(w[y[i]]-w[z[i]]);
		ret+=f[i]*(w[z[i]]-w[x[i]]);
	}
	for(int i=1;i<=n;i++)
		ret+=w[fa[i]];
	return ret;
}

inline void dfs(int pos)
{
	if(pos==n+1)
	{
		int ret=calc();
		if(ans>ret)
			ans=ret;
		return;
	}
	int cpos=fa[pos];
	if(w[cpos])
	{
		dfs(pos+1);
		return;
	}

	if(le[cpos].size())
	{
		w[cpos]=-ww;
		dfs(pos+1);
		w[cpos]=0;
		return;
	}
	if(leq[cpos].size())
	{
		for(int i=0,e=leq[cpos].size();i<e;i++)
			if(w[fa[leq[cpos][i]]]==-ww)
			{
				w[cpos]=-ww;
				dfs(pos+1);
				w[cpos]=0;
				return;
			}
	}
	if(ge[cpos].size())
	{
		w[cpos]=ww;
		dfs(pos+1);
		w[cpos]=0;
		return;
	}
	if(geq[cpos].size())
	{
		for(int i=0,e=geq[cpos].size();i<e;i++)
			if(w[fa[geq[cpos][i]]]==ww)
			{
				w[cpos]=ww;
				dfs(pos+1);
				w[cpos]=0;
				return;
			}
	}
	w[cpos]=ww;
	dfs(pos+1);
	w[cpos]=-ww;
	dfs(pos+1);
	w[cpos]=0;
	return;
}

int mian()
{
	n=read();ww=read();
	p=read();q=read();
	for(int i=1;i<=p;i++)
	{
		x[i]=read();y[i]=read();
		z[i]=read();a[i]=read();
		b[i]=read();c[i]=read();
		d[i]=read();e[i]=read();
		f[i]=read();
	}
	for(int i=1;i<=n;i++)
	{
		fa[i]=i;
		le[i].clear();
		ge[i].clear();
		leq[i].clear();
		geq[i].clear();
	}
	ctop=0;
	for(int i=1,tx,ty,tr;i<=q;i++)
	{
		tx=read();ty=read();tr=read();
		if(tr==0 || tr==2)
			co[++ctop]=(cond){tx,ty,tr};
		else if(tr==1)
		{
			tx=find(tx);ty=find(ty);
			fa[tx]=ty;
		}
	}

	for(int i=1;i<=n;i++)
		find(i);
	for(int i=1;i<=p;i++)
		x[i]=fa[x[i]],y[i]=fa[y[i]],z[i]=fa[z[i]];

	for(int i=1,tx,ty,tr;i<=ctop;i++)
	{
		tx=co[i].x,ty=co[i].y,tr=co[i].r;
		if(tr==0)
		{
			leq[fa[tx]].push_back(fa[ty]);
			geq[fa[ty]].push_back(fa[tx]);
		}
		else
		{
			le[fa[tx]].push_back(fa[ty]);
			ge[fa[ty]].push_back(fa[tx]);
		}
	}

	ans=1e9+7;
	dfs(1);
	printf("%d\n",ans);
	return 0;
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--)
		mian();

	return 0;
}
