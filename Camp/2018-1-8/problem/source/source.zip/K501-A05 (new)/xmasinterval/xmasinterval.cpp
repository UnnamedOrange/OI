#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int Mod = int(1e9 + 7);
const int MAXN = int(20), MAXV = 3 * MAXN;

int n, m;

int p[MAXN + 5];
pii seg[MAXN + 5];

inline void input()
{
	n = read<int>(), m = read<int>();
	for(int i = 0; i < n; ++i) seg[i].fst = read<int>(), seg[i].snd = read<int>();
	for(int i = 0; i < m; ++i) p[i] = read<int>();
}

int len;

inline void Discret()
{
	static vector<int> tmp;
	tmp.clear();

	for(int i = 0; i < n; ++i)
	{
		tmp.push_back(seg[i].fst);
		tmp.push_back(seg[i].snd);
	}
	for(int i = 0; i < m; ++i) tmp.push_back(p[i]);
	sort(ALL(tmp)), tmp.erase(unique(ALL(tmp)), tmp.end());

	for(int i = 0; i < n; ++i)
	{
		seg[i].fst = lower_bound(ALL(tmp), seg[i].fst) - tmp.begin() + 1;
		seg[i].snd = lower_bound(ALL(tmp), seg[i].snd) - tmp.begin() + 1;
	}
	for(int i = 0; i < m; ++i) p[i] = lower_bound(ALL(tmp), p[i]) - tmp.begin() + 1;
	len = SZ(tmp);
}

int ans = 0;

bool point[MAXV + 5], vis[MAXN + 5];

inline bool check()
{
	memset(point, 0, sizeof point);
	for(int i = 0; i < m; ++i) point[p[i]] = 1;
	for(int i = 0; i < n; ++i)
		if(vis[i]) for(int j = seg[i].fst; j <= seg[i].snd; ++j) point[j] = 0;

	for(int i = 1; i <= len; ++i) if(point[i]) return 0;
	return 1;
}

inline void dfs(int dep)
{
	if(dep == n)
	{
		(ans += check()) %= Mod;
		return;
	}

	vis[dep] = 0, dfs(dep + 1);
	vis[dep] = 1, dfs(dep + 1);
}

inline void solve()
{
	Discret();
	dfs(0);
	printf("%d\n", ans);
}

int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);

	input();
	solve();

	return 0;
}


