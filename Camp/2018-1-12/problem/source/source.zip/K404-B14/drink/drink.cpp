#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int INF = 0x3f3f3f3f;
const int MAXB = 2e7;
char buf[MAXB], *cp = buf;
void rd(int &x){
	x = 0;
	while(!isdigit(*cp)) cp++;
	while(isdigit(*cp)) x = x * 10 + *cp++ - 48;
}
inline void gmin(int &x, int y){x = x < y ? x : y;}
inline void gmax(int &x, int y){x = x > y ? x : y;}

namespace Seg{
	#define lc(x) ((x) << 1)
	#define rc(x) ((x) << 1 | 1)
	const int MAXV = 4000010;
	double lsum[MAXV], rsum[MAXV];
	int sumc[MAXV];
	double f[MAXV];
	void init(int n){
		f[0] = 1.00;
		for(int i = 1; i <= n; i++) f[i] = f[i - 1] * 0.5;
	}
	void pup(int x){
		sumc[x] = sumc[lc(x)] + sumc[rc(x)];
		lsum[x] = lsum[rc(x)] + lsum[lc(x)] * f[sumc[rc(x)]];
		rsum[x] = rsum[lc(x)] + rsum[rc(x)] * f[sumc[lc(x)]];
	}
	void build(int x, int l, int r){
		lsum[x] = rsum[x] = 1.00;
		sumc[x] = 0;
		if(l < r){
			int mid = (l + r) >> 1;
			build(lc(x), l, mid);
			build(rc(x), mid + 1, r);
			pup(x);
		}
	}
	void add1(int x, int l, int r, int p){
		if(l == r){
			sumc[x]++;
			lsum[x] = rsum[x] = 0.50;
		}
		else{
			int mid = (l + r) >> 1;
			if(p <= mid) add1(lc(x), l, mid, p);
			if(p > mid) add1(rc(x), mid + 1, r, p);
			pup(x);
		}
	}
	double queryl(int x, int l, int r, int ql, int qr, int &c){
		if(ql <= l && r <= qr){
			c = sumc[x]; return lsum[x];
		}
		else{
			int mid = (l + r) >> 1, cl = 0, cr = 0;
			double ansl = 0, ansr = 0;
			if(ql <= mid) ansl = queryl(lc(x), l, mid, ql, qr, cl);
			if(qr > mid) ansr = queryl(rc(x), mid + 1, r, ql, qr, cr);
			c = cl + cr;
			return ansl * f[cr] + ansr;
		}
	}
	double queryr(int x, int l, int r, int ql, int qr, int &c){
		if(ql <= l && r <= qr){
			c = sumc[x]; return rsum[x];
		}
		else{
			int mid = (l + r) >> 1, cl = 0, cr = 0;
			double ansl = 0, ansr = 0;
			if(ql <= mid) ansl = queryr(lc(x), l, mid, ql, qr, cl);
			if(qr > mid) ansr = queryr(rc(x), mid + 1, r, ql, qr, cr);
			c = cl + cr;
			return ansl + ansr * f[cl];
		}
	}
}
const int MAXN = 1000010;
int n;
double ans;
PII w[MAXN];
using namespace Seg;
int main(){
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	buf[fread(buf, 1, MAXB, stdin)] = 0;
	rd(n);
	init(n);
	build(1, 1, n);
	for(int i = 1; i <= n; i++) rd(w[i].F), w[i].S = i;
	sort(w + 1, w + n + 1);
	for(int i = n; i; i--){
		int x = w[i].S, v = w[i].F, c;
		ans += queryl(1, 1, n, 1, x, c) * queryr(1, 1, n, x, n, c) * v * 0.5;
		add1(1, 1, n, x);
	}
	printf("%.6lf\n", ans / n / n);
	return 0;
}
