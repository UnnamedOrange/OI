//© 2018 Jazengm/Zeng Xiangru, All Rights Reserved
#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int mxn=1<<21;

In void mne(int& x, int y){x>y? x=y: 0;}
In void mxe(int& x, int y){x<y? x=y: 0;}

struct edge
{
    int v, o;
    In edge(int v=0, int o=0):
    v(v), o(o) {}
};

struct graph
{
    int tot, h[mxn]; edge e[mxn];
    In graph(): tot(1) {}
    In void aE(int u, int v)
    {e[++tot]=edge(v, u[h]), u[h]=tot;}
} G1, G2, G3;

#define fev(x) for(Rg int i=u[G##x.h], v; (v=i[G##x.e].v)>0; i=i[G##x.e].o)

int DFN[mxn], bel[mxn], size[mxn], cnt;

void Tarjan(int u)
{
    St int low[mxn], t, st[mxn], tim;
    St bool inS[mxn];
    DFN[st[t++]=u]=low[u]=++tim, inS[u]=1;
    fev(1)
        if(!DFN[v])
            Tarjan(v), mne(low[u], low[v]);
        else
            if(inS[v])
                mne(low[u], DFN[v]);
    if(low[u]==DFN[u])
        for(++cnt; st[t]!=u; ++size[bel[st[--t]]=cnt], inS[st[t]]=0);
}

/*
int DP(int u)
{
    St int vis[mxn];
    vis[u]=1;
    Rg int r=0;
    fev(2)
        if(!vis[v])
        mxe(r, DP(v));
    Re r+size[u];
}
*/

int main()
{
    freopen("bomb.in", "r", stdin);
    freopen("bomb.out", "w", stdout);
    St int n, m;
    scanf("%d%d", &n, &m);
    inc(0, i, m)
    {
        St int u, v;
        scanf("%d%d", &u, &v), G1.aE(u, v);
    }
    inc(1, i, n+1)
        if(!DFN[i])
            Tarjan(i);
    St int deg[mxn];
    inc(1, u, n+1)
        fev(1) if(bel[u]!=bel[v])
            G2.aE(bel[u], bel[v]), G3.aE(bel[v], bel[u]), ++bel[u][deg];
    St int q[mxn];
    Rg int t=0;
    inc(1, i, cnt+1)
        if(!deg[i])
            q[t++]=i;
    St int f[mxn];
    Rg int ans=0;
    inc(0, h, t)
    {
        Rg int u=q[h];
        fev(2)
            mxe(f[u], f[v]);
        mxe(ans, f[u]+=size[u]);
        fev(3)
            if(!--deg[v])
                q[t++]=v;
    }
    printf("%d\n", ans);
    Re 0;
}
