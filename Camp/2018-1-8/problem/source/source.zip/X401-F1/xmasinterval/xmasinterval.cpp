#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=21;
int n,m,x[MAXN],st[MAXN],ed[MAXN],mp[MAXN*3],tot,ans;
bool used[MAXN],cov[MAXN];
bool check()
{
	memset(cov,0,sizeof(cov));
	for(int i=1;i<=n;++i)
		if(used[i])
			for(int j=st[i];j<=ed[i];++j)
				cov[j]=true;
	for(int i=1;i<=m;++i)
		if(!cov[x[i]])return false;
	return true;
}
void dfs(int dep)
{
	if(dep==n+1)
	{
		if(check())++ans;
		return;
	}
	used[dep]=true;
	dfs(dep+1);
	used[dep]=false;
	dfs(dep+1);
	return;
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;++i)mp[++tot]=st[i]=read(),mp[++tot]=ed[i]=read();
	for(int i=1;i<=m;++i)mp[++tot]=x[i]=read();
	sort(mp+1,mp+1+tot);
	tot=unique(mp+1,mp+1+tot)-mp-1;
	for(int i=1;i<=n;++i)st[i]=lower_bound(mp+1,mp+1+tot,st[i])-mp-1,ed[i]=lower_bound(mp+1,mp+1+tot,ed[i])-mp-1;
	for(int i=1;i<=m;++i)x[i]=lower_bound(mp+1,mp+1+tot,x[i])-mp-1;
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
