#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
const int Maxn = 22222222;

int T, n, p[Maxn], plist[Maxn], f[Maxn], g[Maxn];

int main() {
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	cin >> T;
	while (T--) {
		cin >> n;
		for (int i = 2; i <= n; ++i) {
			f[i] = p[i] = i;
		}
		g[1] = 1;
		for (int i = 2; i <= n; ++i) {
			if (p[i] == i) {
				plist[++*plist] = i;
			}
			if (f[i] == i) {
				g[i] = g[i/p[i]]+2;
			} else {
				g[i] = g[i/f[i]]*g[f[i]];
			}
			for (int j = 1; j <= *plist && i*plist[j] <= n; ++j) {
				p[i*plist[j]] = plist[j];
				if (i%plist[j] == 0) {
					f[i*plist[j]] = f[i]*plist[j];
					break;
				} else {
					f[i*plist[j]] = plist[j];
				}
			}
		}
		cout << accumulate(g+1, g+n+1, 0LL) << endl;
	}
	return 0;
}
