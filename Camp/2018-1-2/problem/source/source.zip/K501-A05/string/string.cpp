#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int maxn = int(1e5);

int n;

char s[maxn + 5];

inline void input()
{
	n = read<int>();
	scanf("%s", s);
}

inline bool check()
{
	bool fg;

	fg = 1;
	char c = s[0];
	REP(i, 1, n)
		if(s[i] != c)
		{
			if(!(n & 1) || i != (n >> 1))
			fg = 0;
		}
	if(fg) return 1;

	if(n >= 2)
	{
		fg = 1;
		char a = s[0], b = s[1];
		for(int i = 2; i < (n >> 1); i += 2)
			if(s[i] != a || s[i + 1] != b)
			{
				fg = 0;
				break;
			}
		if(s[n >> 1] != a) fg = 0;
		if(fg) return 1;
	}

	return 0;
}

inline void solve()
{
	bool flag = 1;
	REP(i, 0, n >> 1)
		if(s[i] != s[n - i - 1])
		{
			flag = 0;
			break;
		}

	if(!flag) puts("1");
	else puts(check() ? "-1" : "2");
}

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);

	int T = read<int>();
	while(T--)
	{
		input();
		solve();
	}

	return 0;
}

