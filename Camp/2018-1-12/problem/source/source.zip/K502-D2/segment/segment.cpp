#include <cstdio>
#include <iostream>
using namespace std;

const int mod = 998244353;

#define LL long long

int n, m, k;
LL ans = 0, A[100000 + 1000];

namespace file{
	inline void open()
	{
		freopen("segment.in", "r", stdin);
		freopen("segment.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

namespace input{
	inline int read()
	{
		int a = 0;
		char ch;
		int f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}

	
	inline void Get()
	{
		n = read(), m = read(), k = read();
	}
}

namespace math{
	inline LL ksm(LL a, int b)
	{
		LL base = a, ret = 1;
		while(b > 0)
		{
			if(b & 1)
				ret = ret * base % mod;
			base = base * base % mod;
			b >>= 1;
		}
		return ret;
	}
}

namespace cnt{
	inline void solve()
	{
		for(int len = 1;len <= m - 1;++len)
			ans = (ans + (len * (m - len) % mod)) % mod;
		printf("%lld\n", ans);
	}
}

namespace brute{
	inline void dfs(int x, int li, int ri)
	{
		if(x == n + 1)
		{
			for(int i = 1;i <= m;++i)
				ans = (ans + math::ksm(A[i], k)) % mod;
			return;
		}
		if(li == m || ri == m)
			return;
		for(int i = li + 1;i <= m;++i)
			for(int j = ri + 1;j <= m;++j)
			{
				if(j < i)
					continue;
				for(int k = i;k < j;++k)
					++A[k];
				dfs(x + 1, i, j);
				for(int k = i;k < j;++k)
					--A[k];
			}
	}
	
	inline void solve()
	{
		ans = 0;
		dfs(1, 0, 0);
		printf("%lld\n", ans);
	}
}

namespace method{
	inline void solve()
	{
		printf("19260817\n");
	}
}

namespace check{
	inline void deter()
	{
		if(n == 1)
			cnt::solve();
		else if(m <= 40)
			brute::solve();
		else
			method::solve();
	}
}

int main()
{
	open();
	input::Get();
	check::deter();
	close();
	return 0;
} 
