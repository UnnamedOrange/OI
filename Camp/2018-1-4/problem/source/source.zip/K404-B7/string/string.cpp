#include<bits/stdc++.h>
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')c=getchar(),f=-1;
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

int n,m,ans,a[10];
char s[10][105];
int t[105];

bool check(int x)
{
	for(int i=m-1,j=0;i>=0;i--)
		t[++j]=(x&(1<<i)?1:0);
	for(int i=m+1;i<=2*m;i++)t[i]=t[2*m+1-i]^1;
	x=0;
	for(int i=1;i<=2*m;i++)x=(x<<1)+t[i];
	for(int i=1;i<=n;i++)
	{
		int bz=1,len=strlen(s[i]+1);
		for(int j=0;j<=2*m-len;j++) 
			if((((a[i]<<j)&x)>>j)==a[i]&&(((a[i]<<j)&x)>>j)==((x%(1<<(j+len)))>>j))
			{
				bz=0;
				break;
			}
		if(bz)return false;
	}
	return true;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	n=getint(),m=getint();
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s[i]+1);
		int len=strlen(s[i]+1);
		for(int j=1;j<=len;j++)a[i]=(a[i]<<1)+s[i][j]-'0';
	}
	for(int i=0;i<(1<<m);i++)
		if(check(i))ans++;
	cout<<ans<<'\n';
	return 0;
}
