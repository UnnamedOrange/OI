#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 5010
#define ll long long
#define inf 1000000000
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
struct zgz
{
	int next,to;
}edge[N<<1];
int head[N],cnt=1;
void add(int from,int to)
{
	edge[cnt].to=to;
	edge[cnt].next=head[from];
	head[from]=cnt++;
}
int n,m,type;
int c[N];
int fa[N];
void dfs(int x)
{
	for(int i=head[x];i;i=edge[i].next)
	{
		int to=edge[i].to;
		if(to!=fa[x])
		{
			fa[to]=x;
			dfs(to);
		}
	}
}
int ans=0;
int buc[N];
void cal(int x,int l,int r)
{
	buc[c[x]]++;
	if(c[x]>=l&&c[x]<=r&&buc[c[x]]==1)ans++;
	for(int i=head[x];i;i=edge[i].next)
	{
		int to=edge[i].to;
		if(to!=fa[x])
		{
			cal(to,l,r);
		}
	}
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read(),m=read(),type=read();
	for(int i=1;i<=n;i++)c[i]=read();
	for(int i=1;i<n;i++)
	{
		int x=read(),y=read();
		add(x,y),add(y,x);
	}
	dfs(1);
	while(m--)
	{
		int opt=read();
		if(opt==1)
		{
			int x=read(),l=read(),r=read();
			if(type)x^=ans,l^=ans,r^=ans;
			ans=0;
			memset(buc,0,sizeof(buc));
			cal(x,l,r);
			printf("%d\n",ans);
		}
		else
		{
			int x=read(),y=read();
			if(type)y^=ans;
			c[x]=y;
		}
	}
}