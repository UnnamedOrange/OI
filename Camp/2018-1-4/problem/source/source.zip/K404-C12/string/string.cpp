#include <iostream>
#include <cstring>
#include <cstdio>
#define MOD 998244353
using namespace std; 
char str[7][105], res[1005]; 
namespace solver_brute
{
	inline void solve(int n, int m)
	{
		int ans = 0; 
		for (int i = 0; i < 1 << m; i++)
		{
			for (int j = 0; j < m; j++)
			{
				res[j] = ((i >> j) & 1) + '0'; 
				res[m + m - j - 1] = ((i >> j) & 1 ^ 1) + '0'; 
			}
			bool g = true; 
			for (int j = 0; j < n && g; j++)
			{
				bool f = false;
				int len = strlen(str[j]); 
				for (int x = 0; x + len <= m + m && !f; x++)
				{
					f = true; 
					for (int t = 0; t < len && f; t++)
						f &= res[x + t] == str[j][t]; 
				}
				if (!f)
					g = false; 
			}
			if (g)
				puts(res); 
			ans += g; 
		}
		printf("%d\n", ans); 
	}
}
int main()
{
	freopen("string.in", "r", stdin); 
	freopen("string.out", "wt", stdout); 
	int n, m;
	scanf("%d%d", &n, &m); 
	for (int i = 0; i < n; i++)
		scanf("%s", str[i]); 
	if (m <= 15)
	{
		solver_brute::solve(n, m); 
		return 0; 
	}
	return 0; 
}

