#include<bits/stdc++.h>
#define MO 1000000007
#define N 1000050
#define ab(x) ((x)>0?(x):(-(x)))
using namespace std;
inline int read()
{ //10000000000000///ll
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}//10 32  -1
//bzoj  ll LL lL Ll
int n,c[N],d[N],l,r,ll,dp[N],dp_[N];
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read(); 
	for(int i=1; i<=n; ++i)c[i]=read(),d[i]=read();
	dp[0]=0;
	dp_[0]=1;
	for(int i=1; i<=n; ++i)
	{
//		fl=0;
		l=c[i]; r=d[i];
		for(int j=i-1; j>=0; --j)
		{
			if(i-j>r)break;
			if(i-j>=l && i-j<=r)
			{
				if(dp[i]<dp[j]+1)dp[i]=dp[j]+1,dp_[i]=dp_[j];
				else if(dp[i]==dp[j]+1)dp_[i]=(dp_[i]+dp_[j])%MO;  //upt  upd  //if else   {}   , ; ///
			}
			l=max(c[j],l);
			r=min(d[j],r);
			if(l>r)break;
		}
	}//no _...
	if(!dp[n])puts("-1"); else printf("%d %d\n",dp[n],dp_[n]);
}//_ //\n ////
