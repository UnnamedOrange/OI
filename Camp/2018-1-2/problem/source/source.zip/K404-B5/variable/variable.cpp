#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 23;

struct hT
{
	void input ()
	{
		scanf ( "%d%d%d%d%d%d%d%d%d", &x, &y, &z, &a, &b, &c, &d, &e, &f );
	}
	
	int calc ( int vx, int vy, int vz )
	{
		return ( a * qabs ( vx - vy ) + b * qabs ( vy - vz ) + c * qabs ( vz - vx ) + d * ( vx - vy ) + e * ( vy - vz ) + f * ( vz - vx ) );
	}
	
	int x, y, z, a, b, c, d, e, f;
}h[MAXN];

int n, m, W, nc;
int cx[MAXN], cy[MAXN], cr[MAXN];
int a[MAXN];



void init ();
void input ();
void work ();



int main ()
{
	init ();
	
	int T;
	scanf ( "%d", &T );
	while ( T-- ){
		input ();
		work ();
	}
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "variable" );
}

void input ()
{
	scanf ( "%d%d%d%d", &n, &m, &W, &nc );
	lpi ( i, 1, m ) h[i].input ();
	lpi ( i, 1, nc ){
		scanf ( "%d%d%d", &cx[i], &cy[i], &cr[i] );
	}
}

void work ()
{
	int ms = ( 1 << n ), st, ans = INF, cur;
	bool flag;
	lp ( _st, 0, ms ){
		st = _st << 1;
		lpi ( i, 1, n ) a[i] = ( st >> i & 1 ) ? 1 : -1;
		flag = true;
		lpi ( i, 1, nc ){
			if ( ( cr[i] == 0 && ! ( a[cx[i]] <= a[cy[i]] ) ) || ( cr[i] == 1 && ! ( a[cx[i]] == a[cy[i]] ) ) || ( cr[i] == 2 && ! ( a[cx[i]] < a[cy[i]] ) ) ){
				flag = false;
				break;
			}
		}
		if ( flag ){
			cur = 0;
			lpi ( i, 1, n ) cur += a[i];
			lpi ( i, 1, m ) cur += h[i].calc ( a[h[i].x], a[h[i].y], a[h[i].z] );
			ans = qmin ( ans, cur );
		}
	}
	
	cout << SC ( LL, ans ) * W << endl;
}
