#include <map>
#include <set>
#include <cmath>
#include <queue>
#include <cctype>
#include <cstdio>
#include <vector>
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <functional>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)
#define repe(i,x) for (edge *i=fst[x]; i; i=i->nxt)
#define mid ((l+r)>>1)
#define lson l,mid,t<<1
#define rson mid+1,r,t<<1|1

int get()
{
    static const int S=1<<22|1;
    static char pool[S],*tp=pool;
    #define getchar() (tp<pool+S? 0:fread(tp=pool,1,S,stdin),*tp++)
    char c;
    while (!isdigit(c=getchar()) && c!='-');
    int s=c=='-'? -1:1,k=~s? c-'0':0;
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return s*k;
}

using namespace std;
typedef long long ll;

int main()
{
    freopen(".in","r",stdin);
    freopen(".out","w",stdout);
    return 0;
}
