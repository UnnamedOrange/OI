#include<bits/stdc++.h>
using namespace std;
bool is_rev(const string &s){
	int l=s.length();
	int p1=0,p2=l-1;
	while(p1<=p2){
		if(s[p1]!=s[p2])return false;
		++p1,--p2;
	}
	return true;
}
int curans;
inline bool dfs(const string &s,int step){
	//cout<<s<<" "<<step<<'\n';
	if(s==""){
		return true;
	}
	if(step>curans)return false;
	for(int i=0;i<s.length();++i){
		for(int j=s.length()-1;j>=i;--j){
			if(!is_rev(s.substr(i,j-i+1))){
				string s2=s;
				s2.erase(i,j-i+1);
				if(dfs(s2,step+1))return true;
			}
		}
	}
	return false;
}
inline void work1(int n,const string &s){
	for(curans=1;curans<=10;++curans){
		if(dfs(s,1)){
			cout<<curans<<'\n';
			break;
		}
	}
	if(curans>10)cout<<-1<<'\n';
}
inline bool check(const string &s){
	int p=0;
	while(s[p]==s[p+1])++p;
	if(p==s.length()-1){
		return false;
	}
	else{
		string s2=s;
		s2.erase(p,2);
		if(!is_rev(s2))return true;
		else return p!=0&&p!=s.length()/2-1;
	}
}
inline void work2(int n,const string s){
	if(!is_rev(s)){
		cout<<1<<'\n';
	}
	else{
		if(check(s))cout<<2<<'\n';
		else cout<<-1<<'\n';
	}
}
inline void work(){
	int n;
	cin>>n;
	string s;
	cin>>s;
	//cout<<s<<endl;
	if(n<=0){
		work1(n,s);
	}
	else work2(n,s);
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL),cout.tie(NULL);
	int t;
	cin>>t;
	while(t--){
		work();
	}
	return 0;
}
