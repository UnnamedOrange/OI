#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;
typedef long long ll;
const ll mod = 19260817;

int n, ans, flag = 0;
int a[30], b[30];

inline int fuck(int pos){
	int sum = 0;
	for(int i = 2; i <= pos + 1; i ++){
		if(b[i] - b[i - 1] != 1 && b[i] - b[i - 1] != -1) sum ++;
	}
	return sum;
}

void dfs(int cur, int pos){
	if(cur > ans || flag == 1) return;
	while(pos && b[pos] == pos) pos--;
	if(pos == 0){
		flag = 1;
		return;
	}
	if(fuck(pos) + cur > ans) return;
	for(int i = 2; i <= pos; i ++){
		for(int j = 1; j <= i / 2; j ++){
			swap(b[j], b[i - j + 1]);
		}
		dfs(cur + 1, pos);
		for(int j = 1; j <= i / 2; j ++){
			swap(b[j], b[i - j + 1]);
		}
	}
}

void solve(){
	for(int i = 0; i <= 50; i ++){
		ans = i; flag = 0;
		for(int j = 1; j <= n; j ++) b[j] = a[j];
		dfs(0, n);
		if(flag == 1){
			printf("%d\n", i);
			return;
		}
	}
}

int main(){
    freopen("sequence.in", "r", stdin);
    freopen("sequence.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i ++) scanf("%d", &a[i]);
		solve();
	}
	return 0;
}
