#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
const int mod=1000000007;
int x[100005];
ll fac[100005],inv[100005];
ll quick_mod(ll x,int y)
{
	ll ret=1;
	while(y)
	{
		if(y&1) ret=ret*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return ret;
}
ll c(ll n,ll m)
{
	return fac[n]*inv[m]%mod*inv[n-m]%mod;
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int n,a,b;
	cin>>n>>a>>b;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&x[i]);
		x[i]=x[i]/a;
	}
	int tot1=0,tot2=0;
	for(int i=1;i<=n;i++)
	{
		if(x[i]&1) tot1++;
		else tot2++;
	}
	fac[0]=inv[0]=1;
	for(int i=1;i<=n;i++)
	fac[i]=1LL*fac[i-1]*i%mod;
	inv[n]=quick_mod(fac[n],mod-2);
	for(int i=n-1;i;i--)
	{
		inv[i]=1LL*inv[i+1]*(i+1)%mod;
	}
	ll ans1=0,ans2=0;
	for(int i=0;i<=tot1;i++)
	{
		if(i&1)
		ans1+=c(tot1,i)*quick_mod(2,tot2)%mod;
		else
		ans2+=c(tot1,i)*quick_mod(2,tot2)%mod;
		ans1%=mod;ans2%=mod;
	}
	cout<<0<<" "<<0<<" "<<ans1<<" "<<ans2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
