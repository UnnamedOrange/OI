#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
#define nw(x) (x+n+2)
#define od(x) (x-n-2)
const int N=35,K=20;
int n,k,ans;
struct edge{int t,n;}E[N<<3];
int ft[N],tot;
int dp_vis[N][K],dpf[N][K];
int dp(int u,int p){
	if (p>k) return 0;
	if (dp_vis[u][p]) return dpf[u][p];
	dp_vis[u][p]=1;
	dpf[u][p]=1;
	go(u){
		int tp=0;
		rep(i,p+1,k) tp+=dp(v,i);
		dpf[u][p]*=tp;
	}
	return dpf[u][p];
}
void work_dp(int rt){
	memset(dp_vis,0,sizeof(dp_vis));
	rep(i,1,k) ans+=dp(rt,i);
}
int getsum(int u,int f=0){
	int s=1;
	go(u) if (v!=f) s+=getsum(v,u);
	return s;
}
int cov[N],cov2[N],vis[N];
void dfs_cov(int u,int &cv,int f=0){
	cv|=1<<u;
	go(u) if (!vis[v]&&v!=f) dfs_cov(v,cv,u);
}
void dfs_to_cov(int u){
	int ou=od(u);
	vis[ou]=1;
	dfs_cov(ou,cov[ou]);
	go(u) dfs_to_cov(v),cov2[ou]|=cov2[od(v)];
	cov2[ou]|=1<<ou;
}
int fa[N];
void add(int x,int y){
	E[++tot]=(edge){y,ft[x]},ft[x]=tot;
}
void work(){
	int rt;
	int oldtot=tot;
	rep(i,1,n) ft[nw(i)]=0;
	rep(i,1,n) add(nw(fa[i]),nw(i)),rt=!fa[i]?i:rt;
	tot=oldtot;
	if (getsum(nw(rt))!=n) return;
	memset(vis,0,sizeof(vis));
	memset(cov,0,sizeof(cov));
	memset(cov2,0,sizeof(cov2));
	dfs_to_cov(nw(rt));
	rep(i,1,n) if (cov[i]!=cov2[i]) return;
	work_dp(nw(rt));
}
void dfs(int d,int s0){
	if (d==n+1){
		if (s0) work();
		return;
	}
	rep(i,1,n) if (i!=d){
		fa[d]=i;
		dfs(d+1,s0);
	}
	fa[d]=0;
	if (!s0) dfs(d+1,1);
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	rep(i,2,n){
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y),add(y,x);
	}
	dfs(1,0);
	printf("%d\n",ans);
	return 0;
}

