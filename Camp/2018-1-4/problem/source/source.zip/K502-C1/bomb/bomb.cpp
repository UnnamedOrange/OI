#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue> 
#include <stack>
using namespace std;

struct edge
{
	int u;
	int v;
	int next;
};

const int MAXN = 1e6 + 200;
int n, m, kind, ans, dfx;
int in[MAXN], out[MAXN], depth[MAXN], c[MAXN], f[MAXN], visit[MAXN], dfn[MAXN], low[MAXN], first[MAXN];
int h[100000], st[100000];
edge e[MAXN];
vector<int> g[MAXN];
queue<int> q;
stack<int> s;

namespace DAG
{
	void tarjan(int p)
	{
		++dfx;
		dfn[p] = low[p] = dfx;
		visit[p] = 1;
		s.push(p);
		for (int i = first[p]; i != -1; i = e[i].next)
		{
			int v = e[i].v;
			if (visit[v] == 0)
			{
				tarjan(v);
				low[p] = min(low[p], low[v]);
			}
			else if (visit[v] == 1)
				low[p] = min(low[p], dfn[v]);
		}
		if (low[p] == dfn[p])
		{
			++kind;
			while (s.top() != p)
			{
				c[s.top()] = kind;
				++f[kind];
				visit[s.top()] = 2;
				s.pop();
			}
			++f[kind];
			c[p] = kind;
			visit[p] = 2;
			s.pop();
		}
	}
	void main()
	{
		for (int i = 1; i < n + 1; ++i)
		{
			if (visit[i] == 0)
				tarjan(i);
		}
		for (int i = 0; i < m; ++i)
		{
			int u = e[i].u, v = e[i].v;
			if (c[u] != c[v])
			{
				g[c[u]].push_back(c[v]);
				++in[c[v]];
			}
		}
		for (int i = 1; i < kind + 1; ++i)
		{
			if (in[i] == 0)
			{
				depth[i] = f[i];
				q.push(i);
			}	
		}
		while (!q.empty())
		{
			int now = q.front();
			q.pop();
			ans = max(ans, depth[now]);
			for (int i = 0; i < g[now].size(); ++i)
			{
				int v = g[now][i];
				--in[v];
				depth[v] = max(depth[v], depth[now] + f[v]);
				if (in[v] == 0)
					q.push(v);
			}
		}
		printf("%d\n", ans);
	}
}

namespace Dp
{
	int used[20];
	bool vis[20];
	void dfs(int val, int d)
	{
		bool ok = false;
		for (int i = d; i < n + 1; ++i)
		{
			if (used[i] == 0)
			{
				for (int j = 0; j < g[i].size(); ++j)
				{
					int v = g[i][j];
					++used[v];
				}
				bool se = true;
				for (int j = 1; j < n + 1; ++j)
				{
					if (((val >> (j - 1)) & 1) == 1 && used[j] > 0)
					{
						se = false;
						break;
					}
				}
				if (se)
				{
					ok = true;
					dfs(val | (1 << (i - 1)), i + 1);
				}
				for (int j = 0; j < g[i].size(); ++j)
				{
					int v = g[i][j];
					--used[v];
				}
			}
		}
		if (!ok)
			st[val] = true;
	}
	void bfs(int p, int o)
	{
	//	cerr << p << " " << o << endl;
		if (o != p)
		{
			g[o].push_back(p);
		//	g[p].push_back(o);
		}
		vis[p] = true;
		for (int i = first[p]; i != -1; i = e[i].next)
		{
			int v = e[i].v;
			if (!vis[v])
				bfs(v, o);
		}
	}
	void main()
	{
		for (int i = 1; i < n + 1; ++i)
		{
			memset(vis, 0, sizeof vis);
			bfs(i, i);
		}
/*		for (int i = 1; i < n + 1; ++i)
		{
			cerr << i << " begin" << endl;
			for (int j = 0; j < g[i].size(); ++j)
				cerr << g[i][j] << " ";
			cerr << endl;
		}*/

		memset(used, 0, sizeof used);
		dfs(0, 1);
		memset(h, 0x3f, sizeof h);
		h[0] = 0;
		vector<int> l;
		for (int i = 0; i < (1 << n); ++i)
		{
			if (st[i])
			{
				l.push_back(i);
		//		cerr << i << endl;
			}
		}
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < (1 << n); ++j)
			{
				for (int k = 0; k < l.size(); ++k)
				{
					int po = l[k];
					h[j | po] = min(h[j | po], h[j] + 1);
				}
			}
		}
		printf("%d\n", h[(1 << n) - 1]);
	}
}

void addedge(int u, int v)
{
	static int ctr = 0;
	e[ctr] = (edge){u, v, first[u]};
	first[u] = ctr;
	++ctr;
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	memset(first, -1, sizeof first);
	n = read();
	m = read();
	for (int i = 0; i < m; ++i)
	{
		int u = read(), v = read();
		addedge(u, v);
	}
	if (n <= 10)
		Dp::main();
	else
		DAG::main();
	fclose(stdin);
	fclose(stdout);
}
