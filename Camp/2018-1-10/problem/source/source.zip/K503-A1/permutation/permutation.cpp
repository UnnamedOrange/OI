#include<bits/stdc++.h>
using namespace std;
const int p=998244353;
typedef long long ll;
int n,a[200],h[2000],ans;
bool ha[20];
void check(){
	memset(ha,0,sizeof(ha));
	for (int i=1;i<=n;i++)
	if (!ha[i]){
		int x=i,t=0;
		while (!ha[x]){ha[x]=1;t++;x=a[x];}
		if (t&1) return;
	}
	ans++;
}
void work(int dep){
	if (dep>n) {check();return;}
	if (a[dep]) work(dep+1);
	else{
		for (int i=1;i<=n;i++) 
		if (!h[i]){h[i]=1;a[dep]=i;work(dep+1);h[i]=0;}
		a[dep]=0;
	}
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d\n",&n);
	if (n<=8){
		for (int i=1;i<=n;i++){
		scanf("%d",a+i);
		h[a[i]]=1;
		}
		work(1);
	}
	else {
		ans=1;
		for (int i=1;i<=n;i+=2)	ans=(ll)ans*i%p;
		ans=(ll)ans*ans%p;
	}
	printf("%d\n",ans);
	return 0;
}
