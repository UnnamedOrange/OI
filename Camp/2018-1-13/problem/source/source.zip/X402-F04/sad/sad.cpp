//2018-1-13
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N (50000+5)
const int P = 998244353;

int inv;
vector<int> G[N];
char s[N];
bool col[N];

int Dfs(int now, int F){
	For(i, 0, G[now].size()-1)
		if(G[now][i] != F) return Dfs(G[now][i], now)+1;
}

	void Solve(int n1, int &a, int &b){
	int ta, tmp;
	a = inv, b = 1;

	Forr(i, n1-2, 1){
		ta = Mul(a, inv); tmp = Mod(1 - ta);
		a = inv; b = Mod(Mul(inv*b) + 1);
		a = Mul(a, Pow(tmp, P-2)); b = Mul(b, Pow(tmp, P-2));
	}
}

int Calc(int n, int v){

}

int main(){
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	
	int n, u, v;

	scanf("%d%s", &n, s+1);
	For(i, 1, n) col[i] = s[i] == '1';
	
	For(i, 1, n-1){
		scanf("%d%d", &u, &v); G[u].pb(v); G[v].pb(u);
	}

	int tot1 = Dfs(G[1][0], 1), tot2 = Dfs(G[1][1], 1), a1, a2, b1, b2;
	Solve(tot1, a1, b1); Solve(tot2, a2, b2);
		
	int tmp = Mul(inv, Mod(a1 + a2)), b = Mul(inv, Mod(b1 + b2 + 1));
	tmp = Mod(1 - tmp); b = Mul(b, Pow(tmp, P-2));

	printf("%d\n", Mod(Calc(tot1, b) + Calc(tot2, b)));

	return 0;
}
