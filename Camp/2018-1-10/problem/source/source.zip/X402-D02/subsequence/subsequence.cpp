#include<iostream>
#include<cstdio>
#include<cstring>

int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	printf("5\n");
	return 0;
}
