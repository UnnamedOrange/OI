#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <bitset>
#include <cstdio>
#include <queue>
#include <cmath>
using namespace std;

const int MAXN = 1e5 + 100;
int n, Q, T;
int c[MAXN], dfn[MAXN], End[MAXN], in[MAXN], oc[MAXN];
bool visit[6000];
bitset<51000> vis;
vector<int> e[MAXN];

int read()
{
	int x = 0;
	char ch = getchar();
	while (ch != '-' && (ch > '9' || ch < '0'))
		ch = getchar();
	int w = 1;
	if (ch == '-')
	{
		ch = getchar();
		w = -1;
	}
	while (ch >= '0' && ch <= '9')
	{
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

namespace Force
{
	bool mark = false;
	int ret = 0;
	void query(int p, int fa, int o, int l, int r)
	{
		if (p == o)
			mark = true;
		if (mark && c[p] >= l && c[p] <= r)
		{
			ret += !visit[c[p]];
			visit[c[p]] = true;
		}
		//if (mark && o == 1)
		//		cerr << c[p] << endl;
		for (int i = 0; i < e[p].size(); ++i)
		{
			int v = e[p][i];
			if (v != fa)
				query(v, p, o, l, r);
		}
		if (p == o)
			mark = false;
	}
	void main()
	{
		long long lastans = 0;
		for (int i = 0; i < Q; ++i)
		{
			int opt = read();
			if (opt == 1)
			{
				int u = read(), l = read(), r = read();
				if (T == 1)
				{
					u ^= lastans;
					l ^= lastans;
					r ^= lastans;
				}
				memset(visit, 0, sizeof visit);
				query(1, 0, u, min(l, r), max(l, r));
				lastans = ret;
				ret = 0;
				printf("%lld\n", lastans);
			}
			else
			{
				int u = read(), v = read();
				if (T == 1)
				{
					u ^= lastans;
					v ^= lastans;
				}
				c[u] = v;
			}
		}
	}
}

namespace Bitset
{
	int dfx = 0, sz = 0, num = 0;
	void dfs(int p, int fa)
	{
		++dfx;
		dfn[p] = dfx;
		oc[dfx] = c[p];
		for (int i = 0; i < e[p].size(); ++i)
		{
			int v = e[p][i];
			if (v != fa)
				dfs(v, p);
		}
		End[p] = dfx;
	}
	int query(int x, int l, int r)
	{
		int y = End[x];
		x = dfn[x];
		vis = 0;
		for (int i = x; i < y + 1; ++i)
		{
			if (oc[i] >= l && oc[i] <= r)
				vis[oc[i]] = 1;
		}
		return vis.count();
	}
	void main()
	{
		dfs(1, 0);
		long long lastans = 0;
		for (int i = 0; i < Q; ++i)
		{
			int opt = read();
			if (opt == 1)
			{
				int u = read(), l = read(), r = read();
				if (T == 1)
				{
					u ^= lastans;
					l ^= lastans;
					r ^= lastans;
				}
				lastans = query(u, l, r);
				printf("%lld\n", lastans);
			}
			else
			{
				int u = read(), v = read();
				if (T == 1)
				{
					u ^= lastans;
					v ^= lastans;
				}
				oc[dfn[u]] = v;
			}
		}
	}
}

int main()
{
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	n = read();
	Q = read();
	T = read();
	for (int i = 1; i < n + 1; ++i)
	{
		c[i] = read();
		oc[i] = c[i];
	}
	for (int i = 1; i < n; ++i)
	{
		int u = read(), v = read();
		e[u].push_back(v);
		e[v].push_back(u);
	}
	if (n <= 5000)
		Force::main();
	else
		Bitset::main();
	fclose(stdin);
	fclose(stdout);
}
