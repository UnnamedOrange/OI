#include <cstdio>
#include <algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=20;
int n,i,j,u,v,ans,w[N],r[N],ok[N],near[N];
int En,fst[N],nxt[N*2],to[N*2];
void add(int u,int v) {
	En++; nxt[En]=fst[u]; fst[u]=En; to[En]=v;
}
void dfs(int x,int val)
{
	if (x>n) {
		ans=max(ans,val);
		return;
	}
	int i,j;
	rep(i,1,n)
	  if (ok[i]==1)
	  {
	  	 ok[i]=2;
	  	 for (j=fst[i];j;j=nxt[j])
		   if (ok[to[j]]!=2) ok[to[j]]=1,near[to[j]]++;
		 dfs(x+1,val+w[i]*x);
		 for (j=fst[i];j;j=nxt[j])
		   if (ok[to[j]]==1) {
		   	  near[to[j]]--; if (!near[to[j]]) ok[to[j]]=0;
		   }
		 ok[i]=1;
	  }
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	rep(i,1,n-1) {
	  scanf("%d%d",&u,&v);
      add(u,v); add(v,u);
	}
	rep(i,1,n) scanf("%d%d",&w[i],&r[i]);
	rep(i,1,n)
	  if (r[i]) {
	    ok[i]=2;
	    for (j=fst[i];j;j=nxt[j])
	      ok[to[j]]=1,near[to[j]]++;
		dfs(2,w[i]);
		ok[i]=0;
      }
    printf("%d\n",ans);
	return 0;
}
