#include <bits/stdc++.h>

int main()
{
	freopen("sequence.in", "w", stdout);
	int T = 5, n = 23;
	srand(time(0)); printf("%d\n", T);
	while(T--){
		int vis[30]; 
		memset(vis, 0, sizeof vis); vis[0] = 1;
		printf("%d\n", n);
		for(int i = 1; i <= n; ++i){
			int x = 0;
			while(vis[x]) x = rand() % n + 1;
			vis[x] = 1; printf("%d ", x);
		}
		puts("");
	}
	return 0;
}
