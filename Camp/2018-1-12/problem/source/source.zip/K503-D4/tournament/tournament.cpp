#include<bits/stdc++.h>
#define maxn 100
#define mod 998244353
#define ll long long
using namespace std;
int s[maxn], t[maxn], ch[maxn], k, tot, head[maxn], nxt[maxn], a[maxn], edge;
int n, ans, dep[maxn], flag, visit[maxn], ci = 0;
void create(int u, int v)
{
	edge++; a[edge] = v; nxt[edge] = head[u]; head[u] = edge;
}
void dfs(int u)
{
	visit[u] = 1;
	for (int i = head[u]; i; i = nxt[i])
	{
		int v = a[i];
		if (visit[v] == 0)
		{
			dep[v] = dep[u] + 1;
			dfs(v);
		}
		else if (v == 1 && dep[u] == n) flag = 1; 
	}
}
void sc()
{
	for (int i = 1; i <= n; i++) head[i] = visit[i] = 0;
	edge = flag = 0;
	for (int i = 1; i <= tot; i++)
		if (ch[i] == 0) create(s[i], t[i]);
		else create(t[i], s[i]);
	dep[1] = 1; dfs(1);
	if (flag) ans++;
}
void work(int dep)
{
	if (dep > tot) sc();
	else
	for (int i = 0; i <= 1; i++)
	{
		ch[dep] = i;
		work(dep + 1);
	}
}
ll mi(ll a, ll k)
{
	ll ans = 1;
	while (k)
	{
		if (k % 2) ans = ans * a % mod;
		a = a * a % mod;
		k /= 2;
	}
	return ans;
}
void subtask1()
{
	ll tmp = (ll)n * (n - 1) / 2, ans = mi(2, tmp), cnt = 1 ;
	for (int i = 1; i <= n; i++)
		cnt = cnt * i % mod;
	ans = ((ans - cnt) % mod + mod) % mod;
	printf("%lld\n", ans);
}
int main()
{
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	scanf("%d%d", &n, &k);
	if (k == 3)
	{
		subtask1();
		return 0;
	}
	for (int i = 1; i <= n; i++)
		for (int j = i + 1; j <= n; j++)
		{
			s[++tot] = i; t[tot] = j; 
		}
	work(1);
	printf("%d\n", ans);
	return 0;
}
