#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 100010
using namespace std;
int pos[maxn],c[maxn],id[maxn],col[maxn],n,lastans,q,t,cnt,sz[maxn];
int num,head[maxn];
bool vis[maxn],v[maxn];
struct node{
	int to,pre;
}e[maxn*2];
void Insert(int from,int to){
	e[++num].to=to;
	e[num].pre=head[from];
	head[from]=num;
}
void dfs(int now){
	vis[now]=1;pos[now]=++cnt;id[cnt]=now;col[cnt]=c[now];
	sz[now]=1;
	for(int i=head[now];i;i=e[i].pre){
		int to=e[i].to;
		if(vis[to])continue;
		dfs(to);
		sz[now]+=sz[to];
	}
}
int ask(int rot,int l,int r){
	memset(v,0,sizeof(v));
	int res=0;
	for(int i=1,j=pos[rot];i<=sz[rot];i++,j++)
		if(col[j]<=r&&col[j]>=l&&!v[col[j]])res++,v[col[j]]=1;
	return res;
}
int qread(){
	int i=0,j=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')j=-1;ch=getchar();}
	while(ch<='9'&&ch>='0')i=i*10+ch-'0',ch=getchar();
	return i*j;
}
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("xmastree1.in","r",stdin);freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	int x,y; 
	for(int i=1;i<=n;i++)scanf("%d",&c[i]);
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		Insert(x,y);Insert(y,x);
	}
	dfs(1);
	if(t==1){
		int opt,z;
		for(int i=1;i<=q;i++){
			scanf("%d",&opt);
			if(opt==1){
				scanf("%d%d%d",&x,&y,&z);
				x^=lastans;y^=lastans;z^=lastans;
				lastans=ask(x,y,z);
				printf("%d\n",lastans);
			}
			if(opt==2){
				scanf("%d%d",&x,&y);
				x^=lastans;y^=lastans;
				col[pos[x]]=y;
			}
		}
	}
	if(t==0){
		int opt,z;
		for(int i=1;i<=q;i++){
			scanf("%d",&opt);
			if(opt==1){
				scanf("%d%d%d",&x,&y,&z);
				lastans=ask(x,y,z);
				printf("%d\n",lastans);
			}
			if(opt==2){
				scanf("%d%d",&x,&y);
				col[pos[x]]=y;
			}
		}
	}
	return 0;
}
