#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
#include<vector>
#include<set>
#include<map>
#include<queue>
#define all(x) (x).begin(),(x).end()
#define ll long long
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
#define vi vector<int>
#define setfile(s) freopen(#s".in","r",stdin),freopen(#s".out","w",stdout)
using namespace std;
vi e[30010];int n,w[30010],r[30010],vis[30010],val[30010],siz[30010];
struct item{
	int x;item(int X=0):x(X){}
	bool operator<(const item&that)const{return 1ll*siz[that.x]*val[x]>1ll*siz[x]*val[that.x];}
};
priority_queue<item> pq;
void dfs(int u,int fa){
	val[u]=w[u];siz[u]=1;
	for(auto v:e[u])
		if(v!=fa)dfs(v,u),val[u]+=val[v],siz[u]+=siz[v];
}
int main(){
	setfile(xmastree2);
	scanf("%d",&n);
	for(int i=1;i<n;++i){
		int u,v;
		scanf("%d%d",&u,&v);
		e[u].pb(v),e[v].pb(u);
	}
	for(int i=1;i<=n;++i)scanf("%d%d",w+i,r+i);
	int ans=0;
	for(int i=1;i<=n;++i)
		if(r[i]){
			dfs(i,0);
			pq.push(item(i));
			int p=0;
			int res=0;
			while(!pq.empty()){
				++p;
				int u=pq.top().x;pq.pop();
				//std::cerr<<"u : " << u << " val = " << val[u] << std::endl;
				res+=w[u]*p;vis[u]=1;
				for(auto v:e[u])
					if(!vis[v])pq.push(item(v));
			}
			ans=max(ans,res);
		}
	printf("%d\n",ans);
	return 0;
}

