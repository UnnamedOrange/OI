#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl 
using namespace std;
const int maxn = 100009;
const int mod = 998244353;

vector<int> to[maxn];
int a[maxn],p[maxn],du[maxn];
bool vis[maxn];
int n,cnt;

bool check()
{
	for(int i=1;i<=n;i++) if(a[i]&&p[i]!=a[i]) return false;
	for(int i=1;i<=n;i++)
	{
		int cnt=1;
		for(int j=p[i];j!=i;j=p[j]) cnt++;
		if(cnt&1) return false;
	}
	return true;
}

void work2()
{
	int tot=0,tmp=0;
	for(int i=1;i<=n;i++) if(!vis[i]&&a[i])
	{
		cnt=1;vis[i]=1;
		int now=a[i];
		while(now!=i&&now) now=a[now],cnt++;
		if(now==0) continue;
		if(cnt&1)
		{
			puts("0");
			return ;
		}
	}
	for(int i=1;i<=n;i++) if(du[i]==0)
	{
		cnt=1;
		int x=i;
		while(a[x]) x=a[x],cnt++;
		if(cnt&1) tot++;
		else tmp++;
	}
	int res=1;
	for(int i=1;i<=tot;i+=2) res=1ll*res*i%mod;
	res=1ll*res*res%mod;
	for(int i=1;i<=tmp;i++)
	{
		tot++;
		res=1ll*res*tot%mod;
	}
	cout<<res<<endl;
/*	int ans=0;
	for(int i=1;i<=n;i++) p[i]=i;
	do
	{
		if(check()) ans++;
	}while(next_permutation(p+1,p+1+n));
	cout<<ans<<endl;*/
}
void work1()
{
	int res=1;
	for(int i=1;i<=n;i+=2) res=1ll*res*i%mod;
	res=1ll*res*res%mod;
	cout<<res<<endl;
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	if(n&1){puts("0");return 0;}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		cnt+=(a[i]==0);
		if(a[i])
		{
			du[a[i]]++;
			to[i].push_back(a[i]);
		}
	}
	if(cnt==n) work1();
	else work2();
	return 0;
}
