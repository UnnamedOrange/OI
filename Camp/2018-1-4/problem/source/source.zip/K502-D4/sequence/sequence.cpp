#include<bits/stdc++.h>
#define rep(a,b,c) for(int a=b;a<=c;a++)
#define per(a,b,c) for(int a=b;a>=c;a--)
using namespace std;
int t,n,a[30],ans;
int finda(int f) {
	rep(i,1,n) if(a[i]==f) return i; }
void fan(int x) {
	if(x==1) return;
	ans++;
	rep(i,1,x/2) {
		int tt=a[i];
		a[i]=a[x-i+1];
		a[x-i+1]=tt; } }
void fanqj(int x1,int x2) {
	if(rand()%5==0) return;
	if(x1>=x2) return;
	fan(x2);
	if(x1!=1) {
		fan(x2-x1+1);
		fan(x2); } }
bool checkdul(int x1,int x2) {
	if(x1>=x2) return false;
	rep(i,x1,x2)
	if(a[i]!=x1+x2-i)
		return false;
	return true; }
int tans;
int main() {
	srand((int)new char);
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&t);
	int b[30];
	while(t--) {
		scanf("%d",&n);
		rep(i,1,n) scanf("%d",&b[i]);
		tans=0x3f3f3f3f;
		rep(ti,1,100) {
			rep(i,1,n) a[i]=b[i];
			ans=0;
			per(i,n,1) {
				int tl=1,tr;
				bool flag=0;
				rep(j,1,n) {
					if (a[j]==j) {
						if(flag==1) {
							tr=j-1;
							if(checkdul(tl,tr))
								fanqj(tl,tr); }
						flag=0; }
					else {
						if(flag==0)
							tl=j;
						flag=1;
						if(a[j]>a[j-1]) {
							tl=j;
							if(checkdul(tl,j-1))
								fanqj(tl,j-1); } } }
				if(flag==1)
					if(checkdul(tl,n))
						fanqj(tl,n);
				int loc=finda(i);
				if(loc==i) continue;
				fan(loc);
				fan(i); }
			tans=min(tans,ans); }
		printf("%d\n",tans); }
	return 0; }
