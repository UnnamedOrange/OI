#include<bits/stdc++.h>
using namespace std;

const int maxn=1010;
int a[maxn][10];
int n;

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

void init(){
	for(int i=1;i<=n;i++)
		for(int j=0;j<10;j++) if(i & (1<<j)) a[i][j]=1;
}

int encode(int x,int y){
	for(int i=0;i<10;i++) if(a[x][i] != a[y][i]) return (i<<1) | (a[x][i]);
}
int decode(int x,int y){
	y--;
	return a[x][y>>1] == (y&1);
}

int main(){
	//freopen("xmasset.in","r",stdin),freopen("xmasset.out","w",stdout);

	int T, op, x, y;
	read(op), read(n), read(T);
	init();
	while(T--){
		read(x); read(y);
		if(op==1) printf("%d\n", encode(x, y)+1);
		else printf("%s\n", decode(x, y) ? "yes" : "no");
	}
	return 0;
}
