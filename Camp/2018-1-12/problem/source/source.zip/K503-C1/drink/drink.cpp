# include <bits/stdc++.h>
# define 	N 		1000100
# define 	eps 	1e-8
# define 	T 		100
using namespace std;
struct node{
	int p,num;
}a[N];
int n,pre[N],nex[N];
double ans;
bool cmp(node x, node y){
	return x.num<y.num||x.num==y.num&&x.p<y.p;
}
int read(){
	int tmp=0,fh=1; char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') fh=-1; ch=getchar();}
	while (ch>='0'&&ch<='9'){tmp=tmp*10+ch-'0'; ch=getchar();}
	return tmp*fh;
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for (int i=1; i<=n; i++) {
		a[i].num=read();
		a[i].p=i;
	}
	sort(a+1,a+n+1,cmp);
	for (int i=2; i<=n; i++) pre[i]=i-1;
	for (int i=1; i<n; i++) nex[i]=i+1;
	
	for (int t=1; t<=n; t++){
		int i=a[t].p;
		double num=a[t].num/2.0,sum=0;
		for (int j=i, k=1, la; j!=n+1&&k<=T; j=la+1,k++){
			la=nex[j]-1; if (la==-1) la=n;
			sum=sum+num*(la-j+1), num/=2;
		}
	//	printf("%lf\n",sum);
		for (int j=i, k=1, la; j!=0&&k<=T; j=la-1,k++){
			la=pre[j]+1;
			ans=ans+sum*(j-la+1); sum=sum/2;
		}
	//	printf("%lf\n",ans);
		nex[pre[i]]=nex[i]; pre[nex[i]]=pre[i];
	}
	printf("%.16lf\n",ans/n/n);
	return 0;
}

