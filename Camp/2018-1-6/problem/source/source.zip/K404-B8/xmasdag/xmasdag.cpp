#include<bits/stdc++.h>
#define debug(x) cerr<<#x<<"="<<x<<endl
using namespace std;
const int N = 100009, M = 39;
const int mod = 998244353;

vector<int> to[N];
int du[N],f[N][M],C[M][M];
int n,m,k;
queue<int>q;
// f[i][j] : for i sigma l^j

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
char buff[100];
inline void print(int x)
{
	int len=0;
	while(x){buff[++len]=x%10;x/=10;}
	if(len==0) putchar('0');
	for(int i=len;i>=1;i--) putchar(buff[i]+'0');
	puts("");
}
inline void update(int &x,int y)
{
	x += y;
	x -= x >= mod ? mod : 0;
}

inline void work(int x,int y)
{
	for(int i=0;i<=k;i++)
		for(int j=0;j<=i;j++)
			update(f[x][i],1ll*f[y][j]*C[i][j]%mod);
}

void topsort()
{
	q.push(1);f[1][0]=1;
	while(!q.empty())
	{
		int x=q.front(),sz=to[x].size();q.pop();
		for(int i=0;i<sz;i++)
		{
			int w=to[x][i];
			work(w,x);du[w]--;
			if(du[w]==0) q.push(w);
		}
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=0;i<=k;i++)
	{
		C[i][0]=1;
		for(int j=1;j<=i;j++) C[i][j]=(C[i-1][j-1]+C[i-1][j])%mod;
	}
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();
		to[x].push_back(y);du[y]++;
	}
	topsort();
	for(int i=1;i<=n;i++) print(f[i][k]);
	return 0;
}
