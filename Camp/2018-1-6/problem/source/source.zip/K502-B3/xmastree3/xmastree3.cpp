#include <stdio.h>
#include <string.h>

const int maxn=101,mod=998244353;
long long int first[maxn],nxt[maxn],to[maxn],father[maxn],label[maxn]; 
long long int n,k,cnt;

inline long long int read()
{
    char ch;
    bool flag=false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void clear()
{
	memset(first,-1,sizeof(first));
	cnt=0;
}

void add(long long int ui,long long int vi)
{
	nxt[cnt]=first[ui];
	first[ui]=cnt;
	to[cnt]=vi;
	cnt++;
}

int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	n=read(),k=read();
	long long int i;
	for(i=1;i<=n-1;i++)
	{
		long long int ui=read(),vi=read();
		add(ui,vi);
		add(vi,ui);
	}
	printf("%lld",(n*k)%mod);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
