#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)

using namespace std;
typedef long long ll;
const int p=1e9+7,N=1e6+10;
ll s;
int n,m,t,fac[N],ifc[N],ans;

int c(int n,int m)
{
    return 1ll*fac[n]*ifc[m]%p*ifc[n-m]%p;
}

int inv(int x)
{
    return x>1? 1ll*(p-p/x)*inv(p%x)%p:1;
}

int main()
{
    freopen("success.in","r",stdin);
    freopen("success.out","w",stdout);
    scanf("%lld%d%d%d",&s,&t,&n,&m);
    fac[0]=1;
    rep(i,1,s)
        fac[i]=1ll*fac[i-1]*i%p;
    ifc[s]=inv(fac[s]);
    repd(i,s,1)
        ifc[i-1]=1ll*ifc[i]*i%p;
    rep(i,0,n)
        ans=(ans+(i&1? -1ll:1ll)*c(n,i)*c(s-i*t,m))%p;
    printf("%d",(ans+p)%p);
    return 0;
}
