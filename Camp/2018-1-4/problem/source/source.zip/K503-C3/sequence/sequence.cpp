#include <bits/stdc++.h>
#define N 30
using namespace std;
int t,n,pos,ans,a[N];

int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&t);
	while (t--){
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		ans=0;
		for (int i=n;i;i--){
		//	printf("%d\n",i);
			for (int j=1;j<=n;j++)
				if (a[j]==i){
					pos=j; break;
				}
			if (pos==i) continue;
			ans+=(pos==1?1:2);
			for (int j=1;j<=pos/2;j++)
				swap(a[j],a[pos-j+1]);
		//	for (int j=1;j<=n;j++)
		//		printf("%d ",a[j]);
		//	puts("");
			for (int j=1;j<=i/2;j++)
				swap(a[j],a[i-j+1]);
		//	for (int j=1;j<=n;j++)
		//		printf("%d ",a[j]);
		//	puts("");
		}
		printf("%d\n",ans);
	}
	return 0;
}
