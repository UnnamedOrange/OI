#include<bits/stdc++.h>
#define maxn 1100000
using namespace std;
struct bian{int u,v;};
int head[maxn],next[maxn],a[maxn],low[maxn],dfn[maxn],edge,color[maxn],sta[maxn],top,now,newedge,
insta[maxn],tot,sep[maxn],size[maxn],ru[maxn],dl[maxn],f[maxn],child[maxn];
bian E[maxn];
bool cmp(bian a, bian b){return a.u<b.u;}
int read()
{
	char c=getchar(); int tmp=0;
	while (c<'0' || c>'9') c=getchar();
	while (c>='0' && c<='9')
	{
		tmp=tmp*10+c-'0'; c=getchar();
	}
	return tmp;
}
void create(int u, int v)
{
	edge++; a[edge]=v; next[edge]=head[u]; head[u]=edge;
}
void tarjan(int u)
{
	low[u]=dfn[u]=++now;
	sta[++top]=u; color[u]=1; insta[u]=1;
	for (int i=head[u];i;i=next[i])
	{
		int v=a[i];
		if (color[v]==0)
		{
			tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if (insta[v]) low[u]=min(low[u],dfn[v]);
	}
	if (low[u]==dfn[u])
	{
		tot++;
		while (sta[top]!=u)
		{
			sep[sta[top]]=tot; size[tot]++;
			insta[sta[top]]=0; top--;
		}
		sep[u]=tot; size[tot]++;
		insta[u]=0; top--;
	}
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int n,m;
	n=read(); m=read();
	for (int i=1;i<=m;i++)
	{
		int u,v;
		u=read(); v=read();
		create(u,v);
	}
	for (int i=1;i<=n;i++)
		if (color[i]==0) tarjan(i);
	for (int u=1;u<=n;u++)
		for (int i=head[u];i;i=next[i])
		{
			int v=a[i];
			if (sep[u]!=sep[v])
			{
				E[++newedge]=(bian){sep[u],sep[v]};
				ru[sep[v]]++;
			}
		}
	sort(E+1,E+newedge+1,cmp);
	for (int i=1;i<=E[1].u;i++)
		child[i]=1;
	for (int i=2;i<=newedge;i++)
		for (int j=E[i-1].u+1;j<=E[i].u;j++)
			child[j]=i;
	for (int i=E[newedge].u+1;i<=tot+1;i++)
		child[i]=newedge+1;
	int lef=1,righ=0;
	for (int i=1;i<=tot;i++)
		if (ru[i]==0)
		{
			dl[++righ]=i;
			f[i]=size[i];
		}
	while (lef<=righ)
	{
		int u=dl[lef];
		for (int i=child[u];i<=child[u+1]-1;i++)
		{
			int v=E[i].v;
			ru[v]--; f[v]=max(f[v],f[u]);
			if (ru[v]==0)
			{
				dl[++righ]=v;
				f[v]+=size[v];
			}
		}
		lef++;
	}
	int ans=0;
	for (int i=1;i<=tot;i++)
		ans=max(ans,f[i]);
	printf("%d\n",ans);
	return 0;
}
