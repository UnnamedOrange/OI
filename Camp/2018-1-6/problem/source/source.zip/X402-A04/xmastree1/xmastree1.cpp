#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
int head[N+1],cnt=0;
struct node
{
	int to,next;
}e[N<<1|1];
inline void addedge(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}
int n,col[N+1],siz[N+1],ans[N+1],dfn[N+1],dfs_clk=0,rnk[N+1],f[N+1][21];

namespace seg
{
	int ch[N*60+1][2],sum[N*60+1],sz,rt[N+1]; //72MB
	inline void update(int &o,int l,int r,int x,int k)
	{
		if(!o) o=++sz;
		sum[o]+=k;
		if(l==r) return ;
		int mid=l+r>>1;
		if(x<=mid) update(ch[o][0],l,mid,x,k);
		else update(ch[o][1],mid+1,r,x,k);
		//sum[o]=sum[ch[o][0]]+sum[ch[o][1]];
		//if(x==dfn[2]) cout<<sum[o]<<' '<<k<<endl;
	}
	inline int query(int o,int l,int r,int x,int y)
	{
		if(!o) return 0;
		//if(!sum[o]) return 0;
		if(x<=l&&r<=y) return sum[o];
		int mid=l+r>>1,ans=0;
		if(x<=mid) ans+=query(ch[o][0],l,mid,x,y);
		if(y>mid) ans+=query(ch[o][1],mid+1,r,x,y);
		return ans;
	}
}

namespace bitseg
{
	int ch[N*340+1][2],sum[N*340+1],rt[N+1],sz; //420MB-
	inline void update(int &o,int l,int r,int x,int k)
	{
		if(!o) o=++sz;
		sum[o]+=k;
		if(l==r) return ;
		int mid=l+r>>1;
		if(x<=mid) update(ch[o][0],l,mid,x,k);
		else update(ch[o][1],mid+1,r,x,k);
		//sum[o]=sum[ch[o][0]]+sum[ch[o][1]];
	}
	inline int query(int o,int l,int r,int x,int y)
	{
		if(!o) return 0;
		//if(!sum[o]) return 0;
		if(x<=l&&r<=y) return sum[o];
		int mid=l+r>>1,ans=0;
		if(x<=mid) ans=query(ch[o][0],l,mid,x,y);
		if(y>mid) ans+=query(ch[o][1],mid+1,r,x,y);
		return ans;
	}
	inline void add(int c,int x,int k)
	{
		for(int i=c;i<=n;i+=(i&-i)) update(rt[i],1,n,x,k);
	}
	inline int ask(int cl,int cr,int l,int r)
	{
		int ans=0;
		for(int i=cr;i;i-=(i&-i)) ans+=query(rt[i],1,n,l,r);
		for(int i=cl-1;i;i-=(i&-i)) ans-=query(rt[i],1,n,l,r);
		return ans;
	}
}

void subcol(int x,int c)
{
	int u=x;
	for(int i=17;i>=0;--i) if(f[u][i])
	{
		int fa=f[u][i];
		if(seg::query(seg::rt[c],1,n,dfn[fa],dfn[fa]+siz[fa]-1)==1) u=f[u][i];
	}
	if(u==x) 
	{
		if(seg::query(seg::rt[c],1,n,dfn[x],dfn[x]+siz[x]-1)==1)
		{
			bitseg::add(c,dfn[x],-1);
			if(f[x][0]) bitseg::add(c,dfn[f[x][0]],1);
		}
		seg::update(seg::rt[c],1,n,dfn[x],-1);
		return ;
	}
	seg::update(seg::rt[c],1,n,dfn[x],-1);
	bitseg::add(c,dfn[x],-1);
	if(f[u][0]) bitseg::add(c,dfn[f[u][0]],1);
}

void addcol(int x,int c)
{
	int u=x;
	for(int i=17;i>=0;--i) if(f[u][i])
	{
		int fa=f[u][i];
		if(!seg::query(seg::rt[c],1,n,dfn[fa],dfn[fa]+siz[fa]-1)) u=f[u][i];
	}
	/*if(x==3) 
	{
		cerr<<x<<' '<<u<<endl;
		cerr<<seg::query(seg::rt[1],1,n,dfn[5],dfn[5]+siz[5]-1)<<endl;
	}*/
	if(u==x) 
	{
		if(!seg::query(seg::rt[c],1,n,dfn[x],dfn[x]+siz[x]-1))
		{
			bitseg::add(c,dfn[x],1);
			if(f[x][0]) bitseg::add(c,dfn[f[x][0]],-1);
		}
		seg::update(seg::rt[c],1,n,dfn[x],1);
		return ;
	}
	seg::update(seg::rt[c],1,n,dfn[x],1);
	bitseg::add(c,dfn[x],1);
	if(f[u][0]) bitseg::add(c,dfn[f[u][0]],-1);
}

void dfs(int u,int fa)
{
	siz[u]=1; dfn[u]=++dfs_clk; rnk[dfs_clk]=u; f[u][0]=fa;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,u);
		siz[u]+=siz[v];
	}
}
void dfs2(int u,int fa)
{
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs2(v,u);
	}
	addcol(u,col[u]);
}

void wj()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T,typ;
	//seg::sz=0; seg::sum[0]=0;
	//cerr<<(sizeof(bitseg::ch)+sizeof(bitseg::sum)+sizeof(seg::ch)
	//+sizeof(seg::sum)+sizeof(f))<<endl;
	n=read(); T=read(); typ=read();
	for(i=1;i<=n;++i) col[i]=read();
	for(i=1;i<n;++i)
	{
		int x=read(),y=read();
		addedge(x,y);
	}
	dfs(1,0);
	for(j=1;j<=17;++j) for(i=1;i<=n;++i) f[i][j]=f[f[i][j-1]][j-1];
	dfs2(1,0);
	//cerr<<bitseg::ask(1,n,dfn[4],dfn[4]+siz[4]-1)<<endl;
	//return 0;
	int lastans=0;
	for(int cas=1;cas<=T;++cas)
	{
		opt=read();
		if(opt==1)
		{
			int u=read(),l=read(),r=read();
			if(typ) u^=lastans,l^=lastans,r^=lastans;
			lastans=bitseg::ask(l,r,dfn[u],dfn[u]+siz[u]-1);
			printf("%d\n",lastans);
		}
		else
		{
			int u=read(),c=read();
			if(typ) u^=lastans,c^=lastans;
			subcol(u,col[u]); 
			col[u]=c;
			addcol(u,col[u]);
		}
	}
	//cerr<<bitseg::sz<<' '<<seg::sz<<endl;
	return 0;
}
