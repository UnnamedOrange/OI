#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

const int N = 30;

int n, D, P[N];

int check(){
	int ret = 0;
	For(i, 1, n - 1) if(abs(P[i + 1] - P[i]) != 1) ++ret;
	return ret;
}

bool DFS(int d){
	if(d + check() > D) return false;
	if(d == D){
		For(i, 1, n) if(P[i] ^ i) return false;
		return true;
	}
	For(i, 2, n){
		reverse(P + 1, P + i + 1);
		if(DFS(d + 1)) return true;
		reverse(P + 1, P + i + 1);
	}
	return false;
}

int main(){

	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);

	int Case;
	scanf("%d", &Case);
	while(Case--){
		
		scanf("%d", &n);
		For(i, 1, n) scanf("%d", &P[i]);

		for(D = 0; ; ++D) if(DFS(0)){
			printf("%d\n", D);
			break;
		}

	}

	return 0;
}
