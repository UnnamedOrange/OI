#include<cstdio>
using namespace std;

const int mod = 1e9 + 7;
unsigned long long ans;
int s, t, n, m, al, lin, which, ano, a1, a2;
int F[2][1025000];
int tri[2][1025000]; 

inline void prepare()
{
	for(int i = 1; i <= t; ++i)		tri[1][i] = 1;
	for(int i = 2; i <= n; ++i)
	{	
		al = t + (i - 1) * (t - 1); lin = (al + 1) / 2;
		which = i % 2; ano = which ^ 1;
		for(int j = 1; j <= t; ++j)
		{
			tri[which][j] = tri[which][j - 1] + tri[ano][j]; tri[which][j] %= mod;
		}			
		for(int j = 1 + t; j <= lin; ++j)
		{
			tri[which][j] = tri[which][j - 1] - tri[ano][j - t] + tri[ano][j]; tri[which][j] %= mod;
		}
		if(al % 2 == 1)		lin = lin - 1;	
		for(int j = 1; j <= lin; ++j)
		{
			tri[which][al + 1 - j] = tri[which][j];
		}
	}
	for(int i = 1; i <= 1000005; ++i)		F[1][i] = 1;
	for(int i = 2; i <= (m - n); ++i)
	{
		which = i % 2; ano = which ^ 1;	
		for(int j = 1; j <= 1000005; ++j)
		{
			F[which][j] = F[which][j - 1] + F[ano][j]; F[which][j] %= mod;
		}
	}
}

inline void workk()
{
	a1 = n % 2; a2 = (m - n) % 2; ans = 0; lin = (s - m + 1); ans = 0;
	for(int i = 2; i <= lin; ++i)
	{
		F[a2][i] += F[a2][i - 1]; F[a2][i] %= mod;
	}
	al = n * t;
	for(int i = 1; i <= al; ++i)
	{
		ans += tri[a1][i] * F[a2][lin];
		ans %= mod; lin--;
	}
	printf("%lld", ans);
}

int main()
{
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	scanf("%d%d%d%d", &s, &t, &n, &m);
	prepare();
	workk();
	return 0;
}
