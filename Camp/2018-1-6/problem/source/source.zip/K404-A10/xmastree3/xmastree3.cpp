#include <bits/stdc++.h>

typedef long long int int64;
static const int64 mod = 998244353LL;
struct vertex {
	int estart;
	int parent;
	int64 dp[32768];
	int64 dp2[32768];
} v[50];
struct edge {
	int enext,to;
} e[100];int en;
int mink[32768];
int n,k;
void dfs(int i)
{
	for(int j = v[i].estart;j != -1;j = e[j].enext) {
		int to = e[j].to;
		if(v[to].parent == -2) {
			v[to].parent = i;
			dfs(to);
		}
	}
	for(int x = 0;x < k;++x) {
		memset(v[i].dp2,0,sizeof(v[i].dp2));
		v[i].dp2[0] = 1;
		for(int j = v[i].estart;j != -1;j = e[j].enext) {
			int to = e[j].to;if(v[to].parent != i) continue;
			for(int a = (1 << k) - 1;a >= 0;--a) {
				int64 vv = v[i].dp2[a];
				v[i].dp2[a] = 0;
				int mask = (1 << k) - 1 - (a & ((1 << (x + 1)) - 1));
				for(int b = mask;;b = (b - 1) & mask) {
					v[i].dp2[a|b] = (v[i].dp2[a|b] + vv * v[to].dp[b]) % mod;
					if(b == 0) break;
				}
			}
		}
		int base = (1 << k) - 1 - (1 << x);
		int mask = (1 << x) - 1;
		for(int j = base;;j = (j - 1) & base) {
			v[i].dp[(j&mask)|(1<<x)] = (v[i].dp2[j] + v[i].dp[(j&mask)|(1<<x)]) % mod;
			if(j == 0) break;
		}
	}
}
int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i = 0;i < n;++i) {
		v[i].estart = -1;
		v[i].parent = -2;
	}
	mink[0] = k;
	for(int i = 0;i < k;++i) {
		for(int j = 1;(j << i) < (1 << k);j += 2)
			mink[j<<i] = i;
	}
	for(int i = 0;i < n - 1;++i) {
		int a,b;
		scanf("%d%d",&a,&b);
		--a,--b;
		e[en].enext = v[a].estart;e[en].to = b;v[a].estart = en++;
		e[en].enext = v[b].estart;e[en].to = a;v[b].estart = en++;
	}
	int root = 0;v[root].parent = -1;
	dfs(root);
	int64 ans = 0;
	for(int i = 0;i < (1 << k);++i)
		ans = (ans + v[root].dp[i]) % mod;
	printf("%lld\n",ans);
}
