#include<bits/stdc++.h>
using namespace std;
int n,a[30],ans;
int check() {
	for(int i=1;i<=n;i++) if(a[i]!=i) return 0;
	return 1;
}
void dfs(int num,int pro) {
	if(num>=ans) return;
	int tmp2=0;
	for(int i=1;i<n;i++) if(abs(a[i+1]-a[i])>1) tmp2++;
	if(num+tmp2>=ans) return;
	if(check()) ans=num;
	for(int i=2;i<=n;++i) {
		if(i==pro) continue;
//		int len=i;
//		for(int k=1;k<=len/2;k++) swap(a[1+k-1],a[i-k+1]);
		reverse(a+1,a+i+1);
		dfs(num+1,i);
		reverse(a+1,a+i+1);
//		for(int k=1;k<=len/2;k++) swap(a[1+k-1],a[i-k+1]);
	}
}
void work() {
	scanf("%d",&n);
	ans=60;
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	int tmp=0;
	for(int i=1;i<=n;i++) if(abs(a[i+1]-a[i])>1) tmp++;
	dfs(0,0);
	printf("%d\n",ans);
}
int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) {
		work();
	}
}
