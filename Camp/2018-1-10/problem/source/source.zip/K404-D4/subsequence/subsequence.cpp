#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n, m, k, a[4010], b[4010];
int ta[4010][4010], tb[4010][4010];
int f[8010][4010];
int main () {
	freopen ("subsequence.in", "r", stdin);
	freopen ("subsequence.out", "w", stdout);
	scanf ("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= n; i++) scanf ("%d", &a[i]);
	for (int i = 1; i <= k; i++) ta[n][i] = ta[n + 1][i] = n + 1;
	for (int i = n - 1; i >= 0; i--) {
		for (int j = 1; j <= k; j++) ta[i][j] = ta[i + 1][j];
		ta[i][a[i + 1]] = i + 1;
	}
	for (int i = 1; i <= m; i++) scanf ("%d", &b[i]);
	for (int i = 1; i <= k; i++) tb[m][i] = tb[m + 1][i] = m + 1;
	for (int i = m - 1; i >= 0; i--) {
		for (int j = 1; j <= k; j++) tb[i][j] = tb[i + 1][j];
		tb[i][b[i + 1]] = i + 1;
	}
	memset (f, -1, sizeof (f));
	f[0][0] = 0;
	for (int i = 0; i <= n + m; i++) {
		if (f[i][n + 1] == m + 1) { printf ("%d\n", i); return 0; }
		for (int j = 0; j <= n; j++) if (f[i][j] >= 0) {
			for (int p = 1; p <= k; p++) {
				f[i + 1][ta[j][p]] = max(f[i + 1][ta[j][p]], tb[f[i][j]][p]);
			}
		}
	}
	return 0;
}
