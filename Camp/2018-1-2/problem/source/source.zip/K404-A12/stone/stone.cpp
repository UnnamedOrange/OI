#include <iostream>
#include <cstdio>
#include <cstring>
#define mod 1000000007
using namespace std;
int add(int x,int y){
	return (x+y>=mod)?x+y-mod:x+y;
}
int n,a,b,w[100005],f[100005][2];
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int op=0,tot=1;
	scanf("%d%d%d",&n,&a,&b);
	if(a>b) swap(a,b),op=1;
	for(int i=1;i<=n;i++) scanf("%d",&w[i]),w[i]%=a+b,tot=add(tot,tot);
	f[0][1]=1;
	for(int i=1;i<=n;i++){
		if(w[i]>=b){
			f[i][0]=add(f[i-1][0],f[i-1][1]);
			f[i][1]=add(f[i-1][0],f[i-1][1]);
		}
		else{
			f[i][0]=f[i-1][0];
			f[i][1]=f[i-1][1];
		}
	}
	int wa=tot-f[n][0]-f[n][1],wb=0;
	if(a==b) wa=0;
	wa=(wa%mod+mod)%mod;
	if(op) swap(wa,wb);
	printf("%d %d %d %d",wa,wb,f[n][0],f[n][1]);
	return 0;
}
