#include<iostream>
#include<queue>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}
template <class T,int siz> struct heap
{
	T hp[siz];int htop;heap(){htop=0;}~heap(){}
	inline bool empty(){return htop==0;}inline void clear(){htop=0;}
	inline void push(const T &x){hp[++htop]=x;push_heap(hp+1,hp+htop+1);}
	inline void pop(){pop_heap(hp+1,hp+(htop--));}
	inline T top(){return hp[1];}
};
inline void chkmin(int &a,int b){if(a>b)a=b;}
inline void chkmax(int &a,int b){if(a<b)a=b;}

const int M=4000009;

typedef pair<int,int> pr;

int n,m,mt;
int to[M],frm[M],nxt[M],beg[M],tot;
int eto[M],enxt[M],ebeg[M],etot;
int ind[M],low[M],pre[M],dfn,top;
int stk[M],scc[M],siz[M],f[M],scccnt;
priority_queue<pr,vector<pr>,greater<pr> > q;

inline void dfs(int u)
{
	low[u]=pre[u]=++dfn;
	stk[++top]=u;
	for(int i=beg[u],v;i;i=nxt[i])
		if(!pre[v=to[i]])
		{
			dfs(v);
			chkmin(low[u],low[v]);
		}
		else if(!scc[v])
			chkmin(low[u],pre[v]);
	if(low[u]==pre[u])
	{
		scccnt++;
		do
			scc[stk[top]]=scccnt,siz[scccnt]++;
		while(stk[top--]!=u);
	}
}

inline void add(int u,int v)
{
	to[++tot]=v;
	frm[tot]=u;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void eadd(int u,int v)
{
	eto[++etot]=v;
	enxt[etot]=ebeg[u];
	ebeg[u]=etot;
	ind[v]++;
}

inline int dfs(int u,int fa)
{
	if(~f[u])
		return f[u];
	int mval=siz[u];
	for(int i=beg[u],v;i;i=nxt[i])
		if((v=to[i])!=fa)
			chkmax(mval,siz[u]+dfs(v,u));
	chkmax(mt,mval);
	return f[u]=mval;
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bombs.out","w",stdout);

	n=read();m=read();
	for(int i=1,u,v;i<=m;i++)
	{
		u=read();v=read();
		add(u,v);
	}

	memset(scc,0,sizeof(scc));
	for(int i=1;i<=n;i++)
		if(!scc[i])
			dfs(i);
	for(int i=1;i<=tot;i++)
		if(scc[frm[i]]!=scc[to[i]])
			eadd(scc[to[i]],scc[frm[i]]);

	for(int i=1;i<=scccnt;i++)
		if(!ind[i])
			q.push((pr){siz[i],i});

	while(!q.empty())
	{
		pr u=q.top();q.pop();
		mt=max(mt,u.first);
		for(int i=ebeg[u.second];i;i=enxt[i])
			if(!(--ind[eto[i]]))
				q.push((pr){siz[eto[i]]+u.first,eto[i]});
	}

	printf("%d\n",mt);
	return 0;
}

