#include <queue>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int N = 10000 + 1000;

int n, m, k, ans = 0;
int A[N], B[N], C[N];
int up = 0;
bool flag;

namespace file{
	inline void open()
	{
		freopen("subsequence.in", "r", stdin);
		freopen("subsequence.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	} 
}
using namespace file;

inline int read()
{
	int a = 0;
	char ch;
	int f = 1;
	while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
	if(ch == '-')
		f = -1;
	else
	{
		a = a * 10;
		a += ch - '0';
	}
	while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
	{
		a = a * 10;
		a += ch - '0';
	}
	return a * f;
}

inline void input()
{
	n = read(), m = read(), k = read();
	for(int i = 1;i <= n;++i)
		A[i] = read();
	for(int j = 1;j <= m;++j)
		B[j] = read();
}

inline bool judge()
{
	int i, j;
	for(i = 1, j = 1;i <= n && j <= up;++i)
		if(A[i] == C[j])
			++j;
	if(j == up + 1)
		return false;
	for(i = 1, j = 1;i <= m && j <= up;++i)
		if(B[i] == C[j])
			++j;
	if(j == up + 1)
		return false;
	return true;
}

inline void dfs(int x)
{
	if(x == up + 1)
	{
		if(judge())
			flag = true;
		return;
	}
	if(flag == true)
		return;
	for(int i = 1;i <= k;++i)
	{
		if(flag == true)
			return;
		C[x] = i;
		dfs(x + 1);
		C[x] = 0;
	}
}

inline bool scan(int x)
{
	up = x;
	flag = false;
	dfs(1);
	return flag == true;
}

inline void brute()
{
	int l = 1, r = n + m;
	while(l < r)
	{
		int mid = (l + r) >> 1;
		if(scan(mid))
			ans = mid, r = mid - 1;
		else
			l = mid + 1;
	}
	printf("%d\n", ans);
}

inline void momomo()
{
	printf("%d\n", 1926);
}

inline void check()
{
	if(n <= 18 && m <= 18 && k == 2)
		brute();
	else
		momomo();
}

int main()
{
	open();
	input();
	check();
	close();
	return 0;
} 
