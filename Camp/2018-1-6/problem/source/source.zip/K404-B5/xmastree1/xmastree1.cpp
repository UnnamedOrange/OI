#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 5007;


struct eT
{
	void setd ( int _u, int _v, int _l )
	{
		u = _u, v = _v, last = _l;
	}
	
	int u, v, last;
}edge[MAXN*2];

int n, q, t;
int a[MAXN], ia[MAXN];
int ke, la[MAXN];
int il[MAXN], ir[MAXN], ki;
int qtp, qa, qb, qc;
bool vis[MAXN];



void init ();
void input ();
void inputq ();
void work ();

void dfs ( int now, int fa );

void upd ( int p, int x );
int query ( int p, int l, int r );



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "xmastree1" );
}

void input ()
{
	scanf ( "%d%d%d", &n, &q, &t );
	lpi ( i, 1, n ) scanf ( "%d", &a[i] );
	int u, v;
	ke = 0;
	INIT ( la, -1 );
	lp ( i, 1, n ){
		scanf ( "%d%d", &u, &v );
		edge[ke].setd ( u, v, la[u] );
		la[u] = ke++;
		edge[ke].setd ( v, u, la[v] );
		la[v] = ke++;
	}
}

void inputq ()
{
	scanf ( "%d%d%d", &qtp, &qa, &qb );
	if ( qtp == 1 ) scanf ( "%d", &qc );
}

void work ()
{
	dfs ( 1, -1 );
	
	lpi ( i, 1, n ) ia[il[i]] = a[i];
	
	int lans = 0;
	lp ( _q, 0, q ){
		inputq ();
		
		if ( t ) qa ^= lans, qb ^= lans, qc ^= lans;
		
		if ( qtp == 1 ) printf ( "%d\n", lans = query ( qa, qb, qc ) );
		else upd ( qa, qb );
	}
}



void dfs ( int now, int fa )
{
	il[now] = ir[now] = ++ki;
	for ( int i = la[now]; ~i; i = edge[i].last ){
		if ( edge[i].v ^ fa ){
			dfs ( edge[i].v, now );
			ir[now] = ir[edge[i].v];
		}
	}
}



void upd ( int p, int x )
{
	ia[il[p]] = x;
}

int query ( int p, int l, int r )
{
	INIT ( vis, false );
	int nl = il[p], nr = ir[p];
	int ans = 0;
	lpi ( i, nl, nr ){
		if ( ia[i] >= l && ia[i] <= r ){
			if ( !vis[ia[i]] ){
				vis[ia[i]] = true;
				++ans;
			}
		}
	}
	return ans;
}
