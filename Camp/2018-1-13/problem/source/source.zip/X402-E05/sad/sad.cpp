#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
const LL mod=1e9+7;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
}
int n,deg[N];
int bgn[N],nxt[N<<1],to[N<<1],E;
LL w[N];
char c[N];
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void Add(LL&x,LL y){x=x+y<mod?x+y:x+y-mod;}
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void dfs(int u,int f)
{
	LL ret=deg[u];
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs(v,u);
		Add(w[u],w[v]);
		Add(ret,mod-qpow(deg[v],mod-2));
	}
	w[u]=w[u]*qpow(ret,mod-2)+deg[u]%mod;
}
int main()
{
	int x,y;
	file();
	read(n);
	scanf("%s",c+1);
	For(i,2,n)
	{
		read(x),read(y);
		add_edge(x,y),add_edge(y,x);
		deg[x]++,deg[y]++;
	}
	dfs(1,0);
	printf("%lld\n",w[1]);
	return 0;
}
