#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=100000,A=rand()%1000000000+1,B=rand()%1000000000+1;
	printf("%d %d %d\n",n,A,B);
	for(int i=1;i<=n;i++)
		printf("%d ",rand()%1000000000+1);
	printf("\n");
}
int main(){
	srand(time(0)+getx());
	freopen("stone.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
