#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 30;
int n, m, lst[N], l[N], r[N], d[N];

bool check(int x){
	static int d[30];
	for(int i = 0; i <= m; i++)
		d[i] = 0;
	for(int i = 1; i <= n; i++)
		if(x >> (i - 1) & 1)
			d[l[i]]++, d[r[i] + 1]--;
	for(int i = 1; i <= m; i++){
		d[i] += d[i - 1];
		if(!d[i]) return 0;
	}
	return 1;
}

int main(){
	
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	
	read(n), read(m);
	for(int i = 1; i <= n; i++)
		read(l[i]), read(r[i]);
	for(int i = 1; i <= m; i++)
		read(lst[i]);
	sort(lst + 1, lst + m + 1);
	m = unique(lst + 1, lst + m + 1) - lst - 1;
	for(int i = 1; i <= n; i++){
		l[i] = lower_bound(lst + 1, lst + m + 1, l[i]) - lst;
		r[i] = upper_bound(lst + 1, lst + m + 1, r[i]) - lst - 1;
	}
	int ans = 0;
	for(int i = 0; i < (1 << n); i++)
		ans += check(i);
	write(ans), enter;
	
	return 0;
}
/*
2 4
1 4
2 3
1 2 3 4
*/
