a=0
while true;do
	echo "Case $a:"
	a=`expr $a + 1`
	./gen
	./xmasdag_test
	./force
	if diff xmasdag.out force.out;then
		printf "AC\n"
	else
		printf "WA"
		break ;
	fi
done
