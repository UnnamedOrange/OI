#include<iostream>
#include<cstdio>
#include<cstring>

const int N=10;

bool vis[N];

int s[N],t[N];
int n,ans;

bool check()
{
	static bool a[N];
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;i++)
		if(!a[i])
		{
			int cnt=0;
			for(int p=i;!a[p];)
			{
				cnt++;
				a[p]=1;
				p=t[p];
			}
			if(cnt&1)return 0;
		}
	return 1;
}

void dfs(int p=1)
{
	if(p>n)
	{
		ans+=check();
		return;
	}
	if(s[p]!=0)
	{
		t[p]=s[p];
		dfs(p+1);
	}
	else 
	{
		for(int i=1;i<=n;i++)
			if(!vis[i])
			{
				t[p]=i;
				vis[i]=1;
				dfs(p+1);
				vis[i]=0;
			}
	}
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);

	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&s[i]);
		vis[s[i]]=1;
	}
	ans=0,dfs();
	printf("%d\n",ans);
	return 0;
}
