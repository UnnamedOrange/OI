#!/bin/bash
'/c/Program Files/Dev-Cpp/MinGW64/bin/g++' -g sequence.cpp -o sequence -DDBG -Wall -Wextra -m32
