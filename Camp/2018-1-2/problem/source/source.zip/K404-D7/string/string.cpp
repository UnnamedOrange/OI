#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int T;
int n;
char s[100005];
bool hw[105][105];
int dp[105][105];
bool vis[105][105];
const int inf = 0x3f3f3f3f;
inline int gao(int l, int r) {
	if(l == r) {
		return inf;
	}
	if(l > r) return 0;
	if(vis[l][r]) {
		return dp[l][r];
	}
	bool pd = 1;
	int l1 = l, r1 = r;
	while(l1 <= r1) {
		if(s[l1] != s[r1]) pd = 0;
		++l1, --r1;
	}
	if(!pd) {
		vis[l][r] = 1;
		dp[l][r] = 1;
		return 1;
	}
	int ret = inf;
//	printf("s[%d] = %c, s[%d] = %c\n", l,s[l], r,s[r]);
	for(int i = l + 1; i < r; ++i) {
	//	printf("gao[%d][%d] = %d, gao[%d][%d] = %d\n",  l, i, gao(l, i), i + 1, r, gao(i + 1, r));
		ret = min(gao(l, i) + gao(i + 1, r), ret);
	}
	dp[l][r] = ret;
	vis[l][r] = 1;
	return ret;
}
int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	R(T);
	while(T--) {
		R(n);
		scanf("%s", s + 1);
		if(n <= 100) {	
			memset(vis,0 ,sizeof(vis));
			memset(dp, 0x3f, sizeof(dp));
			gao(1, n);
			if(dp[1][n] < inf)
			cout<<dp[1][n]<<'\n';
			else puts("-1");
		} else {
			int l = 1, r = n;
			bool pd = 1;
			while(l <= r) {
				if(s[l] != s[r]) pd = 0;
				++l, --r;
			}
			if(!pd) {
				puts("1");
			} else {
				puts("2");
			}
		}
 	}
	return 0;
}
