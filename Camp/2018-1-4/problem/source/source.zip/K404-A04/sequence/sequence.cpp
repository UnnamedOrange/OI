#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,lim,a[30];
bool flag;
int eva()
{
	int re=0;
	for(int i=1;i<n;i++)
		if(abs(a[i]-a[i+1])!=1) re++;
	return re;	
}
bool check()
{
//	for(int i=1;i<=n;i++)
//		cout<<a[i]<<' ';
//	cout<<endl;	
	for(int i=1;i<=n;i++)
		if(a[i]!=i) return 0;
	return 1;
}
void dfs(int k)
{
	if(lim-k<eva()) return ;
	if(check()) {flag=1;return ;}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=i/2;j++)
			swap(a[j],a[i-j+1]);
		dfs(k+1);
		for(int j=1;j<=i/2;j++)
			swap(a[j],a[i-j+1]);
		if(flag) return ;		
	}
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int ca;
	scanf("%d",&ca);
	while(ca--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		flag=0;	
		for(lim=0;lim<=2*n&&!flag;lim++)
			dfs(0);
		printf("%d\n",lim-1);	
	}
	return 0;
}
