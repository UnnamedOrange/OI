#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=100,mod=998244353;

int n,m;
int a[N][N];

namespace violence
{
	int b[N];
	int L;
	
	inline bool check()
	{
		for(int i=1;i<=n;++i)
		{
			bool flag=0;
			for(int j=1,k;j<=L-a[i][0]+1;++j)
			{
				for(k=0;k<a[i][0];++k)
					if(a[i][k+1]!=b[j+k])
						break;
				if(k==a[i][0]) flag=1;
			}
			if(!flag) return 0;
		}
		return 1;
	}
	
	void Main()
	{
		register int i,j,ans(0);
		L=m<<1;
		for(i=0;i<(1<<m);++i)
		{
			for(j=1;j<=m;++j)
				b[j]=(i>>j-1)&1;
			for(j=m+1;j<=L;++j)
				b[j]=!b[L-j+1];
			if(check())ans++;
		}
		cout<<ans%mod<<endl;
	}
}

char s[N];

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	
	n=read();m=read();
	register int i,j;
	for(i=1;i<=n;++i)
	{
		scanf("%s",s+1);
		a[i][0]=strlen(s+1);
		for(j=1;j<=a[i][0];++j)
			a[i][j]=s[j]-'0';
	}
	violence::Main();
	return 0;
}
/*
2 3
011
001

4
*/

