#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
const int R_LEN=(1<<18)|1;
struct Fast_io{
    char ibuf[R_LEN],obuf[R_LEN],*s,*t,*wt;
    int buf[50];
    Fast_io(){
        s=ibuf,t=ibuf,wt=obuf;
        memset(buf,0,sizeof(buf));
    }
    ~Fast_io(){fwrite(obuf,1,wt-obuf,stdout);}
    inline char getc(){
        (s==t)&&(t=(s=ibuf)+fread(ibuf,1,R_LEN,stdin));
        return (s==t)?-1:*s++;
    }
    inline int rd(){
        char ch=getc(); int i=0,f=1;
        while(!isdigit(ch)){if(ch=='-')f=-1;ch=getc();}
        while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getc();}
        return i*f;
    }
    inline void print(char c){
        (wt==obuf+R_LEN) && (fwrite(obuf,1,R_LEN,stdout),wt=obuf);
        *wt++=c;
    }
    template<typename T>
    inline void W(T x){
        if(!x){print('0');return;}
        if(x<0){print('-');x=-x;}
        while(x){buf[++buf[0]]=x%10;x/=10;}
        while(buf[0])print(buf[buf[0]--]+'0');
    }
}io;
const int N=1e5+50;
int n,p[N],a[N],vis[N],ans;
int vis2[N],vt;
//----------------------------
inline void dfs(int x,int &y){
	++y; vis2[x]=vt;
	if(vis2[a[x]]!=vt)dfs(a[x],y);
}
inline bool check(){
	++vt; int cnt;
	for(int i=1;i<=n;i++)
		if(vis2[i]!=vt){
			dfs(i,(cnt=0)); if(cnt&1)return false;
		}
	return true;
}
inline void dfs(int x){
	if(x==n+1){
		if(check())++ans;
		return;
	}
	if(p[x]){
		if(vis[p[x]])return;
		vis[p[x]]=1; a[x]=p[x];
		dfs(x+1); vis[p[x]]=0;
	}else{
		for(int i=1;i<=n;i++)
			if(!vis[i]&&i!=x){
				a[x]=i; vis[i]=1;
				dfs(x+1); vis[i]=0;
			}
	}
}

//-------------------------
const int Mod=998244353;
const int G=3;
inline int power(int a,int b){
	int rs=1;
	for(;b;b>>=1,a=(ll)a*a%Mod)if(b&1)rs=(ll)rs*a%Mod;
	return rs;
}
inline void add(int &x,int y){ x=(x+y>=Mod?x+y-Mod:x+y);}
int sz,k,fac[N],invfac[N],inv[N],g[N*8],f[N*8],A[N*8],B[N*8],tp[N*8],w[N*8],pos[N*8];
inline void init(int len){
	for(k=1;k<len;k<<=1); w[0]=1;
	for(register int i=1;i<k;i++)pos[i]= (i&1)?((pos[i>>1]>>1)^(k>>1)):(pos[i>>1]>>1);
}
inline void dft(int *a){
	for(int i=1;i<k;i++) (pos[i]>i) && (swap(a[pos[i]],a[i]),0);
	for(int bl=1;bl<k;bl<<=1){
		int wn=power(G,(Mod-1)/(bl<<1));
		for(int i=1;i<bl;i++) w[i]=(ll)w[i-1]*wn%Mod;
		for(register int bg=0;bg<k;bg+=(bl<<1))
			for(register int j=0;j<bl;j++){
				register int &t1=a[bg+j],&t2=a[bg+j+bl],t3=(ll)t2*w[j]%Mod;
				t2=(t1-t3<0?t1-t3+Mod:t1-t3);
				t1=(t1+t3>=Mod?t1+t3-Mod:t1+t3);
			}
	}
}
/*inline void calc_inverse(int *a,int len){
	if(len==1){B[0]=1; return;}
	calc_inverse(a,len>>1); init(len<<1);
	for(int i=0;i<len;i++)tp[i]=a[i];
	dft(tp); dft(B);
	for(int i=0;i<k;i++)
		B[i]=((ll)B[i]*2%Mod - (ll)tp[i]*B[i]%Mod*B[i]%Mod +Mod)%Mod;
	dft(B); reverse(B+1,B+k);
	const int inv=power(k,Mod-2);
	for(int i=0;i<len;i++)
		B[i]=(ll)B[i]*inv%Mod;
	memset(B+len,0,sizeof(k-len));
}*/
inline void solve(int l,int r){
	if(l==r){
		f[l]=(l?(ll)f[l]*inv[l]%Mod:1);
		return;
 	}int mid=(l+r)>>1;
	solve(l,mid);
	register int len=r-l+1; init(len<<1);
	for(register int i=0;i<len;i++)A[i]=g[i];
	for(register int i=l;i<=mid;i++)B[i-l]=f[i];
	for(register int i=mid+1;i<=r;i++)B[i-l]=0;
	for(register int i=len;i<k;i++)A[i]=(B[i]=0);
	dft(A); dft(B);
	for(register int i=0;i<k;i++) B[i]=(ll)A[i]*B[i]%Mod;
	dft(B); reverse(B+1,B+k);
	register const int iv=power(k,Mod-2);
	for(register int i=0;i<k;i++) B[i]=(ll)B[i]*iv%Mod;
	for(register int i=mid+1;i<=r;i++) add(f[i],B[i-l-1]);
	solve(mid+1,r);
	return;
}
inline void solve(){
	fac[0]=1;
	for(int i=1;i<=n+1;i++)fac[i]=(ll)fac[i-1]*i%Mod;
	invfac[n+1]=power(fac[n+1],Mod-2);
	for(int i=n;i>=0;i--)invfac[i]=(ll)invfac[i+1]*(i+1)%Mod;
	inv[1]=1;
	for(int i=2;i<=n;i++) inv[i]=(Mod-(ll)(Mod/i)*inv[Mod%i]%Mod)%Mod;
	for(int i=1;i<=n;i+=2)g[i]=1;
//	for(sz=1;sz<n+1;sz<<=1);
//	calc_inverse(g,sz);
	solve(0,n);
	io.W((ll)f[n]*fac[n]%Mod);
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=io.rd(); 
	for(int i=1;i<=n;i++) p[i]=io.rd();
	if(n<=8){
		dfs(1); io.W(ans); return 0;
	}else solve();
}
