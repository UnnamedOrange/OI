#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int decode(int x,int y){
	int g=x^y,ans;
	for(int i=0;i<10;i++){
		if(g&(1<<i)){
			ans=i+1;
			if(x&(1<<i)) ans+=10;
			return ans;
		}
	}
}
bool encode(int x,int h){
	int o=h%10-1,g=(h>10);
	if(x&(1<<o)) return g;
	return !g;
}
int main(){
	int op,n,T;
	scanf("%d%d%d",&op,&n,&T);
	while(T--){
		int x,y;
		scanf("%d%d",&x,&y);
		if(op==1){
			printf("%d\n",decode(x,y));
		}
		else{
			if(encode(x,y)) puts("yes");
			else puts("no");
		}
	}
	return 0;
}
