#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)1e5+5,P=998244353;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
int fast(int x,int p){
	int re=1;
	while(p){
		if(p&1)re=(long long)re*x%P;
		x=(long long)x*x%P,p>>=1;
	}return re;
}
int n,a[M];
struct SHUI{
	int ans,fa[15],cnt[15],f[15];
	int getfa(int x){
		if(fa[x]==x)return x;
		return fa[x]=getfa(fa[x]);
	}
	void dfs(int x){
		if(x>n){
			for(int i=1;i<=n;i++)fa[i]=i,cnt[i]=1;
			for(int i=1,faa,fab;i<=n;i++){
				faa=getfa(i),fab=getfa(a[i]);
				if(faa!=fab){
					fa[faa]=fab;
					cnt[fab]+=cnt[faa];
				}
			}
			for(int i=1;i<=n;i++)if(getfa(i)==i&&(cnt[i]&1))return;
			ans++;
			return;
		}
		if(a[x])dfs(x+1);
		else {
			for(int j=1;j<=n;j++)
				if(f[j]==0){
					f[j]=1;
					a[x]=j;
					dfs(x+1);
					f[j]=0;
					a[x]=0;
				}
		}
	}
	void solve(){
		for(int i=1;i<=n;i++)f[a[i]]=1;
		dfs(1);
		printf("%d\n",ans);
	}
}P10;
struct IHSU{
	void solve(){
		int ans=1;
		for(int i=1;i<n;i+=2)ans=(long long)ans*i%P;
		printf("%lld\n",(long long)ans*ans%P);
	}
}P30;
struct HUSI{
	int mark[M],deg[M];
	int fac[M],rfac[M],inv[M];
//	int dp[M];
	void solve(){
		int jidian=0,oudian=0;
		for(int i=1;i<=n;i++)deg[a[i]]++;
		for(int i=1,x;i<=n;i++)
			if(a[i]&&deg[i]==0){
				int c=0;
				x=i;
				while(mark[x]==0){
					mark[x]=1;
					c^=1;
					if(a[x]==0)break;
					x=a[x];
				}
				if(a[x]){
					if(c){
						puts("0");
						return;
					}
				}else if(c)jidian++;
				else oudian++;
			}else if(a[i]==0&&deg[i]==0){
				jidian++;
			}
		fac[0]=1;
		for(int i=1;i<M;i++)fac[i]=(long long)fac[i-1]*i%P;
		rfac[M-1]=fast(fac[M-1],P-2);
		for(int i=M-2;i>=0;i--)rfac[i]=(long long)rfac[i+1]*(i+1)%P;
		inv[0]=1;
		for(int i=1;i<M;i++)inv[i]=(long long)fac[i]*rfac[i-1]%P;
		int sum=fac[jidian-1],tmp=1;
		for(int i=2;i<=jidian;i+=2){
			tmp=(long long)sum*rfac[jidian-i]%P;
			Add(sum,(long long)tmp*fac[jidian-i-1]%P);
		}
//		printf("%d %d\n",tmp,jidian);
//		dp[0]=1;
//		for(int i=2;i<=jidian;i+=2)
//			for(int j=0;j<i;j++)
//				Add(dp[i],(long long)dp[j]*fac[jidian-j-1]%P*rfac[jidian-i]%P);
//		int tmp=dp[jidian];
		int tp=jidian+1;
		for(int i=1;i<=oudian;i++){
			tmp=(long long)tmp*tp%P;
			tp++;
		}
		printf("%d\n",tmp);
	}
}PWP;
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	Rd(n);
	for(int i=1;i<=n;i++)Rd(a[i]);
	if(n&1)puts("0");
	else {
		int sum=0;
		for(int i=1;i<=n;i++)sum+=a[i];
//		if(0);
		if(n<=8)P10.solve();
		else if(sum==0)P30.solve();
		else PWP.solve();
	}
	return 0;
}
