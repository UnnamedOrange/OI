#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
#define cz dp[b[1]][b[2]][b[3]][b[4]][b[5]]
using namespace std;
const int mod=1e9+7;
const int N=100010;
int dp[6][6][6][6][6][2];
int a[N],b[N];int kk[2];
int n;

void solve1(){
	static int dp[N][2];
	int i,j,x;
	dp[0][0]=1;
	rep(i,1,n){
		x=a[i]/kk[0];x&=1;
		rep(j,0,1)	dp[i][j^x]=(dp[i][j^x]+dp[i-1][j])%mod;
		rep(j,0,1)	dp[i][j]=(dp[i][j]+dp[i-1][j])%mod;
	}
	printf("0 0 %d %d\n",dp[n][1],dp[n][0]);
}

void DP(){
	int S,i,ok;
	rep(S,0,1){
		ok=0;
		rep(i,1,n)	if(b[i]>=kk[S]){
			b[i]-=kk[S];
			ok|=(cz[S^1]^1);
			b[i]+=kk[S];
		}
		cz[S]=ok;
	}
}

void dfs(int now){
	if(now==n+1){DP();return;}
	int i;
	rep(i,0,a[now])	{b[now]=i;dfs(now+1);}
}

void solve2(){
	int ans1,ans2,ans3,ans4;
	ans1=ans2=ans3=ans4=0;
	int i,j;
	dfs(1);
	rep(i,0,(1<<n)-1){
		rep(j,0,4){
			if(1<<j&i) b[j+1]=a[j+1];
			else b[j+1]=0;
		}
		if(cz[0]&&cz[1])	ans3++;
		if(cz[0]&&!cz[1])	ans1++;
		if(!cz[0]&&cz[1])	ans2++;
		if(!cz[0]&&!cz[1])	ans4++;
	}
	printf("%d %d %d %d\n",ans1,ans2,ans3,ans4);
}
	

int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int i;
	scanf("%d%d%d",&n,&kk[0],&kk[1]);
	rep(i,1,n)	scanf("%d",&a[i]);
	if(kk[0]==kk[1]){solve1();return 0;}
	if(n<=5){solve2();return 0;}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
