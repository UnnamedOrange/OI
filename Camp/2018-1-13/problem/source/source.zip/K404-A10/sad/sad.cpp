#include <bits/stdc++.h>

typedef long long int int64;
static const int64 mod = 998244353LL;
int64 inv[100003];
int64 gcd(int64 a,int64 b,int64 &aa,int64 &bb) {
	if(b == 0) {
		aa = 1,bb = 0;
		return a;
	}
	int64 v = gcd(b,a % b,bb,aa);
	bb -= aa * (a / b);
	return v;
}
int64 calinv(int64 x) {
	if(x < 0) x += mod;
	int64 a,b;
	gcd(x,mod,a,b);
	return a;
}
struct vertex {
	int estart;
	int type;
	int deg;
	int parent;
	int64 expect,ret,pass,chl;
} v[100003];
struct edge {
	int enext,to;
} e[200003];int en;
void dfs(int i) {
	int cnt = 0;
	int64 sum = 0;
	int64 prob = 0,ret = 0;
	for(int j = v[i].estart;j != -1;j = e[j].enext) {
		int to = e[j].to;
		if(v[to].parent == -2) {
			v[to].parent = i;
			dfs(to);
			++cnt;
		}
	}
	for(int j = v[i].estart;j != -1;j = e[j].enext) {
		int to = e[j].to;
		if(v[to].parent == i) {
			if(v[to].deg != 1) {
				prob = (prob + inv[v[to].deg] * inv[cnt]) % mod;
				sum = sum + (v[to].expect * (v[to].deg - 1) + v[to].type) % mod * inv[v[to].deg] % mod * inv[cnt] % mod;
				ret = ret + v[to].ret;
			} else {
				sum = (sum + inv[cnt]) % mod;
			}
		}
	}
	if(cnt == 0) {
		v[i].deg = 1;
		v[i].expect = 1;
		v[i].ret = 0;
		v[i].type = 1; // force black
	} else {
		ret = inv[cnt+1] * calinv(1 - ret * inv[cnt+1] % mod) % mod;
		v[i].deg = cnt + 1;
		v[i].expect = (sum + v[i].type) * calinv(1 - prob) % mod;
		v[i].ret = ret;
		if(i == 0)
			v[i].deg = cnt;
		else
			v[i].deg = cnt + 1;
	}
}
void dfs2(int i) {
	int64 retsum = 0;
	for(int j = v[i].estart;j != -1;j = e[j].enext) {
		int to = e[j].to;
		if(v[to].parent == i) {
			retsum = (retsum + v[to].ret) % mod;
		}
	}
	for(int j = v[i].estart;j != -1;j = e[j].enext) {
		int to = e[j].to;
		if(v[to].parent == i) {
			v[to].chl = inv[v[i].deg] * calinv(1 - (retsum - v[to].ret + v[i].chl) * inv[v[i].deg] % mod) % mod;
			v[to].pass = v[to].chl * v[i].pass % mod;
			dfs2(to);
		}
	}
}
int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	int n;
	scanf("%d ",&n);
	for(int i = 0;i < n;++i) {
		v[i].type = getchar() - '0';
		v[i].estart = -1;
		v[i].parent = -2;
	}
	inv[1] = 1;
	for(int i = 2;i <= n;++i) {
		inv[i] = (mod - mod / i) * inv[mod % i] % mod;
	}
	for(int i = 0;i < n - 1;++i) {
		int a,b;
		scanf("%d%d",&a,&b);--a,--b;
		e[en].enext = v[a].estart;e[en].to = b;v[a].estart = en++;
		e[en].enext = v[b].estart;e[en].to = a;v[b].estart = en++;
	}
	v[0].parent = -1;
	v[0].pass = 1;v[0].chl = 0;
	dfs(0);dfs2(0);
	int64 ans = v[0].expect % mod;
	for(int i = 0;i < n;++i)
		if(v[i].deg != 1)
			ans = (ans + v[i].pass * (1 - v[i].type)) % mod;
	if(ans < 0) ans += mod;
	printf("%lld\n",ans);
}
