#include<bits/stdc++.h>
using namespace std;
inline int rd(){
	char ch=getchar(); int i=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getchar();}
	return i*f;
}
inline void W(int x){
	static int buf[50];
	if(!x){putchar('0');return;}
	if(x<0){putchar('-');x=-x;}
	while(x){buf[++buf[0]]=x%10;x/=10;}
	while(buf[0]){putchar(buf[buf[0]--]+'0');}
}
const int N=1e5+50,INF=0x3f3f3f3f;
int n,q,T,lst;
int c[N],dfn[N],out[N],id[N],ind;
int g[N],nt[N*2],v[N*2],ec;
inline void add( int x,int y){nt[++ec]=g[x];g[x]=ec;v[ec]=y;}
struct Q{
	int op,l,r,x;
}qry[N];
inline void dfs(int x,int f){
	dfn[x]=++ind; id[ind]=x;
	for(int e=g[x];e;e=nt[e]){
		if(v[e]!=f)
			dfs(v[e],x);
	}
	out[x]=ind;
}


namespace Task1{
	int vis[N],vt;
	inline void solve(){
		for(int i=1;i<=q;i++){
			int op=qry[i].op;
			if(op==1){
				int u=qry[i].x;
				int l=qry[i].l;
				int r=qry[i].r;
				if(T)u^=lst,l^=lst,r^=lst;
				++vt;int cnt=0;
				for(int i=dfn[u];i<=out[u];++i){
					int v=id[i];
					if(c[v]>=l&&c[v]<=r&&vis[c[v]]!=vt)++cnt,vis[c[v]]=vt;
				}
				W(lst=cnt);putchar('\n');
			}else{
				int u=qry[i].x,w=qry[i].l;
				if(T)u^=lst,w^=lst;
				c[u]=w;
			}
		}
	}
}

set<int>S[N];
typedef set<int>::iterator it;
namespace Task2{
	const int alpha = 70;
	struct point{
		int x[3];
		point(){}
		point(int xc,int yc,int zc){
			x[0]=xc; x[1]=yc; x[2]=zc;
		}
	}p[N*2],tp[N*2],mn,mx;
	struct node{
		node *lc,*rc;
		point P;
		int mn[3],mx[3],sze;
		int isdel;
		node():lc(NULL),rc(NULL){}
		inline void upt(){
			sze=(!isdel)+(lc?lc->sze:0)+(rc?rc->sze:0);
			for(int i=0;i<=2;i++)
				mn[i]=min((lc?lc->mn[i]:INF),(rc?rc->mn[i]:INF));
			for(int i=0;i<=2;i++)
				mx[i]=max((lc?lc->mx[i]:-INF),(rc?rc->mx[i]:-INF));
			if(!isdel)
				for(int i=0;i<=2;i++)
					mn[i]=min(mn[i],P.x[i]),mx[i]=max(mx[i],P.x[i]);
		}
	}Pool[N*20],*pool=Pool,*rt,**ql;
	int D;
	inline bool check(node *now){
		if((now->lc?now->lc->sze:0)*100>now->sze*alpha||(now->rc?now->rc->sze:0)*100>now->sze*alpha)return true;
		return false;
	}
	inline bool cmpx(const point &a,const point &b){return a.x[0]<b.x[0];}
	inline bool cmpy(const point &a,const point &b){return a.x[1]<b.x[1];}
	inline bool cmpz(const point &a,const point &b){return a.x[2]<b.x[2];}
	inline void build(node *&now,int l,int r,int dim){
		if(l>r){
			now=NULL;
			return;
		}
		now=++pool; now->sze=r-l+1; 
		int mid=(l+r)>>1;
		if(dim==0) nth_element(tp+l,tp+mid,tp+r+1,cmpx);
		else if(dim==1) nth_element(tp+l,tp+mid,tp+r+1,cmpy);
		else nth_element(tp+l,tp+mid,tp+r+1,cmpz);
		now->P=tp[mid];
		build(now->lc,l,mid-1,(dim+1)%3);
		build(now->rc,mid+1,r,(dim+1)%3);
		now->upt();
	}
	inline int ck_valid(node *now){
		int bz=1;
		for(int i=0;i<=2;i++)bz&=(mn.x[i]<=now->mn[i]&&now->mx[i]<=mx.x[i]);
		if(bz)return 1;
		bz=1;
		for(int i=0;i<=2;i++)bz&=(mn.x[i]>now->mx[i]||mx.x[i]<now->mn[i]);
		if(bz)return -1;
		return 0;
	}
	inline int ck_valid(const point &P){
		int bz=1;
		for(int i=0;i<=2;i++)bz&=(P.x[i]>=mn.x[i]&&P.x[i]<=mx.x[i]);
		return bz;
	}
	inline int query(node *now){
		if(now==NULL)return 0;
		int t=ck_valid(now);
		if(t==-1)return 0;
		if(t==1)return now->sze;
		return query(now->lc)+query(now->rc)+((!now->isdel)&&ck_valid(now->P));
	}
	inline void travel_del(node *now){
		if(!now)return;
		now->sze=0;now->isdel=1;
		travel_del(now->lc);
		travel_del(now->rc);
	}
	inline void del(node *&now,int dim){
		if(now==NULL)return;
		int t=ck_valid(now);
		if(t==1){
			now->sze=0;
			travel_del(now);
			ql=&now; D=dim;
			return;
		}
		if(t==-1)return;
		del(now->lc,(dim+1)%3);del(now->rc,(dim+1)%3);
		if((!now->isdel)&&ck_valid(now->P))
			now->isdel=1;
		now->upt();
		if(check(now))
			ql=&now, D=dim;
	}
	inline void rebuild(node *&now,int dim);
	inline void del(const point &P){
		ql=NULL; 
		for(int i=0;i<=2;i++)mn.x[i]=(mx.x[i]=P.x[i]);
		del(rt,0);
		if(ql!=NULL)rebuild(*ql,D);
	}
	inline void ins(node *&now,const point &P,int dim){
		if(now==NULL){
			now=++pool; now->P=P;
			now->upt(); return;
		}
		int bz=1;
		if(dim==0)bz&=(P.x[0]>now->P.x[0]);
		else if(dim==1)bz&=(P.x[1]>now->P.x[1]);
		else bz&=(P.x[2]>now->P.x[2]);
		bz?(ins(now->rc,P,(dim+1)%3)):(ins(now->lc,P,(dim+1)%3));
		now->upt();
		if(check(now))
			ql=&now, D=dim;
	}
	int tl=n;
	inline void travel(node *now){
		if(!now->isdel)tp[++tl]=now->P;
		(now->lc)&&(travel(now->lc),0);
		(now->rc)&&(travel(now->rc),0);
	}
	inline void rebuild(node *&now,int dim){
		tl=n; travel(now);
		build(now,n+1,tl,dim);
	}
	inline void ins(const point &P){
		ql=NULL; ins(rt,P,0);
		if(ql!=NULL)rebuild(*ql,D);
	}
	inline void solve(){
		for(int i=1;i<=n;i++){
			int u=id[i],w=c[u];
			S[w].insert(i);
			it t=S[w].lower_bound(i);
			(t==S[w].begin())?
			(p[i]=point(i,0,w)):
			(p[i]=point(i,*(--t),w));
		}
		memcpy(tp+1,p+1,sizeof(point)*n);
		build(rt,1,n,0);
		for(int i=1;i<=q;i++){
			int op=qry[i].op;
			if(op==1){
				int u=qry[i].x;
				int l=qry[i].l;
				int r=qry[i].r;
				if(T)u^=lst,l^=lst,r^=lst;
				mn.x[0]=dfn[u]; mx.x[0]=out[u];
				mn.x[1]=0;      mx.x[1]=dfn[u]-1;
				mn.x[2]=l;      mx.x[2]=r;
				W((lst=query(rt)));putchar('\n');
			}else{
				int u=qry[i].x,w=qry[i].l;
				if(T)u^=lst,w^=lst;
				u=dfn[u]; 
				del(p[u]);
				int ori_col=p[u].x[2];
				it t=S[ori_col].lower_bound(u);
				if(t!=(--S[ori_col].end())){
					int p1;
					if(t==S[ori_col].begin())p1=0;
					else p1=(*--t),++t;
					int p2=(*++t);--t;
					del(p[p2]);
					p[p2].x[1]=p1;
					ins(p[p2]);
				}
				S[ori_col].erase(t);
				t=S[w].lower_bound(u);
				int p1;
				if(t==S[w].begin())p1=0;
				else p1=*(--t),++t;
				p[u].x[1]=p1; p[u].x[2]=w;
				if(t!=S[w].end()){
					int p2=*t;
					del(p[p2]);
					p[p2].x[1]=u;
					ins(p[p2]);
				}
				ins(p[u]);
				S[w].insert(u);
			}
		}
	}
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=rd(),q=rd(),T=rd();
	for(int i=1;i<=n;i++) c[i]=rd();
	for(int i=1;i<n;i++){
		int x=rd(),y=rd();
		add(x,y); add(y,x);
	}
	for(int i=1;i<=q;i++){
		qry[i].op=rd();
		if(qry[i].op==1){
			qry[i].x=rd();
			qry[i].l=rd();
			qry[i].r=rd();
		}else{
			qry[i].x=rd();
			qry[i].l=rd();
		}
	}
	dfs(1,0);
	if(n<=5000&&q<=5000)Task1::solve();
	else Task2::solve();
}
