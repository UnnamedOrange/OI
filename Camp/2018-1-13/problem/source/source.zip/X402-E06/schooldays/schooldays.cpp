#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 4000;
const int mo = 1e9 + 7;

int n;
int f[N + 5], g[N + 5];
int c[N + 5], d[N + 5];

int main() {
    freopen("schooldays.in", "r", stdin);
    freopen("schooldays.out", "w", stdout);

    read(n);
    for(int i = 1; i <= n; ++i) 
        read(c[i]), read(d[i]);

    f[0] = 0;
    g[0] = 1;
    for(int i = 1; i <= n; ++i) {
        int Mx = -oo, Mn = oo;

        f[i] = -oo;
        g[i] = 0;

        for(int l = 1; l <= i; ++l) {
            chkmax(Mx, c[i-l+1]);
            chkmin(Mn, d[i-l+1]);

            if(l >= Mx && l <= Mn) {
                if(chkmax(f[i], f[i-l] + 1)) 
                    g[i] = g[i-l];
                else if(f[i] == f[i-l] + 1) {
                    g[i] = (g[i] + g[i-l]) % mo;
                }
            }
        }
    }

    if(f[n] > -oo) {
        printf("%d %d\n", f[n], g[n]);
    } else {
        printf("-1\n");
    }
    return 0;
}
