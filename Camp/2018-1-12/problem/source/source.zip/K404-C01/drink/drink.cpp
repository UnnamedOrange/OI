//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=1e6+7;
typedef double db;
using namespace std;
int rt,n;
db w[N],b[N],ans,power[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1; 
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f; 
}

int tot,ch[N][2],p[N],sz[N];
db a[N],v[N],sum[N],lz[N];
#define lc ch[x][0]
#define rc ch[x][1]
void update(int x) { sum[x]=sum[lc]+sum[rc]+v[x]; sz[x]=sz[lc]+sz[rc]+1;}

void down(int x) {
	if(lz[x]==1) return ;
	if(lc) { sum[lc]/=lz[x]; v[lc]/=lz[x]; lz[lc]*=lz[x]; }
	if(rc) { sum[rc]/=lz[x]; v[rc]/=lz[x]; lz[rc]*=lz[x]; }
	lz[x]=1;
}

void rotate(int x) {
	int y=p[x],z=p[y],l=(x==ch[y][1]),r=l^1;
	if(z) ch[z][y==ch[z][1]]=x; p[x]=z;
	ch[y][l]=ch[x][r]; p[ch[x][r]]=y;
	ch[x][r]=y; p[y]=x;
	update(y); update(x);
}

void splay(int x) {
	static int g[N],top=0;
	for(int tp=x;tp;tp=p[tp]) 
		g[++top]=tp;
	while(top) down(g[top--]);
	for(;p[x];rotate(x)) {
		int y=p[x],z=p[y];
		if(z) 
			((y==ch[z][1])^(x==ch[y][1]))?rotate(x):rotate(y);
	}
	rt=x;
}

int cre(db y) {
	int x=++tot;
	a[x]=sum[x]=v[x]=y;
	lc=rc=0; p[x]=0;
	lz[x]=1; sz[x]=1;
	return x;
}

void insert(db y) {
	int f=0,l=1;
	for(int x=rt;;) {
		if(!x) {
			x=cre(y); p[x]=f;
			if(f) ch[f][l]=x;
			else rt=x;
			splay(x);
			v[x]=y/(power[sz[rc]+1]*1.0);
			if(lc) {
				sum[lc]/=2; v[lc]/=2; lz[lc]*=2;	
			}
			update(x);
			ans+=sum[x];
			return;
		}
		if(y<=a[x]) l=0,f=x,x=lc;
		else l=1,f=x,x=rc;
	}
} 

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
#endif
	read(n);
	power[0]=1;
	for(int i=1;i<=n;i++) {
		read(w[i]);
		power[i]=power[i-1]*2;
	}
	for(int i=1;i<=n;i++) {
		rt=tot=0;
		for(int j=i;j<=n;j++) 
			insert(w[j]);
	}
	ans=ans/((db)n*n);
	printf("%lf\n",ans);
	return 0;
}
