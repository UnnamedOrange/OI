#include <cstdio>
#include <algorithm>
using namespace std;
#define N 100050
int n,i,p[N];
char s[N],t[N];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int tt;scanf("%d",&tt);
	while (tt--){
		scanf("%d",&n);
		scanf("%s",s);bool zw=false;
		for (i=0;i<n;i++) if (s[i]!=s[n-1-i]){
			puts("1");zw=true;break;
		}if (zw) continue;
		t[0]='$';
		for (i=0;i<n;i++) t[i*2+1]=s[i],t[i*2+2]='*';
		t[n*2]='&';int j=0;
		for (i=1;i<n*2;i++){
			if (j+p[j]>=i) p[i]=min(j+p[j]-i,p[2*j-i]);
			while (t[i+p[i]+1]==t[i-p[i]-1]) p[i]++;
			if (i+p[i]>j+p[j]) j=i;
		}zw=false;
		for (i=2;i<n*2;i+=2) if (p[i>>1]<(i>>1)-1&&p[n+(i>>1)]<n-1-(i>>1)){
			puts("2");zw=true;break;
		}if (zw) continue;puts("-1");
	}
	return 0;
}
