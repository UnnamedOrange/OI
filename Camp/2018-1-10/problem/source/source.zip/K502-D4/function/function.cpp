#include<bits/stdc++.h>
using namespace std;
const int N=1000005;
int p[N],d[N],a[N],s[N],miu[N];
bool vis[N];
int tot,n,ans;
void prework(){
	a[1]=1;
	miu[1]=1;
	for(int i=2;i<=N-5;i++){
		if(!vis[i]){
			tot++;
			p[tot]=i;
			a[i]=2;
			miu[i]=-1;
			d[i]=1;
		}
		for(int j=1;j<=tot&&p[j]*i<=N-5;j++){
			vis[p[j]*i]=1;
			if(i%p[j]==0){
				d[p[j]*i]=d[i]+1;
				a[p[j]*i]=a[i]/(d[i]+1)*(d[i]+2);
				miu[p[j]*i]=0;
				break;
			} 
			a[p[j]*i]=a[i]*2;
			d[p[j]*i]=1;
			miu[p[j]*i]=-miu[i];
		}
	}
}
int solve(){
	ans=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j*j<=i;j++)
			if(i%j==0){
				ans+=miu[j]*a[i/j]*a[i/j];
				if(j*j!=i)
					ans+=miu[i/j]*a[j]*a[j];
			}
	return ans;
}
void cFile(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
}
int main(){
	int T;
	cFile();
	scanf("%d",&T);
	prework();
	while(T--){
		scanf("%d",&n);
		printf("%d\n",solve());
	}
	return 0;
}
