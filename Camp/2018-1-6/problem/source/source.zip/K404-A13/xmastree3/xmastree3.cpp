#include<cstdio>
#define LL long long
using namespace std;
const int maxn = 15, maxk = 16;
LL dp[maxn][1 << maxn][maxk];
int graph[maxn][maxn];
int n, k, a, b, ans, stmax;
void dfs(int u, int mask) {
	int nw;
	if(mask == stmax) return ;
	for(register int i = 1; i <= n; ++i) {
		if(!graph[u][i]) continue;
		nw = 1 << (i - 1);
		if(mask & nw) continue;
		for(register int j = 0; j < k; ++j) {
			for(register int l = 1; j + l <= k; ++l)
				dp[i][mask | nw][j + l] += dp[u][mask][j];
		}
		dfs(i, mask | nw);
	}
}
int main() {
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
	scanf("%d%d", &n, &k);
	dp[0][0][0] = 1;
	for(register int i = 1; i < n; ++i) {
		graph[0][i] = graph[i][0] = 1;
		scanf("%d%d", &a, &b);
		graph[a][b] = graph[b][a] = 1;
	}
	stmax = (1 << n) - 1;
	dfs(0, 0);
	for(register int i = 1; i <= n; ++i)
		for(register int j = 0; j <= k; ++j)
			ans += dp[i][stmax][j];
	printf("%d", ans);
	return 0;
}
