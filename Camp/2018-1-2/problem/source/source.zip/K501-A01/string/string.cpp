#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
#define Maxn (100009)
#define rep(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_; ++i) 
char s[Maxn];
int bword(char s[]) {
	int l = strlen(s);
	if(l == 1) return 1;
	rep(i, 0, (l >> 1) - 1) 
		if(s[i] != s[l - i - 1]) return 0;
	return 1;
}
int n;
int check(char s[]) {
	if(n == 1) return 0;
	if(n & 1) {
		char c = 0;int flag = 1;
		rep(i, 0, n - 1){
			if(i == (n >> 1)) continue;
			if(s[i] != s[0]) flag = 0;
		}
		if(!flag) {
			rep(i, 0, n - 1){
				if(i & 1) 
					if(s[i] != s[1]) return 1;
				if(!(i & 1)) 
					if(s[i] != s[0]) return 1;
			}
		}
		return 0;
	}
	return 1;
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	scanf("%d", &T);
	while(T--) {
		scanf("%d", &n);
		scanf("%s", s);
		if(!bword(s)) {
			printf("1\n");
			continue;
		}
		if(check(s))
			printf("2\n");
		else 
			printf("-1\n");
	}
	return 0;
}
