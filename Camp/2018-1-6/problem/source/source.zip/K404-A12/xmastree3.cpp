#include <iostream>
#include <cstdio>
#include <cstring>
#define mod 998244353
using namespace std;
typedef long long ll;
struct edge{
	int k,next;
}e[205];
ll f[55][20],sum[55][20];
int home[55],cnt=-1,n,m,s[55][55],top[55];
bool vis[55];
void add(int x,int y){
	cnt++;
	e[cnt].k=y;
	e[cnt].next=home[x];
	home[x]=cnt;
}
void dfs1(int k,int F,int x){
	s[x][++top[x]]=k;
	for(int i=home[k];~i;i=e[i].next){
		if(e[i].k!=F&&!vis[e[i].k]) dfs1(e[i].k,k,x);
	}
}
void dfs(int k,int dep){
	vis[k]=1;
	for(int p=1;p<=m;p++) f[k][p]=1;
	if(dep==m){
		vis[k]=0;return;
	}
	for(int i=home[k];~i;i=e[i].next){
		if(!vis[e[i].k]){
			top[k]=0;
			dfs1(e[i].k,k,k);
			for(int j=1;j<=m;j++) sum[k][j]=0;
			for(int p=1;p<=top[k];p++){
				dfs(s[k][p],dep+1);
				for(int j=1;j<=m;j++){
					sum[k][j]=(sum[k][j]+f[s[k][p]][j])%mod;
				}
			}
			ll tot=0;
			for(int j=1;j<=m;j++){
				f[k][j]=(f[k][j]*tot)%mod;
				tot=(tot+sum[k][j])%mod;
			}
		}
	}
	vis[k]=0;
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	memset(home,-1,sizeof(home));
	scanf("%d%d",&n,&m);
	for(int i=1,x,y;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	ll ans=0;
	for(int i=1;i<=n;i++){
		dfs(i,1);
		for(int p=1;p<=m;p++) ans=(ans+f[i][p])%mod;
	}
	printf("%lld",ans);
	return 0;
}
