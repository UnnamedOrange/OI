#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=100010,INF=0x3f3f3f3f,Mod=1e9+7;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
}
int w[N],n,a,b,p[N],ans[4];
void init(){
	read(n),read(a),read(b);
	For(i,1,n)read(w[i]);
}
int st[N],tot;
bool dfs(int *s,int cnt,int now){
	int F=1,stp=now?b:a;
	For(i,1,cnt){
		if(s[i]>=stp){
			s[i]-=stp;
			F&=dfs(s,cnt,now^1);
			s[i]+=stp;
		}
	}
	return !F;
}
void calc(){
	if(tot==0)return void(ans[3]++);
	int a1,a2;
	a1=dfs(st,tot,0);
	a2=dfs(st,tot,1);
	if(a1==1&&a2==0)ans[0]++;
	if(a1==0&&a2==1)ans[1]++;
	if(a1==1&&a2==1)ans[2]++;
	if(a1==0&&a2==0)ans[3]++;
}
void dfs(int now){
	if(now>n){
		tot=0;
		For(i,1,n)if(p[i])st[++tot]=w[i];
		calc();
		return ;
	}
	p[now]=1;
	dfs(now+1);
	p[now]=0;
	dfs(now+1);
}
int cnt[2];
ll qpow(ll a,ll b){
	ll ret=1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
void solve1(){
	For(i,1,n)cnt[(w[i]/a)%2]++;
	if(cnt[1])ans[2]=qpow(2,cnt[1]-1)*qpow(2,cnt[0])%Mod;
	ans[3]=(qpow(2,n)+Mod-ans[2])%Mod;
	For(i,0,3)printf("%d ",ans[i]);puts("");
}
void solve(){
	if(a==b)return void(solve1());
	dfs(1);
	For(i,0,3)printf("%d ",ans[i]);puts("");
}
int main(){
	file();
	init();solve();
	return 0;
}
