#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int INF = 0x3f3f3f3f;
const int MAXN = 500010;
const int P = 1000000007;
const int MAXB = 5e7;
char buf[MAXB], *cp = buf;
inline void rd(int &x){
	x = 0;
	while(*cp < '0' || '9' < *cp) cp++;
	while('0' <= *cp && *cp <= '9') x = x * 10 + *cp++ - 48;
}
int n, m, L;
PII Q[MAXN];
int x[MAXN];
LL s[MAXN], f[MAXN], ans;
LL qm(LL a, LL x){
	LL ret = 0;
	while(x){
		if(x & 1) ret = ret * a % P;
		a = a * a % P;
		x >>= 1;
	}
	return ret;
}
int main(){
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	buf[fread(buf, 1, MAXB, stdin)] = 0;
	rd(n); rd(m);
	//scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; i++){
		int x, y;
		rd(x); rd(y);
		//scanf("%d%d", &x, &y);
		Q[i] = MP(y, x);
	}
	for(int i = 0; i < m; i++){
		rd(x[i]);
		//scanf("%d", &x[i]);
	}
	sort(x, x + m);
	sort(Q + 1, Q + n + 1);
	if(Q[1].S > x[0]) return puts("0"), 0;
	s[0] = 1;
	Q[0] = MP(0, 0);
	for(int i = 1; i <= n; i++){
		int p = lower_bound(x, x + m, Q[i].S) - x;
		if(Q[i].S <= x[p]) p--;
		if(p >= 0){
			int j = upper_bound(Q, Q + n + 1, MP(x[p], -INF)) - Q;
			f[i] = (s[i - 1] - s[j - 1] + P) % P;
		}
		else f[i] = s[i - 1];
		s[i] = (s[i - 1] + f[i]) % P;
		if(Q[i].F >= x[m - 1]) ans = (ans + f[i]) % P;
	}
	//for(int i = 0; i <= n; i++) printf("%lld %lld\n", f[i], s[i]);
	cout << ans << endl;
	return 0;
}
