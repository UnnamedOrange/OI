//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<set>
using namespace std;
#define ll long long
const int maxn=29;
ll T,n,sz,a[maxn],mi[maxn],c[maxn],usd[maxn],ans;

struct Node{
	ll x,ans;
	Node(){}
	Node(ll x,ll ans):x(x),ans(ans){}
	bool operator < (const Node& b) const{return x<b.x;}
};

set<Node> G;
set<ll> H[2];
set<ll>::iterator it;
set<Node>::iterator it2;

ll aa;char cc;
ll read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

ll get_id(ll* a) {
	ll rs=0,tot;
	for(int i=1;i<n;++i) {
		tot=0;
		for(int j=i+1;j<=n;++j) if(a[i]>a[j]) ++tot;
		rs+=tot*mi[n-i];
	}
	return rs+1;
}

void get_a(ll x) {
	--x;
	memset(c,0,sizeof(c));
	memset(usd,0,sizeof(usd));
	for(int i=1;i<n;++i) {
		c[i]=x/mi[n-i];
		x-=c[i]*mi[n-i];
	}
	for(int i=1;i<=n;++i) {
		x=c[i]+1;
		for(int j=1;j<=n;++j) if(!usd[j]&&(--x)==0) {
			a[i]=j; usd[j]=1;
			break;
		}
	}
}

void fz(int x) {for(int i=1;i<=x/2;++i) swap(a[i],a[x-i+1]);}

void init(int t,int o) {
	ll x;
	for(int i=2;i<=n;++i) {
		fz(i);
		x=get_id(a);
		if(G.find(Node(x,0))==G.end()) {
			G.insert(Node(x,t));H[o].insert(x);
		}
		fz(i);
	}
}

void doit(int t,int o) {
	ll x;
	for(int i=2;i<=n;++i) {
		fz(i);
		x=get_id(a);
		it2=G.find(Node(x,0));
		if(it2==G.end()) H[o].insert(x);
		else ans=min(ans,t+it2->ans);
		fz(i);
	}
}

int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	T=read();
	mi[1]=1; for(int i=2;i<=25;++i) mi[i]=mi[i-1]*(ll)i;
	while(T--) {
		n=read();sz=(n+1)>>1;
		ans=n+1; G.clear();
		for(int i=1;i<=n;++i) a[i]=read();
		ll x=get_id(a),o=0;
		H[0].clear(); H[0].insert(x); G.insert(Node(x,0));
		for(int i=1;i<=sz;++i) {
			o^=1;H[o].clear();
			for(it=H[o^1].begin();it!=H[o^1].end();++it) {
				get_a(*it);
				init(i,o);
			}
		}
		o=0; H[0].clear(); H[0].insert(1);
		for(int i=1;i<=sz&&i<=ans;++i) {
			o^=1;H[o].clear();
			for(it=H[o^1].begin();it!=H[o^1].end();++it) {
				get_a(*it);
				doit(i,o);
			}
		}
		printf("%lld\n",ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
2
5
5 3 4 1 2
8
8 6 1 3 2 4 5 7
*/
