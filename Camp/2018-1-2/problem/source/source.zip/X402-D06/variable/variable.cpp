#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const ll INF=1e18;
const long double eps=1e-9;
const int maxn=20;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int w,p,q;
ll ans=INF;
int x[maxn],y[maxn],z[maxn],a[maxn],b[maxn],c[maxn],d[maxn],e[maxn],f[maxn],Q[maxn];
int X[maxn],Y[maxn],R[maxn];
void dfs(int cur,int goal){
	int i;
	if(cur>goal){
		for(i=1;i<=q;i++){
			if(R[i]==0 && Q[X[i]]>Q[Y[i]])return;
			if(R[i]==1 && Q[X[i]]!=Q[Y[i]])return;
			if(R[i]==2 && Q[X[i]]>=Q[Y[i]])return;
		}
		ll sum=0;
		for(i=1;i<=goal;i++)sum+=1ll*w*Q[i];
		for(i=1;i<=p;i++){
			sum+=(1ll*a[i]*abs(Q[x[i]]-Q[y[i]])+1ll*b[i]*abs(Q[y[i]]-Q[z[i]])+1ll*c[i]*abs(Q[z[i]]-Q[x[i]])
				+1ll*d[i]*(Q[x[i]]-Q[y[i]])+1ll*e[i]*(Q[y[i]]-Q[z[i]])+1ll*f[i]*(Q[z[i]]-Q[x[i]]))*w;
		}
		ans=min(ans,sum);
		return;
	}
	Q[cur]=1;
	dfs(cur+1,goal);
	Q[cur]=-1;
	dfs(cur+1,goal);
}
int main(){
	int i,j,k,m,n,T;
#ifndef ONLINE_JUDGE
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
#endif
	T=read();
	while(T--){
		ans=INF;
		n=read();w=read();p=read();q=read();
		for(i=1;i<=p;i++){
			x[i]=read();y[i]=read();z[i]=read();
			a[i]=read();b[i]=read();c[i]=read();d[i]=read();e[i]=read();f[i]=read();
		}
		for(i=1;i<=q;i++){
			X[i]=read();Y[i]=read();R[i]=read();
		}
		dfs(1,n);
		printf("%lld\n",ans);
	}
	return 0;
}
