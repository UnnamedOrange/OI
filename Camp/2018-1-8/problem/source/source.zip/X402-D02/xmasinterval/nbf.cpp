#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define x first
#define y second

//		inline int lowbit(int x){return x&(-x);}
//		inline void add(int p,int x){for(;p<N;p+=lowbit(p))inc(x,s[p]);}
//		inline int ask(int p){int ret=0;for(;p;p-=lowbit(p))inc(s[p],ret);return ret;}
//		inline int query(int L,int R){int ret=ask(R);if(!L)return ret+1;return (ret-ask(L-1))%MOD;}

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
}

namespace liketobe
{
	typedef long long ll;
	typedef std::pair<int,int> pii;
	const int N=501000,MOD=1000000009;
	inline void inc(int a,int &b){b=(a+b)%MOD;}
	int mw[N],tot;
	inline int id_l(int x){return std::lower_bound(mw+1,mw+tot+1,x)-mw;}
	inline int id_r(int x){return std::upper_bound(mw+1,mw+tot+1,x)-mw-1;}

	bool cmp(pii A,pii B){return A.y==B.y?A.x<B.x:A.y<B.y;}

	pii s[N];
	int n,m;
	void initialize()
	{
		read(n),read(m);
		for(int i=1;i<=n;i++)read(s[i].x),read(s[i].y);
		tot=m;
		for(int i=1;i<=m;i++)read(mw[i]);
		std::sort(mw+1,mw+tot+1);
		tot=std::unique(mw+1,mw+tot+1)-mw-1;
		m=tot;

		for(int i=1;i<=n;i++)
			s[i].x=id_l(s[i].x),s[i].y=id_r(s[i].y);
		std::sort(s+1,s+n+1,cmp);
	}

	int f[N];

	void dp()
	{
		f[0]=1;
		for(int i=1;i<=n;i++)
		{
			f[i]=0;
			for(int j=i-1,x=1;j>=0;j--)
			{
				if(s[j].x>=s[i].x){x=x*2%MOD;continue;}
				if(s[j].y<s[i].x-1)break;
				inc((ll)f[j]*x%MOD,f[i]);
			}
		}
	}

	void solve()
	{
		initialize();
		dp();
		int ans=0;
		for(int i=1;i<=n;i++)
			if(s[i].y==m)inc(f[i],ans);
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.ans","w",stdout);
	liketobe::solve();
	return 0;
}
