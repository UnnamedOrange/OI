#include<bits/stdc++.h>
using namespace std;
int a[30], b[30];
int read()
{
	int tmp = 0; char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9')
	{
		tmp = tmp * 10 + c - '0';
		c = getchar();
	}
	return tmp;
}
int main()
{
	freopen("xmasset.in", "r", stdin);
	freopen("xmasset.out", "w", stdout);
	int t = read();
	if (t == 1)
	{
		int n, T;
		n = read(); T = read();
		for (int i = 1; i <= T; i++)
		{
			int x, y, tot1 = 0, tot2 = 0;
			x = read(); y = read();
			while (x)
			{
				a[++tot1] = x % 2;
				x /= 2;
			}
			while (y)
			{
				b[++tot2] = y % 2;
				y /=2;
			}
			for (int i = 1; i <= 10; i++)
				if (a[i] != b[i])
				{
					int h;
					if (a[i] == 0) h = i;
					else h = i + 10;
					printf("%d\n", h);
					break;
				}
		}
	}
	else
	{
		int n, T;
		n = read(); T = read();
		for (int i = 1; i <= T; i++)
		{
			int q, h;
			q = read(); h = read();
			if (h <= 10)
			{
				if ((q >> h - 1) & 1) puts("no"); else puts("yes");
			}
			else
			{
				h -= 10;
				if ((q >> h - 1) & 1) puts("yes"); else puts("no");
			}
		}
	}
	return 0;
}
