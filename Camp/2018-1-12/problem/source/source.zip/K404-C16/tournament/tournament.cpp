#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0;char ch=getchar();
	while(ch<'0'||'9'<ch)ch=getchar();
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret;
}
#define p 998244353
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	int n=re(),k=re();
	if(k==3){
		int num=n*(n-1)/2;
		int q=1;
		for(int i=0;i<num;i++)
			q=q*2%p;
		int h=1;
		for(int i=2;i<=n;i++)
			h=h*i%p;
		cout<<(q-h+p)%p<<endl;
	}else
		cout<<19260817<<endl;
	return 0;
}

