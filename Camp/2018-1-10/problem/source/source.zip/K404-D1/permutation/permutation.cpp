#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#define N 100010
#define ll long long
#define mod 998244353
using namespace std;
int n,ans,siz;
int p[N],num[N];
bool sp;
bool v[N],use[N];
void check(int x)
{
    siz++;
    v[x]=true;
    if(!v[num[x]])
        check(num[x]);
}
void dfs(int step)
{
    if(step==n+1)
    {
        bool ok=true;
        for(int i=1; i<=n; i++)
            v[i]=false;
        for(int i=1; i<=n; i++)
            if(!v[i])
            {
                siz=0;
                check(i);
                if(siz&1)
                {
                    ok=false;
                    break;
                }
            }
        if(ok)
            ans++;
    }
    else if(p[step])
        dfs(step+1);
    else for(int i=1; i<=n; i++)
            if(!use[i])
            {
                use[i]=true;
                num[step]=i;
                dfs(step+1);
                use[i]=false;
            }
}
void solve()
{
    if(n&1)
        puts("0");
    else
    {
        int ret=1;
        for(int i=3; i<=n; i+=2)
            ret=(ll)ret*i%mod;
        ret=(ll)ret*ret%mod;
        printf("%d",ret);
    }
    exit(0);
}
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
    sp=true;
    n=read();
    for(int i=1; i<=n; i++)
    {
        num[i]=p[i]=read();
        use[p[i]]=true;
        if(p[i])
            sp=false;
    }
    if(sp)
        solve();
    dfs(1);
    printf("%d",ans);
    return 0;
}
