//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=1000007;
typedef long long LL;
using namespace std;
int n,m,ans;

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

int ecnt,fir[N],nxt[N],to[N];
void add(int u,int v) {
	nxt[++ecnt]=fir[u]; fir[u]=ecnt; to[ecnt]=v;
}

int ec,fi[N],nx[N],tt[N],in[N],col[N];
void add_edge(int u,int v) {
	nx[++ec]=fi[u]; fi[u]=ec; tt[ec]=v; in[v]++;
}

int que[N],top,dfn[N],low[N],dfs_clock,tot,id[N],sz[N];
void tarjan(int x) {
	dfn[x]=low[x]=++dfs_clock;
	que[++top]=x;
	for(int i=fir[x];i;i=nxt[i]) {
		if(!dfn[to[i]]) {
			tarjan(to[i]);
			low[x]=min(low[x],low[to[i]]);
		}
		else if(!id[to[i]]) low[x]=min(low[x],dfn[to[i]]);
	}
	if(dfn[x]==low[x]) {
		id[x]=++tot;
		while(top) {
			int t=que[top--];
			id[t]=tot; sz[tot]++;
			if(t==x) break;
		}
	}
}

void tpsort() {
	top=0;
	for(int i=1;i<=tot;i++) 
		if(!in[i]) {
			col[i]=sz[i];
			que[++top]=i;
		}
	while(top) {
		int x=que[top--];
		for(int i=fi[x];i;i=nx[i]) {
			int y=tt[i];
			if(!col[y]) col[y]=col[x]+sz[y];
			else col[y]=max(col[y],col[x]+sz[y]);
			in[y]--;
			if(!in[y]) que[++top]=y;
		}	
	}
	for(int i=1;i<=tot;i++) 
		ans=max(ans,col[i]);
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
#endif
	read(n); read(m);
	for(int i=1;i<=m;i++) {
		int u,v;
		read(u); read(v);
		add(u,v);
	}
	for(int i=1;i<=n;i++) if(!dfn[i]) tarjan(i);
	for(int i=1;i<=n;i++) 
		for(int j=fir[i];j;j=nxt[j]) {
			int x=i,y=to[j];
			if(id[x]!=id[y]) 
				add_edge(id[x],id[y]);	
		}
	tpsort();
	printf("%d\n",ans);
	return 0;
}
