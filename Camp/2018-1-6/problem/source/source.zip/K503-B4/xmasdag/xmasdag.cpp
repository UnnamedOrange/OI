#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const int maxn=1e5+5;
const int mod=998244353;
int n,m,k,head[maxn],E[maxn*2],V[maxn*2],dis[2005][2005];
int cnt,du[maxn],que[maxn];
ll f[maxn],g[maxn],C[505][505],dp[maxn][505],F[maxn];
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
inline ll poww(int x,int t)
{
	ll res=1,tmp=x;
	while(t)
	{
		if(t&1)
			(res*=tmp)%=mod;
		(tmp*=tmp)%=mod;
		t>>=1;
	}
	return res;
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	read(n);
	read(m);
	read(k);
	if(k==1)
	{
		for(int i=1,u,v;i<=m;i++)
		{
			read(u);
			read(v);
			E[++cnt]=head[u];
			V[cnt]=v;
			head[u]=cnt;
			du[v]++;
		}
		int h=0,tail=0,now;
		for(int i=1;i<=n;i++)
			if(!du[i])
				que[tail++]=i;
		f[1]=1;
		while(h<tail)
		{
			now=que[h++];
			for(int i=head[now];i!=0;i=E[i])
			{
				(f[V[i]]+=f[now])%=mod;
				(g[V[i]]+=g[now]+f[now])%=mod;
				if(!(--du[V[i]]))
					que[tail++]=V[i];
			}
		}
		for(int i=1;i<=n;i++)
			printf("%lld\n",g[i]);
	}
	else if(n<=2000)
	{
		for(int i=1,u,v;i<=m;i++)
		{
			read(u);
			read(v);
			E[++cnt]=head[u];
			V[cnt]=v;
			head[u]=cnt;
			du[v]++;
		}
		int now=0,h=0,tail=0;
		dis[1][0]=1;
		for(int i=1;i<=n;i++)
			if(!du[i])
				que[tail++]=i;
		while(h<tail)
		{
			now=que[h++];
			for(int i=head[now];i!=0;i=E[i])
			{
				for(short e=0;e<n;e++)
					(dis[V[i]][e+1]+=dis[now][e])%=mod;
				if(!(--du[V[i]]))
					que[tail++]=V[i];
			}
		}
		for(int i=0;i<=n;i++)
			f[i]=poww(i,k);
		for(int i=1;i<=n;i++)
		{
			for(int e=0;e<=n;e++)
				(g[i]+=(f[e]*dis[i][e])%mod)%=mod;
			printf("%lld\n",g[i]);
		}
	}
	else
	{
		for(int i=1,u,v;i<=m;i++)
		{
			read(u);
			read(v);
			E[++cnt]=head[u];
			V[cnt]=v;
			head[u]=cnt;
			du[v]++;
		}
		C[0][0]=1;
		for(int i=1;i<=k;i++)
		{
			C[i][0]=1;
			for(int v=1;v<=i;v++)
				C[i][v]=(C[i-1][v]+C[i-1][v-1])%mod;
		}
		int h=0,tail=1,now;
		que[0]=1;
		f[1]=1;
		dp[1][0]=1;
		while(h<tail)
		{
			now=que[h++];
			for(int i=head[now];i!=0;i=E[i])
			{
				int to=V[i];
				(f[V[i]]+=f[now])%=mod;
				for(int e=0;e<=k;e++)
					for(int v=0;v<=e;v++)
						(dp[to][e]+=C[e][v]*dp[now][e-v]%mod)%=mod;
				if(!(--du[to]))
					que[tail++]=to;
			}
		}
		for(int i=1;i<=n;i++)
			printf("%lld\n",dp[i][k]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
