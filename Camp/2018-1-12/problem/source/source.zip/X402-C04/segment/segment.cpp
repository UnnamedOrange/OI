#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

typedef long long ll;
const int md=998244353;
const int M=1e5+9;
const int N=1e5+9;
int n,m,k;
int cnts[M],tots[M];
ll ans;

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)
			ret=ret*a%md;
		a=a*a%md;
		b>>=1;
	}
	return ret;
}

inline void chk(ll &x){if(x>=md)x-=md;}

inline void dfs(int l,int r,int cnt)
{
	if(cnt==n)
	{
		for(int i=1;i<=m;i++)
			chk(ans+=qpow(cnts[i],k));
		return;
	}
	for(int i=l+1;i<=m;i++)
		for(int j=max(i,r+1);j<=m;j++)
		{
			for(int k=i;k<j;k++)
				++cnts[k];
			dfs(i,j,cnt+1);
			for(int k=i;k<j;k++)
				--cnts[k];
		}
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);

	scanf("%d%d%d",&n,&m,&k);

	for(int i=1;i<=m;i++)
		for(int j=i;j<=m;j++)
		{
			for(int k=i;k<j;k++)
				++cnts[k];
			dfs(i,j,1);
			for(int k=i;k<j;k++)
				--cnts[k];
		}

	printf("%lld\n",ans);
	return 0;
}
