#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl
#define _x first
#define _y second

typedef long long LL;
typedef std::pair<int, int> Pii;

template <class T> inline bool maximum(T &a, T b) {return a < b? a = b, 1 : 0;}
template <class T> inline bool minimum(T &a, T b) {return a > b? a = b, 1 : 0;}
template <class T> inline T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = 1;
	for(;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 3e5 + 10;

bool r[N]; 
int w[N], n, fa[N], size[N], dep[N];

int e, to[N << 1], Next[N << 1], Begin[N];

void add_edge(int u, int v)
{
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

void dfs_INIT(int u, int f)
{
	fa[u] = f; size[u] = 1;
	for(int i = Begin[u]; i; i = Next[i]){
		int v = to[i];
		if(v == f) continue;
		dep[v] = dep[u] + 1;
		dfs_INIT(v, u);
		size[u] += size[v];
	}
}

namespace bfer
{
	const int N = 22;

	int dp[1 << 21];

	void main()
	{
		int ans = 0;
		for(int root = 1; root <= n; ++root){
			if(!r[root]) continue;
			else dfs_INIT(root, 0);

			for(int s = 1; s < 1<<(n+1); ++s) dp[s] = -1;
			dp[1] = 0;
			for(int s = 1; s < 1<<(n+1); ++s){
				if(dp[s] == -1) continue;
				for(int i = 1; i <= n; ++i){
					if(!(s & (1 << fa[i]))) continue;
					if(s & (1 << i)) continue;
					maximum(dp[s|(1<<i)], dp[s] + w[i]*__builtin_popcount(s));
				}
			}

			maximum(ans, dp[(1<<(n+1))-1]);
		}
		printf("%d\n", ans);
	}
}

namespace TX
{
	std::multiset<Pii> S;
	std::vector<Pii> G[N];
	bool vis[N];

	void main(int ans = 0)
	{
		for(int rt = 1; rt <= n; ++rt){
			if(!r[rt]) continue; else dfs_INIT(rt, 0);
			for(int i = 1; i <= n; ++i){
				int pi = n-size[i]+1;
				G[pi].push_back(Pii(i, pi));
				S.insert(Pii(-pi * w[i], pi));
			}

			for(int i = 1; i <= n; ++i) vis[i] = 0;
			int ret = 0;
			while(S.size()){
				Pii o = *S.begin();
				std::multiset<Pii>::iterator fir = S.begin();
				ret -= o._x; vis[o._y] = 1;
				int pos = o._y; while(vis[pos]) --pos;
				for(int i = 0; i < (int)G[o._y].size(); ++i){
					Pii u = G[o._y][i];

					std::multiset<Pii>::iterator it =
						S.lower_bound(Pii(-w[u._x]*u._y, u._y));
					if(it == fir){
						S.erase(it); continue;
					}else S.erase(it);

					S.insert(Pii(-pos*w[u._x], pos));
					G[pos].push_back(Pii(u._x, pos));
				}
				G[o._y].clear();
			}
			maximum(ans, ret);
		}
		printf("%d\n", ans);
	}
}

int main()
{
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);

	read(n);
	for(int i = 1; i < n; ++i){
		int u, v; read(u), read(v);
		add_edge(u, v);
	}
	for(int i = 1; i <= n; ++i) read(w[i]), read(r[i]);

	if(n <= 20) bfer::main(); else TX::main();
	return 0;
}
