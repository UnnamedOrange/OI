#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define per(a,b,c) for (int a=b;a>=c;a--)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
int s,t,n,m;
const int N=1000010,lim=1000000,P=1000000007;
LL s1[N],sinv[N],inv[N],f[N],g[N],ans;
LL C(int n,int m){
	return s1[n]*sinv[m]%P*sinv[n-m]%P;
}
void preset(){
	inv[1]=1;
	sinv[0]=s1[0]=1;
	rep(i,2,lim) inv[i]=inv[P%i]*(P-P/i)%P;
	rep(i,1,lim) sinv[i]=sinv[i-1]*inv[i]%P;
	rep(i,1,lim) s1[i]=s1[i-1]*i%P;
}
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	preset();
	rep(i,0,s) f[i]=C(m+i,m);
	rep(i,0,s) if (i%t==0){
		LL sgn=i/t%2==0?1:-1;
		g[i]=sgn*C(n,i/t);
	}
	rep(i,0,s) ans=(ans+f[i]*g[s-m-i])%P;
	ans=(ans+P)%P;
	printf("%lld\n",ans);
	return 0;
}

