#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
char s[100005],a[100005],b[100005];
int main(){
	freopen("string.in","r",stdin); freopen("string.out","w",stdout);
	int _=read(),l,l1,l2,f,fl[27],ma;
	while(_--){
		memset(fl,0,sizeof(fl)); f=0; ma=0;
		l=read(); scanf("%s",s+1);
		For(i,1,l/2)
			if (s[i]==s[l-i+1]);
			else {f=1; break;}
		if (f) {printf("1\n"); continue;}
		For(i,1,l) ++fl[s[i]-96];
		For(i,1,26) if (fl[i]) ma=max(ma,fl[i]);
		if (ma>=l-1) {printf("-1\n"); continue;}
		if (l%2==0) f=1;
		if (!f)
			for(int i=3;i<=l;i+=2)
				if (a[i]==a[i-2]); else {f=1; break;}
		if (!f)
			for(int i=4;i<=l;i+=2)
				if (a[i]==a[i-2]); else {f=1; break;}
		if (!f) {printf("-1\n"); continue;}
		if (l>200) {printf("2\n"); continue;}
		For(i,1,l-1)
			For(j,i+1,l){
				l1=i-1; l2=j-i+1;
				For(k,1,i-1) a[k]=s[k];
				For(k,i,j) b[k-i+1]=s[k];
				For(k,j+1,l) a[++l1]=s[k];
				f=0;
				For(k,1,l1/2)
					if (a[k]==a[l1-k+1]);
					else {++f; break;}
				if (f)
					For(k,1,l2/2)
						if (b[k]==b[l2-k+1]);
						else {++f; break;}
				if (f<2); else {printf("2\n"); goto en;}
			}
		printf("-1\n"); en:;
	}
	return 0;
}
