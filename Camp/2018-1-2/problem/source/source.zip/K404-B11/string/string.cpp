#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int t,n,dp[10010];
char s[10010];

bool judge(int l,int r){
	if(l==r)return 0;
	while(l<=r&&s[l]==s[r])l++,r--;
	if(l>=r)return 0;
	return 1;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		memset(dp,0x3f,sizeof(dp));
		dp[0]=0;
		scanf("%d%s",&n,s+1);
		for(int i=2;i<=n;i++)
		  for(int j=1;j<i;j++)
			if(judge(j,i))
			  dp[i]=min(dp[i],dp[j-1]+1);
		if(dp[n]==0x3f3f3f3f)printf("-1\n");
		else printf("%d\n",dp[n]);
	}
	return 0;
}
