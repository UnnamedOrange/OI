#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 500010;
const int MAXM = 500010;
const ll MOD = 1000000009;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, x[MAXM];
int lf[MAXN], rf[MAXN];
struct Segment {
	int l, r;
	bool operator < (const Segment &rhs) const {
		return l < rhs.l || (l == rhs.l && r < rhs.r);
	}
}s[MAXN];
ll dp[MAXN], ans, p2[MAXN];

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);

	int i, j;

	n = read(), m = read();

	p2[0] = 1;
	for(i = 1; i <= n; i++) p2[i] = (p2[i-1]<<1)%MOD;
	for(i = 1; i <= n; i++) 
		s[i].l = read(), s[i].r = read();
	for(i = 1; i <= m; i++) x[i] = read();
	sort(x+1, x+m+1);
	sort(s+1, s+n+1);

	for(i = 1; i <= n; i++) {
		lf[i] = lower_bound(x+1, x+m+1, s[i].l)-x;
		rf[i] = upper_bound(x+1, x+m+1, s[i].r)-x-1;
		//printf("%d %d\n", lf[i], rf[i]);
	}
	for(i = 1; i <= n; i++) 
		if(lf[i] <= 1) dp[i] = 1;

	for(i = 1; i <= n; i++) {
		int c = 0;
		for(j = i+1; j <= n; j++) {
			if(lf[j] > rf[i]+1) break;
			if(s[j].r <= s[i].r) {
				c++;
				continue;
			}
			update(dp[j], dp[i]*p2[c]%MOD);
		}
		if(s[i].r >= x[m]) update(ans, dp[i]*p2[c]%MOD);
	}
	//printf("%lld %lld\n", dp[3], dp[4]);
	printf("%lld\n", ans);
	return 0;
}
