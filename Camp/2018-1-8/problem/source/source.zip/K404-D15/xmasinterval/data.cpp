#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

int n,m;

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

int main(){
	srand(time(NULL)+clock());
    n=5000,m=5000; printf("%d %d\n",n,m);
	for (int i=1;i<=n;i++){
		int l=rand()+1,r=rand()+1;
		if (l>r) swap(l,r); printf("%d %d\n",l,r);
	}
	for (int i=1;i<=m;i++) printf("%d\n",rand()+1);
	return 0;
}
