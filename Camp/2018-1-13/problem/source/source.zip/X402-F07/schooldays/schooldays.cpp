#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1000005;
struct data{
	int val,cnt;
	void merge(const data &A){
		if(chkmax(val,A.val))cnt=0;
		if(val==A.val)cnt+=A.cnt;
	}
}f[maxn];
int n;
int c[maxn],d[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
#endif
	n=read();
	REP(i,1,n)c[i]=read(),d[i]=read();
	f[0]=(data){0,1};
	REP(i,1,n){
		f[i]=(data){0,0};
		int Max=0,Min=n;
		DREP(j,i,1){
			chkmin(Min,d[j]);
			chkmax(Max,c[j]);
			if(i-j+1>Min)break;
			if(i-j+1>=Max)f[i].merge(f[j-1]);
		}++f[i].val;
	}
	if(f[n].cnt==0)puts("-1");
	else write(f[n].val,' '),write(f[n].cnt,'\n');
	return 0;
}
