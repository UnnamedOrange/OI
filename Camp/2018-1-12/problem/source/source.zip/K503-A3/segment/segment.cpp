#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
#define pr pair<int, int>
#define x first
#define y second
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while(!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while(isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n = n * sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 122222;
const int MOD = 998244353;
int n, m, k, ans;
int cnt[N];
pr d[N];

void upd(int& a, int b){a += b; if (a >= MOD) a -= MOD;}
ll mut(ll a, ll b){
	ll y = 1, t = a;
	for (; b; b >>= 1, t = t * t % MOD)
		if (b & 1) y = y * t % MOD;
	return y; 
}
void calc(){
	rep(i, 1, m) cnt[i] = 0;
	rep(i, 1, n)
		rep(j, d[i].x, d[i].y - 1) cnt[j]++;
	rep(i, 1, m) upd(ans, mut(cnt[i], k));
}
void dfs(int x, int l, int r){
	if (x > n) {calc(); return ;}
	rep(i, l + 1, m) rep(j, r + 1, m)
		d[x] = mp(i, j), dfs(x + 1, i, j);
}

int main(){
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	read(n), read(m), read(k);
	if (n > m) return 0 * puts("0");
	dfs(1, 0, 0);
	printf("%d\n", ans);
	return 0;
}

