//© 2018 Jazengm/ZengXiangru, AllRightsReserved
#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int mxn=10086;

int f[mxn];

struct edge
{
    int v,o;
    In edge(int v=0, int o=0):
    v(v), o(o) {}
} e[mxn<<1];

int col[mxn], h[mxn];

In void aE(int u, int v)
{St int tot=1; e[++tot]=edge(v, u[h]), u[h]=tot;}

#define fev for(Rg int i=u[h], v; v=i[e].v, i>0; i=i[e].o)

void DFS(int w, int u)
{
    u[f]=w;
   fev if(v!=w)
       DFS(u, v);
}

int cnt[mxn], ans;

void solve(int u, int l, int r)
{
    if(col[u]>=l && r>=col[u] && !cnt[col[u]])
        cnt[col[u]]=1, ++ans;
    fev
        if(v!=u[f])
            solve(v, l, r);
}

int main()
{
    freopen("xmastree1.in", "r", stdin);
    freopen("xmastree1.in", "w", stdout);
    St int n, q, t;
    scanf("%d%d%d", &n, &q, &t);
    inc(1, i, n+1)
        scanf("%d", col+i);
    inc(1, i, n)
    {
        St int u, v;
        scanf("%d%d", &u, &v);
        aE(u, v), aE(v, u);
    }
    Rg int lastans=0;
    DFS(0, 1);
    if(n<=5000)
    {
        inc(0, i, q)
        {
            St int opt;
            scanf("%d", &opt);
            if(opt==1)
            {
                St int u, l, r;
                scanf("%d%d%d", &u, &l, &r);
                u^=lastans, l^=lastans, r^=lastans;
                memset(cnt, 0, sizeof(cnt)), ans=0;
                solve(u, l, r);
                if(t) lastans=ans;
                printf("%d\n", ans);
            }
            else
            {
                St int u, c;
                scanf("%d%d", &u, &c);
                u^=lastans, c^=lastans;
                col[u]=c;
            }
        }
    }
    Re 0;
}
