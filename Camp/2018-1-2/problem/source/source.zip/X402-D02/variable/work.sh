a=1
while $ture ; do 
	echo Case : $a
	let a++
	./gen
	./bf
	./variable
	if diff ./variable.out ./variable.ans ; then echo AC ;
	else echo wa ; exit 1 ; fi
done
