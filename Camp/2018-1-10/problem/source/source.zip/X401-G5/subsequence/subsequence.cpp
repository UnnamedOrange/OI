#include<bits/stdc++.h>
using namespace std;
int a[1000],b[1000],c[1000],n,m,k;
void dfs(int i,int j){
	if (i>j)
	{
		int now=1;
		for (int k=1;k<=n;k++)
		if (a[k]==c[now]) now++;
		if (now==(j+1)) return ;
		now=1;
		for (int k=1;k<=m;k++)
		if (b[k]==c[now]) now++;
		if (now==(j+1)) return ;
		cout<<j;
		exit(0);
	}
	c[i]=1;
	dfs(i+1,j);
	c[i]=2;
	dfs(i+1,j);
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++)
	   scanf("%d",&a[i]);
	for (int i=1;i<=m;i++)
	  scanf("%d",&b[i]);
	for (int i=1;i<=max(n,m)+1;i++)
	  dfs(1,i);
}
