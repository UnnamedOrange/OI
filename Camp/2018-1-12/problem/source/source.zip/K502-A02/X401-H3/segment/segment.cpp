#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mod=998244353;
ll read(){
    ll f=1,ret=0;
    char ch=getchar();
    while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
    while(ch<='9'&&ch>='0'){ret=ret*10+ch-'0';ch=getchar();}
    return f*ret;
}
const int N=100005;
ll n,m,k,ans;
int l[N],r[N];

ll ksm(ll a,ll b){
	ll ret=1;
	while(b){
		if(b&1)ret=(ret*a)%mod;
		a=(a*a)%mod;
		b>>=1;
	}
	return ret;
}

int a[N];
void calc(){
	for(int i=1;i<=m;i++)a[i]=0;
	for(int i=1;i<=n;i++){
		for(int j=l[i];j<r[i];j++)a[j]++;
	}
	for(int i=1;i<=m;i++)ans=(ans+ksm(a[i],k))%mod;;
}

void dfs(int dep){
	if(dep==n+1){calc();}
	for(int i=l[dep-1]+1;i<=m;i++){
		l[dep]=i;
		for(int j=max(i,r[dep-1]+1);j<=m;j++){
			r[dep]=j;
			dfs(dep+1);
			r[dep]=0;
		}
		l[dep]=0;
	}
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=read();m=read();k=read();
	if(n>=m){cout<<0;return 0;}
	dfs(1);	
	cout<<ans;
	return 0;
}

