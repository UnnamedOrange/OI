#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <algorithm>
using namespace std;
int main()
{
	freopen("xmasinterval.in","w",stdout);
	srand(time(0));
	int n=20,m=10;printf("%d %d\n",n,m);
	while (n--){
		int l=rand()%20+1,r=rand()%20+1;
		if (l>r) swap(l,r);printf("%d %d\n",l,r);
	}while (m--) printf("%d\n",rand()%20+1);
	return 0;
}
