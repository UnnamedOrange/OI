//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const ll maxn=1e6+10,INF=1e6;
ll T,n,ans;

ll aa;char cc;
ll read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

ll mu[maxn],prime[maxn],totp,f[maxn];
bool ok[maxn];
void get_ol() {
	mu[1]=1;
	for(int i=2;i<=INF;++i) {
		if(!ok[i]) {
			prime[++totp]=i;
			mu[i]=-1;
			f[i]=totp;
		}
		for(int j=1;j<=totp&&prime[j]<=INF/i;++j) {
			ok[i*prime[j]]=1; f[i*prime[j]]=j;
			if(i%prime[j]) 
				mu[i*prime[j]]=-mu[i];
			else {
				mu[i*prime[j]]=0;
				break;
			}
		}
	}
}

ll sum[maxn],num[maxn];
ll get_sum(ll i) {
	ll t=prime[f[i]],tt=1,x=i;
	if(f[i/t]==f[i]) {
		num[i]=num[i/t]+1;
		return sum[i/t]/num[i]*(num[i]+1);
	}
	while(i%t==0) {
		i/=t;
		tt++;
	}
	num[x]=tt-1;
	return tt*sum[i];
}

int main() {
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	T=read();
	if(T) {
		get_ol();
		sum[1]=1;
		for(int i=2;i<=INF;++i) sum[i]=get_sum(i);
		for(int i=2;i<=INF;++i) sum[i]=sum[i]*sum[i]+sum[i-1];
	}
	
	while(T--) {
		n=read(); ans=0;
		for(int i=1;i<=n;++i) ans+=mu[i]*sum[n/i];
		printf("%lld\n",ans);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}

