#include<bits/stdc++.h>
using namespace std;
int c[510][510];
#define N 100010
const int mod=998244353;
struct Edge {
	int u,v,nxt;
}e[N*2];
int head[N],cnt;
void add(int u,int v) {
	e[++cnt].u=u;e[cnt].v=v;e[cnt].nxt=head[u];head[u]=cnt;
}
void pre(int K) {
	c[0][1]=1;
	for(int i=1;i<=K;i++) {
		for(int j=1;j<=i+1;j++) {
			c[i][j]=c[i-1][j-1]+c[i-1][j];
			c[i][j]%=mod;
		}
	}
	for(int i=0;i<=K;i++) c[K][0]=1;
}
unsigned long long xi[510][N];
int K,r[N];
void dfs(int po) {
	for(int i=head[po];i!=-1;i=e[i].nxt) {
		int v=e[i].v;
		int fff=0;
		for(int j=0;j<=K;j++) {
			for(int k=0;k<=j;k++) {
				xi[j][v]=(xi[j][v]+xi[k][po]*c[j][k+1])%mod;
			}
			if(po==1) ++xi[j][v];
		}
		r[v]--;
		if(r[v]==0) dfs(v);
	}
}
int main() {
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	int n,m;
	scanf("%d%d%d",&n,&m,&K);
	memset(head,-1,sizeof(head));
	pre(K);
	for(int i=1;i<=m;i++) {
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		r[v]++;
	}
	dfs(1);
	for(int i=1;i<=n;i++) {
		printf("%d\n",(int)xi[K][i]);
	}
}
