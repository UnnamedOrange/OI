#include <bits/stdc++.h>

typedef long long int int64;
typedef std::bitset<100000> bs;
struct vertex {
	int estart,parent;
	int dfs1,dfs2,c;
} v[100003];
struct edge {
	int enext;
	int to;
} e[200003];int en;
int dfn,dfnv[100003];
void dfs(int i)
{
	dfnv[dfn] = i;
	v[i].dfs1 = dfn++;
	for(int j = v[i].estart;j != -1;j = e[j].enext) {
		int to = e[j].to;
		if(v[to].parent == -2) {
			v[to].parent = i;
			dfs(to);
		}
	}
	v[i].dfs2 = dfn;
}
struct sectree {
	int mid,left,right,ltree,rtree;
	bool leaf;
	bs val;
	void init(int l,int r);
	void query(int l,int r,bs &ret);
	void set(int i,int fromc,int c);
} t[2003];int tn;
void sectree::init(int l,int r) {
	left = l,right = r,mid = (l + r) >> 1;
	if(r - l <= 100) {
		leaf = true;
		for(int i = l;i <= r;++i)
			val.set(v[dfnv[i]].c);
	} else {
		leaf = false;
		mid = (l + r) >> 1;
		t[ltree = tn++].init(l,mid);
		t[rtree = tn++].init(mid+1,r);
		val = t[ltree].val | t[rtree].val;
	}
}
void sectree::query(int l,int r,bs &ret)
{
	if(l == left && r == right)
		ret |= val;
	else if(leaf) {
		for(int i = l;i <= r;++i)
			ret.set(v[dfnv[i]].c);
	} else {
		if(l <= mid)
			t[ltree].query(l,std::min(mid,r),ret);
		if(r > mid)
			t[rtree].query(std::max(mid,l),r,ret);
	}
}
void sectree::set(int i,int fromc,int c)
{
	if(leaf) {
		val.reset();
		for(int i = left;i <= right;++i)
			val.set(v[i].c);
	} else {
		if(i <= mid)
			t[ltree].set(i,fromc,c);
		else
			t[rtree].set(i,fromc,c);
		val[fromc] = t[ltree].val[fromc] | t[rtree].val[fromc];
		val.set(c);
	}
}
bs pre[2003],suf[2003];
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int n,q,tt;
	scanf("%d%d%d",&n,&q,&tt);
	for(int i = 0;i < n;++i) {
		v[i].estart = -1;v[i].parent = -2;
		scanf("%d",&v[i].c);--v[i].c;
		pre[i].set(i);
	}
	for(int i = 0;(i << 6) < n;++i) {
		if(i > 0) pre[i] = pre[i - 1];
		for(int j = 0;j < 64;++j) pre[i].set((i<<6>>6)+j);
		suf[i] = ~pre[i];
	}
	for(int i = 0;i < n - 1;++i) {
		int a,b;
		scanf("%d%d",&a,&b);--a,--b;
		e[en].enext = v[a].estart;e[en].to = b;v[a].estart = en++;
		e[en].enext = v[b].estart;e[en].to = a;v[b].estart = en++;
	}
	v[0].parent = -1;dfs(0);
	tn = 0;t[0].init(0,n-1);
	int lastans = 0;
	for(int i = 0;i < q;++i) {
		int cmd;scanf("%d",&cmd);
		if(cmd == 1) {
			int u,l,r;
			scanf("%d%d%d",&u,&l,&r);
			if(tt == 1) {l ^= lastans,r ^= lastans,u ^= lastans;}--u,--l,--r;
			//std::cout << t[0].val << std::endl;
			bs s;
			t[0].query(v[u].dfs1,v[u].dfs2-1,s);
			
			//std::cout << s << std::endl;
				s &= pre[r >> 6];
				for(int j = r + 1;j < (((r >> 6) + 1) << 6);++j)
					s.reset(j);
					
			//std::cout << s << std::endl;
			if(l > 0) {
				if(l >= 64) s &= suf[(l >> 6) - 1];
				for(int j = l >> 6 << 6;j < l;++j)
					s.reset(j);
			}
			//std::cout << s << std::endl;
			
			
			lastans = s.count();
			printf("%d\n",lastans);
		} else {
			int u,c;
			scanf("%d%d",&u,&c);if(tt == 1) {u ^= lastans,c ^= lastans;}
			--u,--c;int org = v[u].c;v[u].c = c;
			t[0].set(v[u].dfs1,org,c);
		}
	}
}
