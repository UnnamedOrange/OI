#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cctype>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
const int N=55,mod=998244353;
bool vis[N];
int n,k,cnt,siz,rt,h[N],a[N],c[N],ans;
struct edge{int v,n;} e[N<<1];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void addedge(int u,int v)
{
	e[cnt]=(edge){v,h[u]},h[u]=cnt++;
	e[cnt]=(edge){u,h[v]},h[v]=cnt++;
}

void dfs(int x,int fa)
{
	if(!rt || a[x]<a[rt]) rt=x,siz=1;
	else if(a[x]==a[rt]) ++siz;
	for(int i=h[x]; i!=-1; i=e[i].n)
		if(e[i].v!=fa && !vis[e[i].v])
			dfs(e[i].v,x);
}

bool check(int x)
{
	rt=0,siz=0;
	dfs(x,0);
	if(siz>1) return 0;
	vis[rt]=1;
	for(int i=h[rt]; i!=-1; i=e[i].n)
		if(!vis[e[i].v])
			if(!check(e[i].v))
				return 0;
	return 1;
}

void dfs(int x)
{
	if(c[1]>1) return;
	if(x>n)
	{
		rep(i,1,n) vis[i]=0;
		if(check(1)) ++ans;
		return;
	}
	rep(i,1,k)
	{
		a[x]=i,++c[i],dfs(x+1);
		a[x]=0,--c[i];
	}
}

int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	n=getint(),k=getint(),memset(h,-1,sizeof(h));
	rep(i,1,n-1) addedge(getint(),getint());
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
