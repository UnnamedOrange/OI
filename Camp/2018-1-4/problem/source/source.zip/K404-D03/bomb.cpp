#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=1001000;

int last[N],ecnt;
struct EDGE{int to,nt;}e[N];
inline void add(int u,int v)
{e[++ecnt]=(EDGE){v,last[u]};last[u]=ecnt;}

int n,m;

int bel[N],size[N],scc;
int dfn[N],low[N],tim;
int st[N],top;
bool ins[N];

void tarjan(int u)
{
	dfn[u]=low[u]=++tim;
	st[++top]=u;ins[u]=1;
	for(int i=last[u],v;i;i=e[i].nt)
	{
		v=e[i].to;
		if(!dfn[v])
			tarjan(v),low[u]=min(low[u],low[v]);
		else if(ins[v])
			low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		scc++;
		int tmp;
		do
		{
			tmp=st[top--];
			ins[tmp]=0;
			bel[tmp]=scc;
			size[scc]++;
		}while(tmp!=u);
	}
}

int ind[N];
vector<int> son[N];

int q[N],dis[N];

void topo()
{
	register int i,head(0),tail(0),u,v;
	for(i=1;i<=scc;++i)
		if(!ind[i])
			q[tail++]=i,dis[i]=size[i];
	while(head<tail)
	{
		u=q[head++];
		for(i=0;i<son[u].size();++i)
		{
			v=son[u][i];
			dis[v]=max(dis[v],dis[u]+size[v]);
			ind[v]--;
			if(!ind[v]) q[tail++]=v;
		}
	}
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	
	n=read();m=read();
	register int i,u,v;
	while(m--)
	{
		u=read();v=read();
		add(u,v);
	}
	for(i=1;i<=n;++i)
		if(!dfn[i])
			tarjan(i);
	for(u=1;u<=n;++u)
		for(i=last[u];i;i=e[i].nt)
			if(bel[u]!=bel[v=e[i].to])
				ind[bel[v]]++,
				son[bel[u]].push_back(bel[v]);
	topo();
	int ans=0;
	for(i=1;i<=scc;++i)
		ans=max(ans,dis[i]);
	cout<<ans<<endl;
	return 0;
}


