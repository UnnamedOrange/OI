#include <iostream>
#include <cstdio>
using namespace std;
int t, n;
char s[100010];
inline bool check () {
	int l = 1, r = n;
	while (l < r) {
		if (s[l] != s[r]) return false;
		l++, r--;
	}
	return true;
}
inline bool eq () {
	bool r = true;
	for (int i = 2; i <= n / 2; i++) if (s[i] != s[i - 1]) r = false;
	return r;
}
inline bool xh () {
	bool r = true;
	for (int i = 1; i <= n / 2 + 1; i++) if (s[i] != s[i & 1] || s[n - i + 1] != s[i & 1]) r = false;
	return r;
}
inline void solve () {
	scanf ("%d", &n);
	scanf ("%s", s + 1);
	if (!check ()) { printf ("1\n"); return; }
	if (eq ()) { printf ("-1\n"); return; }
	if (n <= 3) { printf ("-1\n"); return; }
	if (n & 1) {
		if (xh ()) { printf ("-1\n"); return; }
		else { printf ("2\n"); return; }
	} else { printf ("2\n"); return; }
}
int main () {
	freopen ("string.in", "r", stdin);
	freopen ("string.out", "w", stdout);
	scanf ("%d", &t);
	while (t--) solve ();
	return 0;
}
