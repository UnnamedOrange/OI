#include <map>
#include <cstdio>

using namespace std;
typedef long long ll;
const int N=1e7;

int tc,n,pr[N/10],tot,cnt[N];
ll f1[N],ans;
map<int,ll> f2;

void init()
{
    f1[1]=1;
    for (int i=2; i<N; ++i)
    {
        if(!cnt[i])
            pr[++tot]=i,cnt[i]=1;
        for(int j=1,t; j<=tot && (t=i*pr[j])<N; ++j)
            if (cnt[t]=cnt[i],i%pr[j])
                ++cnt[t];
            else
                break;
        f1[i]=f1[i-1]+(1<<cnt[i]);
    }
}

const ll f(int x)
{
    if(x<N)
        return f1[x];
    ll &ans=f2[x];
    if (ans)
        return ans;
    for(int l=1,r,t; l<=x; l=r+1)
        t=x/l,r=x/t,ans+=t*(r-l+1ll);
    for(int i=2,t; (t=i*i)<=x; ++i)
        ans-=f(x/t);
    return ans;
}

int main()
{
    freopen("function.in","r",stdin);
    freopen("function.out","w",stdout);
    init();
    for (scanf("%d",&tc); tc--;)
    {
        scanf("%d",&n),ans=0;
        for (int l=1,r,t; l<=n; l=r+1)
            t=n/l,r=n/t,ans+=f(t)*(r-l+1);
        printf("%lld\n",ans);
    }
    return 0;
}
