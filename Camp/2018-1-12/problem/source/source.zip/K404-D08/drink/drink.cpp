#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define per(a,b,c) for (int a=b;a>=c;a--)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=1000010;
int a[N],p[N],/*vis[N],*/n;
dob ans;
int cmp(int x,int y){
	return a[x]==a[y]?x<y:a[x]>a[y];
}
#define ___ int t=1,int l=1,int r=n
#define mid ((l+r)>>1)
#define ls t<<1,l,mid
#define rs t<<1|1,mid+1,r
struct dat{
	dob s,k;
}t1[N<<2],t2[N<<2];
int _x;
dat operator +(dat x,dat y){
	return (dat){x.s+y.s*x.k,x.k*y.k};
}
dat ask1(___){
	if (_x==l) return t1[t];
	if (_x>mid) return ask1(rs);
	return ask1(ls)+t1[t<<1|1];
}
dat ask2(___){
	if (_x==r) return t2[t];
	if (_x<=mid) return ask2(ls);
	return ask2(rs)+t2[t<<1];
}
void rev(___){
	if (l==r){
		t1[t]=t2[t]=(dat){0.5,0.5};
		return;
	}
	if (_x<=mid) rev(ls); else rev(rs);
	t1[t]=t1[t<<1]+t1[t<<1|1];
	t2[t]=t2[t<<1|1]+t2[t<<1];
}
void calc(int x){
	dob /*k=1,*/s1=0,s2=0;
//	rep(i,x,n){
//		if (vis[i]) k/=2;
//		s1+=k;
//	}
//	k=1;
//	per(i,x,1){
//		if (vis[i]) k/=2;
//		s2+=k;
//	}
	_x=x;
	s1=ask1().s;
	s2=ask2().s;
	ans+=s1*s2*a[x];
}
void add(int x){
//	vis[x]=1;
	_x=x,rev();
}
void build(___){
	if (l==r){
		t1[t]=t2[t]=(dat){1,1};
		return;
	}
	build(ls),build(rs);
	t1[t]=t1[t<<1]+t1[t<<1|1];
	t2[t]=t2[t<<1|1]+t2[t<<1];
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	rep(i,1,n) scanf("%d",a+i);
	rep(i,1,n) p[i]=i;
	sort(p+1,p+1+n,cmp);
	build();
	rep(i,1,n){
		int x=p[i];
		calc(x);
		add(x);
	}
	printf("%.8lf\n",ans/n/n/2);
	return 0;
}

