#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=4005,MM=250000,INF=(int)1e9+7;
void Max(int &x,int y){
	if(x<y)x=y;
}
void Min(int &x,int y){
	if(x>y)x=y;
}
int n,m,K,a[M],b[M],rta[M],rtb[M];
int Lson[MM],Rson[MM],val[MM],tot;
int dpa[M],dpb[M];
void build(int L,int R,int &p,int v){
	p=++tot;
	val[p]=v;
	if(L==R)return;
	int mid=(L+R)>>1;
	build(L,mid,Lson[p],v);
	build(mid+1,R,Rson[p],v);
}
void update(int L,int R,int &p,int x,int v){
	int rp=p;
	p=++tot;
	Lson[p]=Lson[rp];
	Rson[p]=Rson[rp];
	val[p]=v;
	if(L==R)return;
	int mid=(L+R)>>1;
	if(mid>=x)update(L,mid,Lson[p],x,v);
	else update(mid+1,R,Rson[p],x,v);
}
int query(int L,int R,int p,int x){
	if(L==R)return val[p];
	int mid=(L+R)>>1;
	if(mid>=x)return query(L,mid,Lson[p],x);
	else return query(mid+1,R,Rson[p],x);
}
void init(){
	build(1,K,rta[n],n+1);
	build(1,K,rtb[m],m+1);
	for(int i=n-1;i>=0;i--){
		rta[i]=rta[i+1];
		update(1,K,rta[i],a[i+1],i+1);
	}
	for(int i=m-1;i>=0;i--){
		rtb[i]=rtb[i+1];
		update(1,K,rtb[i],b[i+1],i+1);
	}
	for(int i=n;i>=1;i--){
		dpa[i]=INF;
		for(int j=1;j<=K;j++)
			Min(dpa[i],dpa[query(1,K,rta[i],j)]);
		dpa[i]++;
	}
	for(int i=m;i>=1;i--){
		dpb[i]=INF;
		for(int j=1;j<=K;j++)
			Min(dpb[i],dpb[query(1,K,rtb[i],j)]);
		dpb[i]++;
	}
}
int qx[M*M],qy[M*M],vvv[M*M];
int mark[M][M];
void solve(){
	int L=0,R=0,x,y,v,vv,nx,ny;
	qx[R]=0,qy[R]=0,vvv[R++]=0;
	mark[0][0]=1;
	int preans=INF;
	for(;val[L]<preans;){
		x=qx[L],y=qy[L],v=vvv[L++],vv=v+1;
		for(int i=1;i<=K;i++){
			nx=query(1,K,rta[x],i);
			ny=query(1,K,rtb[y],i);
			if(nx>n){
				Min(preans,v+dpb[ny]);
			}else if(ny>m){
				Min(preans,v+dpa[nx]);
			}else {
				if(mark[nx][ny]==0){
					qx[R]=nx,qy[R]=ny,vvv[R++]=vv;
					mark[nx][ny]=1;
				}
			}
		}
	}
	printf("%d\n",preans+1);
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d %d %d",&n,&m,&K);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	init();
	solve();
	return 0;
}
