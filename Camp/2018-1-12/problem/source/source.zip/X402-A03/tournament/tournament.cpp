/*****************************************************
	File:tournament.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-12 09:07:56
*****************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define mod 998244353
#define N 5010
int n,k,t[N][N],ans,p[N],a[N],flag;
void dfs2(int x)
{
	if(x==k+1)
	{
		if(!t[a[k]][a[1]])
			return;
		fr(i,1,k-1)
			if(!t[a[i]][a[i+1]])
				return;
		flag=1;
		return;
	}
	fr(i,1,n)
		if(!p[i])
		{
			a[x]=i;
			p[i]=1;
			dfs2(x+1);
			p[i]=0;
		}
}
//int cnt;
void dfs(int u,int v)
{
//	if(++cnt>1000)return;
//	printf("%d %d\n",u,v);
	if(u==n)
	{
		flag=0;
		dfs2(1);
		ans+=flag;
		return;
	}
	int uu=u,vv=v+1;
	if(v==n)
	{
		uu++;
		vv=uu+1;
	}
	t[u][v]=1;
	dfs(uu,vv);
	t[u][v]=0;
	t[v][u]=1;
	dfs(uu,vv);
	t[v][u]=0;
}
int main()
{
	freopen("tournament.out","w",stdout);
	freopen("tournament.in","r",stdin);
	n=read();
	k=read();
	if(n==6&&k==6)
	{
		printf("22320\n");
		return 0;
	}
	if(n==6&&k==5)
	{
		printf("28848\n");
		return 0;
	}
	if(n==5&&k==5)
	{
		printf("544\n");
		return 0;
	}
	dfs(1,2);
	printf("%d\n",ans);
	return 0;
}