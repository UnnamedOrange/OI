#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

const int N = 100010;
const int inf = 1e9;

int n, m, k, ans, tans, MN, lef, lsta, lstb;
int wa[N], wb[N], sa[N], sb[N], vis[N], a[N], b[N], c[N];
vector <int> va[N], vb[N];
priority_queue <int> h1, h2;

void solve_a()
{
	tans = -1; lsta = 0;
	do
	{
		FOR(i, 1, k) vis[i] = 0; lef = k;
		FOR(i, lsta + 1, n)
		{
			if (!vis[a[i]]) --lef, vis[a[i]] = 1;
			if (!lef) {lsta = i; break;}
		}
		++tans;
		if (!lef) wa[tans + 1] = lsta;
	} while (!lef);
	ans = max(ans, tans); wa[tans + 1] = n;
	MN = min(MN, tans);
	
	tans = -1; lsta = n + 1;
	do
	{
		FOR(i, 1, k) vis[i] = 0; lef = k;
		for(int i = lsta - 1; i; --i)
		{
			if (!vis[a[i]]) --lef, vis[a[i]] = 1;
			if (!lef) {lsta = i; break;}
		}
		++tans;
		if (!lef) ++sa[lsta];
	} while (!lef);
	
	for(int i = n; i; --i) sa[i] += sa[i + 1];
}

void solve_b()
{
	tans = -1; lstb = 0;
	do
	{
		FOR(i, 1, k) vis[i] = 0; lef = k;
		FOR(i, lstb + 1, m)
		{
			if (!vis[b[i]]) --lef, vis[b[i]] = 1;
			if (!lef) {lstb = i; break;}
		}
		++tans;
		if (!lef) wb[tans + 1] = lstb;
	} while (!lef);
	ans = max(ans, tans); wb[tans + 1] = m;
	MN = min(MN, tans);
	
	tans = -1; lstb = m + 1;
	do
	{
		FOR(i, 1, k) vis[i] = 0; lef = k;
		for(int i = lstb - 1; i; --i)
		{
			if (!vis[b[i]]) --lef, vis[b[i]] = 1;
			if (!lef) {lstb = i; break;}
		}
		++tans;
		if (!lef) ++sb[lstb];
	} while (!lef);
	
	for(int i = m; i; --i) sb[i] += sb[i + 1];
	FOR(i, 1, m) vb[b[i]].push_back(i);
	FOR(i, 1, k) vb[i].push_back(inf);
}

int find(int x, int y)
{
	int l = 0, r = vb[y].size() - 1, ans;
	while (l <= r)
	{
		int mid = (l + r) >> 1;
		if (vb[y][mid] > x) ans = mid, r = mid - 1; else l = mid + 1;
	}
	return vb[y][ans];
}

bool check(int x, int len)
{
	int now = 1;
	FOR(i, 1, len) c[i] = (x & 1) + 1, x >>= 1;
	for(int i = 1; i <= n && now <= len; ++i)
		if (a[i] == c[now]) ++now;
	if (now > len) return 0;
	now = 1;
	for(int i = 1; i <= m && now <= len; ++i)
		if (b[i] == c[now]) ++now;
	return now <= len;
}

void spe()
{
	for(int i = 1; i <= min(n, m) + 1; ++i)
		for(int j = 0; j < (1 << i); ++j)
			if (check(j, i))
			{
				printf("%d\n", i);
				return;
			}
}

int main()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	k = min(k, max(n, m) + 1); MN = inf;
	FOR(i, 1, n) scanf("%d", &a[i]); solve_a();
	FOR(i, 1, m) scanf("%d", &b[i]); solve_b();
	if (n <= 18 && m <= 18 && k == 2) {spe(); return 0;}
	FOR(i, 0, MN)
	{
		FOR(j, 1, k) vis[j] = 0, h1.push(find(wb[i], j));
		for(int j = wa[i] + 1; j <= wa[i + 1]; ++j)
		{
			if (!vis[a[j]])
			{
				vis[a[j]] = 1;
				h2.push(find(wb[i], a[j]));
			}
			while (!h1.empty() && !h2.empty() && h1.top() == h2.top()) h1.pop(), h2.pop();
			if (h1.top() != inf) ans = max(ans, i + 1 + min(sa[j + 1], sb[h1.top() + 1]));
		}
	}
	printf("%d\n", ans + 2);
	return 0;
}
