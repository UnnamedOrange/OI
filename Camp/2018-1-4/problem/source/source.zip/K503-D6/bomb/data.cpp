#include <cctype>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <process.h>
#include <algorithm>
#include <functional>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)
#define repd(i,x,y) for (int i=x; i>=(y); --i)

using namespace std;

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

int main()
{
    freopen("bomb.in","w",stdout);
    srand(_getpid()^(unsigned long long)new char);
    int n=10,m=rand(100);
    printf("%d %d\n",n,m);
    rep(i,1,m)
        printf("%d %d\n",rand(1,n),rand(1,n));
    return 0;
}
