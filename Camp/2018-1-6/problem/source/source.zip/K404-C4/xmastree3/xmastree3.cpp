#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
const int Mod=998244353;
int n,k,t[55],fa[55],fa2[55],now,f[55][20],ans;
int cnt,head[55],to[110],nxt[110];
bool used[110],vis[55];
int cnt2,head2[55],to2[110],nxt2[110];
void add(int x,int y)
{
	cnt++;
	to[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
void add2(int x,int y)
{
	cnt2++;
	to2[cnt2]=y;
	nxt2[cnt2]=head2[x];
	head2[x]=cnt2;
}
void dfs2(int x)
{
	if (head2[x]==0)
	{
		for (int i=1;i<=k;i++)
		{
			f[x][i]=i;
		}
		return;
	}
	for (int i=head2[x];i;i=nxt2[i])
	{
		int y=to2[i];
		dfs2(y);
		for (int j=2;j<=k;j++)
		{
			f[x][j]+=f[y][j-1];
			f[x][j]%=Mod;
		}
	}
}
void dp(int rt)
{
	cnt2=0;
	memset(head2,0,sizeof(head2));
	memset(f,0,sizeof(f));
	for (int i=1;i<=n;i++)
	{
		//cout<<fa2[i]<<" ";
		if (fa2[i]!=0)
		{
			add2(fa2[i],i);
		}
	}
	//cout<<endl;
	dfs2(rt);
	ans=(ans+f[rt][k])%Mod;
}
void dfs(int x,int rt,int node,int now)
{
	//cout<<x<<" "<<now<<endl;
	if (x==0)
	{
		return;
	}
	if (now==n)
	{
		dp(rt);
		return;
	}
	while (used[node] && node)
	{
		node=nxt[node];
	}
	//cout<<x<<" "<<now<<endl;
	if (!node)
	{
		dfs(fa2[x],rt,head[fa2[x]],now);
		return;
	}
	used[node]=used[node^1]=true;
	int y=to[node];
	int fay=fa[y];
	while (fa[fay]!=fay)
	{
		fay=fa[fay];
		//cout<<fay<<endl;
	}
	//cout<<x<<" "<<now<<endl;
	for (int i=1;i<=n;i++)
	{
		if (vis[i])
		{
			continue;
		}
		int p=i;
		while (p!=fa[p])
		{
			p=fa[p];
		}
		if (p==fay)
		{
			vis[i]=true;
			fa2[i]=x;
			int tmp=fa[i];
			fa[i]=y;
			dfs(i,rt,head[i],now+1);
			fa[i]=tmp;
			vis[i]=false;
		}
	}
	used[node]=used[node^1]=false;
}
void dfs3(int x)
{
	for (int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if (y==fa[x])
		{
			continue;
		}
		fa[y]=x;
		dfs3(y);
	}
}
int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	cnt=1;
	for (int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	for (int i=1;i<=n;i++)
	{
		fa[i]=0;
		dfs3(i);
		fa[i]=i;
		fa2[i]=0;
		vis[i]=true;
		dfs(i,i,head[i],1);
		vis[i]=false;
	}
	printf("%d\n",ans);
	return 0;
}
