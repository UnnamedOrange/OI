#include <bits/stdc++.h>

int n,m;
struct edge {
	int enext,to;
} e[1000003];int en;
struct vertex {
	int estart;
	int dfn,top;
	int newi;
} v[1000003];
edge e2[1000003];int en2;
struct vertex2 {
	int estart;
	int size;
	int bomb;
} v2[1000003];int vn;
int dfn = 1;
std::stack<int> stk;
void dfs(int i)
{
	int mydfn = dfn;
	int top = dfn;
	v[i].dfn = dfn++;
	stk.push(i);
	for(int j = v[i].estart;j != -1;j = e[j].enext) {
		int to = e[j].to;
		if(v[to].dfn == 0) {
			dfs(to);
			if(v[to].top < top) top = v[to].top;
		} else if(v[to].newi == -1) {
			if(v[to].dfn < top)
				top = v[to].dfn;
		}
	}
	v[i].top = top;
	if(top == mydfn) {
		while(!stk.empty()) {
			int t = stk.top();stk.pop();
			//printf("%d ",t);
			v[t].newi = vn;
			if(t == i) break;
		}
		//printf("\n");
		++vn;
	}
}
void dfs2(int i)
{
	int bomb = 0;
	for(int j = v2[i].estart;j != -1;j = e2[j].enext) {
		int to = e2[j].to;
		if(v2[to].bomb == -1) dfs2(to);
		if(v2[to].bomb > bomb) bomb = v2[to].bomb;
	}
	v2[i].bomb = bomb + v2[i].size;
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 0;i < n;++i) {
		v[i].estart = -1;
		v[i].dfn = 0;
		v[i].newi = -1;
	}
	for(int i = 0;i < m;++i) {
		int a,b;
		scanf("%d%d",&a,&b);--a,--b;
		e[en].enext = v[a].estart;e[en].to = b;v[a].estart = en++;
	}
	for(int i = 0;i < n;++i) {
		if(v[i].dfn == 0) {
			dfs(i);
		}
	}
	for(int i = 0;i < vn;++i) {
		v2[i].estart = v2[i].bomb = -1;
		v2[i].size = 0;
	}
	for(int i = 0;i < n;++i) ++v2[v[i].newi].size;
	for(int i = 0;i < n;++i) {
		int a = v[i].newi;
		for(int j = v[i].estart;j != -1;j = e[j].enext) {
			int b = v[e[j].to].newi;
			if(a == b) continue;
			e2[en2].enext = v2[a].estart;e2[en2].to = b;v2[a].estart = en2++;
		}
	}
	int ans = 0;
	for(int i = 0;i < vn;++i) {
		if(v2[i].bomb == -1)
			dfs2(i);
		if(v2[i].bomb > ans)
			ans = v2[i].bomb;
	}
	printf("%d\n",ans);
}
