#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 30;
int T, n, fac, a[N];

void debug(){
	for(int i = 1; i <= n; i++)
		printf("%d%c", a[i], " \n"[i == n]);	
}
void rev(int x){
	for(int i = 1, j = x; i < j; i++, j--)
		swap(a[i], a[j]);	
}
bool check(){
	for(int i = 1; i <= n; i++)
		if(a[i] != i) return 0;
	return 1;
}
int eval(){
	int cnt = 0;
	for(int i = 3; i <= n; i++)
		if((a[i - 1] - a[i - 2]) * (a[i] - a[i - 1]) < 0) cnt++;
	return cnt;
}
bool dfs(int last, int step){
	if(step == 0) return check();
	if(eval() > step) return 0;
	for(int i = 2; i <= n; i++)
		if(i != last){
			rev(i);
			if(dfs(i, step - 1)) return 1;
			rev(i);
		}
	return 0;
}

int main(){
	
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	
	read(T);
	while(T--){
		read(n);
		for(int i = 1; i <= n; i++) 
			read(a[i]);
		int ans = 0;
		while(!dfs(0, ans)) ans++;
		write(ans), enter;
	}
	
	return 0;
}
/*
1
11
7 3 5 11 2 6 1 8 10 9 4

1
10
1 6 2 7 3 8 4 9 5 10
*/
