#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<bitset>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 100001
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
int n,a,b,x[N];
const int mod=1000000007;
namespace one{main(){}};
namespace two{main(){}};
namespace three
{
	main()
	{
		int odd=0,even=0,ans=1;
		for(int i=1;i<=n;++i)
			if((x[i]/a)&1)++odd;
			else ++even;
		for(int i=1;i<n;++i)
			ans=(ans<<1)%mod;
		printf("0 0 ");
		if(odd)printf("%d %d\n",ans,ans);
		else printf("%d %d\n",0,(ans<<1)%mod);
	}
};
namespace four{main(){}};
namespace five{main(){}};
int main()
{
	open(stone);
	re(n),re(a),re(b);
	for(int i=1;i<=n;++i)re(x[i]);
	if(a==b)three::main();
}
