#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 1000;

int n, m;
int len[N + 5];
char st[N + 5];
char sub[10][N + 5];

bool chk(int id, int p) {
    for(int i = 0; i < len[id]; ++i) {
        if(sub[id][i] != st[p + i]) return false;
    }
    return true;
}
bool chk() {
    for(int i = m; i < (m<<1); ++i) st[i] = st[2*m-i-1] == '0' ? '1' : '0';
    st[m<<1] = '\0';

    for(int i = 0; i < n; ++i) {
        bool flag = false;
        for(int j = 0; j < (m<<1) - len[i] + 1; ++j) {
            if(chk(i, j)) {
                flag = true;
                break;
            }
        }
        if(!flag) return false;
    }
    return true;
}

int ans;
void dfs(int u) {
    if(u == m) {
        ans += chk();
        return;
    }

    for(int i = 0; i < 2; ++i) {
        st[u] = i + '0';
        dfs(u + 1);
    }
}

int main() {
    freopen("string.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(n), read(m);
    for(int i = 0; i < n; ++i) scanf("%s", sub[i]), len[i] = strlen(sub[i]);
    dfs(0); printf("%d\n", ans);

    return 0;
}
