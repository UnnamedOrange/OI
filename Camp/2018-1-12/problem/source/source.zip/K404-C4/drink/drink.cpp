#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
int n,w[1000010];
double f1[1000010],f2[1000010],ans;
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++)
	{
		w[i]=read();
	}
	for (int i=1;i<=n;i++)
	{
		double now=1.0;
		f1[i]=1.0;
		for (int j=i-1;j;j--)
		{
			if (w[j]>=w[i])
			{
				now/=2.0;
			}
			f1[i]+=now;
		}
	}
	for (int i=n;i;i--)
	{
		double now=1.0;
		f2[i]=1.0;
		for (int j=i+1;j<=n;j++)
		{
			if (w[j]>w[i])
			{
				now/=2.0;
			}
			f2[i]+=now;
		}
	}
	for (int i=1;i<=n;i++)
	{
		ans+=(double)w[i]*f1[i]*f2[i]/2.0;
	}
	ans/=1LL*n*n;
	printf("%.15f\n",ans);
	return 0;
}
