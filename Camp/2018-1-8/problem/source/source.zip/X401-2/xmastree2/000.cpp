#include<bits/stdc++.h>
#define N 35000
#define eps 1e-8
using namespace std;

inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar(); 
	return ret;
}

int ll,LL,Ll,lL;

struct node
{
	int w, n ,id; 
	bool operator  < (const node & a) const
	{
		double o1=(double)w/n,o2=(double)a.w/a.n;
		if(abs(o1-o2)>eps)return o1<o2;
		return id<a.id;
	}
};
set<node>::iterator it2;
set<node>s;
set<node>::iterator it; 
int id,r[N],u,v,f_a,u_,v_,n,ans,ma,c[N*2][2],a[N],tot,tt,t_t,f[N],fa[N],w[N],hh[N],num[N];

void dfs(int p, int fa_)
{
	fa[p]=fa_;
	for(int o=a[p]; o; o=c[o][1])
	{
		if(c[o][0]==fa_)continue;
		dfs(c[o][0],p);
	}
}

int fid(int p)
{
	if(f[p]==p)return p;
	return f[p]=fid(f[p]);
}
//\n   dierhang shoukongge chile //
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	n=read();
	for(int i=1; i<n; ++i)
	{
		u=read(); v=read();
		c[++tot][0]=v; c[tot][1]=a[u]; a[u]=++tot;
		c[++tot][0]=u; c[tot][1]=a[v]; a[v]=++tot;
	}

	for(int i=1; i<=n; ++i){
		w[i]=read();
		r[i]=read();
	}

	for(int i=1; i<=n; ++i)if(r[i])
	{
		s.clear(); 
		for(int j=1; j<=n; ++j)f[j]=j,hh[j]=w[j],num[j]=1;
		dfs(i,0);
		for(int j=1; j<=n; ++j)if(i!=j)s.insert((node){w[j],1,j});
		ans=0; 
		for(int j=1; j<n; ++j) 
		{
			it=s.begin();
			u=(*it).w;
			v=(*it).n;
			id=(*it).id;
			f_a=fid(fa[id]);  
			u_=hh[f_a];
			v_=num[f_a]; 
			s.erase(it);
			s.erase((node){u_,v_,f_a});
			ans+=v_*u;
			f[id]=f_a;
			hh[f_a]+=u;
			num[f_a]+=v;
			s.insert((node){u_+u,v_+v,f_a}); //no .._
		}
		ans+=hh[1]; 
		ma=max(ma,ans);
		//98
	} //2002 2049  //wa   splay lct//
	printf("%d\n",ma);
}

