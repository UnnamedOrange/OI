#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 100010;
const ll MOD = 998244353;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int st[MAXN], to[MAXN];
int nxt[MAXN], e;
inline void Add(int u, int v) {
	to[++e] = v, nxt[e] = st[u];
	st[u] = e;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int n;
char s[MAXN];
ll a[MAXN], b[MAXN];

void dfs(int u, int fa) {
	int i, cnt = 0;
	ll suma = 0, sumb = 0;
	for(i = st[u]; i; i = nxt[i]) {
		int v = to[i];
		if(v == fa) continue;
		dfs(v, u);
		suma = (suma + a[v])%MOD;
		sumb = (sumb + b[v])%MOD;
		cnt++;
	}
	if(cnt == 0) 
		a[u] = 1, b[u] = 0;
	else if(u == 1) {
		sumb = qpow((cnt-sumb+MOD)%MOD, MOD-2);
		a[u] = (cnt+suma)%MOD*sumb%MOD;
	}
	else {
		suma = (suma+cnt+1)%MOD;
		sumb = (cnt+1-sumb+MOD)%MOD;
		sumb = qpow(sumb, MOD-2);
		a[u] = suma * sumb % MOD;
		b[u] = sumb;
	}
}

int main() {
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);

	int i;

	n = read();
	scanf("%s", s);

	for(i = 1; i < n; i++) {
		int u = read(), v = read();
		Add(u, v), Add(v, u);
	}

	dfs(1, 0);
	/*for(i = 1; i <= n; i++)
		printf("%lld %lld\n", a[i], b[i]);*/
	printf("%lld\n", a[1]);
	return 0;
}
