#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;

int main(){
	srand(time(0));
	freopen("xmasdag.in","w",stdout);
	int n=100000,m=200000,k=500;
	printf("%d %d %d\n",n,m,k);
	For(i,1,n-1)printf("%d %d\n",1,i+1);
	For(i,1,m-n+1){
		int x=rand()%n+1,y=rand()%n+1;
		while(x==y)x=rand()%n+1;
		if(x>y)swap(x,y);
		printf("%d %d\n",x,y);
	}
	return 0;
}
