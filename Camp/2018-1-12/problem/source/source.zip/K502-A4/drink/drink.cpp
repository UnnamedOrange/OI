#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e6+5,LIM=34;

int n,w[N];
struct P_0{
	void work(){
		db ans=0;
		static int arr[105];
		rep(i,1,n+1){
			int now;
			rep(j,i,n+1){
				now=j-i;
				while(arr[now]>w[j])arr[now+1]=arr[now],--now;
				arr[now+1]=w[j];
				db res=0;
				rep(k,1,j-i+2)res=(res+arr[k])/2;
				ans+=res;
			}
		}
		ans=ans/n/n;
		printf("%.9lf\n",ans);
	}
}P0;
int p[N];
bool cmp(const int &a,const int &b){
	return w[a]>w[b];
}
struct P_1{
	int lg[N],BitNxt[N],BitPre[N],bin[50];
	db div[100];
	bool mark[N];
	int a[LIM+5],b[LIM+5],cnta,cntb;
	int prea[LIM+5],preb[LIM+5];
	int tr[N<<2];
	void update(int l,int r,int p,int pos){
		++tr[p];
		if(l==r)return ;
		int mid=(l+r)>>1;
		if(pos<=mid)update(l,mid,p<<1,pos);
		else update(mid+1,r,p<<1|1,pos);
	}
	void queryr(int l,int r,int p,int pos){
		if(!tr[p]||cnta==LIM||r<pos)return ;
		if(l==r){
			a[cnta]=l-prea[cnta];
			prea[++cnta]=l;
			return;
		}
		int mid=(l+r)>>1;
		queryr(l,mid,p<<1,pos);
		queryr(mid+1,r,p<<1|1,pos);
	}
	void queryl(int l,int r,int p,int pos){
		if(!tr[p]||cntb==LIM||pos<l)return ;
		if(l==r){
			b[cntb]=preb[cntb]-l;
			preb[++cntb]=l;
			return;
		}
		int mid=(l+r)>>1;
		queryl(mid+1,r,p<<1|1,pos);
		queryl(l,mid,p<<1,pos);
	}
	void work(){
		{
			int i;
			for(i=0;(1<<i)<=n;++i)lg[1<<i]=i+1;
			lg[n+1]=i+1;
			per(i,1,n+1){
				p[i]=i;
				if(!lg[i])lg[i]=lg[i+1];
			}
			sort(p+1,p+1+n,cmp);
			div[0]=0.5;
			rep(i,1,100)div[i]=div[i-1]/2;
		}
		db ans=0,res;
		if(n<=1500){
			mark[0]=mark[n+1]=1;
			rep(i,1,n+1){
				int pos=p[i],cnta=0,cntb=0,pre=pos;
				rep(j,pos,n+2){
					if(mark[j]){
						a[cnta++]=j-pre,pre=j;
						if(cnta==LIM)break;
					}
				}
				pre=pos;
				per(j,0,pos){
					if(mark[j]){
						b[cntb++]=pre-j;pre=j;
						if(cntb==LIM)break;
					}
				}
				mark[pos]=1;
				res=0;
				rep(j,0,cnta)rep(k,0,cntb){
					if(j+k==LIM)break;
					res+=div[j+k]*a[j]*b[k];
				}
				ans+=res*w[pos];
			}
		}else {
			int pos,j,k;
			update(0,n+1,1,0);
			update(0,n+1,1,n+1);
			rep(i,1,n+1){
				pos=p[i];
				prea[0]=preb[0]=pos;
				cnta=cntb=0;
				queryr(0,n+1,1,pos);
				queryl(0,n+1,1,pos);
				update(0,n+1,1,pos);
				res=0;
				for(j=0;j<cnta;++j)for(k=0;j+k<LIM&&k<cntb;++k)
					res+=div[j+k]*a[j]*b[k];
				ans+=res*w[pos];
			}
		}
		ans=ans/n/n;
		printf("%.9lf\n",ans);
	}
}P1;
int main(){
//	freopen("drink3.in","r",stdin);
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	rd(n);
	rep(i,1,n+1)rd(w[i]);
	if(0);
	else if(n<=100)P0.work();
	else P1.work();
	return 0;
}
