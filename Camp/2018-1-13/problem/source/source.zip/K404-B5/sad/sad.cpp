#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 100007;
const int MOD = 998244353;

struct eT
{
	void setd ( int _u, int _v, int _l )
	{
		u = _u, v = _v, last = _l;
	}
	
	int u, v, last;
}edge[MAXN*2];

int n;
char ctp[MAXN];
bool tp[MAXN];
int ke, la[MAXN];



void init ();
void input ();
void work ();

int qpow ( int a, int b )
{
	LL base = a, ans = 1;
	while ( b ){
		if ( b & 1 ) ( ans *= base ) %= MOD;
		( base *= base ) %= MOD;
		b >>= 1;
	}
	return ans;
}

int add ( int x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
	return x;
}

void addv ( int &x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
}

int dec ( int x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
	return x;
}

void decv ( int &x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
}



namespace task3_6
{
	struct dT
	{
		int ne, fv;
	}dp[MAXN];
	
	void dfs ( int now, int fa )
	{
		int v, deg = ( ~fa ) ? 1 : 0;
		int ce = 0, cv = 0;
		for ( int i = la[now]; ~i; i = edge[i].last ){
			if ( ( v = edge[i].v ) ^ fa ){
				++deg;
				dfs ( v, now );
				ce += dp[v].ne, cv += dp[v].fv;
			}
		}
		if ( deg == 1 ){
			dp[now].ne = 1, dp[now].fv = 0;
			return;
		}
		ce = SC ( LL, ce ) * qpow ( deg, MOD-2 ) % MOD, cv = SC ( LL, cv ) * qpow ( deg, MOD-2 ) % MOD;
		cv = dec ( 1, cv );
		dp[now].ne = SC ( LL, add ( ce, 1 ) ) * qpow ( cv, MOD-2 ) % MOD;
		if ( ~fa ) dp[now].fv = SC ( LL, qpow ( deg, MOD-2 ) ) * qpow ( cv, MOD-2 ) % MOD;
	}
	
	void work ()
	{
		dfs ( 1, -1 );
		printf ( "%d\n", dp[1].ne );
	}
}



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "sad" );
}

void input ()
{
	scanf ( "%d", &n );
	scanf ( "%s", ctp );
	int u, v;
	ke = 0;
	INIT ( la, -1 );
	lp ( i, 1, n ){
		scanf ( "%d%d", &u, &v );
		edge[ke].setd ( u, v, la[u] );
		la[u] = ke++;
		edge[ke].setd ( v, u, la[v] );
		la[v] = ke++;
	}
}

void work ()
{
	lpi ( i, 1, n ) tp[i] = ctp[i] - '0';
	
	bool flagA = true;
	lpi ( i, 1, n ){
		if ( !tp[i] ){
			flagA = false;
			break;
		}
	}
	
	if ( flagA ) task3_6::work ();
	
}
