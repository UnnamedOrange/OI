#include <cstdio>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

namespace OUTBUFFER {
	char buf[1048576];
	int pt;
	inline void putch(register char ch) { buf[pt++] = ch; }
	inline void flush() { if(pt) fwrite(buf,sizeof(char),pt,stdout), pt = 0; }
	inline void check() { if(pt > 1000000) flush(); }
}

template <class T>
inline void put_int(register T x) {
	char temp[23];
	register int top;
	if(x == 0) return OUTBUFFER::putch('0');
	if(x < 0) OUTBUFFER::putch('-'), x = -x;
	for(top = 0; x; temp[++top] = x % 10, x /= 10);
	do OUTBUFFER::putch(temp[top] ^ '0'); while(--top);
	OUTBUFFER::check();
}

struct OUT {
	OUT() { OUTBUFFER::pt = 0; }
	~OUT() { OUTBUFFER::flush(); }
	const OUT &operator << (const char *str) const {
		while(*str) OUTBUFFER::putch(*str++);
		OUTBUFFER::check();
		return *this;
	}
	const OUT &operator << (register char ch) const {
		return OUTBUFFER::putch(ch), *this;
	}
	const OUT &operator << (register int x) const {
		return put_int<int>(x), *this;
	}
	const OUT &operator << (register long long x) const {
		return put_int<long long>(x), *this;
	}
} out;

int N, p, q, W[16];
int Abs(int a) { return a < 0 ? -a : a; }
class Expression {
	int x, y, z, a, b, c, d, e, f;
public:
	friend const IN& operator >>(const IN &in, Expression &e) {
		return in >>e.x >>e.y >>e.z >>e.a >>e.b >>e.c >>e.d >>e.e >>e.f;
	}
	int cal() {
		return a * Abs(W[x] - W[y]) + b * Abs(W[y] - W[z]) + c * Abs(W[z] - W[x])
			 + d *    (W[x] - W[y]) + e *    (W[y] - W[z]) + f *    (W[z] - W[x]);
	}
} Expr[25];
class Condition {
	int x, y, r;
public:
	friend const IN& operator >> (const IN &in, Condition &c) {
		return in >>c.x >>c.y >>c.r;
	}
	bool check() {
		switch(r) {
			case 0:  return W[x] <= W[y];
			case 1:  return W[x] == W[y];
			default: return W[x]  < W[y];
		}
	}
} Cond[25];

inline void init() {
	in >>N >>W[0] >>p >>q;
	for(int i = 1; i <= p; ++i) in >>Expr[i];
	for(int i = 1; i <= q; ++i) in >>Cond[i];
}

inline void solve() {
	if (N > 15) {
		out <<"0\n";
		return;
	}
	int ans = 0x3FFFFFFF;
	for(int x = 0, r = 1 << N; x < r; ++x) {
		int sum = 0;
		bool b = true;
		for(int i = 1; i <= N; ++i)
			sum += (W[i] = (x & (1 << (i - 1))) ? W[0] : -W[0]);
		for(int i = 1; b && i <= q; ++i)
			if(!Cond[i].check()) b = false;
		if(b) {
			for(int i = 1; i <= p; ++i)
				sum += Expr[i].cal();
			ans > sum ? ans = sum : 0;
		}
	}
	out <<ans <<'\n';
}

#define PROBLEM_NAME	"variable"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	int T = get_int();
	while(T--) {
		init();
		solve();
	}
	return 0;
}
