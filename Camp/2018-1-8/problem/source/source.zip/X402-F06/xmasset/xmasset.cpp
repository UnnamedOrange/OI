#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
int num;
int encode(int x,int y){
	REP(i,1,num)
		if((x&(1<<i-1)) && !(y&(1<<i-1)))
			return i;
	int u=0,v=0;
	REP(i,1,num) if(y&(1<<i-1)) ++u;
	REP(i,1,num) if(x&(1<<i-1)) ++v;
	REP(i,1,4) if((u&(1<<i-1)) && !(v&(1<<i-1))) return i+num;
	return 0;
}
bool decode(int x,int y){
	if(y<=num){
		if(x&(1<<y-1)) return 1;
		return 0;
	}
	int k=0;
	REP(i,1,num) if(x&(1<<i-1)) ++k;
	if(k&(1<<y-num-1)) return 0;
	return 1;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
#endif
	int t=read();
	int n=read(),T=read();
	int x=1;
	while(x<=n) x<<=1,++num;
	while(T--){
		int x=read(),y=read();
		if(t==1) printf("%d\n",encode(x,y));
		else printf("%s\n",decode(x,y)?"yes":"no");
	}
	return 0;
}
