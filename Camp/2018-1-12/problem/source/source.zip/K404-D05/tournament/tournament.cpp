#include<bits/stdc++.h>
#define FE "tournament"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c))(c=='-'?p=-1:0),c=getchar();
	while(isdigit(c))x=(x<<3)+(x<<1)+(c^'0'),c=getchar();
	return x*p;
}
inline void putint(int x){
	static int buf[20];
	int tot=0;
	x<0?putchar('-'),x=-x:0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
const long long MOD = 998244353;
inline long long fac(long long x){
	if(x==0)return 1;
	else return fac(x-1)*x%MOD;
}
inline long long ksm(long long a,long long b,long long c){
	a%=c;
	long long ans=1;
	while(b){
		if(b&1)ans=ans*a%c;
		b>>=1,a=a*a%c;
	}
	return ans;
}
const int LEN = 1000000;
int prime[LEN+5],tot,phi[LEN+5];
bool notprime[LEN+5];
inline void sieve(){
	phi[1]=notprime[1]=1;
	for(int i=2;i<LEN;++i){
		if(!notprime[i]){
			prime[++tot]=i;
			phi[i]=i-1;
		}
		for(int j=1;j<=tot&&prime[j]*i<LEN;++j){
			notprime[i*prime[j]]=1;
			if(i%prime[j]==0){
				phi[i*prime[j]]=phi[i]*prime[j];
				break;
			}
			phi[i*prime[j]]=phi[i]*phi[prime[j]];
		}
	}
//	for(int i=1;i<=30;++i){
//		cout<<i<<" "<<phi[i]<<endl;
//	}
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	sieve();
	long long n=getint(),k=getint();
	if(k==3){
		cout<<((ksm(2,n*(n-1)/2,MOD)-fac(n))%MOD+MOD)%MOD;
		return 0;
	}
	if(k==n){
		long long x=phi[n]/2,y=n*(n-1)/2,ans=0;
		for(int i=1;i<=x;++i){
			ans%=MOD;
		}
		cout<<(ans+MOD)%MOD;
		return 0;
	}
	return 0;
}
