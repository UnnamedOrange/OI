#include <bits/stdc++.h>
#include <cstring>
using namespace std;
const int inf(233333333);
int n, ans, maxd, a[50];
bool check() {
	for (int i=1;i<=n;i++) {
		if (a[i]!=i) return false;
	}
	return true;
}
bool check(int dep) {
	int cnt=0;
	for (int i=1;i<n;i++) {
		if (abs(a[i]-a[i+1])!=1) cnt++;
	}
	if (maxd-dep<=cnt) return false;
	return true;
}
void dfs(int dep) {
	if (dep>=maxd) return;
	if (dep>=ans) return;
	/*cout << dep << endl;
	for (int i=1;i<=n;i++) cout << a[i] << " ";
	cout << endl;*/
	if (check()) {
		ans=min(ans,dep);
		return;
	}
	if (!check(dep)) {
		return;
	}
	for (int i=2;i<=n;i++) {
		reverse(a+1,a+i+1);
		dfs(dep+1);
		reverse(a+1,a+i+1);	
	}
}
void work() {
	cin >> n;
	for (int i=1;i<=n;i++) 
		cin >> a[i];
	ans=inf;
	for (maxd=1;maxd<=2*n-2;maxd++) {
		dfs(1);
		if (ans!=inf) {
			cout << ans-1 << endl;
			return;
		}
	}
}
int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	ios::sync_with_stdio(false);
	int T;
	cin >> T;
	while (T--) work();
	return 0;
}
