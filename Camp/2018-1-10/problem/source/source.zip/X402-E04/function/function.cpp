#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=6000100,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
}
ll d[N],s[N],sd[N],sm[N];
int pri[N/10],tot,m2[N];
unsigned short vis[N];
short mu[N],c[N];

void get_prime(int n=N-100){
	d[1]=1;mu[1]=1;s[1]=1;
	For(i,2,n){
		if(!vis[i])pri[++tot]=i,mu[i]=-1,d[i]=2,c[i]=1;
		for(int j=1,v;j<=tot&&(v=pri[j]*i)<=n;j++){
			vis[v]=1;
			if(i%pri[j]==0){
				c[v]=c[i]+1;
				d[v]=d[i]/c[v]*(c[v]+1);
				break;
			}
			mu[v]=-mu[i];
			d[v]=d[i]*2,c[v]=1;
		}
		s[i]=s[i-1]+d[i]*d[i];
	}
	For(i,1,n)sm[i]=sm[i-1]+mu[i];
	For(i,1,n)sd[i]=sd[i-1]+d[i],m2[i]=m2[i-1]+mu[i]*mu[i];
	//For(i,1,n)printf("%d %d\n",mu[i],d[i]);

}
void init(){
	get_prime();
}
tr1::unordered_map<ll,ll>M;
ll calcMu(ll n){
	if(n<=N-100)return sm[n];
	if(M.count(n))return M[n];
	ll ans=1;
	for(ll l=2,r;l<=n;l=r+1){
		r=n/(n/l);
		ans-=(r-l+1)*calcMu(n/l);
	}
	return M[n]=ans;
}
tr1::unordered_map<ll,ll>D,M2;
ll sum_mu2(ll n){
	ll ans=0;
	if(n<=N-100)return m2[n];
	if(M2.count(n))return M2[n];
	for(ll i=1;i*i<=n;++i)
		ans=ans+mu[i]*(n/(i*i));
	return M2[n]=ans;
}
tr1::unordered_map<ll,ll>K;
ll sumd(ll n){
	if(n<=N-100)return sd[n];
	if(K.count(n))return K[n];
	ll ans=0;
	for(ll l=1,r;l<=n;l=r+1){
		r=n/(n/l);
		ans=ans+(r-l+1)*(n/l);
	}
	return K[n]=ans;
}
ll calcd(ll n){
	ll ans=0,last=0,cur;
	for(ll l=1,r;l<=n;l=r+1){
		r=n/(n/l);
		ans=ans+sumd(n/l)*(r-l+1);
		//printf("%lld\n",sumd(r));
		last=cur;
	}
	return ans;
}
ll calcs(ll n){
	if(n<=N-100)return s[n];
	if(D.count(n))return D[n];
	ll ans=0;
	for(ll l=1,r;l<=n;l=r+1){
		r=n/(n/l);
		ans+=(sum_mu2(r)-sum_mu2(l-1))*calcd(n/l);
		//last=cur;
	}
	return D[n]=ans;
}
void solve(){
	int n;
	ll ans=0;
	read(n);
	for(ll l=1,r;l<=n;l=r+1){
		r=n/(n/l);
		ans=ans+(calcMu(r)-calcMu(l-1))*calcs(n/l);
		//last=cur;
	}
	printf("%lld\n",ans);
	cerr<<clock()*1.0/CLOCKS_PER_SEC<<endl;
}

int main(){
	file();
	init();
	int T;
	read(T);
	while(T--)solve();
	return 0;
}
