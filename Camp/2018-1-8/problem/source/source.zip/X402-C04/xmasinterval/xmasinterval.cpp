#include<iostream>
#include<map>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline int maxx(int a,int b){if(a>b)return a;return b;}

typedef map<int,int>::iterator it;
typedef long long ll;
const int N=10009;
const ll md=1000000009;

map<int,int> ha;
int n,m,x[N];
int tot,sum[N<<2],rha[N<<2],p[N<<2],stk[N];
ll ans;

inline ll chk(ll &a){if(a>=md)a-=md;}

struct node
{
	int l,r;
	bool operator < (node o)const
	{
		return l<o.l;
	}
}l[N];

inline void init()
{
	tot=0;
	for(it i=ha.begin();i!=ha.end();i++)
		rha[(*i).second=++tot]=(*i).first;

	for(int i=1;i<=n;i++)
	{
		l[i].l=ha[l[i].l];
		l[i].r=ha[l[i].r];
	}

	for(int i=1;i<=m;i++)
		x[i]=ha[x[i]];

	sort(l+1,l+n+1);
	sort(x+1,x+n+1);
	for(int i=1;i<=m;i++)
		p[x[i]]=i;
}

inline bool judge()
{
	memset(sum,0,sizeof(sum));
	for(int i=1;i<=n;i++)
		if(stk[i])
		{
			sum[l[i].l]++;
			sum[l[i].r+1]--;
		}
	for(int i=1;i<=tot;i++)
	{
		sum[i]+=sum[i-1];
		if(p[i] && sum[i]<=0)
			return 0;
	}
	return 1;
}

inline void dfs(int id)
{
	if(id>n)
	{
		if(judge())
			ans++;
		return;
	}
	stk[id]=0;
	dfs(id+1);
	stk[id]=1;
	dfs(id+1);
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);

	n=read();m=read();
	for(int i=1;i<=n;i++)
	{
		l[i].l=read(),l[i].r=read();
		ha[l[i].l];ha[l[i].r];
	}
	for(int i=1;i<=m;i++)
		ha[x[i]=read()];

	init();

	dfs(1);
	printf("%lld\n",ans);
	return 0;
}
