#include<cstdio>
#include<algorithm>
#define LL long long
#define For(i, a, b) for(register int i = a; i <= b; ++i)
using namespace std;
const int maxn = 1e6 + 5, inf = 0x3f3f3f3f, mod = 1e9 + 7;
int dp[maxn], n, c[maxn], d[maxn], mn, mx;
LL ways[maxn];
int main() {
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
	scanf("%d", &n);
	dp[0] = 0, ways[0] = 1, c[0] = 0, d[0] = inf;
	For(i, 1, n) scanf("%d%d", &c[i], &d[i]);
	For(i, 0, n - 1) {
		mx = inf, mn = 0;
		For(j, i + 1, n) {
			mx = min(mx, d[j]), mn = max(mn, c[j]);
			if(j - i < mn) continue;
			if(j - i > mx || j < i) break;
			if(dp[j] < dp[i] + 1) dp[j] = dp[i] + 1, ways[j] = ways[i];
			else if(dp[j] == dp[i] + 1) (ways[j] += ways[i]) %= mod;
		}
	}
	if(!dp[n]) printf("-1");
	else printf("%d %lld", dp[n], ways[n] % mod);
	return 0;
}
