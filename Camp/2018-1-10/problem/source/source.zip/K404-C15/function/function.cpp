#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 1000000;
int T, n, e[N + 5], prime[N + 5], idx;
ll f[N + 5], sum[N + 5];
bool notprime[N + 5];

void euler(){
	f[1] = 1;
	for(int i = 2; i <= N; i++){
		if(!notprime[i]) 
			prime[++idx] = i, f[i] = 3, e[i] = 1;
		for(int j = 1; j <= idx && i * prime[j] <= N; j++){
			notprime[i * prime[j]] = 1;
			if(i % prime[j]){
				e[i * prime[j]] = 1;
				f[i * prime[j]] = f[i] * f[prime[j]];
			}
			else{
				e[i * prime[j]] = e[i] + 1;
				f[i * prime[j]] = f[i] / (2 * e[i] + 1) * (2 * e[i] + 3);
				break;
			}
		}
	}
	for(int i = 1; i <= N; i++) 
		sum[i] = sum[i - 1] + f[i];
}

int main(){
	
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	
	euler();
	read(T);
	while(T--){
		read(n);
		write(sum[n]), enter;
	}
	
	return 0;
}
