#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
#define lc pos<<1
#define rc pos<<1|1
const int maxn=1e6+7,INF=0x3f3f3f3f;
const ll mod=1e9+7;
int n,cl[maxn],cr[maxn],ql,qr,qx,last;
ll dp[maxn],sum[maxn];

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

void mo(ll &x) {if(x>=mod) x-=mod;}

ll solve() {
	int l,r;
	memset(dp,-1,sizeof(dp));
	dp[0]=0;sum[0]=1;
	for(int i=1;i<=n;++i) {
		l=cl[i],r=cr[i];
		for(int j=i-1;(~j)&&r>=i-j;--j) {
			if(l<=i-j&&(~dp[j])) dp[i]=max(dp[i],dp[j]+1);
			l=max(l,cl[j]); r=min(r,cr[j]);
		}
	}
	if(dp[n]==-1) return -1;
	printf("%lld ",dp[n]);
	for(int i=1;i<=n;++i)  {
		l=cl[i],r=cr[i];
		for(int j=i-1;(~j)&&r>=i-j&&l<=r;--j) {
			if(l<=i-j&&dp[i]==dp[j]+1) sum[i]+=sum[j],mo(sum[i]); 
			l=max(l,cl[j]); r=min(r,cr[j]);
		}
	}
	return sum[n];
}

int main() {
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) cl[i]=read(),cr[i]=read();
	printf("%lld",solve());
	fclose(stdin);fclose(stdout);
	return 0;
}
