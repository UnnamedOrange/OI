#include <cstdio>
#include <queue>
#include <string.h>
#include <map>
#define F(x,y,z) for (x=y;x<=z;++x)
using namespace std;
struct gsqq{
	long long zt;int f,g;
	bool friend operator<(gsqq a,gsqq b){return a.f>b.f;}
};
map<long long,bool> ma; //!!!
int n,m;
long long jc[30],ans;
int a[30],b[30],l;
priority_queue<gsqq>que;
void wr(){
//int k;F(k,1,n)printf("%d ",a[k]);
//printf("%d\n",l);
}
long long zk(){
	long long an=0;int i,j,sum;
	for (i=1;i<=n;++i)
	{
		sum=0;
		for (j=1;j<=i-1;++j)
			if (a[j]<a[i]) ++sum;
		an+=jc[i-1]*sum;
	}
	return an;        //!!!
}

void hy(long long zt){
	int i,sum,j,key;bool h[30];
	F(i,1,n)h[i]=0;
	b[n]=zt/jc[n-1]+1;zt%=jc[n-1];h[b[n]]=1;
	for (i=n-1;i>=1;--i)
	{
		sum=0;j=1;
		key=zt/jc[i-1]+1;zt%=jc[i-1];
		while (key){
			if (!h[j]) --key;
			++j;
		}
		b[i]=j-1;
		h[b[i]]=1;
	}
}

long long H(){
	int i,now=a[2],an=1;
	int f=a[2]>a[1]?1:-1;
	F(i,3,n)
		if (f==1)
			if (a[i]>now) now=a[i];
					else  now=a[i],f=-1,++an;
		else if (a[i]<now) now=a[i];
					else  now=a[i],f=1,++an;
	return an;
}
void Astar()
{
	int i,j,k;
	while (!que.empty()) que.pop();
	ma.clear();
	gsqq now,ne;
	long long nezt,neh;
	now.zt=zk();now.g=0;now.f=H();
	que.push(now);
	while (!que.empty())
	{
		++l;
		if (l>50000 || (l>20000 && n>=14)) 
		{
			ans=999;
			return;
		}
		now=que.top();que.pop();
		hy(now.zt);
		F(k,1,n) a[k]=b[k];
		wr();
		if (now.zt==jc[n]-1) {ans=now.g;return;}
		if (now.g>=n) continue;
		F(j,2,n)
		{
			F(k,1,j) a[k]=b[1+j-k];
			F(k,j+1,n) a[k]=b[k];
			wr();
			nezt=zk();
			if (ma[nezt]) 
				continue;
			ma[nezt]=1;
			neh=H();
			ne.zt=nezt;ne.g=now.g+1;ne.f=ne.g+neh;
			if (nezt==jc[n]-1) {ans=ne.g;return;}  //!!!!!
			que.push(ne);
		}
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int x,y,z,i,j,k,T;
	jc[0]=1;F(i,1,20) jc[i]=jc[i-1]*i;
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		F(i,1,n)scanf("%d",&a[i]);
		Astar();
		if (ans==999)
			 printf("%d\n",n-1);
		else printf("%lld\n",ans);
	}	
	return 0;
}
