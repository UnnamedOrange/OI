#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;

int T,n,W,p,q,w[505];
int x[1001],y[1001],z[1001],a[1001],b[1001],c[1001],d[1001],e[1001],f[1001],xx[1001],yy[1001],r[1001];
int r0[505][505],r1[505][505],topr0[505],topr1[505];
long long sigmaw,sigmah,ans=1e14;

void set(int X,int Y,int R)
{
	if(R==2)
	{
		w[X]=-W; w[Y]=W;
		return;
	}
	if(R==1)
	{
		if(w[X]!=0) w[Y]=w[X];
		else if(w[Y]!=0) w[X]=w[Y];
		else
		{
			r1[X][++topr1[X]]=Y;
			r1[Y][++topr1[Y]]=X;
		}
		return;
	}
	//R==0
	if(w[Y]==-W) w[X]==-W;
	else
	{
		r0[X][++topr0[X]]=-Y;//saved is smaller
		r0[Y][++topr0[Y]]=X;//saved is bigger
	}
}

void calcu()
{
	sigmaw=sigmah=0;
	for(int i=1;i<=n;i++)
		sigmaw+=w[i];
	for(int i=1;i<=p;i++)
	{
		sigmah+= a[i]*abs(w[x[i]]-w[y[i]]) + b[i]*abs(w[y[i]]-w[z[i]]) + c[i]*abs(w[z[i]]-w[x[i]]);
		sigmah+= d[i]*(w[x[i]]-w[y[i]]) + e[i]*(w[y[i]]-w[z[i]]) + f[i]*(w[z[i]]-w[x[i]]);
	}
	if(sigmah+sigmaw<ans) ans=sigmah+sigmaw;
}

void dfs(int now)
{
	if(now==n+1)
	{
		calcu();
		return;
		
	}
	if(w[now]!=0) dfs(now+1);
	else
	{
		w[now]=W;
		for(int i=1;i<=topr1[now];i++)
		{
			int to=r1[now][i];
			w[to]=W;
		}
		for(int i=1;i<=topr0[now];i++)
		{
			int to=r0[now][i];
			if(to<0)
			{
				to=-to;
				w[to]=W;
			}
		}
		dfs(now+1);
		w[now]=-W;
		for(int i=1;i<=topr1[now];i++)
		{
			int to=r1[now][i];
			w[to]=-W;
		}
		for(int i=1;i<=topr0[now];i++)
		{
			int to=r0[now][i];
			if(to<0) w[-to]=0;
			else if(to>0) w[to]=-W;
		}
		dfs(now+1);
		for(int i=1;i<=topr0[now];i++)
		{
			int to=r0[now][i];
			if(to>0) w[to]=0;
		}
	}
}

void init()
{
	sigmaw=sigmah=0;
	ans=1e14;
	memset(a,0,sizeof a); 
	memset(b,0,sizeof b);
	memset(c,0,sizeof c); 
	memset(d,0,sizeof d);
	memset(e,0,sizeof e); 
	memset(f,0,sizeof f);
	memset(x,0,sizeof x); 
	memset(y,0,sizeof y);
	memset(z,0,sizeof z); 
	memset(xx,0,sizeof xx);
	memset(yy,0,sizeof yy); 
	memset(r,0,sizeof r);
	memset(w,0,sizeof w); 
	memset(r0,0,sizeof r0);
	memset(r1,0,sizeof r1); 
	memset(topr0,0,sizeof topr0);
	memset(topr1,0,sizeof topr1); 
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		init();
		scanf("%d%d%d%d",&n,&W,&p,&q);
		for(int i=1;i<=p;i++)
			scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for(int i=1;i<=q;i++)
		{
			scanf("%d%d%d",&xx[i],&yy[i],&r[i]);
			set(xx[i],yy[i],r[i]);
		}
		dfs(1);
		printf("%lld\n",ans);
	}
	return 0;
}
