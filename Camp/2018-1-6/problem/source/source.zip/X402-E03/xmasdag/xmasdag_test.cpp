#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 1e5+5, maxm = 2e5+5, maxk = 505 ;
int n, m, k ;
int modd = 998244353, g[maxn][maxk], sg[maxn][maxk] ;
int e, Begin[maxn], Next[maxm], To[maxm] ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
int deg[maxn] ;
bool vis[maxn] ;
int C[maxk][maxk], inv[maxk], ss[maxk] ;
LL Qpow ( LL a, LL b ) {
	LL rec = 1 ;
	for ( ; b ; b >>= 1, (a *= a) %= modd )
		if (b&1) (rec *= a) %= modd ;
	return rec ;
}
void init() {
	int i, j, l ;
	for ( i = 1 ; i <= k ; i ++ )
		inv[i] = Qpow((LL)i, (LL)(modd-2)) ;
	for ( j = 1 ; j <= k ; j ++ ) {
		for ( l = 0 ; l < j ; l ++ )
			(ss[j] += (LL)j*inv[j-l]%modd) %= modd ;
	}
	C[0][0] = 1 ;
	
	for ( i = 1 ; i <= k ; i ++ ) {
		C[i][0] = C[i][i] = 1 ;
		for ( j = 1 ; j < i ; j ++ )
			C[i][j] = (C[i - 1][j] + C[i - 1][j - 1])%modd ;
	}
}
void dfs ( int x ) {
	if (vis[x]) return ;
	vis[x] = 1 ;
	register int i, j, l, u ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		dfs(u) ;
		(g[x][0] += g[u][0]) %= modd ;
		for ( j = 1 ; j <= k ; j ++ ) {
			(g[x][j] += g[u][j]) %= modd ;
			(g[x][j] += sg[u][j]) %= modd ;
		}
	}
	sg[x][0] = g[x][0] ;
	for ( j = 1 ; j <= k ; j ++ )
		sg[x][j] = (LL)sg[x][j-1]*ss[j]%modd ;
}
int main() {
	freopen ( "xmasdag.in", "r", stdin ) ;
	freopen ( "xmasdag.out", "w", stdout ) ;

	register int i, u, x ;
	Read(n) ; Read(m) ; Read(k) ;
	init() ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(u) ; Read(x) ;
		add(x, u) ;
		++ deg[u] ;
	}
	vis[1] = 1 ;
	sg[1][0] = g[1][0] = 1 ;
	for ( i = 1 ; i <= k ; i ++ )
		sg[1][i] = 1 ;
	for ( i = 2 ; i <= n ; i ++ )
		if (!deg[i]) dfs(i) ;
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%d\n", g[i][k] ) ;
	cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
