#include<bits/stdc++.h>
using namespace std;

const int maxn=5e3+10;
int n,q,t,c[maxn],fa[maxn],lastans;
bitset<maxn> res[maxn];
vector<int> g[maxn];

void dfs(int pos){
	for(int i=0;i<g[pos].size();++i)
		if(g[pos][i]!=fa[pos]){
			fa[g[pos][i]]=pos;
			dfs(g[pos][i]);
			res[pos]|=res[g[pos][i]];
		}
	res[pos][c[pos]]=true;
}

int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.txt","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;++i)
		scanf("%d",&c[i]);
	for(int i=1,u,v;i<n;++i){
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs(1);
	while(q--){
		int opt,u,l,r;
		scanf("%d%d",&opt,&u);
		if(t)
			u^=lastans;
		if(opt==1){
			scanf("%d%d",&l,&r);
			if(t)
				l^=lastans,r^=lastans;
			printf("%d\n",lastans=((res[u]>>l)<<l+maxn-r-1).count());
		}
		else{
			scanf("%d",&l);
			if(t)
				l^=lastans;
			r=c[u];
			c[u]=l;
			while(u){
				res[u][r]=false;res[u][l]=true;
				for(int i=0;i<g[u].size();++i)
					if(g[u][i]!=fa[u]&&res[g[u][i]][r]){
						res[u][r]=true;
						break;
					}
				if(c[u]==r)
					res[u][r]=true;
				u=fa[u];
			}
		}
	}
	return 0;
}
