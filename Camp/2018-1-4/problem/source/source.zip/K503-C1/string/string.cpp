# include <bits/stdc++.h>
# define 	N 		1010
using namespace std;
int n,m,cnt,num;
int len[N];
char now[N],s[N][N];
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1; i<=n; i++)
		scanf("%s",s[i]+1);
	for (int i=1; i<=n; i++){
		len[i]=strlen(s[i]+1);
		for (int j=1; j<=len[i]; j++)
			s[i][j]=s[i][j]-'0';
	}
	for (int i=0; i<(1<<m); i++){
		for (int j=1; j<=m; j++) 
			if (i&(i<<(j-1))) now[j]=1; else now[j]=0;
		for (int j=m+1; j<=m+m; j++) now[j]=(now[m*2-j+1]^1);
		num=0;
		for (int j=1; j<=n; j++){
			bool f=false;
			for (int k=1; k<=m*2-len[j]+1; k++){
				bool flag=true;
				for (int t=1; t<=len[j]; t++)
					if (s[j][t]!=now[k+t-1]){
						flag=false; break;
					}
				f=(f|flag);
			}
			num=num+f;
		}
		if (num==n) cnt++;
	}
	printf("%d\n",cnt);
}
