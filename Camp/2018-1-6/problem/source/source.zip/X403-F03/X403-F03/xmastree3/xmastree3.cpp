#include<cstdio>
#include<iostream>
int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	printf("0\n");
	return 0;
}
