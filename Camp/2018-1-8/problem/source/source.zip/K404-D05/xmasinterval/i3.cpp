#include<bits/stdc++.h>
#define FE "xmasinterval"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		c=='-'?p=-1:0;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
inline void putint(int x){
	x<0?putchar('-'),x=-x:0;
	static int buf[20];
	int tot=0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
const int MOD = 1000000009;
int n,m;
int a[1000005];
struct interval{
	int l,r;
	bool operator < (const interval &b)const{
		if(l!=b.l)return l<b.l;
		return r<b.r;
	}
}b[1000005];
int f[1000005];
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE"2.out","w",stdout);
	n=getint(),m=getint();
	for(int i=1;i<=n;++i){
		b[i].l=getint(),b[i].r=getint();
	}
	for(int i=1;i<=m;++i){
		a[i]=getint();
	}
	sort(a+1,a+m+1);
	for(int i=1;i<=n;++i){
		b[i].l=lower_bound(a+1,a+m+1,b[i].l)-a;
		b[i].r=upper_bound(a+1,a+m+1,b[i].r)-a-1;
	}
	sort(b+1,b+n+1);
	f[0]=1;
	for(int i=1;i<=n;++i){
		for(int j=b[i].r+1;j<=m;++j){
			f[j]*=2;
			f[j]%=MOD;
		}
		for(int j=b[i].r;j>=b[i].l-1;--j){
			f[b[i].r]+=f[j];
			f[b[i].r]%=MOD;
		}
	}
	cout<<f[m]<<endl;
	return 0;
}
