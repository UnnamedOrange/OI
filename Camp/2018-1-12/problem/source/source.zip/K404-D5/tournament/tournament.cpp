#include<cstdio>
using namespace std;
const int mod = 998244353;
int a[10][10];
int qwe, n, k;

inline int workk()
{
	int bbb = 1;
	for(int i = 4; i <= n; ++i)
	{
		bbb += (i - 2);
	}
	return bbb;
}

int main()
{
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	scanf("%d%d", &n, &k);
	if(n == k)
	{
		int re = 1;
		qwe = workk();
		for(int i = 1; i <= qwe; ++i)
		{
			re *= 2; re %= mod;
		}
		printf("%d", re);
		return 0;
	}
	a[3][3] = 2;
	a[4][3] = 40;
	a[5][3] = 904;
	a[6][3] = 32048;
	a[7][3] = 2092112;
	printf("%d", a[n][k]);
	return 0;
}
