#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,m,ans,x[1010],y[1010],p[1010],vis[30],flag[30];
bool check()
{
	for(int i=1;i<=m;i++) if(!flag[i]) return false;
	return true;
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d%d",&x[i],&y[i]);
	for(int i=1;i<=m;i++) scanf("%d",&p[i]);
	sort(p+1,p+m+1);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++) 
		{
			if(x[i]<=p[j]) 
			{
				x[i]=j;
				break;
			}
		}
		for(int j=m;j>=1;j--) 
		{
			if(y[i]>=p[j]) 
			{
				y[i]=j;
				break;
			}
		}
	}
	for(int i=1;i<(1<<n);i++)
	{
		memset(flag,0,sizeof(flag));
		bool ok=false;
		for(int j=1;j<=n;j++)
		{
			if(i&(1<<(j-1)))
			{
				for(int k=x[j];k<=y[j];k++) flag[k]=1;
				if(check()) ok=true;
			}
		}
		if(ok==true) ans++;
	}
	printf("%d",ans);
	return 0;
}
