#include <cmath>
#include <cctype>
#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)

using namespace std;
typedef long long ll;

int get()
{
    char c;
    while (!isdigit(c=getchar()) && c!='-');
    int s=c=='-'? -1:1,k=~s? c-'0':0;
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return s*k;
}

const int N=1e5+10,T=1<<18|1;
const double eps=1e-9;
int n,w[N];
double s[N],ans;

int main()
{
    freopen("drink.in","r",stdin);
    freopen("drink.out","w",stdout);
    n=get();
    rep(i,1,n)
    {
        w[i]=get(),s[i]=0.5;
        double t=0.5;
        repd(j,i-1,1)
            w[j]>w[i]? t/=2:0,s[i]+=t;
        rep(j,1,i-1)
            if (w[j]<=w[i])
                s[j]/=2;
        rep(j,1,i)
            ans+=s[j]*w[j];
    }
    printf("%.10f",ans/(n*n));
    return 0;
}
