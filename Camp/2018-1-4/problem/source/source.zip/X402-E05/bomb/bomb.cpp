#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
}
int n,m;
int bgn[N],nxt[N],to[N],E;
int dfn[N],low[N],dfs_cnt;
int bel[N],scc_cnt,st[N],top,inst[N];
int w[N],dp[N],deg[N],ans;
vector<int>G[N];
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void dfs(int u)
{
	dfn[u]=low[u]=++dfs_cnt;
	st[++top]=u;
	inst[u]=1;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if(!dfn[v=to[i]])
			dfs(v),chkmin(low[u],low[v]);
		else
		if(inst[v])chkmin(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		int x;
		++scc_cnt;
		do
		{
			x=st[top--];
			inst[x]=0;
			bel[x]=scc_cnt;
			w[scc_cnt]++;
		}while(x!=u);
	}
}
int main()
{
	int x,y;
	file();
	read(n),read(m);
	For(i,1,m)read(x),read(y),add_edge(x,y);
	For(i,1,n)if(!dfn[i])dfs(i);
	For(u,1,n)
		for(int v,i=bgn[u];i;i=nxt[i])
			if(bel[u]!=bel[v=to[i]])
			{
				G[bel[v]].pb(bel[u]);
				deg[bel[u]]++;
			}
	queue<int>q;
	For(i,1,scc_cnt)if(!deg[i])q.push(i);
	while(!q.empty())
	{
		int u=q.front();q.pop();dp[u]+=w[u];
		For(i,0,SZ(G[u])-1)
		{
			int v=G[u][i];
			chkmax(dp[v],dp[u]);
			if(!--deg[v])q.push(v);
		}
	}
	For(i,1,scc_cnt)chkmax(ans,dp[i]);
	printf("%d\n",ans);
	return 0;
}
