#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

long long const mod=1000000007;
long long a,b,p=0;
int n;
long long f[5];
long long ans[5];

long long quick(long long a)
{
	int ret=1;
	int k=a%20;
	a=a/20;
	for(int i=1;i<=a;i++)
	{
		ret=ret<<20;
		ret=ret%mod;
	}
	ret=ret<<k;
	ret=ret%mod;
	return ret;
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%lld%lld",&n,&a,&b);
	if(a>b)p=a,a=b,b=p;
	for(int i=1;i<=n;i++)
	{
		long long x;
		scanf("%lld",&x);
		x=x%(a+b);
		if(x<a)f[4]++;
		if(x>=a&&x<b)f[1]++;
		if(x>=b)f[3]++;
	}
	ans[1]=((quick(f[1])-1)*quick(f[3]+f[4]))%mod;
	ans[2]=0;
	ans[3]=(quick(f[3]/2)*quick(f[4]))%mod;
	ans[4]=(quick(f[3]/2)*quick(f[4]))%mod;
	if(p!=0)p=ans[1],ans[1]=ans[2],ans[2]=p;
	for(int i=1;i<=4;i++)
	  printf("%d ",ans[i]);
	fclose(stdin);
	fclose(stdout);
}

