#include<cstdio>
#include<algorithm>
#include<cmath>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
using namespace std;
const int maxn = 25, inf = 0x7fffffff;
int n, W, p, q, stmax, t;
int k[maxn][7], sum, w[maxn];
int xi[maxn], yi[maxn], zi[maxn];
int stm[maxn][3], mn = 0x7fffffff;

int sigW(int mask) {
	int ans = 0, cnt = 0;
	while(cnt++ < n) {
		if(mask & 1) ans += W;
		else ans -= W;
		mask >>= 1;
	}
	return ans;
}

void Input_w(int mask) {
	for(int i = 1, p = 1; p <= stmax; p <<= 1, ++i) w[i] = (mask & p) ? W : -W;
}

int sigF(int mask) {
	int ans = 0, x, y, z;
	For(i, 1, p) {
		x = xi[i], y = yi[i], z = zi[i];
		ans += k[i][1] * abs(w[x] - w[y]) + k[i][2] * abs(w[y] - w[z]) + k[i][3] * abs(w[z] - w[x])
			+ k[i][4] * (w[x] - w[y]) + k[i][5] * (w[y] - w[z]) + k[i][6] * (w[z] - w[x]);
	}
	return ans;
}

bool Legal(int mask) {
	For(i, 1, q) {
		if(stm[i][2] == 0 && w[stm[i][0]] > w[stm[i][1]]) return false;
		if(stm[i][2] == 1 && w[stm[i][0]] != w[stm[i][1]]) return false;
		if(stm[i][2] == 2 && w[stm[i][0]] >= w[stm[i][1]]) return false;
	}
	return true;
}

int main() {
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		mn = inf;
		scanf("%d%d%d%d", &n, &W, &p, &q);
		For(i, 1, p) {
			scanf("%d%d%d", &xi[i], &yi[i], &zi[i]);
			For(j, 1, 6) scanf("%d", &k[i][j]);
		}
		For(i, 1, q) For(j, 0, 2) scanf("%d", &stm[i][j]);
		stmax = (1 << n) - 1;
		For(i, 0, stmax) {
			Input_w(i);
			if(!Legal(i)) continue;
			mn = min(mn, sigF(i) + sigW(i));
		}
		printf("%d\n", mn);
	}
	return 0;
}
