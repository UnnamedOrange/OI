#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;

typedef long long LL;
const int maxn=100010;
const LL mod=998244353;
int n,m,k,cnt=0,head[maxn];
LL t=0,ans[maxn]={0};

struct edge{
	int u,v,next;
}e[400010];
inline void add(int u,int v){
	e[++cnt]=(edge){u,v,head[u]};
	head[u]=cnt;
}

inline LL fpow(LL a,int b){
	LL ret=1,t=a;
	while(b){
		if(b%2)ret=(ret*t)%mod;
		t=(t*t)%mod;b/=2;
	}
	return ret;
}

void dfs(int u){
	ans[u]=(ans[u]+fpow(t,k))%mod;
	for(int i=head[u];i;i=e[i].next){
		t++;
		dfs(e[i].v);
		t--;
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	int u,v;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	dfs(1);
	for(int i=1;i<=n;i++)
	  printf("%lld\n",ans[i]);
	return 0;
}
