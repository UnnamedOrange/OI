#include <bits/stdc++.h>
using namespace std;
char buf[25000100],*pp=buf;
int type, N;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int ch[30];
void write(int x)
{
    ch[0]=0;
    while (x) ch[++ch[0]]=x%10,x/=10;
    if (!ch[0]) ch[0]=1,ch[1]=0;
    while (ch[0]) putchar('0'+ch[ch[0]--]);
}
void init()
{
    
}
int encode(int x, int y)
{
    return x;
}

bool decode(int q, int h)
{
    return q == h;
}

int main()
{
    int T;
    type=read(), N=read(), T=read();
    init();
    while (T--) {
        int x=read(),y=read();
        if (type == 1)
        {
            write(encode(x, y));
            putchar('\n');
        }
        else
        {
            puts(decode(x, y) ? "yes" : "no");
        }
    }
}


