#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while(!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while(isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n = n * sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 511;
const int MOD = 998244353;
int n, m, ans;
int len[N];
char t[N][N], s[N][N], p[N*N];

ll mut(ll a, ll b){
	ll y = 1, t = a;
	for (; b; b >>= 1, t = t * t % MOD)
		if (b & 1) y = y * t % MOD;
	return y;
}
bool find(char *s, char *t){
	int l = strlen(s + 1), r = strlen(t + 1);
	if (l > r) return false;
	for (int i = 1; i <= r - l + 1; ++i){
		bool flg = true;
		rep(j, 1, l) if (s[j] != t[i+j-1]) flg = false;
		if (flg) return true;
	}
	return false;
}
bool check(int x, char *p, int l, int r){
	for (int i = x, j = x + 1; i >= l&&j <= l + r - 1; --i, ++j)
		if (p[i] == p[j]) return false;
	return true;
}
void calc(char *p, int l, int r){
//	rep(i, l, l + r - 1) cerr << p[i] << ' '; cerr << endl;
	rep(i, l - 1, l + r - 1){
		if (!check(i, p, l, r)) continue;
		int le = i - l + 1, ri = l + r - 1 - i;
		if (max(le, ri) * 2 > m) continue;
		ans = (ans + mut(2, m / 2 - max(le, ri))) % MOD;
	}
}
void dfs(int x, char *p, int l, int r){
	if (x > n) {calc(p, l, r); return ;}
	rep(i, l, l + r){
		bool flg = true; int j;
		for (j = 1; j <= len[x]&&i + j - 1 <= l + r - 1; ++j)
			if (s[x][j] != p[i+j-1]) flg = false;
		if (flg&&j <= len[x]){
			int t = r;
			for (; j <= len[x]; ++j) t++, p[l+t-1] = s[x][j];
			dfs(x + 1, p, l, t);
		}
	}
	per(i, l + r - 1, l - 1){
		bool flg = true; int j;
		for (j = 1; j <= len[x]&&i - j + 1 >= l; ++j)
			if (s[x][len[x]-j+1] != p[i-j+1]) flg = false;
		if (flg&&j <= len[x]){
			int le = l, ri = r;
			for (; j <= len[x]; ++j) ri++, p[--le] = s[x][len[x]-j+1];
			dfs(x + 1, p, le, ri);
		}
	}
}

int main(){
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	read(n), read(m); m <<= 1;
	rep(i, 1, n) scanf("%s", t[i] + 1);
	int tmp = n; n = 0;
	rep(i, 1, tmp){
		bool flg = true;
		rep(j, 1, tmp) if (find(t[i], t[j])&&i != j) flg = false;
		if (flg) strcpy(s[++n] + 1, t[i] + 1);
	}
	rep(i, 1, n) len[i] = strlen(s[i] + 1);
	int l = N, r = 0;
	rep(i, 1, len[1]) r++, p[l+r-1] = s[1][i];
	dfs(2, p, l, r);
	printf("%d\n", ans);
	return 0;
}

