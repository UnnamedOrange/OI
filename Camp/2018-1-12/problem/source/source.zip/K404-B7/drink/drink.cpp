#include<bits/stdc++.h>
#define ll long long
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c<'0'||c>'9')&&c!='-';c=getchar());
	if(c=='-')f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

const int N=1000005;
struct node
{
	int val,p;
	inline friend bool operator < (const node &a,const node &b)
	{
		if(a.val==b.val)return a.p<b.p;
		return a.val<b.val;
	}
}b[N];
int n,lim,a[N],l[N],r[N];
double ans;

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=getint();
	if(n<=2000)lim=100;
	else lim=50;
	for(int i=1;i<=n;i++)
	{
		b[i].val=a[i]=getint(),b[i].p=i;
		l[i]=i-1,r[i]=i+1;
	}
	sort(b+1,b+n+1);
	for(int i=1;i<=n;i++)
	{
		double e=1,t1=0,t2=0;
		int p1=b[i].p,p2;
		for(int j=1;j<=lim;j++)
		{
			p2=l[p1];
			t1+=(p1-p2)*e;
			if(!p2)break;
			p1=p2;
			e*=0.5;
		}
		e=0.5,p1=b[i].p;
		for(int j=1;j<=lim;j++)
		{
			p2=r[p1];
			t2+=(p2-p1)*e;
			if(p2==n+1)break;
			p1=p2;
			e*=0.5;
		}
		p1=b[i].p;
		ans+=t1*t2*a[p1];
		r[l[p1]]=r[p1],l[r[p1]]=l[p1];
	}
	ans/=(ll)n*n;
	printf("%0.8f\n",ans);
	return 0;
}
