#include<bits/stdc++.h>
using namespace std;

const int MAXL = 110;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m;
int l[7], ans;
char s[7][MAXL];
bool S[50];

void dfs(int cur) {
	if(cur == m+1) {
		int i, j, k;
		for(i = m+1; i <= 2*m; i++) S[i] = S[2*m-i+1]^1;
		for(i = 1; i <= n; i++) {
			for(j = 1; j+l[i]-1 <= 2*m; j++) {
				for(k = 1; k <= l[i]; k++) 
					if(S[j+k-1] != s[i][k]-'0') break;
				if(k > l[i]) break;
			}
			if(j+l[i]-1 > 2*m) return;
		}
		/*for(i = 1; i <= 2*m; i++) printf("%d", S[i]);
		printf("\n");*/
		ans++;
		return;
	}
	S[cur] = true;
	dfs(cur+1);
	S[cur] = false;
	dfs(cur+1);
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i;

	n = read(), m = read();

	for(i = 1; i <= n; i++) {
		scanf("%s", s[i]+1);
		l[i] = strlen(s[i]+1);
	}

	dfs(1);
	printf("%d\n", ans);
	return 0;
}
