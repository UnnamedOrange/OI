#include<bits/stdc++.h>
using namespace std;
bool p1,p2;
int t,n;
string st;
void pan(){
	p1=true;p2=true;
	for (int i=1;i<=n/2;i++){
		if (st[i]!=st[n-i+1]){
			p1=false;p2=false;
		}
		if (st[i]!=st[1]){
			p1=false;
		}
	}
}
bool co(){
	for (int i=1;i<=n;i+=2)if (st[i]!=st[1]) return false;
	for (int i=2;i<=n;i+=2)if (st[i]!=st[2]) return false;
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	cin>>t;
	while (t--){
		cin>>n;
		for (int i=1;i<=n;i++){
			st[i]=getchar();
			while (st[i]<'a'||st[i]>'z') st[i]=getchar();
		}
		pan();
		if (!p2)cout<<"1"<<endl;
		else if (p1)cout<<"-1"<<endl;
			else
				if (n%2==0)cout<<"2"<<endl;
				else if (co()) cout<<"-1"<<endl;else cout<<"2"<<endl;
	}
	return 0;
}
