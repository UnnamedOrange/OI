//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
lovelive mod=1e9+7;
void read(lovelive &x)
{
  x=0;
  char c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c>='0'&&c<='9')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
lovelive a[1010],b[1010],c[1010],d[1010],e[1010],f[1010],x[1010],y[1010],z[1010];
lovelive x2[1010],y2[1010],r[1010],w[1010];
lovelive val(lovelive x)
{
  if(x<0)
    return -x;
   return x;
}
int main()
{
  freopen("variable.in","r",stdin);
  freopen("variable.out","w",stdout);
  lovelive n,p,q,W,T,ans,sum;
  bool sp;
  read(T);
  while(T--)
  {
  	ans=2e9;
  	read(n);read(W);read(p);read(q);
  	for(int i=1;i<=p;i++)
  	{
  	  read(x[i]);read(y[i]);read(z[i]);
  	  read(a[i]);read(b[i]);read(c[i]);
  	  read(d[i]);read(e[i]);read(f[i]);
	}
	for(int i=1;i<=q;i++)
	  read(x2[i]),read(y2[i]),read(r[i]);
	for(int i=0;i<(1<<n);i++)
	{
	  sum=sp=0;
	  for(int j=0;j<n;j++)
	  {
	    if((i>>j)&1)
	      w[j+1]=1;
	    else
	      w[j+1]=-1;
	    sum+=w[j+1];
	  }
	  for(int j=1;j<=q;j++)
	  	if((r[j]==0&&w[x2[j]]>w[y2[j]])||(r[j]==1&&w[x2[j]]!=w[y2[j]])||(r[j]==2&&w[x2[j]]>=w[y2[j]]))
	  	{
	  	  sp=true;
	  	  break;
	  	}
	  if(sp)
	    continue;
	  for(int j=1;j<=p;j++)
	  {
	  	sum+=a[j]*val(x[j]-y[j]);
	  	sum+=b[j]*val(y[j]-z[j]);
	  	sum+=c[j]*val(z[j]-x[j]);
	  	sum+=d[j]*(x[j]-y[j]);
	  	sum+=e[j]*(y[j]-z[j]);
	  	sum+=f[j]*(z[j]-x[j]);
	  }
	  ans=min(ans,sum);
	}
  }
  cout<<ans*W<<"\n";
  return 0;
}
