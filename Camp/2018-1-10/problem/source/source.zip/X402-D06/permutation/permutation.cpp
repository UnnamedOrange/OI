#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e5+10;
const int mod=998244353;
int a[maxn],vis[maxn],chkvis[maxn];
int n,ans=0;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline int check(){
	int i;
	for(i=1;i<=n;i++)chkvis[i]=0;
	for(i=1;i<=n;i++){
		if(chkvis[i])continue;
		chkvis[i]=1;
		int pos=a[i],cnt=1;chkvis[pos]=1;
		while(pos!=i){
			pos=a[pos];
			chkvis[pos]=1;
			cnt++;
		}
		if(cnt%2==1)return 0;
	}
	return 1;
}
void dfs(int cur,int goal){
	int i;
	if(cur>goal){
		if(check())ans++;
		return;
	}
	if(a[cur])dfs(cur+1,goal);
	for(i=1;i<=goal;i++){
		if(vis[i])continue;
		vis[i]=1;
		a[cur]=i;
		dfs(cur+1,goal);
		vis[i]=0;
		a[cur]=0;
	}
}
int main(){
	int i,j,k,m;
#ifndef ONLINE_JUDGE
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
#endif
	n=read();
	ll sum=0;
	for(i=1;i<=n;i++){
		a[i]=read();
		if(a[i])vis[a[i]]=1;
		sum+=1ll*a[i];
	}
	if(n%2==1)return puts("0"),0;
	if(sum==0){
		ll tans=1;
		for(i=1;i<=n;i+=2)tans=tans*i%mod*i%mod;
		printf("%lld\n",tans);
		return 0;
	}
	dfs(1,n);
	printf("%d\n",ans);
	return 0;
}

