#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 10
#define mod 998244353
#define ll long long
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int n;
int p[N],a[N];
namespace subtask1
{
    int vis[N],T,ans;
    int dfs(int x,int dep)
    {
        if(vis[x]==T)return dep;
        vis[x]=T;
        return dfs(p[x],dep+1);
    }
    void main()
    {
        for(int i=1;i<=n;i++)a[i]=read();
        for(int i=1;i<=n;i++)p[i]=i;
        do{
            bool flag=0;
            for(int i=1;i<=n;i++)
            if(a[i]&&p[i]!=a[i]){flag=1;break ;}
            if(flag)continue ;
            T++;

            for(int i=1;i<=n;i++)
            if(vis[i]!=T)
            {
                int tmp=dfs(i,0);
                if(tmp&1){flag=1;break ;}
            }
            if(!flag)ans++;
        }while(next_permutation(p+1,p+n+1));

        printf("%d\n",ans);
    }
}
namespace subtask2
{
    void main()
    {
        if(n&1)
        {
            puts("0");
            exit(0);
        }
        n--;
        ll tmp=1;
        for(int i=3;i<=n;i+=2)
        {
            tmp=tmp*i%mod*i%mod;
        }
        printf("%lld\n",tmp);
    }
}
int main()
{
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
	n=read();
	if(n<=8)subtask1::main();
    else subtask2::main();
}
