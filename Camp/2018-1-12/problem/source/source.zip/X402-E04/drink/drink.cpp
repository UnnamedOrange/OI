#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=1000010,IN=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
int n,w[N];
inline void file(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
}
void init(){
	read(n);
	For(i,1,n)read(w[i]);
}
double solve(int x){
	double ans1=0,ans2=1,ret1=1,ret2=1;
	For(i,x,n){
		if(w[i]>=w[x])ret1=ret1/2.0;
		ans1=ans1+ret1;
	}
	Forr(i,x-1,1){
		if(w[i]>w[x])ret2/=2.0;
		ans2=ans2+ret2;
	}
	return w[x]*ans1*ans2;
}
void solve(){
	double ans=0;
	For(i,1,n)
		ans+=solve(i);
	printf("%lf\n",ans/n/n);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
