#include<stdio.h>
int main(){
  printf("%d\n", 1+2);
  return 0;
}
