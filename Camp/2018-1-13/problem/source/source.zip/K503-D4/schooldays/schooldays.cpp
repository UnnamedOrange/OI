#include<bits/stdc++.h>
#define maxn 1000010
#define mod 1000000007
#define INF 100000000
using namespace std;
struct data{int a, posi;};
int c[maxn], d[maxn], f[maxn], g[maxn], mnd[maxn], mxc[maxn], mx[maxn * 4], sum[maxn * 4], n;
pair<int, int> A[maxn];
int read()
{
	int tmp = 0; char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9')
	{
		tmp = tmp * 10 + c - '0';
		c = getchar();
	}
	return tmp;
}
void zj(int now, int l, int r, int posi, int x, int y)
{
	if (l == r)
	{
		if (x == -INF) return;
		if (x + 1> mx[now]) {mx[now] = x + 1; sum[now] = y;}
		else if (x + 1 == mx[now]) {sum[now] = sum[now] + y; if (sum[now] > mod) sum[now] -= mod;}
		return;
	}
	int mid = (l + r) / 2;
	if (posi <= mid) zj(now * 2, l, mid, posi, x, y);
	else zj(now * 2 + 1, mid + 1, r, posi, x, y);
	mx[now] = max(mx[now * 2], mx[now * 2 + 1]);
	if (mx[now * 2] == mx[now]) sum[now] = sum[now * 2]; else sum[now] = 0;
	if (mx[now * 2 + 1] ==  mx[now]) {sum[now] = sum[now] + sum[now * 2 + 1]; if (sum[now] > mod) sum[now] -= mod;}
}
void zy(int now, int l, int r, int left , int right, int x)
{
	if (l == left && r == right)
	{
		if (mx[now] > f[x]) {f[x] = mx[now]; g[x] = sum[now];}
		else if (mx[now] == f[x]) {g[x] = g[x] + sum[now]; if (g[x] > mod) g[x] -= mod;}
		return;
	}
	int mid = (l + r) / 2;
	if (left <= mid) zy(now * 2, l, mid ,left, min(right, mid), x);
	if (right >= mid + 1) zy(now * 2 + 1, mid + 1, r, max(left, mid + 1), right, x);
}
void hy(int now, int l, int r, int x)
{
	sum[now] = 0; mx[now] = -INF;
	if (l == r) return;
	int mid = (l + r) / 2;
	if (x <= mid) hy(now * 2, l, mid, x);
	else hy(now * 2 + 1, mid + 1, r, x);
}
void solve(int l, int r)
{
	if (l == r) return;
	int mid = (l + r) / 2, chl, chr, used = l - 1;
	solve(l, mid);
	mnd[mid] = d[mid]; mxc[mid] = c[mid];
	mnd[mid + 1] = d[mid + 1]; mxc[mid + 1] = c[mid + 1];
	for (int i = mid - 1; i >= l; i--)
	{
		mnd[i] = min(mnd[i + 1], d[i]);
		mxc[i] = max(mxc[i + 1], c[i]);
	}
	for (int i = mid + 2; i <= r; i++)
	{
		mnd[i] = min(mnd[i - 1], d[i]);
		mxc[i] = max(mxc[i - 1], c[i]);
	}
	for (int i = l; i <= mid; i++)
		if (i < mid) A[i] = make_pair(mxc[i + 1] + i, i);
		else A[i] = make_pair(mid, i);
	sort(A + l, A + mid + 1);
	chl = l;
	for (int i = mid + 1; i <= r; i++)
	{
		while (chl <= mid && min(mnd[chl + 1], mnd[i]) < i - chl)
			chl++;
		while (used < mid && A[used + 1].first <= i)
		{
			used++;
			int ch = A[used].second;
			zj(1, 1, mid - l + 1, ch - l + 1, f[ch], g[ch]);
		}
		if (chl > mid) break;
		chr = min(mid, i - mxc[i]);
		if (chl <= chr) zy(1, 1, mid - l + 1, chl - l + 1, chr - l + 1, i);
	}
	for (int i = l; i <= used; i++)
		hy(1, 1, mid - l + 1, A[i].second - l + 1);
	solve(mid + 1, r);
} 
void build(int now, int l, int r)
{
	mx[now] = -INF;
	if (l == r) return;
	int mid = (l + r) / 2;
	build(now * 2, l, mid);
	build(now * 2 + 1, mid + 1, r);
}
int main()
{
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
	n = read();
	for (int i = 1; i <= n; i++)
		c[i] = read(), d[i] = read();
	for (int i = 1; i <= n; i++)
		f[i] = -INF;
	int mxc = 0, mnd = INF;
	for (int i = 1; i <= n; i++)
	{
		mxc = max(mxc, c[i]);
		mnd = min(mnd, d[i]);
		if (mxc <= i && mnd >= i) f[i] = g[i] = 1;
	}
	build(1, 1, n);
	solve(1, n);
	if (f[n] == -INF) puts("-1");
	else printf("%d %d\n", f[n], g[n]);
	return 0;
}
