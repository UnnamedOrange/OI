#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;
#define fst first
#define snd second

typedef long long LL;
typedef std::pair<int, int> Pii;

#ifdef __linux__
#define getchar getchar_unlocked
#endif
template <typename T> inline bool maximum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T> inline bool minimum(T &a, T b) { return a > b? a = b, 1 : 0; }
template <typename T>
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int mod = 1e9 + 7;
const int N = 1e6 + 10;
const int inf = 0x3f3f3f3f;

int fpm(int x, int e)
{
	int res = 1;
	for(; e; e >>= 1){
		if(e & 1) res = (LL)res * x % mod;
		x = (LL)x * x % mod;
	}
	return res;
}

void add(int &a, int b)
{
	a += b;
	if(a >= mod) a -= mod;
}

int n, c[N], d[N];

bool Init()
{
	read(n);
	for(int i = 1; i <= n; ++i) read(c[i]), read(d[i]);
	return n <= 2000;
}

namespace bfer
{
	int dp[2010], g[2010];

	void main()
	{
		g[0] = 1; dp[0] = 0;

		for(int i = 1; i <= n; ++i){
			int cmax = 0, dmin = inf;
			for(int j = i; j >= 1; --j){
				maximum(cmax, c[j]);
				minimum(dmin, d[j]);
				if(cmax <= i-j+1 && dmin >= i-j+1){
					if(dp[j-1] + 1 == dp[i]) add(g[i], g[j-1]);
					else if(maximum(dp[i], dp[j-1] + 1)) g[i] = g[j-1];
				}
			}
		}
//		std::cerr << dp[8] << std::endl;

		!g[n]? puts("-1") : printf("%d %d\n", dp[n], g[n]);
		return ;
	}
}

namespace SEGT
{
#define lc (h << 1)
#define rc (lc | 1)

	int Mx[N << 2];

	void insert(int h, int l, int r, int u, int x)
	{
		maximum(Mx[h], x);
		int mid = (l + r) >> 1;
		if(l != r)
			u <= mid? insert(lc, l, mid, u, x) : insert(rc, mid + 1, r, u, x);
	}

	int query(int h, int l, int r, int ql, int qr)
	{
		if(ql <= l && r <= qr) return Mx[h];

		int mid = (l + r) >> 1;
		int tmp = 0;
		if(ql <= mid) tmp = query(lc, l, mid, ql, qr);
		if(qr > mid) maximum(tmp, query(rc, mid + 1, r, ql, qr));

		return tmp;
	}
#undef lc
#undef rc
}

namespace pfer
{
	int nxt[N], dp[N], g[N];

	void main()
	{
		d[0] = inf;
		for(int i = 0; i < n; ++i){
			nxt[i] = std::max(nxt[i-1], i+1);
			int dmin = d[i+1];
			while(dmin >= nxt[i]-i && nxt[i] <= n){
				++nxt[i];
				minimum(dmin, d[nxt[i]]);
			}
			--nxt[i];
		}
		for(int i = 1; i <= n; ++i)
			SEGT::insert(1, 1, n, i, c[i]);

		g[0] = 1; dp[0] = 0;

		for(int i = 0; i < n; ++i){
			int j = i + c[i+1];
			int cmax = 0;
			if(i < j) maximum(cmax, SEGT::query(1, 1, n, i+1, j));
			while(cmax > j - i){
				int tmp = SEGT::query(1, 1, n, j, i + cmax);
				j = i + cmax;
				maximum(cmax, tmp);
			}
			for(; j <= nxt[i]; ++j){
				maximum(cmax, c[j]);
				if(cmax > j - i){
					if(i + cmax - j > 20){
						int tmp = SEGT::query(1, 1, n, j, i + cmax);
						j = i + cmax - 1;
						maximum(cmax, tmp);
					}
					continue;
				}

				if(dp[j] == dp[i] + 1) add(g[j], g[i]);
				else if(maximum(dp[j], dp[i] + 1)) g[j] = g[i];
			}
		}

		!g[n]? puts("-1") : printf("%d %d\n", dp[n], g[n]);
		return ;
	}
}

int main()
{
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);

	if(Init())
		bfer::main();
	else
		pfer::main();
	return 0;
}
