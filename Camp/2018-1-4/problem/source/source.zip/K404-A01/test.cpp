//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const lovelive mod=1004535809;
void read(int &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
int a[25];
int main()
{
  freopen("sequence.in","r",stdin);
  freopen("test.out","w",stdout);
  int n,pos,ans=0;
  read(n);
  for(int i=1;i<=n;i++)
    read(a[i]);
  for(int i=n;i>=1;i--)
  {
  	pos=i;
  	if(a[i]==i)
  	  continue;
  	while(a[pos]!=i)
  	  --pos;
  	if(pos!=1)
  	{
  	  for(int j=1;j<=pos-j;j++)
		swap(a[j],a[pos-j+1]);
	  ++ans;
  	}
  	++ans;
  	for(int j=1;j<=i-j;j++)
  	  swap(a[j],a[i-j+1]);
  }
  cout<<ans<<"\n";
}
