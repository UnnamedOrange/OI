#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
using namespace std;

const int MAXN = 1e5 + 200, MOD = 1e9 + 7;
int n, a, b;
int x[MAXN];
long long ans[4], two[MAXN];
bool visit[30];

namespace Force
{
	void check()
	{
		int A = 0;
		for (int i = 1; i < n + 1; ++i)
		{
			if (!visit[i])
				continue;
			if (x[i] >= a && x[i] < b)
				++A;
			else if (x[i] >= b && x[i] < a)
				--A;
		}
		if (A > 0)
			++ans[0];
		else if (A < 0)
			++ans[1];
		else
		{
			int r = 0, u = 0;
			for (int i = 1; i < n + 1; ++i)
			{
				if (visit[i] && x[i] >= a && x[i] >= b)
				{
					++r;
					if (x[i] >= 2 * min(a, b))
						++u;
				}
			}
			if (u == 0)
			{
				if (r % 2 == 0)
					++ans[3];
				else
					++ans[2];
			}
			else if (u == 1)
			{
				if (r % 2 == 1)
					++ans[2];
				else
				{
					if (a < b)
						++ans[0];
					else
						++ans[1];
				}
			}
			else
			{
				if (a < b)
					++ans[0];
				else
					++ans[1];
			}
		}
	}
	void dfs(int p)
	{
		if (p == n + 1)
			check();
		else if (p < n + 1)
		{
			visit[p] = true;
			dfs(p + 1);
			visit[p] = false;
			dfs(p + 1);
		}
	}
	void main()
	{
		dfs(1);
		printf("%lld %lld %lld %lld\n", ans[0], ans[1], ans[2], ans[3]);
	}
}

namespace Work
{
	vector<int> zero, one;
	void check()
	{
		int A = 0, win = -1;
		for (int i = 0; i < one.size(); ++i)
		{
			if (visit[i])
			{
				if (one[i] >= a && one[i] < b)
					++A;
				else if (one[i] < a && one[i] >= b)
					--A; 
			}
		}
		if (A > 0)
			win = 0;
		else if (A < 0)
			win = 1;
		else
		{
			int r = 0, u = 0;
			for (int i = 0; i < one.size(); ++i)
			{
				if (visit[i] && one[i] >= a && one[i] >= b)
				{
					++r;
					if (one[i] >= 2 * min(a, b))
						++u;
				}
			}
			if (u == 0)
			{
				if (r % 2 == 0)
					win = 3;
				else
					win = 2;
			}
			else if (u == 1)
			{
				if (r % 2 == 1)
					win = 2;
				else
				{
					if (a < b)
						win = 0;
					else
						win = 1;
				}
			}
			else
			{
				if (a < b)
					win = 0;
				else
					win = 1;
			}
		}
		ans[win] += two[zero.size()];
		ans[win] %= MOD;
	}
	void dfs(int p, int d)
	{
		if (p == d)
			check();
		else if (p < d)
		{
			visit[p] = true;
			dfs(p + 1, d);
			visit[p] = false;
			dfs(p + 1, d);
		}
	}
	void main()
	{
		for (int i = 1; i < n + 1; ++i)
		{
			if (x[i] == 0 || x[i] < min(a, b))
				zero.push_back(x[i]);
			else
				one.push_back(x[i]);
		}
		dfs(0, one.size());
		printf("%lld %lld %lld %lld\n", ans[0], ans[1], ans[2], ans[3]);
	}
}

namespace Spe
{
	void main()
	{
		printf("%lld %lld %lld %lld\n", 0, 0, two[n - 1], two[n - 1]);
		return;
	}
}

namespace AcDream
{
	void main()
	{
		int u = 0, v = 0, w = 0, k = 0;
		if (2 * b < a)
		{
			for (int i = 1; i < n + 1; ++i)
			{
				if (x[i] < min(a, b))
					++u;
				else if (x[i] < max(a, b))
					++k;
				else 
					++w;
			}
			ans[2] = two[u] * w % MOD;
			ans[3] = two[u] % MOD;
			if (a < b)
			{
				ans[0] = two[u + k + w] - ans[2];
				ans[0] %= MOD;
				ans[0] -= ans[3];
				ans[0] = (ans[0] + MOD) % MOD; 
			}
			else
			{
				ans[1] = two[u + k + w] - ans[2];
				ans[1] %= MOD;
				ans[1] -= ans[3];
				ans[1] = (ans[1] + MOD) % MOD;
			}
		}
		else
		{
			for (int i = 1; i < n + 1; ++i)
			{
				if (x[i] < min(a, b))
					++u;
				else if (x[i] >= min(a, b) && x[i] < max(a, b))
					++k;
				else if (x[i] < 2 * min(a, b))
					++v;
				else
					++w;
			}
			if (v > 0)
				ans[2] = two[v - 1] % MOD * (1 + w) % MOD * two[u] % MOD;
			else
				ans[2] = two[u] * w % MOD;
			if (v > 0)
				ans[3] = two[v - 1] % MOD * two[u] % MOD;
			else
				ans[3] = two[u];
			if (a < b)
			{
				ans[0] = (two[u + v + w + k] - ans[2]) % MOD - ans[3];
				ans[0] %= MOD;
				ans[0] += MOD;
				ans[0] %= MOD;
			}
			else if (b < a)
			{
				ans[1] = (two[u + v + w + k] - ans[2]) % MOD - ans[3];
				ans[1] %= MOD;
				ans[1] += MOD;
				ans[1] %= MOD;
			}
		}	
		printf("%lld %lld %lld %lld\n", ans[0], ans[1], ans[2], ans[3]);
	}
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	n = read();
	a = read();
	b = read();
	for (int i = 1; i < n + 1; ++i)
	{
		x[i] = read();
		x[i] = x[i] % (a + b);
	}
	two[0] = 1;
	for (int i = 1; i < n + 1; ++i)
		two[i] = (two[i - 1] << 1) % MOD;
	if (n <= 5)
		Force::main();
	else if (n <= 20)
		Work::main();
	else if (a == b)
		Spe::main();
	else
		AcDream::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
