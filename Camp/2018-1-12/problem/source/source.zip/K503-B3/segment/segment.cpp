#include <bits/stdc++.h>
using namespace std;

const int Mod = 998244353;

int n, m, k;

int main() {
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	cin >> n >> m >> k;
	--m;
	int ans = 0;
	for (int i = 1; i <= m; ++i) {
		ans = (ans+(m-i+1LL)*i)%Mod;
	}
	cout << ans << endl;
	return 0;
}
