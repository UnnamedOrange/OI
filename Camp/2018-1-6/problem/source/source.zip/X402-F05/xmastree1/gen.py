from random import *

f = open('xmastree1.in', 'w')

n = 100000
q = 100000
maxc = n

if randint(1, 2) == 1:
	maxc /= 100

t = 0

f.write('{} {} {}\n'.format(n, q, t))

for i in range(1, n + 1):
	f.write('{} '.format(randint(1, maxc)))
f.write('\n')

for i in range(2, 10):
	f.write('{} {}\n'.format(i, randint(1, i - 1)))
for i in range(10, n + 1):
	f.write('{} {}\n'.format(i, randint(i - 9, i - 1)))

for i in range(0, q):
	ty = randint(1, 2)
	u = randint(1, n)

	if ty == 1:
		l = randint(1, maxc)
		r = randint(l, maxc)
		f.write('{} {} {} {}\n'.format(ty, u, l, r))
	else:
		c = randint(1, maxc)
		f.write('{} {} {}\n'.format(ty, u, c))
		

