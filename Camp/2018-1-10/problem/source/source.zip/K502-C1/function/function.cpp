#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
using namespace std;

const int MAXN = 1e6 + 100;
int n, sz;
long long mu[MAXN], delta[MAXN], s[MAXN], primes[MAXN];
bool isprime[MAXN];

void MuDelta()
{
	mu[1] = 1;
	delta[1] = 1;
	isprime[1] = true;
	int up = 1000001;
	for (int i = 2; i < up; ++i)
	{
		if (!isprime[i])
		{
			mu[i] = -1;
			primes[sz] = i;
			++sz;
		}
		for (int j = 0; j < sz; ++j)
		{
			if (i * primes[j] > up)
				break;
			if (i % primes[j] == 0)
			{
				isprime[i * primes[j]] = true;
				mu[i] = 0;
				break;
			}
			isprime[i * primes[j]] = true;
			mu[i * primes[j]] = -mu[i];
		}
	}
	for (int i = 2; i < up; ++i)
	{
		if (!isprime[i])
			delta[i] = 2;
		for (int j = 0; j < sz; ++j)
		{
			if (primes[j] > i || i * primes[j] > up)
				break;
			if (i % primes[j] == 0)
			{
				int t = i, cnt = 0;
				while (t > 0 && t % primes[j] == 0)
				{
					++cnt;
					t /= primes[j];
				}
				delta[i * primes[j]] = delta[i] * (cnt + 2) / (cnt + 1);
				break;
			}
			else
				delta[i * primes[j]] = delta[i] * 2;
		}
	}
}

void init()
{
	MuDelta();
	s[1] = 1;
	int up = n + 1;
	for (int i = 2; i < up; ++i)
	{
		s[i] = s[i - 1];
		for (int j = 1; j < sqrt(i) + 1; ++j)
		{
			if (i % j == 0)
			{
				s[i] += mu[j] * delta[i / j] * delta[i / j];
				s[i] += mu[i / j] * delta[j] * delta[j];
			}
		}
	}
}

long long query(int dd)
{
	long long ret = 0;
	for (int i = 1; i < dd + 1; ++i)
	{
		for (int j = 1; j < sqrt(i) + 1; ++j)
		{
			if (i % j == 0)
			{
				ret += mu[j] * delta[i / j] * delta[i / j];
				ret += mu[i / j] * delta[j] * delta[j];
			}
		}
	}
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	int T = read(), tc = 0;
	int ask[20];
	while(T--)
	{
		read();
		printf("0\n");
	}
	fclose(stdin);
	fclose(stdout);
}
