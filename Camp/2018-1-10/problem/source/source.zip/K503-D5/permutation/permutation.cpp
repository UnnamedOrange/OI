#include <cstdio>
#define LL long long
#define rep(i,j,k) for (i=j;i<=k;i++)
#define down(i,j,k) for (i=j;i>=k;i--)
using namespace std;
const int N=1e5+5,mod=998244353;
int n,i,j,fix,ans,sum,a[N],f[N],used[N],mark[N],fac[N],inv[N];
int quickmi(int a,int n)
{
	int ret=1,bsc=a;
	for (;n>0;n>>=1,bsc=(LL)bsc*bsc%mod)
	  if (n&1) ret=(LL)ret*bsc%mod;
	return ret;
}
void sub_task_30()
{
	fac[1]=1;
	rep(i,2,n) fac[i]=(LL)fac[i-1]*i%mod;
	inv[n]=quickmi(fac[n],mod-2);
	down(i,n-1,1) inv[i]=(LL)(i+1)*inv[i+1]%mod;
	f[0]=1; sum=1;
	for (i=2;i<=n;i+=2)
	{
		f[i]=(LL)sum*fac[i-1]%mod;
		sum=(sum+(LL)f[i]*inv[i]%mod)%mod;
	}
	/*
	rep(i,2,n)
	  for (j=2;j<=i;j+=2)
	    f[i]+=f[i-j]*c[i-1][j-1]*fac[j-1];
	*/
	printf("%d\n",f[n]);	
}
void check()
{
	int i,j,cnt;
	rep(i,1,n) mark[i]=0;
	rep(i,1,n)
	if (!mark[i])
	{
	    mark[i]=1; cnt=1;
	    for (j=a[i];j!=i;j=a[j]) mark[j]=1,cnt++;
        if (cnt&1) return;
	}
	ans++;
}
void dfs(int x)
{
	if (x>n)
	{
		check();
		return;
	}
	if (a[x]) dfs(x+1);
	else {
    int i;
    rep(i,1,n)
      if (!used[i] && i!=x)
      {
      	 used[i]=1; a[x]=i;
      	 dfs(x+1);
      	 used[i]=0; a[x]=0;
	  }
    }
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
    rep(i,1,n)
    {
	   scanf("%d",&a[i]);
       if (a[i]!=0) fix=1;
	}
	if (!fix) sub_task_30();
	else {
	  rep(i,1,n) if (a[i]) used[a[i]]=1;
	  dfs(1);
	  printf("%d\n",ans);
	}
	return 0;
}
