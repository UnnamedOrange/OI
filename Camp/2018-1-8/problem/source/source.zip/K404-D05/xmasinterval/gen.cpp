#include<bits/stdc++.h>
#define FE "xmasinterval"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		c=='-'?p=-1:0;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
inline void putint(int x){
	x<0?putchar('-'),x=-x:0;
	static int buf[20];
	int tot=0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
int main(){
	freopen(FE".in","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL),cout.tie(NULL);
	srand(time(0));
	int n=1000,m=1000;
	cout<<n<<" "<<m<<endl;
	for(int i=1;i<=n;++i){
		int a=rand()%1000+1,b=rand()%1000+1;
		if(a>b)swap(a,b);
		cout<<a<<" "<<b<<"\n";
	}
	for(int i=1;i<=m;++i){
		cout<<rand()%300+500<<"\n";
	}
	return 0;
}
