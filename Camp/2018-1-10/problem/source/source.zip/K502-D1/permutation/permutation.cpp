#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

const int MAXN = 1e5 + 10;
int n;
long long ans = 0;
int p[MAXN];
int status[MAXN];
int num[MAXN];
long long fra[MAXN];
long long mod = 998244353;
bool judge()
{
	int sum = 0;
	for(int i = 1; i <= n; i++) {
		if(p[i]) {
			status[i] = p[i];
		}
	}
	for(int i = 1; i <= n; i++) {
		int k = status[i];
		sum = 0;
		while(k != i) {
		//	cout<<k<<endl;
			k = status[k];
			sum++;
		}
		if(sum % 2 == 0) {
			return false;
		}
	}
	
}
void DFS(int x)
{
	if(x == n + 1) {
		if(judge()) {
			ans++;
		}
		return;
	}
	if(p[x]) {
		DFS(x + 1);
	} else {
		for(int i = 1; i <= n; i++) {
			if(i != x && (num[i] == 0)) {
				num[i] = 1;
				status[x] = i;
				DFS(x + 1);
				num[i] = 0;
			}
		}
	}
}

inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

void open()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}

int main()
{
	open();
	fra[1] = 1;
	n = read();
	for(int i = 1; i <= n; i++) {
		p[i] = read();
		num[p[i]] = 1;
	}
	if(n <= 8) {
		DFS(1);
	} else {
		if(n % 2 == 1) {
			ans = 0;
		} else {
			for(int i = 3; i <= n; i += 2) {
				fra[i] = fra[i - 2] * i % mod;
			}
			fra[n - 1] = fra[n - 1] * fra[n - 1] % mod;
			ans = fra[n - 1];
		}
	}
	printf("%lld\n", ans);
	close();
	return 0;
}
