#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 27
#define ll long long
using namespace std;
inline int read() 
{ 
    int x=0,f=1;char ch=getchar(); 
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();} 
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
    return x*f; 
}
int T,lim,n_lim;
int n,a[N];
bool ok=0;
void dfs(int x,int cal)
{
	if(x+cal>n_lim)return ;
	if(ok)return ;
	if(cal==0&&a[1]==1)
	{
		ok=1;
		return ;
	}
	int tmp[N];
	for(int i=1;i<=n;i++)tmp[i]=a[i];
	for(int i=2;i<=n;i++)
	{
		int sav=cal;
        sav-=(abs(a[i+1]-a[i])>1);
        sav+=(abs(a[1]-a[i+1])>1);
		reverse(a+1,a+i+1);
		dfs(x+1,sav);
		for(int j=1;j<=n;j++)
		a[j]=tmp[j];
	}
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	T=read();
	while(T--)
	{
		ok=0;
		n=read();
		lim=0;
		for(int i=1;i<=n;i++)a[i]=read();
		a[n+1]=n+1;
		for(int i=1;i<=n;i++)lim+=(abs(a[i+1]-a[i])>1);
		
		for(int i=lim;i<=2*n-2;i++)
		{
			n_lim=i;
			dfs(0,lim);
			if(ok)
			{
				printf("%d\n",i);
				break ;
			}
		}
	}
}