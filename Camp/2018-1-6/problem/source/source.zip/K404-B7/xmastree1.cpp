#include<bits/stdc++.h>
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f; 
}

const int N=100005;
int n,m,t,ans,lastans;
int tot,first[N],nxt[N<<1],to[N<<1];
int cnt[N],c[N],fa[N];

void add(int x,int y)
{
	nxt[++tot]=first[x],first[x]=tot,to[tot]=y;
}

void dfs(int u)
{
	for(int e=first[u];e;e=nxt[e])
	{
		int v=to[e];
		if(v==fa[u])continue;
		fa[v]=u;
		dfs(v);
	}
}

void solve(int u,const int &l,const int &r)
{
	if(c[u]>=l&&c[u]<=r)
	{
		cnt[c[u]]++;
		if(cnt[c[u]]==1)ans++;
	}
	for(int e=first[u];e;e=nxt[e])
	{
		int v=to[e];
		if(v==fa[u])continue;
		solve(v,l,r);
	}
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int x,y,op,l,r;
	n=getint(),m=getint(),t=getint();
	for(int i=1;i<=n;i++)c[i]=getint();
	for(int i=1;i<n;i++)
	{
		x=getint(),y=getint();
		add(x,y),add(y,x);
	}
	dfs(1);
	while(m--)
	{
		op=getint(),x=getint();
		if(op==2)c[x]=getint();
		else
		{
			ans=0;
			l=getint(),r=getint();
			if(t)x^=lastans,l^=lastans,r^=lastans;
			for(int i=l;i<=r;i++)cnt[i]=0;
			solve(x,l,r);
			printf("%d\n",ans);
			lastans=ans;
		}
	}
	return 0;
}
