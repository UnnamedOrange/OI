#include <cctype>
#include <cstdio>

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;
}

int type,n,tc;

int main()
{
    type=get(),n=get(),tc=get();
    while (tc--)
        if (type==1)
        {
            int x=get(),y=get(),t=x^y,h=0;
            for (; !((t>>h)&1); ++h);
            h=(h<<1|((x>>h)&1))+1;
            printf("%d\n",h);
        }
        else
        {
            int q=get(),h=get()-1;
            puts(((q>>(h>>1))&1)==(h&1)? "yes":"no");
        }
    return 0;
}
