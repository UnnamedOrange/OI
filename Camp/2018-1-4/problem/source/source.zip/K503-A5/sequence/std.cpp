#include <bits/stdc++.h>
using namespace std;
const int inf(233333333);
int n, ans, a[50];
bool check() {
	for (int i=1;i<=n;i++) {
		if (a[i]!=i) return false;
	}
	return true;
}
void dfs(int dep) {
	if (dep>=ans) return;
	/*cout << dep << endl;
	for (int i=1;i<=n;i++) cout << a[i] << " ";
	cout << endl;*/
	if (check()) {
		ans=min(ans,dep);
		return;
	}
	if (dep>=2*n-2) return;
	for (int i=2;i<=n;i++) {
		//if (a[i]!=i && ((a[i]>a[1]) || (a[i]<a[1] && a[1]==i))) {
			reverse(a+1,a+i+1);
			dfs(dep+1);
			reverse(a+1,a+i+1);	
		//}
	}
}
void work() {
	cin >> n;
	for (int i=1;i<=n;i++) 
		cin >> a[i];
	ans=inf;
	dfs(1);
	cout << ans-1 << endl;
}
int main() {
	freopen("sequence.in","r",stdin);
	freopen("std.out","w",stdout);
	ios::sync_with_stdio(false);
	int T;
	cin >> T;
	while (T--) work();
	return 0;
}
