#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

namespace Nan_Ti
{
	const int N=26;
	int s[N];
	int n,ans;
	int lim;
	void dfs(int cost)
	{
		int val=0;
		for(int i=2;i<=n;i++)
			if(s[i]!=s[i-1]+1 && s[i]!=s[i-1]-1)val++;
		if(cost+val>lim)return;

		if(!val){ans=1;return;}

		for(int i=1;i<=n;i++)
		{
			std::reverse(s+1,s+i+1);
			dfs(cost+1);
			std::reverse(s+1,s+i+1);

			if(ans)return;
		}
	}
	void solve()
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&s[i]);
//		ans=n*2;dfs(0);

		for(lim=0;lim<=n*2;lim++)
		{
			ans=0;
			dfs(0);
			if(ans)break;
		}
			
		printf("%d\n",lim);
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int T;
	for(scanf("%d",&T);T--;Nan_Ti::solve());

//	fprintf(stderr,"ida* time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
