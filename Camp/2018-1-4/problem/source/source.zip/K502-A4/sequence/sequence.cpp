#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<< " = "<<(x)<<" "
#define debug(x) cerr<<#x<< " = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=26;

int a[N],POS,n,fac[N],T;
int arr[N][N];
int que[363000],dis[363000];
struct P_1{
	int into_num(int *a){
		static int res,cnt,i,j;
		for(i=res=0;i<n;++i){
			for(cnt=0,j=i;j<n;++j)
				cnt+=a[j]<a[i];
			res+=fac[n-i-1]*cnt;
		}
		return res+1;
	}
	void into_a(int res,int *a){
		static int i,j,mark[10],lst;
		memset(mark,0,sizeof mark);
		for(--res,i=0;i<n;++i){
			lst=res/fac[n-i-1];res-=fac[n-i-1]*lst;
			for(j=0;j<n;++j)if(!mark[j]){
				if(!lst){mark[j]=1;a[i]=j;break;}
				--lst;
			}
		}
	}
	void init(){
		if(n==POS)return ;
		fac[0]=1;
		rep(i,1,n+1)fac[i]=fac[i-1]*i;
		POS=n;
		rep(i,0,n)a[i]=i;
		memset(dis,-1,sizeof dis);
		int l=0,r=0,b[10],x,i,j,k,y;
		que[r++]=1;dis[1]=0;
		while(l<r){
			x=que[l++];
			into_a(x,a);
			for(i=1;i<n;++i){
				memcpy(b,a,n<<2);
				for(j=0,k=i;j<k;++j,--k)swap(b[j],b[k]);
				y=into_num(b);
				if(dis[y]==-1)dis[y]=dis[x]+1,que[r++]=y;
			}
		}
	}
	void solve(){
		rep(t,0,T){
			n=arr[t][0];
			init();
			rep(i,0,n)a[i]=arr[t][i+1],--a[i];
			ptn(dis[into_num(a)]);
		}
	}
}P1;
struct P_2{
	int ans;
	int mark[N][N];
	int dis(int *a){
		int res=0;
		for(int i=1;i<=n;++i)res+=mark[a[i-1]][a[i]]+mark[a[i]][a[i+1]];
		return res>>1;
	}
	void dfs(int *a,int nowres){
		int b[N],i;
		for(i=1;i<=n;++i)if(a[i]!=i)break;
		if(i>n){
			Min(ans,nowres);
			return ;
		} 
		memcpy(b,a,sizeof b);
		if(dis(b)+nowres>=ans)return ;
		int x,y;
		for(i=1;i<=n;++i){
			memcpy(b,a,sizeof b);
			for(x=1,y=i;x<y;++x,--y)swap(b[x],b[y]);
			dfs(b,nowres+1);
		}
	}
	void solve(){
		int b[N];
		a[0]=a[n+1]=0;
		memset(mark,0,sizeof mark);
		rep(i,0,n+1)rep(j,0,n+1)mark[i][j]=!(abs(i-j)<=1||!i||!j);
		memcpy(b,a,sizeof b);
		ans=2*n;
		dfs(a,0);
		ptn(ans);
	}
	void work(){
		rep(t,0,T){
			n=arr[t][0];
			rep(i,1,n+1)a[i]=arr[t][i];
			solve();
		}
	}
}P2;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int mx=0;rd(T);
	rep(i,0,T){
		rd(arr[i][0]);
		Max(mx,arr[i][0]);
		rep(j,1,arr[i][0]+1)rd(arr[i][j]);
	}
	if(0);
	else if(mx<=9)P1.solve();
	else P2.work();
	return 0;
}
