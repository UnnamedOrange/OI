#include <stdio.h>
int t,n,m,i,j,x,y,k;
int main()
{
	scanf("%d%d%d",&t,&n,&m);
	for (i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		if (t==1)
			for (j=1;;j++)
			{
				if ((x&1)!=(y&1))
				{
					printf("%d\n",j*2-(x&1));
					break;
				}
				x=(x>>1);
				y=(y>>1);
			}
		else if (((x>>((y-1)>>1))&1)==(y&1)) printf("yes\n");
			else printf("no\n");
	}
}
