#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;
int n, m;
int flag = 0;
int K;
int len;
const int MAXN = 5e4 + 10;
int A[MAXN], B[MAXN];
int status[MAXN];
long long ans = 0;
bool judge()
{
	int k = 1;
	for(int i = 1; i <= n; i++) {
		if(A[i] == status[k]) {
			k++;
		}
	}
	if(k == len + 1) {
		return false;
	}
	k = 1;
	for(int i = 1; i <= m; i++) {
		if(B[i] == status[k]) {
			k++;
		}
	}
	if(k == len + 1) {
		return false;	
	}
	return true;
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

void open()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}

void DFS(int x)
{
	if(flag) 
		return;
	if(x == len + 1) {
		if(judge()) {
			flag = 1;
			return ;
		}
		return;
	}
	status[x] = 1;
	DFS(x + 1);
	status[x] = 2;
	DFS(x + 1);
}
int main()
{
	open();
	n = read(), m = read(), K  = read();
	for(int i = 1; i <= n; i++) {
		A[i] = read();
	}
	for(int i = 1; i <= m; i++) {
		B[i] = read();
	}
	for(len = 1; len <= n + m; len++) {
		DFS(1);
		if(flag) {
			ans = len;
			break;
		}
	}
	printf("%d\n", ans);
	close();
}
