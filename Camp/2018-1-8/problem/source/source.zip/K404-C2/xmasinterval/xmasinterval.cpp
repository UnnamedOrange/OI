#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cctype>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define mid (l+r>>1)
#define lch (rt<<1)
#define rch (rt<<1|1)

using namespace std;
typedef long long LL;
const int N=500005,mod=1000000009;
int n,m,ans,p[N],cur[N<<2],t[N<<2],ql,qr,x,y;
struct data{int l,r;} dat[N];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

int findl(int x)
{
	int l=1,r=m;
	while(l<=r)
		p[mid]>=x?r=mid-1:l=mid+1;
	return r+1;
}

int findr(int x)
{
	int l=1,r=m;
	while(l<=r)
		p[mid]<=x?l=mid+1:r=mid-1;
	return l-1;
}

bool cmp(data a,data b)
{
	return a.l==b.l?a.r<b.r:a.l<b.l;
}

void build(int l,int r,int rt)
{
	if(cur[rt]=1,l==r) return;
	build(l,mid,lch),build(mid+1,r,rch);
}

void turn(int rt,int x)
{
	cur[rt]=(LL)cur[rt]*x%mod;
	t[rt]=(LL)t[rt]*x%mod;
}

void pushdown(int rt)
{
	if(cur[rt]!=1)
	{
		turn(lch,cur[rt]);
		turn(rch,cur[rt]);
		cur[rt]=1;
	}
}

void insert(int l,int r,int rt)
{
	if(l==r)
	{
		t[rt]=(t[rt]+y)%mod;
		return;
	}
	pushdown(rt);
	if(x<=mid) insert(l,mid,lch);
	else insert(mid+1,r,rch);
	t[rt]=(t[lch]+t[rch])%mod;
}

void modify(int l,int r,int rt)
{
	if(ql<=l && r<=qr)
	{
		turn(rt,y);
		return;
	}
	pushdown(rt);
	if(ql<=mid) modify(l,mid,lch);
	if(mid<qr) modify(mid+1,r,rch);
	t[rt]=(t[lch]+t[rch])%mod;
}

int query(int l,int r,int rt)
{
	if(ql<=l && r<=qr) return t[rt];
	pushdown(rt);
	if(qr<=mid) return query(l,mid,lch);
	if(mid<ql) return query(mid+1,r,rch);
	return (query(l,mid,lch)+query(mid+1,r,rch))%mod;
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=getint(),m=getint(),build(0,m,1),ans=1;
	rep(i,1,n) dat[i].l=getint(),dat[i].r=getint();
	rep(i,1,m) p[i]=getint();
	sort(p+1,p+1+m);
	rep(i,1,n) dat[i].l=findl(dat[i].l),dat[i].r=findr(dat[i].r);
	sort(dat+1,dat+1+n,cmp),x=0,y=1,insert(0,m,1);
	rep(i,1,n)
	{
		if(dat[i].l>dat[i].r) {ans=ans*2%mod; continue;}
		ql=dat[i].r,qr=m,y=2,modify(0,m,1);
		ql=dat[i].l-1,qr=dat[i].r-1,x=dat[i].r,y=query(0,m,1),insert(0,m,1);
	}
	ql=qr=m,printf("%d\n",(LL)query(0,m,1)*ans%mod);
	return 0;
}
