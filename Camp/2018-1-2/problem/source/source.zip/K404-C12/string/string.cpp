#include <iostream>
#include <cstdio>
using namespace std; 
char str[100005]; 
int main()
{
	freopen("string.in", "r", stdin); 
	freopen("string.out", "wt", stdout); 
	int t; 
	scanf("%d", &t); 
	while (t--)
	{
		int n; 
		scanf("%d%s", &n, str); 
		bool f = true; 
		for (int i = 0; i < n; i++)
			f &= str[i] == str[n - i - 1]; 
		if (!f)
		{
			puts("1"); 
			continue; 
		}
		f = true; 
		for (int i = 0; i < n; i++)
			f &= str[i] == str[i & 1]; 
		if (f)
			puts("-1"); 
		else
			puts("2"); 
	}
	return 0; 
}

