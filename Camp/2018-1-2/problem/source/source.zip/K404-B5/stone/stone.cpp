#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

#define AL 0
#define BO 1
#define FI 2
#define SE 3

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 100007;
const int MOD = 1e9 + 7;

int n, A, B, AB;
int a[MAXN];
int tp[MAXN];
int rem[MAXN];
int p2[MAXN];
int ans[4];
int dp[MAXN][2];
int tma[MAXN];



void init ();
void input ();
void work ();

int add ( int x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
	return x;
}

void addv ( int &x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
}

int dec ( int x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
	return x;
}

void decv ( int &x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
}



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "stone" );
	
	p2[0] = 1;
	lp ( i, 1, MAXN ) p2[i] = add ( p2[i-1], p2[i-1] );
}

void input ()
{
	scanf ( "%d%d%d", &n, &A, &B );
	lpi ( i, 1, n ) scanf ( "%d", &a[i] );
}

void work ()
{
	bool swf = false;
	if ( A > B ) swf = true, swap ( A, B );
	
	AB = A + B;
	int x, tx, c1 = 0, c2 = 0, cb = 0;
	lpi ( i, 1, n ){
		x = a[i] % AB;
		if ( x >= B ){
			rem[i] = 1, tma[i] = x / A;
			if ( tma[i] > 1 ) ++cb;
		}else if ( x < A ) rem[i] = 0;
		else tp[i] = 1, ++c1;
		if ( x + AB <= a[i] ){
			tx = ( x + AB - A ) % AB;
			if ( tx >= A && tx < B ) tp[i] = 2, ++c2;
		}
	}
	
	addv ( ans[AL], SC ( int, SC ( LL, dec ( p2[c1], 1 ) ) * p2[n-c1] % MOD ) );
	addv ( ans[AL], SC ( int, SC ( LL, dec ( p2[c2], c2+1 ) ) * p2[n-c1-c2] % MOD ) );
	
	dp[0][0] = 1;
	lpi ( i, 1, n ){
		if ( !tp[i] && tma[i] == 1 ){
			dp[i][0] = add ( dp[i-1][0], dp[i-1][rem[i]] );
			dp[i][1] = add ( dp[i-1][1], dp[i-1][rem[i]^1] );
		}else{
			dp[i][0] = dp[i-1][0];
			dp[i][1] = dp[i-1][1];
		}
	}
	
	lpi ( i, 1, n ){
		if ( tp[i] == 2 ){
			addv ( ans[AL], dp[n][rem[i]] );
			addv ( ans[FI], dp[n][rem[i]^1] );
		}
	}
	
	addv ( ans[AL], SC ( int, SC ( LL, dec ( p2[cb], cb+1 ) ) * p2[n-c1-cb] % MOD ) );
	lpi ( i, 1, n ){
		if ( !tp[i] && tma[i] > 1 ){
			addv ( ans[AL], dp[n][1] );
			addv ( ans[FI], dp[n][0] );
		}
	}
	
//	lpi ( i, 1, n ){
//		cerr << tp[i] << " " << rem[i] << endl;
//	}
//	cerr << dp[n][0] << " " << dp[n][1] << endl;
	
	addv ( ans[SE], dp[n][0] );
	addv ( ans[FI], dp[n][1] );
	
	if ( swf ) swap ( ans[AL], ans[BO] );
	
	lp ( i, 0, 4 ) cout << ans[i] << " ";
	cout << endl;
}
