#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int Mod=1e9;

int main(){
	srand(time(0));
	freopen("xmasinterval.in","w",stdout);
	int n=rand()%20+1,m=rand()%20+1;
	printf("%d %d \n",n,m);
	For(i,1,n){
		int l=rand()%Mod+1,r=rand()%Mod+1;
		if(l>r)swap(l,r);
		printf("%d %d\n",l,r);
	}
	For(i,1,m){
		printf("%d \n",rand()%Mod+1);
	}
}
