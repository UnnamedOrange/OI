#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=1000010,lim=1000000;
int n,mn[N];
LL s1[N],s2[N],miu[N],d0[N];
void work(){
	scanf("%d",&n);
	int l=1,r,k1;//,k2;
	LL ans=0;
	while (l<=n){
		k1=n/l,r=n/k1;//,k2=n/(r+1);
		ans+=(s1[r]-s1[l-1])*s2[k1];//(s2[k1]-s2[k2]);
		l=r+1;
	}
//	rep(i,1,n) rep(j,1,n/i) ans+=miu[i]*d0[j];
	printf("%lld\n",ans);
}
void init(){
	memset(mn,0x3f,sizeof(mn));
	rep(i,2,lim){
		for (int j=i;j<=lim;j+=i) mn[j]=min(mn[j],i);
	}
	miu[1]=d0[1]=1;
	rep(i,2,lim){
		int tp=i,ai=0;
		while (tp%mn[i]==0) tp/=mn[i],++ai;
		miu[i]=miu[tp]*(ai>1?0:ai?-1:1);
		d0[i]=d0[tp]*(ai+1)*(ai+1);
	}
	rep(i,1,lim) s1[i]=s1[i-1]+miu[i],s2[i]=s2[i-1]+d0[i];
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int tc;
	scanf("%d",&tc);
	init();
	while (tc--) work();
	return 0;
}

