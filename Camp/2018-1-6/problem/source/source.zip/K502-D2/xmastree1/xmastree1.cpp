#include <queue>
#include <cstdio>
#include <bitset>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int mod = 998244353;
const int N = 100000 + 1000;

int n, q, t;
int F[N], v[N << 1], nex[N << 1], EID = 1;
int dfn[N], ndfn[N], tot = 0, siz[N], c[N];
int ty, u, l, r;
bool vis[5010];

namespace file{
	inline void open()
	{
		freopen("xmastree1.in", "r", stdin);
		freopen("xmastree1.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}

namespace input{
	inline int read()
	{
		int a = 0;
		char ch;
		int f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}
	
	inline void add(int f, int t)
	{
		nex[EID] = F[f];
		v[EID] = t;
		F[f] = EID++;
	}
	
	inline void dfs(int x, int fa)
	{
		dfn[++tot] = x;
		ndfn[x] = tot;
		siz[x] = 1;
		for(int i = F[x];i;i = nex[i])
		{
			int t = v[i];
			if(t == fa)
				continue;
			dfs(t, x);
			siz[x] += siz[t];
		}
	}
	
	inline void Get()
	{
		n = read(), q = read(), t = read();
		for(int i = 1;i <= n;++i)
			c[i] = read();
		for(int i = 1;i < n;++i)
		{
			int f = read(), t = read();
			add(f, t);
			add(t, f);
		}
		dfs(1, 0);
	}
}

namespace force{
	inline void solve()
	{
		int ans = 0;
		for(int i = 1;i <= q;++i)
		{
			ty = input::read();
			if(ty == 1)
			{
				memset(vis, 0, sizeof vis);
				u = input::read(), l = input::read(), r = input::read();
				if(t)
					u ^= ans, l ^= ans, r ^= ans;
				int cur = 0;
				for(int j = ndfn[u];j < ndfn[u] + siz[u];++j)
				{
					if(c[dfn[j]] >= l && c[dfn[j]] <= r && !vis[c[dfn[j]]])
						++cur, vis[c[dfn[j]]] = 1;
				}
				printf("%d\n", ans = cur);
			}
			else
			{
				u = input::read(), l = input::read();
				if(t)
					u ^= ans, l ^= ans;
				c[u] = l;
			}
		}
	}
}

namespace check{
	inline void deter()
	{
		if(n <= 5000)
			force::solve();
	}
}

int main()
{
	file::open();
	input::Get();
	check::deter();
	file::close();
}
/*
5 5 1
4 1 1 5 4
5 1
3 5
2 3
4 3
2 5 4
2 2 2
1 3 1 5
2 1 2
1 1 2 7
*/
