//by yjz
#include<bits/stdc++.h>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=998244353;
ll qpow(ll x,ll k){return k==0?1:qpow(x*x%mod,k>>1)*(k&1?x:1)%mod;}
int n,m,K;
int pwk[100111];
void upd(int &x,int v){x=x+v>=mod?x+v-mod:x+v;}
vector<vector<int> > dp[100111];
vector<vector<int> > sum[100111];

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	cin>>n>>m>>K;
	if(n>=m)
	{
		puts("0");
		return 0;
	}
	int ans=0;
	for(int i=0;i<=n;i++)pwk[i]=qpow(i,K);
	
	vector<int> tv;
	for(int i=0;i<=n+2;i++)tv.PB(0);
	for(int i=0;i<=m;i++)
	{
		for(int j=0;j<=n+1;j++)dp[i].PB(tv),sum[i].PB(tv);
	}
	dp[0][0][0]=1;
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<=n;j++)
		{
			for(int k=0;k<=j;k++)
			{
				int &cur=dp[i][j][k];
				if(!cur)continue;
//				cerr<<i<<","<<j<<","<<k<<" "<<cur<<" "<<sum[i][j][k]<<endl;
				upd(dp[i+1][j][k],cur);
				upd(sum[i+1][j][k],(sum[i][j][k]+1ll*pwk[k]*cur)%mod);
				
				upd(dp[i+1][j+1][k+1],cur);
				upd(sum[i+1][j+1][k+1],(sum[i][j][k]+1ll*pwk[k+1]*cur)%mod);
				
				upd(dp[i+1][j+1][k],cur);
				upd(sum[i+1][j+1][k],(sum[i][j][k]+1ll*pwk[k]*cur)%mod);
				
				
				if(k>0)
				{
					upd(dp[i+1][j][k-1],cur);
					upd(sum[i+1][j][k-1],(sum[i][j][k]+1ll*pwk[k-1]*cur)%mod);
				}
			}
		}
	}
	cout<<sum[m][n][0]<<endl;

	return 0;
}
