#include<cstdio> 
using namespace std;
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	if(n==k){printf("2\n"); return 0;}
	else printf("0\n");
	return 0;
}
