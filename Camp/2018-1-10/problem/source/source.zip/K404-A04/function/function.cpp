#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
const int maxn=1000010;
ll f[maxn];
int n,pri[maxn],ci[maxn],num;
bool flag[maxn];
void getpri(int n)
{
	memset(flag,1,sizeof(flag));
	flag[1]=0;f[1]=1;
	for(int i=2;i<=n;i++)
	{
		if(flag[i]) pri[++num]=i,ci[i]=1,f[i]=3;
		for(int j=1;j<=num&&i*pri[j]<=n;j++)
		{
			int v=i*pri[j];ci[v]=1;flag[v]=0;
			if(i%pri[j]==0) {ci[v]+=ci[i],f[v]=f[i]*(ci[v]*2+1)/(ci[v]*2-1);break;}
			f[v]=f[i]*3;
		}
 	}
}
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int ca;
	scanf("%d",&ca);
	getpri(1000000);
//	for(int i=1;i<=60;i++)
//		cout<<pri[i]<<' ';
//	cout<<endl;	
	for(int i=1;i<=1000000;i++)
		f[i]+=f[i-1];
	while(ca--)
	{
		scanf("%d",&n);
		printf("%lld\n",f[n]);
	}
	return 0;
}
