#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int mod=998244353;
int ans;int n,m;

int power(int x,int y){
	int ret=1;
	for(;y;y>>=1,x=1ll*x*x%mod){
		if(y&1)	ret=1ll*ret*x%mod;
	}
	return ret;
}

int main(){
	int i;
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==3){
		ans=1;
		rep(i,1,n)	ans=1ll*ans*i%mod;
		ans=(power(2,1ll*n*(n-1)/2%(mod-1))-ans)%mod;
		printf("%d\n",ans);
		return 0;
	}
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
