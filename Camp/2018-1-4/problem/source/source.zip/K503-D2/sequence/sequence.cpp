#include<bits/stdc++.h>
using namespace std;
int t,sum,a[40],n,pp;
bool dfs(int x,int last,int dep){
	if (x==0) return true;
	int b[30],q;
	for (int i=1;i<=n+1;i++) b[i]=a[i];
	for (int i=2;i<=n;i++)
		if (i!=last){
			q=x;
			q=q+(abs(a[1]-a[i+1])>1)-(abs(a[i]-a[i+1])>1);
			if (dep+q>pp) continue;
			for (int j=1;j<=i;j++)a[j]=b[i-j+1];
			for (int j=i+1;j<=n;j++)a[j]=b[j];
			if (dfs(q,i,dep+1)) return true;
		}
	for (int i=1;i<=n+1;i++) a[i]=b[i];
	return false;
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&t);
	while (t--){
		scanf("%d",&n);
		for (int i=1;i<=n;i++)scanf("%d",&a[i]);
		a[n+1]=n+1;
		sum=0;
		for (int i=1;i<=n;i++)if (abs(a[i]-a[i+1])>1) sum++;
		for (pp=sum;pp<=2*n-2;pp++)
			if (dfs(pp,0,1)){
				cout<<pp<<endl;
				break;
			}
	}
}
