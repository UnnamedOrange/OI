#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e6+5,mod=1000000007;
void add_mod(int &a,int b){if((a+=b)>=mod)a-=mod;}
int n,c[N],d[N];
struct P_0{
	int dp[2005],cnt[2005];
	void work(){
		memset(dp,-1,sizeof dp);
		cnt[0]=1;
		dp[0]=0;
		rep(i,0,n)if(~dp[i]){
			for(int mi=i,mx=n,j=i+1;mi<=mx&&j<=mx;++j){
				Max(mi,i+c[j]);
				Min(mx,i+d[j]);
				if(mi<=j&&j<=mx){
					if(dp[j]<dp[i]+1)dp[j]=dp[i]+1,cnt[j]=0;
					if(dp[j]==dp[i]+1)add_mod(cnt[j],cnt[i]);
				}
			}
		}
		if(!~dp[n])ptn(-1);
		else ptk(dp[n]),ptn(cnt[n]);
	}
}P0;
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	rd(n);
	rep(i,1,n+1)rd(c[i]),rd(d[i]);
	if(n<=2000)P0.work();
	return 0;
}
