#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=200010,P=998244353,K=510;
void upd(int &x,int y){x=(x+y)%P;}
int n,m,k,tot,h,t,q[N],ft[N],deg[N];
struct edge{int t,n;}E[N];
int f[N][K],strl[K][K];
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	rep(i,1,m){
		int x,y;
		scanf("%d%d",&x,&y);
		E[++tot]=(edge){y,ft[x]},ft[x]=tot;
		++deg[y];
	}
	q[h=t=1]=1;
	f[1][0]=1;
	while (h<=t){
		int u=q[h++];
		go(u){
			if (!--deg[v]) q[++t]=v;
			rep(i,0,k) upd(f[v][i],f[u][i]);
			rep(i,0,k-1) upd(f[v][i+1],(LL)f[u][i]*(i+1)%P);
		}
	}
	strl[0][0]=1;
	rep(i,1,k) rep(j,1,i) strl[i][j]=((LL)strl[i-1][j-1]+(LL)strl[i-1][j]*j)%P;
	rep(i,1,n){
		int ans=0;
		rep(j,0,k) upd(ans,(LL)f[i][j]*strl[k][j]%P);
		ans=(ans+P)%P;
		printf("%d\n",ans);
	}
	return 0;
}

