#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 1000007;

struct eT
{
	void setd ( int _u, int _v, int _l )
	{
		u = _u, v = _v, last = _l;
	}
	
	int u, v, last;
}edge[MAXN];

int n, m;
int eu[MAXN], ev[MAXN];
int ke, la[MAXN];
int pre[MAXN], kp, low[MAXN], stk[MAXN], top, scno[MAXN], scsz[MAXN], scc;
bool ins[MAXN];
int w[MAXN];
int dp[MAXN];



void init ();
void input ();
void work ();

void tarjan ( int now );
int dfs ( int now );



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "bomb" );
}

void input ()
{
	scanf ( "%d%d", &n, &m );
	int u, v;
	ke = 0;
	INIT ( la, -1 );
	lp ( i, 0, m ){
		scanf ( "%d%d", &u, &v );
		eu[i] = u, ev[i] = v;
		edge[ke].setd ( u, v, la[u] );
		la[u] = ke++;
	}
}

void work ()
{
	INIT ( pre, -1 );
	INIT ( low, -1 );
	lpi ( i, 1, n ) if ( pre[i] == -1 ) tarjan ( i );
	
	ke = 0;
	INIT ( la, -1 );
	int u, v;
	lp ( i, 0, m ){
		u = scno[eu[i]], v = scno[ev[i]];
		if ( u ^ v ){
			edge[ke].setd ( u, v, la[u] );
			la[u] = ke++;
		}
	}
	lpi ( i, 1, scc ) w[i] = scsz[i];
	
	INIT ( dp, -1 );
	lpi ( i, 1, scc ){
		if ( dp[i] == -1 ) dfs ( i );
	}
	
	int ans = 0;
	lpi ( i, 1, scc ) ans = qmax ( ans, dp[i] );
	
	printf ( "%d\n", ans );
}



void tarjan ( int now )
{
	pre[now] = low[now] = ++kp;
	stk[top++] = now;
	ins[now] = true;
	
	int v;
	for ( int i = la[now]; ~i; i = edge[i].last ){
		v = edge[i].v;
		if ( pre[v] == -1 ){
			tarjan ( v );
			low[now] = qmin ( low[now], low[v] );
		}else if ( ins[v] ){
			low[now] = qmin ( low[now], pre[v] );
		}
	}
	
	if ( low[now] == pre[now] ){
		++scc;
		while ( stk[top] ^ now ){
			--top;
			scno[stk[top]] = scc;
			ins[stk[top]] = false;
			++scsz[scc];
		}
	}
}

int dfs ( int now )
{
	if ( ~dp[now] ) return dp[now];
	
	int ans = 0;
	for ( int i = la[now]; ~i; i = edge[i].last ) ans = qmax ( ans, dfs ( edge[i].v ) );
	
	dp[now] = ans + w[now];
	return dp[now];
}
