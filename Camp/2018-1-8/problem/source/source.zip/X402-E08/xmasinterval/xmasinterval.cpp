/*
Author: CNYALI_LK
LANG: C++
PROG: xmasinterval.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
int l[55],r[55],x[55],c[55];
int fup(int s,int l,int r){
	int mid=0;
	while(l<=r){
		mid=(l+r)>>1;
		if(x[mid]>=s)r=mid-1;
		else l=mid+1;
	}
	return r+1;
}
int fdn(int s,int l,int r){
	int mid=0;
	while(l<=r){
		mid=(l+r)>>1;
		if(x[mid]>s)r=mid-1;
		else l=mid+1;
	}
	return l-1;
}


int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	int n,m;
	n=read();m=read();
	for(int i=1;i<=n;++i){
		l[i]=read();r[i]=read();	
	}
	for(int i=1;i<=m;++i)x[i]=read();
	sort(x+1,x+m+1);
	for(int i=1;i<=n;++i){
		l[i]=fup(l[i],1,m);
		r[i]=fdn(r[i],1,m);
	}
	int t=1<<n;
	int cnt=0;
	for(int i=0;i<t;++i){
		for(int j=0;j<=m;++j)c[j]=0;
		for(int j=0;j<n;++j)if(i&(1<<j)){
			++c[l[j+1]]	;
			--c[r[j+1]+1];
		}
		++cnt;
		for(int j=1;j<=m;++j){c[j]+=c[j-1];if(!c[j]){--cnt;break;}}
	}
	write(cnt,'\n');
	return 0;
}

