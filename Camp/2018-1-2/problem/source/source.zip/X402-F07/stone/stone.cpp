#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005,mod=1e9+7;
int n,a[maxn],c[maxn],x,y;
int fac[maxn],ifac[maxn];
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1)res=1ll*res*x%mod;
		x=1ll*x*x%mod,y>>=1;
	}return res;
}
void init(){
	fac[0]=1;
	REP(i,1,n)fac[i]=1ll*fac[i-1]*i%mod;
	ifac[n]=ksm(fac[n],mod-2);
	DREP(i,n,1)ifac[i-1]=1ll*ifac[i]*i%mod;
}
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
#endif
	bool flag=0;
	n=read(),x=read(),y=read();
	if(x>y)swap(x,y),flag=1;
	REP(i,1,n)a[i]=read();
	REP(i,1,n){
		int f=0;
		if(a[i]%(x+y)>=y){
			f=1;
			if(a[i]%(x+y)>=2*x)f=3;
		}else if(a[i]%(x+y)<x)f=2;
		c[f]++;
	}
	int ans0=0,ans1=0,ans2=0;
	if(c[1])ans1=ans2=ksm(2,c[1]+c[2]-1);
	else ans2=ksm(2,c[2]);
	add(ans1,1ll*c[3]*ksm(2,c[2]+max(0,c[1]-1))%mod);
	ans0=(ksm(2,n)+mod-(ans1+ans2)%mod)%mod;
	if(flag)printf("0 %d %d %d\n",ans0,ans1,ans2);
	else printf("%d 0 %d %d\n",ans0,ans1,ans2);
	return 0;
}
