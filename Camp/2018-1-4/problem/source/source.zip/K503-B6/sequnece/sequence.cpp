#include<algorithm>
#include<iostream>
#include<cstring>
#include<cctype>
#include<cstdio>
#include<string>
#define rep(i,x,y) for(register int i = x;i <= y; ++ i)
#define repd(i,x,y) for(register int i = x;i >= y; -- i)
using namespace std;
typedef long long ll;
template<typename T>inline void read(T&x)
{
	x = 0; char c;int sign = 1;
	do { c = getchar(); if(c == '-') sign = -1; }while(!isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar() ; }while(isdigit(c));
	x *= sign;
}

inline void init(string name)
{
	string in = name + ".in",out = name + ".out";
	freopen(in.c_str(),"r",stdin);
	freopen(out.c_str(),"w",stdout);
}

const int N = 27;
int T,n,ans;

void dfs(int r,int a[],int z)
{
	if(z >= ans) return;
	while(a[r] == r) --r;
	if(r <= 1) return (void(ans = min(ans,z)));
	int x,y;
	rep(i,1,r) if(a[i] == r) { x = y = i; break; }
	if(x == 1)
	{
		rep(i,1,r >> 1)
			swap(a[i],a[r - i + 1]);
		return void(dfs(r - 1,a,z + 1));
	}
	
	bool e = 0;
	while(a[y + 1] == a[y] - 1) ++y,e = 1;
	
	int now[N];
	if(!e && a[x - 1] == a[x] - 1)
	{
		int cnt = 0,R = r;
		repd(i,x,1)
			now[R--] = a[i];
		repd(i,r,x + 1)
			now[++cnt] = a[i];
		
		dfs(r - 2,now,z + 2);
		
		return ;
	}
	rep(j,y,r)
	{
		rep(i,0,j - x)
			now[r - i] = a[x + i];
		int cnt = 0;
		rep(i,j + 1,r) now[++cnt] = a[i];
		rep(i,1,x - 1) now[++cnt] = a[i];
		
		dfs(r - 1,now,z + e + 2);
	}
}

void solve()
{
	ans = 1e9 + 7;
	read(n);
	int a[N];
	rep(i,1,n) read(a[i]);
	a[n + 1] = -1;
	
	dfs(n,a,0);
	
	printf("%d\n",ans);
}

int main()
{
	init("sequence");
	read(T);
	while(T--)
		solve();
	return 0;
}
