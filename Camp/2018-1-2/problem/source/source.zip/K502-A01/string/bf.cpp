#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
char S[100000 + 100];
char S1[100000 + 100];
int N;
inline int Check(int x, int y)
{
	int fl = 0;
	for (int i = x; i <= y; ++i)
		if (S[i] != S[y - i + x])
		{
			fl = 1;
			break;
		}
	if (!fl) return 0;
	int cnt = 0;
	for (int i = 1; i <= N; ++i)
		if (i < x || i > y)
			S1[++cnt] = S[i];
	fl = 0;
	for (int i = 1; i <= cnt; ++i)
		if (S1[i] != S1[cnt - i + 1])
		{
			fl = 1;
			break;
		}
	if (!fl) return 0;
	return 1;
}
int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d", &N);
		scanf("%s", S + 1);
		int fl = 0;
		for (int i = 1; i <= (N / 2); ++i)
			if (S[i] != S[N - i + 1])
			{
				fl = 1;
				break;
			}
		if (fl)
		{
			cout<<"1"<<endl;
			continue;
		}
		fl = 0;
		for (int i = 1; i < (N); ++i)
		{
			for (int j = i + 1 ; j <= N; ++j)
			{
				if (Check(i, j))
				{
					fl = 1;
					break;
				}
			}
			if (fl) break;
		}
		if (fl) cout<<"2"<<endl;
		else cout<<"-1"<<endl;
	}
	return 0;
}
