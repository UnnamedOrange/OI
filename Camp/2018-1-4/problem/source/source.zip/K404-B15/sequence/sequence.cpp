#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
int Refun;
int a[50];
int t,n;

inline void Rever(int x,int y)
{
	while (x<y)
	{
		swap(a[x],a[y]);
		++x;
		--y;
	}
}

inline bool check()
{
	for (int i=1;i<=n;++i)
		if (a[i]!=i) return false;
	return true;
}

void Dfs(int step,int need)
{
	if (step>n) return;
	if (step+need>=Refun) return;
	if (check())
		Refun=min(Refun,step);
	else
	{
		for (int i=2; i<=n; ++i)
		{
			int hh=need;
			if (i<n && abs(a[1]-a[i+1])>1)++hh;
			if (i<n && abs(a[i]-a[i+1])>1)--hh;
			Rever(1,i);
			Dfs(step+1,hh);
			Rever(1,i);
		}
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d",&n);
		Refun=n;
		for (int i=1; i<=n; ++i)
			scanf("%d",&a[i]);
		int sum=0;
		for (int i=1;i<=n-1;++i)
			if (abs(a[i]-a[i+1])>1)
				++sum;
		Dfs(0,sum);
		printf("%d\n",Refun);
	}
	return 0;
}
/*
1
20
17 1 19 18 16 9 11 4 13 5 12 14 15 2 3 6 8 7 10 20
*/
