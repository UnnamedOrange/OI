#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define F first
#define S second
#define PII pair<int, int>
const int INF = 0x3f3f3f3f;
using namespace std;
const int MAXN = 100010;
const LL p = 1000000007LL;
const int c = 27;
int T;
int n;
char s[MAXN];
LL h1[MAXN], h2[MAXN], pc[MAXN];
LL geth(LL *h, int l, int r){
	return (h[r] - h[l - 1] * pc[r - l + 1] % p + p) % p;
}
LL q1(int l, int r){
	return geth(h1, l, r);
}
LL q2(int l, int r){
	return geth(h2, n - r + 1, n - l + 1);
}

int main(){
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &T);
	pc[0] = 1;
	for(int i = 1; i <= 100000; i++) pc[i] = pc[i - 1] * c % p;
	while(T--){
		scanf("%d", &n);
		scanf("%s", s + 1);
		h1[0] = h2[0] = h1[n + 1] = h2[n + 1] = 0;
		for(int i = 1; i <= n; i++) h1[i] = (h1[i - 1] * c + (s[i] - 'a' + 1)) % p;
		for(int i = 1; i <= n; i++) h2[i] = (h2[i - 1] * c + (s[n - i + 1] - 'a' + 1)) % p;
		if(q1(1, n) != q2(1, n)){
			puts("1");
			continue;
		}
		bool flag = false;
		for(int i = 1; i < n; i++){
			if(s[i] != s[i + 1]){
				if(i - 1 <= n - i - 1){
					if(q1(1, i - 1) != q2(n - i + 2 ,n) || q1(i + 2, n - i + 1) != q2(i + 2, n - i + 1)){
						puts("2");
						flag = true;
						break;
					}
				}
				else{
					if(q1(1, n - i - 1) != q2(i + 2 ,n) || q1(n - i, i - 1) != q2(n - i, i - 1)){
						puts("2");
						flag = true;
						break;
					}
				}
			}
		}
		if(!flag) puts("-1");
	}
	return 0;
}
