#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<set>
#define N 200010
using namespace std;
typedef long long LL;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x;
}
int to[N<<1],nxt[N<<1],head[N],tot;
void add(int a,int b){to[++tot]=b,nxt[tot]=head[a],head[a]=tot;}
int n,Q,T,c[N];
int vis[N],ans,Tim;
int f[N][17],dep[N],siz[N],dfn[N],w[N],cnt;
void dfs(int x,int fa)
{
	w[dfn[x]=++cnt]=x;
	siz[x]=1;
	for(int i=head[x];i;i=nxt[i])
	if(to[i]!=fa)
	{
		dep[to[i]]=dep[x]+1;
		f[to[i]][0]=x;
		dfs(to[i],x);
		siz[x]+=siz[to[i]];
	}
}
void dfs2(int x,int fa,int l,int r)
{
	for(int i=dfn[x]+siz[x]-1;i>=dfn[x];i--)
	if(vis[c[i]]!=Tim){
		vis[c[i]]=Tim;
		if(l<=c[i]&&c[i]<=r)++ans;
	}
}
void sol1()
{
	int op,u,l,r,lst=0;
	while(Q--)
	{
		op=read();
		u=read();
		if(T)u^=lst;
		if(op==1)
		{
			l=read(),r=read();
			if(T)l^=lst,r^=lst;
			ans=0;++Tim;
			dfs2(u,f[u][0],l,r);
			printf("%d\n",lst=ans);
		}
		else {
			l=read();
			if(T)l^=lst;
			c[u]=l;
		}
	}
	exit(0);
}
struct node{int d[3];}a[N];
struct KD_tree{int d[3],mx[3],mn[3],ls,rs,siz,s;
void print()
{
	cout<<"p"<<siz<<' '<<d[0]<<' '<<d[1]<<' '<<d[2]<<' '<<s<<endl;
}
}t[N];
int root,qwq;
int pre[N],st[N];
set<int>P[N];
void UPD(int k)
{
	if(t[k].s){
		t[k].mx[0]=t[k].mn[0]=t[k].d[0];
		t[k].mx[1]=t[k].mn[1]=t[k].d[1];
		t[k].mx[2]=t[k].mn[2]=t[k].d[2];
	}else{
		t[k].mx[0]=t[k].mx[1]=t[k].mx[2]=-1;
		t[k].mn[0]=t[k].mn[1]=t[k].mn[2]=n+1;
	}
    for(int i=0;i<3;i++)
    {
        if(t[k].ls)
        t[k].mn[i]=min(t[t[k].ls].mn[i],t[k].mn[i]),t[k].mx[i]=max(t[t[k].ls].mx[i],t[k].mx[i]);
        if(t[k].rs)
        t[k].mn[i]=min(t[t[k].rs].mn[i],t[k].mn[i]),t[k].mx[i]=max(t[t[k].rs].mx[i],t[k].mx[i]);
    }
    t[k].siz=t[t[k].ls].siz+t[t[k].rs].siz+t[k].s;
   // cout<<k<<' ';
   // t[k].print();
}
bool cmp(node a,node b){return a.d[qwq]<b.d[qwq];}
int build(int l,int r,int now)
{
	now%=3;
    qwq=now;
    int mid=l+r>>1;
    nth_element(a+l,a+mid,a+r+1,cmp);
    t[mid].s=1;
    t[mid].mx[0]=t[mid].mn[0]=t[mid].d[0]=dfn[w[mid]];
    t[mid].mx[1]=t[mid].mn[1]=t[mid].d[1]=c[w[mid]];
    t[mid].mx[2]=t[mid].mn[2]=t[mid].d[2]=pre[mid];
    if(l<mid) t[mid].ls=build(l,mid-1,now+1);
    if(mid<r) t[mid].rs=build(mid+1,r,now+1);
    UPD(mid);
    return mid;
}
void ask(int x,int l0,int r0,int l1,int r1,int now)
{
	now%=3; 
	if(!x)return ;
	bool f1=0,f2=0;
	if(t[x].mx[0]<=r0&&t[x].mx[1]<=r1&&t[x].mn[0]>=l0&&t[x].mn[1]>=l1&&t[x].mx[2]<l0)
	{ans+=t[x].siz;cout<<x<<' ',t[x].print();cout<<23456<<endl;return ;}
	if(t[x].mx[0]<l0||t[x].mn[0]>r0||t[x].mx[1]<l1||t[x].mn[1]>r1||t[x].mn[2]>=l0)return;
	if(t[x].d[0]>=l0&&t[x].d[0]<=r0&&t[x].d[1]>=l1&&t[x].d[1]<=r1&&t[x].d[2]<l0)
	ans+=t[x].s,cout<<x<<' ',t[x].print();
	if(now==0)
	{
		if(t[t[x].ls].mx[0]>=l0)f1=1;
		if(t[t[x].rs].mn[0]<=r0)f2=1;
	}
	else if(now==1)
	{
		if(t[t[x].ls].mx[1]>=l1)f1=1;
		if(t[t[x].rs].mn[1]<=r1)f2=1;
	}
	else
	{
		f1=1;
		if(t[t[x].rs].mn[2]<l0)f2=1;
	}
	if(f1)ask(t[x].ls,l0,r0,l1,r1,now+1);
	if(f2)ask(t[x].rs,l0,r0,l1,r1,now+1);
}
void del(int x,int a0,int a1,int a2,int now)
{
	now%=3;
	if(!x)return ;
	if(t[x].d[0]==a0&&t[x].d[1]==a1&&t[x].d[2]==a2){
		t[x].s=0;
		return ;
	}
	if(t[x].mx[0]<a0||t[x].mn[0]>a0||t[x].mx[1]<a1||t[x].mn[1]>a1||t[x].mx[2]<a2||t[x].mn[2]>a2)return;
	if(!now){
		if(a0<=t[t[x].ls].mx[0])del(t[x].ls,a0,a1,a2,now+1);
		if(a0>=t[t[x].rs].mn[0])del(t[x].rs,a0,a1,a2,now+1);
	}else
	if(now==1){
		if(a1<=t[t[x].ls].mx[1])del(t[x].ls,a0,a1,a2,now+1);
		if(a1>=t[t[x].rs].mn[1])del(t[x].rs,a0,a1,a2,now+1);
	}else
	if(now==2){
		if(a2<=t[t[x].ls].mx[2])del(t[x].ls,a0,a1,a2,now+1);
		if(a2>=t[t[x].rs].mn[2])del(t[x].rs,a0,a1,a2,now+1);
	}
	UPD(x);
}
void ins(int &x,int a0,int a1,int a2,int now)
{
	now%=3;
	if(!x){
		x=++cnt;
		t[x].s=1;
		t[x].mx[0]=t[x].mn[0]=t[x].d[0]=a0;
		t[x].mx[1]=t[x].mn[1]=t[x].d[1]=a1;
		t[x].mx[2]=t[x].mn[2]=t[x].d[2]=a2;
		UPD(x);
		return ;
	}
	if(!now){
		if(a0<=t[t[x].ls].mx[0])ins(t[x].ls,a0,a1,a2,now+1);
		else ins(t[x].rs,a0,a1,a2,now+1);
	}else
	if(now==1){
		if(a1<=t[t[x].ls].mx[1])ins(t[x].ls,a0,a1,a2,now+1);
		else ins(t[x].rs,a0,a1,a2,now+1);
	}else
	if(now==2){
		if(a2<=t[t[x].ls].mx[2])ins(t[x].ls,a0,a1,a2,now+1);
		else ins(t[x].rs,a0,a1,a2,now+1);
	}
	UPD(x);
}
void sol2()
{
	for(int i=1;i<=n;i++)
	{
		pre[i]=st[c[w[i]]];
		st[c[w[i]]]=i;
		P[c[w[i]]].insert(i);
	}
	root=build(1,n,0);
	int op,u,l,r,lst=0;
	while(Q--)
	{
		op=read();
		u=read();
		if(T)u^=lst;
		if(op==1)
		{
			l=read(),r=read();
			ans=0;
			if(T)l^=lst,r^=lst;
			ask(root,dfn[u],dfn[u]+siz[u]-1,l,r,0);
			printf("%d\n",lst=ans);
		}
		else {
			l=read();
		//	continue;
			if(T)l^=lst;
			set<int>::iterator it;
			it=P[c[u]].find(dfn[u]);
			int t=-1;
			if(it!=P[c[u]].begin())
			{
				t=*(--it);
				++it;
			}
			++it;if(it!=P[c[u]].end()&&t!=-1)pre[*it]=t;
			del(root,dfn[u],c[u],pre[dfn[u]],0);
			P[c[u]].erase(dfn[u]);
			c[u]=l;
			it=P[l].upper_bound(dfn[u]);
			if(!P[l].size()||it==P[l].begin())pre[dfn[u]]=0;
			else pre[dfn[u]]=*(--it),++it;
			if(P[l].size()){
				++it;
				if(it!=P[l].end())pre[*it]=dfn[u];
			}
			P[l].insert(dfn[u]);
			ins(root,dfn[u],l,pre[dfn[u]],0);
		}
	}
	exit(0);
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&T);
	for(int i=1;i<=n;i++)c[i]=read();
	int u,v;
	for(int i=1;i<n;i++)
	{  
		u=read(),v=read();
		add(u,v),add(v,u);
	}
	dfs(1,1);
	if(n<=5000&&Q<=5000)sol1();
	//else 
//	sol2();
	return 0;
}
/*
5 5 0 
5 5 2 5 5 
5 1 
2 5
4 2
3 5 
1 2 2 3 
1 1 1 5 
1 3 1 5

5 5 0 
5 5 2 5 5 
5 1 
2 5 
4 2 
3 5 
1 2 2 3 
2 5 1 
1 1 1 5 
2 3 2 
1 3 1 5

*/