#include<cstdio>
using namespace std;
const int maxn = 1e2 + 5;
char s[maxn];
int n, m;
int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(register int i = 1; i <= n; ++i)
		scanf("%s", s);
	printf("3");
	return 0;
}
