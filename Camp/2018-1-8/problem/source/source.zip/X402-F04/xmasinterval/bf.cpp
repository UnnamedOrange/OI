//2018-1-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N 21
#define M (100000+6)

int l[N], r[N], imp[N];
bool vis[M];

int main(){
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval2.out", "w", stdout);
	
	int n, m;
	scanf("%d%d", &n, &m);
	For(i, 1, n) scanf("%d%d", &l[i], &r[i]);
	For(i, 1, m) scanf("%d", &imp[i]);
	
	bool flag;
	int ans = 0;

	For(i, 0, (1<<n)-1){
		For(j, 1, n) if(i & (1<<(j-1))){
			For(k, l[j], r[j]) vis[k] = true;
		}

		flag = true;
		For(j, 1, m) if(!vis[imp[j]]){
			flag = false; break;
		}
		if(flag){
			++ans;
		//	For(j, 1, n) if(i & (1<<(j-1))) printf("%d ", j);
		//	puts("");
		}
		For(j, 1, n) if(i & (1<<(j-1))){
			For(k, l[j], r[j]) vis[k] = false;
		}
	}

	printf("%d\n", ans);

	return 0;
}
