#include <bits/stdc++.h>
#define LL long long
#define MOD 998244353
//#define getchar() *(pp++)
using namespace std;
char buf[10000100],*pp=buf;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
struct edge
{
	int v,p;
}e[200010];
int n,head[100010],deg[100010],top;
inline void addedge(int u,int v)
{
	e[++top]=(edge){v,head[u]};
	head[v]=top;
	deg[v]++;
	e[++top]=(edge){u,head[v]};
	head[u]=top;
	deg[u]++;
}
char c[100010];
LL d[1<<6][10],inv[100001];
LL dp(int S,int u)
{
	if(d[S][u])return d[S][u];
	if(deg[u]==1)return d[S][u]=c[u]-'0';
	int temp=0;
	if(!(S&(1<<(u-1))))d[S][u]++;
	for(int i=head[u];i;i=e[i].p)
	{
		temp++;
		d[S][u]=(d[S][u]+dp(S|(1<<(u-1)),e[i].v))%MOD;
	}
	return d[S][u]=d[S][u]*inv[temp]%MOD;
}
int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
//	fread(buf,sizeof(char),sizeof(buf),stdin);	
	n=read();
	scanf("%s",c+1);
	for(int i=1;i<n;i++)
	{
		addedge(read(),read());
	}
	inv[1]=1;
	for(int i=2;i<=n;i++)
	{
		inv[i]=(MOD-MOD/i)*inv[MOD%i];
	}
	for(;;);
	if(n<10)
	{
		cout<<dp(0,1)<<endl;
	}
	return 0;
}
/*
d[i][j]=c[i+j-1][i];
*/
