#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const int maxn = 1005, zhf = 0x3f3f3f3f ;
int n, m, W, p, q, w[maxn] ;
struct H {
	int x, y, z, a, b, c, d, e, f ;
	int calc() {
		return
		a*abs(w[x]-w[y])+b*abs(w[y]-w[z])+c*abs(w[z]-w[x])
		+d*(w[x]-w[y])+e*(w[y]-w[z])+f*(w[z]-w[x]) ;
	}
} s[maxn] ;
struct L {
	int x, y, r ;
} l[maxn] ;
int calc ( int x ) {
	int i, rec = 0 ;
	for ( i = 1 ; i <= n ; i ++, x >>= 1 ) {
		if (x&1) w[i] = W ;
		else w[i] = -W ;
		rec += w[i] ;
	}
	for ( i = 1 ; i <= q ; i ++ )
		if (l[i].r == 0 && w[l[i].x] > w[l[i].y]) return zhf ;
		else if (l[i].r == 1 && (w[l[i].x] ^ w[l[i].y])) return zhf ;
		else if (l[i].r == 2 && w[l[i].x] >= w[l[i].y]) return zhf ;
	//for ( i = 1 ; i <= n ; i ++ )
	//	printf ( "%d ", w[i] ) ; puts("") ;
	for ( i = 1 ; i <= p ; i ++ )
		rec += s[i].calc() ;
	//cout << s[1].calc() << endl ;
	//printf ( "%d\n\n", rec ) ;
	return rec ;
}
int main() {
	freopen ( "variable.in", "r", stdin ) ;
	freopen ( "variable.out", "w", stdout ) ;

	int i, rec, k, _ ;
	Read(_) ;
	while (_--) {
		Read(n) ; Read(W) ; Read(p) ; Read(q) ;
		for ( i = 1 ; i <= p ; i ++ ) {
			Read(s[i].x), Read(s[i].y), Read(s[i].z) ;
			Read(s[i].a), Read(s[i].b), Read(s[i].c) ;
			Read(s[i].d), Read(s[i].e), Read(s[i].f) ;
		}
		for ( i = 1 ; i <= q ; i ++ )
			Read(l[i].x), Read(l[i].y), Read(l[i].r) ;
		rec = zhf ;
		k = 1<<n ;
		for ( i = 0 ; i < k ; i ++ )
			rec = min(rec, calc(i)) ;
		printf ( "%d\n", rec ) ;
	}
	return 0 ;
}
