#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 2000005;
int n, m, k, ans = N, a[20], b[20], son[N][2], dep[N], idx = 1;

void insert(int *a, int n, int x){
	int now = 1;
	for(int i = 1; i <= n; i++)
		if(x >> (i - 1) & 1){
			if(!son[now][a[i]]){
				son[now][a[i]] = ++idx;
				dep[idx] = dep[now] + 1;
			}
			now = son[now][a[i]];
		}
}

int main(){
	
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	
	read(n), read(m), read(k);
	for(int i = 1; i <= n; i++)
		read(a[i]), a[i]--;
	for(int i = 1; i <= m; i++)
		read(b[i]), b[i]--;
	for(int i = 1; i < (1 << n); i++)
		insert(a, n, i);
	for(int i = 1; i < (1 << m); i++)
		insert(b, m, i);
	for(int i = 1; i <= idx; i++)
		if(!son[i][0] || !son[i][1])
			ans = min(ans, dep[i] + 1);
	write(ans), enter;
	
	return 0;
}
/*
3 3 3
1 2 1
2 1 1
*/
