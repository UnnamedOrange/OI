#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 500005
const int mod=1e9+9;

int n,m,debug;
int a[maxn],l[maxn],r[maxn],power[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

struct interval{
	int l,r;
	bool operator <(const interval &a)const{return l<a.l||(l==a.l&&r<a.r);}
}p[maxn];

struct segment_tree{
	struct tree_node{int sum,tag;}tree[maxn*4];
	void update(int p){tree[p].sum=(tree[p<<1].sum+tree[p<<1|1].sum)%mod;}
	void build(int p,int l,int r){
		tree[p].tag=1;
		if (l==r) return; int mid=(l+r)>>1;
		build(p<<1,l,mid),build(p<<1|1,mid+1,r);
	}
	void add_tag(int p,int v){tree[p].sum=1ll*tree[p].sum*v%mod,tree[p].tag=1ll*tree[p].tag*v%mod;}
	void push_down(int p){
		if (!tree[p].tag) return; int &v=tree[p].tag;
		add_tag(p<<1,v),add_tag(p<<1|1,v),v=1;
	}
	void change(int p,int l,int r,int x,int v){
		tree[p].sum=(tree[p].sum+v)%mod;
		if (l==r) return;
		int mid=(l+r)>>1; push_down(p);
		if (x<=mid) change(p<<1,l,mid,x,v);
		else change(p<<1|1,mid+1,r,x,v);
	}
	void mul(int p,int l,int r,int x,int y){
		if (x>y) return;
		if (x<=l&&r<=y){add_tag(p,2); return;}
		int mid=(l+r)>>1; push_down(p);
		if (x<=mid) mul(p<<1,l,mid,x,y);
		if (y>mid) mul(p<<1|1,mid+1,r,x,y);
		update(p);
	}
	int query(int p,int l,int r,int x,int y){
		if (x<=l&&r<=y) return tree[p].sum;
		int mid=(l+r)>>1,ret=0; push_down(p);
		if (x<=mid) ret=(ret+query(p<<1,l,mid,x,y))%mod;
		if (y>mid) ret=(ret+query(p<<1|1,mid+1,r,x,y))%mod;
		return ret;
	}
	void print(int p,int l,int r){
		if (l==r){printf("%d ",tree[p].sum); return;}
		int mid=(l+r)>>1; push_down(p);
		print(p<<1,l,mid),print(p<<1|1,mid+1,r);
	}
}T;

int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read(),m=read();
	power[0]=1; for (int i=1;i<=m;i++) power[i]=(power[i-1]<<1)%mod;
	for (int i=1;i<=n;i++) p[i].l=read(),p[i].r=read();
	for (int i=1;i<=m;i++) a[i]=read();
	sort(a+1,a+m+1),sort(p+1,p+n+1);
	for (int i=1;i<=n;i++){
		l[i]=lower_bound(a+1,a+m+1,p[i].l)-a-1;
		r[i]=upper_bound(a+1,a+m+1,p[i].r)-a-1;
	}
	T.build(1,1,m);
	T.change(1,0,m,0,1);
	for (int i=1;i<=n;i++){
		int x=l[i],y=r[i];
		int v=T.query(1,0,m,x,y);
		T.change(1,0,m,y,v),T.mul(1,0,m,y+1,m);
	}
	printf("%d\n",T.query(1,0,m,m,m));
	return 0;
}
