#include<bits/stdc++.h>
using namespace std;
int qmax(int &x,int y) {if (x<y) x=y;}
int qmin(int &x,int y) {if (x>y) x=y;}
int read()
{
	char s;
	int k=0,base=1;
	while((s=getchar())!='-'&&s!=EOF&&!(isdigit(s)));
	if(s==EOF)exit(0);if(s=='-')base=-1,s=getchar();
	while(isdigit(s)){k=k*10+(s^'0');s=getchar();}
	return k*base;
}
void write(int x)
{
	if(x<0){putchar('-');write(-x);}
	else{if(x/10)write(x/10);putchar(x%10+'0');}
}
const int maxn=1e5+100;
int n,q,t,c[maxn],c1[maxn],ID[maxn],dfs_time,lastans;
int to[maxn*2],ne[maxn*2],po[maxn],id1,sz[maxn],X,Y,Z,BJ,Map[maxn];
int bj[maxn];
void add(int x,int y)
{
	++id1;to[id1]=y;ne[id1]=po[x];po[x]=id1;
}
void DFS(int x)
{
	ID[x]=++dfs_time;sz[x]=1;
	for (int i=po[x];i;i=ne[i])
		if (ID[to[i]]==0) DFS(to[i]),sz[x]+=sz[to[i]];
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read();q=read();t=read();
	if (n<=5000&&q<=5000)
	{
		for (int i=1;i<=n;i++) c[i]=read(),ID[i]=0; 
		for (int i=1;i<n;i++) X=read(),Y=read(),add(X,Y),add(Y,X);
		DFS(1);
		for (int i=1;i<=n;i++) Map[ID[i]]=c[i]; 
		for (int j=1;j<=q;j++)
		{
			BJ=read();
			if (BJ==1)
			{
				X=read();Y=read();Z=read();
				if (t==1) X^=lastans,Y^=lastans,Z^=lastans;
				lastans=0;
				for (int i=ID[X];i<ID[X]+sz[X];i++)
				{
					if (Y<=Map[i]&&Map[i]<=Z)
					{
						if (bj[Map[i]]!=j)
						{
							bj[Map[i]]=j;
							lastans++;
						}
					}
				}
				printf("%d\n",lastans);
			} else
			{
				X=read();Y=read();
				c[X]=Y;
				Map[ID[X]]=Y;
			}
		}
	}
	return 0;
}

