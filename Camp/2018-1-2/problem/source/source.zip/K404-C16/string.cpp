#include<bits/stdc++.h>
using namespace std;
#define N 100010
char a[N];
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int t;
	std::ios::sync_with_stdio(false);
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		bool dif=false;
		cin>>a[1];
		for(int i=2;i<=n;i++){
			cin>>a[i];
			if(a[i]!=a[i-1])
				dif=true;
		}
		if(!dif)
			cout<<-1<<endl;
		else{
			dif=false;
			int i=1,j=n;
			while(i<j){
				if(a[i]!=a[j]){
					cout<<1<<endl;
					dif=true;
					break;
				}
				i++;j--;
			}
			if(!dif)
				cout<<2<<endl;
		}
	}
	return 0;
}

