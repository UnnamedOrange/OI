#include<iostream>
#include<cstdio>
#define minm(a,b) a<b?a:b

using namespace std;

int t;
int n;
char s[105];
bool hw[105][105];
int f[105][105];

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d\n%s",&n,&s);
		for(int i=0;i<n;i++)
			for(int j=i;j<n;j++)
			{
				hw[i][j]=1;
				for(int k=i;k<=(i+j)/2;k++)
					if(s[k]!=s[i+j-k])
					{
						hw[i][j]=0;
						break;	
					}	
			}
		for(int l=1;l<=n;l++)
			for(int i=0;i<n-l+1;i++)
			{
				int j=i+l-1;
				if(!hw[i][j])
					f[i][j]=1;
				else
				{
					f[i][j]=0x3f3f3f3f;
					if(i!=j)
						for(int k=i;k<j;k++)
						{
							if((!hw[i][k])&&(!hw[k+1][j]))
								f[i][j]=minm(f[i][j],f[i][k]+f[k+1][j]);
						}	
				}
			}
		printf("%d\n",f[0][n-1]==0x3f3f3f3f?-1:f[0][n-1]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
