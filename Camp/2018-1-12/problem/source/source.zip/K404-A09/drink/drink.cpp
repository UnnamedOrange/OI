#include<bits/stdc++.h>
using namespace std;
inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
#define N 1000001
#define UP 50
#define si set<Node>::iterator
#define rsi set<int>::reverse_iterator
int a[N],cnt[N],b[UP+1][N],c[UP+1][N];

double p[N],ans;
struct Node{
	int id,it;
	bool operator < (const Node &A) const {
		if(it==A.it) return id<A.id;
		return it<A.it;
	}
	Node(int id=0,int it=0) : id(id),it(it) {}
};
set<Node> s;
int main() {
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int n;
	R(n);
	p[0]=1;for(int i=1;i<=n;i++) p[i]=p[i-1]/2;
	for(int i=1;i<=n;i++) R(a[i]);
	for(int i=1;i<=n;i++) {
		for(si j=s.begin();j!=s.end()&&(*j).it<a[i];) {
			b[++cnt[(*j).id]][(*j).id]=i;
			if(cnt[(*j).id]>=UP) s.erase(j++);
			else j++;
		}
		s.insert(Node(i,a[i]));
	}
	memset(cnt,0,sizeof(cnt));
	s.clear();
	for(int i=n;i>=1;i--) {
		for(si j=s.begin();j!=s.end()&&(*j).it<=a[i];) {
			c[++cnt[(*j).id]][(*j).id]=i;
			if(cnt[(*j).id]>=UP) s.erase(j++);
			else j++;
		}
		s.insert(Node(i,a[i]));
	}
	for(int i=1;i<=n;i++) {
		int pre=i,tmp2=1,tmp5=a[i];
		double tmp=0;
		int j;
		for(j=1;j<=UP&&b[j][i]!=0;++j) {
			tmp+=(b[j][i]-pre)*p[tmp2++],pre=b[j][i];
		}
		tmp+=(n-pre+1)*p[tmp2],tmp2=0,pre=i;
		double tmp3=tmp*a[i],tmp4=0;
		for(j=1;j<=UP&&c[j][i]!=0;++j) {
			tmp4+=(pre-c[j][i])*p[tmp2++],pre=c[j][i];
		}
		tmp4*=tmp3;
		ans+=pre*p[tmp2]*tmp3;
		ans+=tmp4;
	}
	printf("%0.6f\n",ans/n/n);
}
