#include <cstdio>
#include <algorithm>
using namespace std;
#define Mod 1000000007
#define N 1000050
long long s;
int t,n,m,i,ni[N],a[N],b[N];
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%lld%d%d%d",&s,&t,&n,&m);if (n>m) n=m;s++;m++;
	ni[1]=1;for (i=2;i<=max(s-m,(long long)n);i++) ni[i]=-1LL*(Mod/i)*ni[Mod%i]%Mod;
	a[0]=1;for (i=1;i<=n;i++) a[i]=1LL*a[i-1]*(n-i+1)%Mod*ni[i]%Mod;
	b[m-1]=1;for (i=m;i<=s-1;i++) b[i]=1LL*b[i-1]*i%Mod*ni[i-m+1]%Mod;
	int ans=0;
	for (i=0;i<=n;i++) if (s-1LL*i*t>=m) ans=(1LL*((i&1)?(-1):1)*a[i]*b[s-i*t-1]+ans)%Mod;
	printf("%d\n",(ans+Mod)%Mod);
	return 0;
}
