#include<cstdio>
int n;
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	scanf("%d",&n);
	printf("%d",n-1);
	return 0;
}
