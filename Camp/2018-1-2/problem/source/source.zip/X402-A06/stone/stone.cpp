#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, a, b, x[maxn], u, v, w, flag = 0;

void Get(){
	n = read(), a = read(), b = read();
	if(a > b) flag = 1;
	if(a > b) swap(a, b);
	For(i, 1, n) x[i] = read();
}

void solve_bf(){
	int tmp = (1 << n) - 1;

	++ v;
	For(i, 1, tmp){
		int xian = 0, hou = 0, other = 0;

		For(j, 1, n){
			if(i & (1 << j-1)){
				if((x[j] % (a + b)) < a) ++hou;
				else if((x[j] % (a + b)) >= b) ++xian;
				else ++other;
			}
		}

		if(b < 2 * a){
			if(other != 0) ++w;
			else if(xian%2==1) ++u;
			else ++v;
		}
		else{
			if(other != 0 || xian > 1) ++w;
			else if(xian == 1) ++u;
			else ++v;
		}
	}

	if(flag) printf("0 ");
	else printf("%d ", w);
	if(flag) printf("%d ", w);
	else printf("0 ");

	printf("%d %d\n", u, v);
}

const int mod = 1e9+7;

int ksm(int x,int k){
	int s = 1;

	while(k){
		if(k & 1) s = 1ll * s * x % mod;
		x = 1ll * x * x % mod;
		k >>= 1;
	}

	return s;
}

void solve1(){

	int hou = 0, xian = 0, other = 0;
	For(j, 1, n){
		if((x[j] % (a + b)) < a) ++hou;
		else if((x[j] % (a + b)) >= b) ++xian;
		else ++other;
	}

	w = 1ll * (1ll * ksm(2, other) - 1ll + mod) % mod * ksm(2, n - other) % mod;
	if(xian != 0) u = v = 1ll * ksm(2, xian) % mod * ksm(2, hou) % mod * ksm(2, mod-2) % mod;
	else v = (1ll * ksm(2, n) - w + mod) % mod;

	if(flag) printf("0 ");
	else printf("%d ", w);
	if(flag) printf("%d ", w);
	else printf("0 ");

	printf("%d %d\n", u, v);
}

void solve2(){
	int hou = 0, xian = 0, other = 0;
	For(j, 1, n){
		if((x[j] % (a + b)) < a) ++hou;
		else if((x[j] % (a + b)) >= b) ++xian;
		else ++other;
	}

	u = 1ll * xian * ksm(2, hou) % mod;
	v = 1ll * ksm(2, hou) % mod;
	int all = (u + v) % mod;
	w = (1ll * ksm(2, n) - 1ll * all % mod + mod) % mod;
	
	if(flag) printf("0 ");
	else printf("%d ", w);
	if(flag) printf("%d ", w);
	else printf("0 ");

	printf("%d %d\n", u, v);
}

int main(){
	
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);

	Get();
	if(n <= 20) solve_bf();
	else if(b < 2 * a) solve1();
	else solve2();

	return 0;
}
