#include<bits/stdc++.h>
using namespace std;
int n,a,b;
const int mo=1e9+7;
int rock[100005];
long long mi(int v){
	int x=1;
	while(v--){
		x*=2;x%=mo;
	}
	return x;
}
void do_10(){
	int las=0,firs=0;
	for(int i=1;i<=n;i++){
		int p=rock[i]/a;
		if(p%2==0) las++;
		else if(p%2==1) firs++;
	}
	long long  p=mi(firs)/2,q=mi(las);
	long long su=p*q%mo;
	printf("0 0 %lld %lld",su,su);
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	for(int i=1;i<=n;i++){
		scanf("%d",&rock[i]);
	}
	if(a==b) do_10();
	else {
		
	}
	return 0;
}
