#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
int a[1000005],q[1505]; double db[1505],c=1.0/2.0,ans=0.0,s1,s2;
int main(){
	freopen("drink.in","r",stdin); freopen("drink.out","w",stdout);
	int n=read(),m=1500,x,l; db[0]=1.0;
	For(i,1,m) db[i]=db[i-1]*c;
	For(i,1,n) a[i]=read();
	For(i,1,n){
		q[1]=a[i],l=1; ans+=a[i]*0.5,s1=0.0,s2=0.0;
		For(j,i+1,n){
			if (l<m){
				x=++l;
				while(a[j]>q[x-1]&&x>1) q[x]=q[x-1],--x;	
			}
			else{
				x=m;
				while(a[j]>q[x]&&x>1) q[x]=q[x-1],--x;
			}
			q[x]=a[j];
			for(int k=1;k<l;k+=2) s1+=db[k]*q[k],s2+=db[k+1]*q[k+1];
			if (l%2==1) s1+=db[l]*q[l];
		}
		ans+=s1+s2;
	}
	s1=n;
	printf("%.16lf\n",ans/(s1*s1));
	return 0;
}
