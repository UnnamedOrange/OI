#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=110;
int n,f[MAXN][MAXN];
char a[MAXN];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T=read();
	while(T--)
	{
		n=read();
		scanf("%s",a+1);
		memset(f,INF,sizeof(f));
		for(int l=2;l<=n;++l)
			for(int i=1;i+l-1<=n;++i)
			{
				int j=i+l-1;
				if(a[i]!=a[j])f[i][j]=1;
				for(int k=i;k<j,f[i][j]!=1;++k)
					f[i][j]=min(f[i][j],f[i][k]+f[k+1][j]);
			}
		if(f[1][n]>n)puts("-1");
		else printf("%d\n",f[1][n]);
	}
	return 0;
}
