#include<bits/stdc++.h>

#define ll long long
#define inf 999999999
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int maxm = 20;

const int mod = 998244353;

int Begin[maxm], to[maxm], e, Next[maxm], p[maxn], a[maxn], pre[maxm], dfs_clock, low[maxm];

int n;

void add(int x,int y){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get(){
	n = read();
	For(i, 1, n) p[i] = read();
	For(i, 1, n) a[i] = i;
}

int st[maxm], top, circle[maxm];

void init(){
	e = 0;
	mm(Begin, 0);

	mm(pre, 0);
	mm(circle, 0);

	dfs_clock = 0;
}

bool pd = 0;

void dfs(int h){
	st[++top] = h;
	pre[h] = low[h] = ++ dfs_clock;
	for(int i = Begin[h]; i; i = Next[i]){
		int v = to[i];

		if(!pre[v]){
			dfs(v);
			low[h] = min(low[h], low[v]);
		}
		else if(!circle[v]) low[h] = min(low[h], pre[v]);
	}

	if(pre[h] == low[h]){
		int cnt = 0;
		while(1){
			int now = st[top--];
			circle[now] = 1;
			++ cnt;
			if(now == h) break;
		}

		if(cnt & 1) pd = 1;
	}
}

int tarjan(){
	For(i, 1, n){
		pd = 0;
		if(!pre[i]){
			dfs(i);
		}
		
		if(pd) return 0;
	}

	return 1;
}

void solve_bf(){
	int Ans = 0;

	do{
		bool flag = 0;
		For(i, 1, n){
			if(p[i] != 0 && a[i] != p[i]) {flag = 1; break;}
		}

		if(flag) continue;

		init();
		For(i, 1, n){
			add(i, a[i]);
		}

		Ans += tarjan();

	}while(next_permutation(a+1, a+n+1));

	printf("%d\n", Ans);
}

void solve_spe(){
	int Ans = 1;
	if(n&1) puts("0");
	else{
		for(int i = 2;i <= n;i += 2){
			Ans = 1ll * Ans * (i-1) % mod;
		}

		Ans = 1ll * Ans * Ans % mod;
		printf("%d\n", Ans);
	}
}

int main(){
	
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);

	Get();
	if(n & 1){
		puts("0");
		return 0;
	}

	if(n <= 8) solve_bf();
	else solve_spe();

	return 0;
}
