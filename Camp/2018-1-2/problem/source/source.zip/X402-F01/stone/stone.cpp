#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("stone.in","r",stdin);
		freopen("stone.out","w",stdout);
	#endif
}
const int mo=1e9+7;
int n,a,b;
int sum[N],num[5];
void input()
{
	n=read<int>();a=read<int>();b=read<int>();
	For(i,1,n)
	{
		sum[i]=read<int>();
		sum[i]/=a;
		sum[i]%=2;
		num[sum[i]]++;
	}
}
ll power(ll x,ll y)
{
	ll res=1;
	for(;y;x=x*x%mo,y>>=1)if(y&1)res=res*x%mo;
	return res;
}
ll mc[N],inv[N];
void init()
{
	mc[0]=inv[0]=1;
	For(i,1,n)mc[i]=mc[i-1]*i%mo;
	inv[n]=power(mc[n],mo-2);
	Fordown(i,n-1,1)inv[i]=inv[i+1]*(i+1)%mo;
}
ll C(int n,int m)
{
	if(!n||!m||n<m)return 1;
	return mc[n]*inv[m]%mo*inv[n-m]%mo;
}
void work()
{
	ll ans=0;
	for(register int i=1;i<=num[1];i+=2)ans=(ans+C(num[1],i))%mo;
	printf("%lld ",ans*power(2,num[0])%mo);
	ans=0;
	for(register int i=0;i<=num[1];i+=2)ans=(ans+C(num[1],i))%mo;
	printf("%lld ",ans*power(2,num[0])%mo);
	printf("%d %d\n",0,0);
}
int main()
{
	file();
	input();
	init();
	work();
	return 0;
}
