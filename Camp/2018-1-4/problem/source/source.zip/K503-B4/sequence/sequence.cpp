#include <map>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef double real;
const int maxn=2e7+5;
int T,n,dp[maxn],ai[25],bi[25],bit[25],que[maxn],ans,ci[25];
inline int makeit()
{
	int res=0;
	for(int i=1;i<=n;i++)
		res+=ai[i]*bit[i];
	return res;
}
inline int end(int x)
{
	int res=0;
	for(int i=1;i<=x;i++)
		res+=(i-1)*bit[i];
	return res;
}
inline void swap(int &l,int &r)
{
	int t=l;
	l=r;
	r=t;
}
inline int turn(int s,short r)
{
	for(short i=1;i<=n;++i)
		bi[i]=(s%(bit[i]*n))/bit[i];
	short l=1;
	while(l<r)
	{
		swap(bi[l],bi[r]);
		++l;
		--r;
	}
	int res=0;
	for(short i=1;i<=n;i++)
		res+=bi[i]*bit[i];
	return res;
}
inline int getans()
{
	int res=0;
	for(int i=1;i<=n;i++)
		ci[i]=ai[i]+1;
	for(int i=n;i>1;--i)
	{
		for(int v=1;v<=n;v++)
			if(ci[v]==i)
			{
				if(v!=i)
					if(v==1)
					{
						res++;
						for(int l=1,r=i;l<r;l++,r--)
							swap(ci[l],ci[r]);
					}
					else
					{
						for(int l=1,r=v;l<r;l++,r--)
							swap(ci[l],ci[r]);
						for(int l=1,r=i;l<r;l++,r--)
							swap(ci[l],ci[r]);
						res+=2;
					}
				break;
			}
	}
	return res;
}
inline int getans2()
{
	int res=0;
	for(int i=1;i<=n;i++)
		ci[i]=ai[i]+1;
	for(int i=n;i>=1;i--)
	{
		for(int v=1;v<=n;v++)
			if(ci[v]==i)
			{
				if(v!=i&&v!=1)
				{
					res++;
					for(int l=1,r=v;l<r;l++,r--)
						swap(ci[l],ci[r]);
				}
				break;
			}
	}
	for(int i=1;i<=n;i++)
		if(ci[i]!=i)
			return n*2;
	return res;
}
inline int getans3()
{
	int res=0;
	for(int i=1;i<=n;i++)
		ci[i]=ai[i]+1;
	for(int i=1;i<=n;i++)
	{
		for(int v=1;v<=n;v++)
			if(ci[v]==n)
			{
				if(v!=i)
				{
					res+=2;
					for(int l=1,r=v;l<r;l++,r--)
						swap(ci[l],ci[r]);
					for(int l=1,r=i;l<r;l++,r--)
						swap(ci[l],ci[r]);
				}
				break;
			}
	}
	return res;
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&ai[i]);
			ai[i]--;
		}
		if(n<=8)
		{
			bit[1]=1;
			for(int i=2;i<=n;i++)
				bit[i]=bit[i-1]*n;
			memset(dp,0,sizeof(dp));
			int h=0,tail=1,to,now,t=end(n),Bre=0;
			ans=std::min(getans(),std::min(getans2(),getans3()));
			que[h]=makeit();
			dp[que[h]]=1;
			while(h<tail)
			{
				now=que[h++];
				if(now==t)
				{
					ans=dp[now]-1;
					break;
				}
				for(short l=2;l<=n;++l)
				{
					to=turn(now,l);
					if(!dp[to])
					{
						dp[to]=dp[now]+1;
						if(to==t)
						{
							Bre=1;
							ans=dp[to]-1;
							break;
						}
						if(dp[to]<ans)
							que[tail++]=to;
					}
				}
				if(Bre)
					break;
			}
			printf("%d\n",ans);
		}
		else
		{
			printf("%d\n",std::min(getans(),std::min(getans2(),getans3())));
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
