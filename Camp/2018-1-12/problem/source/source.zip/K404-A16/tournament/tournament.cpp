#include <cstdio>
#include <algorithm>
#define FOR(i, l, r) for(ll i = l; i <= r; ++i)

using namespace std;

typedef long long ll;
const int N = 5010;
const int mod = 998244353;

ll f[N], g[N], a[N], c[N][N];
ll n, k;

ll pow(ll a, ll b)
{
	ll ans = 1;
	for(; b; b >>= 1)
	{
		if (b & 1) ans = ans * a % mod;
		a = a * a % mod;
	}
	return ans;
}

int main()
{
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	
	scanf("%lld%lld", &n, &k);
	
	FOR(i, 0, n)
	{
		c[i][0] = 1;
		FOR(j, 1, i)
		{
			c[i][j] = c[i - 1][j - 1] + c[i - 1][j];
			if (c[i][j] >= mod) c[i][j] -= mod;
		}
	}
	
	FOR(i, 1, n) f[i] = pow(2LL, i * (i - 1) / 2);
	
	a[1] = 1;
	FOR(i, 2, n)
	{
		FOR(j, 1, i - 1) a[i] = (a[i] + c[i][j] * a[j] % mod * f[i - j]) % mod;
		a[i] = (f[i] - a[i] + mod) % mod;
	}
	
	g[0] = 1;
	FOR(i, 1, n)
		FOR(j, 1, min(k - 1, i)) g[i] = (g[i] + c[i][j] * a[j] % mod * g[i - j]) % mod;
	printf("%lld\n", (f[n] - g[n] + mod) % mod);
	return 0;
}

