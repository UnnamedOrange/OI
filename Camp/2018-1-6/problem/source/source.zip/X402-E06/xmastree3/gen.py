import sys
from random import *

sys.stdout = open("xmastree3.in", "w")


n = 20
k = 8

print(n, k)

for i in range(2, n+1):
    print (randint(1, i-1), i)
