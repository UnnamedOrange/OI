#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std; 
int nxta[4005][4005], nxtb[4005][4005], a[4005], b[4005];
int vis[4005][4005], que[20000005]; 
int main()
{
	freopen("subsequence.in", "r", stdin); 
	freopen("subsequence.out", "wt", stdout); 
	int n, m, k; 
	scanf("%d%d%d", &n, &m, &k); 
	for (int i = 1; i <= n; i++)
		scanf("%d", a + i);
	for (int i = 1; i <= m; i++)
		scanf("%d", b + i); 
	for (int i = 1; i <= k; i++)
		nxta[n + 1][i] = n + 1; 
	for (int i = n; i >= 0; i--)
	{
		for (int j = 1; j <= k; j++)
			nxta[i][j] = nxta[i + 1][j]; 
		nxta[i][a[i + 1]] = i + 1;
	}
	for (int i = 1; i <= k; i++)
		nxtb[m + 1][i] = m + 1; 
	for (int i = m; i >= 0; i--)
	{
		for (int j = 1; j <= k; j++)
			nxtb[i][j] = nxtb[i + 1][j]; 
		nxtb[i][b[i + 1]] = i + 1;
	}
	memset(vis, 0x3f, sizeof(vis)); 
	int he = 0, ta = 0; 
	que[ta++] = 0;
	vis[0][0] = 0; 
	while (he < ta)
	{
		int x = que[he] >> 12, y = que[he] & 4095; 
		he++; 
		if (x == n + 1 && y == m + 1)
		{
			printf("%d\n", vis[x][y]);
			return 0; 
		}
		for (int i = 1; i <= k; i++)
		{
			int xx = nxta[x][i], yy = nxtb[y][i];
			if (vis[xx][yy] > vis[x][y] + 1)
			{
				vis[xx][yy] = vis[x][y] + 1; 
				que[ta++] = xx << 12 | yy; 
			}
		}
	}
	return 0;
}

