#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int mod=998244353;
int n,m,k;
int a[100],dp[50][50][50];
ll ans=0;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
ll qpow(ll base,ll b){
	ll res=1;
	while(b){
		if(b & 1)res=res*base%mod;
		base=base*base%mod;
		b/=2;
	}
	return res;
}
void dfs(int cur,int tot,int lmin,int rmin){
	int i,j;
	if(cur>tot){
		for(i=1;i<=m;i++)(ans+=qpow(a[i],k))%=mod;
		return;
	}
	for(i=lmin;i<=m;i++)
		for(j=max(i,rmin);j<=m;j++){
			for(int s=i;s<j;s++)a[s]++;
			dfs(cur+1,tot,i+1,j+1);
			for(int s=i;s<j;s++)a[s]--;
		}
}
int main(){
	int i,j;
#ifndef ONLINE_JUDGE
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
#endif
	n=read();m=read();k=read();
	if(n>m){
		puts("0");
		return 0;
	}
	if(m<=6){
		dfs(1,n,1,1);
		printf("%lld\n",ans);
		return 0;
	}
	if(n==1){
		for(i=1;i<=m;i++)ans+=1ll*i*(m-i);
		printf("%lld\n",ans);
	}
	if(k==1){
		int l,r;
		memset(dp,-63,sizeof(dp));
		dp[0][0][0]=0;
		for(i=1;i<=n;i++)
			for(l=1;l<=m;l++)
				for(r=l;r<=m;r++){
					ll sum=0;
					int flag=0;
					for(j=0;j<l;j++)
						for(k=j;k<r;k++){
							if(dp[i-1][j][k]<0)continue;
							(sum+=dp[i-1][j][k]+r-l)%=mod;
							flag=1;
						}
					if(flag)dp[i][l][r]=sum;
					if(i==n && flag)(ans+=dp[i][l][r])%=mod;
				}
		printf("%lld\n",ans);
	}
	return 0;
}

