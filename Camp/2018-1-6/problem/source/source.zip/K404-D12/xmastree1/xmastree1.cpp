#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <map>

using namespace std;
#define MAXN 100000
#define Trav(p) for(rint u = first[p], v; ~u; u = e[u].nex)
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int n, q, TYPE, LASTANS = 0, tot, ql, qr, first[MAXN+5], fa[MAXN+5], c[MAXN+5]; map<int,bool> g;
inline int Read(){return read()^(TYPE?LASTANS:0);}
struct Edge{int to,nex; Edge(){} Edge(int _to, int _nex){to=_to,nex=_nex;}}e[(MAXN<<1)+5];
inline void Add(int a, int b){e[tot] = Edge(b,first[a]), first[a] = tot++, e[tot] = Edge(a,first[b]), first[b] = tot++;}
void DFS_fa(int p){Trav(p) if((v=e[u].to)-fa[p]) fa[v] = p, DFS_fa(v);}
void DFS(int p){ql<=c[p]&&c[p]<=qr ? LASTANS += !g.count(c[p]), g[c[p]] = true : 0; Trav(p) if((v=e[u].to)-fa[p]) DFS(v);}
int main()
{
	freopen("xmastree1.in","r",stdin), freopen("xmastree1.out","w",stdout);
	n = read(), q = read(), TYPE = read(); for(rint i = 1; i <= n; c[i++] = read());
	memset(first+1,-1,n<<2); for(rint i = 2; i <= n; Add(read(),read()), i++);
	DFS_fa(1); for(rint o, u; q--; (o=read())<2 ? u=Read(),ql=Read(),qr=Read(),g.clear(),LASTANS=0,DFS(u),Out(LASTANS),Outc('\n') : (u=Read(),c[u]=Read()));
	_END; return 0;
}
