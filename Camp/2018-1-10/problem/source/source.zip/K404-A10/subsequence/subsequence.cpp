#include <bits/stdc++.h>

int dp[4003][4003];
int n,m,k;
int a[4003],b[4003];
int nexta[4003][4003],nextb[4003][4003];
int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i = 1;i <= n;++i) {
		scanf("%d",&a[i]);
		--a[i];
	}
	for(int i = 0;i < k;++i) nexta[n+1][i] = n + 1;
	for(int i = n;i >= 0;--i) {
		for(int j = 0;j < k;++j) nexta[i][j] = nexta[i+1][j];
		if(i > 0) nexta[i][a[i]] = i;
	}
	for(int i = 1;i <= m;++i) {
		scanf("%d",&b[i]);
		--b[i];
	}
	for(int i = 0;i < k;++i) nextb[m+1][i] = m + 1;
	for(int i = m;i >= 0;--i) {
		for(int j = 0;j < k;++j) nextb[i][j] = nextb[i+1][j];
		if(i > 0) nextb[i][b[i]] = i;
	}
	// dp[0][0..n-1] = 0
	for(int aa = 1;aa <= n + 1;++aa)
		dp[0][aa] = -1;
	dp[0][0] = 0;
	int ans = 0;
	for(int i = 0;i <= 10000;++i) {
		if(i > ans) continue;
		for(int aa = 0;aa <= n + 1;++aa)
			dp[i+1][aa] = -1;
		for(int aa = 0;aa <= n + 1;++aa) if(dp[i][aa] != -1) {
			for(int x = 0;x < k;++x) {
				int next1;
				if(aa == n + 1)
					next1 = n + 1;
				else
					next1 = nexta[aa+1][x];
				int next2;
				if(dp[i][aa] == m + 1)
					next2 = m + 1;
				else
					next2 = nextb[dp[i][aa]+1][x];
				if(next1 == n + 1 && next2 == m + 1) continue;
				ans = i + 1;
				if(dp[i+1][next1] < next2 || dp[i+1][next1] == -1) {
					dp[i+1][next1] = next2;
				}
			}
		}
		for(int aa = 1;aa <= n + 1;++aa)
			if(dp[i+1][aa] == -1 || (dp[i+1][aa-1] != -1 && dp[i+1][aa] < dp[i+1][aa-1]))
				dp[i+1][aa] = dp[i+1][aa-1];
	}
	printf("%d\n",ans);
			
}
