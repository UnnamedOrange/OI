#include<bits/stdc++.h>

using namespace std;

int main(){
	
	freopen("xmasdag.in", "w", stdout);

	srand(time(NULL));

	int n, m, k;
	
	n = 100000, m = n * 2 - 2, k = 30;

	printf("%d %d %d\n", n, m, k);
	for(int i = 2;i <= n; ++i){

		int x = rand() % (i-1) + 1;
		printf("%d %d\n", x, i);

		x = rand() % (i-1) + 1;
		printf("%d %d\n", x, i);
	}

	return 0;
}
