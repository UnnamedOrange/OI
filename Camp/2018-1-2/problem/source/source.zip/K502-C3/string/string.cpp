#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#define NN 100000+20
using namespace std;
void open(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
}
void close(){
	fclose(stdin);
	fclose(stdout);
}
char a[NN]={0};
bool all_same(int n){
	for(int i=1;i<n;++i){
		if(a[i]!=a[0])return false;
	}
	return true;
}
bool rev_str(int n){
	for(int i=0;i<n/2;++i){
		if(a[i]!=a[n-1-i]){
			return false;
		}
	}
	return true;
}
bool half_same(int n){
	if(n%2==0)return false;
	for(int i=1;i<n/2;++i){
		if(a[i]!=a[0]){
			return false;
		}
	}
	return true;
}
int solve(){
	int n;
	scanf("%d",&n);
	scanf("%s",a);
	if(all_same(n))return -1;
	if(rev_str(n)){
		if(half_same(n)){
			return -1;
		}
		else return 2;
	}
	return 1;
}
int main(){
	open();
	int T;
	scanf("%d",&T);
	while(T--){
		printf("%d\n",solve());
	}
	close();
	return 0;
}
