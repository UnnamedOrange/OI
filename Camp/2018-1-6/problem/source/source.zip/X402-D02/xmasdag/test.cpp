#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<ctime>

inline void read(int &x)
{
	char c=x=0;
	for(c=getchar();!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar())x=(x<<3)+(x<<1)+(c^48);
}

typedef long long ll;
const int N=101000,M=N*2,K=505,L=1200,MOD=998244353;
ll inv(int x){return x==1?1:(-(MOD/x)*inv(MOD%x)%MOD);}
ll qpow(ll a,ll b){ll c=1;for(;b;b>>=1,a=a*a%MOD)if(b&1)c=c*a%MOD;return c;}

int fact[K],ifact[K];
int dg[L];

namespace bf
{
	int alf[N][K];

	int begin[N],next[M],to[M];
	int n,m,k,e;

	int lim[N];
	void add(int x,int y)
	{
		lim[y]++;
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
	}
	void initialize()
	{
		read(n),read(m),read(k);
		for(int u,v;m--;)read(u),read(v),add(u,v);

		fact[0]=1;
		for(int i=1;i<K;i++)fact[i]=(ll)fact[i-1]*i%MOD;
		ifact[K-1]=inv(fact[K-1]);
		for(int i=K-1;i;i--)ifact[i-1]=(ll)ifact[i]*i%MOD;
	}
	int seq[N],tot;
	void topsort()
	{
		static std::queue<int> Q;
		while(!Q.empty())Q.pop();
		for(int i=1;i<=n;i++)if(!lim[i])Q.push(i);
		for(int p,q;!Q.empty();)
		{
			p=Q.front();Q.pop();
			seq[++tot]=p;
			for(int i=begin[p];i;i=next[i])
			{
				lim[q=to[i]]--;
				if(!lim[q])Q.push(q);
			}
		}
	}

	void dp()
	{
		static int g[L];

		alf[seq[1]][0]=1;
		for(int o=1;o<=n;o++)
		{
			int p=seq[o],q;
			for(int i=begin[p];i;i=next[i])
			{
				q=to[i];
				for(int j=
			}
		}
	}
	void solve()
	{
		initialize();
		topsort();
		dp();
		for(int i=1;i<=n;i++)
			printf("%d\n",f[i][k]);
	}
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	bf::solve();

	fprintf(stderr,"time = %lf\n",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
