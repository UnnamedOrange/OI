#include<cstdio>
#include<algorithm>
#define LL long long
using namespace std;
const int maxn = 2e3 + 5;
const int maxm = 5e3 + 5;
const int mod = 998244353;
int dp[maxn][maxm], n, m, k, a, b;
struct edge {
	int v, next;
}e[maxm];
int head[maxn], cnt, mnl[maxn], mxl[maxn], vis[maxn], f[maxn];
LL powk[maxm], ans;
void adde(const int &u, const int &v) {
	e[++cnt] = (edge) {v, head[u]};
	head[u] = cnt;
}
LL fpow(LL a, int b, LL p) {
	LL ans = 1;
	while(b) {
		if(b & 1) ans = ans * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return ans;
}
void dfs(int u) {
	vis[u] = 1;
	if(u == 1) return;
	for(register int i = head[u]; i; i = e[i].next) {
		int v = e[i].v;
		if(!vis[v]) dfs(v);
		mxl[u] = max(mxl[v] + 1, mxl[u]);
		for(register int j = 1; j <= mxl[u]; ++j)
			dp[u][j] += dp[v][j - 1];
	}
}
void topdp(int u) {
	vis[u] = 1;
	if(u == 1) return;
	for(register int i = head[u]; i; i = e[i].next) {
		int v = e[i].v;
		if(v == 1) f[u] += 1;
		if(!vis[v]) topdp(v);
		f[u] = (f[u] + f[v]) % mod;
	}
}
int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for(register int i = 1; i <= m; ++i) {
		scanf("%d%d", &a, &b);
		adde(b, a);
	}
	if(k != 0) {
		dp[1][0] = 1;
		for(register int i = 1; i <= n; ++i)
			mnl[i] = mxl[i] = 0;
		for(register int i = 1; i <= m; ++i)
			powk[i] = fpow(i, k, mod);
		for(register int i = 2; i <= n; ++i)
			if(!vis[i]) dfs(i);
		for(register int i = 1; i <= n; ++i) {
			ans = 0;
			for(register int j = 1; j <= mxl[i]; ++j)
				ans = (ans + dp[i][j] * powk[j] % mod) % mod;
			printf("%d\n", ans);
		}
	} else {
		for(register int i = 1; i <= n; ++i)
			if(!vis[i]) topdp(i);
		for(register int i = 1; i <= n; ++i) {
			printf("%d\n", f[i] % mod);
		}
	}
	return 0;
}
