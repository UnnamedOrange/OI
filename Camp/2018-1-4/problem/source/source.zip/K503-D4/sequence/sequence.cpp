#include<bits/stdc++.h>
#define mod1 999983
#define mod2 1000007
#define N 3600000
using namespace std;
int head[mod1],next[N],a[N],tot,zt[N][11],dep[N],tmp[20],x[20],flag;
void enter(int u, int v)
{
	tot++; a[tot]=v; next[tot]=head[u]; head[u]=tot;
}
int cx(int u, int v)
{
	for (int i=head[u];i;i=next[i])
		if (v==a[i]) return i;
	return 0;
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--)
	{
		memset(head,0,sizeof(head)); flag=1;
		tot=0;
		int n;
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
		{
			scanf("%d",&x[i]);
			if (x[i]!=i) flag=0;
		}
		if (flag) {puts("0"); continue;}
		int key1=0,key2=0;
		for (int i=1;i<=n;i++)
		{
			key1=(key1*(n+1)+x[i])%mod1;
			key2=(key2*(n+1)+x[i])%mod2;
		}
		tot=1; enter(key1,key2);
		int lef=1,righ=1;
		for (int i=1;i<=n;i++)
			zt[1][i]=x[i];
		while (lef<=righ)
		{
			for (int i=1;i<=n;i++)
				tmp[i]=zt[lef][i];
			for (int i=2;i<=n;i++)
			{
				for (int j=1;2*j<=i;j++)
					swap(tmp[j],tmp[i-j+1]);
				key1=0; key2=0;
				for (int j=1;j<=n;j++)
				{
					key1=(key1*(n+1)+tmp[j])%mod1;
					key2=(key2*(n+1)+tmp[j])%mod2;
				}
				if (cx(key1,key2)==0)
				{
					int check=1;
					enter(key1,key2);
					righ++;
					for (int j=1;j<=n;j++)
						zt[righ][j]=tmp[j];
					for (int j=1;j<=n;j++)
						if (tmp[j]!=j) {check=0; break;}
					dep[righ]=dep[lef]+1;
					if (check)
					{
						printf("%d\n",dep[righ]);
						flag=1; break;
					}
				}
				for (int j=1;2*j<=i;j++)
					swap(tmp[j],tmp[i-j+1]);
			}
			if (flag) break;
			lef++;
		}
	}
	return 0;
}
