//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=1e6+7;
typedef long long LL;
using namespace std;
int T,p[N],bo[N];
LL n,ans,dt[N],mu[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1; 
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f; 
}

void get_prime() {
	int up=1000000; mu[1]=dt[1]=1;
	for(int i=2;i<=up;i++) {
		if(!bo[i]) {p[++p[0]]=i; mu[i]=-1; dt[i]=2;}
		for(int j=1;j<=p[0]&&p[j]*i<=up;j++) {
			bo[p[j]*i]=1;
			if(i%p[j]==0) {
				int tp=p[j],x=i,k=1;
				while(x%p[j]==0) {
					x/=p[j];
					tp*=p[j]; 
					k++;
				}
				mu[i*p[j]]=0;
				if(x!=1) dt[i*p[j]]=dt[tp]*dt[x];
				else dt[i*p[j]]=k+1;
				break;
			}
			else {
				mu[p[j]*i]=-mu[i];
				dt[p[j]*i]=dt[i]*dt[p[j]];
			}
		}
	}
	for(int i=2;i<=up;i++) mu[i]+=mu[i-1];
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
#endif
	read(T);
	get_prime();
	while(T--) {
		read(n);
		ans=0;
		for(int i=1;i<=n;i++) 
			ans+=dt[i]*dt[i]*mu[n/i];
		printf("%lld\n",ans);
	}
	return 0;
}
/*
1
233333
*/
