#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int MAXB = 1e7;
char buf[MAXB], *cp = buf;
inline void rd(int &x){
	x = 0;
	while(*cp < '0' || '9' < *cp) cp++;
	while('0' <= *cp && *cp <= '9') x = x * 10 + *cp++ - 48;
}
int type, N;
int f[1 << 10];
void init(){
    for(int i = 1; i < 1024; i++){f[i] = (i & 1) ? 1 : f[i >> 1] + 1;}
}
int encode(int x, int y){
	int z = x ^ y;
	return f[z] + ((x >> (f[z] - 1)) & 1) * 10;
}
bool decode(int q, int h){
	int a, b;
	if(h > 10) a = 1, b = h - 10;
	else a = 0, b = h;
    return ((q >> (b - 1)) & 1) == a;
}
int main(){
	//freopen("in.txt", "r", stdin);
	buf[fread(buf, 1, MAXB, stdin)] = 0;
    int T;
    rd(type); rd(N); rd(T);
    //scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--){
        int x, y;
        rd(x); rd(y);
        //scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
    return 0;
}
