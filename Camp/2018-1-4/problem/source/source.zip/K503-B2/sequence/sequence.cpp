#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
int a[100];
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int n,t;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		int maxx=n,ans=0,num=1;
		while(num!=n){
			num=1;
			for(int i=1;i<=n;i++) if(a[i+1]-a[i]==1) num++;
			if(num==n) break;
			for(int i=1;i<=n;i++)
				if(a[maxx]==maxx) maxx--;
				else break;
			int s=maxx;
			while(1)
				if(a[s]!=maxx) s--;
				else break;
			if(a[s]==maxx&&s>1){
				for(int i=1;i<=s/2;i++) swap(a[i],a[s-i+1]);
				ans++;
				continue;
			}
			if(a[1]==maxx){
				s=maxx;
				for(int i=1;i<=s/2;i++) swap(a[i],a[s-i+1]);
				ans++;
				continue;
			}
		}
		printf("%d\n",ans);
	}
}
