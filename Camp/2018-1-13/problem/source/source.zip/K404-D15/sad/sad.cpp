#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
const int mod=998244353;

int n,tot,cnt;
int now[maxn],pre[maxn*2],son[maxn*2],deg[maxn*2],seq[maxn],f[maxn];
char s[maxn];

void add(int a,int b){son[++tot]=b,pre[tot]=now[a],now[a]=tot;}
void link(int a,int b){add(a,b),add(b,a);}

void dfs(int x,int fa){
	seq[++cnt]=x;
	for (int p=now[x];p;p=pre[p])
		if (son[p]!=fa) dfs(son[p],x);
}

int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	scanf("%d%s",&n,s+1);
	for (int i=1,x,y;i<n;i++){
		scanf("%d%d",&x,&y);
		link(x,y),++deg[x],++deg[y];
	}
	for (int i=1;i<=n;i++) if (deg[i]==1){dfs(i,0); break;}
	f[1]=1,f[2]=n-1;
	for (int i=3;i<=n;i++) f[i]=((f[i-1]<<1)%mod-f[i-2]-2)%mod;
	for (int i=1;i<=n;i++) if (seq[i]==1){printf("%d\n",(f[i]+mod)%mod); return 0;}
	return 0;
}
