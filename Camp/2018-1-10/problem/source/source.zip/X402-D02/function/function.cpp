#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<map>

namespace bf
{
	typedef long long ll;
	const int N=10100000;
	bool isit[N];
	int pri[N/10],minc[N],tot;
	int mu[N],D[N];

	void get_pri()
	{
		mu[1]=D[1]=1;
		for(int i=2;i<N;i++)
		{
			if(!isit[i])pri[++tot]=i,mu[i]=-1,D[i]=2,minc[i]=1;
			for(int j=1,x;(x=i*pri[j])<N;j++)
			{
				isit[x]=1;

				if(i%pri[j])
				{
					mu[x]=-mu[i];
					D[x]=D[i]*2;
					minc[x]=1;
				}
				else 
				{
					mu[x]=0;
					D[x]=D[i]/(minc[i]+1)*(minc[i]+2);
					minc[x]=minc[i]+1;
					break;
				}
			}
		}
	}

	int Mu[N],Mu2[N];

	void initialize()
	{
		for(int i=1;i<N;i++)
		{
			D[i]+=D[i-1];
			Mu[i]=Mu[i-1]+mu[i];
			Mu2[i]=Mu2[i-1]+mu[i]*mu[i];
		}
	}

	ll MU(int n)
	{
		if(n<N)return Mu2[n];
		ll ret=0;
		for(int i=1;i*i<=n;i++)
			ret+=(ll)mu[i]*(n/i/i);
		return ret;
	}

	std::map<int,ll> M0,M1;

	ll sum_mu(int n)
	{
		if(n<N)return Mu[n];
		if(M0.count(n))return M0[n]; 

		ll ret=1;
		for(int L=2,R,k;L<=n;L=R+1)
		{
			k=n/L,R=n/k;
			ret-=(ll)(R-L+1)*sum_mu(k);
		}
		return M0[n]=ret;
	}

	ll sum_d(int n)
	{
		if(n<N)return D[n];
		if(M1.count(n))return M1[n]; 
		
		ll ret=n;
		for(int L=2,R,k;L<=n;L=R+1)
		{
			k=n/L,R=n/k;
			ret-=(sum_mu(R)-sum_mu(L-1))*sum_d(k);
		}
		return M1[n]=ret;
	}

	ll query(int n)
	{
		ll ret=0;

		for(int L=1,R,k;L<=n;L=R+1)
		{
			k=n/L,R=n/k;
			ret+=(MU(R)-MU(L-1))*sum_d(k);
		}

		return ret;
	}

	void solve()
	{
		get_pri();
		initialize();

//		query(1000000000);
		
		int T,n;
		for(scanf("%d",&T);T--;)
		{
			scanf("%d",&n);
			printf("%lld\n",query(n));
		}
	}
}

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	bf::solve();
	return 0;
}
