#include <cmath> 
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

#define LL long long

const int mod = 1000000007;
const int N = 1000000 + 1000;

LL n, c[N], d[N];
LL f[21][N], g[21][N];
LL F[N], G[N];

namespace file{
	inline void open()
	{
		freopen("schooldays.in", "r", stdin);
		freopen("schooldays.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

namespace input{
	inline LL read()
	{
		LL a = 0;
		char ch;
		LL f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}
	
	inline void Get()
	{
		n = read();
		for(int i = 1;i <= n;++i)
			c[i] = read(), d[i] = read();
	}
}

namespace brute{
	inline void init()
	{
		for(int i = 1;i <= n;++i)
			f[0][i] = c[i], g[0][i] = d[i];
		for(int j = 1;j <= 20;++j)
			for(int i = 1;i <= n;++i)
			{
				f[j][i] = max(f[j - 1][i], f[j - 1][i + (1 << (j - 1))]);
				g[j][i] = min(g[j - 1][i], g[j - 1][i + (1 << (j - 1))]);
			}
	}
	
	inline LL chkmax(int l, int r)
	{
		if(l == r)
			return f[0][l];
		int mi = r - l + 1;
		int L = log2(mi);
		return max(f[L][l], f[L][r - (1 << L) + 1]);
	}
	
	inline LL chkmin(int l, int r)
	{
		if(l == r)
			return g[0][l];
		int mi = r - l + 1;
		int L = log2(mi);
		return min(g[L][l], g[L][r - (1 << L) + 1]);
	}
	
	inline void solve()
	{
		init();
		memset(F, 0, sizeof F);
		memset(G, -1, sizeof G);
		F[0] = 0, G[0] = 1;
		for(int i = 1;i <= n;++i)
			for(int j = 0;j < i;++j)
			{
				LL A = chkmax(j + 1, i);
				LL B = chkmin(j + 1, i);
				if(A > i - j || B < i - j)
					continue;
				if(F[j] + 1 > F[i])
					F[i] = F[j] + 1, G[i] = G[j];
				else if(F[j] + 1 == F[i])
					(G[i] += G[j]) %= mod;
			}
		if(G[n] == -1)
			printf("%d\n", -1);
		else
			printf("%lld %lld\n", F[n], G[n]);
	}
}

namespace check{
	inline void deter()
	{
		brute::solve();
	}
}

int main()
{
	open();
	input::Get();
	check::deter();
	close();
	return 0;
}
/*
9
1 4
2 5
3 4
1 5
1 1
2 5
3 5
1 3
1 1
*/
