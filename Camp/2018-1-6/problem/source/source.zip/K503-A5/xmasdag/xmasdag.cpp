#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M(998244353);
struct Edge {
	int to; Edge *nxt;
}pool[200100], *tot=pool, *G[100100];
void add(int u, int v) {
	(++tot)->to=v, tot->nxt=G[u], G[u]=tot;
}
int power(int x, int y) {
	int ans=1;
	for (;y;y>>=1) {
		if (y&1)
			ans=(ll)ans*x%M;
		x=(ll)x*x%M;
	} 
	return ans;
}
int ans[100100];
int main() {
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout); 
	ios::sync_with_stdio(false);
	int n, m, k;
	cin >> n >> m >> k;
	for (int i=1;i<=m;i++) {
		int u,v;
		cin >> u >> v;
		add(u,v);
	}
	queue<pair<int, int> > Q;
	Q.push(make_pair(1,0));
	while (!Q.empty()) {
		int x=Q.front().first;
		int step=Q.front().second;
		Q.pop();
		int tmp=power(step+1,k);
		for (Edge *p=G[x];p;p=p->nxt) {
			ans[p->to]+=tmp;
			Q.push(make_pair(p->to,step+1));
		}
	}
	for (int i=1;i<=n;i++) {
		cout << ans[i] << endl;
	}
	return 0;
}

