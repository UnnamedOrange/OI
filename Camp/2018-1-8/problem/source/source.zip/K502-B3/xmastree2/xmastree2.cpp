#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;

#define ll long long int

const int maxn=30001;
ll first[maxn],next[maxn*2],to[maxn*2],w[maxn],r[maxn],dp[maxn],vis[maxn];
ll n,cnt,ans,cur,t;

void clear()
{
	memset(first,-1,sizeof(first));
	cnt=0;
	ans=0;
}

inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void add(ll u,ll v)
{
	next[cnt]=first[u];
	first[u]=cnt;
	to[cnt]=v;
	cnt++;
}

void check(ll x,ll fa)
{
	ll i;
	for(i=first[x];i!=-1;i=next[i])
	{
		if(to[i]==fa)
			continue;
		if(dp[to[i]]<=dp[x])
		{
			t=1;
			return;
		}
		check(to[i],x);
		if(t==1)
			return;
	}
} 

void find(ll x,ll sum)
{
	if(x==n+1)
	{
		t=0;
		check(cur,0);
		if(!t)
			ans=(ll)max(ans,sum);
		return;
	}
	if(x==cur)
		find(x+1,sum);
	ll i;
	for(i=1;i<=n;i++)
	{
		if(!vis[i])
		{
			dp[x]=i;
			vis[i]=1;
			find(x+1,sum+w[x]*i);
			vis[i]=0;
		}
	}
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	clear();
	n=read();
	ll i;
	for(i=1;i<=n-1;i++)
	{
		ll ui=read(),vi=read();
		add(ui,vi);
		add(vi,ui);
	}
	for(i=1;i<=n;i++)
	{
		w[i]=read();
		r[i]=read();
	}
	for(i=1;i<=n;i++)
	{
		if(r[i]==1)
		{
			memset(dp,0,sizeof(dp));
			memset(vis,0,sizeof(vis));
			dp[i]=1;
			vis[1]=1;
			cur=i;
			find(1,w[i]);
		}
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
