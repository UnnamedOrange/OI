#include <bits/stdc++.h>
using namespace std;

int n;
int Dp[1 << 12];
int Go[12][12];

int GetDp(int mask) {
	if (Dp[mask] != -1) {
		return Dp[mask];
	} else {
		int& v = Dp[mask];
		v = 0x3FFFFFFF;
		for (int i = mask; i; i = (i - 1) & mask) {
			bool ok = true;
			for (int x = 0; x < n && ok; ++x) {
				if (i & (1 << x)) {
					for (int y = x + 1; y < n && ok; ++y) {
						if (i & (1 << y)) {
							if (Go[x][y] || Go[y][x]) {
								ok = false;
							}
						}
					}
				}
			}
			if (ok) {
				v = min(v, GetDp(mask ^ i) + 1);
			}
		}
		return v;
	}
}

int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	int m;
	cin >> n >> m;
	for (int i = 0; i < m; ++i) {
		int x, y;
		cin >> x >> y;
		Go[x - 1][y - 1] = 1;
	}
	for (int k = 0; k < n; ++k) {
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				Go[i][j] |= Go[i][k] & Go[k][j];
			}
		}
	}
	memset(Dp, 0xFF, sizeof(Dp));
	Dp[0] = 0;
	cout << GetDp((1 << n) - 1);
}
