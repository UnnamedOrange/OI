#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#define ll long long
using namespace std;
int read()
{
	char ch=getchar();int f=0,x=1;
	while(ch<'0'||ch>'9'){if(ch=='-') x=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){f=(f<<1)+(f<<3)+ch-'0';ch=getchar();}
	return f*x;
}
struct data
{
	int x;
	int y;
};
queue<data> q;
int n,m,k;
int a[100005],b[100005];
int last[100005];
int f[4005][4005];
int c[4005][4005],d[4005][4005];
void bfs()
{
	while(!q.empty())
	{
		data x=q.front();
		q.pop();
		if(x.x==n+1&&x.y==m+1)
		{
			cout<<f[n+1][m+1];
			return;
		}
		for(int i=1;i<=k;i++)
		{
			if(!f[c[x.x][i]][d[x.y][i]])
			{
				f[c[x.x][i]][d[x.y][i]]=f[x.x][x.y]+1;
				data temp;
				temp.x=c[x.x][i],temp.y=d[x.y][i];
				q.push(temp);
			}
		}
	}
}
int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++) b[i]=read();
	for(int i=1;i<=k;i++) last[i]=n+1;
	for(int i=n+1;i>=0;i--)
	{
		for(int j=1;j<=k;j++)
		{
			c[i][j]=last[j];
		}
		last[a[i]]=i;
	}
	for(int i=1;i<=k;i++) last[i]=m+1;
	for(int i=m+1;i>=0;i--)
	{
		for(int j=1;j<=k;j++)
		{
			d[i][j]=last[j];
		}
		last[b[i]]=i;
	}
	data temp;
	temp.x=temp.y=0;
	q.push(temp);
	bfs();
	return 0;
}

