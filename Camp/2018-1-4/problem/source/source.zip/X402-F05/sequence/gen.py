from random import *

f = open('sequence.in', 'w')

Case = 10
f.write('{}\n'.format(Case))


for i in range(0, Case):
	n = randint(22, 23)
	f.write('{}\n'.format(n))

	P = []

	for j in range(0, n):
		P.append(j + 1)
		x = randint(0, j)
		P[j], P[x] = P[x], P[j]
	
	for j in range(0, n):
		f.write('{} '.format(P[j]))
	f.write('\n')

