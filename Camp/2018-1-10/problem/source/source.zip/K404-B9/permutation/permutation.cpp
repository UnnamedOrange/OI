#include<bits/stdc++.h>
using namespace std;

int n,a[111111],vis[111111],dis[111111];
long long ans=0;

bool Judge()
{
	int emm[11]={0},Now=1;
	for (int i=1;i<=n;i++)
	  {
	  	if (!emm[i])
	  	  {
	  	  	int cnt=0;
	  	  	for (Now=i;!emm[Now];Now=a[Now]) emm[Now]=1,cnt++;
	  	  	if (cnt%2) return false;
		  }
	  }
	return true;  
}

void dfs(int x)
{
	if (x==n+1) 
	  if (Judge()) 
	    {
	      ans++;
	      return;
		}
	if (!vis[x])
	  {
	  	for (int i=1;i<=n;i++)
	  	  {
	  	  	if (!dis[i]) 
	  	  	  {
	  	  	  	a[x]=i,dis[i]=1;
	  	  	  	dfs(x+1);
	  	  	  	a[x]=0,dis[i]=0;
			  }
		  }
	  }
	else dfs(x+1);  
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i) 
	  {
	  	scanf("%d",&a[i]);
		if (a[i]) vis[i]=1,dis[a[i]]=1;
	  }
	if (n%2) 
	  {
	  	printf("0");
	  	return 0;
	  } 
	if (n<=8)
	  {
	  	dfs(1);
	  	printf("%lld",ans);
	  }  
	else
	  {
	  	ans=1;
	  	for (int i=1;i<=n;i+=2)
	  	  {
	  	  	ans=ans*i*i;
	  	  	if (ans>998244353) ans=ans%998244353;
		  }
		printf("%lld",ans);
		return 0;  
	  }  
	return 0;  
}
