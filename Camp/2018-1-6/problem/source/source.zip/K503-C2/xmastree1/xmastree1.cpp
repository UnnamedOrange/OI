#include <stdio.h>
#define maxn 100010
int head[maxn],e[maxn*2][2],c[maxn],n,q,i,j,t,x,y,z,k=0,last=0;
bool mark[maxn],b[maxn];
void addedge(int x,int y)
{
	e[++k][1]=y;
	e[k][0]=head[x];
	head[x]=k;
}
int dfs(int x,int y,int l,int r,int k)
{
	int i,ans=0;
	mark[x]=false;
	if (x==y) k=1;
	if (k && (c[x]>=l) && (c[x]<=r) && b[c[x]])
	{
		ans++;
		b[c[x]]=false;
	}
	for (i=head[x];i>0;i=e[i][0])
		if (mark[e[i][1]]) ans+=dfs(e[i][1],y,l,r,k);
	return ans;
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for (i=1;i<=n;i++)
		scanf("%d",&c[i]);
	for (i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		addedge(x,y);
		addedge(y,x);
	}
	for (i=1;i<=q;i++)
	{
		scanf("%d",&x);
		if (x==1)
		{
			scanf("%d%d%d",&x,&y,&z);
			if (t)
			{
				x^=last;
				y^=last;
				z^=last;
			}
			for (j=1;j<=n;j++)
				mark[j]=b[j]=true;
			last=dfs(1,x,y,z,0);
			printf("%d\n",last);
		}
		else
		{
			scanf("%d%d",&x,&y);
			c[x]=y;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
