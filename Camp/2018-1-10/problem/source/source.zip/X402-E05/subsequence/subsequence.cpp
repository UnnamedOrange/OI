#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=4010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
}
int n,m,K,a[N],b[N];
int dp[N][N];
int A[N][N],B[N][N];
int main()
{
	file();
	read(n),read(m),read(K);
	For(i,1,n)read(a[i]);
	For(i,1,m)read(b[i]);
	For(i,1,K)A[n][i]=n+1;
	rFor(i,n-1,0)
	{
		memcpy(A[i],A[i+1],sizeof(A[i]));
		A[i][a[i+1]]=i+1;
	}
	For(i,1,K)B[m][i]=m+1;
	rFor(i,m-1,0)
	{
		memcpy(B[i],B[i+1],sizeof(B[i]));
		B[i][b[i+1]]=i+1;
	}
	/*
	For(i,0,m)For(j,1,K)printf("%d %d:%d\n",i,j,B[i][j]);
	puts("");
	For(i,0,n)For(j,1,K)printf("%d %d:%d\n",i,j,A[i][j]);
	*/
	queue<pii>q;
	q.push(pii(0,0));
	dp[0][0]=1;
	while(!q.empty())
	{
		pii now=q.front();q.pop();
		int x=now.first,y=now.second;
		//printf("(%d %d) %d\n",x,y,dp[x][y]);
		For(i,1,K)
		{
			int nx=A[x][i],ny=B[y][i];
			if(!dp[nx][ny])
			{
				dp[nx][ny]=dp[x][y]+1;
				q.push(pii(nx,ny));
				if(nx==n+1&&ny==m+1)
				{
					printf("%d\n",dp[nx][ny]-1);
					//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
					//assert((double)clock()/CLOCKS_PER_SEC<=1.0);
					exit(0);
				}
			}
		}
	}
	return 0;
}
