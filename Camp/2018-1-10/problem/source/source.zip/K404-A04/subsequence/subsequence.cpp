#include<iostream>
#include<cstdio>
#include<cstring>
#define fs first
#define sc second
#define pss pair<short,short>
using namespace std;
int n[2],k,s[2][4010],lst[4010];
short nxt[2][4010][4010],d[4010][4010];
bool vis[4010][4010];
pss dl[16000010];
void bfs()
{
	dl[1]=make_pair(0,0);vis[0][0]=1;
	for(int hd=1,tl=1;hd<=tl;hd++)
	{
		pss v=dl[hd];
		//cout<<v.fs<<' '<<v.sc<<' '<<d[v.fs][v.sc]<<endl;
		if(v.fs>n[0]&&v.sc>n[1]) break;
		for(int i=1;i<=k;i++)
		{
			int c0=nxt[0][v.fs][i],c1=nxt[1][v.sc][i];
			if(!vis[c0][c1])
			{
				vis[c0][c1]=1;
				dl[++tl]=make_pair(c0,c1);
				d[c0][c1]=d[v.fs][v.sc]+1;
			}
		}
	}
}
int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n[0],&n[1],&k);
	for(int t=0;t<=1;t++)	
		for(int i=1;i<=n[t];i++)
			scanf("%d",&s[t][i]);
	for(int t=0;t<=1;t++)
	{
		for(int i=1;i<=k;i++)
		 	lst[i]=n[t]+1,nxt[t][n[t]+1][i]=n[t]+1;
		for(int i=n[t];i>=0;i--)
		{
			for(int j=1;j<=k;j++)
				nxt[t][i][j]=lst[j];
			lst[s[t][i]]=i;		
		}
	}
	bfs();
	printf("%d",d[n[0]+1][n[1]+1]);
	return 0;
}
