#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1e5+10,MAX=2e7+10;
int n,q,col[MAXN],head[MAXN],cnt,fa[MAXN];
bool vis[MAXN];
struct edge
{
	int v,next;
}e[MAXN*2];
void addedge(int x,int y)
{
	e[++cnt]=(edge){y,head[x]};
	head[x]=cnt;
	return;
}
void dfs1(int u,int lst)
{
	fa[u]=lst;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].v;
		if(v==lst)continue;
		dfs1(v,u);
	}
	return;
}
int query(int u,int l,int r)
{
	int ret=0;
	if(col[u]>=l&&col[u]<=r)
		if(!vis[col[u]])++ret,vis[col[u]]=true;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].v;
		if(v==fa[u])continue;
		ret+=query(v,l,r);
	}
	return ret;
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.outt","w",stdout);
	n=read();q=read();int t=read();
	for(int i=1;i<=n;++i)col[i]=read();
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read();
		addedge(x,y);addedge(y,x);
	}
	dfs1(1,0);
	int lstans=0;
	while(q--)
	{
		int opt=read();
		if(opt==1)
		{
			int x=read()^lstans,l=read()^lstans,r=read()^lstans;
			memset(vis,0,sizeof(vis));
			printf("%d\n",lstans=query(x,l,r));
			if(!t)lstans=0;
		}
		else
		{
			int x=read()^lstans,c=read()^lstans;
			col[x]=c;
		}
	}
	return 0;
}
