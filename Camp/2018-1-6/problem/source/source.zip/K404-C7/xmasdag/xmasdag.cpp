#include <bits/stdc++.h>
using namespace std;

const int MOD = 998244353;

int Pow[100010];
int In[100010];
vector<int> Back[100010];
map<int, int> Key[100010];

int Ksm(int a, int b) {
	int r = 1;
	while (b) {
		if (b & 1) {
			r = (long long)r * a % MOD;
		}
		a = (long long)a * a % MOD;
		b >>= 1;
	}
	return r;
}

int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	int n, m, k;
	cin >> n >> m >> k;
	Key[1][0] = 1;
	for (int i = 1; i <= n; ++i) {
		Pow[i] = Ksm(i, k);
	}
	while (m--) {
		int x, y;
		cin >> x >> y;
		Back[x].push_back(y);
		++In[y];
	}
	queue<int> Q;
	Q.push(1);
	while (Q.size()) {
		int p = Q.front();
		Q.pop();
		for (vector<int>::iterator it = Back[p].begin(); it != Back[p].end(); ++it) {
			for (map<int, int>::iterator pr = Key[p].begin(); pr != Key[p].end(); ++pr) {
				Key[*it][pr->first + 1] += pr->second;
			}
			if (!--In[*it]) {
				Q.push(*it);
			}
		}
	}
	for (int i = 1; i <= n; ++i) {
		int ans = 0;
		for (map<int, int>::iterator it = Key[i].begin(); it != Key[i].end(); ++it) {
			ans = ((long long)Pow[it->first] * it->second + ans) % MOD;
		}
		cout << ans << endl;
	}
}
