/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int mod = 998244353;
const int MAXN = 360 + 10;
int n, m, k, ans;
int a[MAXN];
int dp[MAXN][MAXN], sum[MAXN][MAXN], f[MAXN][MAXN], sum1[MAXN][MAXN], sum2[MAXN][MAXN];

inline int mod_pow(int a, int b) {
	int ans = 1;
	for (; b; b >>= 1, a = (long long)a * a % mod)
		if (b & 1) ans = (long long)ans * a % mod;
	return ans;
}

inline void add(int &x, int t) {
	x += t, (x >= mod) ? (x -= mod) : (x);
}

inline void dfs(int cur, int l, int r) {
	if (cur == n + 1) {
		for (int i = 1; i <= m; ++i) 
			add(ans, mod_pow(a[i], k));
		return ;
	}
	for (int i = l + 1; i <= m; ++i)
		for (int j = std::max(i, r + 1); j <= m; ++j) {
			for (int k = i; k < j; ++k) a[k]++;
			dfs(cur + 1, i, j);
			for (int k = i; k < j; ++k) a[k]--;
		}
}

inline void solve() {
	R(n), R(m), R(k);
	if (n == 1) {
		for (int i = 1; i <= n; ++i)
			add(ans, ((long long)i * (long long)(i - 1) / 2LL) % mod);
		std::cout << ans, exit(0);
	}
	if (k == 1) {
		for (int i = 1; i <= m; ++i)
			for (int j = i; j <= m; ++j)
				dp[i][j] = 1, f[i][j] = j - i;
		for (int i = 2; i <= n; ++i) {
			for (int j = 1; j <= m; ++j) {
				int temp1 = 0, temp2 = 0;
				for (int k = j; k <= m; ++k) {
					add(temp1, dp[j][k]), add(temp2, f[j][k]);
					sum1[j][k] = temp1, sum2[j][k] = temp2;
					add(sum1[j][k], sum1[j - 1][k]);
					add(sum2[j][k], sum2[j - 1][k]);
				}
			}
			for (int j = 1; j <= m; ++j)
				for (int k = j; k <= m; ++k) {
					dp[j][k] = sum1[j - 1][k - 1];
					f[j][k] = sum2[j - 1][k - 1];
					add(f[j][k], (long long)(k - j) * dp[j][k] % mod);
				}
		}
		for (int i = 1; i <= m; ++i)
			for (int j = i; j <= m; ++j)
				add(ans, f[i][j]);
		std::cout << ans, exit(0);
	}
	dfs(1, 0, 0), std::cout << ans, exit(0);
}

int main() {
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	solve();
	return 0;
}
