/*****************************************************
	File:success.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-13 09:46:48
*****************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define mod 1000000007
#define N 110
int s,t,n,m,f[N][N],ans;
int main()
{
	freopen("success.out","w",stdout);
	freopen("success.in","r",stdin);
	s=read();	
	t=read();
	n=read();
	m=read();
	f[0][0]=1;
	fr(i,1,m)
		fr(j,1,s)
		{
			if(i<=n)
				fr(k,max(j-t,0),j-1)
					f[i][j]=(f[i][j]+f[i-1][k])%mod;
			else
				fr(k,0,j-1)
					f[i][j]=(f[i][j]+f[i-1][k])%mod;
			if(i==m)
				ans=(ans+f[i][j])%mod;
//			printf("%d%c",f[i][j],j==s?'\n':' ');
		}
	printf("%d\n",ans);
	return 0;
}