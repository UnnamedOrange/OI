#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int ty,n,ca;
int main()
{
	scanf("%d%d%d",&ty,&n,&ca);
	if(ty==1)
	{
		while(ca--)
		{
			int x,y,re=0;
			scanf("%d%d",&x,&y);
			for(;(x&1)==(y&1);x>>=1,y>>=1) re++;
			printf("%d\n",re+(x&1)*10+1);
		}
	}
	else
	{
		while(ca--)
		{
			int q,h;
			scanf("%d%d",&q,&h);h--;
			//cout<<"decode:"<<h%10<<' '<<h/10<<endl;
			if(((q>>(h%10))&1)==(h/10)) puts("yes");
			else puts("no");
		}
	}
	return 0;
}
/*1
5 6
1 2
4 5
1 2
3 5
4 5
5 2

2
5 6
1 11
4 1
2 11
3 12
5 1
2 11*/
