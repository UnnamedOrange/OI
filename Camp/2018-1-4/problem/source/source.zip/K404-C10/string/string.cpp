#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;
#define Mod 998244353
#define N 10
int g[150000][70],f[2][1205][70],i,j,k,mask,len[N],ch[150000][2],id,c[150000],qq,d[150000],dep[150000],nxt[150000],trans[150000][2],n,m;
char s[N][105];
queue<int> q;
vector<int> v[505];
inline void init()
{
	int now=0;
	for (j=0;j<len[i];j++){
		if (!ch[now][s[i][j]-'0']) ch[now][s[i][j]-'0']=++id;
		now=ch[now][s[i][j]-'0'];
	}c[now]|=1<<i;now=0;
	for (j=len[i]-1;j>=0;j--){
		if (!ch[now][(s[i][j]-'0')^1]) ch[now][(s[i][j]-'0')^1]=++id;
		now=ch[now][(s[i][j]-'0')^1];
	}c[now]|=1<<i;
}
inline void get_nxt()
{
	for (int ii=0;ii<=1;ii++) if (ch[0][ii]) dep[ch[0][ii]]=1,q.push(ch[0][ii]);
	while (!q.empty()){
		int psz=q.front();q.pop();
		if (psz>qq) v[dep[psz]+1].push_back(psz);
		c[psz]|=c[nxt[psz]];
		trans[psz][0]=(ch[nxt[psz]][0]&&ch[nxt[psz]][0]<=qq)?ch[nxt[psz]][0]:trans[nxt[psz]][0];
		trans[psz][1]=(ch[nxt[psz]][1]&&ch[nxt[psz]][1]<=qq)?ch[nxt[psz]][1]:trans[nxt[psz]][1];
		for (int ii=0;ii<=1;ii++) if (ch[psz][ii]){
			int j=nxt[psz];dep[ch[psz][ii]]=dep[psz]+1;
			while (j&&!ch[j][ii]) j=nxt[j];
			if (ch[j][ii]) nxt[ch[psz][ii]]=ch[j][ii];
			q.push(ch[psz][ii]);
		}
	}
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (i=0;i<n;i++) scanf("%s",s[i]),len[i]=strlen(s[i]),init();qq=id;
	for (i=0;i<n;i++)
	for (j=0;j<len[i]-1;j++){
		bool zw=false;
		for (k=0;k<=min(j,len[i]-2-j);k++) if (s[i][j-k]==s[i][j+k+1]){
			zw=true;break;
		}if (zw) continue;
		if (j>len[i]-2-j){
			int now=0;
			for (k=j;k>=0;k--){
				if (!ch[now][(s[i][k]-'0')^1]) ch[now][(s[i][k]-'0')^1]=++id;
				now=ch[now][(s[i][k]-'0')^1];
			}d[now]|=1<<i;
		}else{
			int now=0;
			for (k=1;k<=len[i]-1-j;k++){
				if (!ch[now][s[i][j+k]-'0']) ch[now][s[i][j+k]-'0']=++id;
				now=ch[now][s[i][j+k]-'0'];
			}d[now]|=1<<i;
		}
	}get_nxt();f[1][0][0]=1;
	for (i=1;i<=m;i++){
		memset(f[i+1&1],0,sizeof(f[i+1&1]));
		for (j=0;j<=qq;j++)
		for (mask=0;mask<(1<<n);mask++)
		for (k=0;k<=1;k++){
			if (ch[j][k]&&ch[j][k]<=qq) f[i+1&1][ch[j][k]][i==dep[j]+1?(mask|c[ch[j][k]]|d[ch[j][k]]):(mask|c[ch[j][k]])]=(f[i+1&1][ch[j][k]][i==dep[j]+1?(mask|c[ch[j][k]]|d[ch[j][k]]):(mask|c[ch[j][k]])]+f[i&1][j][mask])%Mod;
			else if (ch[j][k]>qq&&i==dep[j]+1) g[ch[j][k]][mask|c[ch[j][k]]|d[ch[j][k]]]=(g[ch[j][k]][mask|c[ch[j][k]]|d[ch[j][k]]]+f[i&1][j][mask])%Mod;
			else f[i+1&1][trans[j][k]][mask|c[trans[j][k]]]=(f[i+1&1][trans[j][k]][mask|c[trans[j][k]]]+f[i&1][j][mask])%Mod;
		}
		for (j=0;j<v[i].size();j++)
		for (mask=0;mask<(1<<n);mask++)
		for (k=0;k<=1;k++){
			if (ch[v[i][j]][k]) g[ch[v[i][j]][k]][mask|c[ch[v[i][j]][k]]|d[ch[v[i][j]][k]]]=(g[ch[v[i][j]][k]][mask|c[ch[v[i][j]][k]]|d[ch[v[i][j]][k]]]+g[v[i][j]][mask])%Mod;
			else f[i+1&1][trans[v[i][j]][k]][mask|c[trans[v[i][j]][k]]]=(f[i+1&1][trans[v[i][j]][k]][mask|c[trans[v[i][j]][k]]]+g[v[i][j]][mask])%Mod;
		}
	}int ans=0;
	for (j=0;j<v[m+1].size();j++) ans=(ans+g[v[m+1][j]][(1<<n)-1])%Mod;
	for (i=0;i<=qq;i++) ans=(ans+f[m+1&1][i][(1<<n)-1])%Mod;
	printf("%d\n",ans);
	return 0;
}
