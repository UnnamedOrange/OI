#include<iostream>
#include<map>
#include<vector>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

typedef long long ll;
const int N=59;
const int md=998244353;
const int ha=19260817;
const int hv=2333;

int n,k;
int to[N<<1],nxt[N<<1],beg[N],tot=1;
int ban[N];
ll f[ha+2];

//map<int,ll> f;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline void chk(int &a){if(a>=md)a-=md;}

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void dfs_get(int u,int f,vector<int> &stk)
{
	stk.push_back(u);
	for(int i=beg[u];i;i=nxt[i])
		if(!ban[to[i]] && to[i]!=f)
			dfs_get(to[i],u,stk);
}

inline ll chk(ll a){if(a>=md)return a-md;return a;}

inline ll keys(const vector<int> &ps,int v)
{
	ll ret=0;
	for(int i=0,e=ps.size();i<e;i++)
		ret=chk(ret*hv%ha+ps[i]);
	ret=((ret*(ll)v)%ha^v)%ha;
	return ret;
}

inline int dfs(int x,const vector<int> &ps)
{
	ll now=keys(ps,x);
	//cerr<<now<<endl;
	if(~f[now])return f[now];
	if(ps.size()==1)return f[now]=1;

	ll ret=0;
	for(int l=0;l<ps.size();l++)
	{
		int rt=ps[l];
		ban[rt]=1;
		
		ll curret=1;
		for(int i=beg[rt];i;i=nxt[i])
			if(!ban[to[i]])
			{
				vector<int> nxt;
				nxt.clear();
				dfs_get(to[i],rt,nxt);

				ll cur=0;
				for(int j=x+1;j<=k;j++)
					cur=chk(cur+dfs(j,nxt));
				(curret*=cur)%=md;
			}

		ban[rt]=0;
		ret=chk(ret+curret);
	}
	
	return ret;
}

int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);

	memset(f,-1,sizeof(f));
	n=read();k=read();
	for(int i=1,u,v;i<n;i++)
	{
		u=read();v=read();
		add(u,v);add(v,u);
	}

	vector<int> ps;
	for(int i=1;i<=n;i++)
		ps.push_back(i);
	ll ans=0;
	for(int i=1;i<=k;i++)
		(ans+=dfs(i,ps))%=md;
	
	printf("%lld\n",ans);
	return 0;
}
