#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n=15;
	printf("%d\n",n);
	for(int i=2;i<=n;i++)
		printf("%d %d\n",rand()%(i-1)+1,i);
	for(int i=1;i<=n;i++)
		printf("%d %d\n",rand()%300+1,rand()%2);
}
int main(){
	srand(time(0)+getx());
	freopen("xmastree2.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
