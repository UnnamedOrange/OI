#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

int type, N;
int mark[1000][1000],vis[1000][30],cnt[1000];
void init(){
	if(type!=2){
		bool flag;
		rep(i,1,N+1)rep(j,1,N+1)if(i!=j){
			flag=false;
			rep(k,0,10)if((i>>k&1)&&!(j>>k&1)){mark[i][j]=k+1,flag=true;break;}
			if(!flag){
				rep(k,0,10)if(!(i>>k&1)&&(j>>k&1)){mark[i][j]=k+11;break;}
			}
		}
	}
	if(type!=1){
		rep(q,1,N+1)rep(h,1,21){
			vis[q][h]=(q>>((h>10?h-10:h)-1)&1)^(h>10);
		}
	}
}
int encode(int x, int y){
	return mark[x][y];
}

bool decode(int q, int h){
	return vis[q][h];
}
int main(){
	int T;
	scanf("%d%d%d", &type, &N, &T);
	init();
//	rep(i,1,N+1)rep(j,1,N+1)if(i!=j){
//		assert(decode(i,encode(i,j)));
//		assert(!decode(j,encode(i,j)));
//	}
	while (T--) {
		int x, y;
		rd(x),rd(y);
		if (type == 1)
			ptn(mark[x][y]);
		else{
			if(vis[x][y])putchar('y'),putchar('e'),putchar('s');
			else putchar('n'),putchar('o');
			putchar('\n');
		}
	}
	return 0;
}
