/*#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0,f=1;char ch=getchar();
	while(ch<'0'||'9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret*f;
}
#define N 510
#define M 1010
int zen[N],fan[N];
bool bla[N];
int edg[N][N];
int ans;
int n,w,p,q;
void init(){
	n=re(),w=abs(re()),p=re(),q=re();
		for(int i=0;i<p;i++){
			int x=re(),y=re(),z=re();
			int a=re(),b=re(),c=re();
			zen[x]+=w|a;fan[x]+=(-w)|a;
			zen[y]+=w|b;fan[y]+=(-w)|b;
			zen[z]+=w|c;fan[z]+=(-w)|c;
			int d=re(),e=re(),f=re();
			zen[x]+=(d+f)*w;fan[x]+=(d+f)*(-w);
			zen[y]+=(d+e)*w;fan[y]+=(d+e)*(-w);
			zen[z]+=(e+f)*w;fan[z]+=(e+f)*(-w);
		}
		for(int i=0;i<q;i++){
			int x=re(),y=re();
			edg[x][y]=re()+1;
		}
		for(int i=1;i<=n;i++){
			zen[i]+=w;
			fan[i]-=w;
		}
}
void dfs(int pos,bool rel){
	if(rel){
		bla[pos]=true;
		ans+=zen[pos];
		for(int tar=1;tar<=n;tar++)
			if(!bla[tar]&&(edg[tar][pos]==1||edg[pos][tar]==2||edg[tar][pos]==2))
				dfs(tar,true);
	}else{
		bla[pos]=true;
		ans+=fan[pos];
		for(int tar=1;tar<=n;tar++)
			if(!bla[tar]&&(edg[pos][tar]==1||edg[pos][tar]==2||edg[tar][pos]==2))
				dfs(tar,false);
	}
	return;
}
void gef(int kig,int pos){
	for(int tar=1;tar<=n;tar++)
		if(edg[pos][tar]==2||edg[tar][pos]==2){
			zen[kig]+=zen[tar];fan[kig]+=fan[tar];
			bla[tar]=true;
			for(int wor=1;wor<=n;wor++)
				edg[kig][wor]=max(edg[kig][wor],edg[tar][wor]);
			dfs(kig,tar);
		}
	return;
}
struct info{int poi,num;};
struct swp{bool operator()(const info &a,const info &b){return a.num<b.num;}};
priority_queue<info , vector<info> , swp> H;
int tim[N],low[N];
bool vis[N],alg[N];
int top,sta[N];
int tim;
void tarjan(int pos){
	dfn[pos]=low[pos]=tim++;
	sta[++top]=pos;
	vis[pos]=true;
	for(int tar=1;tar<=n;tar++){
		if(!bla[tar]&&edg[pos][tar]==1){
			if(!vis[tar])
				tarjan(tar);
			if(!alg[tar])
				low[pos]=min(low[pos],low[tar]);
		}
	}
	if(low[pos]==dfn[pos]){
		while(sta[top]!=pos){
			bla[sta[top]]=true;
			alg[sta[top]]=true;
			zen[pos]+=zen[sta[top]];
			fan[pos]+=fan[sta[top]];
			top--;
		}
		alg[pos]=true;
		top--;
	}
	return;
}
int main(){
	int t=re();
	while(t--){
		ans=0;
		init();
		memset(bla,0,sizeof(bla));
		for(int x=1;x<=n;x++)
			for(int y=1;y<=n;y++)
				if(edg[x][y]==3)
					{dfs(y,true);dfs(x,false);}
		for(int i=1;i<=n;i++)
			if(!bla[i])
				gef(i,i);
		tim=0;
		top=0;
		memset(alg,0,sizeof(alg));
		memset(vis,0,sizeof(vis));
		for(int i=1;i<=n;i++)
			if(!bla[i])
				tarjan(i);
		for(int x=1;x<=n;x++)
			for(int y=1;y<=n;y++)
				if(!bla[x]&&!bla[y])
					
		for(int i=1;i<=n;i++){
			
		}
	}
	return 0;
}
//���ˣ�ȫTM���� 
*/
#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0,f=1;char ch=getchar();
	while(ch<'0'||'9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret*f;
}
#define N 100010 
int x[N],y[N],z[N],a[N],b[N],c[N],d[N],e[N],f[N];
int u[N],v[N],r[N];
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int t;
	cin>>t;
	while(t--){
		int n,w,p,q;
		cin>>n>>w>>p>>q;
		for(int i=0;i<p;i++)
			cin>>x[i]>>y[i]>>z[i]>>a[i]>>b[i]>>c[i]>>d[i]>>e[i]>>f[i];
		for(int i=0;i<q;i++)
			cin>>u[i]>>v[i]>>r[i];
		int ans=0x7fffffff;
		int vis[20];
		for(int i=0;i<(1<<n+1);i++){
			bool k=true;
			int num=i;
			for(int h=1;h<=n;h++){
				if(num&1)
					vis[h]=1;
				else
					vis[h]=-1;
				num=num>>1;
			}
			for(int j=0;j<q;j++){
				if(r[j]==0){
					if(!(vis[u[j]]<=vis[v[j]])){
						k=false;
						break;
					}
				}else{
					if(r[j]==1){
						if(!(vis[u[j]]==vis[v[j]])){
							k=false;
							break;
						}
					}else{
						if(!(vis[u[j]]<vis[v[j]])){
							k=false;
							break;
						}
					}
				}
			}
			if(k){
				int pos=0;
				for(int j=0;j<p;j++)
					pos+=	a[j]*abs(vis[x[j]]-vis[y[j]])+
							b[j]*abs(vis[y[j]]-vis[z[j]])+
							c[j]*abs(vis[z[j]]-vis[x[j]])+
							d[j]*(vis[x[j]]-vis[y[j]])+
							e[j]*(vis[y[j]]-vis[z[j]])+
							f[j]*(vis[z[j]]-vis[x[j]]);
				for(int j=1;j<=n;j++)
					pos+=vis[j];
				ans=min(ans,pos);
			}
		}	
		cout<<ans*w<<endl;
	}
	
	return 0;
}
