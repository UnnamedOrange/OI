#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#define maxn 100010
int q[maxn],ans[maxn],t,n,i,j,l,r,k,s;
char str[maxn];
bool mark[maxn];
bool check(int l,int r,int k)
{
	int i,j;
	for (i=l;i<=r;i++)
		if ((k>>i)&1) break;
	if (i>r) return false;
	i=l;
	j=r;
	for (;i<j;(i++,j--))
	{
		for (;(i<n) && !((k>>i)&1);i++);
		for (;(j>=0) && !((k>>j)&1);j--);
		if (i>=j) break;
		if (str[i]!=str[j]) return false;
	}
	return true;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	for (scanf("%d",&t);t>0;t--)
	{
		scanf("%d%s",&n,str);
		if (n<=10)
		{
			if (!check(0,n-1,(1<<n)-1)) printf("1\n");
			else
			{
				memset(mark,true,sizeof(mark));
				mark[(1<<n)-1]=false;
				ans[(1<<n)-1]=0;
				q[0]=(1<<n)-1;
				for (l=r=0;l<=r;l++)
				{
					for (i=0;i<n-1;i++)
					{
						for (j=i+1;j<n;j++)
							if (!check(i,j,q[l]))
							{
								s=q[l];
								for (k=i;k<=j;k++)
									if ((s>>k)&1) s-=(1<<k);
								if (mark[s])
								{
									q[++r]=s;
									mark[s]=false;
									ans[s]=ans[q[l]]+1;
								}
								if (!s)
								{
									printf("%d\n",ans[0]);
									break;
								}
							}
							if (!mark[0]) break;
					}
					if (!mark[0]) break;
				}
				if (mark[0]) printf("-1\n");
			}
		}
		else
		{
			if (!check(0,n-1,(1<<n)-1)) printf("1\n");
			else
			{
				for (i=0;i<n-1;i++)
				{
					for (j=i+1;j<n;j++)
						if (!check(i,j,(1<<n)-1))
						{
							s=(1<<n)-1;
							for (k=i;k<=j;k++)
								s-=(1<<k);
							if (!check(0,n-1,s))
							{
								printf("2\n");
								break;
							}
						}
					if (j<n) break;
				}
				if (i>=n-1) printf("-1\n");
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
