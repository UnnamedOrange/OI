#include <set>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
const int maxn=1e5+5;
struct QueryType
{
	int l,r,l_,r_,t,id,key;
	bool operator<(const QueryType &tmp)const
	{
		if(key==tmp.key)
			if(t==tmp.t)
				return r<tmp.r;
			else
				return t<tmp.t;
		return key<tmp.key;
	}
};
struct QueryType qu[maxn],qu2[maxn];
int n,m,num[maxn],val[maxn],valb[maxn],numb;
int type,ai[maxn],bi[maxn],head[maxn],E[maxn<<1],pre[maxn],suf[maxn];
int V[maxn<<1],li[maxn],ri[maxn],tag,ti[maxn],ci[maxn],lowbit[maxn];
int pi[maxn],q,cnt,ans[maxn],blo,m1,m2,bl[maxn],br[maxn],bel[maxn];
int back[maxn];
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
void dfs(int now,int fa)
{
	li[now]=++tag;
	ci[tag]=ai[now];
	for(int i=head[now];i!=0;i=E[i])
		if(V[i]!=fa)
			dfs(V[i],now);
	ri[now]=tag;
}
inline void updata(int x,bool d)
{
	x=ci[x];
	if(d)
	{
		if((++num[x])==1)
		{
			valb[bel[x]]++;
			val[x]++;
		}
	}
	else
	{
		if(!(--num[x]))
		{
			valb[bel[x]]--;
			val[x]--;
		}
	}
}
inline void updata2(int x,bool d)
{
	int u=ci[qu2[x].l],t=qu2[x].r;
	if(d)
	{
		back[x]=u;
		if(!(--num[u]))
		{
			valb[bel[u]]--;
			val[u]--;
		}
		if((++num[t])==1)
		{
			valb[bel[t]]++;
			val[t]++;
		}
	}
	else
	{
		u=back[x];
		if((++num[u])==1)
		{
			valb[bel[u]]++;
			val[u]++;
		}
		if(!(--num[t]))
		{
			valb[bel[t]]--;
			val[t]--;
		}
	}
}
int get(int l,int r)
{
	int res=0;
	if(bel[l]!=bel[r])
	{
		for(int i=bel[l]+1;i<=bel[r]-1;i++)
			res+=valb[i];
		for(int i=l;i<=ri[bel[l]];i++)
			res+=val[i];
		for(int i=r;i>=li[bel[r]];i--)
			res+=val[i];
	}
	else
	{
		for(int i=l;i<=r;i++)
			res+=val[i];
	}
	return res;
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	read(n);
	read(q);
	read(type);
	for(int i=1;i<=n;i++)
		read(ai[i]);
	for(int i=1,u,v;i<n;i++)
	{
		read(u);
		read(v);
		E[++cnt]=head[u];
		V[cnt]=v;
		head[u]=cnt;
		E[++cnt]=head[v];
		V[cnt]=u;
		head[v]=cnt;
	}
	dfs(1,0);
	if(n<=50000)
	{
		int lastans=0;
		for(int i=1,u,l,r,op;i<=q;i++)
		{
			read(op);
			if(op==1)
			{
				read(u);
				read(l);
				read(r);
				if(type)
				{
					u^=lastans;
					l^=lastans;
					r^=lastans;
				}
				lastans=0;
				for(int v=li[u];v<=ri[u];v++)
					if(ti[ci[v]]!=i&&ci[v]>=l&&ci[v]<=r)
					{
						ti[ci[v]]=i;
						lastans++;
					}
				printf("%d\n",lastans);
			}
			else
			{
				read(u);
				read(l);
				if(type)
				{
					u^=lastans;
					l^=lastans;
				}
				ai[u]=l;
				ci[li[u]]=l;
			}
		}
	}
	else if(type==0)
	{
		blo=std::sqrt(n);
		for(int i=1;i<=n;i++)
		{
			bel[i]=i/blo+1;
			if(li[bel[i]]==0)
				li[bel[i]]=i;
			ri[bel[i]]=i;
			numb=bel[i];
		}
		for(int i=1,op,u;i<=q;i++)
		{
			read(op);
			if(op==1)
			{
				++m1;
				read(u);
				read(qu[m1].l_);
				read(qu[m1].r_);
				qu[m1].l=li[u];
				qu[m1].r=ri[u];
				qu[m1].id=m1;
				qu[m1].t=m2;
				qu[m1].key=qu[m1].l/blo;
			}
			else
			{
				read(u);
				++m2;
				qu2[m2].l=li[u];
				read(qu[m2].r);
			}
		}
		std::sort(qu+1,qu+m1+1);
		int l=1,r=0,t=0;
		for(int i=1;i<=m1;i++)
		{
			while(t<qu[i].t)
				updata2(++t,true);
			while(t>qu[i].t)
				updata2(t--,false);
			while(r<qu[i].r)
				updata(++r,true);
			while(r>qu[i].r)
				updata(r--,false);
			while(l>qu[i].l)
				updata(--l,true);
			while(l<qu[i].l)
				updata(l++,false);
			ans[qu[i].id]=get(qu[i].l_,qu[i].r_);
		}
		for(int i=1;i<=m1;i++)
			printf("%d\n",ans[i]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
