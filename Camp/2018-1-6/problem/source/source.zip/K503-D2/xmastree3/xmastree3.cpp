#include<bits/stdc++.h>
#define mo 998244353
using namespace std;
struct Info{
	int nu,ne,an;
	bool p;
}a[100];
int b[50]={0},num,n,k,x,y;
void jb(int x,int y){
	a[++num].nu=y;a[num].ne=b[x];b[x]=num;a[num].p=true;a[num].an=0;
}
int dfs1(int x,int fa){
	int sum=(1<<(x-1));
	for (int y=b[x];y;y=a[y].ne){
		if (a[y].p&&a[y].nu!=fa) sum=sum+dfs1(a[y].nu,x);
	}
	return sum;
}
int lin(int x){
	if (x % 2 ==0) return x-1;return x+1;
}
int co(int x){
	int u=0;while (x){u+=x%2;x/=2;}return u;
}
int dfs(int x,int z){
	if (z>k) return 0;
	if ((co(x)==1))return k-z;
	long long an=0,sum;
	for (int i=1,pp=1;i<(1<<n);i*=2,pp++){
		if ((i&x)==i){
			for (int y=b[pp];y;y=a[y].ne)if (a[y].p){a[y].p=false;a[lin(y)].p=false;a[y].an=dfs1(a[y].nu,0);}else a[y].an=0;
			for (int j=1;j+z<=k;j++){
				sum=1;
				for (int y=b[pp];y;y=a[y].ne)if (a[y].an!=0){sum=(sum*dfs(a[y].an,j+z)%mo);}
				an+=sum;
			}
			for (int y=b[pp];y;y=a[y].ne)if (a[y].an!=0){a[y].p=true;a[lin(y)].p=true;a[y].an=0;}
		}
		an=an%mo;
	}
//	cout<<x<<' '<<z<<' '<<an<<endl;
	return an;
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d %d",&n,&k);
	for (int i=1;i<n;i++){
		scanf("%d %d",&x,&y);
		jb(x,y);jb(y,x);
	}
	cout<<dfs((1<<n)-1,0)<<endl;
}
