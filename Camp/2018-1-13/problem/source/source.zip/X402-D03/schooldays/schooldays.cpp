#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 1000000007;
const int MAXN = 2010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, f[MAXN];
int c[MAXN], d[MAXN];
ll dp[MAXN], g[MAXN];

int main() {
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);

	int i, j;
	n = read();
	for(i = 1; i <= n; i++) c[i] = read(), d[i] = read();
	f[0] = 0, dp[0] = 1;
	for(i = 0; i < n; i++) {
		int C = 0, D = n;
		for(j = i+1; j <= n; j++) {
			C = max(C, c[j]);
			D = min(D, d[j]);
			if(j-i >= C && j-i <= D) {
				if(f[j] < f[i]+1) {
					f[j] = f[i]+1;
					dp[j] = dp[i];
				}
				else if(f[j] == f[i]+1) 
					dp[j] = (dp[j]+dp[i])%MOD;
			}
		}
	}
	if(dp[n] == 0) 
		printf("-1\n");
	else 
		printf("%d %lld\n", f[n], dp[n]);
	return 0;
}
