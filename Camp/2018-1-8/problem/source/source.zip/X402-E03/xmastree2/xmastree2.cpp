#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 150 ;
int n, m, e, Begin[maxn], Next[maxn<<1], To[maxn<<1] ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
int w[maxn], dfn[maxn], p[maxn], fa[maxn], ans, rec ;
bool vis[maxn], inq[maxn], isrt[maxn] ;
void _dfs ( int x ) {
	int i, u ;
	inq[x] = 1 ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (!inq[u]) {
			fa[u] = x ;
			_dfs(u) ;
		}
	}
}
void check() {
	int i, tmp = rec ;
	for ( i = 2 ; i <= n ; i ++ ) {
		if (dfn[fa[p[i]]] > dfn[p[i]]) return ;
		tmp += w[p[i]]*i ;
	}
	ans = max(ans, tmp) ;
}
void dfs ( int stp ) {
	if (stp > n) {
		check() ;
		return ;
	}
	for ( int i = 1 ; i <= n ; i ++ )
		if (!vis[i]) {
			p[stp] = i ;
			vis[i] = 1 ;
			dfn[i] = stp ;
			dfs(stp+1) ;
			vis[i] = 0 ;
		}
}
int main() {
	freopen ( "xmastree2.in", "r", stdin ) ;
	freopen ( "xmastree2.out", "w", stdout ) ;
	//freopen ( "force.out", "w", stdout ) ;
	
	int i, u, x ;
	Read(n) ;
	for ( i = 1 ; i < n ; i ++) {
		Read(x) ; Read(u) ;
		add(x, u) ;
		add(u, x) ;
	}
	for ( i = 1 ; i <= n ; i ++ ) {
		Read(w[i]) ; scanf ( "%d", isrt+i ) ;
	}
	for ( i = 1 ; i <= n ; i ++ )
		if (isrt[i]) {
			vis[p[1] = i] = 1 ;
			rec = w[i] ;
			dfn[i] = 1 ;
			_dfs(i) ;
			dfs(2) ;
			vis[i] = 0 ;
		}
	cout << ans << endl ;
	return 0 ;
}
