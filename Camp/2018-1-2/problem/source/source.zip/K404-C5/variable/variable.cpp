#include<bits/stdc++.h>
typedef long long ll;
typedef unsigned int uint;
using namespace std;

inline int rd(){
	char ch=getchar();int i=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getchar();}
	return i*f;
}

inline void W(ll x){
	static int buf[50];
	if(!x){putchar('0');return;}
	if(x<0){putchar('-');x=-x;}
	while(x){buf[++buf[0]]=x%10;x/=10;}
	while(buf[0])putchar(buf[buf[0]--]+'0');
}
const int N=5e2+50,M=1e5+50,INF=0x3f3f3f3f;
int T,n,_W,p,q,g[N],v[M],w[M],nt[M],ec;
int lev[N],cur[N],cnt[N];
int src,des,ans;

inline void add(int x,int y,int o){
//	cout<<x<<" "<<y<<" "<<o<<endl;
	nt[++ec]=g[x];g[x]=ec;v[ec]=y;w[ec]=o;
}
inline bool bfs(){
	for(int i=1;i<=des;i++)lev[i]=0;
	queue<int>q;q.push(src);lev[src]=1;
	while(!q.empty()){
		int u=q.front();q.pop();
		for(int e=g[u];e;e=nt[e]){
			if(!w[e]||(lev[v[e]]))continue;
			lev[v[e]]=lev[u]+1;
			if(v[e]==des)return true;
			q.push(v[e]);
		}
	}
	return false;
}
inline int dinic(int x,int f,int dep){
//	for(int i=1;i<=dep;i++)putchar(' ');
//	printf("%d\n",x);
	if(x==des)return f;
	int rs=0;
	for(int &e=cur[x];e;e=nt[e]){
		if(!w[e]||(lev[v[e]]!=lev[x]+1)) continue;
		int o=dinic(v[e],min(f-rs,w[e]),dep+1);
		rs+=o;w[e]-=o;w[e^1]+=o;
		if(rs==f)return rs;
	}
	return lev[x]=0,rs;
}
inline int maxflow(){
	int rs=0;
	while(bfs()){
		int t;memcpy(cur,g,sizeof(cur));
		while((t=dinic(src,INF,0)))rs+=t,memcpy(cur,g,sizeof(cur));
	}
	return rs;
}
inline void solve(){
	memset(g,0,sizeof(g));
	memset(cnt,0,sizeof(cnt));
	n=rd(),_W=rd(),p=rd(),q=rd();
	ec=1;src=n+1;des=n+2;ans=0;
	for(int i=1;i<=p;i++){
		int x=rd(),y=rd(),z=rd();
		int a=rd(),b=rd(),c=rd();
		int d=rd(),e=rd(),f=rd();
		cnt[x]+=(d-f);
		cnt[y]+=(e-d);
		cnt[z]+=(f-e);
		add(x,y,2*a);add(y,x,2*a);
		add(y,z,2*b);add(z,y,2*b);
		add(x,z,2*c);add(z,x,2*c);
	}
	for(int i=1;i<=n;i++)++cnt[i];
	for(int i=1;i<=n;i++){
		if(cnt[i])
			(cnt[i]>0)?
			(ans-=cnt[i],add(i,des,2*cnt[i]),add(des,i,0)):
			(ans+=cnt[i],add(src,i,-2*cnt[i]),add(i,src,0));
	}
	for(int i=1;i<=q;i++){
		int x=rd(),y=rd(),r=rd();
		if(r==1)add(x,y,INF),add(y,x,INF);
		else if(r==2){
			add(x,des,INF),add(des,x,0);
			add(src,y,INF),add(y,src,0);
		}else add(x,y,INF),add(y,x,0);
	}
	ans+=maxflow();
	W(1ll*ans*_W);putchar('\n');
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	for(T=rd();T>=1;--T)solve();
}
