#include<bits/stdc++.h>
using namespace std;
int a[30];
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int t;
	scanf("%d",&t);
	while (t--){
		int n;
		scanf("%d",&n);
		a[0]=-1;
		for (int i=1;i<=n;i++)
			scanf("%d",a+i);
		int p=n,ans=0;
		while (a[p]==p) p--;
		while (p){
			if (a[1]!=p)
				for (int i=2;i<=n;i++)
					if (a[i]==p){
						reverse(a+1,a+i+1);
						ans++;
						break;
					}
			if (!p) break;
			reverse(a+1,a+p+1);
			while (a[p]==p) p--;
			ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}
