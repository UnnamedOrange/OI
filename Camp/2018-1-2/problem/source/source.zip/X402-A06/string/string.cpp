#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int maxm = 110;

char s[maxn];

int n, dp[maxm][maxm], flag;

void Get(){
	n = read();
	scanf("%s", s+1);
}

void pre_work(){
	For(i, 1, n){
		For(j, 1, n){
			int u = i, v = j;
			while(u <= v && s[u] == s[v]){
				++u, --v;
			}
			if(u > v) dp[i][j] = inf;
			else{
				dp[i][j] = 1;
				flag = 1;
			}
		}
	}
}

int dfs(int l,int r){
	if(dp[l][r] != inf) return dp[l][r];
	if(l == r) return inf;
	For(k, l, r-1){
		dp[l][r] = min(dp[l][r], dfs(l, k) + dfs(k+1, r));
	}

	if(dp[l][r] > inf) dp[l][r] = inf;
	return dp[l][r];
}

void solve_bf(){
	if(!flag) printf("-1\n");
	else {
		int Ans = dfs(1, n);
		if(Ans > n) printf("-1\n");
		else printf("%d\n", Ans);
	}
}

void solve(){
	flag = 0;
	For(i, 2, n) if(s[i] != s[i-1]) flag = 1;

	if(!flag) printf("-1\n");
	else{
		flag = 0;
		For(i, 3, n) if(s[i] != s[i-2]) flag = 1;
		if(!flag) printf("-1\n");

		int u = 1, v = n;
		while(u <= v && s[u] == s[v]){
			++ u, -- v;
		}

		if(u > v) printf("2\n");
		else printf("1\n");
	}
}

int main(){
	
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);

	int _ = read();
	while(_ --){
		flag = 0;
		Get();
		if(n <= 100){
			pre_work();
			solve_bf();
		}
		else solve();
	}

	return 0;
}
