#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 100000;

int T, n;
string st;
std::map<string, int> mp;

bool chk(string& a, int l, int r) {
    while(l <= r) if(a[l++] != a[r--]) return false;
    return true;
}

int dfs(string cur) {
    if(cur.length() == 0) return 0;
    if(mp.count(cur)) return mp[cur];

    int ans = oo;
    for(int l = 0; l < (int) cur.length(); ++l) {
        for(int r = l; r < (int) cur.length(); ++r) {
            if(!chk(cur, l, r)) {
                string tmp;
                tmp = cur.substr(0, l) + cur.substr(r+1, cur.length());
                chkmin(ans, dfs(tmp) + 1);
            }
        }
    }
    return mp[cur] = ans;
}

void solve() {
    read(n);
    std::cin >> st; 

    int ans = dfs(st);
    printf("%d\n", ans == oo ? -1 : ans);
}

int main() {
    freopen("string.in", "r", stdin);
    freopen("bf.out", "w", stdout);

    read(T);
    while(T--) solve();

    return 0;
}
