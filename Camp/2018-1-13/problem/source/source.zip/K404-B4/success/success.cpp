#include <bits/stdc++.h>
#define LL long long
#define MOD 1000000007
#define getchar() *(pp++)
using namespace std;
char buf[10000100],*pp=buf;
inline LL read()
{
	LL x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
LL s,t,n,m,fac[2000010],ifac[2000010],inv[2000010],d1[101][10010],d2[1000010],ret;
inline LL qpow(int x,int y)
{
	LL temp=x,ans=1;
	while(y)
	{
		if(y&1)ans=ans*temp%MOD;
		temp=temp*temp%MOD;
		y>>=1;
	}
	return ans;
}
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	fread(buf,sizeof(char),sizeof(buf),stdin);	
	s=read();
	t=read();
	n=read();
	m=read();
	inv[1]=1;
	for(int i=2;i<=2*s;i++)
	{
		inv[i]=((MOD-MOD/i)*inv[MOD%i])%MOD;
	}
	ifac[0]=fac[0]=1;
	for(int i=1;i<=2*s;i++)
	{
		fac[i]=i*fac[i-1]%MOD;
		ifac[i]=inv[i]*ifac[i-1]%MOD;
//		cout<<fac[i]<<' '<<ifac[i]<<endl;
	}
	for(int i=1;i<=n;i++)
	{
		d1[i][i]=1;
		for(int j=i+1;j<=i*t;j++)
		{
			d1[i][j]=d1[i][j-1]-(j>t?d1[i-1][j-t-1]:0)+d1[i-1][j-1]; 
//			cout<<i<<' '<<j<<' '<<d1[i][j]<<endl;
		}
	}
	for(int i=1;i<=s;i++)
	{
		if(n==m)d2[i]=0;
		else d2[i]=fac[i-1]*ifac[i-m+n]%MOD*ifac[m-n-1]%MOD;
//		cout<<i<<' '<<d2[i]<<endl;
	}
	for(int i=m;i<=s;i++)
	{
		for(int j=n;j<=min(n*t,1LL*i);j++)
		{
			ret=(ret+d1[n][j]*d2[i-j])%MOD;
		}
	}
	cout<<ret<<endl; 
	return 0;
}
/*
d[i][j]=c[i+j-1][i];
*/
