#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <queue>

using namespace std;
char ch[100005];
int a[200005], p[200005];

int n;

int main(){
	int T;
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &T);
	while(T--){
		scanf("%d", &n);
		scanf("%s", ch + 1);
		for(int i = 1; i <= n; i ++){
			a[i * 2] = ch[i];
			a[i * 2 + 1] = '#';
		}
		a[0] = '*'; a[1] = '#'; a[n * 2 + 1] = '#'; a[n * 2 + 2] = '$';
		int id = 0, mx = 0;
		for(int i = 1; i <= n * 2 + 1; i ++){
			if(mx > i) p[i] = min(p[2 * id - i], mx - i);
			else p[i] = 1;
			while(a[i - p[i]] == a[i + p[i]]) p[i] ++;
			if(i + p[i] > mx){
				id = i;
				mx = i + p[i];
			}
		}
		if(p[n + 1] != n + 1){
			printf("%d\n", 1);
			continue;
		}
		int flag = 1;
		for(int i = 1; i <= n; i ++){
			if(p[2 * i] != min(2 * i, n * 2 - 2 * i + 2)){
				flag = 0;
				break;
			}
		}
		if(flag == 1){
			printf("-1\n");
			continue;
		}
		printf("2\n");
	}
	return 0;
}
