#include <bits/stdc++.h>
#define ModAdd(x,y) (((x)%MOD+(y)%MOD)%MOD)
#define ModMul(x,y) ((((x)%MOD)*((y)%MOD))%MOD)
using namespace std;
typedef long long LL;

const int MAXN = 100000, MOD = 1000000007;
LL S, T, N, M;

template<typename T>
inline void readint(T& x) {
	T f=1, r=0; char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	x = f * r;
}

void Init() {
	readint(S); readint(T); readint(N); readint(M);
}

inline void MultiplyPolynomials(LL Len, LL *A, LL *B, LL *C0) {
	static LL C[MAXN+10];
	memset(C, 0, sizeof(C));
	for(int i=0; i<=Len; i++) 
		for(int j=0; j<=Len; j++)
			C[i+j] = ModAdd(C[i+j], ModMul(A[i], B[j]));
	memcpy(C0, C, sizeof(LL)*(Len+1));
}

void Work() {
	static LL Ans, lhs0[MAXN+10], lhs1[MAXN+10],
		rhs0[MAXN+10], rhs1[MAXN+10]; 
	for(LL i=1; i<=T; i++) 
		lhs0[i] = lhs1[i] = 1;
	for(LL i=1; i<=(S/T)+1; i++) 
		rhs0[i] = rhs1[i] = 1;
	for(LL i=1; i<=N-1; i++) 
		MultiplyPolynomials(S, lhs1, lhs0, lhs1);
	for(LL i=1; i<=M-N-1; i++) 
		MultiplyPolynomials(S, rhs1, rhs0, rhs1);
	MultiplyPolynomials(S, lhs1, rhs1, rhs1);
	for(LL i=0; i<=S; i++) Ans = ModAdd(Ans, rhs1[i]);
	printf("%lld", Ans);
}

int main() {
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	Init(); Work();
} 
