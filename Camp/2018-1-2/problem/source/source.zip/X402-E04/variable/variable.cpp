#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=2010,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char C=getchar();
	while(!isdigit(C))C=getchar();
	while( isdigit(C))x=x*10+C-48,C=getchar();
}
template<class T>inline bool chmi(T &A,T B){return A>B?A=B,1:0;}
inline void file(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
}
int n,W,p,q;
ll ans=1e18;
ll w[N],x[N],y[N],z[N],a[N],b[N],c[N],d[N],e[N],f[N];
struct ed{
	int x,y,r;
}E[N];
void init(){
	read(n),read(W),read(p),read(q);
	For(i,1,p)
		read(x[i]),read(y[i]),read(z[i]),read(a[i]),read(b[i]),read(c[i]),read(d[i]),read(e[i]),read(f[i]);
	For(i,1,q)
		read(E[i].x),read(E[i].y),read(E[i].r);
}
void dfs(int now){
	if(now>n){
		ll t=0;
		For(i,1,q){
			if(E[i].r==0&&w[E[i].x]>w[E[i].y])return ;
			if(E[i].r==1&&w[E[i].x]!=w[E[i].y])return ;
			if(E[i].r==2&&w[E[i].x]>=w[E[i].y])return ;
		}
		For(i,1,p)t+=a[i]*abs(w[x[i]]-w[y[i]])+b[i]*abs(w[y[i]]-w[z[i]])+c[i]*abs(w[z[i]]-w[x[i]])+d[i]*(w[x[i]]-w[y[i]])+e[i]*(w[y[i]]-w[z[i]])+f[i]*(w[z[i]]-w[x[i]]);
		For(i,1,n)t+=w[i];
		return void(chmi(ans,t));
	}
	w[now]=-W;
	dfs(now+1);
	w[now]=W;
	dfs(now+1);
}
void solve(){
	ans=100000000000;
	dfs(1);
	printf("%lld\n",ans);
}
int main(){
	file();
	int T;
	read(T);
	while(T--)init(),solve();
	return 0;
}
