# include <bits/stdc++.h>
# define 	N 		110
# define 	ll 		long long
# define 	P 		998244353
using namespace std;
ll n,k,u,v;
struct node{
	ll data,next;
}e[N];
ll place,head[N],ti,use[N],tag[N],ans;
void build(ll u, ll v){
	e[++place].data=v; e[place].next=head[u]; head[u]=place;
	e[++place].data=u; e[place].next=head[v]; head[v]=place;
}
ll dfs(ll x, ll now){
	ll pl=1, pr=1,q[11]; q[1]=x; ti++; use[x]=ti;
	while (pl<=pr){
		x=q[pl++];
		for (ll ed=head[x]; ed!=0; ed=e[ed].next){
			if (tag[e[ed].data]==true||use[e[ed].data]==ti) continue;
			q[++pr]=e[ed].data; use[e[ed].data]=ti;
		}
	}
	ll tot=0;
	for (ll i=1; i<=pr; i++){
		tag[q[i]]=true;
		ll sum=1;
		for (ll ed=head[q[i]]; ed!=0; ed=e[ed].next){
			if (tag[e[ed].data]==true) continue;
			ll num=0;
			for (ll i=now+1; i<=k; i++)
				num=(num+dfs(e[ed].data,i))%P;
			sum=(sum*num)%P;
		}
		tot=(tot+sum)%P;
		tag[q[i]]=false;
	}
	return tot;
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for (ll i=1; i<n; i++){
		scanf("%lld%lld",&u,&v);
		build(u,v);
	}
	for (ll i=1; i<=k; i++)
		ans=(ans+dfs(1,i))%P;
	printf("%lld\n",ans);
	return 0;
}

