#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=200100;
int beg[maxn],tto[maxn],nex[maxn],e;
int d[maxn],q[maxn];
long long dp[2010][2010];
long long p[2010];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("baoli.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	int s,t;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		d[t]++;
	}
	int l=1,r=1,u;
	q[1]=1,dp[1][0]=1;
	while(l<=r){
		u=q[l],l++;
		for(int i=beg[u];i;i=nex[i]){
			for(int j=0;j<n;j++)
				(dp[tto[i]][j+1]+=dp[u][j])%=md;
			d[tto[i]]--;
			if(!d[tto[i]]) q[++r]=tto[i];
		}
	}
	for(int i=1;i<=n;i++)
		p[i]=powd(i,k);
	long long ans;
	for(int i=1;i<=n;i++){
		ans=0;
		for(int j=1;j<=n;j++)
			ans=(ans+dp[i][j]*p[j])%md;
		printf("%lld\n",ans);
		if(i==n) cerr<<ans<<endl;
	}
	return 0;
}
