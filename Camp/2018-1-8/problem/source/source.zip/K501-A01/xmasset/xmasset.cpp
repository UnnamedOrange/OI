#include<stdio.h>
int lowbit(int x) {
	return x & (-x);
}
int main(){
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	int t, T, n;
	scanf("%d %d %d", &t, &n, &T);
	while(T--){
		if(t == 1){
			int a, b;
			scanf("%d %d", &a, &b);
			int k = 0, z = lowbit(a ^ b);	
			int cnt = 0;
			while(z) {
				++cnt;
				if(z & 1) break;
				z >>= 1;
			}
			while(a || b) {
				if((a & 1) ^ (b & 1))
					if(a & 1) {
						k = 1;
						break;
					}else{
						k = 0;
						break;
					}
				a >>= 1;
				b >>= 1;
			}
			if(k) printf("%d", k);
			printf("%d\n", cnt - 1);
		}
		if(t == 2){
			int q, h;
			scanf("%d %d", &q, &h);
			int z = h / 10;
			int o = 1 << (h % 10);
			if(q & o) 
				puts(z?"yes":"no");
			else 
				puts(z?"no":"yes");
		}
	}
	return 0;
}
