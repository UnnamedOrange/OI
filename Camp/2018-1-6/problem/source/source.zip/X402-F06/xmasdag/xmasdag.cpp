#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
#define begin Begin
#define next Next
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10,maxm=2e5+10,maxk=500+10,mod=998244353;
int begin[maxn],next[maxm],to[maxm],d[maxn],e;
int C[maxk][maxk];
int dp[maxn][maxk];
inline void add(int &x,int y){x=(x+y)%mod;}
void add_edge(int x,int y){
	to[++e]=y;
	next[e]=begin[x];
	begin[x]=e;
}
queue<int> q;
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
#endif
	int n=read(),m=read(),k=read();
	REP(i,1,m){
		int x=read(),y=read();
		add_edge(x,y);
		d[y]++;
	}
	REP(i,0,k){
		C[i][0]=C[i][i]=1;
		REP(j,1,i-1) C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
	}
	q.push(1);
	dp[1][0]=1;
	while(!q.empty()){
		int u=q.front();
		q.pop();
		for(int i=begin[u];i;i=next[i]){
			int v=to[i];
			REP(j,0,k)
				REP(l,0,j)
					add(dp[v][j],1ll*dp[u][l]*C[j][l]%mod);
			d[v]--;
			if(!d[v]) q.push(v);
		}
	}
	printf("0\n");
	REP(i,2,n) printf("%d\n",dp[i][k]);
	return 0;
}
