#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int N=100+9;

int n,ans;
char s[N];

inline bool check(char *ss,int l,int r)
{
	if(r-l+1==1)return false;
	for(int i=l;i<=r;i++)
		if(ss[i]!=ss[r-(i-l)])
			return true;
	return false;
}

inline void dfs(int dep,int len)
{
	if(dep>=ans)return;
	if(!len)
	{
		ans=dep;
		return;
	}
	
	char ss[N];
	for(int i=1;i<=len;i++)
		ss[i]=s[i];
	for(int l=1;l<=len;l++)
		for(int r=l+1;r<=len;r++)
			if(check(s,l,r))
			{
				for(int i=r+1;i<=len;i++)
					s[i-r+l-1]=s[i];
				dfs(dep+1,len-(r-l+1));
				for(int i=1;i<=len;i++)
					s[i]=ss[i];
			}
}

int mian()
{
	scanf("%d%s",&n,s+1);
	ans=1e9+7;
	dfs(0,n);
	printf("%d\n",ans==1e9+7?-1:ans);
	return 0;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("strings.out","w",stdout);
	
	int T;
	scanf("%d",&T);
	while(T--)
		mian();

	return 0;
}
