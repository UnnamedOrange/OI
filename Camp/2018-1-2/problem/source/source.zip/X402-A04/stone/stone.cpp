#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int mod=1e9+7;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}

int n,m,X[N],Y[N],a[2];
int s[N];
bool dfs(bool wh)
{
	bool ans=0;
	for(int i=1;i<=m;++i) 
	{
		if(Y[i]>=a[wh])
		{
			Y[i]-=a[wh];
			ans|=(!dfs(!wh));
			Y[i]+=a[wh];
		}
	}
	return ans;
}

int lastans[5],num[5];
void wj()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read(); a[0]=read(); a[1]=read();
	for(i=1;i<=n;++i) X[i]=read(),Y[i]=X[i];

	if(a[0]==a[1])
	{
		for(i=1;i<=n;++i) s[i]=(X[i]/a[0]%2==1?1:0),num[s[i]]++;
		if(num[1]) printf("0 0 %lld %lld\n",qpow(2,n-1),qpow(2,n-1));
		else printf("0 0 0 %lld\n",qpow(2,n));
		return 0;
	}

	if(n>7)
	{
		printf("%lld 0 %lld %lld\n",qpow(2,n-1),qpow(2,n-2),qpow(2,n-2));
		return 0;
	}

	int tot=1<<n;
	for(int s=0;s<tot;++s)
	{
		m=0;
		for(i=1;i<=n;++i) if(s&(1<<i-1)) Y[++m]=X[i];
		bool ans0=dfs(0),ans1=dfs(1);
		//for(i=1;i<=n;++i) printf("%d",(s>>i-1)&1);
		//printf(" : %d%d\n",(int)ans0^1,(int)ans1);
		//^ the first man win?
		ans0=!ans0;
		//^ 0: Alice win; 1: Bob win;
		lastans[(ans0<<1)|ans1]++;
	}
	printf("%d %d %d %d\n",lastans[0],lastans[3],lastans[1],lastans[2]);
	return 0;
}
