#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N=100010,M=200010,INF=0x3f3f3f3f,K=510,Mod=998244353;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
}
ll s[K][K],dp[N][K];
void init_st(int n){
	s[0][0]=1;
	For(i,1,n)
		For(j,1,i)
			s[i][j]=(s[i-1][j-1]+j*s[i-1][j])%Mod;
}
int Begin[N],Next[M],to[M],e,n,m,k,deg[N];
inline void add(int x,int y){
	to[++e]=y,Next[e]=Begin[x],Begin[x]=e;deg[y]++;
}
void init(){
	read(n),read(m),read(k);
	init_st(k);
	For(i,1,m){
		int x,y;
		read(x),read(y);
		add(x,y);
	}
}
void solve(){
	queue<int>q;q.push(1);
	dp[1][0]=1;
	while(!q.empty()){
		int u=q.front();q.pop();
		Rep(i,u){
			dp[v][0]=(dp[v][0]+dp[u][0])%Mod;
			For(j,1,k)
				dp[v][j]=(dp[v][j]+dp[u][j-1]*j+dp[u][j])%Mod;
			if(!(--deg[v]))q.push(v);
		}
	}
	For(i,1,n){
		ll ans=0;
		For(j,0,k)
			ans=(ans+s[k][j]*dp[i][j]%Mod)%Mod;
		printf("%lld\n",ans);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
