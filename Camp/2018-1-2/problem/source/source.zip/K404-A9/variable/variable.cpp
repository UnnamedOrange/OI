#include<bits/stdc++.h>
using namespace std;
#define N 1010
int x[N],y[N],z[N],a[N],b[N],c[N],d[N],e[N],f[N];
struct Node {
	int u,v,r;
}E[N];
int v[N],n,q,p,ans;
void dfs(int po) {
	if(po==n+1) {
		for(int i=1;i<=q;i++) {
			int U=E[i].u,V=E[i].v,r=E[i].r;
			if(v[U]>v[V]) return;
			if(v[U]<v[V]) {
				if(r==1) return;
			}
			if(v[U]==v[V]) {
				if(r==2) return;
			}
		}
		int tmp=0;
		for(int i=1;i<=p;i++) {
			tmp+=a[i]*abs(v[x[i]]-v[y[i]])+b[i]*abs(v[y[i]]-v[z[i]])
			+c[i]*abs(v[z[i]]-v[x[i]])+d[i]*(v[x[i]]-v[y[i]])
			+e[i]*(v[y[i]]-v[z[i]])+f[i]*(v[z[i]]-v[x[i]]);
		}
		for(int i=1;i<=n;i++) tmp+=v[i];
		ans=min(ans,tmp);
		return;
	}
	v[po]=1;
	dfs(po+1);
	v[po]=-1;
	dfs(po+1);
}
void work() {
	int w;
	ans=INT_MAX;
	scanf("%d%d%d%d",&n,&w,&p,&q);
	for(int i=1;i<=p;i++) {
		scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],
			&c[i],&d[i],&e[i],&f[i]);
	}
	for(int i=1;i<=q;i++) {
		scanf("%d%d%d",&E[i].u,&E[i].v,&E[i].r);
	}
	dfs(1);
	printf("%d\n",ans*w);
}
int main() {
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) work();
}
