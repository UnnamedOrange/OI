#include<bits/stdc++.h>
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')c=getchar(),f=-1;
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

const int N=1000005;
int n,m,idx,num,ans;
vector<int>e[N],g[N];
int top,stk[N],dfn[N],low[N],val[N],id[N],du[N],dis[N];
queue<int>q;
bool exist[N];

inline void tarjan(int u)
{
	dfn[u]=low[u]=++idx;
	stk[++top]=u,exist[u]=true;
	for(int i=0,sz=e[u].size();i<sz;i++)
	{
		int v=e[u][i];
		if(!dfn[v])
		{
			tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(exist[v])low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		num++;
		while(stk[top]!=u)
		{
			exist[stk[top]]=false;
			id[stk[top]]=num,val[num]++;
			top--;
		}
		top--,exist[u]=false;
		id[u]=num,val[num]++;
	}
}

void bfs()
{
	for(int i=1;i<=num;i++)
		if(!du[i])dis[i]=val[i],q.push(i);
	while(!q.empty())
	{
		 int u=q.front();q.pop();
		 for(int i=0,sz=g[u].size();i<sz;i++)
		 {
		 	int v=g[u][i];
		 	dis[v]=max(dis[v],dis[u]+val[v]);
		 	if(!(--du[v]))q.push(v);
		 }
	}
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int x,y;
	n=getint(),m=getint();
	while(m--)
	{
		x=getint(),y=getint();
		e[x].push_back(y);
	}
	for(int i=1;i<=n;i++)
		if(!dfn[i])tarjan(i);
	for(int u=1;u<=n;u++)
		for(int i=0,sz=e[u].size();i<sz;i++)
		{
			int v=e[u][i];
			if(id[u]!=id[v])g[id[u]].push_back(id[v]),du[id[v]]++;
		}
	bfs();
	for(int i=1;i<=num;i++)ans=max(ans,dis[i]);
	printf("%d\n",ans);
	return 0;
}

