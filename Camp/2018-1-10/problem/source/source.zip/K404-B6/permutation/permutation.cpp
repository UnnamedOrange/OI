#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 100001
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
const int mod=998244353;
int n,p[N];
namespace task1
{
	int ans,col[11],s[11];
	bool ok;
	void dfs(int u)
	{
		if(~col[s[u]])
		{
			if(col[s[u]]==col[u])ok=0;
		}
		else 
		{
			col[s[u]]=col[u]^1;
			dfs(s[u]);
		}
	}
	void main()
	{
		
		for(int i=1;i<=n;++i)s[i]=i;
		do
		{
			ok=1;
			memset(col,-1,sizeof col);
			for(int i=1;i<=n;++i)
				if(p[i] && s[i]!=p[i])
					ok=0;
			for(int i=1;i<=n;++i)
				if(!~col[i])
					col[i]=0,dfs(i);
			ans+=ok;
		}while(next_permutation(s+1,s+n+1));
		printf("%d\n",ans);
	}
}
namespace task2
{
	void main()
	{
		if(n&1)puts("0");
		else 
		{
			int ans=1,m=0;
			for(int i=1;i<=n;++i)
				if(p[i]==0)
					++m;
			for(int i=1;i<=m;i+=2)
				ans=1ll*ans*i%mod;
			printf("%d\n",1ll*ans*ans%mod);
		}
	}
}
int main()
{
	open(permutation);
	re(n);
	for(int i=1;i<=n;++i)re(p[i]);
	if(n<=10)task1::main();
	else task2::main();
}
