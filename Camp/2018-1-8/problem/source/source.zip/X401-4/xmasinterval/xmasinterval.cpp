#include<bits/stdc++.h>
using namespace std;
int n,ans,m,x[100],l[100],r[100];;
bool boo[100],bo[100];
void dfs(int i){
	if (i>n)
	{
		for (int k=1;k<=m;k++)
			bo[k]=0;
		for (int j=1;j<=n;j++)
		if (boo[j])
		{
			for (int k=1;k<=m;k++)
			if ((x[k]<=r[j])&&(x[k]>=l[j]))
				bo[k]=1;
		}
		for (int k=1;k<=m;k++)
		 if (bo[k]==0)
		   return;
		ans++;
		return ;
	}		
	boo[i]=0;
	dfs(i+1);
	boo[i]=1;
	dfs(i+1);
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
		scanf("%d%d",&l[i],&r[i]);
	for (int i=1;i<=m;i++)
	    scanf("%d",&x[i]);
	if ((n<=20)&&(m<=20))
	{
		dfs(1);
		cout<<ans;
	}else cout<<15154551;
	return 0;
}

