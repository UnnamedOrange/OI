#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
long long Mod=1000000009;
struct node
{
	int l,r;
	bool used;
}b[500010];
int n,m,a[500010],c[500010],k;
long long ans=1,dp[2][10010];
void solve()
{
	int cnt[65],s[65];
	ans=0;
	k=m;
	for (int i=0;i<n;i++)
	{
		c[k++]=b[i].l;
		c[k++]=b[i].r;
	}
	sort(c,c+m+2*n);
	k=unique(c,c+m+2*n)-c;
	for (int i=0;i<n;i++)
	{
		b[i].l=lower_bound(c,c+k,b[i].l)-c;
		b[i].r=lower_bound(c,c+k,b[i].r)-c;
		//cout<<b[i].l<<" "<<b[i].r<<endl;
	}
	for (int i=0;i<m;i++)
	{
		a[i]=lower_bound(c,c+k,a[i])-c;
		//cout<<a[i]<<endl;
	}
	for (int mask=0;mask<(1<<n);mask++)
	{
		memset(cnt,0,sizeof(cnt));
		memset(s,0,sizeof(s));
		for (int i=0;i<n;i++)
		{
			if (!(mask&(1<<i)))
			{
				continue;
			}
			cnt[b[i].l]++;
			cnt[b[i].r+1]--;
		}
		s[0]=cnt[0];
		for (int i=1;i<=k;i++)
		{
			s[i]=s[i-1]+cnt[i];
		}
		/*
		cout<<mask<<endl;
		for (int i=0;i<=k;i++)
		{
			cout<<s[i]<<" ";
		}
		cout<<endl;
		*/
		bool f=true;
		for (int i=0;i<m;i++)
		{
			if (s[a[i]]<=0)
			{
				f=false;
				break;
			}
		}
		if (f)
		{
			ans++;
		}
	}
	printf("%d\n",ans);
}
bool cmp(node x,node y)
{
	if (!y.used)
	{
		return true;
	}
	if (!x.used)
	{
		return false;
	}
	if (x.r==y.r)
	{
		return x.l<y.l;
	}
	else
	{
		return x.r<y.r;
	}
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read();
	m=read();
	//scanf("%d%d",&n,&m);
	for (int i=0;i<n;i++)
	{
		b[i].l=read();
		b[i].r=read();
	}
	for (int i=0;i<m;i++)
	{
		a[i]=read();
		c[i]=a[i];
	}
	/*
	if (n<=20)
	{
		solve();
		return 0;
	}
	*/
	sort(c,c+m);
	k=unique(c,c+m)-c;
	//cout<<k<<endl;
	for (int i=0;i<m;i++)
	{
		a[i]=lower_bound(c,c+k,a[i])-c;
	}
	int cnt=n;
	for (int i=0;i<n;i++)
	{
		//cout<<b[i].l<<" "<<b[i].r<<"-->";
		b[i].l=lower_bound(c,c+k,b[i].l)-c;
		b[i].r=lower_bound(c,c+k,b[i].r+1)-c;
		b[i].r--;
		//cout<<b[i].l<<" "<<b[i].r<<endl;
		if (b[i].l>b[i].r)
		{
			ans=ans*2%Mod;
			b[i].used=false;
			cnt--;
		}
		else
		{
			b[i].used=true;
		}
	}
	sort(a,a+m);
	sort(b,b+n,cmp);
	/*
	for (int i=0;i<n;i++)
	{
		cout<<b[i].l<<" "<<b[i].r<<endl;
	}
	*/
	n=cnt;
	for (int i=n;i;i--)
	{
		b[i]=b[i-1];
	}
	k=0;
	while (b[k+1].r<a[0] && k<=n)
	{
		k++;
	}
	int p=0;
	long long s=1;
	for (int j=0;j<m;j++)
	{
		p^=1;
		memset(dp[p],0,sizeof(dp[p]));
		for (int i=k+1;i<=n && b[i].l<=a[j] && b[i].r>=a[j];i++)
		{
			if (i-k>1)
			{
				dp[p][i]=(dp[p][i]+2*dp[p][i-1])%Mod;
			}
			dp[p][i]=(dp[p][i]+s)%Mod;
		}
		if (j==m-1)
		{
			break;
		}
		while (b[k+1].r<a[j+1] && k<=n)
		{
			k++;
		}
		s+=dp[p][k];
	}
	ans=ans*dp[p][n]%Mod;
	printf("%lld\n",ans);
	return 0;
}
/*
4 6
3 8
1 6
3 8
2 7
8
4
6
3
7
1
*/
