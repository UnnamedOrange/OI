#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>
using namespace std;

const int MOD = 1e9 + 7;
long long n, m, s, t;

namespace Force
{
	long long f[200][200];
	void main()
	{
		s -= m;
		--t;
		memset(f, 0, sizeof f);
		f[0][0] = 1;
		for (int i = 1; i < m + 1; ++i)
		{
			for (int j = 0; j < s + 1; ++j)
			{
				if (i <= n)
				{	
					for (int k = 0; k < min((long long)j, t) + 1; ++k)
						f[i][j] = (f[i][j] + f[i - 1][j - k]) % MOD;
				}
				else
				{
					for (int k = 0; k < j + 1; ++k)
						f[i][j] = (f[i][j] + f[i - 1][j - k]) % MOD;
				}
			} 
		}
		long long sum = 0;
		for (int j = 0; j < s + 1; ++j)
			sum = (sum + f[m][j]) % MOD;
		printf("%lld\n", sum % MOD);
	}
}

int main()
{
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	cin >> s >> t >> n >> m;
	Force::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}

