#include<bits/stdc++.h>
using namespace std;
const long long mo=998244353;
long long superand(){
	long long ans=1;
	for(int i=1;i<10000;i++){
		ans=(ans*rand()%mo)%mo;
		ans=ans==0?1:ans;
	}
	return ans;
}
int main(){
	//0.0000001%
	//really sad....
	srand((unsigned int)new char);
	freopen("sad.out","w",stdout);
	printf("%d\n",superand());
	return 0;
}
