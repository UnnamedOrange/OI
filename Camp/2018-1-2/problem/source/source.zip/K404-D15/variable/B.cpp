#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 1005
typedef long long ll;

int n,w,p,q;
int v[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

struct constraints{
	int x,y,z,a,b,c,d,e,f;
	void fuckpps(){
		x=read(),y=read(),z=read();
		a=read(),b=read(),c=read();
		d=read(),e=read(),f=read();
	}
	void modpps(){x=read(),y=read(),z=read();}
	int calc(){
		int ret=0;
		ret+=a*abs(v[x]-v[y])+d*(v[x]-v[y]);
		ret+=b*abs(v[y]-v[z])+e*(v[y]-v[z]);
		ret+=c*abs(v[z]-v[x])+f*(v[z]-v[x]);
		return ret;
	}
}a[maxn],b[maxn];

int main(){
	for (int T=read();T;T--){
		n=read(),w=read(),p=read(),q=read();
		for (int i=1;i<=p;i++) a[i].fuckpps();
		for (int i=1;i<=q;i++) b[i].modpps();
		ll ans=1e18;
		for (int i=0;i<(1<<n);i++){
			for (int j=1;j<=n;j++) if (i>>(j-1)&1) v[j]=w; else v[j]=-w;
			bool can=1;
			for (int j=1;j<=q;j++){
				int x=b[j].x,y=b[j].y,z=b[j].z;
				if (z==0&&v[x]<=v[y]) continue;
				if (z==1&&v[x]==v[y]) continue;
				if (z==2&&v[x]<v[y]) continue;
				can=0; break;
			}
			if (!can) continue; ll res=0;
			for (int j=1;j<=n;j++) res+=v[j];
			for (int j=1;j<=p;j++) res+=a[j].calc();
			ans=min(ans,res);
		}
		cout<<ans<<endl;
	}
	return 0;
}
