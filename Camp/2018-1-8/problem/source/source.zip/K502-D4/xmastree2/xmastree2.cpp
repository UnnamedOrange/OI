#include<algorithm>
#include<cstdio>
#include<cstdlib>
using namespace std;
int n;
int en[1005];
int e[1005][1005];
long long w[1005];
int r[1005];
long long ans;
int cur;
long long temans;
void dfs(int fa,int u){
	cur++;
	temans+=cur*w[u];
	for(int i=0;i<en[u];i++){
		int v=e[u][i];
		if(v!=fa){
			dfs(u,v);
		}
	}
}
bool cmp(int t1,int t2){
	if(rand()%2==0)
		return false;
	else
		return true;
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmasetree2.out","w",stdout);
	srand((int)new char);
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		int t1,t2;
		scanf("%d%d",&t1,&t2);
		e[t1][en[t1]++]=t2;
		e[t2][en[t2]++]=t1;
	}
	for(int i=1;i<=n;i++){
		scanf("%lld%d",&w[i],&r[i]);
	}
	for(int i=1;i<=n;i++){
		if(r[i]){
			for(int j=1;j<50;j++){
				for(int k=1;k<=n;k++)
					sort(e[k],e[k]+en[k],cmp);
				temans=0;
				cur=0;
				dfs(i,i);
				ans=max(ans,temans);
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}
