#include <bits/stdc++.h>

char s[100007];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) {
		int n;
		scanf("%d ",&n);
		for(int i = 0;i < n;++i) s[i] = getchar();
		bool ok = true;
		for(int i = 0;i < n;++i) if(s[n-1-i] != s[i]) {ok=false;break;}
		if(!ok) {printf("1\n");continue;}
		ok = true;
		for(int i = 0;i < n - 2;++i) if(s[i] != s[i+2]) {ok=false;break;}
		if(ok) {printf("-1\n");continue;}
		printf("2\n");
	}
}
