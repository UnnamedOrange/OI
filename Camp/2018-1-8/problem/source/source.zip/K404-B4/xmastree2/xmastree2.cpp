#include <bits/stdc++.h>
#define getchar() *(pp++)
using namespace std;
char buf[1000100],*pp=buf;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
struct edge
{
	int v,p;
}e[60010];
int n,top,head[30010],w[30010],f[30010],deg[30010];
bool r[30010];
inline void addedge(int u,int v)
{
	e[++top]=(edge){v,head[u]};
	head[u]=top;
	e[++top]=(edge){u,head[v]};
	head[v]=top;
}
void dfs(int u,int fa)
{
	f[u]=fa;
	for(int i=head[u];i;i=e[i].p)
	{
		if(e[i].v==fa)continue;
		dfs(e[i].v,u);
		deg[u]++;
	}
}
long long solve()
{
	priority_queue< pair<int,int> > q;
	for(int i=1;i<=n;i++)
	{
		if(!deg[i])
		{
			q.push(make_pair(w[i],i));	
		}	
	}	
	long long ret=0;
	for(int i=n;i;i--)
	{
		pair<int,int> u=q.top();
		q.pop();
		ret+=1LL*i*u.first;
		int v=f[u.second];
		if(--deg[v]==0)
		{
			q.push(make_pair(w[v],v));
		}
	}
	return ret;
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	fread(buf,sizeof(char),sizeof(buf),stdin);
	n=read();
	for(int i=1;i<n;i++)
	{
		addedge(read(),read());
	}
	for(int i=1;i<=n;i++)
	{
		w[i]=read();
		r[i]=read();
	}
	long long ret=0;
	for(int i=1;i<=n;i++)
	{
		if(r[i])
		{
			memset(deg,0,sizeof(deg));
			dfs(i,0);
			ret=max(ret,solve());
		}
	}
	cout<<ret<<endl;
	return 0;
}
