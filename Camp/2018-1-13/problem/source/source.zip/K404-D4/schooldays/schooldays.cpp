#include <iostream>
#include <cstdio>
using namespace std;
int n, c[1000010], d[1000010];
int f[1000010], g[1000010];
int main () {
	freopen ("schooldays.in", "r", stdin);
	freopen ("schooldays.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++) scanf ("%d%d", &c[i], &d[i]);
	f[0] = 0, g[0] = 1;
	for (int i = 1; i <= n; i++) {
		f[i] = -1, g[i] = 0;
		for (int j = i, mi = c[i], ma = d[i]; j >= 1; j--) {
			mi = max (mi, c[j]), ma = min (ma, d[j]);
			if (i - j + 1 > ma) break;
			if (i - j + 1 >= mi && i - j + 1 <= ma && f[j - 1] != -1) {
				if (f[j - 1] + 1 > f[i]) f[i] = f[j - 1] + 1, g[i] = 0;;
				if (f[j - 1] + 1 == f[i]) g[i] += g[j - 1];
			}
			if (i - j + 1 < mi) j = i + 2 - mi;
		}
	}
	if (f[n] == -1) printf ("-1\n");
	else printf ("%d %d\n", f[n], g[n]);
	return 0;
}
