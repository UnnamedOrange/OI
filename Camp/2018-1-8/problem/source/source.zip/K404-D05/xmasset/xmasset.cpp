#include <bits/stdc++.h>

int type, N;

void init()
{
    
}

int encode(int x, int y)
{
    for(int i=0;i<=10;++i){
    	int cur=1<<i;
    	int a=cur&x,b=cur&y;
    	if(a!=b)return (i+1)*2-(a==0);
	}
}

bool decode(int q, int h)
{
    int pos=(h-1)>>1;
    int cur=1<<pos;
    if(q&cur){
    	if(h&1){
    		return 0;
		}
		else{
			return 1;
		}
	}
	else{
		if(h&1){
			return 1;
		}
		else{
			return 0;
		}
	}
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}

