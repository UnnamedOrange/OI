#include <bits/stdc++.h>

namespace {

inline char read() {
    static const int IN_LEN = 1 << 18 | 1;
    static char buf[IN_LEN], *s, *t;
    return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
            s == t ? -1 : *s++;
}

template <typename T>
inline void read(T &x) {
    static char c;
    static bool iosig;
    for (c = read(), iosig = false; !isdigit(c); c = read()) {
        if (c == -1) return;
        iosig |= c == '-';
    }
    for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
    iosig && (x = -x);
}

inline int read(char *buf) {
    register int s = 0;
    register char c;
    while (c = read(), isspace(c) && c != -1)
        ;
    if (c == -1) {
        *buf = 0;
        return -1;
    }
    do
        buf[s++] = c;
    while (c = read(), !isspace(c) && c != -1);
    buf[s] = 0;
    return s;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
    (oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
    *oh++ = c;
}

template <typename T>
inline void print(T x) {
    static int buf[21], cnt;
    if (x != 0) {
        (x < 0) && (print('-'), x = -x);
        for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
        while (cnt) print((char)buf[cnt--]);
    } else {
        print('0');
    }
}

inline void print(const char *s) {
    for (; *s; s++) print(*s);
}

struct InputOutputStream {
    ~InputOutputStream() {
        fwrite(obuf, 1, oh - obuf, stdout);
    }

    template <typename T>
    inline InputOutputStream &operator>>(T &x) {
        read(x);
        return *this;
    }

    template <typename T>
    inline InputOutputStream &operator<<(const T &x) {
        print(x);
        return *this;
    }
} io;

inline int encode(int x, int y) {
    register int pos = __builtin_ctz(x ^ y), t;
    t = (x >> pos) & 1;
    return t ? 10 + pos + 1 : pos + 1;
}

inline int decode(int x, int y) {
    register int t = y > 10;
    y--;
    if (t) {
        y -= 10;
        return ((x >> y) & 1) == 1;
    } else {
        return ((x >> y) & 1) == 0;
    }
}

inline void solveEncode() {
    register int n, T;
    io >> n >> T;
    for (register int x, y, pos, t, len, ans; T--;) {
        io >> x >> y;
        io << encode(x, y) << '\n';
    }
}

inline void solveDecode() {
    register int n, T;
    io >> n >> T;
    for (register int x, y, pos, t, len, ans; T--;) {
        io >> x >> y;
        io << (decode(x, y) ? "yes\n" : "no\n");
    }
}

inline void solve() {
    register int type;
    io >> type;
    if (type == 1) {
        solveEncode();
    } else {
        solveDecode();
    }
}
}

int main() {
    solve();
    return 0;
}