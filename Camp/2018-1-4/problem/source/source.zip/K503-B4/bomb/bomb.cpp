#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define rg register
const int maxn=1e6+5;
struct EdgeType
{
	int u,v;
};
struct EdgeType edge[maxn];
int n,m,head[maxn],E[maxn],V[maxn],cnt,dfn[maxn],low[maxn];
int stack[maxn],top,tag,size[maxn],col,bel[maxn],du[maxn];
int f[maxn],ans,que[maxn];
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
void tarjan(int now)
{
	dfn[now]=low[now]=++tag;
	stack[++top]=now;
	for(int i=head[now];i!=0;i=E[i])
		if(!bel[V[i]])
			if(dfn[V[i]])
				low[now]=std::min(low[now],dfn[V[i]]);
			else
			{
				tarjan(V[i]);
				low[now]=std::min(low[now],low[V[i]]);
			}
	if(low[now]==dfn[now])
	{
		col++;
		size[col]=1;
		while(stack[top]!=now)
		{
			bel[stack[top]]=col;
			++size[col];
			top--;
		}
		bel[now]=col;
		top--;
	}
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	read(n);
	read(m);
	for(int i=1,u,v;i<=m;i++)
	{
		read(u);
		read(v);
		edge[i].u=u;
		edge[i].v=v;
		E[++cnt]=head[u];
		V[cnt]=v;
		head[u]=cnt;
	}
	for(int i=1;i<=n;i++)
		if(!dfn[i])
			tarjan(i);
	memset(head,0,sizeof(head));
	cnt=0;
	for(int i=1,u,v;i<=m;i++)
	{
		u=bel[edge[i].u];
		v=bel[edge[i].v];
		if(u!=v)
		{
			E[++cnt]=head[u];
			V[cnt]=v;
			head[u]=cnt;
			du[v]++;
		}
	}
	int h=0,tail=0,now;
	for(int i=1;i<=col;i++)
		if(!du[i])
			que[tail++]=i;
	while(h<tail)
	{
		now=que[h++];
		f[now]+=size[now];
		if(f[now]>ans)
			ans=f[now];
		for(int i=head[now];i!=0;i=E[i])
		{
			f[V[i]]=std::max(f[V[i]],f[now]);
			if(!(--du[V[i]]))
				que[tail++]=V[i];
		}
	}
	std::cout<<ans<<std::endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
