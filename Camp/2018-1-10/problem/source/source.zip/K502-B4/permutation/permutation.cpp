#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;
long long n,cnt,q[1010],vis[1010],ans,flag[1010],dfn[1010],low[1010],dfn_clock,col[1010],color,st[1010],top;
struct node 
{
	long long v;
	node *next_;
}pool[2010],*h[1010];
void addedge(long long u,long long v)
{
	node *p=&pool[++cnt];
	p->v=v;p->next_=h[u];h[u]=p;
}
void DFS(long long u)
{
	dfn[u]=++dfn_clock;
	low[u]=dfn_clock;
	flag[u]=1;st[++top]=u;
	for(node *p=h[u];p;p=p->next_)
	{
		long long v=p->v;
		if(!dfn[v]) DFS(v),low[u]=min(low[u],low[v]);
		else if(flag[v]) low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		color++;
		for(;st[top+1]!=u;top--)
		{
			flag[st[top]]=0;
			col[color]++;	
		}
	}
} 
void work()
{
	memset(pool,0,sizeof(pool));
	memset(h,0,sizeof(h));cnt=0;
	memset(dfn,0,sizeof(dfn));color=0;
	memset(low,0,sizeof(low));dfn_clock=0;
	memset(st,0,sizeof(st));top=0;
	memset(col,0,sizeof(col));
	for(long long i=1;i<=n;i++) 
	{
		if(i==q[i]) return ;
		addedge(i,q[i]);
	}
	for(long long i=1;i<=n;i++) if(!dfn[i]) DFS(i);
	bool flag_=true;
	for(long long i=1;i<=color;i++) if(col[i]%2==1 && col[i]>1) flag_=false;
	if(flag_) ans++;
}
void dfs(long long dep)
{
	if(dep>n)
	{
		work();
		return;
	}
	if(q[dep]!=0) 
	{
		dfs(dep+1);
		return ;
	}
	for(long long i=1;i<=n;i++) 
	{
		if(vis[i]) continue;
		vis[i]=1;
		q[dep]=i;
		dfs(dep+1);
		q[dep]=0;
		vis[i]=0;
	}
}
long long mul_(long long x)
{
	long long res=1;
	for(long long i=1;i<x;i+=2) res=(res*i)%998244353;
	res=(res*res)%998244353;
	return res;
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%lld",&n);
	for(long long i=1;i<=n;i++) scanf("%lld",&q[i]),vis[q[i]]=1;
	if(n%2==1) 
	{
		printf("0");
		return 0;
	}
	if(n>=10)
	{
		bool flag_=true;
		for(long long i=1;i<=n;i++) if(q[i]!=0) flag_=false;
		if(flag_) printf("%lld",mul_(n)%998244353);
		else printf("19260817");
	}
	else
	{
		dfs(1);
		printf("%lld",ans);
	}
	return 0;
}

