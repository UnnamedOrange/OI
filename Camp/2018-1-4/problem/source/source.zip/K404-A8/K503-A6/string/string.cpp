#include<cstdio>
#include<cstring>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
int n,i,j,k,ans,m,len[10];
char s[10][510],str[20];
bool check(){
	int i;
	rep(i,1,n){
		bool flag=false;
		rep(j,1,m*2-len[i]+1){
			bool p=true;
			rep(k,1,len[i])
			if(str[j+k-1]!=s[i][k]){
				p=false;
				break ;
			}
			if(p) {
				flag=true;
				break ;
			}
		}
		if(!flag) return false;
	}
	return true;
}
void dfs(int k){
	if(k>m){
		if(check()) ans++;
		return ;
	}
	str[k]='0'; str[2*m-k+1]='1';
	dfs(k+1);
	str[k]='1'; str[2*m-k+1]='0';
	dfs(k+1);
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n){
		scanf("%s",s[i]+1);
		len[i]=strlen(s[i]+1);
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
