#!/bin/bash
'/c/Program Files/Dev-Cpp/MinGW64/bin/g++' -g xmastree1.cpp -o xmastree1 -DDBG -Wall -Wextra -m32
