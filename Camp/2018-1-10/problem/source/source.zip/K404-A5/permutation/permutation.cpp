//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=998244353;
const int proot=3;
const int FFTmx=200111;
const int FFTpmx=262144;
ll qpow(ll x,ll k){return k==0?1:qpow(x*x%mod,k>>1)*(k&1?x:1)%mod;}
ll fac[100111],ifac[100111];
ll inv[100111];
int n,p[100111];
bool vis[100111];
int le;
void dfs(int x,int st)
{
	vis[x]=1;le++;
	if(!p[x])return;
	if(!vis[p[x]])dfs(p[x],st);
	else
	{
		if(p[x]!=st)cerr<<"FUCK!"<<endl;
		if(le&1)
		{
			puts("0");
			exit(0);
		}
	}
}
ll F[FFTmx];
bool nst[100111];
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	fac[0]=1;
	for(int i=1;i<=100005;i++)fac[i]=fac[i-1]*i%mod;
	ifac[100005]=qpow(fac[100005],mod-2);
	for(int i=100004;i>=0;i--)ifac[i]=ifac[i+1]*(i+1)%mod;
	for(int i=1;i<=100005;i++)inv[i]=ifac[i]*fac[i-1]%mod;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p[i]);
		nst[p[i]]=1;
	}
	int cnt1=0,cnt0=0;
	for(int i=1;i<=n;i++)
	{
		if(vis[i]||nst[i])continue;
		le=0;
		dfs(i,i);
		if(le&1)cnt1++;else cnt0++;
	}
	for(int i=1;i<=n;i++)
	{
		if(vis[i])continue;
		le=0;
		dfs(i,i);
	}
	
//	cerr<<"cnt0="<<cnt0<<" cnt1="<<cnt1<<endl;
	if(cnt1&1)
	{
		puts("0");
		return 0;
	}
	F[0]=1;
	ll sum0=1,sum1=0;
	for(int i=1;i<=cnt1;i++)
	{
		if(i&1)F[i]=1ll*sum1*inv[i]%mod,sum1=(sum1+F[i])%mod;
		else F[i]=1ll*sum0*inv[i]%mod,sum0=(sum0+F[i])%mod;
	}
	ll ansp=F[cnt1]*fac[cnt1]%mod;
//	cerr<<ansp<<endl;
	ll ans=ansp;
	for(int i=1;i<=cnt0;i++)ans=ans*(cnt1+i)%mod;
	cout<<(ans%mod+mod)%mod<<endl;
	return 0;
}
