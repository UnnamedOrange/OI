//O(nlgn+n^2) 30pts

#include <bits/stdc++.h>
#define REP(i, a, b) for(int i=a; i<=b; i++)
#define PER(i, b, a) for(int i=b; i>=a; i--)
#define ModAdd(x,y) (((x)%MOD+(y)%MOD)%MOD)
#define ModMul(x,y) ((((x)%MOD)*((y)%MOD))%MOD)
using namespace std;

const int MAXN = 1000, MOD = 1000000007, INF = 0x3f3f3f3f;
int N, C[MAXN+10], D[MAXN+10], opt[MAXN+10][MAXN+10], cnt[MAXN+10][MAXN+10];
int MinD[MAXN+10][22], MaxC[MAXN+10][22];
template<typename T>
inline void readint(T& x) {
	T f=1, r=0; char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	x = f*r;
}

void Init() {
	readint(N);
	REP(i, 1, N) {
		readint(C[i]); readint(D[i]);
	}
	REP(i, 1, N) {
		MinD[i][0] = D[i];
		MaxC[i][0] = C[i];
	}
	for(int j=1; j<=20; j++)
		for(int i=1; i+(1<<j)-1<=N; i++){
			MinD[i][j] = min( MinD[i][j-1], MinD[i+(1<<(j-1))][j-1] );
			MaxC[i][j] = max( MaxC[i][j-1], MaxC[i+(1<<(j-1))][j-1] );
		}
}

inline int QueryMinD(int l, int r) {
	int j;
	for(j=0; (1<<(j+1)) <= r-l+1; j++);
	return min(MinD[l][j], MinD[r-(1<<j)+1][j]);
}

inline int QueryMaxC(int l, int r) {
	int j;
	for(j=0; (1<<(j+1)) <= r-l+1; j++);
	return max(MaxC[l][j], MaxC[r-(1<<j)+1][j]);
}

void Work() {
	memset(opt, 0xcf, sizeof(opt));
	opt[1][0] = 0; cnt[1][0] = 1;
	for(int i=1; i<=N; i++)
		for(int j=0; j<i; j++) if(opt[i][j]>=0) {
			int mc, md;
			md = QueryMinD(j+1, i+1);
			mc = QueryMaxC(j+1, i);
			if(i-j+1<=md) opt[i+1][j] = max(opt[i+1][j], opt[i][j]);
			if(i-j>=mc) opt[i+1][i] = max(opt[i][j]+1, opt[i+1][i]);
		}
	for(int i=1; i<=N; i++)
		for(int j=0; j<i; j++) if(opt[i][j]>=0) {
			int mc, md;
			md = QueryMinD(j+1, i+1);
			mc = QueryMaxC(j+1, i);
			if(i-j+1<=md && opt[i+1][j] == opt[i][j]) 
				cnt[i+1][j] = ModAdd(cnt[i+1][j], cnt[i][j]);
			if(i-j>=mc && opt[i+1][i] == opt[i][j]+1) 
				cnt[i+1][i] = ModAdd(cnt[i+1][i], cnt[i][j]);
		}
	if(opt[N+1][N] >= 0)
		printf("%d %d", opt[N+1][N], cnt[N+1][N]);
	else puts("-1");
}

int main() {
#ifndef DEBUG
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
#endif
	Init(); Work();
	return 0;
}
