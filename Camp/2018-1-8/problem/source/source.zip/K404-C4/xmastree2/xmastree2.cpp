#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
long long ans=0;
int n,w[30010],r[30010],fa[30010],p[30010],du[30010];
int cnt,head[30010],to[60010],nxt[60010];
void add(int x,int y)
{
	cnt++;
	to[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
void dfs(int x)
{
	for (int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if (y==fa[x])
		{
			continue;
		}
		du[x]++;
		fa[y]=x;
		dfs(y);
	}
}
void solve(int rt)
{
	fa[rt]=0;
	dfs(rt);
	for (int i=1;i<=n;i++)
	{
		p[i]=i;
	}
	do
	{
		if (p[rt]!=1)
		{
			continue;
		}
		bool f=true;
		for (int i=1;i<=n;i++)
		{
			if (i==rt)
			{
				continue;
			}
			if (p[fa[i]]>p[i])
			{
				f=false;
				break;
			}
		}
		if (!f)
		{
			continue;
		}
		long long s=0;
		for (int i=1;i<=n;i++)
		{
			s+=1LL*w[i]*p[i];
		}
		ans=max(ans,s);
	}while (next_permutation(p+1,p+n+1));
}
priority_queue<pair<int,int> > q;
void work(int rt)
{
	fa[rt]=0;
	dfs(rt);
	while (!q.empty())
	{
		q.pop();
	}
	for (int i=1;i<=n;i++)
	{
		if (du[i]==0)
		{
			q.push(make_pair(w[i],i));
		}
	}
	long long s=0;
	int k=n;
	while (!q.empty())
	{
		int x=q.top().second;
		//cout<<x<<" ";
		int ww=q.top().first;
		s+=1LL*k*ww;
		q.pop();
		int y=fa[x];
		du[y]--;
		if (du[y]==0)
		{
			q.push(make_pair(w[y],y));
		}
		k--;
	}
	ans=max(ans,s);
	//cout<<s<<endl;
	s=0;
	k=1;
	q.push(make_pair(-w[rt],rt));
	while (!q.empty())
	{
		int x=q.top().second;
		//cout<<x<<" ";
		int ww=-q.top().first;
		s+=1LL*k*ww;
		q.pop();
		for (int i=head[x];i;i=nxt[i])
		{
			int y=to[i];
			if (y==fa[x])
			{
				continue;
			}
			q.push(make_pair(-w[y],y));
		}
		k++;
	}
	//cout<<s<<endl;
	ans=max(ans,s);
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	//scanf("%d",&n);
	n=read();
	for (int i=1;i<n;i++)
	{
		int x,y;
		x=read();
		y=read();
		add(x,y);
		add(y,x);
	}
	for (int i=1;i<=n;i++)
	{
		w[i]=read();
		r[i]=read();
	}
	if (n<=10)
	{
		for (int i=1;i<=n;i++)
		{
			if (r[i])
			{
				solve(i);
			}
		}
		printf("%lld\n",ans);
		return 0;
	}
	for (int i=1;i<=n;i++)
	{
		if (r[i])
		{
			work(i);
		}
	}
	printf("%lld\n",ans);
	return 0;
}
