#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

int type, N;

void init()
{
	
}

int encode(int x,int y)
{
	int k=x^y;
	int tmp=0;
	while(!((1<<tmp)&k)) tmp++;
	return tmp+10*((y>>tmp)&1)+1;
}

bool decode(int q,int h)
{
	h--;
	bool f=0;
	if(h>=10) h-=10,f=1;
	if(q&(1<<h)) return 1^f;
	return 0^f;
}

int main()
{
	int T;
	scanf("%d%d%d", &type, &N, &T);
	init();
	if (type==1)
		while(T--)
		{
			int x,y;
			scanf("%d%d", &x, &y);
			printf("%d\n",encode(x,y));
		}
	else
		while(T--)
		{
			int x,y;
			scanf("%d%d", &x, &y);
			puts(decode(x,y) ? "yes" : "no");
		}
}


