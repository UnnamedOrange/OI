#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define per(a,b,c) for (int a=b;a>=c;a--)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=100010,P=998244353;
int n,k;
LL cn2[N],inv[N],sinv[N],h[N],g[N],f[N],sn,ans;
LL pw2(LL k){
	LL x=2,y=1;
	while (k){
		if (k&1) y=y*x%P;
		x=x*x%P;
		k>>=1;
	}
	return y;
}
void preset(){
	sn=1;
	rep(i,1,n) sn=sn*i%P;
	inv[1]=sinv[0]=1;
	rep(i,2,n) inv[i]=inv[P%i]*(P-P/i)%P;
	rep(i,1,n) sinv[i]=sinv[i-1]*inv[i]%P;
	rep(i,1,n) cn2[i]=i*(i-1)/2;
	rep(i,1,n) h[i]=pw2(cn2[i])*sinv[i]%P;
}
void add(LL &x,LL y){x=(x+y)%P;}
LL dp(int k){
	memset(f,0,sizeof(f));
	f[0]=1;
	rep(i,0,n){
		int lim=min(n-i,k);
		rep(j,1,lim){
			add(f[i+j],g[j]*f[i]%P);
		}
	}
	return f[n]*sn%P;
}
void work1(){
	LL tp=pw2(cn2[n]);
	tp=(tp-sn)%P;
	tp=(tp+P)%P;
	printf("%lld\n",tp);
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	preset();
	if (k==3){
		work1();
		return 0;
	}
	g[1]=1,g[2]=0;
	rep(i,3,n){
		g[i]=h[i];
		rep(j,1,i-1) add(g[i],-g[j]*h[i-j]%P);
	}
	ans=dp(k)-dp(k-1);
	ans=(ans%P+P)%P;
	printf("%lld\n",ans);
	return 0;
}

