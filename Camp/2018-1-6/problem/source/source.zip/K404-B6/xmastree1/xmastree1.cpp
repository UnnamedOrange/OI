#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 100001
#define M 10000000
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
bool have[5001];
int tag[M],ls[M],rs[M];
int n,q,e,ti,siz,root[N],last[N],col[N],s[N],t[N],dft[N];
int cnt,head[N],to[N+N],nxt[N+N];
void dfs(int u,int fa)
{
	s[u]=++ti;
	dft[ti]=u;
	for(int i=head[u],v;i;i=nxt[i])
		if((v=to[i]) != fa)
			dfs(v,u);
	t[u]=ti;
}
void build(int &x,int y,int l,int r,int a,int b)
{
	x=++siz;
	ls[x]=ls[y];
	rs[x]=rs[y];
	tag[x]=tag[y];
	if(a<=l && b>=r)
	{
		++tag[x];
		return;
	}
	int mid=l+r>>1;
	if(a<=mid)build(ls[x],ls[y],l,mid,a,b);
	if(b>mid)build(rs[x],rs[y],mid+1,r,a,b);
}
int query(int x,int l,int r,int a)
{
	if(!x)return 0;
	if(l==r)return tag[x];
	int mid=l+r>>1;
	if(a<=mid)return tag[x]+query(ls[x],l,mid,a);
	else return tag[x]+query(rs[x],mid+1,r,a);
}
int main()
{
	open(xmastree1);
	re(n),re(q),re(e);
	for(int i=1;i<=n;++i)re(col[i]);
	for(int u,v,i=1;i<n;++i)
	{
		re(u),re(v);
		add_edge(u,v);
		add_edge(v,u);
	}
	dfs(1,0);	
	if(n<=5000 && q<=5000)
	{
		for(int i=1,opt,a,b,c,ans=0;i<=q;++i)
		{
			re(opt),re(a),re(b);
			if(opt==1)
			{
				re(c);
				if(e==1)	
					a^=ans,b^=ans,c^=ans;
				ans=0;
				memset(have,0,sizeof have);
				for(int j=s[a];j<=t[a];++j)
					if(!have[col[dft[j]]] && col[dft[j]]>=b && col[dft[j]]<=c)
					{
						have[col[dft[j]]]=1;
						++ans;
					}
				printf("%d\n",ans);
			}
			else 
			{
				if(e==1)
					a^=ans,b^=ans;
				col[a]=b;
			}
		}
	}
	else 
	{
		for(int i=1;i<=n;++i)	
		{
			build(root[i],root[i-1],last[col[dft[i]]]+1,i,1,n);
			last[col[dft[i]]]=i;
		}
	}
}
