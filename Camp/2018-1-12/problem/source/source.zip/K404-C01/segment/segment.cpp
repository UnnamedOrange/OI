//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=1e5+7;
const int mod=998244353;
typedef long long LL;
using namespace std;
int n,m,k,ll[N],rr[N];
LL ans,a[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

LL ksm(LL a,LL b) {
	LL base=a,res=1;
	while(b) {
		if(b&1) (res*=base)%=mod;
		(base*=base)%=mod;
		b>>=1;
	}
	return res;
}

void dfs(int cnt,int pl,int pr) {
	if(cnt==n+1) {
		for(int i=1;i<=m;i++) a[i]=0;
		for(int i=1;i<=n;i++) 
			for(int j=ll[i];j<rr[i];j++) 
				a[j]++;
		for(int i=1;i<=m;i++) 
			(ans+=ksm(a[i],k))%=mod;
		return ;
	}
	for(int i=pl+1;i<=m-(n-cnt);i++) 
		for(int j=pr+1;j<=m-(n-cnt);j++) {
			ll[cnt]=i; rr[cnt]=j;
			dfs(cnt+1,i,j);
		}
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
#endif
	read(n); read(m); read(k);
	if(n>m) puts("0");
	else {
		dfs(1,0,0);
		printf("%lld\n",ans);
	}
	return 0;
}
