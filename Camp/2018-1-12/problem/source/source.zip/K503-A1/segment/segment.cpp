#include<bits/stdc++.h>
using namespace std;
const int p=998244353;
typedef long long ll;
int n,m,k,f[360][360][360],s[360][360][360],ans,a[30];
void sp1(){
	int sum=0;
	for (int i=1;i<=n;i++)
	sum=(sum+(ll)i*(n-i+1)%p)%p;
	ans=sum;
}
int calc(int x,int y){
	if (x<y) return y-x;
	else return 0;
}
int pow(int x,int k){
	int t=1;
	for (;k;k>>=1){
		if (k&1) t=(ll)t*x%p;
		x=(ll)x*x%p;
	}
	return t;
}
void check(){
	for (int i=1;i<=m;i++)
	ans=(ans+pow(a[i],k))%p;
}
void plu(int l,int r){for (int i=l;i<r;i++) a[i]++;}
void dec(int l,int r){for (int i=l;i<r;i++) a[i]--;}
void work(int dep,int x,int y){
	if (dep>n) check();
	else {
		for (int i=x;i<=m;i++)
		for (int j=max(i,y);j<=m;j++)
		{plu(i,j);work(dep+1,i+1,j+1);dec(i,j);}
	}
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	if (n==1) sp1();
	else if (k==1){
		for (int i=0;i<=m;i++)
		for (int j=0;j<=m;j++)
		f[0][i][j]=1;
		for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
		for (int k=1;k<=m;k++){
			f[i][j][k]=(f[i][j-1][k]+f[i][j][k-1]-f[i][j-1][k-1])%p;
			s[i][j][k]=(s[i][j-1][k]+s[i][j][k-1]-s[i][j-1][k-1])%p;
			if (j<=k) {
				f[i][j][k]=(f[i][j][k]+f[i-1][j-1][k-1])%p;
				s[i][j][k]=((s[i][j][k]+s[i-1][j-1][k-1])%p+(ll)f[i-1][j-1][k-1]*calc(j,k)%p)%p;
			}
		}
		ans=s[n][m][m];
	}
	else work(1,1,1);
	printf("%d\n",ans);
	return 0;
}
