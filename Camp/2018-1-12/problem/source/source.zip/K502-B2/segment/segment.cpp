#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int P=998244353;
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
void Del(int &x,int y){
	x-=y;
	if(x<0)x+=P;
}
int fast(int x,int p){
	int re=1;
	while(p){
		if(p&1)re=(long long)re*x%P;
		x=(long long)x*x%P,p>>=1;
	}return re;
}
int n,m,K;
struct SHUI{
	int ans;
	int sum[15];
	void dfs(int x,int l,int r){
		if(x>m){
			for(int i=1,c=0;i<=n;i++){
				c+=sum[i];
				Add(ans,fast(c,K));
			}
			return;
		}
		for(l++;l<=n;l++)
			for(int pr=max(r+1,l);pr<=n;pr++)
				sum[l]++,sum[pr]--,dfs(x+1,l,pr),sum[l]--,sum[pr]++;
	}
	void solve(){
		dfs(1,0,0);
		printf("%d\n",ans);
	}
}P15;
struct IHSU{
	void solve(){
		int ans=0;
		for(int i=1;i<m;i++)Add(ans,(long long)i*(m-i)%P);
		printf("%d\n",ans);
	}
}P10;

int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d %d %d",&m,&n,&K);
	if(m>n)puts("0");
	else if(n<=6)P15.solve();
	else if(m==1)P10.solve();
	
	return 0;
}
