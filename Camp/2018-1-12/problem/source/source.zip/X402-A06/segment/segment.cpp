#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

const int mod = 998244353;

int n, m, K, Ans, a[maxn];

void Get(){
	n = read(), m = read(), K = read();
}

int ksm(int x,int k){
	int s = 1;
	while(k){
		if(k&1) s = 1ll * s * x % mod;
		x = 1ll * x * x % mod;
		k >>= 1;
	}

	return s;
}

void calc(){
	int nowans = 0;
	For(i, 1, m){
		if(!a[i]) continue;
		(nowans += ksm(a[i], K)) %= mod;
	}

	(Ans += nowans) %= mod;
}

const int maxm = 360;

int dp[maxm][maxm][maxm];

void dfs(int h,int l,int r){
	if(h == n+1){
		calc();
		return;
	}

	For(i, l+1, m){
		For(j, max(r+1, i), m){

			For(k, i, j-1) ++ a[k];
			dfs(h+1, i, j);
			For(k, i, j-1) -- a[k];

		}
	}
}

void solve_bf(){
	Ans = 0;
	dfs(1, 0, 0);
	printf("%d\n", Ans);
}

int kind[maxm][maxm][maxm];

void solve_spe(){
	For(i, 0, n)
		For(j, 0, m)
			For(k, 0, m) 
				dp[i][j][k] = -1;

	dp[0][0][0] = 0;
	kind[0][0][0] = 1;
	int Ans = 0;

	For(i, 0, n){
		For(j, 0, m){
			For(k, j, m){

				if(dp[i][j][k] == -1) continue;
				if(i == n){ (Ans += dp[i][j][k]) %= mod; continue;}

				For(u, j+1, m){
					int tmp = max(u, k+1);
					For(v, tmp, m){
						if(dp[i+1][u][v] == -1){
							dp[i+1][u][v] = (dp[i][j][k] + 1ll * kind[i][j][k] * (v-u) % mod) % mod;
						}
						else (dp[i+1][u][v] += (dp[i][j][k] + 1ll * kind[i][j][k] * (v-u) % mod)) %= mod;
						(kind[i+1][u][v] += kind[i][j][k]) %= mod;
					}
				}
			}
		}
	}

	printf("%d\n", Ans);
}

void solve_spe3(){
	For(i, 0, n)
		For(j, 0, m)
			For(k, 0, m) 
				dp[i][j][k] = -1, kind[i][j][k] = 0;

	dp[0][0][0] = 0;
	kind[0][0][0] = 1;
	int Ans = 0;

	For(i, 0, n){
		For(j, 0, m){
			For(k, j, m){

				if(dp[i][j][k] == -1) continue;
				if(i == n){ (Ans += dp[i][j][k]) %= mod; continue;}

				For(u, j+1, m){
					int tmp = max(u, k+1);
					For(v, tmp, m){
						if(dp[i+1][u][v] == -1){
							dp[i+1][u][v] = (dp[i][j][k] + 1ll * kind[i][j][k] * (v-max(u, k)) % mod) % mod;
						}
						else (dp[i+1][u][v] += (dp[i][j][k] + 1ll * kind[i][j][k] * (v-max(u, k)) % mod)) %= mod;
						(kind[i+1][u][v] += kind[i][j][k]) %= mod;
					}
				}
			}
		}
	}

	printf("%d\n", Ans);
}

void solve_spe1(){
	int cha3 = 1, cha2 = 0, cha1 = 0;
	For(i, 2, m){
		(cha2 += cha3) %= mod;
		(cha1 += cha2) %= mod;
		(cha3 += 1) %= mod;
	}

	printf("%d\n", cha1);
}

void solve_spe2(){
	int cha1 = 0, cha2 = 0, cha3 = 0, cha4 = 0, cha5 = 4;
	For(i, 3, m){
		(cha4 += cha5) %= mod;
		(cha3 += cha4) %= mod;
		(cha2 += cha3) %= mod;
		(cha1 += cha2) %= mod;
		(cha5 += 6) %= mod;
	}

	printf("%d\n", cha1);
}

void guess(){
	For(i, 1, 10){
		For(j, i, 10){
			n = i, m = j;
			printf("i : %d, j : %d, ans : ", n, m);
			solve_bf();
		}
	}
}

void solve_spe4(){
	if(m == 4){ printf("10\n"); return;}
	int cha1 = 96, cha8 = 29, cha2 = 86, cha3 = 76, cha4 = 66, cha5 = 56, cha6 = 46, cha7 = 36;
	For(i, 6, m){
		(cha7 += cha8) %= mod;
		(cha6 += cha7) %= mod;
		(cha5 += cha6) %= mod;
		(cha4 += cha5) %= mod;
		(cha3 += cha4) %= mod;
		(cha2 += cha3) %= mod;
		(cha1 += cha2) %= mod;
	}

	printf("%d\n", cha1);
}

int main(){
	
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);

	Get();
	if(n >= m){puts("0");return 0;}

	if(n == 1){
		solve_spe1();
		return 0;
	}
	if(K == 1 && n == 2){
		solve_spe2();
		return 0;
	}

	if(K == 1 && n == 3){
		solve_spe4();
		return 0;
	}

	if(m <= 6) solve_bf();
	else if(m <= 350 && (K == 1)) solve_spe();
	else if(m <= 350 && (K == 998244352)) solve_spe3();
	else solve_bf();

	return 0;
}
