#include <bits/stdc++.h>
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v ;
}
using namespace std;
int n, m, k;
const int mod = 998244353;
int mi[100005];
pair<int, int>st[10005];
int top;
inline int ksm(int x, int y) {
	if(mi[x] != -1) return mi[x];
	int ret = 1, x1 = x;
	while(y) {
		if(y & 1) ret = (long long) ret * x % mod;
		x = (long long) x * x % mod;
		y >>= 1;
	}
	return mi[x1] = ret;
}
int a[100005];
int ans;
inline void gao() {
	for(int i = 1; i <= m; ++i) {
		ans = ((long long)ans + ksm(a[i], k)) % mod;
	}
}
inline void dfs(int l, int r, int step) {
	if(step == n) {
		gao();
		//	for(int k = 1; k <= top; ++k) {
		//		printf("l = %d, r = %d ", st[top].first, st[top].second);
		//	}
//		puts("");
		return;
	}
	for(int i = l + 1; i <= m - (n - step - 1); ++i) {
		for(int j = max(r + 1, i); j <= m - (n - step - 1); ++j) {
			for(int k = i; k < j; ++k) a[k]++;
			st[++top] = make_pair(i, j);
			dfs(i, j, step + 1);
			--top;
			for(int k = i; k < j; ++k) a[k]--;
		}
	}
}
pair<int, int>dp[2][355][355];

int main() {
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	R(n), R(m), R(k);
	memset(mi, -1, sizeof(mi));
	if(n == 1) {
		for(int i = 1; i <= m; ++i) {
			ans = ((long long)ans + (long long) i * (i - 1) / 2) % mod;
		}
		printf("%d\n", ans);
		return 0;
	}
	if(m <= 6) {
		dfs(0, 0, 0);
		printf("%d\n", ans);
		return 0;
	} else {
		if(m<=40) {
			if(k == 1) {
				bool now = 0;
				dp[0][0][0] = make_pair(1, 0);
				for(int step = 0; step < n; ++step) {
					for(int l = 0; l <= m; ++l) {
						for(int r = 0; r <= m; ++r) {
							if(dp[now][l][r] != make_pair(0, 0)) {
								for(int i = l + 1; i <= m - (n - step - 1); ++i) {
									for(int j = max(r + 1, i); j <= m - (n - step - 1); ++j) {
										dp[now ^ 1][i][j].first = (dp[now ^ 1][i][j].first + dp[now][l][r].first) % mod;
										dp[now ^ 1][i][j].second = ((long long)dp[now ^ 1][i][j].second + dp[now][l][r].second + dp[now][l][r].first * (long long)(j - i)) % mod;
									}
								}
							}
						}
					}
					memset(dp[now], 0, sizeof(dp[now]));
					now ^= 1;
				}
				for(int l = 0; l <= m; ++l) {
					for(int r = 0; r <= m; ++r) {
						ans = (ans + dp[now][l][r].second) % mod;
					}
				}
				printf("%d\n", ans);
				return 0;
			} else {
				if(k == 998244352) {
					bool now = 0;
					dp[0][0][0] = make_pair(1, 0);
					for(int step = 0; step < n; ++step) {
						for(int l = 0; l <= m; ++l) {
							for(int r = 0; r <= m; ++r) {
								if(dp[now][l][r] != make_pair(0, 0)) {
									for(int i = l + 1; i <= m - (n - step - 1); ++i) {
										for(int j = max(r + 1, i); j <= m - (n - step - 1); ++j) {
											dp[now ^ 1][i][j].first = (dp[now ^ 1][i][j].first + dp[now][l][r].first) % mod;
											dp[now ^ 1][i][j].second = ((long long)dp[now ^ 1][i][j].second + dp[now][l][r].second + dp[now][l][r].first * (long long)(j - max(i, r))) % mod;
										}
									}
								}
							}
						}
						memset(dp[now], 0, sizeof(dp[now]));
						now ^= 1;
					}
					for(int l = 0; l <= m; ++l) {
						for(int r = 0; r <= m; ++r) {
							ans = (ans + dp[now][l][r].second) % mod;
						}
					}
					printf("%d\n", ans);
					return 0;
				} else {
					puts("0");
					return 0;
				}
			}
		} else {
			puts("0");
			return 0;
		}
	}
}

