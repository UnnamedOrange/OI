#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N = 1010;

int w[N];

struct Formula{
	int x, y, z, a, b, c, d, e, f;

	int calc(){
		return a * abs(w[x] - w[y]) + b * abs(w[y] - w[z]) + c * abs(w[z] - w[x]) + 
			   d * (w[x] - w[y]) + e * (w[y] - w[z]) + f * (w[z] - w[x]);
	}
}A[N];

struct Constraint{
	int x, y, r;

	bool check(){
		if(r == 0) return w[x] <= w[y];
		if(r == 1) return w[x] == w[y];
		return w[x] < w[y];
	}
}B[N];

int main(){
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);

	int Case;
	scanf("%d", &Case);
	while(Case--){
		int n, W, p, q;
		scanf("%d%d%d%d", &n, &W, &p, &q);

		For(i, 1, p) scanf("%d%d%d%d%d%d%d%d%d", &A[i].x, &A[i].y, &A[i].x, &A[i].a, &A[i].b, &A[i].c, &A[i].d, &A[i].e, &A[i].f);
		For(i, 1, q) scanf("%d%d%d", &B[i].x, &B[i].y, &B[i].r);

		int ans = 1e9;

		For(i, 0, (1 << n) - 1){

			int sum = 0;
			For(j, 1, n) w[j] = i & (1 << (j - 1)) ? 1 : -1, sum += w[j];

			bool ok = true;
			For(j, 1, q) if(!B[j].check()){
				ok = false;
				break;
			}
			if(!ok) continue;

			For(j, 1, p) sum += A[j].calc();
			if(sum < ans) ans = sum;
		}

		printf("%lld\n", 1ll * ans * W);
	}

	return 0;
}
