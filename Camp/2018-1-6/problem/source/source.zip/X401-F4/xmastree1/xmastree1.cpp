#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define maxn 10010
#define maxm 10010
int fa[maxn],siz[maxn],c[maxn][1000];
int clr[maxn];
inline int read(){
	int ret=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ret=ret*10+ch-'0';
		ch=getchar();
	}
	return ret*f;
}
int head[maxn],ecnt;
struct Edge{
	int u,v,next;
}E[maxm];
void addedge(int u,int v){
	E[++ecnt].u=u;
	E[ecnt].v=v;
	E[ecnt].next=head[u];
	head[u]=ecnt;
}
void dfs(int x,int fx){
	fa[x]=fx;
	c[fx][++siz[fx]]=x;
	for(int i=head[x];i;i=E[i].next){
		int v=E[i].v;
		if(fx==v) continue;
		dfs(v,x);
	}
}
bool vis[maxn];
int ans;
void dfs2(int x,int ql,int qr){
	if(!vis[clr[x]]&&clr[x]<=qr&&clr[x]>=ql){
		++ans;
		vis[clr[x]]=1;
	}
	for(int i=1;i<=siz[x];++i){
		dfs2(c[x][i],ql,qr);
	}
	return ;
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int n=read(),q=read(),t=read();
	for(int i=1;i<=n;++i){
		clr[i]=read();
	}
	for(int i=1;i<n;++i){
		int ua=read(),va=read();
		addedge(ua,va);
		addedge(va,ua);
	}
	dfs(1,0);
	int lstans=0;
	while(q--){
		int op=read()-1,tu,ql,qr;
		if(op){
			tu=read()^lstans;
			clr[tu]=read()^lstans;
		}
		else{
			tu=read()^lstans;
			ql=read()^lstans;
			qr=read()^lstans;
			memset(vis,0,sizeof(vis));
			ans=0;
			dfs2(tu,ql,qr);
			printf("%d\n",ans);
			if(t)lstans=ans;
		}
	}
	return 0;
}

