#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define M 52
#define N 1000001
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char temp[1<<25],*S=temp;
char ch;void re(int& x)
{
	while(ch=*S++,ch<33);x=ch-48;
	while(ch=*S++,ch>33)x=x*10+ch-48;
}
using namespace std;
int n,w[N],l[N],r[N];
double ans;
struct node
{
	int a,b;
	bool operator < (const node& i)const
	{
		return a==i.a?b<i.b:a<i.a;
	}
}e[N];
int main()
{
	open(drink);
	fread(temp,1,1<<25,stdin);
	re(n);
	for(int i=1;i<=n;++i)
	{
		re(w[i]);
		e[i].a=w[i];
		e[i].b=i;
		l[i]=i-1;
		r[i]=i+1;
	}
	sort(e+1,e+n+1);
	for(int i=1;i<=n;++i)
	{
		int x=e[i].b;
		double ea=0,eb=0;
		double ta=1,tb=1;
		for(int j=1,last=x,now=l[x];j<=M;++j)
		{
			ea+=(last-now)*ta;
			if(!now)break;
			ta/=2;
			last=now;
			now=l[now];
		}
		for(int j=1,last=x,now=r[x];j<=M;++j)
		{
			eb+=(now-last)*tb;
			if(now>n)break;
			tb/=2;
			last=now;
			now=r[now];
		}
		ans+=ea*eb*e[i].a/2;
		r[l[x]]=r[x];
		l[r[x]]=l[x];
	}
	printf("%.15lf\n",ans/n/n);
}
