#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue> 
#include <stack>
using namespace std;

const int MOD = 998244353;
long long ans = 0;
int n, m;
int a[10][110], fail[10][100], b[1200];
long long r[600], f[600][200], two[1200];

namespace Force
{
	bool findsub(int p)
	{
		int j = 0;
		for (int i = 1; i < 2 * m + 1; ++i)
		{
			while (j > 0 && a[p][j + 1] != b[i])
				j = fail[p][j];
			if (a[p][j + 1] == b[i])
				++j;
			if (j == a[p][0])
				return true;
		}
		return false;
	}
	bool check()
	{
		for (int i = m + 1; i < 2 * m + 1; ++i)
			b[i] = b[2 * m - i + 1] ^ 1;
		for (int i = 0; i < n; ++i)
		{
			if (!findsub(i))
				return false;
		}
		return true;
	}
	void dfs(int p)
	{
		if (p == m + 1)
		{
			if (check())
			{
				++ans;
				if (ans > MOD)
					ans -= MOD;
			}
		}
		else if (p < m + 1)
		{
			b[p] = 1;
			dfs(p + 1);
			b[p] = 0;
			dfs(p + 1);
		}
	}
	void main()
	{
		dfs(1);
		printf("%lld\n", ans);
	}
}

namespace Spe
{
	void main()
	{
		f[0][0] = 1;
		for (int i = 0; i < m + 1; ++i)
		{
			for (int j = a[0][0] - 1; j > 0; --j)
			{
				f[i + 1][j + 1] += f[i][j];
				f[i + 1][j + 1] %= MOD;
				f[i][fail[0][j]] += f[i][j];
				f[i][fail[0][j]] %= MOD;
			}
			f[i + 1][1] += f[i][0];
			f[i + 1][1] %= MOD;
			f[i + 1][0] += f[i][0];
			f[i + 1][0] %= MOD;
		}
		for (int i = 1; i < m + 1; ++i)
		{
			for (int j = 0; j < a[0][0]; ++j)
				r[i] = (r[i] + f[i][j]) % MOD;
		}
		long long s = two[m];
		for (int i = 0; i < a[0][0]; ++i)
			s = (s - f[m][i]) % MOD;
		for (int len = 1; len < a[0][0]; ++len)
		{
			bool ok = true;
			for (int j = 1; j < len + 1; ++j)
			{
				int r = a[0][0] - len + j, l = a[0][0] - len - j + 1;
				if (l > 0 && r > 0 && l < a[0][0] + 1 && r < a[0][0] + 1 && a[0][l] == a[0][r])
				{
					ok = false;
					break;
				}
			}
			if (ok)
				s = (s + r[m - a[0][0] + len]) % MOD;
		}
		printf("%lld\n", s % MOD);
	}
}

void getnext(int p)
{
	fail[p][0] = -1;
	fail[p][1] = 0;
	int j = 0;
	for (int i = 2; i < a[p][0] + 1; ++i)
	{
		while (j > 0 && a[p][i] != a[p][j + 1])
			j = fail[p][j];
		if (a[p][i] == a[p][j + 1])
			++j;
		fail[p][i] = j;
	}
}

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	cin >> n >> m;
	for (int i = 0; i < n; ++i)
	{
		string s;
		cin >> s;
		a[i][0] = s.size();
		for (int j = 0; j < s.size(); ++j)
			a[i][j + 1] = s[j] - '0';
		getnext(i);
	}
	two[0] = 1;
	for (int i = 1; i < 1010; ++i)
		two[i] = two[i - 1] * 2 % MOD;
	if (m <= 15)
		Force::main();
	else
		Spe::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
