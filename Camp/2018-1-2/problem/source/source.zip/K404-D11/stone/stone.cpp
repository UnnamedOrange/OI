#include<cstdio>
using namespace std;

const int maxn = 1e5 + 5, mod = 1e9 + 7;
unsigned long long n, a, b;
unsigned long long s[maxn], c[maxn];

inline unsigned long long cc(unsigned long long k, int t)
{
	//printf("k == %lld t == %d ", k, t);
	unsigned long long mu = 1, zi = 1;
	for(int i = 1; i <= t; ++i)
	{
		mu *= i; zi *= (t - i + 1);
		mu %= mod; zi %= mod; 
	}
	//if(mu != 0)
	//printf("ret == %lld\n", zi / mu);
	if(mu == 0)	return mu;
	return zi / mu;
}

int main()
{
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	scanf("%d%d%d", &n, &a, &b);
	for(int i = 1; i <= n; ++i)
		scanf("%d", &s[i]);
	if(a == b)
	{
		unsigned long long jo[maxn];
		unsigned long long mo[2]; mo[1] = 0; mo[0] = 0;
		for(int i = 1; i <= n; ++i)
		{
			c[i] = s[i] / a; jo[i] = c[i] % 2; 
			mo[jo[i]]++;
 		}
		printf("0 0 ");
		unsigned long long j_j = 0, j_ou = 0, ou = 1;
		for(int i = 1; i <= mo[1]; i = i + 2)
		{
			j_j += cc(mo[1], i); j_j %= mod;
		}
		for(int i = 0; i <= mo[1]; i = i + 2)
		{
			j_ou += cc(mo[1], i); j_ou %= mod;
		}
		for(int i = 1; i <= mo[0]; ++i)
		{
			ou *= 2; ou %= mod;
		}
		unsigned long long ans = 0;
		ans = j_j * ou; ans %= mod; printf("%lld ", ans); ans = 0;
		ans = j_ou * ou; ans %= mod; printf("%lld", ans);
		return 0;
	}
}
