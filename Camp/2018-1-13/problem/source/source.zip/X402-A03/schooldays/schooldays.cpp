/**********************************************************
	File:schooldays.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-13 11:37:06
**********************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
int main()
{
//	freopen("/home/huhao/Desktop/.out","w",stdout);
	freopen("/home/huhao/Desktop/.in","r",stdin);
	return 0;
}/*****************************************************
	File:schooldays.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-13 10:11:11
*****************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define mod 1000000007
#define N 1000010
#define inf (1<<29)
int n,m,c[N],d[N],f[N],num[N],mc,md;
int main()
{
	freopen("schooldays.out","w",stdout);
	freopen("schooldays.in","r",stdin);
	n=read();
	fr(i,1,n)
	{
		c[i]=read();
		d[i]=read();
	}
	f[1]=1;
	num[1]=1;
	fr(i,1,n)
		if(f[i])
		{
			mc=0;
			md=inf;
			int o=0;
			fr(j,i,n)
			{
				o++;
				mc=max(mc,c[j]);
				md=min(md,d[j]);
				if(o>=mc&&o<=md)
				{
					if(f[i]+1==f[j+1])
						num[j+1]=(num[j+1]+num[i])%mod;
					if(f[i]+1>f[j+1])
					{
						f[j+1]=f[i]+1;
						num[j+1]=num[i];
					}
//					printf("%d %d %d %d %d\n",i,j,o,mc,md);
				}
			}
		}
//	fr(i,1,n)
//		printf("%d%c",f[i],i==n?'\n':' ');
	if(f[n+1]==0)
		printf("-1\n");
	else
		printf("%d %d\n",f[n+1]-1,num[n+1]);
	return 0;
}