#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e5+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
template<typename T>void write(T x,char y)
{
	if(x==0)
	{
		putchar('0');putchar(y);
		return;
	}
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	static char wr[20];
	int top=0;
	for(;x;x/=10)wr[++top]=x%10+'0';
	while(top)putchar(wr[top--]);
	putchar(y);
}
const int mo=998244353;
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("permutation.in","r",stdin);
		freopen("permutation.out","w",stdout);
	#endif
}
int n,a[N],ans;
bool use[N],vis[N];
void input()
{
	n=read<int>();
	For(i,1,n)a[i]=read<int>();
}
bool check()
{
	For(i,1,n)if(a[i])return 0;
	return 1;
}
bool judge()
{
	memset(vis,0,sizeof vis);
	For(i,1,n)
	{
		if(vis[i])continue;
		static int num,now;
		now=i;num=0;
		do
		{
			num++;vis[now]=1;
			now=a[now];
		}while(i^now);
		if(num&1)return 0;
	}
	return 1;
}
void dfs(int dep)
{
	if(dep==n+1)
	{
		if(judge())
		{
			ans++;
			if(ans>=mo)ans-=mo;
		}
		return;
	}
	if(a[dep]!=0)dfs(dep+1);
	For(i,1,n)
	{
		if(!use[i])
		{
			a[dep]=i;use[i]=1;
			dfs(dep+1);
			use[i]=0;a[dep]=0;
		}
	}
}
void work()
{
	if(n&1){printf("0\n");return;}
	else if(check())
	{
		ll res=1;
		for(ll i=1;i<=n;i+=2)res=1ll*i*res%mo;
		printf("%lld\n",res*res%mo);
	}
	else if(n<=10)
	{
		For(i,1,n)use[a[i]]=1;
		dfs(1);
		printf("%d\n",ans);
	}
	else 
	{
		printf("0\n");	
	}
}
int main()
{
	file();
	input();
	work();
	return 0;
}
