#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define N 100010
using namespace std;
typedef long long LL;
int n,a,b,x[N];
LL fac[N],inv[N],tar,mod=1e9+7;
void pre()
{
	fac[0]=1;
	for(LL i=1;i<N;i++)fac[i]=fac[i-1]*i%mod;
	inv[1]=1;
	for(LL i=2;i<N;i++)inv[i]=inv[mod%i]*(mod-mod/i)%mod;
	inv[0]=1;
	for(LL i=1;i<N;i++)inv[i]=inv[i-1]*inv[i]%mod;
}
LL C(int n,int m)
{
	return fac[n]*inv[m]%mod*inv[n-m]%mod;
}
void sol1()
{
	int c1=0,c2=0;
	for(int i=1;i<=n;i++)
	{
		x[i]/=a;
		if(x[i]&1)++c1;
		else ++c2; 
	}
	LL a1=0,a2=0;
	tar=1;for(int i=1;i<=c2;i++)tar=tar*2%mod;
	for(int i=1;i<=c1;i+=2)
	a1=(a1+C(c1,i)*tar)%mod; 
	for(int i=0;i<=c1;i+=2)
	a2=(a2+C(c1,i)*tar)%mod; 
	printf("0 0 %lld %lld\n",a1,a2);
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	for(int i=1;i<=n;i++)
	scanf("%d",&x[i]);
	pre();
	if(a==b)sol1();
	return 0;
}