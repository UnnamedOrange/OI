#include <cstdio>

typedef long long ll;

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

template<typename T>
inline T get_int() {
	register int ch, flag = 1;
	register T x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int<int>(), *this; }
	const IN& operator >> (ll   &x) const { return x = get_int<ll >(), *this; }
} in;

const int MOD = 1000000007;
int S, T, N, M, Ans = 0;

template <class T>
inline void addTo(T &a, T b) { (a += b) >= MOD ? a -= MOD : 0; }

inline void init() {
	in >>S >>T >>N >>M;
}

inline void search(int pos, int rest) {
	if(pos > M) {
		++Ans;
		return;
	}
	int u = (rest > T && pos <= N) ? T : rest;
	for(int x = 1; x <= u; ++x)
		search(pos + 1, rest - x);
}

inline void solve() {
	Ans = 0;
	search(1, S);
	printf("%d\n", Ans);
}

#define PROBLEM_NAME	"success"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	init();
	solve();
	return 0;
} 
