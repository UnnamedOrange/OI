#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;
int n,m,k,cnt[10010],ans;
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(n==1)
	{
		m--;
		int tim=m/2;
		for(int i=1;i<=tim;i++) ans+=(i*(m-i+1)*2)%998244353,ans%=998244353;
		if(m%2==1) ans+=((tim+1)*(m-tim))%998244353;ans%=998244353;
		printf("%d",ans);
		return 0;
	}
	else printf("19260817");
	return 0;
}
