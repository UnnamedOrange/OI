//2018-1-4
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define N 25

int n, a[N], ans;

void Swap(int x, int y){
    while(x < y) swap(a[x++], a[y--]);
}

void Dfs(int t){
	if(t > ans) return;

	bool flag = true;
	int step = 0;
	
	For(i, 1, n){
		if(a[i] != i) flag = false;
		if(i>1 && abs(a[i]-a[i-1])!=1) ++step;
	}

	if(flag){ans = t; return;}
	if(t+step > ans) return;

	For(i, 2, n){
		Swap(1, i); Dfs(t+1); Swap(1, i);
	}
}

int main(){
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);

	int T;
	scanf("%d", &T);

	while(T--){
		scanf("%d", &n);
		For(i, 1, n) scanf("%d", &a[i]);

		ans = n << 1; Dfs(0);
		printf("%d\n", ans);
	}

	return 0;
}
