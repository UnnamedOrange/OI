#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int Mod = 998244353;
const int maxn = 6, maxm = 500;

int n, m;
char s[maxn + 5][maxm + 5];

inline void input()
{
	n = read<int>(), m = read<int>();
	REP(i, 0, n) scanf("%s", s[i]);
}

int ans;

char s0[maxm + 5];

inline bool hash_find(char *S, char *w)
{
	int L1 = strlen(S), L2 = strlen(w);
	if(L1 < L2) return 0;

	LL t1 = 0, t2 = 0, fpm = 1;
	REP(i, 0, L2)
	{
		t1 = t1 * 2 + S[i] - '0';
		t2 = t2 * 2 + w[i] - '0';
		fpm *= 2;
	}

	if(t1 == t2) return 1;
	REP(i, L2, L1)
	{
		t1 = t1 * 2 + S[i] - '0' - (S[i - L2] - '0') * fpm;
		if(t1 == t2) return 1;
	}

	return 0;
}

inline bool check()
{
	REP(i, 0, n) if(!hash_find(s0, s[i])) return 0;
	return 1;
}

inline void dfs(int dep)
{
	if(dep == m / 2)
	{
		REP(i, m / 2, m) s0[i] = !(s0[m - i - 1] - '0') + '0';
		ans += check();
		return;
	}

	s0[dep] = '0';
	dfs(dep + 1);
	s0[dep] = '1';
	dfs(dep + 1);
}

inline void solve()
{
	m *= 2, ans = 0, dfs(0);
	printf("%d\n", ans);
}

inline int fpm(int x, int y)
{
	int res = 1;
	for(x %= Mod; y; y >>= 1, x = LL(x) * x % Mod) if(y & 1) res = LL(res) * x % Mod;
	return res;
}

int f[maxm + 5][maxm + 5][maxm + 5];

inline void spe_solve()
{
	int len = strlen(s[0]);
	REP(i, 0, len) s[1][len - i - 1] = !(s[0][i] - '0') + '0';

	f[0][0][0] = 1;
	REP(i, 0, m)
		REP(j, 0, len)
			REP(k, 0, len)
			{
				(f[i + 1][j + (s[0][j] == '0')][k + (s[1][k] == '0')] += f[i][j][k]) %= Mod;
				(f[i + 1][j + (s[0][j] == '1')][k + (s[1][k] == '1')] += f[i][j][k]) %= Mod;
			}

	int sum = 0;
	REP(j, 0, len) REP(k, 0, len) (sum += f[m][j][k]) %= Mod;
	REP(i, 0, len)
		REP(j, 0, len)
			REP(k, 0, len)
				sum -= f[1][j][len - i] * f[m][i][k];

	printf("%d\n", ((fpm(2, m) - sum) % Mod + Mod) % Mod);
}

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);

	input();
	if(n == 1) spe_solve();
	else solve();

	return 0;
}

