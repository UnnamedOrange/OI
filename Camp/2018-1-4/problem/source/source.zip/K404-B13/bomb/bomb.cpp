#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn = 1e6 + 1e5, maxm = 1e6 + 1e5;
int Index,pd[maxn],DFN[maxn],LOW[maxn];
int tot,color[maxn],sum[maxn],f[maxn];
int edge,fir[maxn],Next[maxm],to[maxm];
int sta[maxn],top; //��дջ 
int n,m,val[maxn],x[maxm],y[maxm],ans;
int read(){
    int x=0,f=1; char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1; ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-48; ch=getchar();}
    return f*x;    
}
void add(int x,int y){
    to[++edge]=y; Next[edge]=fir[x]; fir[x]=edge;
}
void tarjan(int x){  
    sta[++top]=x;
    pd[x]=1;
    DFN[x]=LOW[x]= ++Index;
    for(int i=fir[x];i;i=Next[i]){
        int v=to[i];
        if(!DFN[v]){
            tarjan(v);
            LOW[x]=min(LOW[x],LOW[v]);
        }
        else if(pd[v]){
            LOW[x]=min(LOW[x],DFN[v]);
        }
    }
    if(DFN[x]==LOW[x]){
        tot++;
        while(sta[top+1]!=x){
            color[sta[top]]=tot;
            sum[tot]+=val[sta[top]];
            pd[sta[top--]]=0;
        }
    }
}
void search(int x){   //��DAG�ϼ��仯����
    if(f[x]) return ;
    f[x]=sum[x];
    int maxsum = 0;
    for(int i=fir[x];i;i=Next[i]){
        if(!f[to[i]]) search(to[i]);
        maxsum=max(maxsum,f[to[i]]);
    }
    f[x]+=maxsum;
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
    n=read(); m=read();
    for(int i=1;i<=n;i++) val[i]=1;
    for(int i=1;i<=m;i++){
        x[i]=read();                                // ���������鱣���ԭ�ߣ����ں������½�ͼ��
        y[i]=read();
        add(x[i],y[i]);
    }
    for(int i=1;i<=n;i++) if(!DFN[i]) tarjan(i);
    memset(fir,0,sizeof(fir));                 //���ԭͼ
    memset(Next,0,sizeof(Next));
    memset(to,0,sizeof(to));
    edge=0;
    for(int i=1;i<=m;i++){       //���½�ͼ��ö��ÿһ��ԭ�ߣ�������ͬһǿ��ͨ���������һ���ߣ�����ͬԭ�ߣ���
        if(color[x[i]]!=color[y[i]])
            add(color[x[i]],color[y[i]]);
    }
    for(int i=1;i<=tot;i++){  
        if(!f[i]){
            search(i);
            ans=max(ans,f[i]);
        }
    }
    printf("%d",ans);
    return 0;
}
