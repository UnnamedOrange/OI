#include <bits/stdc++.h>
using namespace std;

int MASK[100];
int L[30], R[30];
int X[30];
vector<int> nums;

int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 0; i < n; ++i) {
		cin >> L[i] >> R[i];
		nums.push_back(L[i]);
		nums.push_back(R[i]);
	}
	for (int i = 0; i < m; ++i) {
		cin >> X[i];
		nums.push_back(X[i]);
	}
	sort(nums.begin(), nums.end());
	nums.erase(unique(nums.begin(), nums.end()), nums.end());
	for (int i = 0; i < n; ++i) {
		L[i] = lower_bound(nums.begin(), nums.end(), L[i]) - nums.begin();
		R[i] = lower_bound(nums.begin(), nums.end(), R[i]) - nums.begin();
	}
	for (int i = 0; i < m; ++i) {
		X[i] = lower_bound(nums.begin(), nums.end(), X[i]) - nums.begin();
	}
	int mask = 1 << n;
	int ans = 0;
	for (int i = 0; i < mask; ++i) {
		memset(MASK, 0, sizeof(MASK));
		for (int j = 0; j < n; ++j) {
			if (i & (1 << j)) {
				for (int k = L[j]; k <= R[j]; ++k) {
					MASK[k] = 1;
				}
			}
		}
		bool ok = true;
		for (int j = 0; j < m; ++j) {
			if (!MASK[X[j]]) {
				ok = false;
				break;
			}
		}
		if (ok) {
			++ans;
		}
	}
	cout << ans;
}
