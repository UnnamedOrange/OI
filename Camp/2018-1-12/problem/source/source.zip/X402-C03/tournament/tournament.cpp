#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=300+10,mod=998244353;
int n,k,ans;
bool g[maxn][maxn],tmp[maxn];

bool dfss(int rest,int beg,int pos){
	if(!rest)
		return beg==pos;
	for(int i=1;i<=n;++i)
		if(g[pos][i]&&!tmp[i]){
			tmp[i]=true;
			if(dfss(rest-1,beg,i))
				return true;
			tmp[i]=false;
		}
	return false;
}
void dfs(int x,int y){
	if(y>n)
		++x,y=x+1;
	if(y>n){
		for(int i=1;i<=n;++i)
			tmp[i]=false;
		for(int i=1;i<=n;++i)
			if(dfss(k,i,i)){
				++ans;
				break;
			}
		return;
	}
	g[x][y]=true;
	g[y][x]=false;
	dfs(x,y+1);
	g[x][y]=false;
	g[y][x]=true;
	dfs(x,y+1);
}

int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	dfs(1,2);
	printf("%d\n",ans%mod);
	return 0;
}
