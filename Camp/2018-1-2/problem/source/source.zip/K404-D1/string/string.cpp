#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define N 110
#define ull unsigned long long
using namespace std;
int t,n;
int f[N][N];
ull pow[N],h1[N][N],h2[N][N];
char s[N];
bool check(int l1,int r1,int l2,int r2)
{
    return h1[l1][r1]*pow[r2-l2+1]+h1[l2][r2]!=h2[l2][r2]*pow[r1-l1+1]+h2[l1][r1];
}
int main()
{
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%s",&n,&s[1]);
        pow[0]=1;
        for(int i=1; i<=n; i++)
            pow[i]=pow[i-1]*29;
        for(int i=1; i<=n; i++)
            for(int j=i; j<=n; j++)
                h1[i][j]=h1[i][j-1]*29+s[j]-'a'+1;
        for(int j=1; j<=n; j++)
            for(int i=j; i; i--)
                h2[i][j]=h2[i+1][j]*29+s[i]-'a'+1;
        memset(f,63,sizeof(f));
        for(int len=2; len<=n; len++)
            for(int i=1; i+len-1<=n; i++)
            {
                int j=i+len-1;
                if(h1[i][j]!=h2[i][j])
                    f[i][j]=1;
                else
                {
                    for(int k=i+1; k<j-1; k++)
                        f[i][j]=min(f[i][j],f[i][k]+f[k+1][j]);
                    for(int l=i+1; l<j-1; l++)
                        if(f[i][l]<f[i][j]&&h1[l+1][j]!=h2[l+1][j])
                            f[i][j]=f[i][l]+1;
                    for(int k=i+2; k<j; k++)
                        if(f[k][j]<f[i][j]&&h1[i][k-1]!=h2[i][k-1])
                            f[i][j]=f[k][j]+1;
                    for(int k=i+1; k<j; k++)
                        for(int l=k+1; l<j; l++)
                            if(f[k][l]<f[i][j]&&check(i,k-1,l+1,j))
                                f[i][j]=f[k][l]+1;
                }
            }
        if(f[1][n]<1e9)
            printf("%d\n",f[1][n]);
        else puts("-1");
    }
    return 0;
}
