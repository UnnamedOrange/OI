#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
#define rep(i,l,r) for(int i=l;i<=r;++i)
const int N=1e5+5,D=998244353;
ll mi(ll x,int y=D-2)
{
	ll ans=1;
	while(y)
	{
		if(y&1)ans=ans*x%D;
		x=x*x%D;y>>=1;
	}
	return ans;
}
int du[N];
ll s[N],p_to_f[N],p_f_to[N],p[N],w[N];
char col[N];
struct edge
{
	int to,next;
};
int t[N];
edge l[N*2];int e;
#define fore(i,x) for(int i=t[x];i;i=l[i].next)
namespace P_TO_F
{
void dfs(int x,int fr)
{
	fore(i,x)
	{
		int y=l[i].to;
		if(y==fr)continue;
		dfs(y,x);
		if(du[y]==1)continue;
		p_to_f[y]=mi(du[y]-s[y]);	
		(s[x]+=p_to_f[y])%=D;
	}
}
};
namespace P_F_TO
{
void dfs(int x,int fr)
{
	fore(i,x)
	{
		int y=l[i].to;
		if(y==fr)continue;
		p_f_to[y]=mi(du[x]-s[x]+p_to_f[y]);
		p[y]=p[x]*p_f_to[y]%D;
		s[y]+=p_f_to[y];
		dfs(y,x);
	}	
}
};
namespace W
{
void dfs(int x,int fr)
{
	if(du[x]==1){w[x]=p[x];return ;}
	fore(i,x)
	{
		int y=l[i].to;
		if(y==fr)continue;
		dfs(y,x);
		ll ans=w[y];
		fore(j,y)
		{
			int c=l[j].to;
			if(c==x)continue;
			if(du[c]>1)(ans-=w[c]*mi(du[c]))%=D;
		}
		w[x]=ans*du[y]%D;
	}
	w[x]+=bool(x==1);	
}
};

int main()
{
	freopen("sad.in","r",stdin);freopen("sad.out","w",stdout);
	int n;
	cin>>n;
	scanf("%s",col+1);
	rep(i,1,n-1)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		l[++e]=(edge){y,t[x]};t[x]=e;
		l[++e]=(edge){x,t[y]};t[y]=e;
		++du[x];++du[y];
	}
	P_TO_F::dfs(1,0);
	p[1]=1;
	P_F_TO::dfs(1,0);
	W::dfs(1,0);
	ll ans=0;
	rep(i,1,n)ans+=(col[i]=='1'?w[i]:p[i]);
	cout<<(ans%D+D)%D;
}
