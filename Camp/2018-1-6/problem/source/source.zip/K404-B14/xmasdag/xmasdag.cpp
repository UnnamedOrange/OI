#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int p = 998244353;
const int MAXN = 100010;
const int MAXK = 505;
int n, m, k;
vector<int> G[MAXN];
int d[MAXN];
int q[MAXN], f, r;
int C[MAXK][MAXK];
int dp[MAXN][MAXK];
int main(){
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 1; i <= m; i++){
		int u, v;
		scanf("%d%d", &u, &v);
		G[u].PB(v);
		d[v]++;
	}
	C[0][0] = 1;
	for(int i = 1; i <= k; i++){
		C[i][0] = 1;
		for(int j = 1; j <= i; j++){
			C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % p;
		}
	}
	
	dp[1][0] = 1;
	q[r++] = 1;
	while(f < r){
		int u = q[f++];
		for(register unsigned int i = 0; i < G[u].size(); i++){
			int v = G[u][i];
			for(register int i = 0; i <= k; i++)
				for(register int j = 0; j <= i; j++)
					dp[v][i] = (dp[v][i] + (LL)dp[u][j] * C[i][j]) % p;
			if(!--d[v]) q[r++] = v;
		}
	}
	for(int i = 1; i <= n; i++) printf("%d\n", dp[i][k]);
	return 0;
}
