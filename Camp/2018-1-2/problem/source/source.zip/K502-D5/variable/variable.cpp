#include<bits/stdc++.h>
using namespace std;

const int maxn = 3000 + 10;
const int INF = 0x7fffffff;

int n,en,w,p,q;
struct edge{
	int u,v,a,b;
}e[maxn];
struct xz{
	int u,v,tp;//0<=   1=  2< 
	bool check(bool a,bool b)
	{
		if(tp==0) return a<=b;
		if(tp==1) return a==b;
		return a<b;
	}
}l[maxn];

inline void addedge(int u,int v,int a,int b)
{
	e[en].u=u;e[en].v=v;e[en].a=a;e[en++].b=b;
}

void read()
{
	int i;
	int a,b,c,d,e,f,x,y,z;
	scanf("%d%d%d%d",&n,&w,&p,&q);en=0;
	for(i=0;i<p;i++) 
	{
		scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&e,&f);
		x--;y--;z--;
		addedge(x,y,a,d);
		addedge(y,z,b,e);
		addedge(z,x,c,f);
	}
	for(i=0;i<q;i++) 
	{
		scanf("%d%d%d",&l[i].u,&l[i].v,&l[i].tp);
		l[i].u--;l[i].v--;
	}
}

int calc(int S)
{
	int i,ans=0;
	bool sta[maxn];
	
	for(i=0;i<n;i++) sta[i]=(S&1<<i)!=0;
	
	for(i=0;i<q;i++)
	{
		if(!l[i].check(sta[l[i].u],sta[l[i].v])) return INF;
	}
	
	for(i=0;i<n;i++) ans+=(sta[i]?1:-1);
	for(i=0;i<en;i++) if(sta[e[i].u]^sta[e[i].v])
	{
		if(sta[e[i].u]) ans+=e[i].a+e[i].b<<1;
		else            ans+=(e[i].a-e[i].b)*2;
	}
	return ans;
}

void solve()
{
	int S,ans=INF;
	
	for(S=0;S<(1<<n);S++)
	{
		//cout<<S<<' '<<calc(S)<<endl;
		ans=min(ans,calc(S));
	}
	cout<<1ll*ans*w<<endl;
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	
	int qq;
	cin>>qq;
	while(qq--)
	{
		read();
		solve();
	}
	
	return 0;
}
