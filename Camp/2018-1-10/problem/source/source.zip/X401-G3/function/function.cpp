#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
#define rep(i,l,r) for(int i=l;i<=r;++i)
#define per(i,r,l) for(int i=r;i>=l;--i)
namespace SHAI
{
const int N=1e7;
int miu[N],d[N],a[N];
int pr[N/10],top;
void init()
{
	miu[1]=1;
	d[1]=1;
	rep(i,2,N-1)
	{
		if(!d[i])
		{
			a[i]=1;miu[i]=-1;d[i]=2;
			pr[++top]=i;
		}
		for(int j=1,x;x=pr[j],i*x<N;++j)
		{
			if(i%x==0){ a[i*x]=a[i]+1;miu[i*x]=0;d[i*x]=d[i]/(a[i]+1)*(a[i]+2);  break;}	
			a[i*x]=1;miu[i*x]=-miu[i];d[i*x]=d[i]*2;		
		}
	}
	rep(i,1,N-1){miu[i]+=miu[i-1];d[i]=d[i]*d[i]+d[i-1];}
}
};

namespace MIU
{
map<int,int>S;
int F(int n)
{
	if(n<SHAI::N)return SHAI::miu[n];
	if(S.count(n))return S[n];
	int ans=1;
	int i=2;
	while(i<=n)
	{
		int j=n/(n/i);
		ans-=(j-i+1)*F(n/i);
		i=j+1;
	}																																		
	return S[n]=ans;
}
};

int n,m,cnt_m;
const int N=100000;
int p[N],suf[N];
namespace PR
{
int f[N],g[N];
int F(int i)
{
	return i<m?f[i]:g[n/i];
}
void init()
{
rep(i,1,m){g[i]=i-1;f[i]=n/i-1;}	
cnt_m=0;
rep(i,2,m)
{
	int p=g[i-1];
	if(g[i]==p)continue;
	::p[++cnt_m]=i;
	int i_2=i*i;
	int mj=min(m-1,n/i_2);
	rep(j,1,mj)f[j]-=F(i*j)-p;
	per(j,m,i_2)g[j]-=g[j/i]-p;	
}
}
};
namespace DP
{
ll f[N],g[N];
ll F2(int j,int i)
{
	if(i<p[j])return 1;
	return 1+2*2*(j- ((i>=p[1])?0:suf[i])  );
}
ll F(int j,int i)//return f(n/i)
{
	if(n/i>=p[j]*p[j])return i<m?f[i]:g[n/i];
	return F2(j,n/i);
}
ll G(int j,int i)
{
	if(i>=p[j]*p[j])return g[i];
	return F2(j,i);
}
void init()
{
reverse(p+1,p+cnt_m+1);
p[cnt_m+1]=0;
rep(i,1,cnt_m)
rep(j,p[i+1],p[i]-1)suf[j]=i;

rep(i,1,m){g[i]=1;f[i]=1;}
rep(j,1,cnt_m)
{
	int p_2=p[j]*p[j];
	int mi=min(m-1,n/p_2);
	rep(i,1,mi)
	{
		f[i]=F(j-1,i);
		ll x=i;
		for(int k=1;x*=p[j],x<=n;++k)
			f[i]+=(k+1)*(k+1)*F(j-1,x);
	} 
	per(i,m,p_2)
	{
		g[i]=G(j-1,i);
		int x=i;
		for(int k=1;x/=p[j],x;++k)g[i]+=(k+1)*(k+1)*G(j-1,x);
	}
}
}
};
ll D(int i)//return f(n/i)
{
	ll ans=DP::F(cnt_m,i);
	for(int j=1;n/(i*j)>m;++j)
	{
		ans+=(SHAI::d[j]-SHAI::d[j-1])*2*2*(PR::F(i*j)-cnt_m);
	}
//	if(ans!=SHAI::d[n/i])
  //		cerr<<i<<endl;
	return ans;
}

int main()
{
	freopen("function.in","r",stdin);freopen("function.out","w",stdout);
	SHAI::init();
	int tt;cin>>tt;
	while(tt--)
	{
		cin>>n;
//		if(n>=SHAI::N)continue;
		m=1;
		while(m*m<=n)++m;
		PR::init();DP::init();
		ll ans=0;
		int i=1;
		while(i<=n)
		{
			int j=n/(n/i);
			ans+=(ll)(MIU::F(j)-MIU::F(i-1))*D(i);
			i=j+1;
		}
		cout<<ans<<endl;
	}
}
