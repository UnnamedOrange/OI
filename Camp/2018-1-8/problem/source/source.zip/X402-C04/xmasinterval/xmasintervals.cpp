#include<iostream>
#include<map>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

inline int maxx(int a,int b){if(a>b)return a;return b;}
inline int minn(int a,int b){if(a<b)return a;return b;}

typedef map<int,int>::iterator it;
typedef long long ll;
const int N=500009;
const int M=N*3;
const ll md=1000000009;

map<int,int> ha;
int n,nn,m,x[N];
int tot,las[M],cnt[N],bits[M];
ll f[N],sum[N],pow2[N],bit[M];
int h[N];

inline ll chk(ll &a){if(a>=md)a-=md;}

struct node
{
	int l,r;
	bool operator < (node o)const
	{
		if(r==o.r)
			return l>o.l;
		return r<o.r;
	}
}l[N];

inline ll qpow(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1)
			ret=ret*a%md;
		a=a*a%md;
		b>>=1;
	}
	return ret;
}

inline void add(int x,ll v)
{
	for(;x<M;x+=x&-x)
		chk(bit[x]+=v);
}

inline ll query(int x)
{
	ll ret=0;
	for(;x;x-=x&-x)
		chk(ret+=bit[x]);
	return ret;
}

inline void adds(int x,int v)
{
	for(;x<M;x+=x&-x)
		bits[x]+=v;
}

inline int querys(int x)
{
	int ret=0;
	for(;x;x-=x&-x)
		ret+=bits[x];
	return ret;
}


namespace segt
{
	const int M=1e7+9;
	#define mid ((l+r)>>1)
	int ls[M],rs[M],t[M],tot;
	int stk[M],*curs;

	inline void init()
	{
		for(int i=1;i<M-3;++i)
			stk[i]=i;
		curs=&stk[M-4];
	}

	inline int allocate()
	{
		return *curs--;
	}

	inline void free(int x)
	{
		*++curs=x;
	}

	inline void cp(int x,int y)
	{
		t[x]=t[y];
		ls[x]=ls[y];
		rs[x]=rs[y];
	}

	inline int add(int pre,int l,int r,int p,int v)
	{
		int now=allocate();
		cp(now,pre);
		t[now]+=v;
		if(l==r)return now;
		if(p<=mid)
			ls[now]=add(ls[pre],l,mid,p,v);
		else
			rs[now]=add(rs[pre],mid+1,r,p,v);
		if(pre)free(pre);
		return now;
	}

	inline int query(int x,int l,int r,int dl,int dr)
	{
		if(l==dl && r==dr)
			return t[x];
		if(dr<=mid)
			return query(ls[x],l,mid,dl,dr);
		else if(mid<dl)
			return query(rs[x],mid+1,r,dl,dr);
		else
			return query(ls[x],l,mid,dl,mid)+query(rs[x],mid+1,r,mid+1,dr);
	}
}

namespace bitt
{
	int root[N];
	
	inline void modify(int x,int y,int v)
	{
		//printf("modify %d %d %d\n",x,c,v);
		for(;x<=n;x+=x&-x)
			root[x]=segt::add(root[x],1,n,y,v);
	}

	inline int query(int x,int l,int r)
	{
		//printf("query %d %d %d\n",x,l,r);
		int ret=0;
		for(;x;x-=x&-x)
			ret+=segt::query(root[x],1,n,l,r);
		return ret;
	}
}

inline void init()
{
	tot=0;
	for(it i=ha.begin();i!=ha.end();i++)
		(*i).second=++tot;
	pow2[0]=1;
	for(int i=1;i<=n;i++)
		chk(pow2[i]=pow2[i-1]*2ll);

	for(int i=1;i<=n;i++)
	{
		l[i].l=ha[l[i].l];
		l[i].r=ha[l[i].r];
	}

	for(int i=1;i<=m;i++)
		x[i]=ha[x[i]];

	sort(l+1,l+n+1);
	sort(x+1,x+n+1);

	for(int i=1;i<=m;i++)
	{
		las[x[i]]=x[i];
		sum[x[i]]++;
		printf("%d\n",x[i]);
	}
	for(int i=1;i<=tot;i++)
	{
		las[i]=maxx(las[i],las[i-1]);
		sum[i]+=sum[i-1];
	}

	int tt=0;
	for(int i=1;i<=n;i++)
		if(sum[l[i].l-1]!=sum[l[i].r])
			h[++tt]=i;
	nn=n;
	n=tt;
	for(int i=1;i<=n;i++)
		l[i]=l[h[i]];

	for(int i=1;i<=n;i++)
	{
		cnt[i]=querys(l[i].r)-querys(l[i].l-1);
		adds(l[i].l,1);
		printf("%d %d %d\n",l[i].l,l[i].r,cnt[i]);
	}
	memset(bits,0,sizeof(bits));
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasintervals.out","w",stdout);

	n=read();m=read();
	for(int i=1;i<=n;i++)
	{
		l[i].l=read(),l[i].r=read();
		ha[l[i].l];ha[l[i].r];
	}
	for(int i=1;i<=m;i++)
		ha[x[i]=read()];

	init();

	ll ans=0;
	int minl=1e9;

	for(int i=1,j=0;i<=n;i++)	
	{
		minl=minn(minl,l[i].l);
		int lx=las[l[i].l-1];cnt[i]=querys(l[i].r)-querys(lx);
		if(lx==0)
			f[i]=pow2[cnt[i]]*(1);
		else 
			chk(f[i]+=query(lx)*(pow2[cnt[i]])%md);
		printf("%d(%lld):%d %d %d\n",i,f[i],lx,query(lx),cnt[i]);

		ll invp=qpow(pow2[cnt[i]],md-2);
		add(l[i].l,f[i]*invp%md);
		add(l[i].r+1,(md-f[i])*invp%md);
		adds(l[i].l,1);

		if(l[i].r>=x[m])
			chk(ans+=f[i]);
	}

	if(x[1]<minl)ans=0;
	printf("%lld\n",ans*pow2[nn-n]);
	return 0;
}
