#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005;
int n;
struct seg_tree{
	int tot=0,rt[maxn<<2];
	struct node{
		int lc,rc,cnt,sum;
	}tr[maxn*400];
	void push_up(int p){
		tr[p].sum=tr[tr[p].lc].sum+tr[tr[p].rc].sum;
	}
	void updatey(int &p,int l,int r,int pos,int x){
		if(!p)p=++tot;
		if(l==r){
			tr[p].cnt+=x;
			tr[p].sum=(tr[p].cnt>0);
			return;
		}int mid=(l+r)>>1,u=p<<1,v=u+1;
		if(pos<=mid)updatey(tr[p].lc,l,mid,pos,x);
		else updatey(tr[p].rc,mid+1,r,pos,x);
		push_up(p);
	}
	void update(int p,int l,int r,int L,int R,int pos,int x){
		if((L<=l)&&(R>=r))return updatey(rt[p],1,n,pos,x);
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		if(L<=mid)update(u,l,mid,L,R,pos,x);
		if(R>mid)update(v,mid+1,r,L,R,pos,x);
	}
	int queryy(int p,int l,int r,int L,int R){
		if(!p)return 0;
		if((L<=l)&&(R>=r))return tr[p].sum;
		int mid=(l+r)>>1,u=p<<1,v=u+1,res=0;
		if(L<=mid)res+=queryy(tr[p].lc,l,mid,L,R);
		if(R>mid)res+=queryy(tr[p].rc,mid+1,r,L,R);
		return res;
	}
	int query(int p,int l,int r,int pos,int L,int R){
		int res=0;
		res+=queryy(rt[p],1,n,L,R);
		if(l==r)return res;
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		if(pos<=mid)res+=query(u,l,mid,pos,L,R);
		else res+=query(v,mid+1,r,pos,L,R);
		return res;
	}
}T;
vector<int>E[maxn];
int q_cnt,t,c[maxn];
int sz[maxn],Mson[maxn],fa[maxn];
int dfn[maxn],dfs_clock,top[maxn];
void dfs1(int u){
	sz[u]=1;
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if(v==fa[u])continue;
		fa[v]=u;
		dfs1(v);
		sz[u]+=sz[v];
		if(sz[v]>sz[Mson[u]])Mson[u]=v;
	}
}
void dfs2(int u){
	dfn[u]=++dfs_clock;
	if(!Mson[u])return;
	top[Mson[u]]=top[u],dfs2(Mson[u]);
	REP(i,0,E[u].size()-1){
		int v=E[u][i];
		if((v==fa[u])||(v==Mson[u]))continue;
		top[v]=v,dfs2(v);
	}
}
namespace BF{
	int fa[maxn];
	bool vis[maxn];
	void dfs(int u){
		vis[c[u]]=1;
		REP(i,0,E[u].size()-1){
			int v=E[u][i];
			if(v==fa[u])continue;
			fa[v]=u,dfs(v);
		}
	}
	int work(){
		int lstans=0;
		dfs(1);
		REP(i,1,q_cnt){
			int type=read(),u=read()^(t*lstans),x,l,r;
			if(type==1){
				l=read()^(t*lstans),r=read()^(t*lstans);
				memset(vis,0,sizeof(vis));
				dfs(u);
				int ans=0;
				REP(j,l,r)if(vis[j])++ans;
				write(lstans=ans,'\n');
			}else
				x=read()^(t*lstans),c[u]=x;
		}
		return 0;
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
#endif
	n=read(),q_cnt=read(),t=read();
	REP(i,1,n)c[i]=read();
	REP(i,1,n-1){
		int u=read(),v=read();
		E[u].pb(v),E[v].pb(u);
	}
	if((n<=5000)&&(q_cnt<=5000))return BF::work();
	dfs1(1);
	top[1]=1,dfs2(1);
	REP(i,1,n){
		int u=i;
		while(u){
			T.update(1,1,n,dfn[top[u]],dfn[u],c[i],1);
			u=fa[top[u]];
		}
	}
	cout<<T.query(1,1,n,1,1,n)<<endl;
	REP(i,1,q_cnt){
		int type=read(),u=read(),l,r,x;
		if(type==1){
			l=read(),r=read();
			write(T.query(1,1,n,dfn[u],l,r),'\n');
		}else{
			x=read();
			int v=u;
			while(u){
				T.update(1,1,n,dfn[top[u]],dfn[u],c[v],-1);
				T.update(1,1,n,dfn[top[u]],dfn[u],x,1);
				u=fa[top[u]];
			}c[v]=x;
		}
	}
	return 0;
}
