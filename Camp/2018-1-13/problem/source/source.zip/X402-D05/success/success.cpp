#include<bits/stdc++.h>
using namespace std;
const long long md=1000000007;
const int maxn=200100;
long long dp[maxn],dq[maxn];
long long fac[maxn],inv[maxn];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
long long niyuan[maxn];
long long getC(long long n,long long m){
	long long res=1;
	for(int i=1;i<=m;i++)
		res=res*((n-i+1)%md)%md*niyuan[i]%md;
	return res;
}
long long C(int n,int m){
	if(n<0||m<0||m>n) return 0;
//	cerr<<n<<" "<<m<<endl;
	return fac[n]*inv[m]%md*inv[n-m]%md;
}
long long sum[maxn];
long long A[maxn],B[maxn],c[maxn];
void Mult(long long *a,long long *b,long long n){
	for(int i=0;i<=n;i++)
		c[i]=0;
	for(int i=0;i<=n;i++)
		for(int j=0;j<=i;j++)
			c[i]=(c[i]+a[j]*b[i-j])%md;
	for(int i=0;i<=n;i++)
		a[i]=c[i];
}
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	long long n,m,t,s;
	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
	if(n==m){
		printf("%lld\n",powd(t,n));
		return 0;
	}
	s=s-n*t;
	t--;
	m=m-n;

	for(int i=1;i<maxn;i++)
		niyuan[i]=powd(i,md-2);
	fac[0]=1;
	for(int i=1;i<maxn;i++)
		fac[i]=fac[i-1]*i%md;
	inv[maxn-1]=powd(fac[maxn-1],md-2);
	for(int i=maxn-1;i>=1;i--)
		inv[i-1]=inv[i]*i%md;
	for(int i=0;i<=t;i++)
		sum[i]=(sum[i-1]+C(t,i))%md;

	for(int i=1;i<=m;i++)
		dp[i]=getC(s,i);
	dp[0]=1;
	for(int i=0;i<=m;i++)
		A[i]=dp[i];
	for(int i=0;i<=m;i++)
		B[i]=C(t+1,i+1);
	while(n){
		if(n&1) Mult(A,B,m*2);
		Mult(B,B,m*2);
		n>>=1;
	}
	printf("%lld\n",A[m]);
	return 0;
}
