cas=1
while true; do
	./test || break
	./variable ||break
	echo $cas
	cas=`expr $cas + 1`
done
