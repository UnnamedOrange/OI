#include<bits/stdc++.h>
using namespace std;
#define maxn 10005
const int mo=1e9+9;
int n,m;
struct range{
	int l,r;
	bool operator < (const range& rhs)const {
		return r<rhs.r;
	}
}R[maxn];
bool cmp2(range a,range b){
	return a.l<b.l;
}
queue<int> G[maxn]; 
int T[maxn],S[maxn];
void readit(){
	cin>>n>>m;
	for(int a,b,i=1;i<=n;i++){
		scanf("%d%d",&a,&b);
		R[i]=(range){a,b};
	}
	sort(R+1,R+n+1);
	for(int a,i=1;i<=m;i++)
		scanf("%d",&T[i]);
	sort(T+1,T+m+1);
	for(int i=1;i<=m;i++){
		range k=(range){T[i],T[i]};
		int p=lower_bound(R+1,R+n+1,k)-R;
		int q=lower_bound(R+1,R+n+1,k,cmp2)-R;
		while(R[q].l==T[i]) q++; 
		for(int j=1;j<p;j++){
			G[i].push(j);S[i]++;
		}
		for(int j=q+1;j<=n;j++){
			G[i].push(j);S[i]++;
		}
		//printf("p=%d,q=%d\n",p,q);
	}
}
void merge(int x,int y){
	queue<int> h;S[y]=0;
	while(!G[x].empty()&&!G[y].empty()){
		int a=G[x].front(),b=G[y].front();
		if(a==b){
			h.push(a);G[x].pop();G[y].pop();
		}else{
			if(a<b) G[x].pop();
			else G[y].pop();
		}
	}
	while(!G[y].empty()) G[y].pop();
	while(!h.empty()) {
		G[y].push(h.front());h.pop();S[y]++;
	}
}
long long mi(int k){
	int x=2;long long sum=1;
	while(k){
		if(k&1) sum*=x;
		x*=x;sum%=mo;x%=mo;
		k=k/2;
	} 
	return sum;
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	readit();
//	for(int i=1;i<=n;i++)
//	printf("i=%d,S[i]=%d\n",i,S[i]);
 	long long ans=mi(n);
	for(int i=0;i<n;i++){
		int f=i%2==1?1:-1;
//		printf("i=%d,f=%d:\n ",i,f);
		for(int j=n;j>=i;j--){
		//	printf(" is %d,ans=%d\n",S[i],)
			if(!S[j])continue; 
			ans+=mi(S[j])*f;
			while(ans<0)ans+=mo;
			merge(j-1,j);		
		}	
	}
	cout<<ans; 
	return 0;
}
