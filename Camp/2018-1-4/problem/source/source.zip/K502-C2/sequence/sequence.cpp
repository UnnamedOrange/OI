#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

const int M = 30;

int n, A[M];

namespace Subtask1 {
	
	const int Max = 3628805;
	
	bool used[M];
	int fact[M], Q[Max], dis[Max];
	
	int getid() {
		int rs = 0;
		for (int i = 1; i <= n; i++) used[i] = false;
		for (int i = 1; i <= n; i++) {
			int p = 1, c = 0;
			while (p < A[i]) c += !used[p], p++;
			used[p] = true;
			rs += c * fact[n - i];
		}
		return rs;
	}
	
	void getp(int v) {
		for (int i = 1; i <= n; i++) used[i] = false;
		for (int i = 1; i <= n; i++) {
			int p = 1, c = 0;
			while (used[p]) p++;
			while ((c + 1) * fact[n - i] <= v) c += !used[p++];
			while (used[p]) p++;
			v -= c * fact[n - i];
			used[p] = true;
			A[i] = p;
		}
	}
	
	int BFS() {
		int L = 0, R = -1;
		Q[++R] = getid();
		dis[Q[R]] = 0;
		if (dis[0] == 0) return 0;
		while (L <= R) {
			int now = Q[L++];
			getp(now);
			for (int i = n; i >= 1; i--) {
				if (A[i] == i) continue;
				reverse(A + 1, A + i + 1);
				int nxt = getid();
				if (dis[now] + 1 < dis[nxt]) {
					dis[nxt] = dis[now] + 1;
					Q[++R] = nxt;
					if (!nxt) return dis[nxt];
				}
				reverse(A + 1, A + i + 1);
			}
		}
		return -1;
	}
	
	void solve() {
		fact[0] = 1;
		for (int i = 1; i <= n; i++) fact[i] = fact[i - 1] * i;
		for (int i = 0; i < fact[n]; i++) dis[i] = 2 * n + 1;
		printf("%d\n", BFS());
	}
}

int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		for (int i = 1; i <= n; i++)
			scanf("%d", &A[i]);
		if (n <= 10) Subtask1::solve();
	}
	return 0;
}
