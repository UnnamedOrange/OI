#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int a[5000],b[5000];
bool mark[5000];

int work(int *a, int n, int k){
	memset(mark,0,sizeof(mark));
	int cnt=0,ans=0;
	for (int i=0;i<n;i++)
		if (!mark[a[i]]){
			mark[a[i]]=true,cnt++;
			if (cnt>=k){
				memset(mark,0,sizeof(mark));
				cnt=0; ans++;
			}
		}
	return ans+1;
}

int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	int n,m,k; scanf("%d%d%d",&n,&m,&k);
	for (int i=0;i<n;i++) scanf("%d",&a[i]);
	for (int i=0;i<m;i++) scanf("%d",&b[i]);
	printf("%d",max(work(a,n,k),work(b,m,k)));
	fclose(stdin);
	fclose(stdout);
	return 0;
}

