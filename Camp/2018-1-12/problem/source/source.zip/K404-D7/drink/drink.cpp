#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch ^ '0');
		ch = getchar();
	}
	if(p) v=-v;
}
int n, w[1000005];
multiset<int>q;
long long gao[70];
int main() {
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	R(n);
	double ans, now;
	int cnt;
	for(int i = 1; i <= n; ++i) R(w[i]);
	for(int i = 1; i <= n; ++i) {
		q.clear();
	//	printf("i = %d\n", i);
		for(int j = i; j <= n; ++j) {
	//		printf("j = %d\n", j);
			q.insert(w[j]);
			now = 0;
			cnt = 0;
			if(q.size() < 60) {
				for(multiset<int>::iterator iter = --q.end();; --iter ) {
					gao[++cnt] += *iter;
			//		printf("cnt = %d, *iter = %d\n", cnt, *iter);
					if(iter != q.begin()) continue;
					else break;
				}
			} else {
				for(multiset<int>::iterator iter = --q.end(); cnt < 60; --iter ) {
					gao[++cnt] += *iter;
				}
			}
		}
	}
	long long chu = 2;
	for(int i = 1;  i <= 60; ++i) {
//		printf("gao[%d] = %I64d\n", i, gao[i]);
		ans += (double)gao[i] / chu;
		chu<<=1;
	}
	ans /= (long long)n * n;
	printf("%0.15f\n", ans);
	return 0;
}
