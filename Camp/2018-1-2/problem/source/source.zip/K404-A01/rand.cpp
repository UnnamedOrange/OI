//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
void read(int &x)
{
  x=0;
  char c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c>='0'&&c<='9')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
int main()
{
  freopen("stone.in","w",stdout);
  int n=1e5,a=rand()%19260817,b=rand()%19260817;
  cout<<n<<" "<<a<<" "<<b<<"\n";
  for(int i=1;i<=n;i++)
    cout<<rand()<<"\n";
  return 0;
}
