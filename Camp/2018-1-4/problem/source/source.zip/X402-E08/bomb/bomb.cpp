/*
Author: CNYALI_LK
LANG: C++
PROG: bomb.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE ud\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}

#ifndef cnyali_lk
#define cnyali_lk
#endif
const int N=1000105;
struct edges{
	int beg[N],to[N],lst[N],e;
	void add(int u,int v){
		to[++e]=v;
		lst[e]=beg[u];
		beg[u]=e;
	}
};
edges a,b;
int dfn[N],low[N],col[N],stk[N],t,top,co;
int rd[N],siz[N];
void dfs(int x){
	dfn[x]=low[x]=++t;
	stk[++top]=x;
	for(int i=a.beg[x];i;i=a.lst[i]){
		if(!dfn[a.to[i]]){
			dfs(a.to[i]);
			chkmin(low[x],low[a.to[i]]);
		}
		else if(!col[a.to[i]])chkmin(low[x],dfn[a.to[i]]);
	}
	if(dfn[x]==low[x]){
		stk[top+1]=-1;
		++co;
		while(stk[top+1]!=x){
			++siz[co];
			col[stk[top]]=co;
			--top;
		}
	}
}
void sd(int n){
	for(int i=1;i<=n;++i)for(int j=a.beg[i];j;j=a.lst[j]){
		if(col[i]!=col[a.to[j]]){
			b.add(col[i],col[a.to[j]]);
			++rd[col[a.to[j]]];
		}
	}
}
int f[1024242];
void js(int x){
	rd[x]=-1;
	f[x]+=siz[x];
	for(int i=b.beg[x];i;i=b.lst[i]){
		chkmax(f[b.to[i]],f[x]);	
		if(!(--rd[b.to[i]]))js(b.to[i]);
	}
}
int main(){
#ifdef cnyali_lk
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
#endif
	int n,m,u,v;
	n=read();m=read();
	for(int i=1;i<=m;++i){
		u=read();v=read();
		a.add(u,v);
	}
	for(int i=1;i<=n;++i)if(!dfn[i])dfs(i);
	sd(n);
	for(int i=1;i<=co;++i)if(!rd[i])js(i);
	int ans=0;
	for(int i=1;i<=co;++i)chkmax(ans,f[i]);
	write(ans,'\n');
	return 0;
}

