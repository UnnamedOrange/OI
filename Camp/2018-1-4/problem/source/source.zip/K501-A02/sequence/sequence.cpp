#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
int n,k;
int ans,flag;
int a[50];
void work(int x){
	for (int i=1;i*2<=x;++i){
		int t=a[i];
		a[i]=a[x-i+1];
		a[x-i+1]=t;
	}
}
void solve(int x,int y){
	if (x+y>ans) return;
	int f=1;
	for (int i=1;i<=n;++i)
		if (a[i]!=i){
			f=0;
			break;
		}
	if (f) flag=1;
	if (flag) return;
	for (int i=2;i<=n;++i){
		int ny=y;
		if (i<n){
			if (a[i]-a[i+1]==1 || a[i]-a[i+1]==-1)
				ny++;
			if (a[1]-a[i+1]==1 || a[1]-a[i+1]==-1)
				ny--;
		}
		work(i);
		solve(x+1,ny);
		work(i);
		if (flag) return;
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout); 
	int T=read();
	while (T--){
		n=read();
		k=0;
		for (int i=1;i<=n;++i)
			a[i]=read();
		for (int i=1;i<n;++i)
			if (a[i]-a[i+1]>1 || a[i+1]-a[i]>1)
				k++;
		ans=flag=0;
		while (1){
			solve(0,k);
			if (flag) break;
			ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}

