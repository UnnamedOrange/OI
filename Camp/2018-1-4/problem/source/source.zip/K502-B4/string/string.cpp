#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,m,s[210],map[10][200],next[10][200],len[10],ans;
char a[200];
void get_next(int x)
{
	next[x][0]=-1;
	int k=-1,j=0;
	while(j<len[x])
	{
		if(k==-1 || map[x][j]==map[x][k]) next[x][++j]=++k;
		else k=next[x][k];
	}
}
bool check(int x)
{
	int i=0,j=0;
	while(i<2*m)
	{
		if(j==-1 || s[i]==map[x][j]) i++,j++;
		else j=next[x][j];
		if(j==len[x]) return true;
	}
	return false;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("stirng.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",a);
		len[i]=strlen(a);
		for(int j=0;j<len[i];j++) map[i][j]=a[j]-'0';
	}
	for(int i=1;i<=n;i++) get_next(i);
	for(int i=0;i<=(1<<m)-1;i++)
	{
		memset(s,0,sizeof(s));
		for(int j=0;j<m;j++) if(i&(1<<(j)))s[j]=1;
		for(int j=2*m-1;j>=m;j--) s[j]=1-s[2*m-j-1];
		bool flag=true;
		for(int j=1;j<=n;j++) 
			if(!check(j)) flag=false;
		if(flag) ans++;
	}
	printf("%d",ans);
	return 0;
}
