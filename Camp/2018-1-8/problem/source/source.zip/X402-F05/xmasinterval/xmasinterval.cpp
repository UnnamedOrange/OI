#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for(int i = j; i <= k; i++)
#define Forr(i, j, k) for(int i = j; i >= k; i--)

using namespace std;

int Read(){
	char c = getchar();
	while(c > '9' || c < '0') c = getchar();
	int x = c - '0'; c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

typedef long long LL;

const int Mod = 1e9 + 9;
const int N = 5e5 + 10;

struct Segment_Tree{

	LL mulv[N << 2], sum[N << 2];

	Segment_Tree(){
		For(i, 0, (N << 2) - 1) mulv[i] = 1;
	}

	#define M ((L + R) >> 1)
	#define lc (o << 1)
	#define rc (o << 1 | 1)

	/*
	void pushdown(int o){
		if(mulv[o] == 1) return;
		mulv[lc] = mulv[lc] * mulv[o] % Mod, mulv[rc] = mulv[rc] * mulv[o] % Mod;
		sum[lc] = sum[lc] * mulv[o] % Mod, sum[rc] = sum[rc] * mulv[o] % Mod;
		mulv[o] = 1;
	}
	*/

	void add(int o, int L, int R, int x, LL val){
		assert(mulv[o] == 1);
		sum[o] = (sum[o] + val) % Mod;
		if(L < R) 
			x <= M ? add(lc, L, M, x, val) : add(rc, M + 1, R, x, val);
	}

	void mul(int o, int L, int R, int l, int r){
		if(l <= L && R <= r){
			mulv[o] = mulv[o] * 2 % Mod;
			sum[o] = sum[o] * 2 % Mod;
		}
		else{
			if(l <= M) mul(lc, L, M, l, r);
			if(r > M) mul(rc, M + 1, R, l, r);
			sum[o] = (sum[lc] + sum[rc]) * mulv[o] % Mod;
		}
	}

	LL query(int o, int L, int R, int l, int r){
		if(l <= L && R <= r) return sum[o];
		else{
			LL ret = 0;
			if(l <= M) ret = query(lc, L, M, l, r);
			if(r > M) ret += query(rc, M + 1, R, l, r);
			return ret * mulv[o] % Mod;
		}
	}

}T;

struct Interval{
	int l, r;

	bool operator < (const Interval& A) const{
		return r < A.r;
	}
}A[N];

int num[N], n, m;

int main(){

	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);

	n = Read(), m = Read();
	For(i, 1, n) A[i].l = Read(), A[i].r = Read();
	sort(A + 1, A + n + 1);
	For(i, 1, m) num[i] = Read();
	num[++m] = 0;
	sort(num + 1, num + m + 1), m = int(unique(num + 1, num + m + 1) - num) - 1;
	For(i, 1, n) A[i].l = lower_bound(num + 1, num + m + 1, A[i].l) - num, 
				 A[i].r = upper_bound(num + 1, num + m + 1, A[i].r) - num - 1;


	T.add(1, 1, m, 1, 1);
	LL coe = 1, ans = 1;

	For(i, 1, n){
		if(A[i].l > A[i].r){
			coe = (coe << 1) % Mod;
			continue;
		}
		
		ans = T.query(1, 1, m, A[i].l - 1, A[i].r);

		T.add(1, 1, m, A[i].r, ans);
		if(A[i].l > 2) T.mul(1, 1, m, 1, A[i].l - 2);
	}

	ans = T.query(1, 1, m, m, m) * coe % Mod;
	printf("%lld\n", ans);

	return 0;
}
