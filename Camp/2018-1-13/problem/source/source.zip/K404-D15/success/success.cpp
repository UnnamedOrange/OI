#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int mod=1e9+7;

int s,t,n,m;

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

namespace task1{
	const int maxn=105;
	int f[maxn][maxn];
	void solve(){
		f[0][0]=1;
		for (int i=1;i<=n;i++)
			for (int j=1;j<=s;j++)
				for (int k=1;k<=min(j,t);k++)
					f[i][j]=(f[i][j]+f[i-1][j-k])%mod;
		for (int i=n+1;i<=m;i++)
			for (int j=1;j<=s;j++)
				for (int k=1;k<=j;k++)
					f[i][j]=(f[i][j]+f[i-1][j-k])%mod;
		int ans=0;
		for (int i=1;i<=s;i++) ans=(ans+f[m][i])%mod;
		cout<<ans<<endl;
	}
}
/*
namespace task2{
	void solve(){
		s-=m;
		if (s<0){puts("0"); return;}
		if (!s){puts("1"); return;}
		
	}
	}*/

int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	s=read(),t=read(),n=read(),m=read();
	if (s<=100&&t<=100&&n<=100&&m<=100) task1::solve();
	//	else if (m<=1000000&&s<=1000000) task2::solve();
	return 0;
}
