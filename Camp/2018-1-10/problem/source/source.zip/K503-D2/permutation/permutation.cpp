#include<bits/stdc++.h>
#define mo 998244353
using namespace std;
long long a[100010],f[100010]={0},n,ansn=0;
int dfs1(int x,int be,int nu){
	if (nu>n) return 0;
	if (nu!=0&&be==x){
		if (nu%2==0) return 2;return 1;
	}
	return dfs1(a[x],be,nu+1);
}
void dfs(int x){
	if (x>n){
		for (int i=1;i<=n;i++){
			int gx=dfs1(i,i,0);
			if (gx==1)return ;
		}
		ansn++;
	}else{
		if (a[x]!=0){
			dfs(x+1);
		}else{
			for (int i=1;i<=n;i++){
				if (f[i]==0){
					a[x]=i;
					f[i]=1;dfs(x+1);f[i]=0;
					a[x]=0;
				}
			}
		}
	}
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++){
		cin>>a[i];
		if (a[i]!=0) f[a[i]]=1;
		if (a[i]==i){
			cout<<"0"<<endl;
			return 0;
		}
	}
	if (n<=8){
		dfs(1);
		cout<<ansn<<endl;	
	}else{
		if (n%2==1){
			cout<<"0"<<endl;
		}else{
			int sum=0;ansn=1;
			for (int i=1;i<=n;i++){
				if (a[i]!=0) sum++;
			}
			for (int i=n-1;i>=1;i-=2){
				if (sum>=2) sum-=2;
				else{
					if (sum==1) sum--,ansn=(ansn*i)%mo;
					else ansn=((ansn*i)%mo*i)%mo;
				}
			}
			cout<<ansn<<endl;
		}
	}
}
/*
1 0
2 1  1 
3 0
4 9  3
5 0
6 225  15 3*5
7 0
8 11025  105 3*5*7
9 0
10 893025  3*5*7*9
8 10
*/
