#include<bits/stdc++.h>
using namespace std;
int n,a[1000010],f[50];
double p[30],ansn=0,sum=0;
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)scanf("%d",&a[i]);
	p[0]=1;
	for (int i=1;i<=28;i++)p[i]=p[i-1]/2;
	f[0]=100000000;
	for (int l=1;l<=n;l++){
		sum=0;
		for (int j=1;j<=28;j++) f[j]=0;
		for (int r=l;r<=n;r++){
			if (a[r]>f[28]);
			for (int k=27;k>=0;k--){
				if (a[r]<f[k]){
					for (int l=27;l>=k+1;l--)f[l+1]=f[l];
					f[k+1]=a[r];sum=0;
					for (int i=1;i<=28;i++)sum=sum+f[i]*p[i];
					break;
				}
			}
			ansn+=sum;
		}
	}
	printf("%.6lf",ansn/n/n);
    return 0;
}
