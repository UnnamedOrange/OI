#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=500010;
const int inf=0x3f3f3f3f;
const int mod=1e9+9;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval1.out","w",stdout);
}
int n,m,ans;
int x[N],p[N],vis[N];
struct node
{
	int l,r;
	node(){}
	node(int l,int r):l(l),r(r){}
}a[N];
inline bool operator<(const node&A,const node&B){return A.r==B.r?A.l<B.l:A.r<B.r;}
inline void Add(int&x,int y){x=x+y<mod?x+y:x+y-mod;}
inline bool check()
{
	For(i,1,m)vis[i]=0;
	For(i,1,n)
		if(p[i])
			For(j,a[i].l,a[i].r)
				vis[j]=1;
	For(i,1,m)if(!vis[i])return 0;
	return 1;
}
inline void dfs(int now)
{
	if(now==n+1)
	{
		if(check())ans++;
		return;
	}
	p[now]=1;
	dfs(now+1);
	p[now]=0;
	dfs(now+1);
}
int main()
{
	file();
	read(n),read(m);
	For(i,1,n)read(a[i].l),read(a[i].r);
	For(i,1,m)read(x[i]);
	sort(x+1,x+m+1);
	For(i,1,n)
	{
		a[i].l=lower_bound(x+1,x+m+1,a[i].l)-x;
		a[i].r=upper_bound(x+1,x+m+1,a[i].r)-x-1;
	}
	dfs(1);
	printf("%d\n",ans);
	cerr<<ans<<endl;
	return 0;
}
