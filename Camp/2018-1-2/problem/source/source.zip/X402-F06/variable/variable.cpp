#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmin(ll &x,ll y){return y<x?(x=y,1):0;}
const int maxn=1000+10;
const ll inf=1e18;
struct point{
	int x,y,z,a,b,c,d,e,f;
	void input(){
		x=read(),y=read(),z=read(),a=read(),b=read(),c=read(),d=read(),e=read(),f=read();
	}
	ll work(int *B){
		return 1ll*a*abs(B[x]-B[y])+1ll*b*abs(B[y]-B[z])+1ll*c*abs(B[z]-B[x])+1ll*d*(B[x]-B[y])+1ll*e*(B[y]-B[z])+1ll*f*(B[z]-B[x]);
	}
}a[maxn];
int b[maxn];
int qx[maxn],qy[maxn],qz[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
#endif
	int T=read();
	while(T--){
		int n=read(),W=read(),m=read(),q=read();
		REP(i,1,m) a[i].input();
		REP(i,1,q) qx[i]=read(),qy[i]=read(),qz[i]=read();
		ll ans=inf;
		REP(i,0,(1<<n)-1){
			ll sum=0;
			REP(k,1,n){
				if(i&(1<<k-1)) b[i]=1;else b[k]=-1;
				sum+=b[k];
			}
			bool flag=0;
			REP(k,1,q){
				if(qz[k]==0 && b[qx[k]]>b[qy[k]]){flag=1;break;}
				else if(qz[k]==1 && b[qy[k]]!=b[qx[k]]){flag=1;break;}
				else if(qz[k]==2 && b[qx[k]]>=b[qy[k]]){flag=1;break;}
			}
			if(flag) continue;
			REP(j,1,m) sum+=a[j].work(b);
			chkmin(ans,sum);
		}
		printf("%lld\n",ans*W);
	}
	return 0;
}
