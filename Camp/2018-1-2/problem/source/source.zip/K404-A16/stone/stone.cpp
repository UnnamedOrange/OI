#include <cstdio>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)
using namespace std;

typedef long long ll;
const int mod = 1e9 + 7;
int n, a, b, num[2], x[100010];
ll ans;

ll pow(ll x, int y)
{
	ll ans = 1;
	for(; y; y >>= 1)
	{
		if (y & 1) ans = ans * x % mod;
		x = x * x % mod;
	}
	return ans;
}

void spe()
{
	FOR(i, 1, n) num[(x[i] / a) & 1]++;
	ans = pow(2, n - 1);
	if (num[1])
	{
		printf("0 0 %d ", ans);
		printf("%d\n", ans);
	}
	else printf("0 0 0 %d\n", ans * 2 % mod);
}

int main()
{
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	scanf("%d%d%d", &n, &a, &b);
	FOR(i, 1, n) scanf("%d", &x[i]);
	if (a == b) {spe(); return 0;}
	return 0;
}
