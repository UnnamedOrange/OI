#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long
#define lson (p << 1)
#define rson (p << 1 | 1)

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while(c = getchar(), c >= '0');
}

const int M = (int) 5e5 + 5;
const int P = (int) 1e9 + 9;

struct Node {
	int L, R;
	bool operator < (const Node &_) const {
		if (L != _.L) return L < _.L;
		else return R > _.R;
	}
} A[M];

int n, m, sz, L[M], R[M], X[M], dp[M], pw[M];
int sum[M << 2], add[M << 2];

inline void Add(int &a, int b) {
	a += b;
	if (a >= P) a -= P;
}

inline void Up(int p) {
	sum[p] = sum[lson] + sum[rson];
	if (sum[p] >= P) sum[p] -= P;
}

inline void Down(int p) {
	if (add[p] == 1) return;
	add[lson] = (ll) add[lson] * add[p] % P;
	add[rson] = (ll) add[rson] * add[p] % P;
	sum[lson] = (ll) sum[lson] * add[p] % P;
	sum[rson] = (ll) sum[rson] * add[p] % P;
	add[p] = 1;
}

void Build(int L, int R, int p) {
	add[p] = 1;
	if (L == R) return;
	int mid = (L + R) >> 1;
	Build(L, mid, lson);
	Build(mid + 1, R, rson);
}

void Modify(int L, int R, int x, int v, int p) {
	if (L == R) {
		Add(sum[p], v);
		return;
	}
	Down(p);
	int mid = (L + R) >> 1;
	if (x <= mid) Modify(L, mid, x, v, lson);
	else Modify(mid + 1, R, x, v, rson);
	Up(p);
}

void Update(int L, int R, int l, int r, int p) {
	if (L == l && r == R) {
		Add(add[p], add[p]);
		Add(sum[p], sum[p]);
		return;
	}
	Down(p);
	int mid = (L + R) >> 1;
	if (r <= mid) Update(L, mid, l, r, lson);
	else if (l > mid) Update(mid + 1, R, l, r, rson);
	else Update(L, mid, l, mid, lson), Update(mid + 1, R, mid + 1, r, rson);
	Up(p);
}

int Query(int L, int R, int l, int r, int p) {
	if (L == l && r == R) return sum[p];
	Down(p);
	int mid = (L + R) >> 1;
	if (r <= mid) return Query(L, mid, l, r, lson);
	else if (l > mid) return Query(mid + 1, R, l, r, rson);
	else return (Query(L, mid, l, mid, lson) + Query(mid + 1, R, mid + 1, r, rson)) % P;
}

namespace BIT {
	
	#define lowbit(x) ((x) & (-x))
	
	int cnt[M];
	
	void Update(int x) {
		while (x <= m) {
			cnt[x]++;
			x += lowbit(x);
		}
	}
	
	int Query(int x) {
		int rs = 0;
		while (x) {
			rs += cnt[x];
			x -= lowbit(x);
		}
		return rs;
	}
	
}

int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	Rd(n), Rd(m);
	for (int i = 1; i <= n; i++) Rd(L[i]), Rd(R[i]);
	for (int i = 1; i <= m; i++) Rd(X[i]);
	pw[0] = 1;
	for (int i = 1; i <= n; i++) pw[i] = (ll) 2 * pw[i - 1] % P;
	sort(X + 1, X + m + 1);
	m = unique(X + 1, X + m + 1) - X - 1;
	int cntemp = 0;
	for (int i = 1; i <= n; i++) {
		A[i].L = lower_bound(X + 1, X + m + 1, L[i]) - X;
		A[i].R = upper_bound(X + 1, X + m + 1, R[i]) - X - 1;
		if (A[i].L > A[i].R) cntemp++;
		else A[++sz] = A[i];
	}
	n = sz;
	sort(A + 1, A + n + 1);
	Build(1, m ,1);
	for (int i = 1; i <= n; i++) {
		if (A[i].L == 1) dp[i] = 1;
		if (A[i].R > 1) Add(dp[i], Query(1, m, max(1, A[i].L - 1), A[i].R - 1, 1));
		Update(1, m, A[i].R, m, 1);
		Modify(1, m, A[i].R, dp[i], 1);
	}
	int ans = 0;
	for (int i = n; i >= 1; i--) {
		if (A[i].R == m) Add(ans, (ll) dp[i] * pw[BIT::Query(m - A[i].L + 1)] % P);
		BIT::Update(m - A[i].R + 1);
	}
	ans = (ll) ans * pw[cntemp] % P;
	printf("%d\n", ans);
	return 0;
}
