#include <stdio.h>
#include <vector>
#include <set>
#include <bitset>
#include <string.h>
#include <algorithm>
#include <queue>
#include <cctype>
using namespace std;
#define rep(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_ ; ++i)
#define drep(i, a, b) for(register int i = (a), i##_end_ = (b); i >= i##_end_ ; --i)
typedef long long LL;
#define inf (0x3f3f3f3f)
int read() {
	int x = 0, flag = 1;
	char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') flag = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		x = (x << 3) + (x << 1) + (ch - 0x30);
		ch = getchar();
	}
	return flag * x;
}
#define Maxn 100009
#define Mod (998244353)

int n, p[Maxn];
int vis[Maxn];
int res, flag;
int ans;
void dfs(int a) {
	++res;
	if(!p[a]) return ;
	vis[a] = 1;
	if(flag) return ;
	if(vis[p[a]]) {
		flag = 1;
		return ;
	} else dfs(p[a]);
}
int main() {
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d", &n);
	if(n & 1) {
		printf("%d\n", 0);
		return 0;
	}
	rep(i, 1, n) scanf("%d", &p[i]);
	int x = 0, y = 0;
	rep(i, 1, n) 
		if(!vis[i]){
			res = 0, flag = 0, dfs(i);
			if(flag && (res & 1)) {
				printf("0\n");
				return 0;
			}
			if(!flag)
				if(res & 1) ++x; else ++y;
		}
	int tmp = 1;
	for(int i = 1; i <= x; i += 2)
		tmp = (1ll * tmp * i) % Mod;
	tmp = tmp * 1ll * tmp % Mod; 
	// UP
	ans = tmp;
	rep(i, 1, y - 1) 
		ans = 1ll * ans * (x + i) % Mod;
	printf("%d\n", ans);
	return 0;
}
