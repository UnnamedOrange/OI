#include <bits/stdc++.h>

const int N = 30;

int l[N], r[N], p[N], n, m;
int s[N];

int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.ans", "w", stdout);

	scanf("%d%d", &n, &m);
	for(int i = 0; i < n; ++i) scanf("%d%d", &l[i], &r[i]);
	for(int i = 0; i < m; ++i) scanf("%d", &p[i]);
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < m; ++j)
			if(p[j] >= l[i] && p[j] <= r[i])
				s[i] |= 1 << j;
	}

	int ans = 0;
	for(int i = 0; i < (1<<n); ++i){
		int sit = 0;
		for(int j = 0; j < n; ++j)
			if(i & (1 << j)) sit |= s[j];
		ans += sit == ((1<<m)-1);
	}
	printf("%d\n", ans);

	return 0;
}
