#include <bits/stdc++.h>
#define N 510
using namespace std;
int n,m,k,f[N][N],a[N],b[N],pa[N],pb[N];

int main(){
//	cout << sizeof(f)/1024/1024;
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if (!pa[a[i]]) pa[a[i]]=i;
	}
	for (int i=1;i<=m;i++){
		scanf("%d",&b[i]);
		if (!pb[b[i]]) pb[b[i]]=i;
	}
	for (int i=0;i<=n;i++)
		for (int j=0;j<=m;j++)
			f[i][j]=max(n,m)+1;
	for (int i=1;i<=k;i++)
		f[pa[i]][pb[i]]=1;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			if (f[i][j]!=N){
				for (int l=1;l<=k;l++)
					pa[l]=pb[l]=0;
				for (int l=i+1;l<=n;l++)
					if (!pa[a[l]]) pa[a[l]]=l;
				for (int l=j+1;l<=m;l++)
					if (!pb[b[l]]) pb[b[l]]=l;
				for (int l=1;l<=k;l++)
					f[pa[l]][pb[l]]=min(f[pa[l]][pb[l]],f[i][j]+1);
			}
	for (int i=1;i<=n;i++)
		if (f[i][0]!=N){
			for (int l=1;l<=k;l++)
				pa[l]=0;
			for (int l=i+1;l<=n;l++)
				if (!pa[a[l]]) pa[a[l]]=l;
			for (int l=1;l<=k;l++)
				f[pa[l]][0]=min(f[pa[l]][0],f[i][0]+1);
		}
	for (int i=1;i<=m;i++)
		if (f[0][i]!=N){
			for (int l=1;l<=k;l++)
				pb[l]=0;
			for (int l=i+1;l<=m;l++)
				if (!pb[b[l]]) pb[b[l]]=l;
			for (int l=1;l<=k;l++)
				f[0][pb[l]]=min(f[0][pb[l]],f[0][i]+1);
		}
	printf("%d\n",f[0][0]);
	return 0;
}
