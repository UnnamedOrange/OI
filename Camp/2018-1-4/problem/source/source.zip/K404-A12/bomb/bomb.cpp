#include <iostream>
#include <cstdio>
#include <cstring>
#define N 1000005
using namespace std;
char buf[30000005],*p1=buf-1;
int read(){
	char c=*(++p1);int w=0,f=0;
	while(c<'0'||c>'9'){if(c=='-') f=1;c=*(++p1);}
	while(c>='0'&&c<='9'){w=(w<<3)+(w<<1)+c-'0';c=*(++p1);}
	return f?-w:w;
}
struct edge{
	int k,next;
}e[N<<1];
int home1[N],cnt=-1,n,m,home[N];
void add(int *home,int x,int y){
	cnt++;
	e[cnt].k=y;
	e[cnt].next=home[x];
	home[x]=cnt;
}
int dfn[N],mn[N],s[N],top,cc=0,id[N],tot,sum[N];
bool ins[N];
void tarjan(int k){
	dfn[k]=mn[k]=++cc;s[++top]=k;ins[k]=1;
	for(int i=home1[k];~i;i=e[i].next){
		if(!dfn[e[i].k]){
			tarjan(e[i].k);
			mn[k]=min(mn[k],mn[e[i].k]);
		}
		else if(ins[e[i].k]) mn[k]=min(mn[k],mn[e[i].k]);
	}
	if(dfn[k]==mn[k]){
		id[k]=++tot;
		ins[k]=0;
		sum[tot]++;
		while(s[top]!=k){
			ins[s[top]]=0;
			id[s[top]]=tot;
			sum[tot]++;
			top--;
		}
		top--;
	}
}
int mx[N],IN[N],ans;
void topsort(){
	top=0;
	for(int i=1;i<=tot;i++) if(!IN[i]) s[++top]=i;
	for(int i=1;i<=tot;i++){
		mx[s[i]]+=sum[s[i]];
		for(int p=home[s[i]];~p;p=e[p].next){
			mx[e[p].k]=max(mx[e[p].k],mx[s[i]]);
			IN[e[p].k]--;
			if(!IN[e[p].k]) s[++top]=e[p].k;
		}
		ans=max(ans,mx[s[i]]);
	}
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	fread(buf,1,sizeof(buf),stdin);
	memset(home,-1,sizeof(home));
	memset(home1,-1,sizeof(home1));
	n=read();m=read();
	for(int i=1,x,y;i<=m;i++){
		x=read();y=read();
		add(home1,x,y);
	}
	for(int i=1;i<=n;i++) if(!dfn[i]) cc=0,tarjan(i);
	for(int i=1;i<=n;i++){
		for(int p=home1[i];~p;p=e[p].next){
			if(id[e[p].k]!=id[i]) add(home,id[i],id[e[p].k]),IN[id[e[p].k]]++;
		}
	}
	topsort();
	printf("%d",ans);
	return 0;
} 
