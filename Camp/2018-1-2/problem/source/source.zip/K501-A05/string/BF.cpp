#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int maxn = int(1e5);

int n;

char s[maxn + 5];

inline void input()
{
	n = read<int>();
	scanf("%s", s);
}

inline bool check(int l, int r)
{
	for(int i = l, j = r; i < j; ++i, --j)
		if(s[i] != s[j]) return 0;
	return 1;
}

char swp[maxn + 5];

inline void solve()
{
	if(!check(0, n - 1))
	{
		puts("1");
		return;
	}

	REP(i, 0, n - 1)
		REP(j, i + 1, n)
		if(!check(i, j))
		{
			for(int k = i; k <= j; ++k) swp[k - i] = s[k];
			REP(k, i, n) s[k] = s[k + (j - i + 1)];

			if(!check(0, n - 1 - (j - i + 1)))
			{
				puts("2");
				return;
			}

			REP(k, i, n) s[k + (j - i + 1)] = s[k];
			for(int k = i; k <= j; ++k) s[k] = swp[k - i];
		}

	puts("-1");
}

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.ans", "w", stdout);

	int T = read<int>();
	while(T--)
	{
		input();
		solve();
	}

	return 0;
}

