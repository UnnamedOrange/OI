#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int maxn = int(1e6), maxm = int(1e6);

struct edge
{
	int adj, nxt;

	edge() { }
	edge(int _adj, int _nxt): adj(_adj), nxt(_nxt) { }
}e[maxm + 5];

int st[maxn + 5], _cnt;

inline void add_edge(int u, int v)
{
	e[_cnt] = edge(v, st[u]), st[u] = _cnt++;
}

int n, m;

inline void input()
{
	n = read<int>(), m = read<int>();

	memset(st, -1, sizeof st), _cnt = 0;
	while(m--)
	{
		int u = read<int>() - 1, v = read<int>() - 1;
		add_edge(u, v);
	}
}

bool vis[maxn + 5];
int dfn[maxn + 5], low[maxn + 5], dfs_cur;

stack<int> S;
int scc[maxn + 5], val[maxn + 5], scc_cnt;

vector<int> adj[maxn + 5];

inline void dfs(int u)
{
	S.push(u), vis[u] = 1;
	dfn[u] = low[u] = dfs_cur++;

	for(int i = st[u]; ~i; i = e[i].nxt)
	{
		int v = e[i].adj;
		if(!vis[v])
		{
			dfs(v);
			chkmin(low[u], low[v]);
		}
		else if(!~scc[v]) chkmin(low[u], dfn[v]);
	}

	if(dfn[u] == low[u])
	{
		while(!S.empty())
		{
			int k = S.top();
			S.pop();

			scc[k] = scc_cnt, ++val[scc_cnt];
			if(k == u) break;
		}
		++scc_cnt;
	}
}

inline void find_scc()
{
	memset(scc, -1, sizeof scc), scc_cnt = 0;
	while(!S.empty()) S.pop();
	memset(vis, 0, sizeof vis);
	memset(val, 0, sizeof val);
	dfs_cur = 0;
	REP(i, 0, n) if(!vis[i]) dfs(i);
}

inline void build_DAG()
{
	REP(u, 0, n)
		for(int i = st[u]; ~i; i = e[i].nxt)
		{
			int v = e[i].adj;
			if(scc[u] != scc[v]) adj[scc[u]].push_back(scc[v]);
		}
}

int f[maxn + 5];

inline int dfs_dp(int u)
{
	if(~f[u]) return f[u];

	f[u] = 0;
	REP(i, 0, SZ(adj[u]))
	{
		int v = adj[u][i];
		chkmax(f[u], dfs_dp(v));
	}

	return f[u] = f[u] + val[u];
}

inline void DP()
{
	memset(f, -1, sizeof f);
	REP(i, 0, scc_cnt) dfs_dp(i);
}

inline void solve()
{
	find_scc();
	build_DAG();

	DP();

	int ans = 0;
	REP(i, 0, scc_cnt) chkmax(ans, f[i]);
	printf("%d\n", ans);
}

int main()
{
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);

	input();
	solve();

	return 0;
}

