#include<bits/stdc++.h>
#define FE "permutation"
using namespace std;
inline long long getint(){
	long long x=0,p=1;
	char c=getchar();
	while(!isdigit(c))(c=='-'?p=-1:0),c=getchar();
	while(isdigit(c))x=(x<<3)+(x<<1)+(c^'0'),c=getchar();
	return x*p;
}
inline void putint(long long x){
	static long long buf[20];
	long long tot=0;
	x<0?putchar('-'),x=-x:0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
long long n;
long long a[100005],b[100005];
bool visit[100005];
const long long MOD =  998244353;
inline long long ksm(long long a,long long b,long long c){
	long long ans=1;
	while(b){
		if(b&1)ans=ans*a%c;
		b>>=1;
		a=a*a%c;
	}
	return ans;
}
inline void dfs(int cur,int &len,bool &is_ring){
	visit[cur]=1;
	if(a[cur]==0){
		is_ring=0;
		return;
	}
	int v=a[cur];
	if(visit[v]){
		is_ring=1;
		return;
	}
	dfs(v,len=len+1,is_ring);
}
long long fac[1000005],invfac[1000005];
inline long long inv(long long x){
	x%=MOD;
	return ksm(x,MOD-2,MOD);
}
inline void pre(){
	fac[0]=1;
	for(int i=1;i<=n;++i){
		fac[i]=fac[i-1]*i%MOD;
	}
	invfac[n]=inv(fac[n]);
	for(int i=n-1;i>=0;--i){
		invfac[i]=invfac[i+1]*(i+1)%MOD;
	}
//	for(int i=1;i<=10;++i){
//		cout<<i<<" "<<fac[i]<<" "<<invfac[i]<<endl;
//	}
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	n=getint();
	pre();
	for(int i=1;i<=n;++i){
		a[i]=getint();
		if(a[i])b[a[i]]=i;
	}
	if(n%2==1){
		cout<<0<<endl;
		return 0;
	}
	int totodd=0,toteven=0;
	for(int i=1;i<=n;++i){
		if(b[i]==0){
			int len=1;
			bool r=0;
			dfs(i,len,r);
			if(len&1){
				++totodd;
			}
			else ++toteven;
		}
	}
	for(int i=1;i<=n;++i){
		if(!visit[i]){
			int len=1;
			bool r=0;
			dfs(i,len,r);
			if(len&1){
				cout<<0<<endl;
				return 0;
			}
		}
	}
	long long ans=1;
	for(int i=2;i<=totodd;i+=2){
		ans=ans*(i-1)%MOD;
	}
	ans=ans*ans%MOD;
	long long tot=ans,cxi=1,cyi=1;
	ans=0;
	long long x=totodd,y=toteven;
	//cout<<x<<" "<<y<<endl;
	if(x==0){
		cout<<fac[y]<<endl;
		return 0;
	}
	for(int i=0;i<=toteven;++i){
		ans+=fac[y]*fac[x+i-1]%MOD*invfac[i]%MOD*invfac[x-1]%MOD*tot%MOD;
		ans%=MOD;
	}
	cout<<ans%MOD<<endl;
	return 0;
}
