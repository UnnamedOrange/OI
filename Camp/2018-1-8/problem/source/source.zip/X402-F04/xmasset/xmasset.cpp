//2018-1-8
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

int Pow1(int a, int b){
	int ret = 1;
	For(i, 1, b) ret = ret * a % 19;
	return ret;
}

int Pow2(int a, int b){
	int ret = 1;
	For(i, 1, b) ret = ret * a % 11;
	return ret;
}

int main(){
	int type;
	scanf("%d", &type);

	int n, T;
	scanf("%d%d", &n, &T);

	int x, y;
	while(T--){
		scanf("%d%d", &x, &y);
		
		if(type == 1) printf("%d\n", x);
		else{
			if(x == y) puts("yes"); else puts("no");
		}
	}

	return 0;
}
