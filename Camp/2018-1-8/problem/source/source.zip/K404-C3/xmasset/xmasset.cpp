#include<cmath>
#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iomanip>
#include<iostream>
#include<algorithm>
using namespace std;
inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int T;
int encode(int x,int y)
{
	for(int i=0;i<=9;i++)
	{
		bool p1=(x>>i)&1,p2=(y>>i)&1;
		if(p1!=p2)
		{
			if(p1)return i+1;
			else return 10+i+1;
		}
	}
}
bool decode(int q, int h)
{
    if(h<=10)
    {
    	h--;
    	if((q>>h)&1)return 1;
    	else return 0;
    }
    else
    {
    	h-=11;
    	if((q>>h)&1)return 0;
    	else return 1;
    }
}
int main()
{
	int type=read();
	read();T=read();
	while(T--)
	{
		int x=read(),y=read();
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
	}
}