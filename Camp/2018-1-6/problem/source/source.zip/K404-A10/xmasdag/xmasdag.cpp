#include <bits/stdc++.h>

typedef long long int int64;
static const int64 mod = 998244353LL;
int n,m,k;
int64 f[503][503];
int64 x[503];
int64 g[100003][503];
struct edge {
	int to;
	int enext;
} e[200003];int en;
struct vertex {
	int estart,deg;
	int64 ans;
} v[100003];
int q[100003],qstart,qend;
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	f[0][0] = 1;
	for(int i = 0;i < n;++i) {
		v[i].estart = -1;
		v[i].deg = 0;
	}
	for(int i = 0;i <= k;++i) {
		for(int j = 0;j <= i;++j) {
			f[i+1][j] = (f[i+1][j] - f[i][j]) % mod;
			f[i+1][j+1] = (f[i+1][j+1] + f[i][j]) % mod;
		}
	}
	for(int i = 0;i <= k;++i) {
		int64 v = 1;
		for(int j = 0;j < k;++j) v = (v * i) % mod;
		x[i] = v;
	}
	for(int i = 0;i < m;++i) {
		int a,b;
		scanf("%d%d",&a,&b);--a,--b;
		e[en].to = b;e[en].enext = v[a].estart;v[a].estart = en++;++v[b].deg;
	}
	qstart = 0,qend = 1,q[0] = 0;g[0][0] = 1;
	while(qstart != qend) {
		int cur = q[qstart++];
		if(g[cur][k+1] != 0) for(int j = 0;j <= k;++j) {
			g[cur][j] = (g[cur][j] - g[cur][k+1] * f[k+1][j]) % mod;
		}
		for(int j = v[cur].estart;j != -1;j = e[j].enext) {
			int to = e[j].to;
			--v[to].deg;if(v[to].deg == 0) q[qend++] = to;
			for(int i = 0;i <= k;++i) g[to][i+1] = (g[to][i+1] + g[cur][i]) % mod;
		}
		int64 ans = 0;
		for(int j = 0;j <= k;++j) ans = (ans + x[j] * g[cur][j]) % mod;
		v[cur].ans = ans;
	}
	for(int i = 0;i < n;++i) {
		printf("%lld\n",(v[i].ans < 0 ? v[i].ans + mod : v[i].ans));
	}
}
