#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=1000005,maxm=100005,lim=25;
int n,a[maxn],b[maxn];
int pl[100],pr[100];
int rt[maxn],tot;
int idx[maxn],m;
struct node{int lc,rc,sum;};
struct seg_tree{
	node tr[maxm*40];
	void update(int &p,int lst,int l,int r,int pos){
		tr[p=++tot]=tr[lst];
		tr[p].sum++;
		if(l==r)return;
		int mid=(l+r)>>1,u=p<<1,v=u+1;
		if(pos<=mid)update(tr[p].lc,tr[lst].lc,l,mid,pos);
		else update(tr[p].rc,tr[lst].rc,mid+1,r,pos);
	}
	int query(int p,int l,int r,int L,int R){
		if(!p)return 0;
		if((L<=l)&&(R>=r))return tr[p].sum;
		int mid=(l+r)>>1,res=0;
		if(L<=mid)res+=query(tr[p].lc,l,mid,L,R);
		if(R>mid)res+=query(tr[p].rc,mid+1,r,L,R);
		return res;
	}
}T;
int main(){
#ifndef ONLINE_JUDGE
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
#endif
	n=read();
	REP(i,1,n)a[i]=read(),idx[++m]=a[i];
	sort(idx+1,idx+1+m);
	m=unique(idx+1,idx+1+m)-idx-1;
	REP(i,1,n)b[i]=lower_bound(idx+1,idx+1+m,a[i])-idx,T.update(rt[i],rt[i-1],1,m,b[i]);
	lf ans=0;
	REP(i,1,n){
		int tmp=T.query(rt[i],1,m,b[i]+1,m);
		pl[0]=i,pl[lim+1]=0;
		REP(j,1,lim+1){
			int l=1,h=pl[j-1]-1;
			while(l<=h){
				int mid=(l+h)>>1;
				if(tmp-T.query(rt[mid-1],1,m,b[i]+1,m)>=j)l=mid+1;
				else h=mid-1;
			}pl[j]=h;
			if(pl[j]<1)break;
		}
		tmp=T.query(rt[i],1,m,b[i],m);
		pr[0]=i,pr[lim+1]=n+1;
		REP(j,1,lim+1){
			int l=pr[j-1]+1,h=n;
			while(l<=h){
				int mid=(l+h)>>1;
				if(T.query(rt[mid],1,m,b[i],m)-tmp>=j)h=mid-1;
				else l=mid+1;
			}pr[j]=l;
			if(pr[j]>n)break;
		}
		REP(j,0,lim){
			if(pl[j]==0)break;
			REP(k,0,lim-j){
				if(pr[k]==n+1)break;
				ans+=1ll*a[i]*(pl[j]-pl[j+1])*(pr[k+1]-pr[k])/pow(2.0,j+k+1);
			}
		}
	}
	printf("%.10lf\n",ans/n/n);
	return 0;
}
