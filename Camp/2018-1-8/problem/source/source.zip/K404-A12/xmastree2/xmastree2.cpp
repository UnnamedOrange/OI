#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define N 30005
using namespace std;
typedef long long ll;
struct edge{
	int k,next;
}e[N<<1];
ll f[N],sum[N];
int n,home[N],cnt=-1,siz[N],w[N],root[20],tot,s[N],top;
void add(int x,int y){
	cnt++;
	e[cnt].k=y;
	e[cnt].next=home[x];
	home[x]=cnt;
}
bool cmp(int a,int b){
	return sum[b]*siz[a]>sum[a]*siz[b];
}
void dfs(int k,int F){
	siz[k]=1;sum[k]=w[k];f[k]=0;
	for(int i=home[k];~i;i=e[i].next){
		if(e[i].k!=F){
			dfs(e[i].k,k);
			siz[k]+=siz[e[i].k];
			sum[k]+=sum[e[i].k];
			f[k]+=f[e[i].k];
		}
	}
	f[k]+=sum[k];
	top=0;
	for(int i=home[k];~i;i=e[i].next){
		if(e[i].k!=F){
			s[++top]=e[i].k;
		}
	}
	sort(s+1,s+top+1,cmp);
	ll S=0;
	for(int i=top;i;i--){
		f[k]+=S*siz[s[i]];
		S+=sum[s[i]];
	}
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	memset(home,-1,sizeof(home));
	scanf("%d",&n);
	for(int i=1,x,y;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	for(int i=1,op;i<=n;i++){
		scanf("%d%d",&w[i],&op);
		if(op) root[++tot]=i;
	}
	ll ans=0;
	for(int i=1;i<=tot;i++) dfs(root[i],0),ans=max(ans,f[root[i]]);
	printf("%lld",ans);
	return 0;
}
