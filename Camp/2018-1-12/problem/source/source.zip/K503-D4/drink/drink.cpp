#include<bits/stdc++.h>
#define maxn 100000
using namespace std;
int a[maxn], tmp[maxn];
long long mi[100];
double ans;
int main()
{
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	mi[0] = 1;
	for (int i = 1; i <= 60; i++)
		mi[i] = mi[i - 1] * 2;
	for (int i = 1; i <= n; i++)
	{
		int tot = 0;
		for (int j = i; j <= n; j++)
		{
			int pre = tot;
			for (int k = 1; k <= tot; k++)
				if (tmp[k] < a[j]) {pre = k - 1; break;}
			for (int k = tot; k >= pre + 1; k--)
				tmp[k + 1] = tmp[k];
			tot++;
			tmp[pre + 1] = a[j];
			if (tot > 60) tot = 60;
			for (int k = 1; k <= tot; k++)
				ans = ans + (double)tmp[k] / mi[k] / n / n;
		}
	}
	printf("%.4lf\n", ans);
	return 0;
}
