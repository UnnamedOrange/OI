#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <sstream>
#include <cctype>
#include <cmath>
#include <algorithm>
#define THE_BRST_PONY "Rainbow Dash"

using namespace std;
const int N=4040,INF=~0u>>2;

int n,m,k;
int a[N],b[N];
int da[N][N],db[N][N],dp[N][N];

int main() {
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d",&b[i]);
	for(int i=1;i<=k;i++) da[n][i]=-1;
	for(int i=n-1;i>=0;i--) {
		for(int j=1;j<=k;j++) {
			if(a[i+1]==j) da[i][j]=i+1;
			else da[i][j]=da[i+1][j];
		}
	}
	for(int i=1;i<=k;i++) db[m][i]=-1;
	for(int i=m-1;i>=0;i--) {
		for(int j=1;j<=k;j++) {
			if(b[i+1]==j) db[i][j]=i+1;
			else db[i][j]=db[i+1][j];
		}
	}
	for(int i=n;i>=0;i--) {
		for(int j=m;j>=0;j--) {
			dp[i][j]=INF;
			for(int c=1;c<=k;c++) {
				if(da[i][c]==-1&&db[j][c]==-1)
					dp[i][j]=min(dp[i][j],1);
				else if(da[i][c]==-1)
					dp[i][j]=min(dp[i][j],dp[i][db[j][c]]+1);
				else if(db[j][c]==-1)
					dp[i][j]=min(dp[i][j],dp[da[i][c]][j]+1);
				else dp[i][j]=min(dp[i][j],dp[da[i][c]][db[j][c]]+1);
			}
		}
	}
	printf("%d",dp[0][0]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

