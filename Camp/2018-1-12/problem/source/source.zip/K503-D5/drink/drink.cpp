#include <cstdio>
#include <cstring>
#include <algorithm>
#define db double
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=1e5+5;
int n,i,j,k,l,t,od,a[N],id[N],b[N],cnt[N];
db tmp,ans,exp[N],sum[N*4],lazy[N*4],S;
void read(int &ret)
{
	char ch; ret=0;
	for (ch=getchar();ch<'0' || ch>'9';ch=getchar());
	for (;ch>='0' && ch<='9';ch=getchar()) ret=ret*10+ch-'0';
}
void Init()
{
	read(n);
	exp[1]=0.5; rep(i,2,n) exp[i]=exp[i-1]*0.5;
	rep(i,1,n) read(a[i]),b[i]=a[i];
	sort(b+1,b+1+n);
	l=unique(b+1,b+1+n)-b-1;
	rep(i,1,n) id[i]=lower_bound(b+1,b+1+l,a[i])-b;	
}
int lowbit(int x) { return x&(-x); }
int query1(int x) {
	int ret=0; while (x>0) {ret+=cnt[x]; x-=lowbit(x);}
	return ret;
}
void change1(int x) {
	while (x<=n) {cnt[x]++; x+=lowbit(x);}
}
void pushdown(int x)
{
	int lft=x<<1,rgt=(x<<1)+1;
	sum[lft]*=lazy[x]; sum[rgt]*=lazy[x];
	if (!lazy[lft]) lazy[lft]=1;
	if (!lazy[rgt]) lazy[rgt]=1;
	lazy[lft]*=lazy[x]; lazy[rgt]*=lazy[x]; lazy[x]=1;
}
void visit(int l,int r,int L,int R,int x)
{
	if (!lazy[x]) lazy[x]=1;
	if (l>R || r<L) return;
	if (L<=l && r<=R) {
		if (od==1) sum[x]+=a[j]*exp[t];
		if (od==2) sum[x]*=0.5,lazy[x]*=0.5;
		if (od==3) tmp+=sum[x];
		return;
	}
	int mid=(l+r)>>1,lft=x<<1,rgt=(x<<1)+1;
	pushdown(x);
	visit(l,mid,L,R,lft);
	visit(mid+1,r,L,R,rgt);
	sum[x]=sum[lft]+sum[rgt];
}
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	Init();
	
	rep(i,1,n)
	{
	   rep(j,1,n) cnt[j]=0;
	   rep(j,1,n*4) sum[j]=lazy[j]=0;
	   S=0;
	   rep(j,i,n)
	   {
	   	  tmp=0;
	   	  od=3; visit(1,n,1,id[j],1); S-=tmp; S+=tmp*0.5;
	   	  t=j-i+1-query1(id[j]); S+=a[j]*exp[t];
	   //	  printf("%.4lf ",S);
	   	  ans+=S; change1(id[j]);
		  od=2; visit(1,n,1,id[j],1);
		  od=1; visit(1,n,id[j],id[j],1);
	   }
    }
	ans/=n; ans/=n;
	printf("%.13lf\n",ans);
	return 0;
}
