#include <cstdio>
#include <queue>

const int MAXN = 1000000 + 10;
const int MAXM = 1000000 + 10;
int N, M;
int cnt = 0, head[MAXN], next[MAXM], to[MAXM];
int new_cnt = 0, new_head[MAXN], new_next[MAXM], new_to[MAXM], degree[MAXN];
int dfn[MAXN], low[MAXN], block[MAXN], num[MAXN], stack[MAXN], tot, sum, top;
int dist[MAXN];
bool instack[MAXN];
bool visited[MAXN];
int ans;

inline int min( int x, int y ) {
	return x < y ? x : y;
}

inline int max( int x, int y ) {
	return x < y ? y : x;
}

inline void insert( int x, int y ) {
	next[++cnt] = head[x]; to[cnt] = y, head[x] = cnt;
}

inline void add( int x, int y ) {
	new_next[++new_cnt] = new_head[x]; new_to[new_cnt] = y, new_head[x] = new_cnt;
	++degree[y];
}

inline void Tarjan( int x ) {
	register int i;
	dfn[x] = low[x] = ++tot;
	stack[++top] = x;
	instack[x] = 1;
	for( i = head[x]; i; i = next[i] )
		if( !dfn[to[i]] )
			Tarjan( to[i] ),
			low[x] = min( low[x], low[to[i]] );
		else
			if( instack[to[i]] )
				low[x] = min( low[x], dfn[to[i]] );
	if( dfn[x] == low[x] ) {
		int v;
		num[block[x] = ++sum] = 1; instack[x] = 0;
		while( ( v = stack[top--] ) != x && v )
			block[v] = sum, ++num[sum], instack[v] = 0;
	}
}

inline void shrinkle() {
	register int i, j;
	for( i = 1; i <= N; ++i )
		for( j = head[i]; j; j = next[j] )
			if( block[i] != block[to[j]] )
				add( block[i], block[to[j]] );
}

inline void SPFA() {
	register int i, now;
	std::queue<int> q;
	for( i = 1; i <= sum; ++i )
		if( !degree[i] )
			q.push( i ), dist[i] = num[i], visited[i] = 1;
	while( !q.empty() ) {
		now = q.front(); q.pop();
		for( i = new_head[now]; i; i = new_next[i] ) {
			if( dist[now] + num[new_to[i]] > dist[new_to[i]] ) {
				dist[new_to[i]] = dist[now] + num[new_to[i]];
				if( !visited[new_to[i]] )
					visited[new_to[i]] = 1, q.push( new_to[i] );
			}
		}
		visited[now] = 0;
	}
	for( i = 1; i <= sum; ++i )
		ans = max( ans, dist[i] );
}

int main() {
	freopen( "bomb.in", "r", stdin );
	freopen( "bomb.out", "w", stdout );
	register int i;
	int x, y;
	scanf( "%d%d", &N, &M );
	for( i = 1; i <= M; ++i )
		scanf( "%d%d", &x, &y ),
		insert( x, y );
	if( M == 0 )
		return 0 * puts( "1" );
	for( i = 1; i <= N; ++i )
		if( !dfn[i] )
			Tarjan( i );
	shrinkle();
	SPFA();
	printf( "%d\n", ans );
	return 0;
}
