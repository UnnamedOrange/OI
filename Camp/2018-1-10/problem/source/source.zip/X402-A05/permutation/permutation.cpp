#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl
#define fst first
#define snd second

typedef long long LL;
typedef std::pair<int, int> Pii;

#ifdef __linux__
#define getchar getchar_unlocked
#endif
template <typename T> inline bool maximum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T> inline bool minimum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T>
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 1e5 + 10, mod = 998244353;

int n, p[N];

bool vis[N];
int ans;

void dfs_permutation(int dep)
{
	if(dep == n + 1){
		bool inq[20] = {0}, flag = 1;
		for(int i = 1; i <= n; ++i){
			if(inq[i]) continue;
			else inq[i] = 1;

			int cnt = 1;
			for(int u = p[i]; !inq[u]; u = p[u]){
				inq[u] = 1; 
				++cnt;
			}

			if(cnt & 1){
				flag = false; 
				break;
			}
		}
		ans += flag;
		return ;
	}

	if(p[dep]){
		dfs_permutation(dep + 1);
		return ;
	}

	for(int i = 1; i <= n; ++i){
		if(vis[i]) continue;
		vis[i] = 1; p[dep] = i;
		dfs_permutation(dep + 1);
		vis[i] = 0; p[dep] = 0;
	}
}

namespace h10_666
{
	int ans[N];

	void main()
	{
		ans[2] = 1;
		for(int i = 4; i <= n; i += 2){
			int d1 = !p[i-1]? i - 1 : 1;
			int d2 = !p[i]? i - 1 : 1;
			ans[i] = 1LL * ans[i-2] * d1 % mod * d2 % mod;
		}
		printf("%d\n", ans[n]);
	}
}

int main()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);

	read(n);
	for(int i = 1; i <= n; ++i){
		read(p[i]);
		vis[p[i]] = 1;
	}

	if(n == 8){
		dfs_permutation(1);
		printf("%d\n", ans);
	}
	else
		h10_666::main();

	return 0;
}
