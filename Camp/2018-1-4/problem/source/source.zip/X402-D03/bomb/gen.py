import sys
from random import *

sys.stdout = open("bomb.in", "w")

n = 1000000
m = 1000000

print(n, m)

for i in range(m):
	u = randint(1, n-1)
	v = randint(u+1, n)
	if randint(0,1) : 
		u, v = v, u
	print(u, v)
