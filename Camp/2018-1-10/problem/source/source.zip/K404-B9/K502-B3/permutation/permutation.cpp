#include <stdio.h>
#include <string.h>
using namespace std;

#define ll long long int

const int mod=998244353;
ll a[100001],p[9][9],vis[9],hash[9];
ll n,ans=0,sum;
 
inline ll read()
{
    char ch;
    bool flag=false;
    ll r=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        r*=10;
        r+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        r*=10;
        r+=ch-'0';
    }
    if(flag)
	{
        r=-r;
    }
    return r; 
}

void find(ll x)
{
	hash[x]=1;
	sum++;
	ll i;
	for(i=1;i<=n;i++)
	{
		if(p[x][i]&&!hash[i])
		{
			find(i);
		}
	}
}

bool check()
{
	memset(hash,0,sizeof(hash));
	ll i;
	for(i=1;i<=n;i++)
	{
		if(!hash[i])
		{
			sum=0;
			find(i);
			if(sum%2==1)
				return 0;
		}
	}
	return 1;
}

void dfs(ll x)
{
	if(x==n+1)
	{
		if(check())
			ans=(ans+1)%mod;
		return;
	}
	if(a[x]!=0)
	{
		p[x][a[x]]=1;
		vis[a[x]]=1;
		dfs(x+1);
		return;
	}
	ll i;
	for(i=1;i<=n;i++)
	{
		if(!vis[i])
		{
			p[x][i]=1;
			vis[i]=1;
			dfs(x+1);
			p[x][i]=0;
			vis[i]=0;
		}
	}
}

ll cou()
{
	ll i,temp=1;
	for(i=1;i<=n-1;i+=2)
		temp=((temp*i)%mod*i)%mod;
	return temp%mod;
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=read();
	ll i,flag=0;
	for(i=1;i<=n;i++)
	{
		a[i]=read();
		if(a[i]!=0)
			flag++;
	}
	if(n%2==1)
	{
		printf("0");
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	if(n<=8)
	{
		dfs(1); 
		printf("%lld",ans%mod);
	}
	else
	{
		if(!flag)
			printf("%lld",cou()%mod);
		else
			printf("0"); 
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
