#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const int mod=1e9+7;
ll n,m,t,s,dp[105][105];
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	std::cin>>s>>t>>n>>m;
	dp[0][0]=1;
	for(int i=1;i<=m;i++)
		if(i<=n)
		{
			for(int v=1;v<=s;v++)
				for(int k=1;k<=t;k++)
					if(k<=v)
						(dp[i][v]+=dp[i-1][v-k])%=mod;
					else
						break;
		}
		else
		{
			for(int v=1;v<=s;v++)
				for(int k=1;k<=v;k++)
					(dp[i][v]+=dp[i-1][v-k])%=mod;
		}
	ll ans=0;
	for(int i=m;i<=s;i++)
		(ans+=dp[m][i])%=mod;
	std::cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
