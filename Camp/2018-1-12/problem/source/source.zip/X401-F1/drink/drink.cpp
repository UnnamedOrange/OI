#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
#define lc (o<<1)
#define rc (o<<1|1)
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1e6+10,MAX=1e5+10;
int n,w[MAXN],tot;
db ans;
namespace case1
{
	int t[MAXN];
	void solve()
	{

		for(int l=1;l<=n;++l)
		{
			int tot=0;
			for(int r=l;r<=n;++r)
			{
				t[++tot]=w[r];
				sort(t+1,t+tot+1);
				int cnt=0;
				db tmp=0;
				for(int k=tot;k;--k)
					tmp+=(db)1/(1<<(++cnt))*t[k];
				ans+=tmp;
			}
		}
		printf("%.6lf\n",ans/((db)n*n));
		exit(0);
		return;
	}
}
namespace case2
{
	struct Seg_T
	{
		db sumv[MAX*3],divv[MAX*3];
		void push_up(int o)
		{
			sumv[o]=sumv[lc]+sumv[rc];
			return;
		}
		void push_down(int o)
		{
			if(divv[o])
			{
				sumv[lc]/=divv[o];
				sumv[rc]/=divv[o];
				divv[lc]+=divv[o];
				divv[rc]+=divv[o];
				divv[o]=0;
			}
			return;
		}
		void update(int o,int l,int r,int yl,int yr,int k)
		{
			if(r>l)return;
			if(yl<=l&&r<=yr)
			{
				if(!k)
				{
					divv[o]+=2;
					sumv[o]/=2.0;
				}
				else
					sumv[o]+=k;
				return;
			}
			int mid=(l+r)>>1;
			push_down(o);
			if(yl<=mid)update(lc,l,mid,yl,yr,k);
			if(yr>mid)update(rc,mid+1,r,yl,yr,k);
			push_up(o);
			return;
		}
		db query(int o,int l,int r,int yl,int yr)
		{
			if(r>l)return 0;
			if(yl<=l&&r<=yr)return sumv[o];
			int mid=(l+r)>>1;
			db ret=0;
			push_down(o);
			if(yl<=mid)ret=query(lc,l,mid,yl,yr);
			if(yr>mid)ret+=query(rc,mid+1,r,yl,yr);
			return ret;
		}
	}T1,T2;
	void solve()
	{
		for(int i=1;i<=n;++i)
		{
			T1.update(1,1,tot,1,w[i]-1,0);
			T2.update(1,1,tot,1,w[i]-1,0);
			db xi=T2.query(1,1,tot,w[i],tot)/2;
			ans+=(T1.sumv[1]+(xi+0.5)*w[i])/((db)n*n);
			T1.update(1,1,tot,w[i],w[i],(xi+0.5)*w[i]);
			T2.update(1,1,tot,w[i],w[i],xi+0.5);
		}
		printf("%.6lf\n",ans);
		exit(0);
		return;
	}
}
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)w[i]=read(),tot=max(tot,w[i]);
	if(n<=100)case1::solve();
	case2::solve();
	return 0;
}
