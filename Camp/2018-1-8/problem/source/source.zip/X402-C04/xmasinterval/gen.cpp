#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=5000;
const int M=6;

int n,m;
int a[N];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("xmasinterval.in","w",stdout);

	n=5,m=5;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;i++)
	{
		int l=rand()%M+1,r=rand()%M+1;
		if(l>r)swap(l,r);
		printf("%d %d\n",l,r);
	}

	for(int i=1;i<=m;i++)
		printf("%d\n",rand()%M+1);
	return 0;
}

