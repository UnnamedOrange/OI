#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;
#define memS(a) memset(a, 0, sizeof a)

int main()
{
    St int t;
    for(scanf("%d", &t); t--;)
    {
        scanf("%d%d%d%d", &n, &w, &p, &q);
        inc(1, i, n+1)
            B[i]=1;
        inc(0, i, p)
        {
            St int x, y, z, a, b, c, d, e, f;
            scanf("%d%d%d%d%d%d%d%d%d", &x, &y, &z, &a, &b, &c, &d, &e, &f);
            A[x][y]=A[y][x]+=a, A[y][z]=A[z][y]+=b, A[z][x]=A[x][z]+=c;
            B[x]+=d-f, B[y]+=e-d, B[z]+=f-e;
        }
        //memset
        S=n+1, T=n+2
        inc(1, i, n+1)
            if(B[i]<0)
                sum-=B[i]*W, aE(S, i, 0), aE(i, T, -2*B[i]*W);
            else
                sum+=B[i]*W, aE(S, i, 2*B[i]*W), aE(i, T, 0);
        inc(1, i, n)
            inc(i+1, j, n+1)
                if(A[i][j]>0)
                    sum+=2*A[i][j]*W, aE(i, j, )
    }
    Re 0;
}
