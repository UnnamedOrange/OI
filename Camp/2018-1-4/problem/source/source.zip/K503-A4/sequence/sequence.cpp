//Astar 20-36pts
#include <bits/stdc++.h>
#define mswap(x,y) {x^=y;y^=x;x^=y; }
#define rint register int
using namespace std;
typedef unsigned long long ULL;
const int MAXN = 8, INF = 0x3f3f3f3f, MOD = 131071;
int T, N, Ans;
struct State {
	int val; char A[MAXN+1];
	ULL h;
	inline void getHash() {
		h = 0;
		for(rint i=1; i<=N; i++) h = h * 13131 + A[i];
		h %= MOD;
	}
	inline void getVal() {
		val = 0;
		for(rint i=1; i<=N; i++)
			val += abs(i - A[i]);
	}
	inline State operator=(const State& rhs) {
		//memcpy(A, rhs.A, sizeof(A));
		A[1] = rhs.A[1]; A[2] = rhs.A[2];A[3] = rhs.A[3];A[4] = rhs.A[4];
		A[5] = rhs.A[5];A[6] = rhs.A[6];
		A[7] = rhs.A[7];A[8] = rhs.A[8];/*
		A[9] = rhs.A[9];A[10] = rhs.A[10];
		A[11] = rhs.A[11];A[12] = rhs.A[12];
		A[13] = rhs.A[13];A[14] = rhs.A[14];
		A[15] = rhs.A[15];A[16] = rhs.A[16];
		A[17] = rhs.A[17];A[18] = rhs.A[18];
		A[19] = rhs.A[19];A[20] = rhs.A[20];
		A[21] = rhs.A[21];A[22] = rhs.A[22];
		A[23] = rhs.A[23];A[24] = rhs.A[24];
		A[25] = rhs.A[25];*/
		val=rhs.val; h=rhs.h;
		return *this;
	}
	inline bool operator<(const State& rhs) const {
		return val < rhs.val;
	}
	inline bool operator>(const State& rhs) const {
		return val > rhs.val;
	}
};
State st, ed;
inline int readint() {
	int f=1,r=0;
	char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	return f*r;
}

inline void flip(char *A, int L, int R) {
	for(rint i=L; i < L + ((R-L+1)>>1); i++)
		mswap( A[i], A[R+L-i] );
}

inline void Dbg(const char* str, State& u) {
	printf("%s: h=%llu val=%d\n[", str, u.h, u.val);
	for(rint i=1; i<=N; i++) printf("%d%c ", u.A[i], ",]"[i==N]);
	putchar(10);
	for(rint i=1; i<=2*N; i++) putchar('-');
	putchar(10);
}

void AStar() {
	static int dist[MOD+10];
	memset(dist, 0x3f, sizeof(dist));
	priority_queue<State, vector<State>, greater<State> > pq;
	st.getVal(); st.getHash();
	ed.getVal(); ed.getHash();
	pq.push(st); dist[st.h] = 0;
	State u, v;
	while(!pq.empty()) {
		u = pq.top(); pq.pop();
		if(u.h != ed.h)
		for(rint i=N; i>1; i--) {
			v = u; flip(v.A, 1, i);
			v.getVal(); v.getHash();
			//Dbg("u", u); Dbg("v", v);
			if(dist[v.h] > dist[u.h] + 1) {
				dist[v.h] = dist[u.h] + 1;
				pq.push(v);
			}
			//printf("%d %d\n\n\n", dist[u.h], dist[v.h]);
		}
	}
	printf("%d\n", dist[ed.h]);
}

int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	T = readint();
	while(T--) {
		N = readint();
		for(int i=1; i<=N; i++) st.A[i] = readint();
		for(int i=1; i<=N; i++) ed.A[i] = i;
		AStar();
	}
	return 0;
}
