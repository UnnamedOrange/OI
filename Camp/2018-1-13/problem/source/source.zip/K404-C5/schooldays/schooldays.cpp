#include<bits/stdc++.h>
using namespace std;
const int R_LEN=(1<<18)|1;
char ibuf[R_LEN],*sbuf=ibuf,*tbuf=ibuf;
inline char getc(){
	(sbuf==tbuf) && (tbuf=(sbuf=ibuf)+fread(ibuf,1,R_LEN,stdin));
	return (sbuf==tbuf)?-1:*sbuf++;
}
inline int rd(){
	char ch=getc(); int i=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1; ch=getc();}
	while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0'; ch=getc();}
	return i*f;	
}
const int N=1e6+50,INF=0x3f3f3f3f,Mod=1000000007;
int n,a[N],b[N],l[N],r[N],f[N],s[N];
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=rd(); 
	for(int i=1;i<=n;i++) {
		a[i]=rd(); b[i]=rd();
		l[i]=i-b[i]+1; r[i]=i-a[i]+1;
	} memset(f,0xc0,sizeof(f));
	f[0]=0; s[0]=1;
	for(int i=1;i<=n;i++){
		int mxl=-INF,mnr=INF,mx=-INF,rs=0;
		for(int j=i;j>=1;j--){
			mxl=max(mxl,l[j]+i-j);
			mnr=min(mnr,r[j]+i-j);
			if(mxl<=j&&j<=mnr&&mx<=f[j-1])
				rs=(mx==f[j-1])?((rs+s[j-1])%Mod):(mx=f[j-1],s[j-1]);
			if(mxl>mnr)break;
		}
		f[i]=mx+1; s[i]=rs;
	}
	(f[n]<0)?(puts("-1"),0):printf("%d %d\n",f[n],s[n]);
}
