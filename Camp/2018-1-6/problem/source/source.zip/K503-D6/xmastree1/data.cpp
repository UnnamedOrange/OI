#include <cctype>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <process.h>
#include <algorithm>
#include <functional>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)
#define repd(i,x,y) for (int i=x; i>=(y); --i)

using namespace std;

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

int main()
{
    freopen("xmastree1.in","w",stdout);
    srand(_getpid()^(unsigned long long)new char);
    int n=5,m=3,type=0;
    printf("%d %d %d\n",n,m,type);
    rep(i,1,n)
    	printf("%d ",rand(1,n));
    puts("");
    rep(i,2,n)
    	printf("%d %d\n",rand(1,i-1),i);
    rep(i,1,m)
    	if (rand(2))
    	{
    		int l=rand(1,n),r=rand(1,n);
    		if (l>r)
    			swap(l,r);
    		printf("1 %d %d %d\n",rand(1,n),l,r);
    	}
    	else
    		printf("2 %d %d\n",rand(1,n),rand(1,n));
    return 0;
}
