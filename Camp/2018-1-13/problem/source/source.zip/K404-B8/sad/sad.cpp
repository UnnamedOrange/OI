#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl
using namespace std;
const int maxn = 100009;
const int mod = 998244353;

int first[maxn],col[maxn],du[maxn];
int f[maxn],g[maxn];
struct edg{int next,to;}e[maxn<<1];
int n,e_sum,type1,type2;
char str[maxn];

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void add_edg(int x,int y)
{
	e_sum++;
	e[e_sum].next=first[x];
	first[x]=e_sum;
	e[e_sum].to=y;
}

int PowerMod(int x,int y)
{
	int res=1;
	while(y)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;y>>=1;
	}return res;
}
int inv(int x)
{
	if(x<0) x+=mod;
	return PowerMod(x,mod-2);
}

void dfs(int x,int fa)
{
	if(du[x]==1&&x!=1)
	{
		f[x]=1;
		g[x]=0;
		return ;
	}
	for(int i=first[x];i;i=e[i].next)
	{
		int w=e[i].to;
		if(w==fa) continue;
		dfs(w,x);
		f[x]=(f[x]+f[w])%mod;
		g[x]=(g[x]+g[w])%mod;
	}
	f[x]=(1ll*f[x]*inv(du[x])+1)%mod;
	g[x]=1ll*g[x]*inv(du[x])%mod;
	f[x]=1ll*f[x]*inv(1-g[x])%mod;
	g[x]=1ll*inv(du[x])*inv(1-g[x])%mod;
}

void work1() // all black
{
	dfs(1,0);
	cout<<f[1]<<endl;
}

int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	n=read();
	scanf("%s",str+1);
	for(int i=1;i<=n;i++) col[i]=str[i]-'0'+1;
	for(int i=1;i<n;i++)
	{
		int x=read(),y=read();du[x]++;du[y]++;
		add_edg(x,y);add_edg(y,x);
	}
	type1=0;type2=1;
	for(int i=1;i<=n;i++)
	{
		if(col[i]) type1|=1;
		if(!col[i]) type1|=2;
	}
	for(int i=1;i<=n;i++) if(du[i]>2) type2=0;
	if(type1==1) work1();
//	else if(type2) work2();
	return 0;
}
