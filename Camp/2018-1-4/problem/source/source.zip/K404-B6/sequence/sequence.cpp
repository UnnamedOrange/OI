#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;void re(int& x)
{
	while(ch=getchar(),ch<33);x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
}
using namespace std;
int n,x[24];
bool fin;
void sp(int t)
{
	for(int i=1,j=t;i<j;++i,--j)
		swap(x[i],x[j]);
}
void dfs(int step,int end)
{
	if(step == end)
	{
		for(int i=1;i<=n;++i)
			if(x[i] != i)
				return;
		fin=1;
	}
	else 
	{
		int need=0;
		for(int i=1;i<n;++i)	
			need+=abs(x[i]-x[i+1])!=1;
		need+=x[n]!=n;
		if(step+need>end)return;
		int tmp[24];
		memcpy(tmp,x,sizeof x);
		for(int i=2;i<=n;++i)
		{
			sp(i);
			dfs(step+1,end);
			if(fin)return;
			memcpy(x,tmp,sizeof x);
		}
	}
}
int main()
{
	open(sequence);
	int T;re(T);
	while(T--)
	{
		re(n);fin=0;
		for(int i=1;i<=n;++i)re(x[i]);
		for(int i=0;;++i)
		{
			dfs(0,i);
			if(fin)
			{
				printf("%d\n",i);
				break;
			}
		}
	}
}
