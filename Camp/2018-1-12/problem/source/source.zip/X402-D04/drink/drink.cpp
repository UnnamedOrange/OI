#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1000010;
int n;
double a[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

double ans;
ll c1[maxn], c2[maxn], c3[maxn];

int main(){
	freopen("drink.in","r",stdin),freopen("drink.out","w",stdout);

	read(n);
	int x;
	for(int i=1;i<=n;i++) read(x), a[i]=x;
	for(int i=1;i<=n;i++){
		int cnt1=0, cnt2=0;
		for(int j=0;j<=n;j++) c1[j]=c2[j]=c3[j]=0;
		for(int l=i;l>=1;l--){
			if(a[l]>a[i]) cnt1++;
			c1[cnt1]++;
		}
		for(int r=i;r<=n;r++){
			if(a[r]>a[i] || (a[r]==a[i] && r>i)) cnt2++;
			c2[cnt2]++;
		}
		// for(int j=0;j<=n;j++) printf("%d ", c1[j]); puts("");
		// for(int j=0;j<=n;j++) printf("%d ", c2[j]); puts("");
		// printf("i = %d : %d %d\n", i, cnt1, cnt2);
		for(int l=0;l<i;l++) for(int r=0;i+r<=n;r++) c3[l+r]+=c1[l]*c2[r];
		// printf("i = %d\n", i);
		/*
		int tot=0;
		for(int l=i;l>=1;l--){
			if(a[l]>a[i]) cnt1++;
			cnt2=0;
			for(int r=i;r<=n;r++){
				tot++;
				if(a[r]>a[i] || (a[r]==a[i] && r>i)) cnt2++;
				// printf("%d %d\n", cnt1, cnt2);
				c3[cnt1+cnt2]++;
			}
		}
		*/
		// printf("cnt2 = %d\n", tot);
		/*
		cnt2=0;
		for(int l=1;l<=i;l++){
			for(int r=i;r<=n;r++){
				cnt2++;
				cnt1=0;
				for(int k=l;k<=r;k++){
					if(a[k]>a[i] || (a[k]==a[i] && k>i)) cnt1++;
				}
				c3[cnt1]++;
			}
		}
		*/
		// printf("cnt2 = %d\n", cnt2);
		// for(int j=0;j<=n;j++) printf("%d ", c3[j]); puts("");
		double now=a[i];
		for(int j=0;j<=n;j++){
			now/=2;
			ans+=now*c3[j]/n/n;
		}
	}
	printf("%.10lf\n", ans);
	return 0;
}
