#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

int type;
int n, T;

namespace file{
	inline void open()
	{
		freopen("xmasset.in", "r", stdin);
		freopen("xmasset.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

inline int read()
{
	int a = 0;
	char ch;
	int f = 1;
	while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
	if(ch == '-')
		f = -1;
	else
	{
		a = a * 10;
		a += ch - '0';
	}
	while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
	{
		a = a * 10;
		a += ch - '0';
	}
	return a * f;
}

inline int encode(int x, int y)
{
	int i = 1;
	while(x > 0 && y > 0)
	{
		if((x & 1) ^ (y & 1))
		{
			int ret = 10 - i;
			if(x & 1)
				return 2 * ret - 1;
			else
				return 2 * ret;
			break;
		}
		++i;
		x >>= 1;
		y >>= 1;
	}
}

inline void A()
{
	n = read(), T = read();
	while(T--)
	{
		int x = read(), y = read();
		printf("%d\n", encode(x, y));
	}
}

inline void decode(int q, int h)
{
	int pos = 10 - ((h + 1) / 2);
	if(h & 1)
	{
		if(q & (1 << (pos - 1)))
			printf("yes\n");
		else
			printf("no\n");
	}
	else
	{
		if(q & (1 << (pos - 1)))
			printf("no\n");
		else
			printf("yes\n");
	}
}

inline void B()
{
	n = read(), T = read();
	while(T--)
	{
		int q = read(), h = read();
		decode(q, h);
	}
}

int main()
{
	open();
	type = read();
	if(type == 1)
		A();
	else if(type == 2)
		B();
	close();
	return 0;
}
