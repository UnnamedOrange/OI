#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int md=998244353;
const int N=5009;

inline void chk(int &a){if(a>=md)a-=md;}

int n,k,g[N][N];
int vis[N],ans;

inline bool dfs(int u,int dist,int t,int tim)
{
	//printf("%d %d %d %d\n",u,dist,t,tim);
	if(u==t && dist!=0)
	{
		if(dist==k)
			return true;
		return false;
	}
	if(u!=t)vis[u]=tim;
	for(int i=1;i<=n;i++)
		if(vis[i]!=tim && g[u][i])
			if(dfs(i,dist+1,t,tim))
				return true;
	return false;
}

inline bool judge()
{
	memset(vis,0,sizeof(vis));
	//for(int i=1;i<=n;i++,puts(""))
	//	for(int j=1;j<=n;j++)
	//		printf("%d ",g[i][j]);
	//puts("");

	int times=1;
	for(int i=1;i<=n;i++)
		if(dfs(i,0,i,++times))
			return true;
	return false;
}

inline void dfs(int i,int j)
{
	if(i==n)
	{
		if(judge())
			chk(++ans);
		return;
	}

	g[j][i]=0;
	g[i][j]=1;
	if(j<n)dfs(i,j+1);
	else dfs(i+1,i+2);
	g[j][i]=1;
	g[i][j]=0;
	if(j<n)dfs(i,j+1);
	else dfs(i+1,i+2);
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);

	scanf("%d%d",&n,&k);
	dfs(1,2);
	printf("%d\n",ans);
	return 0;
}
