﻿《算法竞赛入门经典》代码仓库

第十一章习题代码

注意：有些题目并没有在书中出现，但是仍然有一定的启发意义，所以一并放在这里，供读者参考。

所有代码中都写了题目大意。

UVa10034 Freckles                最小生成树
UVa10397 Connect the Campus      最小生成树
UVa10048 Audiophobia             Floyd算法变形
UVa10099 The Tourist Guide       Floyd算法变形
UVa10986 Sending email           Dijkstra
UVa558   Wormholes               Bellman-Ford找负圈
UVa820   Internet Bandwidth      最大流
UVa10330 Power Transmission      最大流，拆点
UVa10594 Data Flow               最小费用最大流
UVa10746 Crime Wave - The Sequel 二分图最小权匹配（用最小费用最大流实现）
