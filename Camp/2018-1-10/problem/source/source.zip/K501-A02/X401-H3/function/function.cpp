#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1000005;
ll read(){
    ll f=1,ret=0;
    char ch=getchar();
    while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
    while(ch<='9'&&ch>='0'){ret=ret*10+ch-'0';ch=getchar();}
    return f*ret;
}
int mu[N],prime[N],isprime[N],tot,d[N],c[N];
ll q[N];
void genPrime(int n){
    memset(isprime,true,sizeof isprime);
    mu[1]=d[1]=c[1]=1;
    for(int i=2;i<=n;++i){
        if(isprime[i]){
            prime[++tot]=i;
            mu[i]=-1;
            c[i]=1;
            d[i]=2;
        }
        for(int j=1;j<=tot&&i*prime[j]<=n;++j){
            isprime[i*prime[j]]=false;
            if(i%prime[j]==0){
                d[i*prime[j]]=d[i]/(c[i]+1)*(c[i]+2);
                c[i*prime[j]]=c[i]+1;break;
            }
            mu[i*prime[j]]=-mu[i];
            d[i*prime[j]]=d[i]*d[prime[j]];
            c[i*prime[j]]=1;
        }
    }
}
int main(){
	genPrime(1000000);
	for(int i=1;i<=1000000;i++)for(int j=1;j*i<=1000000;j++)q[j*i]+=mu[i]*d[j]*d[j];
	for(int i=1;i<=1000000;i++)q[i]+=q[i-1];
	int T=read();
	while(T--){
		ll n=read();
		printf("%lld\n",q[n]);
	}
	
	return 0;
}

