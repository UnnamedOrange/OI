#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int maxn = 100000 + 10;
const int mod = 1e+9 + 7;

int n,a,b;
bool swaped;
int x[maxn];
int pow2[maxn],acnt,xcnt,hcnt;

void init()
{
	int i;
	pow2[0]=1;
	for(i=1;i<maxn;i++) pow2[i]=pow2[i-1]*2%mod;
}

inline void cnt(int x)
{
	x%=a+b;
	if(x<a) hcnt++;
	else if(x<b) acnt++;
	else xcnt++;
}
void read()
{
	int i;
	
	scanf("%d%d%d",&n,&a,&b);swaped=false;
	if(a>b) swap(a,b),swaped=true;
	acnt=hcnt=xcnt=0;
	for(i=0;i<n;i++) scanf("%d",x+i),cnt(x[i]);
	
}

void solve()
{
	ll t1=pow2[xcnt-1+hcnt],t2=(pow2[n]-t1*2%mod+mod)%mod;
	if(swaped) cout<<0<<' '<<t2<<' '<<t1<<' '<<t1<<endl;
	else       cout<<t2<<' '<<0<<' '<<t1<<' '<<t1<<endl;
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	
	init();
	read();
	solve();
	
	return 0;
}
