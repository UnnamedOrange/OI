#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>
#include <cmath>

using namespace std;

const int MAXN = 1e5 + 10;
int n;
int a, b;
long long mod = 1e9 + 7;
long long x[MAXN]; 
long long bc = 0;
long long bn = 0;
long long Ac = 0, Bc = 0;
long long sbc, sbn, sAc, SBc;
long long ans1 = 0, ans2 = 0, ans3 = 0, ans4 = 0;
long long c[110][110]; 
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

void open()
{
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}

long long fast(long long x, long long k)
{
	long long res = 1;
	long long cnt = x;
	while(k) {
		if(k % 2 == 1) {
			res = res * cnt % mod;
			k--;
		} else {
			cnt = cnt * cnt % mod;
			k = k / 2;
		}
	}
	return res;
}
void init()
{
	for(int i = 0; i < 100; i++) {
		c[i][0] = 1;
		for(int j = 1; j <= i; j++) {
			c[i][j] = c[i - 1][j - 1] + c[i - 1][j] % mod; 
		}
	}
}
int main()
{
	open();
	init();
	n = read(), a = read(), b = read();
	for(int i = 1; i <= n; i++) {
		x[i] = read();
		x[i] = x[i] % (a + b);
		if(x[i] >= a && x[i] >= b) {
			bc++;
		} else if(x[i] < a && x[i] < b) {
			bn++;
		} else if(x[i] >= a && x[i] < b) {
			Ac++;
		} else if(x[i] < a && x[i] >= b) {
			Bc++;
		}
	}	
	sbn = fast(2, bn);
	for(long long i = 1; i <= Ac; i++) {
		for(int j = 0; j < min(i, Bc + 1); j++) {
			ans1 = (ans1 + c[Ac][i] * c[Bc][j]) % mod;
		}
	}
	for(long long i = 1; i <= Bc; i++) {
		for(int j = 0; j < min(i, Ac + 1); j++) {
			ans2 = (ans2 + c[Bc][i] * c[Ac][j]) % mod;
		}
	}
	long long tt = 0;
	for(long long i = 1; i <= bc; i += 2) {
		tt = (tt + c[bc][i]) % mod;
	}
	for(int i = 0; i <= min(Ac, Bc); i++) {
		ans3 = (ans3 + c[Ac][i] % mod * c[Bc][i]) % mod;
	}
	ans3 = ans3 * tt % mod;
	tt = 0;
	for(int i = 0; i <= bc; i += 2) {
		tt = (tt + c[bc][i]) % mod;
	}
	for(int i = 0; i <= min(Ac, Bc); i++) {
		ans4 = (ans4 + c[Ac][i] % mod * c[Bc][i]) % mod;
	}
	ans4 = ans4 * tt % mod;
	printf("%lld %lld %lld %lld", ans1 * sbn % mod, ans2 * sbn % mod, ans3 * sbn % mod, ans4 * sbn % mod);
	close();
	return 0;
}
