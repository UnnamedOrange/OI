#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int f[1024], _c[1024], w[30005], r[30005], fa[30005], first[30005], tot, n, E;
struct Edge{int to,nex; Edge(){} Edge(int _to, int _nex){to=_to,nex=_nex;}}e[60005];
inline void Add(int a, int b){e[tot] = Edge(b,first[a]), first[a] = tot++, e[tot] = Edge(a,first[b]), first[b] = tot++;}
void DFS(int p){for(rint u = first[p], v; ~u; u = e[u].nex) if((v=e[u].to)-fa[p]) fa[v] = p, DFS(v);}
bool Check(int p, int S){for(p = fa[p]; p; p = fa[p]) if((S>>~-p)&1) return false; return true;}
int Robot(int S)
{
	if(!S) return 0; if(f[S]) return f[S];
	for(rint i = 1; i <= n; i++)
		if((S>>~-i)&1 && Check(i,S)) f[S] = max(f[S],Robot(S^(1<<~-i))+w[i]*-~_c[S]); return f[S];
}
int main()
{
	freopen("xmastree2.in","r",stdin), freopen("xmastree2.out","w",stdout);
	n = read(), memset(first+1,-1,n<<2); for(rint i = 2; i <= n; Add(read(),read()), i++); E = ~-(1<<n);
	if(n <= 10)
	{
		for(rint i = 1; i <= n; w[i] = read(), r[i] = read(), i++);
		for(rint i = 1; i <= E; _c[i] = -~_c[i-(i&-i)], i++);
		for(rint i = 0; i <= E; _c[i] = n-_c[i], i++);
		for(rint i = 1; i <= n; i++)
			if(r[i]){DFS(i), f[E] = max(f[E],Robot(E^(1<<~-i))+w[i]);} printf("%d\n",f[E]);
	}	return 0;
}
