#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <queue>
#define LL long long
using namespace std;
const int Maxn = 400000 + 100, Mod = 998244353;
int Begin[Maxn], Next[Maxn], To[Maxn], e;
LL W[Maxn];
int N, M, K;
inline LL Pow(LL a, LL b)
{
	LL Ans = 1;
	while (b)
	{
		if (b & 1) (Ans *= a) %= Mod;
		(a *= a) %= Mod;
		b >>= 1;
	}
	return Ans;
}
inline void add_edge(int x, int y)
{
	To[ ++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}
LL Sum[Maxn], Cnt[Maxn];
queue <int> q;
int In[Maxn];
inline void BF1()
{
	q.push(1);
	Cnt[1] = 1;
	while (!q.empty())
	{
		int x = q.front(); q.pop();
		for (int i = Begin[x]; i; i = Next[i])
		{
			int y = To[i];
			In[y] --;
			(Cnt[y] += Cnt[x]) %= Mod;
			(Sum[y] += Cnt[x] + Sum[x]) %= Mod;
			if (!In[y]) q.push(y);
		}
	}
	for (int i = 1; i <= N; ++i)
		printf("%lld\n", Sum[i]);
}
LL A[2010][2010];
inline void BF2()
{
	q.push(1);
	A[1][0] = 1;
	while (!q.empty())
	{
		int x = q.front(); q.pop();
	//	cout<<x<<endl;
		for (int i = Begin[x]; i; i = Next[i])
		{
			int y = To[i];
			In[y] --;
			for (int j = 1; j < N; ++j)
				A[y][j] += A[x][j - 1];
			if (!In[y]) q.push(y);
		}
	}
	for (int i = 1; i <= N; ++i)
	{
		LL Ans = 0ll;
		for (int j = 1; j < N; ++j)
			(Ans += ((A[i][j] * Pow((LL)j, K)) % Mod)) %= Mod;
		printf("%lld\n", Ans);
	}
}
LL C[50][50];
LL F[100000 + 100][50];
inline void BF3()
{
	C[0][0] = 1;
	for (int i = 1; i <= 50; ++i)
		for (int j = 0; j <= i; ++j)
		{
			if (i == j || !j) C[i][j] = 1;
			else C[i][j] = (C[i - 1][j] + C[i - 1][j - 1]) % Mod;
		}
	q.push(1);
	F[1][0] = 1;
	while (!q.empty())
	{
		int x = q.front(); q.pop();
	//	cout<<x<<endl;
		for (int i = Begin[x]; i; i = Next[i])
		{
			int y = To[i];
			In[y] --;
			for (int j = 0; j <= K; ++j)
				for (int k = 0; k <= j; ++k)
					(F[y][j] += ((F[x][k] * C[j][k]) % Mod)) %= Mod;
			if (!In[y]) q.push(y);
		}
	}
	for (int i = 1; i <= N; ++i)
		printf("%lld\n", F[i][K]);

}
int main()
{
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	scanf("%d%d%d", &N, &M, &K);
	for (int i = 1; i <= M; ++i)
	{
		int x, y;
		LL z;
		scanf("%d%d", &x, &y);
		add_edge(x, y);
		In[y] ++;
	}
	if (K == 1) BF1();
	else if (N <= 2000 && M <= 5000) BF2();
	else BF3();
	return 0;
}
