#include<cstdio>
#include<cstring>
#include<algorithm>
#define N 500001
#define M 1<<20
#define il inline
#define rg register
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char temp[1<<25],*S=temp;
char ch;il void re(int& x)
{
	while(ch=*S++,ch<33);x=ch-48;
	while(ch=*S++,ch>33)x=x*10+ch-48;
}
using namespace std;
const int mod=1000000009;
int n,m,ans=1,x[N],f[N];
int l[M],r[M],sum[M],tag[M];
struct node
{
	int l,r;
	bool operator < (const node& a)const
	{
		return l<a.l;
	}
}p[N];
il int fix(rg int x)
{
	return x<mod?x:x-mod;
}
il void push(rg int k)
{
	if(tag[k]>1)
	{
		tag[k<<1]=1ll*tag[k<<1]*tag[k]%mod;
		tag[k<<1|1]=1ll*tag[k<<1|1]*tag[k]%mod;
		sum[k<<1]=1ll*sum[k<<1]*tag[k]%mod;
		sum[k<<1|1]=1ll*sum[k<<1|1]*tag[k]%mod;
		tag[k]=1;
	}
}
il void build(rg int k,rg int a,rg int b)
{
	l[k]=a,r[k]=b,tag[k]=1;
	if(a==b)return;
	build(k<<1,a,a+b>>1);
	build(k<<1|1,(a+b>>1)+1,b);
}
il void cal(rg int k,rg int a,rg int b)
{
	if(a>r[k] || b<l[k])return;
	if(a<=l[k] && b>=r[k])
	{
		tag[k]=(tag[k]<<1)%mod;
		sum[k]=(sum[k]<<1)%mod;
		return;
	}
	cal(k<<1,a,b);
	cal(k<<1|1,a,b);
	push(k);
	sum[k]=fix(sum[k<<1]+sum[k<<1|1]);
}
il void add(rg int k,rg int a,rg int b)
{
	if(l[k]==r[k])
	{
		sum[k]=(sum[k]+b)%mod;
		return;
	}
	push(k);
	if(a <= l[k]+r[k]>>1)add(k<<1,a,b);
	else add(k<<1|1,a,b);
	sum[k]=fix(sum[k<<1]+sum[k<<1|1]);
}
il int ask(rg int k,rg int a,rg int b)
{
	if(a>r[k] || b<l[k])return 0;
	if(a<=l[k] && b>=r[k])return sum[k];
	push(k);
	return fix(ask(k<<1,a,b)+ask(k<<1|1,a,b));
}
int main()
{
	open(xmasinterval);
	fread(temp,1,1<<25,stdin);
	re(n),re(m);
	for(rg int i=1;i<=n;++i)
		re(p[i].l),re(p[i].r);
	sort(p+1,p+n+1);
	for(rg int i=1;i<=m;++i)re(x[i]);
	sort(x+1,x+m+1);
	int cnt=0;
	for(rg int i=1;i<=m;++i)
		if(x[i]!=x[i-1])
			x[++cnt]=x[i];
	m=cnt;
	build(1,1,m+1);
	add(1,1,1);
	for(rg int i=1;i<=n;++i)
	{
		rg int a=lower_bound(x+1,x+m+1,p[i].l)-x;
		rg int b=upper_bound(x+1,x+m+1,p[i].r)-x-1;
		if(a>b)ans=(ans<<1)%mod;
		else 
		{
			if(b+1<=m)cal(1,b+2,m+1);
			add(1,b+1,ask(1,a,b+1));
		}
	}
	printf("%d\n",1ll*ask(1,m+1,m+1)*ans%mod);
}
