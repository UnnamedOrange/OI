//70pts
#include <bits/stdc++.h>
#include <algorithm>
#define L first
#define R second
#define rint register int
using namespace std;
typedef pair<int, int> pii;
const int MAXN = 1e4, MOD = 1e9+9;

int n, m, Len, Pt[2*MAXN+10], opt[100][2*MAXN+10]; 
pii P[2*MAXN+10];

template<typename T>
inline void readint(T& x) {
	T f=1, r=0; char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	x=f*r;
}

void Init() {
	static int Pt0[500010], Num[2000010];
	readint(n); readint(m);
	for(rint i=1; i<=n; i++) {
		readint(P[i].L); readint(P[i].R);
	}
	for(rint i=1; i<=m; i++) 
		readint(Pt0[i]);
	for(rint i=1; i<=n; i++) {
		Num[++Num[0]] = P[i].L;
		Num[++Num[0]] = P[i].R;
	}
	for(rint i=1; i<=m; i++)
		Num[++Num[0]] = Pt0[i];
	sort(Num+1, Num+Num[0]+1);
	Num[0] = unique(Num+1, Num+Num[0]+1) - Num - 1;
	for(rint i=1; i<=n; i++) {
		P[i].L = lower_bound(Num+1, Num+Num[0]+1, P[i].L) - Num;
		P[i].R = lower_bound(Num+1, Num+Num[0]+1, P[i].R) - Num;
	}
	for(rint i=1; i<=m; i++) {
		rint x = lower_bound(Num+1, Num+Num[0]+1, Pt0[i]) - Num;
		if(!Pt[x]) {
			Pt[x] = 1; ++Pt0[0];
		}
	}
	m=Pt0[0]; Len = Num[0];
	sort(P+1, P+n+1);
	for(rint i=1; i<=Len; i++) Pt[i] += Pt[i-1];
}

void Work() {
	P[n+1] = make_pair(Len+1, Len+1);
	for(rint j=P[n+1].L-1; Pt[P[n+1].L-1] - Pt[j] == 0; j--)
		opt[(n+1)&1][j] = 1; 
	for(rint i=n; i>=1; i--)
		for(rint j=Len; j>=P[i].L || 
			(j>=0 && Pt[P[i].L-1] - Pt[j] == 0); j--)
			opt[i&1][j] = (opt[(i+1)&1][max(P[i].R, j)] + opt[(i+1)&1][j]) % MOD;
	printf("%d", opt[1&1][0]);
}

int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	Init(); Work();
	return 0;
}
