#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while (c = getchar(), c >= '0');
}

const int M = (int) 1e6 + 5;

int n, A[M];

namespace Subtask1 {
	
	int B[M];
	
	void solve() {
		double ans = 0;
		for (int l = 1; l <= n; l++)
			for (int r = 1; r <= n; r++) {
				int sz = 0;
				for (int i = l; i <= r; i++) B[++sz] = A[i];
				sort(B + 1, B + sz + 1);
				double rs = 0;
				for (int i = 1; i <= sz; i++) rs = (rs + B[i]) / 2;
				ans += rs;
			}
		printf("%.6f\n", ans / n / n);
	}
	
}

namespace Subtask2 {
	#define double long double
	double pw[M];
	int P[M], pos[M];
	
	bool cmp(int a, int b) {
		if (A[a] != A[b]) return A[a] < A[b];
		return a < b;
	}
	
	double sum[M << 1];
	int mul[M << 1];
	
	#define lson (p << 1)
	#define rson (p << 1 | 1)
	
	void up(int p) {
		sum[p] = sum[lson] + sum[rson];
	}
	
	void down(int p) {
		if (!mul[p]) return;
		mul[lson] += mul[p];
		mul[rson] += mul[p];
		sum[lson] *= pw[mul[p]];
		sum[rson] *= pw[mul[p]];
		mul[p] = 0;
	}
	
	void build(int l, int r, int p) {
		sum[p] = 0; mul[p] = 0;
		if (l == r) return;
		int mid = (l + r) >> 1;
		build(l, mid, lson);
		build(mid + 1, r, rson);
	}
	
	void update(int L, int R, int l, int r, int p) {
		if (L == l && r == R) {
			mul[p]++;
			sum[p] *= 2;
			return;
		}
		down(p);
		int mid = (L + R) >> 1;
		if (r <= mid) update(L, mid, l, r, lson);
		else if (l > mid) update(mid + 1, R, l, r, rson);
		else update(L, mid, l, mid, lson), update(mid + 1, R, mid + 1, r, rson);
	}
	
	void modify(int l, int r, int x, double v, int p) {
		if (l == r) {
			sum[p] += v;
			return;
		}
		down(p);
		int mid = (l + r) >> 1;
		if (x <= mid) modify(l, mid, x, v, lson);
		else modify(mid + 1, r, x, v, rson);
		up(p);
	}
	
	struct BinaryIndexedTree {
		
		#define lowbit(x) ((x) & (-x))
		
		int cnt[M];
		
		void clear() {
			for (int i = 1; i <= n; i++) cnt[i] = 0;
		}
		
		void update(int x) {
			while (x <= n) {
				cnt[x]++;
				x += lowbit(x);
			}
		}
		
		int query(int x) {
			int rs = 0;
			while (x) {
				rs += cnt[x];
				x -= lowbit(x);
			}
			return rs;
		}
		
	} BIT;
	
	void solve() {
		for (int i = 1; i <= n; i++) P[i] = i;
		sort(P + 1, P + n + 1, cmp);
		for (int i = 1; i <= n; i++) pos[P[i]] = i;
		pw[0] = 1;
		for (int i = 1; i <= n; i++) pw[i] = pw[i - 1] * 2;
		double ans = 0;
		for (int i = 1; i <= n; i++) {
			build(1, n, 1); BIT.clear();
			for (int j = i; j <= n; j++) {
				int cnt = BIT.query(pos[j]);
				update(1, n, pos[j], n, 1);
				modify(1, n, pos[j], pw[cnt] * A[j], 1);
				BIT.update(pos[j]);
				ans += sum[1] / pw[j - i + 1];
			}
		}
		printf("%.6Lf\n", ans / n / n);
	}
	
}

int main() {
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	Rd(n);
	for (int i = 1; i <= n; i++) Rd(A[i]);
	if (n <= 100) Subtask1::solve();
	else Subtask2::solve();
	return 0;
}
