#include <cstdio>

using namespace std;

typedef long long ll;
const int N = 100010;
const int mod = 998244353;

struct edge{int to, next;} e[N << 1];
ll dp1[N], dp2[N], dp3[N], dp4[N], dp5[N], ans;
int head[N], du[N], n, x, y, cnt;
char c[N];
 
void ins(int x, int y)
{
	e[++cnt].to = y; e[cnt].next = head[x]; head[x] = cnt; ++du[x];
}
 
ll pow(ll x, int y)
{
	ll ans = 1;
	for(; y; y >>= 1)
	{
		if (y & 1) ans = ans * x % mod;
		x = x * x % mod;
	}
	return ans;
}
ll inv(ll x) {return pow(x, mod - 2);}

//dp1[i] �ߵ� i �ŵ���Է��ظ��׵ĸ���
//dp1[i] = (1/du[i]) (1 + sum(dp1[j]) * dp1[i] )

void dfs1(int x, int y)
{
	ll tmp = inv(du[x]), now = 1;
	for(int i = head[x]; i; i = e[i].next)
		if (e[i].to != y && du[e[i].to] > 1)
		{
			dfs1(e[i].to, x);
			now = (now - tmp * dp1[e[i].to] % mod + mod) % mod;
		}
	if (x != 1) dp1[x] = tmp * inv(now) % mod;
}

//dp2[i] ���� fa[i] ֮�󾭹� i �ĸ���
//dp3[i] ���� i �ŵ�ĸ��� 
//dp2[i] = (1/du[fa[i]]) * (1 + (sum(dp1[j (j��i�ֵ�)]) + dp2[fa[i]]) * dp2[i])
//dp3[i] = dp3[fa[i]] * dp2[i] 

void dfs2(int x, int y)
{
	if (x == 1) dp3[x] = 1; else dp3[x] = dp3[y] * dp2[x] % mod;
	ll sum = dp2[x], tmp = inv(du[x]), now = 1;
	for(int i = head[x]; i; i = e[i].next)
		if (e[i].to != y) sum = (sum + dp1[e[i].to]) % mod;
	for(int i = head[x]; i; i = e[i].next)
		if (e[i].to != y)
		{
			now = (now - tmp * (sum - dp1[e[i].to]) % mod + mod) % mod;
			dp2[e[i].to] = tmp * inv(now) % mod;
			dfs2(e[i].to, x); 
		}
}

// dp4[i] ���� i �ŵ����������
// dp5[i] dp4[i] = dp5[i] * dp4[fa[i]]

void dfs3(int x, int y)
{
	ll tmp = inv(du[x]), now = 1;
	for(int i = head[x]; i; i = e[i].next)
		if (e[i].to != y && du[e[i].to] > 1)
		{
			dfs3(e[i].to, x);
			now = (now - tmp * dp5[e[i].to] % mod + mod) % mod;
		}
	if (x != 1) dp5[x] = tmp * inv(now) % mod; else dp4[x] = inv(now);
}

void dfs4(int x, int y)
{
	for(int i = head[x]; i; i = e[i].next)
		if (e[i].to != y && du[e[i].to] > 1)
		{
			dp4[e[i].to] = dp5[e[i].to] * dp4[x] % mod;
			dfs4(e[i].to, x);
		}
}

int main()
{
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	scanf("%d%s", &n, c + 1);
	for(int i = 1; i < n; ++i)
	{
		scanf("%d%d", &x, &y);
		ins(x, y); ins(y, x);
	}
	dfs1(1, 0); dfs2(1, 0); dfs3(1, 0); dfs4(1, 0);
	for(int i = 1; i <= n; ++i) 
		ans = (ans + ((c[i] == '0' || du[i] == 1) ? dp3[i] : dp4[i])) % mod;
	printf("%lld\n", ans);
	return 0;
}
