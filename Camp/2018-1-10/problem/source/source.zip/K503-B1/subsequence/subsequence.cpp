#include<bits/stdc++.h>
using namespace std;
const int maxn=4010;
int n,m,k,a[maxn],b[maxn];
int dp[maxn][maxn],mp1[maxn][maxn],mp2[maxn][maxn];
int i,j,kk;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	n=read(); m=read(); k=read();
	for (i=1;i<=n;i++) a[i]=read();
	for (i=1;i<=m;i++) b[i]=read();
	for (i=0;i<=n+1;i++){
		for (j=1;j<=k;j++){
			for (kk=i+1;kk<=n;kk++){
				if (a[kk]==j){
					mp1[i][j]=kk;
					break;
				}
			}
			if (mp1[i][j]==0) mp1[i][j]=n+1;
		}
	}
	for (i=0;i<=m+1;i++){
		for (j=1;j<=k;j++){
			for (kk=i+1;kk<=n;kk++){
				if (b[kk]==j){
					mp2[i][j]=kk;
					break;
				}
			}
			if (mp2[i][j]==0) mp2[i][j]=m+1;
		}
	}
	for (i=0;i<=n+1;i++){
		for (j=0;j<=m+1;j++){
			dp[i][j]=1e9;
		}
	}
	dp[0][0]=0;
	for (i=0;i<=n+1;i++){
		for (j=0;j<=m+1;j++){
			for (kk=1;kk<=k;kk++){
				dp[mp1[i][kk]][mp2[j][kk]]=min(dp[mp1[i][kk]][mp2[j][kk]],dp[i][j]+1);
			}
		}
	}
	printf("%d\n",dp[n+1][m+1]);
	return 0;
}
