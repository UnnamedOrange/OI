#include<bits/stdc++.h>
using namespace std;
const int R_LEN=(1<<18)|1;
struct Fast_io{
    char ibuf[R_LEN],obuf[R_LEN],*s,*t,*wt;
    int buf[50];
    Fast_io(){
        s=ibuf,t=ibuf,wt=obuf;
        memset(buf,0,sizeof(buf));
    }
    ~Fast_io(){fwrite(obuf,1,wt-obuf,stdout);}
    inline char getc(){
        (s==t)&&(t=(s=ibuf)+fread(ibuf,1,R_LEN,stdin));
        return (s==t)?-1:*s++;
    }
    inline int rd(){
        char ch=getc(); int i=0,f=1;
        while(!isdigit(ch)){if(ch=='-')f=-1;ch=getc();}
        while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getc();}
        return i*f;
    }
    inline void print(char c){
        (wt==obuf+R_LEN) && (fwrite(obuf,1,R_LEN,stdout),wt=obuf);
        *wt++=c;
    }
    template<typename T>
    inline void W(T x){
        if(!x){print('0');return;}
        if(x<0){print('-');x=-x;}
        while(x){buf[++buf[0]]=x%10;x/=10;}
        while(buf[0])print(buf[buf[0]--]+'0');
    }
}io;
const int N=3e2+50;
int n,m,k,a[N],b[N],f[N][N],preA[N][N],preB[N][N],lst[N];
inline void pre(){
	for(int i=1;i<=n;i++){
		lst[a[i]]=i;
		for(int j=1;j<=k;j++) preA[i][j]=lst[j];
	}
	memset(lst,0,sizeof(lst));
	for(int i=1;i<=m;i++){
		lst[b[i]]=i;
		for(int j=1;j<=k;j++) preB[i][j]=lst[j];
	}
}
int main() {
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	n=io.rd(),m=io.rd(),k=io.rd();
	for(int i=1;i<=n;i++) a[i]=io.rd();
	for(int i=1;i<=m;i++) b[i]=io.rd();
	pre();
	for(int i=0;i<=n;i++)
		for(int j=0;j<=m;j++){
			if(!i||!j)continue;
			int mx=0x3f3f3f3f;
			for(int c=1;c<=k;c++){
				int t1=min(i-1, preA[i][c]? f[preA[i][c]-1][j]: -1);
				int t2=min(j-1, preB[j][c]? f[i][preB[j][c]-1]: -1);
				mx=min(mx,max(t1,t2)+1);
			}
			f[i][j]=mx; 
			if(i)f[i][j]=max(f[i-1][j],f[i][j]);
			if(j)f[i][j]=max(f[i][j-1],f[i][j]);
		}
	io.W(f[n][m]+1);
}
