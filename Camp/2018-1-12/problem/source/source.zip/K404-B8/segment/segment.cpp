#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl
typedef long long ll;
using namespace std;
const int maxn = 359;
const int mod = 998244353;

ll f[maxn][maxn][maxn],g[maxn][maxn][maxn],sum1[maxn][maxn][maxn],sum2[maxn][maxn][maxn],a[maxn],pw[maxn];
int n,m,K,ans;

int PowerMod(int x,int y)
{
	if(x==0) return 0;
	int res=1;
	while(y)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;y>>=1;
	}return res;
}
int calc()
{
	int res=0;
	for(int i=1;i<=n;i++) res=(res+pw[a[i]])%mod;
	return res;
}
void dfs(int step,int L,int R)
{
	if(step==m)
	{
		ans=(ans+calc())%mod;
		return ;
	}
	for(int i=L+1;i<=n;i++)
		for(int j=R+1;j<=n;j++)
			if(i<=j)
			{
				for(int p=i;p<j;p++) a[p]++;
				dfs(step+1,i,j);
				for(int p=i;p<j;p++) a[p]--;
			}
}

void work1()
{
	if(m>n) puts("0");
	else
	{
		dfs(0,0,0);
		cout<<ans<<endl;
	}
}
void work2()
{
	g[0][0][0]=1;
	for(int i=0;i<=n;i++) for(int j=i;j<=n;j++) sum1[0][i][j]=1;
	for(int i=1;i<=m;i++)
		for(int j=i;j<=n;j++)
			for(int k=j;k<=n;k++)
			{
				f[i][j][k]=(sum2[i-1][j-1][k-1]+sum1[i-1][j-1][k-1]*(k-j)%mod)%mod;
				g[i][j][k]=sum1[i-1][j-1][k-1];
				sum1[i][j][k]=((g[i][j][k]+sum1[i][j-1][k]+sum1[i][j][k-1]-sum1[i][j-1][k-1])%mod+mod)%mod;
				sum2[i][j][k]=((f[i][j][k]+sum2[i][j-1][k]+sum2[i][j][k-1]-sum2[i][j-1][k-1])%mod+mod)%mod;
			}
	int res=0;
	for(int i=1;i<=n;i++)
		for(int j=i;j<=n;j++)
			res=(res+f[m][i][j])%mod,printf("%d %d %d\n",i,j,f[m][i][j]);
	cout<<res<<endl;
}
void work3()
{
}
void work4()
{
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&m,&n,&K);
	if(m>=n){puts("0");return 0;}
	for(int i=1;i<=min(m,n);i++) pw[i]=PowerMod(i,K);
	if(n<=6) work1();
	else if(K==1) work2();
	else if(K==998244352) work3();
	else if(m==1) work4();
}
