#include<bits/stdc++.h>
using namespace std;
double t[20000],ans;
int a[2000000],n,m,l[20000],r[20000];
bool smaller(int x,int y){return (a[x]<a[y])||((a[x]==a[y])&&(x<y));}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	t[0]=1;ans=0;
	for (int i=1;i<=20000;i++) t[i]=t[i-1]*0.5;
	scanf("%d",&n);m=100000000/n;
	for (int i=1;i<=n;i++) scanf("%d",a+i);
	for (int i=1;i<=n;i++){
		double sl=0,sr=0;
		int las=i,j=i-1,cnt=0;
		while ((cnt<=m)&&(j>=0)){
			while ((j>0)&&(smaller(j,i))) j--;
			l[cnt++]=las-j;las=j--; 
		}
		for (j=0;j<cnt;j++)
		sl+=t[j]*l[j];
		las=i;j=i+1;cnt=0;
		while ((cnt<=m)&&(j<=n+1)){
			while ((j<=n)&&(smaller(j,i))) j++;
			r[cnt++]=j-las;las=j++; 
		}
		for (j=0;j<cnt;j++)
		sr+=t[j]*r[j];
		ans+=sl*sr*0.5*a[i];
	}
	printf("%.12f\n",ans/n/n);
	return 0;
}
