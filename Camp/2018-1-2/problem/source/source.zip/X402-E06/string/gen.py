import sys
from random import *

sys.stdout = open("string.in", "w")

T = 20
print (T)
a = ['a', 'b', 'c', 'd']

for i in range(T):
    n = randint(5, 10)
    print (n)
    for j in range(n):
        print (a[randint(0, 2)], end = '')
    print ()
        
