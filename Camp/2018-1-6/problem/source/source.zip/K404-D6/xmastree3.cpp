#include<cstdio>
#include<queue>
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
using namespace std;
int n,k,x,y;
const int mod=998244353;
int ans=0;
bool vis[51];
struct edge{
	int to;
	edge *nxt;
}e[511],*las[511],*et=e;
int dp[1<<17][17][17];
int cnt;
bool h[1<<17][17][17];
int xu[511],num[511];
inline void add(int x,int y){
	*++et=(edge){y,las[x]};las[x]=et;
}
inline int dfs(int s,int f,int x,int t){
	if(h[t][s][x])
		return dp[t][s][x];
	h[t][s][x]=1;
	int ret=1;
	vis[s]=1;
	register int dep[51]={},p[51]={};
	queue<int>q;
	for(register edge *it=las[s];it;it=it->nxt){
		if(!vis[it->to]){
			dep[it->to]=1;
			register int part=0,now;
			q.push(it->to);
			while(!q.empty()){
				now=q.front();q.pop();
				FOR(v,x+1,k)
					part=(part+dfs(now,s,v,t|(1<<now-1)))%mod;
				for(register edge *t=las[now];t;t=t->nxt)
					if(!vis[t->to]&&!dep[t->to]&&dep[now]+1+x<=k){
						q.push(t->to);
						dep[t->to]=dep[now]+1;
					}
			}
			ret=1ll*ret*part%mod;
		}
	}
	vis[s]=0;
	return dp[t][s][x]=ret;
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	FOR(i,2,n){
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	FOR(i,1,n)
		FOR(j,1,k)
			ans=(ans+dfs(i,0,j,(1<<i-1)));	
	printf("%d\n",ans);
	return 0;
}
/*
10 10
9 10
2 3
7 4
2 4
5 6
8 1 
1 5
1 2
9 8
*/
