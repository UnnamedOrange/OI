#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 1000001
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
int cnt,prime[N],d[N],mu[N],ans[N];
bool vis[N];
void init()
{
	mu[1]=d[1]=1;
	for(int i=2;i<N;++i)
	{
		if(!vis[i])
		{
			prime[++cnt]=i;
			mu[i]=-1;
		}
		++d[i];
		for(int j=1;j<=cnt && i*prime[j]<N;++j)
		{
			vis[i*prime[j]]=1;
			if(i%prime[j]==0)
			{
				mu[i*prime[j]]=0;
				break;	
			}
			else mu[i*prime[j]]=-mu[i];
		}
		for(int j=i;j<N;j+=i)++d[j];
	}
	for(int i=1;i<N;++i)
		for(int j=i;j<N;j+=i)
			ans[j]+=mu[i]*d[j/i]*d[j/i];
	for(int i=1;i<N;++i)
		ans[i]+=ans[i-1];
}
int main()
{
	open(function);
	init();
	int T;re(T);
	while(T--)
	{
		int n;re(n);
		printf("%d\n",ans[n]);
	}
}
