#include <bits/stdc++.h>
#include <windows.h>

namespace {

typedef unsigned int uint;

uint x;

inline uint nextUint() {
    return x ^= x << 13, x ^= x >> 17, x ^= x << 5, x;
}
}

const int MAXN = 2000;
const int MAXM = 1000000;

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);
    char *t = new char;
    x = GetTickCount() * (long long)t ^ time(0);
    delete t;
    register int n = nextUint() % MAXN + 2;
    register int m = std::min(n * (n - 1ll) / 2, (long long)(nextUint() % MAXM + 1));
    std::set<std::pair<int, int> > set;
    std::cout << n << ' ' << m << '\n';
    for (register int i = 1, u, v; i <= m; i++) {
        do {
            do {
                u = nextUint() % n + 1;
                v = nextUint() % n + 1;
            } while (u == v);
            if (u > v) std::swap(u, v);
        } while (set.count(std::make_pair(u, v)));
        set.insert(std::make_pair(u, v));
        std::cout << u << ' ' << v << '\n'; 
    }
}
