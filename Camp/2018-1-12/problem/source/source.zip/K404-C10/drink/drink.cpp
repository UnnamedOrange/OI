#include <cstdio>
#include <algorithm>
using namespace std;
#define pr pair<int,int>
#define fr first
#define se second
#define N 1000050
int n,i,j,nxt[N],pre[N],b[N],c[N],it;
pr a[N];
inline int rd()
{
	char ch=getchar();int ret=0;
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9') ret=(ret<<3)+(ret<<1)+ch-'0',ch=getchar();
	return ret;
}
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=rd();
	for (i=1;i<=n;i++) a[i].fr=rd(),a[i].se=i;
	sort(a+1,a+n+1);double ans=0,ans1,ans2;
	for (i=n;i>=1;i--){
		it=0;
		for (j=n+1-a[i].se;j>=1;j-=(j&(-j))) it=max(it,c[j]);
		it=n+1-it;
		ans1=0;ans2=0;
		if (it!=n+1){
			int now=it,lst=a[i].se,ji=1;double psz=1;
			nxt[lst]=now;pre[now]=lst;
			while (now&&ji<=65){
				ans1+=(now-lst)/psz;
				psz*=2;lst=now;now=nxt[now];ji++;
			}ans1+=(n+1-lst)/psz;
		}else ans1+=n+1-a[i].se;
		it=0;
		for (j=a[i].se;j>=1;j-=(j&(-j))) it=max(it,b[j]);
		if (it){
			int now=it,lst=a[i].se,ji=1;double psz=1;
			nxt[now]=lst;pre[lst]=now;
			while (now&&ji<=65){
				ans2+=(lst-now)/psz;
				psz*=2;lst=now;now=pre[now];ji++;
			}ans2+=lst/psz;
		}else ans2+=a[i].se;
		ans+=ans1*ans2*a[i].fr/2;
		for (j=a[i].se;j<=n;j+=(j&(-j))) b[j]=max(b[j],a[i].se);
		for (j=n+1-a[i].se;j<=n;j+=(j&(-j))) c[j]=max(c[j],n+1-a[i].se);
	}printf("%.10f\n",ans/(1LL*n*n));
	return 0;
}
