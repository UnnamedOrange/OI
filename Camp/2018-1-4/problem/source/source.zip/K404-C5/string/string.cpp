#include<bits/stdc++.h>
typedef unsigned long long ull;
using namespace std;
int n,m;
char t[7][105];
char s[1050];
namespace SP0{
	int cnt=0;
	const ull base=31;
	ull pw[35];
	inline bool check(){
		static ull hv[31];
		for(int i=m+1;i<=2*m;++i)s[i]=(s[2*m-i+1]=='0'?'1':'0');
		for(int i=1;i<=2*m;i++)hv[i]=hv[i-1]*base+s[i];
		for(int i=1;i<=n;i++){
			int l=strlen(t[i]+1),bz=0;ull hv_t=0;
			for(int j=1;j<=l;j++)hv_t=hv_t*base+t[i][j];
			for(int j=1;j<=2*m&&(!bz);j++){
				if(j+l-1>2*m)break;
				if(hv[j+l-1]-hv[j-1]*pw[l]==hv_t)bz=1;
			}
			if(!bz)return false;
		}
		return true;
	}
	inline void dfs(int x){
		if(x==m+1){
			if(check())++cnt;
			return;
		}
		s[x]='0';dfs(x+1);
		s[x]='1';dfs(x+1);
	}
	inline void solve(){
		for(int i=1;i<=n;i++)scanf("%s",t[i]+1);
		pw[0]=1;
		for(int i=1;i<=30;i++)pw[i]=pw[i-1]*base;
		dfs(1);
		cout<<cnt<<endl;
	}
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	cin>>n>>m;
	if(m<=15)SP0::solve();
	else puts("23333");
}
