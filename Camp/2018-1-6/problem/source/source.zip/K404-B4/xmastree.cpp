#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <cstring>
#define getchar() *(pp++)
#define MOD 998244353
using namespace std;
char buf[2000100],*pp=buf;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int n,q,t,top,/*root[400010],lc[35000000],rc[35000000],sum[35000000],*/color[100010],st[100010],ed[100010],dfn[100010],dfs_clock;
bool b[5010];
struct edge
{
	int v,p;
}e[200010];
int head[100010];
inline void addedge(int u,int v)
{
	e[++top]=(edge){v,head[u]};
	head[u]=top;
	e[++top]=(edge){u,head[v]};
	head[v]=top;
}
void dfs(int u,int fa)
{
	st[u]=++dfs_clock;
	dfn[dfs_clock]=u;
	for(int i=head[u];i;i=e[i].p)
	{
		if(e[i].v==fa)continue;
		dfs(e[i].v,u);
	}
	ed[u]=dfs_clock; 
}
int ask(int l,int r,int cl,int cr)
{
	memset(b,0,sizeof(b));
	int cnt=0;
	for(int i=l;i<=r;i++)
	{
		if(cl<=color[dfn[i]]&&color[dfn[i]]<=cr&&!b[color[dfn[i]]])b[color[dfn[i]]]=1,cnt++;
	}
	return cnt;
}
int modify(int u,int c)
{
	color[u]=c;
}
int main()
{
	freopen("xmastree.in","r",stdin);
	freopen("xmastree.out","w",stdout);
	fread(buf,2000000,1,stdin);
	n=read();
	q=read();
	t=read();
	for(int i=1;i<=n;i++)
	{
		color[i]=read();
	}
	for(int i=1;i<n;i++)
	{
		addedge(read(),read());
	}
	dfs(1,0); 
	int lastans=0;
	for(int i=1;i<=q;i++)
	{
		if(read()==1)
		{
			int u=read()^lastans,l=read()^lastans,r=read()^lastans,temp=ask(st[u],ed[u],l,r);
			cout<<temp<<endl;
			if(t)lastans=temp;
		}
		else
		{
			int u=read()^lastans,c=read()^lastans;
			modify(u,c);
		}
	}
	return 0;
}
