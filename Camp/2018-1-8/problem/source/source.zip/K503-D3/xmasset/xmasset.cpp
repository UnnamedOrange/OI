#include <cstdio>

inline int read(){
    char ch=getchar(); int x=0,sgn=1;
    for (;ch<'0'||ch>'9';ch=getchar())
        if (ch=='-') sgn=-1;
    while (ch>='0'&&ch<='9')
        x=x*10+ch-'0',ch=getchar();
    return x*sgn;
}

int main(){
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	int k=read(),n=read(),t=read();
	while (t--){
		int x=read(),y=read();
		if (k==1) printf("%d\n",x);
		else printf(x==y?"yes\n":"no\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

