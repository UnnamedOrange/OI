#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)1e6+5,P=1000000007;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
int n,c[M],d[M];
struct SHUI{
	int dp[2005],f[2005];
	void solve(){
		memset(dp,-1,sizeof(dp));
		dp[0]=0,f[0]=1;
		for(int i=1;i<=n;i++){
			int mi=0,mx=n+1;
			for(int j=i;j>=1;j--){
				if(c[j]>mi)mi=c[j];
				if(d[j]<mx)mx=d[j];
				if((i-j+1)>=mi&&(i-j+1)<=mx){
					if(dp[j-1]+1>dp[i])dp[i]=dp[j-1]+1,f[i]=0;
					if(dp[j-1]+1==dp[i])Add(f[i],f[j-1]);
				}
			}
		}
		if(dp[n]==-1)puts("-1");
		else printf("%d %d\n",dp[n],f[n]);
	}
}P30;
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	Rd(n);
	for(int i=1;i<=n;i++)Rd(c[i]),Rd(d[i]);
	if(n<=2000)P30.solve();
	
	return 0;
}
