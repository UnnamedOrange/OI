#include <cstdio>
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
#define F(x,y,z) for (x=y;x<=z;++x)
using namespace std;
const int N=4004;
int n,m,K;
int a[N],b[N];
int f[2][N];
int h[N];
//int p[2][N][N];   //(a,b);(��ɫ);(λ��) 

int main()
{
	freopen("subsequence.in","r",stdin);freopen("subsequence.out","w",stdout);
	int i,j,k,l;
	scanf("%d%d%d",&n,&m,&K);
	F(i,1,n) scanf("%d",&a[i]);
	F(i,1,m) scanf("%d",&b[i]);
//	F(i,1,k)F(j,1,n)p[0][i][j]=p[0][i][j-1]+(a[j]==i);
//	F(i,1,k)F(j,1,m)p[1][i][j]=p[1][i][j-1]+(b[j]==i);
	
	F(i,1,n+m)//���� 
	{
		int now=i&1;int la=!now,ok;bool fl=0;
		F(j,0,n) f[now][j]=210000000;
		F(j,0,n)//A������ʼλ�� 
		{
			if (j>0)
				if (f[la][j]>=f[la][j-1]) continue;
			if (f[la][j]>m) continue;
			fl=1;
			
			{
				ok=0;
				F(k,1,K) h[k]=0;
				F(k,j+1,n){
					if (!h[a[k]])
						++ok;
					h[a[k]]++;
					if (ok==K) break;
				}
				l=f[la][j];int kk=k;
				for (;k>=j;--k)
				{
					if (k!=kk)
					{
						h[a[k+1]]--;
						if (!h[a[k+1]]) --ok;
					}
					while (ok!=K)
					{
						++l;
						//if (l>m && k==kk) 
						if (l>m) break;
						if (!h[b[l]]) ++ok;
						h[b[l]]++;
					}
					if (ok==K)
						f[now][k]=Min(f[now][k],l);
				}
			}
			
		}
		if (!fl){printf("%d\n",i-1);return 0;}
	}
	return 0;
}
