#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

#define LL long long

const int N = 500000 + 5000;
const int mod = 1000000009;

int n, m;
int L[N], R[N], x[N];
LL ans = 0;
int vis[40];

namespace file{
	inline void open()
	{
		freopen("xmasinterval.in", "r", stdin);
		freopen("xmasinterval.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

namespace input{
	inline int read()
	{
		int a = 0;
		char ch;
		int f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}
	
	inline void Get()
	{
		n = read(), m = read();
		for(int i = 1;i <= n;++i)
			L[i] = read(), R[i] = read();
		for(int i = 1;i <= m;++i)
			x[i] = read();
	}
	
	inline int find(int p)
	{
		int l = 0, r = m;
		if(x[m] <= p)
			return m;
		if(x[1] > p)
			return 0;
		while(l < r)
		{
			int mid = (l + r) >> 1;
			if(x[mid] < p && x[mid + 1] >= p)
				return mid;
			else if(x[mid + 1] < p)
				l = mid + 1;
			else if(x[mid] >= p)
				r = mid;
		}
	}
	
	inline void deal()
	{
		sort(x + 1, x + 1 + m);
		for(int i = 1;i <= n;++i)
		{
			L[i] = find(L[i]) + 1;
			R[i] = find(R[i]);
			printf("L[%d]=%d R[%d]=%d\n", i, L[i], i, R[i]);
		}
	}
}

namespace brute{
	inline void dfs(int p, int tot)
	{
		if(p == n + 1)
		{
			if(tot == n)
				ans = (ans + 1) % mod;
			return;
		}
		int cur = 0;
		for(int i = 1;i <= m;++i)
			if(!vis[i] && x[i] >= L[p] && x[i] <= R[p])
				vis[i] = p, ++cur;
		dfs(p + 1, tot + cur);
		for(int i = 1;i <= m;++i)
			if(vis[i] == p)
				vis[i] = 0;
		dfs(p + 1, tot); 
	}
	
	inline void solve()
	{
		dfs(1, 0);
		printf("%lld\n", ans);
	}
}

namespace method{
	inline void solve()
	{
		input::deal();
	}
}

namespace check{
	inline void deter()
	{
		if(n <= 20)
			brute::solve();
		else
			method::solve();
	}
}

int main()
{
	open();
	input::Get();
	check::deter();
	close();
	return 0;
} 
