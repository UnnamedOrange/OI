#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100005,mod=998244353;
int n,p[maxn],vis[maxn];
int fa[maxn],sz[maxn],ans;
int find_fa(int x){
	return x==fa[x]?x:fa[x]=find_fa(fa[x]);
}
void merge(int x,int y){
	if(x!=y)fa[y]=x,sz[x]+=sz[y];
}
bool check(){
	REP(i,1,n)fa[i]=i,sz[i]=1;
	REP(i,1,n)merge(find_fa(i),find_fa(p[i]));
	REP(i,1,n)if((fa[i]==i)&&(sz[i]&1))return 0;
	return 1;
}
void dfs(int step){
	if(step>n){ans+=check();return;}
	if(p[step])dfs(step+1);
	REP(i,1,n)if(!vis[i])vis[p[step]=i]=1,dfs(step+1),vis[p[step]]=0,p[step]=0;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
#endif
	n=read();
	if(n&1)return puts("0"),0;
	REP(i,1,n)vis[p[i]=read()]=1;
	if(n<=10){
		dfs(1);
		write(ans,'\n');
	}else{
		static int f[maxn];
		n>>=1,f[1]=1;
		REP(i,2,n)f[i]=1ll*f[i-1]*(2*i-1)%mod*(2*i-1)%mod;
		write(f[n],'\n');
	}
	return 0;
}
