#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int mo=1e9+7;
const int maxn=110;
int s,t,n,m,C[maxn][maxn];
int f[maxn],ans;
void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}
void init(){
    C[0][0]=1;
    for(int i=1;i<=100;i++){
        C[i][0]=1;
        for(int j=1;j<=i;j++) C[i][j]=(C[i-1][j]+C[i-1][j-1])%mo;
    }
}
int main(){
    freopen("success.in","r",stdin);
    freopen("success.out","w",stdout);
    init();
    read(s); read(t); read(n); read(m);
    f[0]=1;
    for(int i=1;i<=n;i++){
        for(int j=n*t;~j;j--){
            f[j]=0;
            for(int k=1;k<=t&&j-k>=0;k++) Add(f[j],f[j-k]);
        }
    }
    for(int i=1;i<=n*t;i++) Add(f[i],f[i-1]);
    for(int i=m-n;i<=s;i++) Add(ans,1ll*C[i-1][m-n-1]*f[s-i]%mo);
    printf("%d\n",ans);
    return 0;
}
