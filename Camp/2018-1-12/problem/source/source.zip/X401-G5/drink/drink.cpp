#include<bits/stdc++.h>
using namespace std;
const int daxiao=40;
int n,a[1005000];
int pre[1000050],next[1000050],b[1000050];
double dp[1000],ans,gong[1000500];
char ch;
bool mmp(int i,int j){
	if (a[i]!=a[j])
	  return a[i]<a[j];
	return i<j;
}
inline int read(){
	int k=0;ch=getchar();
	while ((ch>'9')||(ch<'0')) ch=getchar();
	while ((ch<='9')&&(ch>='0'))
	{
		k=k*10+ch-'0';
		ch=getchar();
	}
	return k;
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);	
	dp[0]=1;
	for (int i=1;i<=daxiao*2;++i)
	  dp[i]=dp[i-1]/2;
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
		a[i]=read();
	for (int i=1;i<=n;++i)
	  next[i]=i+1;
	for (int i=1;i<=n;++i)
	  pre[i]=i-1;
	pre[n+1]=n;
	next[0]=1;
	for (int i=1;i<=n;++i)
	  b[i]=i;
	sort(b+1,b+1+n,mmp);
	for (int i=1;i<=n;++i)
	{
		int now=b[i];
		for (int k=1;k<=daxiao;++k)
		{
			if (now>n) break;
			gong[b[i]]+=(next[now]-now)*dp[k]*a[b[i]];
			now=next[now];
		}
		int k=next[b[i]];
		next[pre[b[i]]]=next[b[i]];
		pre[k]=pre[b[i]];
	}
	for (int i=1;i<=n;i++)
	  next[i]=i+1;
	for (int i=1;i<=n;i++)
	  pre[i]=i-1;
	pre[n+1]=n;
	next[0]=1;
	for (int i=1;i<=n;++i)
	{
		int now=b[i];
		for (int k=1;k<=daxiao;++k)
		{
			if (now==0) break;
			ans+=(now-pre[now])*gong[b[i]]*dp[k-1];
			now=pre[now];
		}
		int k=next[b[i]];
		next[pre[b[i]]]=next[b[i]];
		pre[k]=pre[b[i]];
	}
	printf("%.10lf",ans/n/n);
}

