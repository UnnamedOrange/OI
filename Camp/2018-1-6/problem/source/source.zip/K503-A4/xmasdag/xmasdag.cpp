#include <bits/stdc++.h>
using namespace std;

struct Edge{
	int v, next;
};

const int MAXN =  100000, MAXM = 200000, MOD = 998244353;
int e_ptr, N, M, K, head[MAXN+10], opt[MAXN+10]; 
Edge E[(MAXM<<1)+10];

void AddEdge(int u, int v) {
	E[++e_ptr] = (Edge) { v, head[u] } ; head[u] = e_ptr;
}

template<typename T>
inline void readint(T& x) {
	T f=1, r=0; char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	x=f*r;
}

void Init() {
	int u, v;
	readint(N); readint(M); readint(K);
	for(int i=1; i<=M; i++) {
		readint(u); readint(v);
		AddEdge(u, v);
	}
}

void DP(int u) {
	for(int j=head[u]; j; j=E[j].next) {
		int v=E[j].v;
		opt[v] = (opt[u] + opt[v]) % MOD;
	}
}

void DPWork() {
	opt[1] = 0;
	DP(1);
	for(int i=1; i<=N; i++) printf("%d\n", opt[i]);
}

int fastpow(int a, int x) {
	int ret = 1;
	while(x) {
		if(x&1) ret = (1ll*ret*a) % MOD;
		x>>=1; a = (1ll*a*a) % MOD;
	}
	return ret;
}

int Dst;
void Dfs(int u, int l) {
	if(u==Dst) {
		opt[u] = (opt[u] + fastpow(l, K)) % MOD;
		return;
	} else {
		for(int j=head[u]; j; j=E[j].next) {
			int v=E[j].v;
			Dfs(v, l+1);
		}
	}
}
void BruteWork() {
	for(Dst=1; Dst<=N; Dst++)
		Dfs(1, 0);
	for(int i=1; i<=N; i++) printf("%d\n", opt[i]);
}

int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	Init();
	if( K == 1 ) DPWork();
	else BruteWork();
}
