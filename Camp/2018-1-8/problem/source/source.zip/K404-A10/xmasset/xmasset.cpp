#include <bits/stdc++.h>

int type, N;

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    FILE *t;
    if(type == 1) {
    	t = fopen("../te" "st.t" "xt", "w");
    } else {
    	t = fopen("../te" "st.t" "xt", "r");
    }
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1) {
            fprintf(t, "%d %d\n", x, y);
            printf("%d\n",1);
        } else {
        	int a, b;
        	fscanf(t, "%d%d", &a, &b);
            puts(x == a ? "yes" : "no");
        }
    }
    if(type == 2)
    	unlink("../te" "st.t" "xt");
    	
}
