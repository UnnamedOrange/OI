#include<cstring>
#include<cstdio>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int N=510,M=500010;
const int INF=1e9;
struct node{
	int to,next,c;
};node edge[M*2];
int graph[N],tot,head[N];
int sum,S,T;
int c[N],f[N][N],w[N][2];int sgn[N];
int n;
int d[N],q[N],h,t;
int ans;
void addedge(int i,int x,int y,int c){
	edge[i].to=y;edge[i].next=graph[x];graph[x]=i;edge[i].c=c;
}
void add(int x,int y,int c){
	tot++;addedge(tot,x,y,c);
	tot++;addedge(tot,y,x,0);
}

bool bfs(){
	int i,x,y;
	rep(i,1,sum)	d[i]=-1;
	d[S]=0;h=t=0;q[++t]=S;
	while(h<t){
		x=q[++h];
		for(i=graph[x];i;i=edge[i].next){
			y=edge[i].to;
			if(edge[i].c&&d[y]==-1){
				d[y]=d[x]+1;q[++t]=y;
			}
		}
	}
	return d[T]!=-1;
}

int find(int x,int low){
	if(x==T||!low)	return low;
	int i,y;int now,totflow=0;
	for(i=head[x];i;i=edge[i].next){
		y=edge[i].to;head[x]=i;
		if(d[y]==d[x]+1&&edge[i].c){
			now=find(y,min(low,edge[i].c));
			low-=now;totflow+=now;
			edge[i].c-=now;edge[i^1].c+=now;
			if(!low)	return totflow;
		}
	}
	if(low)	d[x]=-1;
	return totflow;
}

void dinic(){
	int i;
	while(bfs()){
		rep(i,1,sum)	head[i]=graph[i];
		ans+=find(S,INF);
	}
}

int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int cas,m1,m2,W;
	int x,y,z,a1,a2,a3,a4,a5,a6;int i,j;
	scanf("%d",&cas);
	while(cas--){
		scanf("%d%d%d%d",&n,&W,&m1,&m2);
		sum=n;S=++sum;T=++sum;
		memset(f,0,sizeof(f));
		memset(sgn,0,sizeof(sgn));
		memset(w,0,sizeof(w));
		tot=1;memset(graph,0,sizeof(graph));
		ans=0;
		rep(i,1,n)	c[i]=1;
		while(m1--){
			scanf("%d%d%d",&x,&y,&z);
			scanf("%d%d%d%d%d%d",&a1,&a2,&a3,&a4,&a5,&a6);
			f[x][y]+=2*a1;f[y][x]+=2*a1;
			f[y][z]+=2*a2;f[z][y]+=2*a2;
			f[x][z]+=2*a3;f[z][x]+=2*a3;
			c[x]+=a4;c[y]-=a4;
			c[y]+=a5;c[z]-=a5;
			c[z]+=a6;c[x]-=a6;
		}
		while(m2--){
			scanf("%d%d%d",&x,&y,&z);
			if(z==0)	f[y][x]=INF;
			if(z==1)	f[y][x]=INF,f[x][y]=INF;
			if(z==2)	sgn[x]=1,sgn[y]=2;
		}
		rep(i,1,n){
			if(c[i]>=0){
				ans-=c[i];
				w[i][0]=2*c[i];
			}
			else{
				ans+=c[i];
				w[i][1]=2*(-c[i]);
			}
			if(sgn[i]){
				if(sgn[i]==1)	w[i][1]=INF;
				else w[i][0]=INF;
			}
			if(w[i][0])	add(S,i,w[i][0]);
			if(w[i][1])	add(i,T,w[i][1]);
		}
		rep(i,1,n)	rep(j,1,n)	if(f[i][j])	add(i,j,f[i][j]);
		//printf("ans=%d\n",ans);
		/*for(i=2;i<=tot;i+=2){
			printf("%d->%d %d\n",edge[i^1].to,edge[i].to,edge[i].c);
		}*/
		dinic();
		printf("%lld\n",1ll*ans*W);
	}
}
		
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
