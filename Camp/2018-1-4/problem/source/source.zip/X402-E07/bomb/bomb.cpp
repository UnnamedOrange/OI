#include <bits/stdc++.h>
using namespace std;
const int maxn = 2000000 +10;
int read(){
	int x=0,flag=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')flag=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*flag;
}
int n,m,cnte,top,id,cnt,cnte2;
int head[maxn],to[maxn],fr[maxn],nxt[maxn],si[maxn],dfn[maxn],vis[maxn],sum[maxn],tag[maxn],low[maxn];
int head2[maxn],to2[maxn],fr2[maxn],nxt2[maxn],in[maxn];
void AddEdge(int x,int y){ ++cnte;fr[cnte]=x;to[cnte]=y;nxt[cnte]=head[x];head[x]=cnte; }
void AddEdge2(int x,int y){ ++cnte2;fr2[cnte2]=x;to2[cnte2]=y;nxt2[cnte2]=head2[x];head2[x]=cnte2;++in[y];} 
void solve(int x){
	si[++top]=x;
	dfn[x]=low[x]=++id;
	vis[x]=1;
    for(int i=head[x];i;i=nxt[i]){
		if(!dfn[to[i]]){
			solve(to[i]);
			low[x]=min(low[x],low[to[i]]);
		}
		else if(vis[to[i]])
			low[x]=min(low[x],dfn[to[i]]);
	}
    if(dfn[x]==low[x]){
		++cnt;
		while(si[top]!=x){
			tag[si[top--]]=cnt;
			sum[cnt]++;
        }
		tag[si[top--]]=cnt;
		sum[cnt]++; 
    }
}
void Solve(){ for(int i=1;i<=n;i++)if(!dfn[i])solve(i); }
void dfs(int x,int w,int& ans){
	w += sum[x]; ans = max(ans,w); vis[x] = 1;
	for(int i=head2[x];i;i=nxt2[i])dfs(to2[i],w,ans);
}
int main(){
	freopen("bomb.in","r",stdin),freopen("bomb.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		int x,y;x=read();y=read();
		AddEdge(x,y);
	}
	Solve();
	for(int i=1;i<=cnte;i++)if(tag[fr[i]]!=tag[to[i]])AddEdge2(tag[fr[i]],tag[to[i]]);
	for(int i=1;i<=n;i++)printf("%d ",tag[i]);puts("");
	int ans=0;memset(vis,0,sizeof vis);
	for(int i=1;i<=n;i++)if(!in[tag[i]]&&!vis[tag[i]])dfs(tag[i],0,ans);
	printf("%d\n",ans);
	return 0;
}
