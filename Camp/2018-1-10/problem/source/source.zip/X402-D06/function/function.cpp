#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e7+10;
int vis[maxn],prime[maxn],mu[maxn],sigma[maxn],sum[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline void initialize(int n){
	int i,j;
	int cnt=0;
	mu[1]=1;sigma[1]=1;
	for(i=2;i<=n;i++){
		if(!vis[i]){
			prime[++cnt]=i;
			mu[i]=-1;
			sigma[i]=2;
		}
		for(j=1;j<=cnt && i*prime[j]<=n;j++){
			vis[i*prime[j]]=1;
			mu[i*prime[j]]=-mu[i];
			sigma[i*prime[j]]=sigma[i]*2;
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				sigma[i*prime[j]]-=sigma[i/prime[j]];
				break;
			}
		}
	}
	for(i=1;i<=n;i++)sum[i]=sum[i-1]+mu[i];
}
int main(){
	int i,j,k,m,n,T;
#ifndef ONLINE_JUDGE
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
#endif
	T=read();
	initialize(maxn-5);
	while(T--){
		n=read();
		int ans=0;
		for(i=1;i<=n;i++)ans+=sum[n/i]*sigma[i]*sigma[i];
		printf("%d\n",ans);
	}
	return 0;
}

