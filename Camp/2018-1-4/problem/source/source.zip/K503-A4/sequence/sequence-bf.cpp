//brute 16pts
#include <bits/stdc++.h>
#define rint register int
using namespace std;
typedef unsigned long long ULL;
const int MAXN = 25, INF = 0x3f3f3f3f;
int T, N, Ans, A[MAXN+1];
set<ULL> vis;
inline int readint() {
	int f=1,r=0; char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	return f*r;
}

inline void flip(int L, int R) {
	for(rint i=L; i < L + ((R-L+1)>>1); i++)
		swap( A[i], A[R+L-i] );
}

inline ULL getState() {
	ULL ret = 0;
	for(int i=1; i<=N; i++) ret = ret * 131 + A[i];
	return ret;
}

void dfs(int u) {
	for(int i=1; i<=N; i++) printf("%d ",A[i]);
	putchar(10);
	system("pause");
	bool ok = true; ULL S = getState();
	if( u > Ans || vis.count(S)) return;
	vis.insert(S);
	for(int i=1; i<=N-1; i++)
		if(A[i+1] != A[i] + 1) {
			ok = false; break;
		}
	if(ok) {
		Ans = min(Ans, u);
		return;
	} else {
		for(int i=N; i>=1; i--) {
			flip(1, i);
			dfs(u+1);
			flip(1, i);
		}
	}
	vis.erase(S);
}

int main() {
#ifndef DEBUG
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
#endif
	T = readint();
	while(T--) {
		N = readint(); Ans = INF; vis.clear();
		for(int i=1; i<=N; i++) A[i] = readint();
		dfs(1); printf("%d\n", Ans-1);
	}
	return 0;
}
