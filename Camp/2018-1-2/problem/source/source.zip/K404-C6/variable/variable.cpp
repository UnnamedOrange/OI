#include <queue>
#include <cstdio>
#include <iostream>
#include <cstring>

#define MP make_pair
#define PB push_back
#define FO(x) freopen(#x".in", "r", stdin), freopen(#x".out", "w", stdout)

using namespace std;
typedef long long LL;
typedef unsigned long long u64;

template <typename T> inline bool cmin(T & a, const T & b) { return a > b ? a = b, 1 : 0;}
template <typename T> inline bool cmax(T & a, const T & b) { return a < b ? a = b, 1 : 0;}
int read() {
	int x = 0, f = 1;char ch;
	for(ch = getchar(); !isdigit(ch); ch = getchar())
		if(ch == '-') f = -1;
	for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	return x * f;
}

const int MaxN = 1234, inf = 1e9;

int n, W, p, q, s[MaxN], w[MaxN], x[MaxN], y[MaxN], z[MaxN], a[MaxN], b[MaxN], c[MaxN], d[MaxN], e[MaxN], f[MaxN];

const int MaxE = MaxN * 30;

namespace dinic {
	struct edge {
		int to, nxt, cap;
	}e[MaxE]; int cnt = 1, lst[MaxN], s, t;
	
	void clear() {
		cnt = 1;
		memset(lst, 0, sizeof(lst));
	}
	void addEdge(int a, int b, int c) {
		e[++cnt] = (edge) {b, lst[a], c}; lst[a] = cnt;
		e[++cnt] = (edge) {a, lst[b], 0}; lst[b] = cnt;
	}
	
	queue<int> q; int h[MaxN];
	int bfs(int s, int t) {
		memset(h, -1, sizeof(h));
		q.push(s); h[s] = 0;
		while(!q.empty()) {
			int c = q.front(); q.pop();
			for(int i = lst[c], b; b = e[i].to, i; i = e[i].nxt) 
				if(! ~ h[b] && e[i].cap) 
					h[b] = h[c] + 1, q.push(b);
		}
		return ~h[t];
	}
	
	int dfs(int x, int t, int f) {
		if(x == t) return f;
		int used = 0, w;
		for(int i = lst[x], b; b = e[i].to, i; i = e[i].nxt) {
			if(h[b] == h[x] + 1 && e[i].cap) {
				int w = dfs(b, t, min(e[i].cap, f - used));
				used += w; e[i].cap -= w; e[i ^ 1].cap += w;
				if(used == f) return f;
			}
		}
		if(!used) h[x] = -1; return used;
	}
	
	int dinic(int s, int t) {
		int ans = 0;
		while(bfs(s, t)) {
			ans += dfs(s, t, inf);
		}
		return ans;
	}
}

using dinic :: addEdge;
int main() {
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	int i, j;
	int T = read();
	while(T--) {
		dinic :: clear();
		n = read(); W = read(); p = read(); q = read();
		for(i = 1; i <= n; i++) s[i] = 1;
		for(i = 1; i <= p; i++) {
			x[i] = read(); y[i] = read(); z[i] = read(); a[i] = read(); b[i] = read(); c[i] = read(); d[i] = read(); e[i] = read(); f[i] = read();
			addEdge(y[i], x[i], 4 * a[i]);
			addEdge(z[i], y[i], 4 * b[i]);
			addEdge(x[i], z[i], 4 * c[i]);
			s[x[i]] += -a[i] + c[i] + d[i] - f[i];
			s[y[i]] += -b[i] + a[i] + e[i] - d[i];
			s[z[i]] += -c[i] + b[i] + f[i] - e[i];
		}
		int ans = 0;
		for(i = 1; i <= n; i++) {
			ans -= (s[i] > 0 ? s[i] : -s[i]);
			if(s[i] < 0)	
				addEdge(i, n + 1, -2 * s[i]);
			else
				addEdge(0, i, 2 * s[i]);
		}
		for(i = 1; i <= q; i++) {
			int x = read(), y = read(), r = read();
			if(r == 2) {
				addEdge(0, x, inf);
				addEdge(y, n + 1, inf);
			}else {
				addEdge(y, x, inf);
				if(r) addEdge(x, y, inf);
			}
		}
		int z = dinic :: dinic(0, n + 1);
		cout << (LL) (ans + z) * W << endl; 
	} 
	return 0;
}
