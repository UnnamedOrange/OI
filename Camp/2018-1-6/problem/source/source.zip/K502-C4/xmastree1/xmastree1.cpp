#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

int n,q,t,a[100005],c[100005],code[100005],u,v,L,R,k,cnt;
int head[100005],top,l[100005],r[100005],ans,lastans;
bool vis[100005];

struct edge
{
	int v,next;
} s[200005];

void dfs(int now,int fa)
{
	code[now]=++cnt;
	c[code[now]]=a[now];
	l[now]=code[now];
	for(int i=head[now];i!=0;i=s[i].next)
	{
		int to=s[i].v;
		if(to==fa) continue;
		dfs(to,now);
	}
	r[now]=cnt;
}

void query(int l,int r)
{
	memset(vis,0,sizeof vis); ans=0;
	for(int i=l;i<=r;i++)
	{
		if(c[i]>=L&&c[i]<=R&&vis[c[i]]==0)
		{
			vis[c[i]]=1;
			ans++;
		}
	}
	printf("%d\n",ans);
	lastans=ans;
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d%d",&u,&v);
		s[++top].v=v; s[top].next=head[u]; head[u]=top;
		s[++top].v=u; s[top].next=head[v]; head[v]=top;
	}
	
	dfs(1,0);
	
	for(int i=1;i<=q;i++)
	{
		scanf("%d",&u);
		if(u==1)
		{
			scanf("%d%d%d",&u,&L,&R);
			if(t==1)
			{
				u=u^lastans;
				L=L^lastans;
				R=R^lastans;
			}
			query(l[u],r[u]);
		}
		else
		{
			scanf("%d%d",&u,&k);
			if(t==1)
			{
				u=u^lastans;
				k=k^lastans;
			}
			c[code[u]]=k;
		}
	}
	return 0;
}
