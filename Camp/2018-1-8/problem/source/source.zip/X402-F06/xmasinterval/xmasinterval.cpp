#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int mod=1000000009,maxn=5e5+10;
inline void add(int &x,int y){
	x+=y;
	if(x>=mod) x-=mod;
}
struct point{
	int l,r;
	bool operator <(const point &rhs) const{
		return r<rhs.r || (r==rhs.r && l<rhs.l);
	}
}a[maxn];
//struct Segment_tree{
//	int sum[maxn<<2];
//	void build_tree(){
//		memset(sum,0,sizeof(sum));
//	}
//	void push_up(int x){
//		sum[x]=sum[x<<1]+sum[x<<1|1];
//		if(sum[x]>=mod) sum[x]-=mod;
//	}
//	int query(int x,int L,int R,int ql,int qr){
//		if(ql<=L && R<=qr) return sum[x];
//		int Mid=(L+R)>>1,num=0;
//		if(ql<=Mid) num=query(x<<1,L,Mid,ql,qr);
//		if(qr>Mid) add(num,query(x<<1|1,Mid+1,R,ql,qr));
//		return num;
//	}
//	void update(int x,int L,int R,int q,int v){
//		if(L==R){
//			add(sum[x],v);
//			return;
//		}
//		int Mid=(L+R)>>1;
//		if(q<=Mid) update(x<<1,L,Mid,q,v);
//		else update(x<<1|1,Mid+1,R,q,v);
//		push_up(x);
//	}
//}Seg;
int n,m;
struct szsz{
	int c[maxn];
	inline int lowbit(int x){
		return x&(-x);
	}
	void build(){
		memset(c,0,sizeof(c));
	}
	int sum(int x){
		int num=0;
		while(x){
			add(num,c[x]);
			x-=lowbit(x);
		}
		return num;
	}
	void update(int x,int y){
		while(x<=n){
			add(c[x],y);
			x+=lowbit(x);
		}
	}
	int query(int x,int y){
		int u=sum(y)-sum(x-1);
		if(u<0) u+=mod;
		return u;
	}
}bit;
int pos[maxn];
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
#endif
	n=read(),m=read();
	REP(i,1,n) a[i].l=read(),a[i].r=read();
	REP(i,1,m) pos[i]=read();
	sort(pos+1,pos+m+1);
	m=unique(pos+1,pos+m+1)-pos-1;
	REP(i,1,n){
		a[i].l=lower_bound(pos+1,pos+m+1,a[i].l)-pos;
		a[i].r=upper_bound(pos+a[i].l,pos+m+1,a[i].r)-pos-1;
	}
	sort(a+1,a+n+1);
//	Seg.build_tree();
	bit.build();
	REP(i,1,n){
		int x=lower_bound(a+1,a+i+1,(point){0,a[i].l-1})-a;
		int num=0;
	//	if(x<i) num+=bit.query(1,1,n,x,i-1);
		if(x<i) num+=bit.query(x,i-1);
		if(a[i].l-1<=0) add(num,1);
	//	Seg.update(1,1,n,i,num);
		bit.update(i,num);
	}
	int x=lower_bound(a+1,a+n+1,(point){0,m})-a;
	//printf("%d\n",Seg.query(1,1,n,x,n));
	int num=bit.query(x,n);
	REP(i,1,n) if(bit.query(i,i)==0) num=1ll*num*2%mod;
	printf("%d\n",num);
	return 0;
}
