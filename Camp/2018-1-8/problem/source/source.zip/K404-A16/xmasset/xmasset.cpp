#include <cstdio>

using namespace std;

int T, q, h, x, y, n, t, fl, tot;

void work1()
{
	while (T--)
	{
		scanf("%d%d", &x, &y); fl = 0;
		for(int i = 0; i <= 9; ++i)
			if ((x & (1 << i)) && !(y & (1 << i)))
			{
				fl = 1;
				printf("%d\n", i + 1);
				break;
			}
		if (!fl)
		{
			tot = 10;
			for(int i = 0; i <= 9; ++i)
				if (!(y & (1 << i))) ++tot;
			printf("%d\n", tot);
		}
	}
}

void work2()
{
	while (T--)
	{
		scanf("%d%d", &q, &h);
		if (h <= 10)
		{
			if (q & (1 << (h - 1))) puts("yes"); else puts("no");
		}
		else
		{
			tot = 10;
			for(int i = 0; i <= 9; ++i)
				if (!(q & (1 << i))) ++tot;
			if (tot == h) puts("yes"); else puts("no");
		}
	}
}

int main()
{
	scanf("%d%d%d", &t, &n, &T);
	if (t == 1) work1(); else work2();
	return 0;
}
