#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
int n,m,t,kind=0;
int cnt=0,tot=0,top=0;
struct node{
	int next,to;
}a[1000010],s[1000010];
int head[1000010],w[1000010];
int dfn[1000010],low[1000010];
int q[1000010],p[1000010],sz[1000010];
int f[1000010],fr[1000010];
void init(int u,int v){
	a[++cnt].to=v;
	a[cnt].next=head[u];
	head[u]=cnt;
}
void init2(int u,int v){
	s[++tot].to=v;
	s[tot].next=fr[u];
	fr[u]=tot;
}
void dfs(int x){
	t++;
	dfn[x]=low[x]=t;
	q[++top]=x;
	p[x]=1;
	for (int i=head[x];i;i=a[i].next){
		int y=a[i].to;
		if (p[y]) low[x]=low[x]<dfn[y]?low[x]:dfn[y];
		else if (!dfn[y]){
			dfs(y);
			low[x]=low[x]<low[y]?low[x]:low[y];
		}
	}
	if (low[x]==dfn[x]){
		kind++;
		while (q[top]!=x){
			w[q[top]]=kind;
			p[q[top]]=0;
			sz[kind]++;
			top--;
		}
		sz[kind]++;
		w[x]=kind;
		p[x]=0;
		top--; 
	}
}
int solve(int x){
	if (f[x]) return f[x];
	f[x]=sz[x];
	for (int i=fr[x];i;i=s[i].next){
		int y=s[i].to;
		int k=solve(y);
		f[x]=f[x]>sz[x]+k?f[x]:sz[x]+k;
	}	
	return f[x];
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=m;++i){
		int u=read(),v=read();
		init(u,v);
	}
	for (int i=1;i<=n;++i)
		if (!dfn[i]){
			t=top=0;
			dfs(i);
		}
	for (int i=1;i<=n;++i)
		for (int j=head[i];j;j=a[j].next)
			if (w[i]!=w[a[j].to])
				init2(w[i],w[a[j].to]);
	int ans=0;
	for (int i=1;i<=kind;++i){
		int k=solve(i);
		ans=ans>k?ans:k;
	}
	printf("%d\n",ans);
	return 0;
}

