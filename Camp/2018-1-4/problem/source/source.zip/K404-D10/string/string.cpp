//© 2018 Jazengm/Zeng Xiangru, All Rights Reserved
#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int mxn=640, p=998244353;

struct ACAutomataMachine
{
    int m, e[mxn][2], f[mxn], delMask[mxn];
    In ACAutomataMachine(): m(1) {}
    In void add(char* s, int n, int no)
    {
        Rg int u=1;
        for(Rg int i=0; i<n; ++i)
            if(u[e][s[i]])
                u=u[e][s[i]];
            else
                u=u[e][s[i]]=++m;
        delMask[u]|=1<<no;
    }
    In int getN(int u, int c)
    {
        for(;!u[e][c]; u=u[f]);
        Re u[e][c];
    }
    In void build()
    {
        St int q[mxn];
        Rg int t=1;
       f[q[0]=e[0][0]=e[0][1]=1]=0;
        inc(0, h, t)
        {
            Rg int u=q[h];
            inc(0, c, 2)
                if(u[e][c])
                    f[q[t++]=u[e][c]]=getN(u[f], c);
        }
    }
    In int match(char* s, int n)
    {
        Rg int u=1;
        inc(0, i, n)
            u=getN(u, s[i]);
        Re u;
    }
} AC, AC_;

In void upd(int& x, int y){x=(x+y)%p;}

int main()
{
    St int n, m;
    freopen("string.in", "r", stdin);
    freopen("string.out", "w", stdout);
    scanf("%d%d\n", &n, &m);
    if(m<=15)
    {
        St ll a[1<<6], l[1<<6];
        inc(0, i, n)
        {
            St char s[1<<6];
            scanf("%s", s);
            l[i]=strlen(s);
            inc(0, j, l[i])
                a[i]=a[i]<<1|s[j]-'0';
        }
        Rg int ans=0;
        inc(0, _, 1<<m)
        {
            Rg ll b=_, __=~_;
            inc(0, i, m)
                b=b<<1|__&1, __>>=1;
            Rg int k1=0;
            inc(0, i, n)
            {
                Rg int k2=0;
                inc(0, j, 2*m-l[i]+1)
                    if(!((b>>j ^ a[i]) & (1<<l[i])-1)) k2=1;//, printf("%d %d\n", i, j);
                if(!k2) k1=1;
            }
            if(!k1) ++ans;//, printf("%d\n", b);
        }
        printf("%d\n", ans);
    }
    else
    {
        St char str[mxn][mxn], str_[mxn][mxn];
        St int len[mxn];
        inc(0, i, n)
        {
            scanf("%s", str[i]);
            len[i]=strlen(str[i]);
            inc(0, j, len[i])
            str_[i][j]=str[i][len[i]-j]-='0';
            AC.add(str[i], len[i], i);
            AC_.add(str_[i], len[i], i);
        }
        AC.build(), AC_.build();
        St int delMask[mxn][mxn];
        inc(0, i, n)
        {
            inc(0, j, len[i])
                delMask[AC.match(str[i], j)][AC_.match(str_[i], len[i]-j)]|=1<<i;
        }
        St int f[mxn][mxn][1<<6], g[mxn][mxn][1<<6];
//        Rg int** f=a1, g=a2;
        f[1][1][0]=1;
        inc(0, _, m)
        {
            memset(g, 0, sizeof(f));
            inc(1, i, AC.m+1)
                inc(1, j, AC_.m+1)
                    inc(0, mask, 1<<n)
                        if(f[i][j][mask])
                            inc(0, c, 2)
                            {
                                Rg int i_=AC.getN(i, c), j_=AC_.getN(j, !c);
                                upd(g[i_][j_][mask|AC.delMask[i_]|AC_.delMask[j_]], f[i][j][mask]);
                            }
            swap(f, g);
        }
        Rg int ans=0;
        inc(1, i, AC.m+1)
            inc(1, j, AC_.m+1)
                inc(0, mask, 1<<n)
                    if((mask|delMask[i][j])==(1<<n)-1)
                        upd(ans, f[i][j][mask]);
        printf("%d\n", ans);
    }
    Re 0;
}
