#include<cstdio>
#include<iostream>
using namespace std;
int n,m;
const int N=1000010;
struct edg{
	int to,next;
}e[N],g[N];
struct B{
	int x,y;
}E[N];
int h[N],size,head[N];
int st[N],tot,dfn[N],low[N],cnt;
int ans;
int vis[N];
int x,y;
int fa[N];
int num=0; 
int mi[30],bg[N];
int ru[N],dep[N];
bool v[N];
int q[N],ta,he;
void add(int x,int y)
{
	size++;
	e[size].to=y;
	e[size].next=head[x];
	head[x]=size;
}
void addg(int x,int y)
{
	size++;
	g[size].to=y;
	g[size].next=h[x];
	h[x]=size;
}
void dfs(int x)
{
	st[++tot]=x;
	vis[x]=1;
	dfn[x]=++cnt;low[x]=cnt;
	for (int i=head[x];i;i=e[i].next)
	{
		int y=e[i].to;
		if (vis[y]==0) dfs(y),low[x]=min(low[x],low[y]);
		else if (vis[y]==1)low[x]=min(low[x],dfn[y]); 
	}
	if (low[x]==dfn[x])
	{
		num++;
		int siz=0;
		while (st[tot]!=x)
		{
			siz++;
			vis[st[tot]]=2;
			fa[st[tot]]=num;
			tot--;
		}
		siz++;
		vis[st[tot]]=2;
		fa[st[tot]]=num;
		tot--;
		ans=max(ans,siz);
	}

}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		add(x,y);
		E[i].x=x;E[i].y=y;
	}
	for (int i=1;i<=n;i++)
		if (vis[i]==0) dfs(i);
	size=0;
	for (int i=1;i<=m;i++)
		if (fa[E[i].x]!=fa[E[i].y])ru[fa[E[i].y]]++,addg(fa[E[i].x],fa[E[i].y]);
	for (int i=1;i<=num;i++)
		if (ru[i]==0) q[++ta]=i,dep[i]=1;
	while (he<ta)
	{
		int x=q[++he];
		v[x]=1; 
		for (int i=h[x];i;i=g[i].next)
		{
			int y=g[i].to;
			if (!v[y]) dep[y]=dep[x]+1,ans=max(ans,dep[y]),q[++ta]=y;
		}
	}
	printf("%d",ans);
}
