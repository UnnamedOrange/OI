/*
Author: CNYALI_LK
LANG: C++
PROG: subsequence.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
namespace bf{
	int a[1024],b[1024],n,m,k;
	int UNpip(int *a,int n,int s,int sl){
		int it=1;
		for(int i=0;i<sl;++i){
			int k=(s&(1<<i))>>i;
			while(it<=n&&a[it]!=k)++it;
		}
		return it>n;
	}
	int ok(int len){
		int s=1<<len;
		for(int i=0;i<s;++i){
			if(UNpip(a,n,i,len)&&UNpip(b,m,i,len))return 1;
		}
		return 0;
	}
	void main(int q,int w,int e){
		n=q;m=w;k=e;
		for(int i=1;i<=n;++i){
			a[i]=read()-1;
		}
		for(int i=1;i<=m;++i){
			b[i]=read()-1;
		}
		int len=1;	
		while(!ok(len))++len;
		printf("%d\n",len);
	}
}
namespace ja{
	int cnt1[102424],cnt2[102424];
	void main(int n,int m,int k){
		for(int i=1;i<=n;++i)++cnt1[read()];
		for(int i=1;i<=m;++i)++cnt2[read()];
		int ans=0x3f3f3f3f;
		for(int i=1;i<=k;++i)chkmin(ans,max(cnt1[i],cnt2[i])+1);
		printf("%d\n",ans);
	}
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	int n,m,k;
	n=read();
	m=read();
	k=read();
	if(k==2)bf::main(n,m,k);
	else ja::main(n,m,k);
	return 0;
}

