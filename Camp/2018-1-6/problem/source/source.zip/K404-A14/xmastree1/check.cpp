#include<cstdio>
#include<cstring>
#include<algorithm>
#include<string>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
string s1,s2;
int main(){
	int T=10;char ch;
	while(T--){
		system("data.exe");
		system("xmastree1.exe");
		system("bl.exe");
		s1.clear();s2.clear();
		freopen("xmastree1.out","r",stdin);
		while((ch=getchar())!=EOF)	s1+=ch;
		freopen("bl.out","r",stdin);
		while((ch=getchar())!=EOF)	s2+=ch;
		if(s1!=s2){printf("WA!\n");return 0;}
		else printf("AC!\n");
	}
	printf("ALL CORRECT!\n");
	return 0;
}
		
