# include <bits/stdc++.h>
# define 	N 		200100
using namespace std;
bool usel[N],user[N];
char s[N];
int can[N],len,n,last,cnt[1000];
void malachar(){
	int p=0, r=0, l=0;
	for (int i=1; i<=len; i++){
		if (i>r){
			for (can[i]=0; s[i+can[i]+1]==s[i-can[i]-1]; can[i]++);
			p=i; r=i+can[i]; l=i-can[i];
		}
		else {
			int j=p-(i-p);
			if (j-can[j]>l){
				can[i]=can[j];
			}
			else {
				for (can[i]=j-l; s[i+can[i]+1]==s[i-can[i]-1]; can[i]++);
				p=i; r=i+can[i]; l=i-can[i];
			}
		}
	}
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int opt,ca=1;
	for (scanf("%d",&opt); ca<=opt; ca++){
		scanf("%d",&n);
		scanf("\n%s",s+1);
		len=n;
		for (int i=len; i>=1; i--)
			s[i*2]=s[i], s[i*2-1]='#';
		s[len*2+1]='#'; s[0]='*'; s[len*2+2]='&';
		len=len*2+1;
		malachar();
		if (can[n+1]!=n){
			printf("1\n");
			continue;
		}
		last=0;
		memset(cnt,0,sizeof(cnt));
/*		memset(usel,0,sizeof(usel));
		memset(user,0,sizeof(user));
		for (int i=1; i<=n; i++)
			for (int j=max(can[i]+1,last-i+1); i-j>=1; j++)
				usel[i+j]=true,last++;
		last=len; 
		for (int i=len; i>n; i--)
			for (int j=max(can[i]+1,i-last+1); i+j<=len; j++)
				user[i-j]=true,last--;
		bool flag=false;
		for (int i=1; i<=len; i+=2)
			if (usel[i-1]==true&&user[i+1]==true){
					printf("%d\n",2);
					flag=true;
					break;
			}
		if (flag==false)
			printf("-1\n");*/
		bool flag=false;
	/*	for (int i=3; i<=len-2; i+=2){
			if (i<=n+1){
				if (can[i]==0&&can[n+3]/2<n/2-i/2){
					flag=true; break;
				}
			}
			else if (can[i]==0&&can[n-1]/2<n/2-(len-i)/2){
				flag=true; break;
			}
		}*/
		for (int i=6; i<=len; i+=2)
			if (s[i]!=s[i-4]) flag=true;
		if (flag==false){
			printf("-1\n");
			continue;
		}
		flag=false;
		for (int i=2; i<=len; i+=2)
			cnt[s[i]]++;
		for (int i='a'; i<='z'; i++)
			if (cnt[i]>1&&cnt[i]<=n/2){
				flag=true;
			}
		if (flag==true)
			printf("2\n");
			else printf("-1\n");
	}
	return 0;
}

