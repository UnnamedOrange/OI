#include<bits/stdc++.h>
#include<vector>
using namespace std;
const int Mod=998224353;
int n,m,k;
long long fpow(long long di,int top) { 
	long long ret=1;
	while(top!=0) { 
		if(top%2) ret*=di,ret%=Mod;
		top/=2;di*=di,di%=Mod;
	} 
	return ret;
} 
struct point { 
	int ap[2100];
};
vector<int>ed[123123];
bool vis[123123];
int ts[123123];
long long ans[210000];
long long totl[110000];
long long totw[110000];
point aa[2100];
int np=1;
stack<int>tt;
void getans(int nw) { 
	for(int i=0;i<2100;++i) { 
		ans[nw]+=1LL*aa[nw].ap[i]*fpow(i,k);
		if(ans[nw]>Mod) ans[nw]%=Mod;
	} 
} 
void tos(int nw) { 
	vis[nw]=1,tt.push(nw);
	for(int i=0;i<ed[nw].size();++i) { 
		int tar=ed[nw][i];
		if(vis[tar]==0) tos(tar);
	} 
	ts[n-np]=nw,np++;
} 
void ks(int nw) { 
	for(int i=0;i<ed[nw].size();++i) { 
		int tar=ed[nw][i];
		for(int j=0;j<2000;++j) { 
			aa[tar].ap[j+1]+=aa[nw].ap[j];
			if(aa[tar].ap[j+1]>Mod) aa[tar].ap[j+1]-=Mod;
		} 
	} 
} 
void ks2(int nw) { 
	for(int i=0;i<ed[nw].size();++i) { 
		int tar=ed[nw][i];
		totl[tar]+=totl[nw]+totw[nw];
		totw[tar]+=totw[nw];
		if(totl[tar]>Mod) totl[tar]%=Mod;
		if(totw[tar]>Mod) totw[tar]%=Mod;
	} 
} 
int main() { 
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	int a,b;
	for(int i=0;i<m;++i) { 
		scanf("%d%d",&a,&b);
		ed[a].push_back(b);
	} 
	for(int i=1;i<=n;++i) if(vis[i]==0) tos(i);
	if(0) { 
		totw[1]=1;
		for(int i=0;i<n;++i) { 
			ks2(ts[i]);
			ans[ts[i]]=totl[ts[i]];
		} 
		for(int i=1;i<=n;++i) printf("%lld\n",ans[i]);
	} 
	else { 
		aa[1].ap[0]=1;
		for(int i=0;i<n;++i) { 
			getans(ts[i]);
			ks(ts[i]);
		} 
	//	for(int i=0;i<n;++i) { 
	//		printf("%d ",ts[i]);
	//	} 
	//	printf("\n");
		for(int i=1;i<=n;++i) printf("%lld\n",ans[i]);
		return 0;
	} 
} 
