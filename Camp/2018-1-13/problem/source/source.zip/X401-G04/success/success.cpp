/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
#define MODP 1000000007
#define MOD(x) ((x)%MODP)
typedef long long LL;
LL s,t,n,m;
void upd(LL &a,LL b)
{
    a=MOD(a+b);
}
LL qpow(LL x,LL n)
{
    if (n==1) return x;
    LL t=qpow(x,n/2);
    t=MOD(t*t);
    if (n%2!=0) t=MOD(t*x);
    return t;
}
LL calcC(LL n,LL m)
{
    LL ans=1;
    for(int i=n+1; i<=m; ++i)
    {
        ans=MOD(ans*i);
    }
    LL ans2=1;
    for(int i=1; i<=m-n; ++i)
    {
        ans2=MOD(ans2*i);
    }
    ans=MOD(ans*qpow(ans2,MODP-2));
    return ans;
}
namespace x1
{
const int maxs=1000000;
LL a[2][maxs+10];
LL main()
{
    int Max=t-1;
    s-=n;
    for(int i=0; i<t; ++i)
    {
        a[1][i]=1;
    }
    for(int i=2; i<=n; ++i)
    {
        int ii=i%2;
        std::memcpy(a[ii],a[ii^1],sizeof(a[ii]));
        for(int j=1; j<t; ++j)
        {
            for(int l=0; l<=Max; ++l)
            {
                upd(a[ii][l+j],a[ii^1][l]);
            }
            ++Max;
        }
    }
    LL ans=0;
    for(int i=0; i<=Max; ++i)
    {
        /*if (i>0)
            upd(a[n%2][i],a[n%2][i-1]);*/
		for(int j=m-n; j<=s-i; ++j)
        {
            LL x=a[n%2][i]*calcC(m-n-1,j-1);
            //cerr<<x<<' ';
            upd(ans,x);
        }
        //cerr<<a[n%2][i]<<' ';
    }
    return ans;
}
}
int main()
{
    freopen("success.in","r",stdin);
#ifndef MDEBUG
    freopen("success.out","w",stdout);
#endif
    cin>>s>>t>>n>>m;
    LL ans=0;
    ans=x1::main();
    cout<<ans<<endl;
    return 0;
}
