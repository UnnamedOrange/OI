#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=100100,mod=int(1e9)+7;

int n,A,B,x[N];

int a[N],tot;
void lalala()
{
	register int i,j;
	for(j=30;~j;j--)
	{
		for(i=tot+1;i<=n;++i)
			if((1<<j)&x[i])
			{
				tot++;
				swap(x[tot],x[i]);
				break;
			}
		for(i=1;i<=n;++i)
			if(i!=tot)
				x[i]^=x[tot];
	}
}

inline int qpow(int x,int y)
{
	int res=1;
	while(y)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return res;
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	
	n=read();A=read();B=read();
	for(int i=1;i<=n;++i)
		x[i]=read()%A;
	lalala();
	cout<<"0 0 ";
	cout<<((qpow(2,n-tot))%mod+mod)%mod<<" "<<((qpow(2,n)-qpow(2,n-tot))%mod+mod)%mod<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

