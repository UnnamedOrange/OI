/*******************************************
	File:permutation.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-10 08:18:10
*******************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 100010
#define mod 998244353
int n,t[N],p[N],ans,vis[N],q[N],l[N];
long long f[N];
void dfs(int x)
{
	if(x==n+1)
	{
		fr(i,1,n)
			q[i]=1;
		fr(i,1,n)
			if(q[i])
			{
				int k=1,th=p[i];
				q[i]=0;
				while(th!=i)
				{
					q[th]=0;
					th=p[th];
					k++;
				}
				if(k&1)
					return;
			}
		ans++;
		return;
	}
	if(t[x])
	{
		p[x]=t[x];
		if(vis[t[x]])
			return;
		vis[t[x]]=1;
		dfs(x+1);
		vis[t[x]]=0;
		return;
	}
	fr(i,1,n)
		if(!vis[i]&&i!=x)
		{
			vis[i]=1;
			p[x]=i;
			dfs(x+1);
			vis[i]=0;
		}
}
int main()
{
	freopen("permutation.out","w",stdout);
	freopen("permutation.in","r",stdin);
	n=read();
	if(n&1)
	{
		printf("0\n");
		return 0;
	}
	fr(i,1,n)
		t[i]=read();
	if(n<=8){
//	if(0){
		dfs(1);
		printf("%d\n",ans);
	}
	else
	{ 
		f[0]=1;
		fr(i,1,n/2)
			f[i+i]=f[i+i-2]*(i+i-1)%mod*(i+i-1)%mod;
		bool flag=1;
		fr(i,1,n)
			if(t[i])
				flag=0;
		if(flag)
		{
			printf("%lld\n",f[n]);
			return 0;
		}
		fr(i,1,n)
			l[t[i]]=i;
//		fr(i,1,n)
//			printf("%d%c",l[i],i==n?'\n':' ');
		int x=n,y=0;
		fr(i,1,n)
			if(!t[i]&&l[i]&&!vis[i])
			{
				vis[i]=1;
				int k=l[i],num=1;
				while(l[k])
				{
					vis[k]=1;
					k=l[k];
					num++;
				}
				x-=num-(num&1);
				y+=(num&1);
			}
//		printf("%d %d\n",x,y);
		fr(i,1,n)
			if(t[i]&&l[i]&&!vis[i])
			{
				vis[i]=1;
				int k=l[i],num=1;
				while(l[k]&&!vis[k])
				{
					vis[k]=1;
					k=l[k];
					num++;
				}
				if(num&1)
				{
					printf("0\n");
					return 0;
				}
				x-=num;
			}
//		printf("%d %d\n",x,y);
		long long ans=1;
		while(y)
		{
			ans=ans*(x-y)%mod;
			x-=2;
			y--;
		}
		printf("%lld\n",ans*f[x]%mod);
	}
	return 0;
}