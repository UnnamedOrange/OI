#include<stdio.h>
#include<algorithm>
using namespace std;
#define Maxn 30
#define inf (1 << 30)
#define rep(i, a, b) for(int i = (a), i##_end_ = (b);i <= i##_end_;++i)
int n, a[Maxn], ans = inf, lz, flag;
int check(){
	rep(i, 1, n) 
		if(a[i] ^ i) return 0;
	return flag = 1;
}
int future() {
	int res = 0;
	rep(i, 1, n - 1) 
		res += (abs(a[i + 1] - a[i]) > 1);
	return res;
}
int dfs(int dep,int step) {
	if(flag) return 1;
	if(step > dep) return 0;
	if(step + future() > dep) return 0;
	if(check()) return 1;
	rep(i, 2, n) {
		reverse(a + 1, a + i + 1);
		if(dfs(dep, step + 1)) return 1;
		reverse(a + 1, a + i + 1);
	}
	return 0;
}
int main(){
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--) {
		scanf("%d", &n); flag = 0;
		rep(i, 1, n) scanf("%d", &a[i]);
		if(check()) {
			printf("0\n");
			continue;
		}
		int limit = 0;
		while(!dfs(limit, 0)) ++limit;
		printf("%d\n", limit);
	}
	return 0;
}
