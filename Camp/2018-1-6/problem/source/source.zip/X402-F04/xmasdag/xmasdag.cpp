//2018-1-6
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define K (500+5)
#define N (100000+5)

const int P = 998244353;

inline int Mod(int a){return a >= P? a-P: a;}
inline int Mul(int a, int b){return 1ll * a * b % P;}

int Pow(int a, int anum){
	int ret = 1;
	while(anum){
		if(anum & 1) ret = Mul(ret, a);
		a = Mul(a, a); anum >>= 1;
	}
	return ret;
}

int n, m, k, ans[N], C[K][K];
vector<int> G[N];

void Dfsbf(int now, int L){
	ans[now] = Mod(ans[now] + Pow(L, k));
	For(i, 0, G[now].size()-1) Dfsbf(G[now][i], L+1);
}

void Bf(){
	int u, v;
	For(i, 1, m){
		scanf("%d%d", &u, &v); G[u].pb(v);
	}
	Dfsbf(1, 0);
	For(i, 1, n) printf("%d\n", ans[i]);
}

void Init(){
	C[0][0] = 1;
	For(i, 1, k){
		C[i][0] = 1;
		For(j, 1, i) C[i][j] = Mod(C[i-1][j]+C[i-1][j-1]);
	}
}

int num[N][K], tnum[K];
bool vis[N];

inline void Calc(int now){
	For(i, 0, k) tnum[i] = num[now][i];
	Forr(i, k, 0) For(j, 0, i-1)
		tnum[i] = Mod(tnum[i]+Mul(C[i][j], tnum[j]));
}

void Dp(int now){
	if(vis[now]) return;

	int v;
	For(i, 0, G[now].size()-1){
		v = G[now][i]; Dp(v); Calc(v);
		For(j, 0, k) num[now][j] = Mod(num[now][j]+tnum[j]);
	}
	vis[now] = true;
}

void Solve(){
	Init();
	
	int u, v;
	For(i, 1, m){
		scanf("%d%d", &u, &v); G[v].pb(u);
	}

	num[1][0] = 1; vis[1] = true;
	For(i, 1, n) if(!vis[i]) Dp(i);

	For(i, 1, n) printf("%d\n", num[i][k]);
}

int main(){
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &k);

	if(n <= 2000){Bf(); return 0;}
	Solve();

	return 0;
}
