#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=30010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
}
int n,ans,w[N],r[N],p[N],a[N],fa[N];
int bgn[N],nxt[N<<1],to[N<<1],E;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void dfs(int u,int f)
{
	fa[u]=f;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs(v,u);
	}
}
inline void dfs_ans(int now)
{
	if(now==n+1)
	{
		int ret=0;
		For(i,1,n)ret+=w[a[i]]*i;
		chkmax(ans,ret);return;
	}
	For(i,1,n)
	if(!p[i]&&p[fa[i]])
	{
		p[i]=1;
		a[now]=i;
		dfs_ans(now+1);
		p[i]=0;
	}
}
int main()
{
	int x,y;
	file();
	read(n);
	For(i,2,n)
	{
		read(x),read(y);
		add_edge(x,y),add_edge(y,x);
	}
	For(i,1,n)read(w[i]),read(r[i]);
	p[0]=1;
	For(i,1,n)
	if(r[i])
	{
		dfs(i,0);
		dfs_ans(1);
	}
	printf("%d\n",ans);
	return 0;
}
