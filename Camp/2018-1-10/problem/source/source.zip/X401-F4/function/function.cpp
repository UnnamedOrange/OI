#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define maxn 1000010
inline int read(){
	int ret=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ret=ret*10+ch-'0';
		ch=getchar();
	}
	return ret*f;
}
int prime[maxn],mu[maxn],fac[maxn],d[maxn];
bool vis[maxn];
void sieve(){
	int n=1000000,cnt=0;
	mu[1]=1;
	for(int i=2;i<=n;++i){
		if(!vis[i]){
			prime[++cnt]=i;
			mu[i]=-1;
			d[i]=1;
			fac[i]=2;
		}
		for(int j=1;j<=cnt&&i*prime[j]<=n;++j){
			vis[i*prime[j]]=1;
			if(i%prime[j]){
				mu[i*prime[j]]=-mu[i];
				d[i*prime[j]]=1;
				fac[i*prime[j]]=fac[i]<<1;
			}
			else{
				d[i*prime[j]]=d[i]+1;
				fac[i*prime[j]]=fac[i]/(d[i]+1)*(d[i]+2);
				break;
			}
		}
	}
	return ;
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int T=read();
	sieve();
	while(T--){
		int n=read();
		long long ans=0;
		for(int i=1;i<=n;++i){
			for(int d=1;d<=i;++d){
				if(i%d==0)ans+=mu[d]*fac[i/d]*fac[i/d];
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}

