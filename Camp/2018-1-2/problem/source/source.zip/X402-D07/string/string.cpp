#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=100010,INF=1e9+7;
int n;
char s[maxn];
bool check(int L,int R){
    while(L<R){
        if(s[L]!=s[R]) return 0;
        L++; R--;
    }
    return 1;
}
int main(){
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    int _; read(_);
    while(_--){
        read(n); scanf("%s",s+1);
        if(!check(1,n)) puts("1");
        else{
            bool flag=0;
            for(int mid=(n+1)/2;mid>1;mid=(mid+1)/2)
                if(!check(1,mid)&&!check(mid+1,n)){ puts("2"); flag=1; break; }
            if(!flag) puts("-1");
        }
    }
    return 0;
}
