//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
int n,m,k;
int a[4011],b[4011],anxt[4011][4011],bnxt[4011][4011];
int pre[4011];
int dp[4011],ndp[4011];
void upd(int &x,int v){x=x<v?x:v;}
int lst[4011];
int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	for(int i=1;i<=k;i++)
	{
		anxt[n+1][i]=n+1;
		bnxt[m+1][i]=m+1;
	}
	for(int i=n;i>=0;i--)
	{
		for(int j=1;j<=k;j++)anxt[i][j]=anxt[i+1][j];
		if(i<n)anxt[i][a[i+1]]=i+1;
		if(!lst[a[i]])
		{
			lst[a[i]]=i;
		}
	}
	for(int i=n;i>=1;i--)
	{
		for(int j=1;j<i;j++)if(a[i]==a[j])pre[i]=j;
	}
	for(int i=m;i>=0;i--)
	{
		for(int j=1;j<=k;j++)bnxt[i][j]=bnxt[i+1][j];
		if(i<m)bnxt[i][b[i+1]]=i+1;
	}
	memset(dp,-1,sizeof(dp));
	dp[0]=0;
	for(int ti=1;ti<=max(n,m)+1;ti++)
	{
//		for(int i=0;i<=n;i++)cerr<<dp[i]<<" ";cerr<<endl;
		memset(ndp,-1,sizeof(ndp));
		for(int i=1;i<=n;i++)
		{
			if(dp[pre[i]]!=-1)ndp[i]=bnxt[dp[pre[i]]][a[i]];
		}
		for(int i=1;i<=k;i++)
		{
			if(dp[lst[i]]!=-1)ndp[n+1]=max(ndp[n+1],bnxt[dp[lst[i]]][i]);
		}
		for(int i=n;i>=0;i--)ndp[i]=max(ndp[i],ndp[i+1]);
		swap(dp,ndp);
		if(dp[n+1]>=m+1)
		{
			cout<<ti<<endl;
			return 0;
		}
	}
	return 0;
}
