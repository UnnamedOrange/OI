#include<bits/stdc++.h>
using namespace std;

const int maxn=5e5+10,mod=1e9+9;
int n,m,x[maxn],y[maxn],pos[maxn];
int cnt[maxn],ans;

void dfs(int p){
	if(p>n){
		for(int i=1;i<=m;++i)
			if(!cnt[i])
				return;
		++ans;
		return;
	}
	dfs(p+1);
	for(int i=1;i<=m;++i)
		if(x[p]<=pos[i]&&pos[i]<=y[p])
			++cnt[i];
	dfs(p+1);
	for(int i=1;i<=m;++i)
		if(x[p]<=pos[i]&&pos[i]<=y[p])
			--cnt[i];
}

int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.txt","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d%d",&x[i],&y[i]);
	for(int i=1;i<=m;++i)
		scanf("%d",&pos[i]);
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
