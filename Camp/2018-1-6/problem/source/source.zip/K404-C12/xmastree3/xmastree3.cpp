#include <iostream>
#include <utility>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#define mp make_pair
using namespace std; 
set<pair<vector<int>, vector<int> > > ans; 
bool vis[55], ok; 
vector<int> fa, lab; 
int lst[55], to[105], pre[105], tot, n, k; 
int cnt, seq[55]; 
inline void add_edge(int u, int v)
{
	to[tot] = v; 
	pre[tot] = lst[u];
	lst[u] = tot++; 
}
void fill(int u, int f = -1)
{
	seq[cnt++] = u; 
	for (int i = lst[u]; ~i; i = pre[i])
	{
		if (!vis[to[i]] && f != to[i])
			fill(to[i], u); 
	}
}
void dfs(int u, int f, int x)
{
	cnt = 0; 
	fill(u); 
	int v = seq[rand() % cnt];
	fa[v] = f; 
	lab[v] = x; 
	vis[v] = true; 
	for (int i = lst[v]; ~i && ok; i = pre[i])
	{
		if (vis[to[i]])
			continue; 
		if (x == k)
		{
			ok = false; 
			return; 
		}
		dfs(to[i], v, x + rand() % (k - x) + 1); 
	}
}
int main()
{
	freopen("xmastree3.in", "r", stdin); 
	freopen("xmastree3.out", "wt", stdout); 
	memset(lst, -1, sizeof(lst)); 
	srand(19260817); 
	scanf("%d%d", &n, &k); 
	for (int i = 1; i < n; i++)
	{
		int u, v; 
		scanf("%d%d", &u, &v); 
		add_edge(--u, --v); 
		add_edge(v, u); 
	}
	fa.resize(n); 
	lab.resize(n); 
	for (int i = 0; i < 1000000; i++)
	{
		memset(vis, false, sizeof(vis)); 
		ok = true; 
		dfs(rand() % n, 0, rand() % k + 1); 
		if (ok)
			ans.insert(mp(fa, lab)); 
	}
	printf("%d\n", ans.size());
	return 0; 
}

