#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	cout << 0 << endl;
	return 0;
}
