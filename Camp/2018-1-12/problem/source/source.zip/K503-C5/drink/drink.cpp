/*************************************************************************
	> File Name: drink.cpp
	> Author: BuLR
	> Mail: BuLingReactor@163/gmail.com
	> Created Time: Fri 12 Jan 2018 10:31:03 AM DST
 ************************************************************************/

#include <bits/stdc++.h>

using namespace std;

const int DJLFO = 1111111;

ifstream fin;
ofstream fout;
int n;
int w[DJLFO], t[DJLFO];
long double tot = 0;

int main()
{
    ios::sync_with_stdio(false);
    fin.open("drink.in");
    fout.open("drink.out");

    fin >> n;
    for (int i = 1; i <= n; i++)
    {
        fin >> w[i];
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = i; j <= n; j++)
        {
            for (int k = i; k <= j; k++)
            {
                t[k] = w[k];
            }
            sort(t + i, t + j + 1);
            long double tmp = 0;
            for (int k = i; k <= j; k++)
            {
                tmp = (tmp + t[k]) / 2.0;
            }
            tot += tmp;
        }
    }
    fout << fixed << setprecision(12) << tot / double(n * n) << endl;

    fin.close();
    fout.close();
    return 0;
}
