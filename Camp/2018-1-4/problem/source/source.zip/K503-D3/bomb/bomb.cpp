#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define N (int)1e6+100

inline int read(){
	char ch=getchar(); int x=0;
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9')
		x=x*10+ch-'0',ch=getchar();
	return x;
}

struct graph{
    int head[2][N],from[2][N],to[2][N],next[2][N],cnt[2];
    inline void addedge(int k, int x, int y){
        from[k][++cnt[k]]=x; to[k][cnt[k]]=y;
        next[k][cnt[k]]=head[k][x]; head[k][x]=cnt[k];
    }
    int dfn[N],low[N],time,st[N],top,pos[N],size[N],ind[N],sum;
	bool mark[N]; int i[N],q[N],t[N],dep,dis[N];
    inline void dfs(int x0){
    	dep=1,q[1]=x0,t[1]=1;
	    while (dep){
	    	int x=q[dep];
	    	if (t[dep]==1){
				mark[x]=1; dfn[x]=low[x]=++time;
        		st[++top]=x; t[dep]=3;
			}
			if (t[dep]==2){
				low[x]=min(low[x],low[to[0][i[dep]]]);
				t[dep]=3;
			}
			if (t[dep]==3){
				if (i[dep]==0) i[dep]=head[0][x];
		        for (;i[dep];i[dep]=next[0][i[dep]])
		            if (!dfn[to[0][i[dep]]]){
		            	t[dep]=2; t[dep+1]=0;
						q[dep+1]=to[0][i[dep]];
						dep++; break;
					}
		            else if (mark[to[0][i[dep]]])
		                low[x]=min(low[x],dfn[to[0][i[dep]]]);
		        t[dep]++;
			}
			if (t[dep]==4){
		        if (dfn[x]==low[x])
		            for (size[++sum]=0;st[top+1]!=x;mark[st[top--]]=0)
		                pos[st[top]]=sum,size[sum]++;
				t[dep--]=0;
			}
		}
    }
    void tarjan(int n, int m){
        top=time=sum=0;
        for (int i=1;i<=n;i++)
            if (!dfn[i]) dfs(i);
        for (int i=1;i<=m;i++)
            if (pos[from[0][i]]!=pos[to[0][i]])
                addedge(1,pos[from[0][i]],pos[to[0][i]]),
                ind[pos[to[0][i]]]++;
    }
    int bfs(){
    	int l=0,r=-1;
        for (int i=1;i<=sum;i++)
        	if (ind[i]) dis[i]=size[i];
        	else dis[q[++r]=i]=size[i];
        for (;l<=r;l++)
            for (int i=head[1][q[l]];i;i=next[1][i])
                if (ind[to[1][i]]){
                	ind[to[1][i]]--;
                    dis[to[1][i]]=max(dis[to[1][i]],dis[q[l]]+size[to[1][i]]);
                    if (!ind[to[1][i]]) q[++r]=to[1][i];
                }
        int ans=0;
        for (int i=1;i<=sum;i++)
        	ans=max(ans,dis[i]);
        return ans;
    }
}G;

int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int n=read(),m=read();
	for (int i=0;i<m;i++){
		int x=read(),y=read();
		G.addedge(0,x,y);
    }
    G.tarjan(n,m);
    printf("%d",G.bfs());
    fclose(stdin);
    fclose(stdout);
    return 0;
}
