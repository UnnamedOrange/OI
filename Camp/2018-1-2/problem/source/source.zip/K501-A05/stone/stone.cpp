#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int Mod = int(1e9 + 7);
const int maxn = int(1e5);

int n, a, b;

int p[maxn + 5];

inline void input()
{
	n = read<int>(), a = read<int>(), b = read<int>();
	REP(i, 0, n) p[i] = read<int>();
}

int fac[maxn + 5], inv[maxn + 5];

inline int fpm(int x, int y)
{
	int res = 1;
	for(x %= Mod; y; y >>= 1, x = LL(x) * x % Mod) if(y & 1) res = LL(res) * x % Mod;
	return res;
}

inline int C(int _n, int _m)
{
	if(_n < _m) return 0;
	return LL(fac[_n]) * inv[_m] % Mod * inv[_n - _m] % Mod;
}

int cnt[2];

inline void solve()
{
	REP(i, 0, n) cnt[(p[i] / a) & 1]++;

	fac[0] = 1;
	for(int i = 1; i <= n; ++i) fac[i] = LL(fac[i - 1] ) * i % Mod;
	inv[n] = fpm(fac[n], Mod - 2);
	for(int i = n - 1; ~i; --i) inv[i] = LL(i + 1) * inv[i + 1] % Mod;

	int ans0 = 0, ans1 = 0;
	for(int i = 0; i <= cnt[1]; ++i)
		if(i & 1) ans0 = (ans0 + LL(C(cnt[1], i)) * fpm(2, cnt[0]) % Mod) % Mod;
		else ans1 = (ans1 + LL(cnt[1], i) * fpm(2, cnt[0]) % Mod) % Mod;

	printf("%d %d %d %d\n", 0, 0, ans0, ans1);
}

int main()
{
#ifdef fatesky
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
#endif

	input();
	solve();

	return 0;
}

