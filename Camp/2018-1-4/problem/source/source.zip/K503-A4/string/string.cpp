#include <bits/stdc++.h>
using namespace std;

const int MAXL = 1000;

inline int readint() {
	int f=1,r=0; char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	return f*r;
}

inline void readstr(char *str) {
	char c=getchar(); int p=0;
	while(!isalnum(c) && !ispunct(c)) c=getchar();
	while(isalnum(c) || ispunct(c)) {
		str[p++] = c;
		c = getchar();
	}
	str[p]='\0';
}


int N, M, Cnt; char T[MAXL+2], str[10][MAXL+2];
int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	N = readint(); M = readint();
	for(int i=1; i<=N; i++) 
		readstr(str[i]);
	
	for(int i=0; i<(1<<M); i++) {
		for(int j=0; j<M; j++) {
			T[j] = ((i&(1<<j)) ? '1' : '0');
			T[2*M-j-1] = ((i&(1<<j)) ? '0' : '1');
		}
		for(int j=1; j<=N; j++)
			if(!strstr(T, str[j])) goto con;
		Cnt++;
		con: N=N;
	}
	printf("%d", Cnt);
	return 0;
}
