#include<iostream>
#include<cstdio>
#include<cstring>
#define G(x,t) (((x)>>(t-1))&1)
using namespace std;
int n,w,p,q,l[510],r[510][510],ans;
struct node
{
	int a,b,t;
}lim[1010];
bool check(int x)
{
	for(int i=1;i<=q;i++)
	{
		int w1=G(x,lim[i].a),w2=G(x,lim[i].b);
		if(lim[i].t==0&&w1>w2) return 0;
		if(lim[i].t==1&&w1!=w2)return 0;
		if(lim[i].t==2&&w1>=w2)return 0; 
	}
	return 1;
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int ca;
	scanf("%d",&ca);
	while(ca--)
	{
		memset(r,0,sizeof(r));
		memset(l,0,sizeof(l));
		scanf("%d%d%d%d",&n,&w,&p,&q);
		for(int i=1;i<=p;i++)
		{
			int x,y,z,a,b,c,d,e,f;
			scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&e,&f);
			r[y][x]=(r[x][y]+=2*a);
			r[z][y]=(r[y][z]+=2*b);
			r[z][x]=(r[x][z]+=2*c);
			l[x]+=d-f;
			l[y]+=e-d;
			l[z]+=f-e;
		}
		for(int i=1;i<=q;i++)
			scanf("%d%d%d",&lim[i].a,&lim[i].b,&lim[i].t);
		for(int i=1;i<=n;i++) l[i]++;	
//		for(int i=1;i<=n;i++)
//			cout<<l[i]<<' ';
//		cout<<endl;
//		for(int i=1;i<=n;i++,puts(""))
//			for(int j=1;j<=n;j++)
//				cout<<r[i][j]<<' ';	
		ans=1e9;	
		for(int i=0;i<(1<<n);i++)
		{
			if(!check(i)) continue;
			int cal=0;
			for(int j=1;j<=n;j++)
				if(G(i,j)) cal+=l[j];else cal-=l[j];
			for(int j=1;j<=n;j++)
				for(int k=j;k<=n;k++)
					if(G(i,j)^G(i,k)) cal+=r[j][k];
			ans=min(ans,cal);			 	
		}
		printf("%lld\n",(long long)ans*w);
	}
	return 0;
}
/*2
3 1 1 1
1 2 3 1 1 1 1 1 1
1 2 2
3 2 1 1
1 2 3 1 2 3 4 5 6
1 3 2*/
