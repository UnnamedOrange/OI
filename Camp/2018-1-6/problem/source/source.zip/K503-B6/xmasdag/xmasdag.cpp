#include<iostream>
#include<cstdio>
#include<cctype>
#include<algorithm>
#include<cstring>
#include<string>
#include<queue>
#include<map>
#include<vector>
#define size(x) (((int)z[x].size()) - 1)
#define rep(i,x,y) for(register int i = x ;i <= y; ++ i)
using namespace std;
typedef long long ll;
template<typename T>inline void read(T&x)
{
	x = 0;char c;int sign = 1;
	do { c = getchar(); if(c == '-') sign = -1; }while(!isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); }while(isdigit(c));
	x *= sign ;
}
inline void init(string name )
{
	string in = name + ".in",out = name + ".out";
	freopen(in.c_str(),"r",stdin);
	freopen(out.c_str(),"w",stdout);
}

const int N = 1e5+500,p = 998244353;
int n,m,k,in[N]; ll ans[N],pre[N];
int nxt[N<<1],to[N<<1],head[N],tot;
queue<int> q;
vector<pair<int,int> > z[N];
map<pair<int,int> ,int> mp;

inline void add(int x,int y) { nxt[tot] = head[x]; to[tot] = y; head[x] = tot++; }

inline void toposort()
{
	z[1].push_back(make_pair(0,1));
	q.push(1);
	
	while(!q.empty())
	{
		int x = q.front();q.pop();
		rep(i,0,size(x))
			ans[x] = (ans[x] + (pre[z[x][i].first] * z[x][i].second % p)) % p;
		
		for(int i = head[x];~i ;i = nxt[i])
		{
			rep(j,0,size(x))
			{
				int oo = mp[make_pair(to[i],z[x][j].first + 1)];
				if(oo)
				{
					z[to[i]][oo].second = ((ll)z[to[i]][oo].second + z[x][j].second) %p;
				}else
				{
					z[to[i]].push_back(make_pair(z[x][j].first + 1,z[x][j].second));
					mp[make_pair(to[i],z[x][j].first + 1)] = size(to[i]);
				}
			}
			
			--in[to[i]];
			if(!in[to[i]]) q.push(to[i]);
		}
	}
	
}

int main()
{
	init("xmasdag");
	memset(head,-1,sizeof head);
	read(n);read(m);read(k);
	rep(i,1,m)
	{
		int u,v;
		read(u);read(v);
		add(u,v); ++in[v];
	}

	rep(i,1,n){
		pre[i] = i;
		rep(j,1,k - 1)
			pre[i] = pre[i] * i % p;
	}
	
	toposort();
	
	rep(i,1,n)
		printf("%lld\n",ans[i]);
	
	return 0;
}
