#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int n,m;
//	const int maxv=10;
//	n=5,m=5;
	n=rand()%5+16,m=rand()%5+16;
	const int maxv=1000000000;
	printf("%d %d\n",n,m);
	int l,r,x;
	for(int i=1;i<=n;i++){
		l=rand()%maxv+1,r=rand()%maxv+1;
		if(l>r) swap(l,r);
		printf("%d %d\n",l,r);
	}
	for(int i=1;i<=m;i++){
		x=rand()%maxv+1;
		printf("%d\n",x);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("xmasinterval.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
