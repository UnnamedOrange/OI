#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cctype>
#include<algorithm>
#define rep(i,x,y) for(register int i = x; i <= y; ++ i)
using namespace std;
typedef long long ll;
template<typename T>inline void read(T&x)
{
	x = 0;char c;int sign = 1;
	do { c = getchar(); if(c == '-') sign = -1; }while(!isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); }while(isdigit(c));
	x *= sign;
}

inline void init(string name)
{
	string in = name + ".in",out = name + ".out";
	freopen(in.c_str(),"r",stdin);
	freopen(out.c_str(),"w",stdout);
}

const int N = 5e5 + 50, P = 1e9 + 7;
int p[N],n,m,ans;
int cnt[N];
struct Str
{
	int l,r;
	
	bool operator < (Str B) const { return l < B.l || l == B.l && r < B.r; }
}a[N];

bool check()
{
	rep(i,1,m)
		if(!cnt[i]) return false;
	return true;
}

void dfs(int now)
{
	if(now == n + 1)
	{
		if(check()) ++ans;
		return;
	}
	
	rep(i,1,m)
		if(a[now].l <= p[i] && a[now].r >= p[i]) ++cnt[i];
	
	dfs(now + 1);
	
	rep(i,1,m)
		if(a[now].l <= p[i] && a[now].r >= p[i]) --cnt[i];
	
	dfs(now + 1);
	
}

int main()
{
	init("xmasomterval");
	read(n);read(m);
	rep(i,1,n)
	{
		read(a[i].l),read(a[i].r);
		if(a[i].l > a[i].r) swap(a[i].l,a[i].r);
	}
	rep(i,1,m) read(p[i]);
	
//	sort(a + 1,a + 1 + n);
//	sort(p + 1,p + 1 + n);
	
	dfs(1);
	
	cout<<ans<<endl;
	
	return 0;
}
