#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar(), bool f = 0 ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) if (c == '-') f = 1 ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
	if (f) x = -x ;
}
const LL maxn = 1e5+5, modd = 1e9+7 ;
LL Qpow ( LL a, LL b ) {
	LL rec = 1 ;
	for ( a %= modd ; b ; b >>= 1, (a *= a) %= modd )
		if (b&1) (rec *= a) %= modd ;
	return rec ;
}
LL n, m, fac[maxn], inv[maxn] ;
void init() {
	LL i ;
	fac[0] = 1 ;
	for ( i = 1 ; i < maxn ; i ++ )
		fac[i] = fac[i - 1]*i%modd ;
	inv[maxn-1] = Qpow(fac[maxn-1], modd-2) ;
	for ( i = maxn-1 ; i ; i -- )
		inv[i - 1] = inv[i]*i%modd ;
}
LL C ( LL a, LL b ) {
	if (a < b) return 0 ;
	LL rec = fac[a] ;
	(rec *= inv[b]) %= modd ;
	(rec *= inv[a - b]) %= modd ;
	return rec ;
}
LL a, b, cnt[3] ;
int main() {
	freopen ( "stone.in", "r", stdin ) ;
	freopen ( "stone.out", "w", stdout ) ;

	init() ;
	Read(n) ; Read(a) ; Read(b) ;
	bool fg = 0 ;
	LL rec1 = 0, rec0 = 0 ;
	if (a < b) {
		swap(a, b) ;
		fg = 1 ;
	}
	LL i, x ;
	for ( i = 1 ; i <= n ; i ++ ) {
		Read(x) ;
		x %= (a+b) ;
		if (x < b) cnt[0] ++ ;
		else if (x < a) cnt[2] ++ ;
		else cnt[1] ++ ;
		printf ( "%lld ", x ) ;
	}
	printf ( "\ncnt [0]=%lld [1]=%lld [2]=%lld\n", cnt[0], cnt[1], cnt[2] ) ;
	a = 0, b = (Qpow(2, n) - Qpow(2, n-cnt[2]) + modd)%modd ;
	x = n-cnt[2] ;
	for ( i = 0 ; i <= cnt[1] ; i ++ )
		if (i&1) {
			(rec1 += C(cnt[1], i)) %= modd ;
		} else {
			(rec0 += C(cnt[1], i)) %= modd ;
		}
	(rec0 *= Qpow(2, cnt[0])) %= modd ;
	(rec1 *= Qpow(2, cnt[0])) %= modd ;
	if (fg) swap(a, b) ;
	printf ( "%lld %lld %lld %lld\n", a, b, rec1, rec0 ) ;
	return 0 ;
}
