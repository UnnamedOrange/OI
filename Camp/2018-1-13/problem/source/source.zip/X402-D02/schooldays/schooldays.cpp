#include<iostream>
#include<cstdio>
#include<cstring>

namespace a
{
	const int N=2010;

	int f[N],g[N];
	int c[N],d[N];
	int n;
	void dp()
	{
		f[0]=1,g[0]=0;
		for(int i=1;i<=n;i++)
		{
			int mc=c[i],md=d[i];

			for(int j=i-1;j>=0;j--)
			{
				if(f[j] && i-j>=mc && i-j<=md)
				{
					if(g[j]+1==g[i])f[i]+=f[j];
					else if(g[j]+1>g[i])f[i]=f[j],g[i]=g[j]+1;
				}
				mc=std::max(mc,c[j]);
				md=std::min(md,d[j]);
			}
		}
	}
	void solve()
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d%d",c+i,d+i);
		dp();
		if(f[n])printf("%d %d\n",g[n],f[n]);
		else printf("-1\n");
	}
}

int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	a::solve();
	return 0;
}
