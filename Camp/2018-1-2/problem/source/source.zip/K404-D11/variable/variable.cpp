#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;

const int maxn = 25;
int n, W, p, q, all, ans = 0x7fffffff;
int x[maxn], y[maxn], z[maxn], a[maxn], b[maxn], c[maxn], d[maxn], e[maxn], f[maxn], xx[maxn], yy[maxn], r[maxn], ini[maxn];

inline void insert(int t)
{
	for(int i = 1; i <= n; ++i)
	{
		if(t & 1 == 1)	ini[i] = W;
		else ini[i] = 0 - W;
		t = t >> 1;
		all += ini[i];
	}
}

inline bool check()
{
	for(int i = 1; i <= q; ++i)
	{
		if(r[i] == 0)
		{
			if(ini[xx[i]] > ini[yy[i]]) return false;
		}
		if(r[i] == 1)
		{
			if(ini[xx[i]] != ini[yy[i]]) return false;
		}
		if(r[i] == 2)
		{
			if(ini[xx[i]] >= ini[yy[i]]) return false;
		}
	}
	return true;
}

int main()
{
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	int v; scanf("%d", &v);
	for(int o = 1; o <= v; ++o)
	{
		scanf("%d%d%d%d", &n, &W, &p, &q);
		for(int i = 1; i <= p; ++i)
			scanf("%d%d%d%d%d%d%d%d%d", &x[i], &y[i], &z[i], &a[i], &b[i], &c[i], &d[i], &e[i], &f[i]);
		for(int i = 1; i <= q; ++i)
			scanf("%d%d%d", &xx[i], &yy[i], &r[i]);
		for(int i = 0; i <= 32770; ++i)
		{
			all = 0;
			insert(i);
			if(!check()) continue;
			for(int i = 1; i <= p; ++i)
			{
				all += a[i] * abs(ini[x[i]] - ini[y[i]]) + b[i] * abs(ini[y[i]] - ini[z[i]]) + c[i] * abs(ini[z[i]] - ini[x[i]]);
				all += d[i] * (ini[x[i]] - ini[y[i]]) + e[i] * (ini[y[i]] - ini[z[i]]) + f[i] * (ini[z[i]] - ini[x[i]]);
			}
			ans = min(ans, all);
		}
		printf("%d\n", ans);
	}
	return 0;
}
