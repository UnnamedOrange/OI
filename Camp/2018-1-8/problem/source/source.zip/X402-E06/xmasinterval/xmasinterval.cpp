#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 500000;
const int mo = 1000000009;

inline bool cmp(const pii& a, const pii& b) { return a.snd < b.snd; }
inline void add(int& a, int b) {
    if((a += b) >= mo)
        a -= mo;
}

int n, m;
pii it[N + 5];
int d[N + 5], dcnt;
int dp[N + 5], x[N + 5];

namespace Seg_T {
#define lc (u << 1)
#define rc (u << 1 | 1)
#define mid ((l + r) >> 1)
    
    const int SZ = N << 2;
    int tag[SZ + 5], sum[SZ + 5];

    void clear() {
        std::fill(tag, tag + SZ, 1);
    }
    void push_up(int u) {
        sum[u] = (sum[lc] + sum[rc]) % mo;
    }
    void push_down(int u) {
        if(tag[u] > 1) {
            tag[lc] = 1ll * tag[lc] * tag[u] % mo;
            sum[lc] = 1ll * sum[lc] * tag[u] % mo;

            tag[rc] = 1ll * tag[rc] * tag[u] % mo;
            sum[rc] = 1ll * sum[rc] * tag[u] % mo;
            tag[u] = 1;
        }
    }

    void modify(int u, int l, int r, int x, int y) {
        if(l == r) { add(sum[u], y); return; }
        push_down(u);

        if(x <= mid) 
            modify(lc, l, mid, x, y);
        else 
            modify(rc, mid+1, r, x, y);

        push_up(u);
    }

    void mult(int u, int l, int r, int x, int y) {
        if(x <= l && r <= y) {
            tag[u] = (tag[u] << 1) % mo;
            sum[u] = (sum[u] << 1) % mo;
            return;
        }
        push_down(u);
        
        if(x <= mid) mult(lc, l, mid, x, y);
        if(mid < y) mult(rc, mid+1, r, x, y);

        push_up(u);
    }

    int query(int u, int l, int r, int x, int y) {
        if(x > r || y < l) return 0;
        if(x <= l && r <= y) { return sum[u]; }
        push_down(u);
        return (query(lc, l, mid, x, y) + query(rc, mid+1, r, x, y)) % mo;
    }
}

void input() {
    read(n), read(m);
    for(int i = 1; i <= n; ++i) read(it[i].fst), read(it[i].snd);
    for(int i = 1; i <= m; ++i) d[dcnt ++] = read(x[i]);

    std::sort(d, d + dcnt);
    dcnt = std::unique(d, d + dcnt) - d;

    for(int i = 1; i <= n; ++i) {
        it[i].fst = std::lower_bound(d, d + dcnt, it[i].fst) - d;
        it[i].snd = std::upper_bound(d, d + dcnt, it[i].snd) - d - 1;
    }
    std::sort(it + 1, it + n + 1, cmp);
}

int main() {
    freopen("xmasinterval.in", "r", stdin);
    freopen("xmasinterval.out", "w", stdout);

    input();

    Seg_T::clear();
    Seg_T::modify(1, 0, dcnt, 0, 1);

    for(int i = 1; i <= n; ++i) {
        dp[i] = Seg_T::query(1, 0, dcnt, it[i].fst, it[i].snd + 1);
        Seg_T::modify(1, 0, dcnt, it[i].snd + 1, dp[i]);
        if(it[i].fst >= 1) Seg_T::mult(1, 0, dcnt, 0, it[i].fst - 1);
    }
    printf("%d\n", Seg_T::query(1, 0, dcnt, dcnt, dcnt));

    return 0;
}
