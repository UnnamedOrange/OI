#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
int n,w,p,q; 
struct node{
	int x,y,z,a,b,c,d,e,f;
}s[1010];
struct fk{
	int x,y,k;
}a[1010];
long long ans=1e18;
int num[1010];
long long Abs(long long x){
	return x>0?x:-x;	
}
void check(){
	for (int i=1;i<=q;++i){
		if (a[i].k==0 && num[a[i].x]>num[a[i].y]) return;
		if (a[i].k==1 && num[a[i].x]!=num[a[i].y]) return;
		if (a[i].k==2 && num[a[i].x]>=num[a[i].y]) return;
	}
	long long tot=0;
	for (int i=1;i<=n;++i)
		tot+=num[i];	
	for (int i=1;i<=p;++i){
		long long t1=num[s[i].x]-num[s[i].y];
		long long t2=num[s[i].y]-num[s[i].z];
		long long t3=num[s[i].z]-num[s[i].x];	
		tot+=t1*s[i].d+t2*s[i].e+t3*s[i].f;
		tot+=Abs(t1)*s[i].a+Abs(t2)*s[i].b+Abs(t3)*s[i].c;
	}
	ans=tot<ans?tot:ans;
}
void solve(int x){
	if (x>n){
		check();
		return;	
	}
	num[x]=w;
	solve(x+1);
	num[x]=-w;
	solve(x+1);
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T=read();
	while (T--){
		n=read();w=read();
		p=read();q=read();
		for (int i=1;i<=p;++i){
			s[i].x=read();s[i].y=read();s[i].z=read();
			s[i].a=read();s[i].b=read();s[i].c=read();
			s[i].d=read();s[i].e=read();s[i].f=read();	
		}
		for (int i=1;i<=q;++i){
			a[i].x=read();a[i].y=read();a[i].k=read();
		}
		solve(1);
		printf("%d\n",ans);
	}
	return 0;
}

