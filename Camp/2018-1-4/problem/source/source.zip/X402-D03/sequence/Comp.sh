while true; do
echo ">>> gen.py"
python3 gen.py
echo ">>> bf"
./bf
echo ">>> sequence"
./sequence
if diff ./bf.out ./sequence.out;
then continue;
else break;
fi
done
