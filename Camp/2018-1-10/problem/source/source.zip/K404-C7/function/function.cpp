#include <bits/stdc++.h>
using namespace std;

int p[100010];
int u[1000010];
int o[1000010];


int main() {
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;

	}
}
