#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<map>
#include<set>
#include<iomanip>
using namespace std;
typedef long long ll;
inline int read()
{
    int X=0,w=0; char ch=0;
    while(!isdigit(ch)) w|=ch=='-',ch=getchar();
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}
const int N=1e5+10;
int t,n,pr,ans;
char a[N];
map<char,int>m;
bool ju;
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	register int i;
	t=read();
	while(t--)
	{
		n=read();ju=0;ans=0;pr=0;
		m.clear();
		for(i=1;i<=n;++i)
		{
			a[i]=getchar();
			if(m[a[i]]==0)
			{
				m[a[i]]=++pr;
			}
		}
		for(i=1;i<=n/2;++i)
		{
			if(a[i]!=a[n-i+1])
			{
				ju=1;
				break;
			}
		}
		if(ju==1)
		{
			puts("1");
			continue;
		}
		if(pr>=3)
		{
			puts("2");
			continue;
		}
		if(pr==1)
		{
			puts("-1");
			continue;
		}
		for(i=1;i<=n-1;++i)
		{
			if(a[i]==a[i+1])
			{
				ju=1;
				break;
			}
		}
		if(ju==1)
		{
			puts("2");
			continue;
		}
		puts("-1");
	}
}