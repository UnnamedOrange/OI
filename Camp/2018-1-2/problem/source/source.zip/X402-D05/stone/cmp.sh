a=0
while true;do
	echo "Case $a :"
	a=`expr $a + 1`
	./gen
	./baoli
	./stone
	if diff baoli.out stone.out;then
		printf "Accepted!\n"
	else
		printf "Wrong Answer!\n"
		break
	fi
done
