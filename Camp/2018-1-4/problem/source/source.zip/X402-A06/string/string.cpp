#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 1010;

int n, m, len[maxn], Max;

char s[10][maxn], ss[maxn];

void Get(){
	n = read(), m = read();
	For(i, 1, n){
		scanf("%s", s[i]);
		len[i] = strlen(s[i]);
		Max = max(Max, len[i]);
	}
}

void solve_bf(){
	int tmp = (1 << m) - 1, Ans = 0;
	For(i, 0, tmp){
		bool flag = 0;
		For(j, 0, m - 1){
			if(i & (1 << j)){
				ss[j] = '1';
				ss[2 * m - j - 1] = '0';
			}
			else{
				ss[j] = '0';
				ss[2 * m - j - 1] = '1';
			}
		}

		For(j, 1, n){
			char *p = strstr(ss, s[j]); 
			if(p == NULL) {flag = 1; break;}
		}

		if(!flag) ++ Ans;
	}

	printf("%d\n", Ans);
}

const int mod = 1e9+7;

int ksm(int x,int k){
	int s = 1;
	while(k){
		if(k&1) s = 1ll * s * x % mod;
		x = 1ll * x * x % mod;
		k >>= 1;
	}

	return s;
}

void greedy(){
	printf("%d\n", ksm(2, m));
}

int main(){
	
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);

	Get();
	if(m <= 15) solve_bf();
	else greedy();

	return 0;
}
