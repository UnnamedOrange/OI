#include <bits/stdc++.h>
using namespace std;

string str[7];

string gen(int n, int x) {
	char buf[n + 1];
	for (int i = 0; i < n; ++i) {
		buf[i] = (x & (1 << i)) ? '1' : '0';
	}
	buf[n] = 0;
	return buf;
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 0; i < n; ++i) {
		cin >> str[i];
	}
	int mask = (1 << m) - 1;
	int ans = 0;
	for (int i = 0; i <= mask; ++i) {
		string s = gen(m, i);
		string t = gen(m, mask ^ i);
		reverse(t.begin(), t.end());
		s += t;
		bool ok = true;
		for (int j = 0; j < n; ++j) {
			if (s.find(str[j]) == string::npos) {
				ok = false;
				break;
			}
		}
		ans += ok;
	}
	cout << ans;
}
