#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=30;

int n;
bool ok=0;

int a[N];

void dfs(int remain,int now)
{
	if(ok) return ;
	while(a[now]==now && now>0) now--;
	if(!now){ok=1;return ;}
	if(!remain) return ;
	int f(0);
	for(int i=2;i<=now;++i)
		if(abs(a[i]-a[i-1])>1)
			f++;
	if(f>remain) return ;
	for(int i=2;i<=now;++i)
	{
		for(int j=1;j<=(i>>1);++j) swap(a[j],a[i-j+1]);
		dfs(remain-1,now);
		for(int j=1;j<=(i>>1);++j) swap(a[j],a[i-j+1]);
	}
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);

	register int T=read(),i;
	while(T--)
	{
		n=read();
		for(i=1;i<=n;++i) a[i]=read();
		while(a[n]==n && n>0) n--;
		if(!n){puts("0");continue;}
		int ans=2*n-2;
		ok=0;
		for(i=1;i<ans;++i)
		{
			dfs(i,n);
			if(ok) ans=i;
		}
		print(ans);puts("");
	}
	return 0;
}
/*
5
25
2 7 9 1 17 11 12 6 25 23 10 8 21 4 3 20 18 13 15 5 14 19 16 22 24
25
10 6 7 5 15 3 23 14 21 25 17 12 24 18 1 22 2 11 4 19 8 13 9 16 20
25
9 2 4 7 8 18 23 3 5 25 10 20 15 17 16 21 1 19 22 6 24 13 11 12 14
25
16 1 8 23 17 25 12 21 9 19 3 4 20 2 24 13 11 15 18 6 10 5 14 22 7
25
24 20 16 3 1 6 5 15 10 13 22 9 21 18 12 11 14 8 17 2 25 4 23 7 19
*/

