#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=2010,mo=1e9+7;
int n,Max[maxn][12],Min[maxn][12],Log[maxn];
int f[maxn],g[maxn];
struct data{
    int l,r;
} t[maxn];
void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}
void RMQ_init(){
    int num=0,k=2;
    for(int i=1;i<=n;i++){
        if(i==k) ++num,k<<=1;
        Log[i]=num;
    }
    for(int j=1;j<=Log[n];j++)
        for(int i=1;i+(1<<j)-1<=n;i++){
            Max[i][j]=max(Max[i][j-1],Max[i+(1<<(j-1))][j-1]);
            Min[i][j]=min(Min[i][j-1],Min[i+(1<<(j-1))][j-1]);
        }
}
int query(int L,int R,bool op){
    int len=Log[R-L+1];
    if(op) return min(Min[L][len],Min[R-(1<<len)+1][len]);
    else return max(Max[L][len],Max[R-(1<<len)+1][len]);
}
int main(){
    freopen("schooldays.in","r",stdin);
    freopen("schooldays.out","w",stdout);
    read(n);
    for(int i=1;i<=n;i++){
        Max[i][0]=read(t[i].l);
        Min[i][0]=read(t[i].r);
    }
    RMQ_init();
    g[0]=1;
    for(int i=1;i<=n;i++)
        for(int j=0;j<i;j++)
            if(i-j>=query(j+1,i,0)&&i-j<=query(j+1,i,1)){
                if(chkmax(f[i],f[j]+1)) g[i]=g[j];
                else if(f[i]==f[j]+1) Add(g[i],g[j]);
            }
    if(!f[n]) puts("-1");
    else printf("%d %d\n",f[n],g[n]);
    return 0;
}
