#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 1005, INF = 0x3f3f3f3f;
int T, n, W, p, q;
int x[N], y[N], z[N], a[N], b[N], c[N], d[N], e[N], f[N];
int X[N], Y[N], R[N];

bool legal(int m){
	for(int i = 1; i <= q; i++){
		int a = (m >> (X[i] - 1)) & 1, b = (m >> (Y[i] - 1)) & 1;
		if(R[i] == 0 && a > b) return 0;
		if(R[i] == 1 && a != b) return 0;
		if(R[i] == 2 && a >= b) return 0;
	}
	return 1;
}
int calc(int m){
	int ans = 0;
	for(int i = 1; i <= n; i++)
		ans += ((m >> (i - 1)) & 1) ? 1 : -1;
	for(int i = 1; i <= p; i++){
		int wx = ((m >> (x[i] - 1)) & 1) ? 1 : -1;
		int wy = ((m >> (y[i] - 1)) & 1) ? 1 : -1;
		int wz = ((m >> (z[i] - 1)) & 1) ? 1 : -1;
		//if(m == 2) printf("wx = %d wy = %d wz = %d\n", wx, wy, wz);
		ans += a[i] * abs(wx - wy) + b[i] * abs(wy - wz) + c[i] * abs(wz - wx);
		ans += d[i] * (wx - wy) + e[i] * (wy - wz) + f[i] * (wz - wx);
	}
	return ans;
}
void solve1(){
	int ans = INF;
	for(int i = 0; i < (1 << n); i++)
		if(legal(i))
			ans = min(ans, calc(i));
	write((ll) ans * W), enter;
}

int main(){

	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	
	read(T);
	while(T--){
		read(n), read(W), read(p), read(q);
		for(int i = 1; i <= p; i++)
			read(x[i]), read(y[i]), read(z[i]), read(a[i]), read(b[i]), read(c[i]), read(d[i]), read(e[i]), read(f[i]);
		for(int i = 1; i <= q; i++)
			read(X[i]), read(Y[i]), read(R[i]);
		if(n <= 15){
			solve1();
			continue;	
		}
	}
	
	return 0;
}
/*
2
3 1 1 1
1 2 3 1 1 1 1 1 1
1 2 2
3 1 1 1
1 2 3 1 1 1 1 1 1
1 2 2
*/
