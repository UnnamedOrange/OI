//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const lovelive N=12500+10,mod=1e9+7;
void read(lovelive &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
lovelive c[N],d[N],f[N],dp[N];
int main()
{
  freopen("schooldays,in","r",stdin);
  freopen("schooldays.out","w",stdout);
  lovelive n,maxc,mind;
  read(n);
  dp[0]=1;
  for(int i=1;i<=n;i++)
    read(c[i]),read(d[i]);
  for(int i=1;i<=n;i++)
  {
  	maxc=0,mind=1e9;
  	for(int j=i;j>=1;j--)
  	{
  	  maxc=max(maxc,c[j]);
  	  mind=min(mind,d[j]);
  	  if(maxc>(i-j)+1)
  	    continue;
  	  if(mind<(i-j)+1||maxc>mind)
  	  {
  	  	if(f[i]<=0)
  	      f[i]=-1e9;
		break;    
	  }
  	  if(f[i]<f[j-1]+1)
  	  	f[i]=f[j-1]+1,dp[i]=dp[j-1];
  	  else
  	  	if(f[i]==f[j-1]+1)
  	  	  dp[i]+=dp[j-1],dp[i]%=mod;
	}
  }
  if(f[n]>0)
    cout<<f[n]<<" "<<dp[n];
  else
    cout<<"-1";
  return 0;
}
/*
9
1 4
2 5
3 4
1 5
1 1
2 5
3 5
1 3
1 1

2
1 1
2 2
*/
