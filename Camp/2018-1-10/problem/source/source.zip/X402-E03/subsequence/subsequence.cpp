#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 305 ;
int n, m, a[maxn], b[maxn], c[maxn], lim, ans ;
int f[maxn] ;
bool judge ( int k ) {
	int i, j ;
	f[0] = 0 ;
	for ( i = 1 ; i <= n ; i ++ ) {
		f[i] = f[i - 1] ;
		for ( j = f[i - 1]+1 ; j <= k ; j ++ )
			if (a[i] == c[j]) {
				f[i] = j ;
				break ;
			}
	}
	if (f[n] == k) return 0 ;
	f[0] = 0 ;
	for ( i = 1 ; i <= m ; i ++ ) {
		f[i] = f[i - 1] ;
		for ( j = f[i - 1]+1 ; j <= k ; j ++ )
			if (b[i] == c[j]) {
				f[i] = j ;
				break ;
			}
	}
	if (f[m] == k) return 0 ;
	if (k < ans) ans = k ;
	return 1 ;
}
void dfs ( int stp ) {
	if (stp > ans) return ;
	if (stp > 1 && judge(stp-1)) return ;
	for ( int i = 1 ; i <= lim ; i ++ ) {
		c[stp] = i ;
		dfs(stp+1) ;
	}
}
int main() {
	freopen ( "subsequence.in", "r", stdin ) ;
	freopen ( "subsequence.out", "w", stdout ) ;

	int i ;
	Read(n) ; Read(m) ; Read(lim) ;
	for ( i = 1 ; i <= n ; i ++ ) Read(a[i]) ;
	for ( i = 1 ; i <= m ; i ++ ) Read(b[i]) ;
	ans = max(n, m)+1 ;
	dfs(1) ;
	cout << ans << endl ;
	return 0 ;
}
