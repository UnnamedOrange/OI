#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}
const int maxn=4010;

int n,m,k,siz;

int a[maxn],b[maxn],ne[maxn][17],Next[maxn],s[maxn],t[maxn];

void init(int *P,int xx){
	memset(Next,0,sizeof(Next));
	for(int q=1,kk=0;q<xx;++q){
		while(kk&&P[q]!=P[kk]) kk=Next[kk-1];
		if(P[q]==P[kk]) kk++;
		Next[q]=kk;
	}
}

bool kmp(int *T,int *P,int xxx){
	for(int i=0,q=0;i<xxx;++i){
		while(q&&T[i]!=P[q]) q=Next[q-1];
		if(P[q]==T[i]) q++;
		if(q==xxx) return true;
	}
	return false;
}

void dfs(int tur,int len,int num,int tl){
	ne[tur][tl++]=num;
	if(tl>=len) return ;
	dfs(tur,len,num,tl);
}

void mkne(){
	for(int xx=1;xx<=k;xx++)
		for(int i=(xx==1)?1:(1<<n)-1,j;i<=2*(1<<n)-2;){
			for(j=1;j<=n;j++) if((i<=2*(1<<j)-2)&&(i>=2*(1<<(j-1))-2)) break;
			dfs(i,j,xx,0),i++;
	}
}


int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	read(n),read(m),read(k);mkne();
	for(int i=0;i<n;i++) read(a[i]);
	for(int i=0;i<m;i++) read(b[i]);
	for(int i=0,j=0;i<n&&j<m;i++,j++){
		for(int x=1;x<=k;x++){
			bool oks=false,okt=false;
			for(int ii=0,jj=0;ii<=i&&jj<=j;jj++,ii++) s[ii]=a[i],t[jj]=b[j];
			init(s,i+1);if(kmp(ne[i],s,i+1)) oks=1;
			init(t,i+1);if(kmp(ne[i],t,i+1)) okt=1;
//---------------------------------------------------------------------------------------------------------------
	//		for(int ii=0;ii<=i;ii++) printf("%d ",ne[ii]);
	//		puts("");
//---------------------------------------------------------------------------------------------------------------
			if(oks&&okt) break;
			if(oks||okt) break;
			printf("%d\n",min(i+1,j+1));
			return 0;
		}
	}
	printf("%d\n",max(n,m));
	return 0;
}
