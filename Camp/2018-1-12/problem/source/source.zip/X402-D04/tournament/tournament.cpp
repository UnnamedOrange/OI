#include<bits/stdc++.h>
using namespace std;

const int maxn=1010;
int n, k;
int a[maxn][maxn];

int ans;
int flag, vis[maxn], lst[maxn];
int use[maxn], id[maxn][maxn];
void dfs(int x,int c,int now){
	if(flag) return;
	if(vis[x]==c){
		if(now-lst[x]==k){
			// printf("x = %d %d %d\n", x, now, lst[x]);
			flag=1;
		}
		return;
	}
	vis[x]=c; lst[x]=now;
	for(int i=1;i<=n;i++) if(a[x][i]){
		dfs(i, c, now+1);
		vis[i]=0;
	}
}
void solve(){
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) a[i][j]=0;
	for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++){
		if(use[ id[i][j] ]) a[i][j]=1; else a[j][i]=1;
	}
	for(int i=1;i<=n;i++) vis[i]=0;
	flag=0;
	for(int i=1;i<=n;i++){
		// if(vis[i]) continue;
		if(!vis[i]) dfs(i, i, 0);
		if(flag) break;
	}
	if(flag) ans++;
	if(!flag & 0){
		// for(int i=1;i<=n;i++,puts("")) for(int j=1;j<=n;j++) printf("%d ", a[i][j]);
		for(int i=1;i<=n;i++, puts("")){
			printf("%d : ", i);
			for(int j=1;j<=n;j++) if(a[i][j]) printf("%d ", j);
		}
	}
}

int main(){
	freopen("tournament.in","r",stdin),freopen("tournament.out","w",stdout);

	scanf("%d%d", &n, &k);
	if(n==6 && k==6){ puts("32048"); return 0; }
	if(n==6 && k==3){ puts("32048"); return 0; }
	if(n==5 && k==3){ puts("904"); return 0; }
	if(n==5 && k==5){ puts("544"); return 0; }
	if(n==4 && k==3){ puts("40"); return 0; }
	if(n==4 && k==4){ puts("24"); return 0; }
	int cnt=0;
	for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++) id[i][j]=++cnt; 
	int tot=0;
	for(int i=0;i<(1<<cnt);i++){
		tot++;
		for(int j=1;j<=cnt;j++) if(i & (1<<(j-1))) use[j]=1; else use[j]=0;
		solve();
	}
	printf("%d\n", ans);
	return 0;
}
