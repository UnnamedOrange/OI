//© 2018 Jazengm/ZengXiangru, AllRightsReserved

#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

int main()
{
    scanf("%d", &n);
    inc(1, i, n)
    {
        St int u, v;
        scanf("%d%d", &u, &v), aE(u, v), aE(v, u);
    }
    inc(1, i, n+1)
        scanf("%d%d", &u, &v)
    Re 0;
}
