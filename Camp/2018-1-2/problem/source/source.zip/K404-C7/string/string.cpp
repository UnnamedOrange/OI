#include <bits/stdc++.h>
using namespace std;

double Eval(const string& str) {
	int cnt[26];
	memset(cnt, 0, sizeof(cnt));
	for (string::const_iterator it = str.begin(); it != str.end(); ++it) {
		++cnt[*it - 'a'];
	}
	int sum = 0;
	for (int i = 0; i < 26; ++i) {
		sum += cnt[i];
	}
	double avr = sum / 26.0;
	double ret = 1;
	for (int i = 0; i < 26; ++i) {
		ret *= fabs(avr - cnt[i]);
	}
	return ret;
}

bool Test(const string& str) {
	const char* s = str.c_str();
	const char* e = s + str.length() - 1;
	while (s < e) {
		if (*s != *e) {
			return true;
		} else {
			++s;
			--e;
		}
	}
	return false;
}

bool TestSub(const string& str, size_t l, size_t r) {
	const char* s = str.c_str() + l;
	const char* e = str.c_str() + r;
	while (s < e) {
		if (*s != *e) {
			return true;
		} else {
			++s;
			--e;
		}
	}
	return false;
}

int Hash(const string& str) {
	long long value = 0;
	for (string::const_iterator it = str.begin(); it != str.end(); ++it) {
		value *= 1004535809;
		value += *it - 'a';
		value %= 998244353;
	}
	return value;
}

struct Handler {
	string str;
	double val;
	int hash;
	int cnt;
	Handler(const string& s, int c) : str(s), val(Eval(s)), hash(Hash(s)), cnt(c) {}
	bool operator<(const Handler& a) const {
		return val < a.val;
	}
};

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int t;
	cin >> t;
	while (t--) {
		priority_queue<Handler> Q;
		int n;
		cin >> n;
		string s;
		cin >> s;
		Q.push(Handler(s, 1));
		int ans = 0x3FFFFFFF;
		while (Q.size()) {
			Handler h = Q.top();
			Q.pop();
			while (Q.size() && Q.top().hash == h.hash && Q.top().str == h.str) {
				Q.pop();
			}
			if (h.cnt > ans) {
				continue;
			}
			if (Test(h.str)) {
				ans = h.cnt;
				continue;
			}
			size_t l = h.str.length() - 1;
			for (register size_t i = 1; i < l; ++i) {
				if (TestSub(h.str, 0, i - 1)) {
					Q.push(Handler(h.str.substr(i), h.cnt + 1));
				}
				if (TestSub(h.str, i, h.str.length() - 1)) {
					Q.push(Handler(h.str.substr(0, i), h.cnt + 1));
				}
			}
			for (register size_t i = 1; i < l; ++i) {
				for (register size_t j = i + 1; j < l; ++j) {
					if (TestSub(h.str, i, j)) {
						Q.push(Handler(h.str.substr(i, j - i + 1), h.cnt + 1));
					}
				}
			}
		}
		if (ans != 0x3FFFFFFF) {
			cout << ans << '\n';
		} else {
			cout << "-1\n";
		}
	}
}
