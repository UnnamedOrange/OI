#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;
int n;
long long ans[10][10];
int a[20][20];
int vis[20];
int t[20];
int f[20];
int K;
long long sum = 0;
void search(int k, int flag)
{
	/*if(a[1][2] == 1 && a[2][3] == 1 && a[3][1] == 1) {
		cout<<k<<" "<<flag<<" "<<vis[1]<<endl;
	}*/
	for(int i = 1; i <= n; i++) {
		if(a[k][i] == 1) {
			if(t[i]) {
				f[flag - vis[i] + 1] = 1;
			} else {
				t[i]++;
				vis[i] = flag + 1;
				search(i, flag + 1);
				t[i]--;
				vis[i] = 0;
			}
		}
	}
}

void open()
{
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}
bool judge()
{
	/*for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++) {
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;*/
	memset(vis, 0, sizeof vis);
	memset(f, 0, sizeof f);
	for(int i = 1; i <= n; i++) {
		t[i]++;
		vis[i] = 1;
		search(i, 1);
		t[i]--;
		vis[i] = 0;
	}
	/*for(int i = 1; i <= n; i++) {
		cout<<f[i]<<" ";
	}
	cout<<endl<<endl;*/
	if(f[K]) {
		return true;
	} 
	return false;
}
void DFS(int x, int y, int k)
{
	if(k == n * (n - 1) / 2) {
		if(judge()) {
			sum++;
		}
		return; 
	}
//	cout<<x<<" "<<y<<endl;
	a[x][y] = 1;
	a[y][x] = -1;
	if(y == n) {
		DFS(x + 1, x + 2, k + 1);
	} else {
		DFS(x, y + 1, k + 1);
	}
	a[y][x] = 1;
	a[x][y] = -1;
	if(y == n) {
		DFS(x + 1, x + 2, k + 1);
	} else {
		DFS(x, y + 1, k + 1);
	}
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

void init()
{
	ans[1][1] = 0, ans[1][2] = 0, ans[1][3] = 0, ans[1][4] = 0, ans[1][5] = 0, ans[1][6] = 0;
	ans[2][1] = 0, ans[2][2] = 0, ans[2][3] = 0, ans[2][4] = 0, ans[2][5] = 0, ans[2][6] = 0;
	ans[3][1] = 0, ans[3][2] = 0, ans[3][3] = 2, ans[3][4] = 0, ans[3][5] = 0, ans[3][6] = 0;
	ans[4][1] = 0, ans[4][2] = 0, ans[4][3] = 40, ans[4][4] = 24, ans[4][5] = 0, ans[4][6] = 0;
	ans[5][1] = 0, ans[5][2] = 0, ans[5][3] = 904, ans[5][4] = 784, ans[5][5] = 544, ans[5][6] = 0;
	ans[6][1] = 0, ans[6][2] = 0, ans[6][3] = 32048, ans[6][4] = 31008, ans[6][5] = 28848, ans[6][6] = 22320;
}
int main()
{
	open();
	init();
	n = read(), K = read();
//	DFS(1, 2, 0);
	printf("%lld\n", ans[n][K]);
	close();
	return 0;
}
