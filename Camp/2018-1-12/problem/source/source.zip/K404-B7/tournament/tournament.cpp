#include<bits/stdc++.h>
#define ll long long
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c<'0'||c>'9')&&c!='-';c=getchar());
	if(c=='-')f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

const int p=998244353;
int n,k;

int ksm(int x,int y)
{
	int res=1;
	for(;y;y>>=1,x=1ll*x*x%p)
		if(y&1)res=1ll*res*x%p;
	return res;
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	n=getint(),k=getint();
	cout<<ksm(2,n*(n-1)/2-n+1)<<'\n';
	return 0;
}

