#include <cstdio>
#include <algorithm>
#include <vector>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

typedef long long ll;
const int N = 1010;

struct edge{int to, next;} e[N];
int n, x, y, cnt;
int head[N], r[N];
ll w[N], ans, tans, F[N][N];
vector <ll> v[N], VV;

void ins(int x, int y)
{
	e[++cnt].to = y; e[cnt].next = head[x]; head[x] = cnt;
}

void searc(int x, int y, int nx, int ny)
{
	if (!nx && !ny) return;
	if (!nx) {VV.push_back(v[y][ny - 1]); searc(x, y, nx, ny - 1);} else
	if (!ny) {VV.push_back(v[x][nx - 1]); searc(x, y, nx - 1, ny);} else
	if (F[nx][ny] == F[nx - 1][ny] + v[x][nx - 1] * (nx + ny))
	{
		VV.push_back(v[x][nx - 1]);
		searc(x, y, nx - 1, ny);
	}
	else
	{
		VV.push_back(v[y][ny - 1]);
		searc(x, y, nx, ny - 1);
	}
}

void work(int x, int y)
{
	for(int i = 1; i <= v[x].size(); ++i) F[i][0] = F[i - 1][0] + v[x][i - 1] * i;
	for(int j = 1; j <= v[y].size(); ++j) F[0][j] = F[0][j - 1] + v[y][j - 1] * j;
	for(int i = 1; i <= v[x].size(); ++i)
		for(int j = 1; j <= v[y].size(); ++j)
			F[i][j] = max(F[i - 1][j] + v[x][i - 1] * (i + j), F[i][j - 1] + v[y][j - 1] * (i + j));
			
	searc(x, y, v[x].size(), v[y].size());
	v[x].clear(); v[y].clear();
	for(int i = VV.size() - 1; ~i; --i) v[x].push_back(VV[i]);
	VV.clear();
}

void dfs(int x, int y)
{
	bool fl = 0;
	for(int i = head[x]; i; i = e[i].next)
		if (e[i].to != y)
		{
			dfs(e[i].to, x);
			if (fl) work(x, e[i].to);
			else
			{
				for(int j = 0; j < v[e[i].to].size(); ++j) v[x].push_back(v[e[i].to][j]);
				v[e[i].to].clear(); fl = 1;
			}
		}
	for(int i = 0; i < v[x].size(); ++i) VV.push_back(v[x][i]);
	v[x].clear(); v[x].push_back(w[x]);
	for(int i = 0; i < VV.size(); ++i) v[x].push_back(VV[i]);
	VV.clear();
}

int main()
{
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	scanf("%d", &n);
	FOR(i, 2, n)
	{
		scanf("%d%d", &x, &y);
		ins(x, y); ins(y, x);
	}
	FOR(i, 1, n) scanf("%lld%d", &w[i], &r[i]);
	FOR(i, 1, n) if (r[i])
	{
		dfs(i, 0); tans = 0;
		for(ll j = 0; j < v[i].size(); ++j)
			tans += (j + 1) * v[i][j];
		v[i].clear();
		ans = max(ans, tans);
	}
	printf("%lld\n", ans);
	return 0;
}
