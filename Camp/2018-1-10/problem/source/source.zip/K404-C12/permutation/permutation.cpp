#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define MOD 998244353
using namespace std; 
typedef long long ll;
namespace brute
{
	bool vis[15]; 
	int arr[15], idx[15];
	inline void solve(int n)
	{
		for (int i = 0; i < n; i++)
		{
			scanf("%d", arr + i); 
			idx[i] = i + 1; 
		}
		int ans = 0; 
		do
		{
			bool f = true; 
			for (int i = 0; i < n && f; i++)
			{
				if (arr[i] != idx[i] && arr[i])
					f = false; 
			}
			if (!f)
				continue; 
			memset(vis, false, sizeof(vis)); 
			for (int i = 0; i < n && f; i++)
			{
				if (vis[i])
					continue; 
				int x = i, cnt = 0; 
				do
				{
					vis[x] = true; 
					x = idx[x] - 1; 
					cnt++; 
				}
				while (x != i); 
				if (cnt & 1)
					f = false; 
			}
			ans += f;
		}
		while (next_permutation(idx, idx + n)); 
		printf("%d\n", ans); 
	}
}
int main()
{
	freopen("permutation.in", "r", stdin); 
	freopen("permutation.out", "wt", stdout); 
	int n; 
	scanf("%d", &n); 
	if (n <= 8)
	{
		brute::solve(n); 
		return 0; 
	}
	if (n & 1)
	{
		puts("0"); 
		return 0; 
	}
	ll sum = 1; 
	for (int i = 2; i <= n; i += 2)
		sum = sum * (i - 1) % MOD;
	printf("%lld\n", sum * sum % MOD);  
	return 0;
}

