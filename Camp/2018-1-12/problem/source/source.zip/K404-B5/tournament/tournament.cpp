#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 11;

int n, m;
int ord[MAXN];
bool g[MAXN][MAXN];



void init ();
void input ();
void work ();



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "tournament" );
}

void input ()
{
	scanf ( "%d%d", &n, &m );
}

void work ()
{
	int nn = n * ( n - 1 ) / 2;
	int ms = 1 << nn, tn;
	bool flag;
	int ans = 0;
	lp ( i, 0, ms ){
		tn = 0;
		lpi ( j, 1, n ){
			lpi ( k, j+1, n ){
				g[j][k] = i >> tn & 1;
				g[k][j] = !g[j][k];
				++tn;
			}
		}
		
//		cerr << i << " " << tn << endl;
//		lpi ( j, 1, n ){
//			lpi ( k, 1, n ){
//				cerr << g[j][k] << " ";
//			}
//			cerr << endl;
//		}
		
		lpi ( j, 1, n ) ord[j] = j;
		
		do{
			flag = true;
			lp ( j, 1, m ){
				if ( !g[ord[j]][ord[j+1]] ){
					flag = false;
					break;
				}
			}
			if ( flag && g[ord[m]][ord[1]] ){
				++ans;
				break;
			}
		}while ( next_permutation ( ord+1, ord+1+n ) );
	}
	cout << ans << endl;
}
