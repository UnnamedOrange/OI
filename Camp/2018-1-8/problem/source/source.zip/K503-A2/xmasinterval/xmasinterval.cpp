#include<cstdio>
#include<iostream>
#include<queue>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int a[25],nowl[25],nowr[25],n,m,ans;
bool f[25];
struct E{
	int l,r;
}e[25];
inline bool cmp(E a,E b){
	return a.l<b.l;
}
inline bool check(){
	int s=0,j=1;
	for(int i=1;i<=n;i++) if(f[i]) nowl[++s]=e[i].l,nowr[s]=e[i].r;
	nowr[s+1]=nowl[s+1]=0x3fffffff;
	for(int i=1;i<=m;i++){
		while(a[i]>nowr[j]) j++;
		if(nowl[j]>a[i]) return 0;
	}
	return 1;
}
void dfs(int i){
	if(i>n){
		if(check()) ans++;
		return;
	}
	f[i]=1;
	dfs(i+1);
	f[i]=0;
	dfs(i+1);
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++) scanf("%d%d",&e[i].l,&e[i].r);
	for(int i=1;i<=m;i++) scanf("%d",&a[i]);
	sort(e+1,e+n+1,cmp);
	sort(a+1,a+m+1);
	dfs(1);
	printf("%d",ans);
	return 0;
}
