#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
int n,m,ans,len[7];
bool p[7][105],now[1001];
char s[105];
int main()
{
	open(string);
	re(n),re(m);
	for(int i=1;i<=n;++i)	
	{
		scanf("%s",s+1);
		len[i]=strlen(s+1);
		for(int j=1;j<=len[i];++j)
			p[i][j]=s[j]-'0';
	}
	for(int i=0;i<(1<<m);++i)
	{
		for(int j=1,c=i;j<=m;++j,c>>=1)
			now[j]=c&1,now[m+m-j+1]=now[j]^1;
		bool ok=1;
		for(int j=1;j<=n;++j)
		{
			bool meet=0;
			for(int k=1;k+len[j]-1<=m+m;++k)
			{
				bool pp=1;
				for(int l=1;l<=len[j];++l)
					if(now[k+l-1] != p[j][l])	
					{
						pp=0;
						break;
					}
				if(pp)
				{
					meet=1;
					break;
				}
			}
			if(!meet)
			{
				ok=0;
				break;
			}
		}
		ans+=ok;
	}
	printf("%d\n",ans);
}
/*
2 3
011
001
*/
