#include<cstdio>
#include<algorithm>
#include<cmath>
#include<set>
#define gc getchar()
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
using namespace std;
inline int read(){
	char c;while(c=gc,c==' '||c=='\n');int data=c-48;
	while(c=gc,c>='0'&&c<='9')data=(data<<1)+(data<<3)+c-48;return data;
}
const int maxn=4000011;
set<int>s[250000];
int n,q,t,x,y,times,tot,u,l,r,c,cnt,blo,type,_l,_r,now;
int a[maxn>>1],b[maxn],sz[maxn>>1],hv[maxn>>1],_hv[15151],
	xu[maxn>>1],col[maxn>>1],ans[maxn>>1];
struct edge{
	int to;
	edge *nxt;
}e[maxn],*las[maxn],*et=e;
inline void add(int x,int y){
	*++et=(edge){y,las[x]};las[x]=et;
}
struct question{
	int id,u,l,r,time;
	inline bool operator <(question A)const{
		if(xu[u]/blo!=xu[A.u]/blo)return xu[u]<xu[A.u];
		if((xu[u]+sz[u]-1)/blo!=(xu[A.u]+sz[A.u]-1)/blo)return xu[u]+sz[u]<xu[A.u]+sz[A.u];
		if(time/blo!=A.time/blo)return time<A.time;
		if(l/blo!=A.l/blo)return l<A.l;
		if(r/blo!=A.r/blo)return r<A.r;
		if(id/blo!=A.id/blo)return id<A.id;
	}
}qs[maxn];
struct change{
	int u,c;
}cg[maxn];
inline void disc_init(){
	sort(b+1,b+b[0]+1);
	b[0]=unique(b+1,b+b[0]+1)-b-1;
	FOR(i,1,n)
		a[i]=lower_bound(b+1,b+b[0]+1,a[i])-b;
	FOR(i,1,tot){
		qs[i].l=lower_bound(b+1,b+b[0]+1,qs[i].l)-b;
		qs[i].r=upper_bound(b+1,b+b[0]+1,qs[i].r)-b-1;
	}
	FOR(i,1,times)
		cg[i].c=lower_bound(b+1,b+b[0]+1,cg[i].c)-b;
}
inline void dfs(int now,int fa){
	sz[now]=1;
	xu[now]=++cnt;
	col[cnt]=a[now];
	s[a[now]].insert(xu[now]);
	for(register edge *it=las[now];it;it=it->nxt)
		if(it->to!=fa){
			dfs(it->to,now);
			sz[now]+=sz[it->to];
		}
}
inline void add(int x){if(!hv[x])++_hv[(x-1)/blo+1];++hv[x];}
inline void del(int x){--hv[x];if(!hv[x])--_hv[(x-1)/blo+1];}
inline void modify(int now,int l,int r){
	register int pos=xu[cg[now].u];
	if(l<=pos&&pos<=r){
		del(col[pos]);
		add(cg[now].c);
	}
	swap(cg[now].c,col[pos]);
}
inline int query(int l,int r){
	register int i=l,j=r,ans=0;
	for(;;++i){
		if((i-1)/blo!=(i-2)/blo)
			break;
		if(hv[i]){
			++ans;
		}
		if(i==r)
			return ans;
	}
	for(;;--j){
		if(hv[j])
			++ans;
		if((j-1)/blo!=(j-2)/blo){
			break;
		} 
	}
	for(register int k=(i-1)/blo+1;k<=(j-1)/blo;++k)
		ans+=_hv[k];
	return ans;
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read();q=read();t=read();
	blo=10*sqrt(n);
	FOR(i,1,n){
		a[i]=read();
		b[++b[0]]=a[i];
	}
	FOR(i,2,n){
		x=read(),y=read();
		add(x,y);add(y,x);
	}
	if(n<=10000){
		dfs(1,0);
		register int ans=0,p;
		FOR(i,1,n)
			s[a[i]].insert(i);
		FOR(i,1,n+q)
			s[i].insert(2147483647);
		FOR(i,1,q){
			type=read();
			if(type==1){
				u=read();l=read();r=read();
				if(t)u^=ans,l^=ans,r^=ans;
				ans=0;
				FOR(i,l,r){
					p=*lower_bound(s[i].begin(),s[i].end(),xu[u]);
					if(p<=xu[u]+sz[u]-1)
						++ans;
				}
				printf("%d\n",ans);
			}
			else{
				u=read();c=read();
				if(t)u^=ans,c^=ans;
				s[a[u]].erase(xu[u]);
				a[u]=c;
				s[a[u]].insert(xu[u]);
			}
		}
		return 0;
	}
	if(t==0){
		FOR(i,1,q){
			type=read();
			if(type==1){
				u=read();l=read();r=read();
				qs[++tot]=(question){tot,u,l,r,times};
			}
			else{
				u=read();c=read();
				cg[++times]=(change){u,c};
				b[++b[0]]=c;
			}
		}
		disc_init();
		dfs(1,0);
		sort(qs+1,qs+tot+1);
		l=1,r=0,now=0;
		FOR(i,1,tot){
			u=qs[i].u;
			times=qs[i].time;
			_l=xu[u];_r=xu[u]+sz[u]-1;
			while(l<_l)del(col[l++]);
			while(l>_l)add(col[--l]);
			while(r<_r)add(col[++r]);
			while(r>_r)del(col[r--]);
			while(now<times)modify(++now,_l,_r);
			while(now>times)modify(now--,_l,_r);
			ans[qs[i].id]=query(qs[i].l,qs[i].r);
		}
		FOR(i,1,tot)
			printf("%d\n",ans[i]);
		return 0;
	}
	dfs(1,0);
	register int ans=0,p;
	FOR(i,1,n)
		s[a[i]].insert(i);
	FOR(i,1,n+q)
		s[i].insert(2147483647);
	FOR(i,1,q){
		type=read();
		if(type==1){
			u=read();l=read();r=read();
			if(t)u^=ans,l^=ans,r^=ans;
			ans=0;
			FOR(i,l,r){
				p=*lower_bound(s[i].begin(),s[i].end(),xu[u]);
				if(p<=xu[u]+sz[u]-1)
					++ans;
			}
			printf("%d\n",ans);
		}
		else{
			u=read();r=read();
			if(t)u^=ans,c^=ans;
			s[a[u]].erase(xu[u]);
			a[u]=c;
			s[a[u]].insert(xu[u]);
		}
	}
	return 0;
}
/*
5 5 0
5 5 2 5 5
5 1
2 5
4 2
3 5
1 2 2 3
2 5 1
1 1 1 5
2 3 2 
1 3 1 5
*/
