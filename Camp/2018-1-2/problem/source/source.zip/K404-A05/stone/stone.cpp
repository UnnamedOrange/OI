//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
ll qpow(ll x,ll k){return k==0?1:qpow(x*x%mod,k>>1)*(k&1?x:1)%mod;}
int n,a,b;
ll fac[200111],ifac[200111],pw2[200111];
ll C(ll x,ll y){return x<y?0:fac[x]*ifac[y]%mod*ifac[x-y]%mod;}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	pw2[0]=1;
	for(int i=1;i<=200005;i++)pw2[i]=pw2[i-1]*2%mod;
	fac[0]=1;
	for(int i=1;i<=200005;i++)fac[i]=fac[i-1]*i%mod;
	ifac[200005]=qpow(fac[200005],mod-2);
	for(int i=200004;i>=0;i--)ifac[i]=ifac[i+1]*(i+1)%mod;
	
	scanf("%d%d%d",&n,&a,&b);
	int cnt1=0,cnt0=0;
	for(int i=1;i<=n;i++)
	{
		int x;
		scanf("%d",&x);
		int cur=x/a;
		if(cur&1)cnt1++;else cnt0++;
	}
	ll ans1=0,ans0=0;
	for(int i=0;i<=cnt1;i++)
	{
		if(i&1)ans1+=pw2[cnt0]*C(cnt1,i)%mod;
		else ans0+=pw2[cnt0]*C(cnt1,i)%mod;
	}
	ans1=(ans1%mod+mod)%mod;
	ans0=(ans0%mod+mod)%mod;
	cout<<0<<" "<<0<<" "<<ans1<<" "<<ans0<<endl;
	return 0;
}
