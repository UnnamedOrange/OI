#include <bits/stdc++.h>
using namespace std ;
const int maxn = 30 ;
int n, m, p[maxn], lim ;
bool fg ;
inline void dfs ( int stp ) {
	if (fg) return ;
	register int i, l, r = 0 ;
	for ( i = 1 ; i < n ; i ++ )
		if (abs(p[i] - p[i+1]) > 1) ++ r ;
	if (stp + r > lim+1) return ;
	fg = 1 ;
	for ( i = 1 ; i <= n ; i ++ )
		if (p[i] ^ i) {
			fg = 0 ;
			break ;
		}
	if (fg) return ;
	for ( i = 2 ; i <= n ; i ++ ) {
		for ( l = 1, r = i ; l < r ; l ++, r -- )
			swap(p[l], p[r]) ;
		dfs(stp+1) ;
		for ( l = 1, r = i ; l < r ; l ++, r -- )
			swap(p[l], p[r]) ;
	}
}
int main() {
	freopen ( "sequence.in", "r", stdin ) ;
	freopen ( "sequence.out", "w", stdout ) ;

	int i, _ ;
	scanf ( "%d", &_ ) ;
	while (_--) {
		scanf ( "%d", &n ) ;
		for ( i = 1 ; i <= n ; i ++ )
			scanf ( "%d", p+i ) ;
		m = n<<1 ;
		fg = 0 ;
		for ( lim = 0 ; lim <= m ; lim ++ ) {
			dfs(1) ;
			if (fg) break ;
		}
		printf ( "%d\n", lim ) ;
	}
	//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
