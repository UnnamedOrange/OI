#include<cstdio>
#include<cstring>
#include<algorithm>
#define fi first
#define se second
#define MP make_pair
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int mod=998244353;
const int N=100010,BL=350;
int a[N];
int n,m,K;
int ans;

int power(int x,int y){
	int ret=1;
	for(;y;y>>=1,x=1ll*x*x%mod){
		if(y&1)	ret=1ll*ret*x%mod;
	}
	return ret;
}

void calc(){
	int i;
	rep(i,1,n)	ans=(ans+power(a[i],K))%mod;
}

void dfs(int now,int l,int r){
	int i,j,k;
	if(now==m+1){calc();return;}
	rep(i,l+1,n) rep(j,r+1,n) if(i<=j){
		rep(k,i,j-1)	a[k]++;
		dfs(now+1,i,j);
		rep(k,i,j-1)	a[k]--;
	}
}

void solve2(){
	static int f[N],c[N];
	int i;
	rep(i,1,n)	f[i]=(f[i-1]+1ll*i*(i-1))%mod;
	rep(i,1,n)	c[i]=(1ll*i*(i-1)/2)%mod;
	rep(i,1,n){
		ans=(ans+1ll*c[i]*c[n-i]%mod*power(2,K))%mod;
		ans=(ans+1ll*i*f[n-i])%mod;
		ans=(ans+1ll*(n-i)*f[i])%mod;
	}
	printf("%d\n",ans);
}

void solve1(){
	static pair<int,int> dp[BL][BL][BL];
	register int i,j,k;
	dp[0][0][0]=MP(1,0);
	rep(i,0,n) rep(j,0,n) rep(k,0,m) if(dp[i][j][k].fi){
		//printf("dp[%d][%d][%d]=(%d,%d)\n",i,j,k,dp[i][j][k].fi,dp[i][j][k].se);
		(dp[i][j+1][k].fi+=dp[i][j][k].fi)%=mod;		
		(dp[i+1][j][k].fi+=dp[i][j][k].fi)%=mod;
		(dp[i+1][j+1][k].fi-=dp[i][j][k].fi)%=mod;
		(dp[i][j+1][k].se+=dp[i][j][k].se)%=mod;		
		(dp[i+1][j][k].se+=dp[i][j][k].se)%=mod;
		(dp[i+1][j+1][k].se-=dp[i][j][k].se)%=mod;
		if(i<=j){			
			(dp[i+1][j+1][k+1].fi+=dp[i][j][k].fi)%=mod;
			dp[i+1][j+1][k+1].se=(dp[i+1][j+1][k+1].se+dp[i][j][k].se+
			1ll*dp[i][j][k].fi*(j-i))%mod;
		}
	}
	printf("%d\n",(dp[n][n][m].se+mod)%mod);
}
	
void solve0(){
	static int dp[BL][BL][BL];
	register int i,j,k;
	dp[0][0][0]=1;
	rep(i,0,n) rep(j,0,n) rep(k,0,m) if(dp[i][j][k]){
		//printf("dp[%d][%d][%d]=(%d,%d)\n",i,j,k,dp[i][j][k].fi,dp[i][j][k].se);
		(dp[i][j+1][k]+=dp[i][j][k])%=mod;		
		(dp[i+1][j][k]+=dp[i][j][k])%=mod;
		(dp[i+1][j+1][k]-=dp[i][j][k])%=mod;
		if(i<=j){(dp[i+1][j+1][k+1]+=dp[i][j][k])%=mod;}
	}
	int now;
	ans=1ll*dp[n][n][m]*n%mod;
	rep(i,1,n){
		now=0;
		rep(k,0,m)	now=(now+1ll*dp[i][i][k]*dp[n-i][n-i][m-k])%mod;
		ans=(ans-now+mod)%mod;
	}
	printf("%d\n",ans);
	//rep(i,1,n)	printf("%d\n",dp[n][n][m]);
}

int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int i;
	scanf("%d%d%d",&m,&n,&K);
	if(m>n){printf("0\n");return 0;}
	if(n<=6){dfs(1,0,0);printf("%d\n",ans);return 0;}
	if(m==1){
		rep(i,1,n)	ans=(ans+1ll*i*(n-i))%mod;
		printf("%d\n",ans);
		return 0;
	}
	if(m==2){solve2();return 0;}
	if(n<=350){
		if(K==1){solve1();return 0;}
		if(K==998244352){solve0();return 0;}
		return 0;
	}				
}






















