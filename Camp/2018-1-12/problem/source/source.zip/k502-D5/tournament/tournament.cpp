#include<bits/stdc++.h>
using namespace std;

const int maxn = 6 + 1;

int n,k,ans;
int e[maxn];
int vis,st,success;

void input()
{
	scanf("%d%d",&n,&k);ans=0;
}

void dfs2(int u,int step)
{
	int i;
	
	vis^=1<<u;
	for(i=0;i<n && !success;i++) if(e[u]&1<<i)
	{
		if(vis&1<<i) 
		{
			if(step==k && i==st) {success=1;return;}
		}
		else dfs2(i,step+1);
	}
	vis^=1<<u;
}

void dfs1(int u)
{
	int S,i;
	
	if(u==n)
	{
		for(st=0;st<n;st++) vis=success=0,dfs2(st,1);
		ans+=success;
		return;
	}
	for(S=0;S<(1<<n);S++) if(!(S&1<<u))
	{
		for(i=0;i<n;i++) if(((e[i]&1<<u)==0) == ((S&1<<i)==0)) continue;
		e[u]=S;
	}
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	
	input();
	dfs1(0);
	cout<<ans;
	
	return 0;
}
