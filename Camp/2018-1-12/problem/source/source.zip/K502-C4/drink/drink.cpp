#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

int n,w[1000005],temp[1000005],top;
long double Ans,ans;

void init()
{
	top=0; ans=0;
	memset(temp,0,sizeof temp);
}

void solve()
{
	sort(temp+1,temp+top+1);
	for(int i=1;i<=top;i++)
		if(temp[i]>ans) ans=(ans+temp[i])/2;
	Ans+=ans/(n*n);
}

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&w[i]);
	for(int i=1;i<=n;i++)
	{
		init();
		for(int j=i;j<=n;j++)
		{
			ans=0;
			temp[++top]=w[j];
			solve();
		}
	}
	printf("%Lf",Ans);
	return 0;
} 
