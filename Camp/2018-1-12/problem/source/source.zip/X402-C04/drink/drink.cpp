#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

typedef double db;
const int N=1e6+9;

int n,w[N],tmp[N];

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);

	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&w[i]);

	db ans=0,n2=(db)n*n;
	for(int l=1;l<=n;l++)
		for(int r=l;r<=n;r++)
		{
			for(int i=l;i<=r;i++)
				tmp[i]=w[i];
			sort(tmp+l,tmp+r+1);
			db cur=0;
			for(int i=l;i<=r;i++)
				cur=(cur+(db)tmp[i])/2.0;
			ans+=cur;
		}

	printf("%.3lf\n",ans/n2);
	return 0;
}
