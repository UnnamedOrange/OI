#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int mod=998244353;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int p[N],f[N],fac[N],finv[N],n,sum[N],g[N];
int id[N],deg[N],stk[N],top;
bool hav[N];

void wj()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	int m=0;
	n=read();
	if(n&1){printf("0\n");return 0;}
	bool isall0=1;
	for(i=1;i<=n;++i) 
	{
		p[i]=read();
		if(hav[p[i]]) {printf("0\n");return 0;}
		if(p[i]) hav[p[i]]=1,deg[p[i]]++;
		if(p[i]) isall0=0;
	}
	if(isall0)
	{
		fac[0]=1; finv[0]=1;
		for(i=1;i<=n;++i) fac[i]=1ll*fac[i-1]*i%mod;
		finv[n]=qpow(fac[n],mod-2);
		for(i=n-1;i>=1;--i) finv[i]=1ll*finv[i+1]*(i+1)%mod;

		f[0]=1; sum[0]=1;
		for(i=2;i<=n;++i)
		{
			f[i]=1ll*fac[i-1]*sum[i-2]%mod;
			sum[i]=(sum[i-2]+1ll*f[i]*finv[i]%mod)%mod;
		}
		printf("%d\n",f[n]);
		return 0;
	}
	if(n<=8)
	{
		for(i=1;i<=n;++i) id[i]=i;
		int ans=0;
		do
		{
			bool can=1;
			for(i=1;i<=n;++i) if(p[i]&&id[i]!=p[i]) {can=0;break;}
			if(can)
			{
				bool add=1;
				for(i=1;i<=n;++i)
				{
					j=id[i]; int cnt=1;
					while(j!=i) j=id[j],cnt++;
					if(cnt&1) {add=0;break;}
				}
				if(add) ans++;
			}
		}while(next_permutation(id+1,id+1+n));
		printf("%d\n",ans);
		return 0;
	}
	fac[0]=1; finv[0]=1;
	for(i=1;i<=n;++i) fac[i]=1ll*fac[i-1]*i%mod;
	finv[n]=qpow(fac[n],mod-2);
	for(i=n-1;i>=1;--i) finv[i]=1ll*finv[i+1]*(i+1)%mod;

	f[0]=1; sum[0]=1;
	for(i=2;i<=n;++i)
	{
		f[i]=1ll*fac[i-1]*sum[i-2]%mod;
		sum[i]=(sum[i-2]+1ll*f[i]*finv[i]%mod)%mod;
	}

	for(i=1;i<=n;++i) g[i]=1ll*f[i]*qpow(i-1,mod-2)%mod,hav[i]=0;
	int nn=0;
	for(i=1;i<=n;++i) if(!deg[i]) stk[++top]=i;
	while(top)
	{
		i=stk[top]; top--;
		if(!p[i]) {nn++;continue;}
		if(p[i]==i) continue;
		j=p[i];
		int cnt=2; bool cir=0;
		while(p[j])
		{
			j=p[j]; cnt++;
			if(j==i) {cir=1;break;}
		}
		if(cir) continue;
		if(cnt&1) nn++;
		else nn+=2,m++;
	}
	n=nn;
	int mm=m;
	//cerr<<n<<' '<<m<<endl;
	if(n&1) {printf("0\n");return 0;}
	if(!m) {printf("%d\n",f[n]);return 0;}
	int cnt=0;
	while(mm>1) nn-=2,mm--,cnt++;
	int ans=g[nn],mul=nn;
	for(i=1;i<=cnt;++i)
	{
		ans=1ll*ans*mul%mod;
		mul++;
	}
	printf("%d\n",ans);
	return 0;
}
