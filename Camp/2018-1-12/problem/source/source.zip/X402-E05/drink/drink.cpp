#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define ft first
#define sd second
#define mkp make_pair
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define ls l,mid
#define rs mid+1,r
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int W=100000;
const int N=1000010;
const int M=20000010;
const int inf=0x3f3f3f3f;
const double eps=1e-8;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
}
int n,w[N];
double sum[N],ans;
inline void Solve(int x,int y)
{
	double ret=1./2.,h=0.0;
	For(i,x,n)
	{
		if(w[i]>w[x])ret/=2.;
		else sum[i]/=2.;
		if(ret<eps)break;
		h+=ret*y;
	}
	sum[x]=h;
	For(i,x,n)ans+=sum[i];
}
int main()
{
	file();
	read(n);
	For(i,1,n)read(w[i]);
	rFor(i,n,1)Solve(i,w[i]);
	printf("%.8lf\n",ans/(1.*n)/(1.*n));
	return 0;
}
