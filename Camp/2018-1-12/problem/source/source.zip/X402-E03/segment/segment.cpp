#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const int maxn = 1e5+5, modd = 998244353 ;
int Qpow ( int a, int b ) {
	int rec = 1 ;
	for ( a %= modd ; b ; b >>= 1, a = (LL)a*a%modd )
		if (b&1) rec = (LL)rec*a%modd ;
	return rec ;
}
int n, m, a[maxn], l[maxn], r[maxn], k, ans ;
void dfs ( int stp ) {
	if (stp > m) {
		for ( int i = 1 ; i <= n ; i ++ )
			(ans += Qpow(a[i], k)) %= modd ;
		return ;
	}
	for ( int L = l[stp-1]+1 ; L <= n ; L ++ )
		for ( int R = max(r[stp-1]+1, L) ; R <= n ; R ++ ) {
			l[stp] = L, r[stp] = R ;
			for ( int i = L ; i < R ; i ++ )
				a[i] ++ ;
			dfs(stp+1) ;
			for ( int i = L ; i < R ; i ++ )
				a[i] -- ;
		}
}
int main() {
	freopen ( "segment.in", "r", stdin ) ;
	freopen ( "segment.out", "w", stdout ) ;
	cin >> m >> n >> k ;
	dfs(1) ;
	cout << ans << endl ;
	return 0 ;
}
