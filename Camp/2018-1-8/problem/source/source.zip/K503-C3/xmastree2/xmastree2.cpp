#include <bits/stdc++.h>
#define N 5010
#define P 1000000009
#define ll long long
using namespace std;
int n,s[N],a[N],fir[N],to[N],nxt[N],tot(1),w[N],r[N],b[N],c[N],Ans(0),ans,f[N],used[N],d[N];
int nx[N],sum[N];

template <class Aqua>
inline void read(Aqua &s){
	s=0; char c=getchar();
	while (!isdigit(c)) c=getchar(); // -?
	while (isdigit(c)) s=s*10+c-'0',c=getchar();
}

inline void add(int u,int v){
	to[++tot]=v; nxt[tot]=fir[u]; fir[u]=tot;
}

int calc(int num){
	int sum=0,x=s[c[b[1]]];
	for (int i=2;i<=num;i++)
		sum+=x*a[c[b[i]]],x+=s[c[b[i]]];
	return sum;
}

void search(int dep,int num){
	if (dep>num){
		ans=max(ans,calc(num));
		return;
	}
	for (int i=1;i<=num;i++)
		if (!used[i]){
			used[i]=1;
			b[dep]=i;
			search(dep+1,num);
			used[i]=0;
		}
}

void dfs(int x,int fa){
	f[x]=a[x]=w[x]; s[x]=1;
	int num=0;
	for (int i=fir[x];i;i=nxt[i])
		if (to[i]!=fa)
			dfs(to[i],x),s[x]+=s[to[i]],a[x]+=a[to[i]];
	for (int i=fir[x];i;i=nxt[i])
		if (to[i]!=fa)
			c[++num]=to[i];
	for (int i=1;i<=num;i++)
		used[i]=0;
	ans=0;
	if (n<=15)
		search(1,num);
	else{
		int ss,ss_,cnt=0,y,h=1,cur,tmp,las=0;
		for (int i=1;i<=num;i++)
			sum[i]=sum[i-1]+a[c[i]];
		nx[0]=h;
		for (int i=2;i<=num;i++){
			cur=h;
			y=ss=ss_=0,ans=las+sum[i-1]*s[c[i]];
			for (int j=1;j<i;j++){
				ss+=s[c[cur]]; ss_+=a[c[cur]];
				tmp=las+a[c[i]]*ss+s[c[i]]*(sum[i-1]-ss_);
				if (tmp>ans)
					ans=tmp,y=j;
				cur=nx[cur];
			}
			cur=0;
			for (int j=1;j<=y;j++){
				cur=nx[cur];
			}
			nx[i]=nx[cur]; nx[cur]=i;
			if (cur==0) h=i;
			las=ans;
		}/*
		if (!fa){
			cur=0;
			for (int j=1;j<=num;j++){
				cur=nx[cur];
				printf("%d ",c[cur]);
			}
			puts("");
		}*/
		/*
		for (int i=1;i<=num;i++){
			ans=-1;
			for (int j=1;j<i;j++)
				d[j]=b[j];
			for (int j=1;j<=i;j++){
				b[j]=i; cnt=0;
				for (int k=1;k<j;k++)
					b[k]=d[++cnt];
				for (int k=j+1;k<=i;k++)
					b[k]=d[++cnt];
				xx=calc(i);
				if (ans<xx)
					ans=xx,y=j;
			}
			b[y]=i; cnt=0;
			for (int k=1;k<y;k++)
				b[k]=d[++cnt];
			for (int k=y+1;k<=i;k++)
				b[k]=d[++cnt];
		}*/
	}
	for (int i=1;i<=num;i++)
		ans+=f[c[i]]+a[c[i]];
	ans+=w[x];
	f[x]=ans;
}

int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	read(n);
	int u,v;
	for (int i=1;i<n;i++)
		read(u),read(v),add(u,v),add(v,u);
	for (int i=1;i<=n;i++)
		read(w[i]),read(r[i]);
	for (int i=1;i<=n;i++)
		if (r[i]){
			dfs(i,0);
		//	for (int j=1;j<=n;j++)
		//		printf("%d ",f[j]);
		//	puts("");
		//	printf("%d\n",f[i]);
			Ans=max(Ans,f[i]);
		}
	printf("%d\n",Ans);
	return 0;
}
