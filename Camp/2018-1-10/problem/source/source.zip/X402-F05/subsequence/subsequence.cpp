#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)
#define Forr(i, j, k) for(int i = j; i >= k; i--)

using namespace std;

const int N = 4010;

int k;
bool vis[N];

int work(int *A, bool dp[N][N], int n){
	For(j, 1, n) dp[j][0] = true;
	For(i, 1, n){
		int cnt = 0;
		For(j, 1, k) vis[j] = false;
		Forr(j, n, 0){
			dp[j][i] = cnt == k;
			if(j && dp[j][i - 1] && !vis[A[j]]) ++cnt, vis[A[j]] = true;
		}
		if(cnt < k) return i - 1;
	}
	return n;
}

int n, m;
int A[N], B[N];

bool dpa[N][N], dpb[N][N];

int main(){
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);
	For(i, 1, n) scanf("%d", &A[i]);
	For(i, 1, m) scanf("%d", &B[i]);

	int x = work(A, dpa, n), y = work(B, dpb, n);
	if(x != y) printf("%d\n", max(x, y) + 1);
	else{
		For(i, 1, k) vis[i] = false;
		For(i, 1, n) if(dpa[i][x]) vis[A[i]] = true;
		For(i, 1, m) if(dpb[i][x]) vis[B[i]] = true;
		int cnt = 0;
		For(i, 1, k) cnt += vis[i];
		printf("%d\n", x + 1 + (cnt == k));
	}

	return 0;
}
