#include<cstdio>
using namespace std;
const int maxn=4005;
int a[maxn],b[maxn];
int max(int x,int y){
	return x>y?x:y;
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d",&b[i]);
	printf("%d",max(n,m)+1);
}
