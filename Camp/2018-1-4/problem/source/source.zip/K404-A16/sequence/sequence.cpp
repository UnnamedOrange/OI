#include <cstdio>
#include <cstdlib>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

int T, n, a[30];

bool check()
{
	FOR(i, 2, n) if (a[i] < a[i - 1]) return 0;
	return 1;
}

bool dfs(int x, int y, int lst)
{
	if (check()) return 1;
	int tot = 0, b[30];
	FOR(i, 1, n) b[i] = a[i];
	FOR(i, 2, n) if (abs(a[i] - a[i - 1]) > 1) ++tot;
	if (y - 1 + tot > x || y > x) return 0;
	FOR(i, 2, n) if (i != lst)
	{
		FOR(j, 1, i) a[j] = b[i - j + 1];
		if (dfs(x, y + 1, i)) return 1;
		FOR(j, 1, i) a[j] = b[j];
	}
	return 0;
}

void work()
{
	scanf("%d", &n);
	FOR(i, 1, n) scanf("%d", &a[i]);
	FOR(i, 0, 2 * n - 2)
		if (dfs(i, 1, 0))
		{
			printf("%d\n", i);
			return;
		}
}

int main()
{
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	scanf("%d", &T);
	while (T--) work();
	return 0;
}
