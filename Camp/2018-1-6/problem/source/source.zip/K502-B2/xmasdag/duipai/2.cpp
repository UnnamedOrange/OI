#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)1e5+5,N=(int)2e5+5,P=998244353;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
void Del(int &x,int y){
	x-=y;
	if(x<0)x+=P;
}
int fast(int x,int p){
	int re=1;
	while(p){
		if(p&1)re=(long long)re*x%P;
		x=(long long)x*x%P,p>>=1;
	}return re;
}
struct W{
	int to,nx;
}Lis[N];
int Head[M],tot;
void eAdd(int x,int y){
	Lis[++tot]=(W){y,Head[x]};
	Head[x]=tot;
}
int n,m,K;
struct SHUI{
	int dp[2005][5005];
	int deg[2005],q[2005],L,R;
	int FC[5005];
	void solve(){
		for(int i=1;i<=m;i++){
			FC[i]=1;
			for(int j=1;j<=K;j++)FC[i]=(long long)FC[i]*i%P;
		}
		L=R=0;
		for(int x=1;x<=n;x++)
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
				deg[to]++;
		for(int i=1;i<=n;i++)if(deg[i]==0)q[R++]=i;
		dp[1][0]=1;
		for(int x;L<R;){
			x=q[L++];
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx){
				if(deg[to]--==1)q[R++]=to;
				for(int j=0;j<=m;j++)
					Add(dp[to][j+1],dp[x][j]);
			}
		}
		for(int i=1;i<=n;i++){
			int ans=0;
			for(int j=1;j<=m;j++)Add(ans,(long long)FC[j]*dp[i][j]%P);
			printf("%d\n",ans);
		}
	}
}P20;
struct IHUS{
	int dp[M],pd[M],deg[M],q[M],L,R;
	void solve(){
		L=R=0;
		pd[1]=1;
		for(int x=1;x<=n;x++)
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
				deg[to]++;
		for(int i=1;i<=n;i++)if(deg[i]==0)q[R++]=i;
		for(int x;L<R;){
			x=q[L++];
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx){
				if(deg[to]--==1)q[R++]=to;
				Add(pd[to],pd[x]);
				Add(dp[to],pd[x]);
				Add(dp[to],dp[x]);
			}
		}
		for(int i=1;i<=n;i++)printf("%d\n",dp[i]);
	}
}P10;
struct IHSU{
	int dp[M][505],deg[M],q[M],L,R;
	int a[1005],b[1005],rev[1005];
	void init(int len){
		for(int i=0,tmp;i<len;i++){
			tmp=0;
			for(int t=1;t<len;t<<=1){
				tmp<<=1;
				if(t&i)tmp|=1;
			}
			rev[i]=tmp;
//			printf("%d %d\n",i,tmp);
		}
	}
	int fac[505],rfac[505];
	void fft(int *a,int len,int p){
		for(int i=0,x;i<len;i++)
			if((x=rev[i])>i)swap(a[x],a[i]);
		for(int i=1,w,wm,tmp;i<len;i<<=1){
			w=fast(3,(long long)(P-1)/2/i*p%(P-1));
			for(int j=0,stp=(i<<1);j<len;j+=stp){
				wm=1;
				for(int k=0;k<i;k++){
					tmp=(long long)a[i+j+k]*wm%P;
					Del(a[i+j+k]=a[j+k],tmp);
					Add(a[j+k],tmp);
					wm=(long long)wm*w%P;
				}
			}
		}
		if(p==P-2){
			int inv=fast(len,P-2);
			for(int i=0;i<len;i++)a[i]=(long long)a[i]*inv%P;
		}
	}
	void solve(){
		L=R=0;
		for(int x=1;x<=n;x++)
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
				deg[to]++;
		dp[1][0]=1;
		for(int i=1;i<=n;i++)if(deg[i]==0)q[R++]=i;
		int len=1;
		while(len<=K)len<<=1;len<<=1;
		init(len);
		fac[0]=1;
		for(int i=1;i<505;i++)fac[i]=(long long)fac[i-1]*i%P;
		rfac[504]=fast(fac[504],P-2);
		for(int i=503;i>=0;i--)rfac[i]=(long long)rfac[i+1]*(i+1)%P;
		for(int i=0;i<=K;i++)b[i]=rfac[i];
		for(int i=K+1;i<len;i++)b[i]=0;
		fft(b,len,1);
		for(int x;L<R;){
			x=q[L++];
			if(Head[x]==0)continue;
			for(int i=0;i<=K;i++)a[i]=(long long)dp[x][i]*rfac[i]%P;
			for(int i=K+1;i<len;i++)a[i]=0;
			fft(a,len,1);
			for(int i=0;i<len;i++)a[i]=(long long)a[i]*b[i]%P;
			fft(a,len,P-2);
			for(int i=0;i<=K;i++)a[i]=(long long)a[i]*fac[i]%P;
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx){
				if(deg[to]--==1)q[R++]=to;
				for(int j=0;j<=K;j++)Add(dp[to][j],a[j]);
			}
		}
		for(int i=1;i<=n;i++)printf("%d\n",dp[i][K]);
	}
}PPP;
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("2.out","w",stdout);
	Rd(n),Rd(m),Rd(K);
	for(int i=1,x,y;i<=m;i++)Rd(x),Rd(y),eAdd(x,y);
//	if(0);
	if(n<=2000&&m<=5000)P20.solve();
	else if(K==1)P10.solve();
	else PPP.solve();
	return 0;
}
