#include<bits/stdc++.h>
using namespace std;
const int R_LEN=(1<<18)|1;
struct Fast_in{
    char ibuf[R_LEN],*s,*t;
    Fast_io(){s=ibuf,t=ibuf;}
    inline char getc(){
        (s==t)&&(t=(s=ibuf)+fread(ibuf,1,R_LEN,stdin));
        return (s==t)?-1:*s++;
    }
    inline int rd(){
        char ch=getc(); int i=0,f=1;
        while(!isdigit(ch)){if(ch=='-')f=-1;ch=getc();}
        while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getc();}
        return i*f;
    }
    inline Fast_in &operator >>(int &x){x=rd();return *this;}
}in;
typedef long double ld;
const int N=1e5+50,LIM=48,INF=0x3f3f3f3f;
int n,a[N],l[N][LIM+1],r[N][LIM+1];
ld ans;
namespace SP{
	inline void solve(){
		for(int i=1;i<=n;i++){
			ld sum=0,tp=a[i]/2.0;
			for(int j=i;j>=1;j--){
				if(a[j]>a[i]) tp/=2.0;
				sum+=tp;
			} ans+=sum;
			for(int j=i+1;j<=n;j++){
				if(a[j]>=a[i]) sum/=2.0;
				ans+=sum;
			}
		}
		printf("%.10f",(double)(ans/(1ll*n*n)));
	}
}
int mx[N*4];
vector<int>qry_pre[N*(LIM+1)];
vector<int>qry_suf[N*(LIM+1)];
inline void clear(int k,int l,int r){
	mx[k]=-INF; if(l==r)return;
	int mid=(l+r)>>1;
	clear(k<<1,l,mid); clear(k<<1|1,mid+1,r);
}
inline void insert(int k,int l,int r,int p,int v){
	if(l==r){ mx[k]=v; return;}
	int mid=(l+r)>>1;
	(p<=mid)? (insert(k<<1,l,mid,p,v)): (insert(k<<1|1,mid+1,r,p,v));
	mx[k]=max(mx[k<<1],mx[k<<1|1]);
}
inline int query_pre(int k,int l,int r,int v){
	if(l==r){ return (mx[k]>=v)?l:(l-1);}
	int mid=(l+r)>>1;
	return (mx[k<<1|1]>=v)? (query_pre(k<<1|1,mid+1,r,v)): (query_pre(k<<1,l,mid,v));
}
inline int query_suf(int k,int l,int r,int v){
	if(l==r){ return (mx[k]>=v)?l:(l+1);}
	int mid=(l+r)>>1;
	return (mx[k<<1]>=v)? (query_suf(k<<1,l,mid,v)): (query_suf(k<<1|1,mid+1,r,v));
}
inline int pos(int x,int y){
	return x*(n+2)+y;
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	in>>n; for(int i=1;i<=n;i++) in>>a[i];
	if(n<=1500){SP::solve(); return 0;}
	for(int i=2; i<=n; i++) qry_pre[pos(0,i-1)].push_back(i);
	for(int i=0; i<LIM; i++){
		clear(1,1,n);
		for(int j=1; j<=n; j++){
			for(int k=qry_pre[pos(i,j-1)].size()-1; k>=0; k--){
				int v=qry_pre[pos(i,j-1)][k];
				l[v][i]=query_pre(1,1,n,a[v]+1);
				if(l[v][i]>1) qry_pre[pos(i+1,l[v][i]-1)].push_back(v);
			}
			insert(1,1,n,j,a[j]);
		}
	}
	for(int i=n-1; i>=1; i--) qry_suf[pos(0,i+1)].push_back(i);
	for(int i=0; i<LIM; i++){
		clear(1,1,n);
		for(int j=n;j>=1;j--){
			for(int k=qry_suf[pos(i,j+1)].size()-1; k>=0; k--){
				int v=qry_suf[pos(i,j+1)][k];
				r[v][i]=query_suf(1,1,n,a[v]);
				if(r[v][i]<n) qry_suf[pos(i+1,r[v][i]+1)].push_back(v);
			}
			insert(1,1,n,j,a[j]);
		}
	}
	for(int i=1;i<=n;i++){
		ld sum=0,tp=a[i]/2.0; 
		for(int pos=i,cnt=0; pos&&cnt<LIM; pos=l[i][cnt++]){
			sum+=tp*(pos-l[i][cnt]); tp/=2.0;
		}
		for(int pos=i,cnt=0; pos&&pos<=n&&cnt<LIM; pos=r[i][cnt++]){
			ans+=sum*((r[i][cnt]?r[i][cnt]:(n+1))-pos); sum/=2.0;
		}
	}
	printf("%.10f",(double)(ans/(1ll*n*n)));
}
