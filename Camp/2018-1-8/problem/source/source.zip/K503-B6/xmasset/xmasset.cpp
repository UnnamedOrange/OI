#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cctype>
#include<algorithm>
#define rep(i,x,y) for(register int i = x; i <= y; ++ i)
#define repd(i,x,y) for(register int i = x; i >= y; -- i)
using namespace std;
typedef long long ll;
template<typename T>inline void read(T&x)
{
	x = 0;char c;int sign = 1;
	do { c = getchar(); if(c == '-') sign = -1; }while(!isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); }while(isdigit(c));
	x *= sign;
}
inline void init(string name)
{
	string in = name + ".in",out = name + ".out";
	freopen(in.c_str(),"r",stdin);
	freopen(out.c_str(),"w",stdout);
}

int n,t,T;

int find(int x,int y)
{
	int a = x,b = y;
	int len = 0;
	while(x || y)
	{
		++len;
		if((x & 1) && !(y&1)) return len;
		if(!(x & 1) && (y&1)) return len + 10;
		x >>= 1;y >>= 1;
	}

}

inline void solve_()
{
	
	int x,y;
	read(n); read(T);
	rep(i,1,T)
	{
		read(x); read(y);
		printf("%d\n",find(x,y));
	}
}

inline void solve__()
{
	int x,y;
	read(n); read(T);
	rep(i,1,T)
	{
		read(x);read(y);
		
		puts((x&(1<<(y%10)-1))^(y / 10) ? "yes":"no");
		
	}
}

int main()
{
	init("xmasset");
	read(t);
	if(t == 1) solve_();
	else solve__();
	
	return 0;
}
