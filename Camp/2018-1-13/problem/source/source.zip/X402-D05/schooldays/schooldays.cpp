#include<bits/stdc++.h>
using namespace std;
const long long md=1000000007;
const int maxn=1001000;
void chkmax(int &x,int y){
	x=x>y?x:y;
}
void chkmin(int &x,int y){
	x=x<y?x:y;
}
struct node{
	int l,r;
}a[maxn];
void Merge(node &A,node B){
	chkmax(A.l,B.l);
	chkmin(A.r,B.r);
}
bool pd[2010][2010];
int dp[maxn];
long long f[maxn];
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&a[i].l,&a[i].r);
	node st;
	for(int i=1;i<=n;i++){
		st=a[i];
		for(int j=i;j<=n;j++){
			Merge(st,a[j]);
			if(j-i+1>=st.l&&j-i+1<=st.r)
				pd[i][j]=1;
		}
	}
	f[0]=1;
	for(int i=1;i<=n;i++){
		for(int j=0;j<i;j++){
			if(!pd[j+1][i]) continue;
			if(!f[j]) continue;
			if(dp[j]+1>dp[i]){
				dp[i]=dp[j]+1;
				f[i]=f[j];
			}
			else if(dp[j]+1==dp[i])
				f[i]=(f[i]+f[j])%md;
		}
	}
	if(f[n]==0) printf("-1\n");
	else printf("%d %lld\n",dp[n],f[n]);
	return 0;
}
