#include <bits/stdc++.h>
using namespace std;
int main()
{
	int Cnt = 0;
	while (Cnt <= 10000)
	{
		system("./gen");
		system("./string");
		freopen("string.out", "r", stdin);
		int N;
		while (scanf("%d", &N)!= EOF)
			if (N > 2) break;
		printf("No Problem %d times!\n", ++Cnt);
	}
	puts("There is a N > 2 !!!!!");
	return 0;
}
