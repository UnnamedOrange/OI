#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 1000010
#include<vector>
vector<int>t[N];
int n,m,ans,f[N];
int dfs2(int x)
{
	if(f[x])
		return f[x];
	fr(i,0,t[x].size()-1)
		f[x]=max(f[x],dfs2(t[x][i]));
	f[x]++;
	return f[x];
}
int p[N];
void dfs(int x,int th,int w)
{
	if(!p[th])
		w++;
	p[th]++;
	if(x>15)
		return;
	if(w>ans)
		ans=w;
	fr(i,0,t[th].size()-1)
		dfs(x+1,t[th][i],w);
	p[th]--;
}
int main()
{
	freopen("bomb.out","w",stdout);
	freopen("bomb.in","r",stdin);
	n=read();
	m=read();
	fr(i,1,m)
	{
		int u=read(),v=read();
		t[u].push_back(v);
	}
	if(n<=10&&m<=10)
	{
		fr(i,1,n)
			dfs(1,i,0);
		printf("%d\n",ans);
		return 0;
	}
	fr(i,1,n)
		ans=max(ans,dfs2(i));
	printf("%d\n",ans);
	return 0;
}