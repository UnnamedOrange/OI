#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=5000;

int n,m;
int a[N];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("bomb.in","w",stdout);

	n=100000,m=n;
	printf("%d %d\n",n,m);

	for(int i=1;i<=m;i++)
		printf("%d %d\n",rand()%n+1,rand()%n+1);

	return 0;
}
