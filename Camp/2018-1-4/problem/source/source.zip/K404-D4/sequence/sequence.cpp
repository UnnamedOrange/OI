#include <iostream>
#include <cstdio>
using namespace std;
int t, n, a[25], ans;
inline void rev (int x) { for (int i = 1; i <= x / 2; i++) swap (a[i], a[x - i + 1]); }
inline void dfs (int step) {
	if (step >= ans) return;
	int ln = n;
	int maxn = a[1];
	for (int i = 1; i <= n; i++) maxn = max (maxn, a[i]);
	if (a[1] == maxn) {
		int pos = 2;
		while (pos <= n && a[pos] == maxn) pos++;
		if (pos > n) { ans = min (ans, step - 1); return; }
		for (int i = pos; i <= n; i++) if (a[i] == maxn) {
			rev (i - 1);
			dfs (step + 1);
			rev (i - 1);
		}
		rev (n);
		while (n) {
			bool b = true;
			for (int i = 1; i <= n; i++) if (a[n] < a[i]) b = false;
			if (b) n--;
			else break;
		}
		dfs (step + 1);
		n = ln;
		rev (n);
	} else {
		for (int i = 2; i < n; i++) if (a[i] == maxn && a[i] != a[i + 1]) {
			rev (i);
			dfs (step + 1);
			rev (i);
		}
	}
}
inline void solve () {
	scanf ("%d", &n);
	if (n == 1) { printf ("0\n"); return; }
	ans = 2 * n - 3;
	for (int i = 1; i <= n; i++) {
		scanf ("%d", &a[i]);
		//if (a[i] == a[i - 1]) i--, n--;
	}
	while (n) {
		bool b = true;
		for (int i = 1; i <= n; i++) if (a[n] < a[i]) b = false;
		if (b) n--;
		else break;
	}
	dfs (1);
	printf ("%d\n", ans);
}
int main () {
	freopen ("sequence.in", "r", stdin);
	freopen ("sequence.out", "w", stdout);
	scanf ("%d", &t);
	while (t--) solve ();
	return 0;
}
