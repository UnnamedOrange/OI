#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar(); 
	return ret;
}int u,v,cu,cv,a[100];;

int main()
{
	freopen("2.out","w",stdout);
	a[0]=1;
	for(int i=1; i<=9; ++i)a[i]=a[i-1]<<1; 
	for(int i=1; i<=919; ++i)
	for(int j=i+1; j<=920; ++j)
	{
		u=i;
		v=j;
		cu=0;
		cv=0;
		for(int k=9; k>=0; --k)if(u>=a[k])
		{
			u-=a[k];
			++cu;
		}
		for(int k=9; k>=0; --k)if(v>=a[k])
		{
			v-=a[k];
			++cv;
		}
		if(cu!=cv)continue;
		if(i%81==j%81)
		{
			printf("%d %d\n",i,j);
		}
	}
}

