#include <bits/stdc++.h>
using namespace std;

int type, N;

void init() {
}

int encode(int x, int y) {
	int res = 0, c;
	for(c = 0; c < 10; c++) 
		if(((x>>c)&1)^((y>>c)&1)) break;
	res = c*2+((x>>c)&1)+1;
    return res;
}

bool decode(int q, int h) {
	int c = (h-1)/2, p = (h-1)%2;
	return ((q>>c)&1) == p;
}

int main() {
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
	return 0;
}
