#include <bits/stdc++.h>
using namespace std;

const int Maxn = 33;

int T, n, x[Maxn], limit;

bool dfs(int dep) {
	if (dep > limit) {
		for (int i = 1; i <= n; ++i) {
			if (x[i] != i) {
				return false;
			}
		}
		return true;
	} else {
		for (int i = 2; i <= n; ++i) {
			reverse(x+1, x+i+1);
			if (dfs(dep+1)) {
				return true;
			}
			reverse(x+1, x+i+1);
		}
	}
	return false;
}

int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	cin >> T;
	while (T--) {
		cin >> n;
		for (int i = 1; i <= n; ++i) {
			cin >> x[i];
		}
		int ans = 2*n-1;
		for (limit = 1; limit < ans; ++limit) {
			if (dfs(1)) {
				ans = limit;
				break;
			}
		}
		cout << ans << endl;
	}
	return 0;
}
