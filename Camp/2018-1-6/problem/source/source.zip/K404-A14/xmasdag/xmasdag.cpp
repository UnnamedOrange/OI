#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int mod=998244353;
const int N=100010,M=510;
struct node{
	int to,next;
};node edge[N*2*2];
int graph[N],tot;
int q[N],h,t;
int s[M][M],dp[N][M],f[N];int in[N];

void addedge(int i,int x,int y){
	edge[i].to=y;edge[i].next=graph[x];graph[x]=i;
}

int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	int n,m,K;
	register int i,j,x,y;
	scanf("%d%d%d",&n,&m,&K);
	rep(i,1,m){
		scanf("%d%d",&x,&y);
		tot++;addedge(tot,x,y);
		in[y]++;
	}
	dp[1][0]=1;
	rep(i,1,n)	if(!in[i])	q[++t]=i;
	while(h<t){
		x=q[++h];
		for(i=graph[x];i;i=edge[i].next){
			y=edge[i].to;
			(dp[y][0]+=dp[x][0])%=mod;
			rep(j,1,K)	dp[y][j]=(dp[y][j]+dp[x][j]+1ll*j*dp[x][j-1])%mod;
			in[y]--;
			if(!in[y])	q[++t]=y;
		}
	}
	s[0][0]=1;
	rep(i,1,K)	rep(j,1,i) s[i][j]=(s[i-1][j-1]+1ll*j*s[i-1][j])%mod;
	rep(i,1,n)	rep(j,0,K)	f[i]=(f[i]+1ll*dp[i][j]*s[K][j])%mod;
	rep(i,1,n)	printf("%d\n",f[i]);
}
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
