#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define ll long long
#define N 100010
char s[10][1005];
int n,m,len[10];
namespace sub1
{
	int ans;
	bool p[33];
	bool cck(int x)
	{
		for(int i=1;i<=m*2;i++)
		{
			int j,k;
			for(j=1,k=i;j<=len[x]&&k<=m*2;j++,k++)
				if(p[k]!=s[x][j]-'0') break;
			if(j>len[x]) return 1;
		}
		return 0;
	}
	bool ck(int x)
	{
		for(int i=0;i<m;i++)
		{
			p[i+1]=(x&(1<<i))?1:0;
			p[2*m-i]=p[i+1]^1;
		}
		for(int i=1;i<=n;i++)
			if(!cck(i)) return 0;
		return 1;
	}
	void Main()
	{
		for(int i=0;i<(1<<m);i++)
			if(ck(i)) ans++;
		printf("%d\n",ans);
	}
};
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s[i]+1);
		len[i]=strlen(s[i]+1);
	}
	if(m<=15) sub1::Main();
	return 0;
}