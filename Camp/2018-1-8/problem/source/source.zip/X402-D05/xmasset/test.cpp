#include<bits/stdc++.h>
using namespace std;
int C[100][100];
int main(){
	printf("%d\n",12*11*10*9*8*7/(6*5*4*3*2));
	return 0;
}
