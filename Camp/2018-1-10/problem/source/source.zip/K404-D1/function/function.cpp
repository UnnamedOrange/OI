#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define N 1000010
#define ll long long
using namespace std;
int t,n,i_,tot;
int cnt[N],num[N],prime[N];
bool mark[N];
long long now,ans[N];
void pre()
{
    for(int i=2; i<=1000000; i++)
    {
        if(!mark[i])
            prime[++tot]=i;
        for(int j=1; j<=tot&&i*prime[j]<=1000000; j++)
        {
            mark[i*prime[j]]=true;
            if(i%prime[j]==0)
                break;
        }
    }
    cnt[1]=1;
    for(int i=2; i<=1000000; i++)
    {
        int ret=1,x=i;
        for(int j=1; ; j++)
        {
            if(!mark[x])
            {
                ret<<=1;
                break;
            }
            if(x%prime[j]==0)
            {
                int CNT=0;
                while(x%prime[j]==0)
                {
                    CNT++;
                    x/=prime[j];
                }
                ret*=(CNT+1);
                if(x==1)
                    break;
            }
        }
        cnt[i]=ret;
    }
}
void dfs(int id,int pos,int sum)
{
    if(pos==tot+1)
    {
        now+=(ll)id*cnt[i_/sum]*cnt[i_/sum];
        return;
    }
    dfs(id,pos+1,sum);
    dfs(-id,pos+1,sum*num[pos]);
}
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("function.in","r",stdin);
    freopen("function.out","w",stdout);
    pre();
    ans[1]=1;
    for(int i=2; i<=1000000; i++)
    {
        int x=i;
        tot=0;
        for(int j=1; ; j++)
        {
            if(!mark[x])
            {
                num[++tot]=x;
                break;
            }
            if(x%prime[j]==0)
            {
                num[++tot]=prime[j];
                while(x%prime[j]==0)
                    x/=prime[j];
                if(x==1)
                    break;
            }
        }
        i_=i;
        now=0;
        dfs(1,1,1);
        ans[i]=ans[i-1]+now;
    }
    t=read();
    while(t--)
    {
        n=read();
        printf("%lld\n",ans[n]);
    }
    return 0;
}
