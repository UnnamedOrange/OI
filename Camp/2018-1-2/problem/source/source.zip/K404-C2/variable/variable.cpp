#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
const int N=1005;
typedef long long LL;
int n,W,w[N],p,q,a[N],b[N],c[N],x[N],y[N],z[N],d[N],e[N],f[N];
struct data{int tp,x,y;} dat[N];
LL ans;

int getint()
{
	char ch;
	int f=1;
	while(!isdigit(ch=getchar())) if(ch=='-') f=-1;
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

bool check()
{
	rep(i,1,q)
	{
		int x=w[dat[i].x],y=w[dat[i].y];
		if(dat[i].tp==0 && x>y) return 0;
		if(dat[i].tp==1 && x!=y) return 0;
		if(dat[i].tp==2 && x>=y) return 0;
	}
	return 1;
}

LL query()
{
	LL rt=0;
	rep(i,1,p)
	{
		LL A=w[x[i]]-w[y[i]],B=w[y[i]]-w[z[i]],C=w[z[i]]-w[x[i]];
		rt+=a[i]*abs(A)+b[i]*abs(B)+c[i]*abs(C)+d[i]*A+e[i]*B+f[i]*C;
	}
	rep(i,1,n) rt+=w[i];
	return rt;
}

void task1()
{
	ans=1ll<<62;
	rep(i,1,p)
	{
		x[i]=getint(),y[i]=getint(),z[i]=getint();
		a[i]=getint(),b[i]=getint(),c[i]=getint();
		d[i]=getint(),e[i]=getint(),f[i]=getint();
	}
	rep(i,1,q) dat[i].x=getint(),dat[i].y=getint(),dat[i].tp=getint();
	rep(i,0,(1<<n)-1)
	{
		rep(j,1,n) if(i&(1<<j-1)) w[j]=W; else w[j]=-W;
		if(check()) ans=min(ans,query());
	}
	printf("%lld\n",ans);
}

void solve()
{
	n=getint(),W=abs(getint()),p=getint(),q=getint();
	if(n<=15 && p<=20 && q<=20) task1();
}		
	
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	for(int T=getint(); T--; solve());
	return 0;
}	
