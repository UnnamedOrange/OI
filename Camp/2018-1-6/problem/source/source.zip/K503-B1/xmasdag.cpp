#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
const int mod=998244353;
int T,opt,n,m,x,y,a[maxn],getcs[510][510];
int i,j,k,ans,anss[maxn],dp[maxn][40];
int r,f1[maxn],f2[maxn],f3[maxn],ha[maxn];
int mp[2010][2010];
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void tuobu(){
	int i,j,ll=1,rr=0;
	for (i=1;i<=n;i++){
		if (ha[i]==0){
			rr++; a[rr]=i;
		}
	}
	memset(mp,0,sizeof(mp));
	mp[1][0]=1;
	while (ll<=rr){
		i=f1[a[ll]];
		while (i!=0){
			for (j=1;j<=n;j++){
				mp[f2[i]][j]=(mp[f2[i]][j]+mp[a[ll]][j-1])%mod;
			}
			ha[f2[i]]--;
			if (ha[f2[i]]==0){
				rr++; a[rr]=f2[i];
			}
			i=f3[i];
		}
		ll++;
	}
}
void getcc(){
	int i,j;
	getcs[0][0]=1;
	for (i=1;i<=n;i++){
		for (j=0;j<=i;j++){
			getcs[i][j]=getcs[i-1][j];
			if (j!=0) getcs[i][j]=(getcs[i][j]+getcs[i-1][j-1])%mod;
		}
	}
}
void tuobu2(){
	int i,j,jj,ll=1,rr=0;
	for (i=1;i<=n;i++){
		if (ha[i]==0){
			rr++; a[rr]=i;
		}
	}
	memset(dp,0,sizeof(dp));
	dp[1][0]=1;
	while (ll<=rr){
		i=f1[a[ll]];
		while (i!=0){
			dp[f2[i]][0]=(dp[f2[i]][0]+dp[a[ll]][0])%mod;
			for (j=1;j<=k;j++){
				for (jj=0;jj<=j;jj++){
					dp[f2[i]][j]=(dp[f2[i]][j]+getcs[j][jj]*dp[a[ll]][jj])%mod;
				}
			}
			ha[f2[i]]--;
			if (ha[f2[i]]==0){
				rr++; a[rr]=f2[i];
			}
			i=f3[i];
		}
		ll++;
	}
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read(); m=read(); k=read();
	for (i=1;i<=n;i++){
		anss[i]=1;
		for (j=1;j<=k;j++){
			anss[i]=(anss[i]*i)%mod;
		}
	}
	r=0; memset(f1,0,sizeof(f1));
	for (i=1;i<=m;i++){
		x=read(); y=read();
		r++; f2[r]=y; f3[r]=f1[x]; f1[x]=r;
		ha[y]++;
	}
	if (k>30){
		tuobu();
		for (i=1;i<=n;i++){
			ans=0;
			for (j=1;j<=n;j++){
				ans=(ans+mp[i][j]*anss[j])%mod;
			}
			printf("%d\n",ans);
		}
	}
	else{
		getcc();
		tuobu2();
		for (i=1;i<=n;i++){
			printf("%d\n",dp[i][k]);
		}
	}
	return 0;
}
