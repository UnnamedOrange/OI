#include <bits/stdc++.h>
using namespace std;
const int MAXN = 100, MOD = 998244353;
int N, K, Ans, G[MAXN+10][MAXN+10];

int dfs_clock, Dfn[MAXN+10];
bool Dfs2(int u) {
	//cout<<' '<<u<<endl;
	Dfn[u] = ++dfs_clock;
	for(int v=1; v<=N; v++) if(G[u][v]){
		if(Dfn[v]) {
			if(Dfn[u] - Dfn[v] + 1 == K) 
				return true;
		} else return Dfs2(v);
	}
	Dfn[u] = 0;
	return false;
}

void ShowMap() {
	//for(int i=1; i<=N; i++) {
	//	for(int j=1; j<=N; j++) printf("%d ", G[i][j]);
	//	putchar(10);
	//}
	//putchar(10);
}

void judge() {
	dfs_clock = 0;
	for(int i=1; i<=N; i++)
		for(int j=1; j<=N; j++)
			if(i!=j && ((G[i][j] ^ G[j][i]) == 0)) return;
	for(int i=1; i<=N; i++) {
		memset(Dfn, 0, sizeof(Dfn));
		if(Dfs2(i)) {
			//cout<<i<<endl;
			Ans++; Ans%=MOD;
			ShowMap();
			break;
		}
	}
}

void Dfs1(int u, int v) {
	if(u>N || v>N) judge();
	else if(v<=u) Dfs1(u, v+1);
	else {
		G[u][v] = 1; G[v][u] = 0;
		if(v==N) Dfs1(u+1, 1);
		else Dfs1(u, v+1);
		G[u][v] = 0; G[v][u] = 1;
		if(v==N) Dfs1(u+1, 1);
		else Dfs1(u, v+1);
	}
}

int main() {
#ifndef DEBUG
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
#endif
	scanf("%d%d", &N, &K);
	Dfs1(1, 1);
	printf("%d", Ans);
	return 0;
}
