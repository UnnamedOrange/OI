#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<set>
#define pii pair<int,int>
#define fs first
#define sc second
using namespace std;
const int maxn=1000010;
const int R=32;
int n,l[R+5],r[R+5];
pii w[maxn];
set<int> a;
double mi[R+5],ans=0;
int read()
{
	int x=0;char ch;
	for(ch=getchar();ch<'0'&&ch>'9';ch=getchar());
	for(;ch>='0'&&ch<='9';ch=getchar())x=x*10+ch-'0';
	return x;
}
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) w[i].fs=read(),w[i].sc=i;
	mi[0]=1;
	for(int i=1;i<=R;i++) mi[i]=mi[i-1]/2.0;
	sort(w+1,w+n+1);
	for(int i=n;i;i--)
	{
		a.insert(w[i].sc);
		//cout<<"ins:"<<w[i].fs<<' '<<w[i].sc<<endl;
		set<int>::iterator now=a.find(w[i].sc),lt=now,rt=now;rt++;
		int ltop=0,rtop=0;
		for(int j=1;j<=R;j++)
		{
			if(lt!=a.begin())l[++ltop]=*(--lt);
			if(rt!=a.end())r[++rtop]=*(rt++);	
		}
//		cout<<"top:"<<ltop<<' '<<rtop<<endl;
			
		l[0]=r[0]=w[i].sc;l[ltop+1]=0;r[rtop+1]=n+1;
//		for(int j=0;j<=ltop+1;j++)
//			cout<<l[j]<<' ';
//		cout<<endl;
//		for(int j=0;j<=rtop+1;j++)
//			cout<<r[j]<<' ';
//		cout<<endl;	
		for(int j=1;j<=ltop+1;j++)
			for(int k=1;k<=min(R-j,rtop)+1;k++)
				ans+=mi[j+k-1]*(l[j-1]-l[j])*(r[k]-r[k-1])*w[i].fs;
		//cout<<"ans:"<<ans<<endl;			
	}
	printf("%.10lf",ans/n/n);
	return 0;
}
/*5
1 2 3 4 1*/
