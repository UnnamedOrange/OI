#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 500005, P = 1000000009;
int n, m, lst[N], f[N];
ll data[4 * N], lazy[4 * N];
struct interval{
	int l, r;
	bool operator < (const interval &b) const{
		return l < b.l;
	}
} a[N];

void build(int k, int l, int r){
	lazy[k] = 1;
	if(l == r) return;
	int mid = (l + r) >> 1;
	build(k << 1, l, mid);
	build(k << 1 | 1, mid + 1, r);
}
void pushdown(int k){
	if(lazy[k] == 1) return;
	lazy[k << 1] = lazy[k << 1] * lazy[k] % P;
	lazy[k << 1 | 1] = lazy[k << 1 | 1] * lazy[k] % P;
	data[k << 1] = data[k << 1] * lazy[k] % P;
	data[k << 1 | 1] = data[k << 1 | 1] * lazy[k] % P;
	lazy[k] = 1;
}
void mul(int k, int l, int r, int ql, int qr){
	if(ql <= l && qr >= r){
		lazy[k] = lazy[k] * 2 % P;
		data[k] = data[k] * 2 % P;
		return;
	}
	pushdown(k);
	int mid = (l + r) >> 1;
	if(ql <= mid) mul(k << 1, l, mid, ql, qr);
	if(qr > mid) mul(k << 1 | 1, mid + 1, r, ql, qr);
	data[k] = (data[k << 1] + data[k << 1 | 1]) % P;
}
void add(int k, int l, int r, int p, int x){
	if(l == r) return (void)(data[k] = (data[k] + x) % P);
	pushdown(k);
	int mid = (l + r) >> 1;
	if(p <= mid) add(k << 1, l, mid, p, x);
	else add(k << 1 | 1, mid + 1, r, p, x);
	data[k] = (data[k << 1] + data[k << 1 | 1]) % P;
}
int query(int k, int l, int r, int ql, int qr){
	if(ql <= l && qr >= r) return data[k];
	pushdown(k);
	int mid = (l + r) >> 1, ret = 0;
	if(ql <= mid) ret += query(k << 1, l, mid, ql, qr);
	if(qr > mid) ret += query(k << 1 | 1, mid + 1, r, ql, qr);
	return ret % P;
}

int main(){
	
	//freopen("xmasinterval.in", "r", stdin);
	//freopen("xmasinterval.out", "w", stdout);
	
	read(n), read(m);
	for(int i = 1; i <= n; i++)
		read(a[i].l), read(a[i].r);
	for(int i = 1; i <= m; i++)
		read(lst[i]);
	sort(lst + 1, lst + m + 1);
	m = unique(lst + 1, lst + m + 1) - lst - 1;
	for(int i = 1; i <= n; i++){
		a[i].l = lower_bound(lst + 1, lst + m + 1, a[i].l) - lst;
		a[i].r = upper_bound(lst + 1, lst + m + 1, a[i].r) - lst - 1;
	}
	sort(a + 1, a + n + 1);
	/*
	f[0] = 1;
	for(int i = 1; i <= n; i++){
		for(int j = a[i].r; j >= a[i].l - 1; j--)
			f[a[i].r] += f[j];
		for(int j = a[i].r + 1; j <= m; j++)
			f[j] += f[j];
//		for(int j = 0; j <= m; j++)
//			printf("f[%d][%d] = %d\n", i, j, f[j]);
	}
	write(f[m]), enter;
	*/
	build(1, 1, m + 1);
	add(1, 1, m + 1, 1, 1);
	for(int i = 1; i <= n; i++){
		//printf("l = %d, query = %d\n", a[i].l, query(1, 1, m + 1, a[i].l, a[i].r + 1));
		add(1, 1, m + 1, a[i].r + 1, query(1, 1, m + 1, a[i].l, a[i].r + 1));
		if(a[i].r + 1 <= m) mul(1, 1, m + 1, a[i].r + 2, m + 1);
	}
	write(query(1, 1, m + 1, m + 1, m + 1));
	
	return 0;
}
/*
2 4
2 3
1 4
1 2 3 4

2 3
1 2
2 3
1 2 3
*/
