#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<set>
#include<queue>
#define ll long long
using namespace std;
const int mod=998244353;
queue<int> q;
int read()
{
	char ch=getchar();int x=0,f=1;
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int head[100005],du[100005],tot;
struct node
{
	int from;
	int to;
	int next;
}edge[500005];
void add(int u,int v)
{
	edge[tot].from=u;
	edge[tot].to=v;
	edge[tot].next=head[u];
	head[u]=tot++;
}
int n,f[5005][5005],m,k;
ll g[100005],h[100005];
void topsort()
{
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		for(int i=head[x];i!=-1;i=edge[i].next)
		{
			int y=edge[i].to;
			for(int j=0;j<=n;j++)
			{
				f[y][j+1]+=f[x][j];
				f[y][j+1]%=mod;
			}
			du[y]--;
			if(!du[y])
			q.push(y);
		}
	}
}
void topsort2()
{
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		for(int i=head[x];i!=-1;i=edge[i].next)
		{
			int y=edge[i].to;
			g[y]+=g[x];
			g[y]%=mod;
			h[y]+=(h[x]+g[x])%mod;
			h[y]%=mod;
			du[y]--;
			if(!du[y])
			q.push(y);
		}
	}
}
ll quick_mod(ll x,int y)
{
	ll ret=1;
	while(y)
	{
		if(y&1) ret=ret*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return ret;
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	memset(head,-1,sizeof(head));
	f[1][0]=1;
	n=read();m=read();k=read();
	for(int i=1;i<=m;i++)
	{
		int u=read(),v=read();
		add(u,v);
		du[v]++;
	}
	if(k==1)
	{
		g[1]=1;
		h[1]=0;
		for(int i=1;i<=n;i++)
		{
			if(!du[i])
			q.push(i);
		}
		topsort2();
		for(int i=1;i<=n;i++)
		{
			printf("%lld\n",h[i]);
		}
	}
	else
	{
		for(int i=1;i<=n;i++)
		{
			if(!du[i])
			q.push(i);
		}
		topsort();
		for(int i=1;i<=n;i++)
		{
			ll ans=0;
			for(int j=1;j<=n;j++)
			{
				ans+=quick_mod(j,k)*f[i][j];
			}
			printf("%lld\n",ans);
		}
	}
}
/*
6 8 1
1 2
1 3
1 5
2 4
3 2
3 4
3 6
4 6
*/
