#include<bits/stdc++.h>
using namespace std;

const int MAXN = 4010;
const int INF = 1000000000;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, K;
int a[MAXN], b[MAXN];
int nxa[MAXN][MAXN];
int nxb[MAXN][MAXN];
int dp[MAXN][MAXN];

inline void chkmin(int &cur, int val) {
	if(val < cur) cur = val;
}

int main() {
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);

	int i, j, k;

	n = read(), m = read(), K = read();
	for(i = 1; i <= n; i++) a[i] = read();
	for(i = 1; i <= m; i++) b[i] = read();
	for(j = 1; j <= K; j++) nxa[n+1][j] = n+1;
	for(i = n; i >= 0; i--) 
		for(j = 1; j <= K; j++) {
			nxa[i][j] = nxa[i+1][j];
			if(a[i+1] == j) nxa[i][j] = i+1;
		}
	for(j = 1; j <= K; j++) nxb[m+1][j] = m+1;
	for(i = m; i >= 0; i--)
		for(j = 1; j <= K; j++) {
			nxb[i][j] = nxb[i+1][j];
			if(b[i+1] == j) nxb[i][j] = i+1;
		}
	for(i = 0; i <= n+1; i++)
		for(j = 0; j <= m+1; j++) dp[i][j] = INF;
	/*for(i = 0; i <= n; i++) {
		for(j = 1; j <= K; j++) printf("%d ", nxa[i][j]);
		printf("\n");
	}
	printf("\n");
	for(i = 0; i <= m; i++) {
		for(j = 1; j <= K; j++) printf("%d ", nxb[i][j]);
		printf("\n");
	}*/
	dp[0][0] = 0;
	for(i = 0; i <= n+1; i++)
		for(j = 0; j <= m+1; j++) {
			if(i == n+1 && j == m+1) continue;
			if(dp[i][j] == INF) continue;
			for(k = 1; k <= K; k++) 
				chkmin(dp[nxa[i][k]][nxb[j][k]], dp[i][j]+1);
		}
	printf("%d\n", dp[n+1][m+1]);
	return 0;
}
