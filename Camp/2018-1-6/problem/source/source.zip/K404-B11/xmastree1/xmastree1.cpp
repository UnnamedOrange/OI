#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

const int maxn=100010;
int n,q,t,k=0,last=0,root=1,head[maxn];
bool vis[maxn];
struct tree{
	int fa,co;
}a[maxn];
struct edge{
	int u,v,next;
}e[maxn*2];
inline void add(int u,int v){
	e[++k]=(edge){u,v,head[u]};
	head[u]=k;
}

void find_fa(int u){
	if(u==1)a[u].fa=1;
	for(int i=head[u];i;i=e[i].next)
	  if(e[i].v!=a[u].fa)
	    a[e[i].v].fa=u,find_fa(e[i].v);
}

void dfs(int u){
	vis[a[u].co]=1;
	for(int i=head[u];i;i=e[i].next)
	  if(e[i].v!=a[u].fa)
	    dfs(e[i].v);
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int u,v,x,l,r,c,ans;
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++)scanf("%d",&a[i].co);
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		if(u!=v)add(u,v),add(v,u);
	}
	find_fa(1);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&x,&u);
		if(x==1){
			ans=0;
			scanf("%d%d",&l,&r);
			if(t==1)u=u^last,l=l^last,r=r^last;
			memset(vis,0,sizeof(vis));
			dfs(u);
			for(int i=l;i<=r;i++)
			  if(vis[i])
			    ans++;
			printf("%d\n",ans);
			last=ans;
		}
		else scanf("%d",&c),a[u].co=c;
	}
	return 0;
}
