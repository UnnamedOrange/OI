#include <map>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

#define ret return

const int N = 1000000 + 10000;

int n, m;
struct edge{
	int f, t;
}e[N];
int color[N], dfn[N], size[N], tot = 0, status = 0;
vector<int> g[N];
int In[N], Out[N], f[N], ans = 0;
bool vis[N];

inline void open()
{
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	ret;
}

inline void close()
{
	fclose(stdin);
	fclose(stdout);
	ret;
}

inline int read()
{
	int a = 0;
	char ch;
	int f = 1;
	while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
	if(ch == '-')
		f = -1;
	else
	{
		a = a * 10;
		a += ch - '0';
	}
	while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
	{
		a = a * 10;
		a += ch - '0';
	}
	ret a * f;
}

inline void input()
{
	n = read(), m = read();
	for(int i = 1;i <= m;++i)
		e[i].f = read(), e[i].t = read();
}

inline void dfs(int p)
{
	vis[p] = 1;
	int s = g[p].size();
	for(int i = 0;i < s;++i)
		if(!vis[g[p][i]])
			dfs(g[p][i]);
	if(status == 0)
		dfn[++tot] = p;
	else
		color[p] = tot, ++size[tot];
}

inline void paint()
{
	memset(vis, 0, sizeof vis);
	for(int i = 1;i <= m;++i)
		g[e[i].t].push_back(e[i].f);
	for(int i = 1;i <= n;++i)
		if(!vis[i])
			dfs(i);
	tot = 0, status = 1;
	for(int i = 1;i <= n;++i)
		g[i].clear();
	for(int i = 1;i <= m;++i)
		g[e[i].f].push_back(e[i].t);
	memset(vis, 0, sizeof vis);
	for(int i = n;i >= 1;--i)
		if(!color[dfn[i]])
			++tot, dfs(dfn[i]);
	ret;
}

inline void solve()
{
	for(int i = 1;i <= n;++i)
		g[i].clear();
	for(int i = 1;i <= m;++i)
	{
		int f = e[i].f, t = e[i].t;
		if(color[f] != color[t])
			g[color[f]].push_back(color[t]), ++Out[color[f]], ++In[color[t]];
	}
	queue<int> q;
	for(int i = 1;i <= tot;++i)
		if(!In[i])
			q.push(i), f[i] = size[i];
	while(q.size() > 0)
	{
		int fr = q.front();q.pop();
		int s = g[fr].size();
		for(int i = 0;i < s;++i)
		{
			int t = g[fr][i];
			f[t] = max(f[t], f[fr] + size[t]);
			--In[t];
			if(!In[t])
				q.push(t);
		}
		if(s == 0)
			ans = max(ans, f[fr]);
	}
	printf("%d\n", ans);
	ret;
}

int main()
{
	open();
	input();
	paint();
	solve();
	close();
	ret 0;
}
