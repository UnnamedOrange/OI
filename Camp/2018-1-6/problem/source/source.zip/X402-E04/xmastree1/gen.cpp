#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;

int main(){
	freopen("xmastree1.in","w",stdout);
	int n=100000,q=100000,t=0;
	printf("%d %d %d\n",n,q,t);
	For(i,1,n)printf("%d ",rand()%n+1);puts("");
	For(i,1,q){
		int tp=1,u=rand()%n+1,l=rand()%n+1,r=rand()%n+1;
		printf("%d %d %d %d\n",tp,u,l,r);
	}
	return 0;
}
