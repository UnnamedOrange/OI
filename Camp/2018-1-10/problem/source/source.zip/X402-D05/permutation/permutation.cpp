#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=400100;
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int nx[maxn];
int vis[maxn];
int gt[maxn],isline[maxn];
int getzt(int ps){
	int p=ps,zt=0;
	while(p&&!vis[p]){
		vis[p]=ps;
		p=nx[p];
		zt^=1;
	}
	if(p==0){
		gt[ps]=zt;
		isline[ps]=1;
	}
	else if(vis[p]!=ps){
		gt[vis[p]]^=zt;

		int clr=vis[p];
		p=ps;
		while(vis[p]!=clr){
			vis[p]=clr;
			p=nx[p];
		}
	}
	else{
		if(zt==1) return -1;
		return 0;
	}
	return 1;
}
long long solve(int n){
	if(n&1) return 0;
	long long res=1;
	for(int i=1;i<=n;i++)
		if(i&1)
			res=res*i%md;
	return res*res%md;
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int n;
	scanf("%d",&n);
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;i++){
		scanf("%d",&nx[i]);
		if(nx[i]){
			if(vis[nx[i]]){
				printf("0\n");
				return 0;
			}
			vis[nx[i]]=1;
		}
	}
	memset(vis,0,sizeof(vis));
	int v;
	int cnt1=0,cnt2=0;
	for(int i=1;i<=n;i++){
		if(vis[i]) continue;
		v=getzt(i);
		if(v==0) continue;
		if(v==-1){
			printf("0\n");
			return 0;
		}
	}
	for(int i=1;i<=n;i++){
		if(isline[i]){
			if(gt[i]==0) cnt2++;
			else cnt1++;
		}
	}
	long long ans=solve(cnt1);
	for(int i=1;i<=cnt2;i++)
		ans=ans*(cnt1+i)%md;
	printf("%lld\n",ans);
	return 0;
}
