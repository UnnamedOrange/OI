#include<iostream>
#include<assert.h>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int N=100009;
const int md=1e9+7;

int n,a[2];
int x[N],s[N],ans[4];

inline void chk(int &a)
{
	if(a>=md)a-=md;
}

inline int play()
{
	for(int i=1;i<=n;i++)
	{
		if(s[i]%(a[0]+a[1])==a[0])
			return 0;
	}
	if(sum%(a[0]+a[1])<a[0])
		return 3;
	else if(sum%(a[0]+a[1])==a[0])
		return 0;
	else
		return 2;
}

inline void dfs(int pos,int sum)
{
	if(pos==n+1)
	{
		ans[play()]++;
		return;
	}

	s[pos]=x[pos];
	dfs(pos+1);
	s[pos]=0;
	dfs(pos+1);
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);

	scanf("%d%d%d",&n,&a[0],&a[1]);
	bool flag=0;
	if(a[0]>a[1])swap(a[0],a[1]),flag=1;
	for(int i=1;i<=n;i++)
		scanf("%d",&x[i]);
	dfs(1,0);
	if(flag)swap(ans[0],ans[1]);
	for(int i=0;i<=3;i++)
		printf("%d\n",ans[i]);
	return 0;
}
