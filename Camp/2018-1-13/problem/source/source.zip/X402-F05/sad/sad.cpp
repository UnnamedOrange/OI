#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

typedef long long LL;

const int N = 2e5 + 10;
const int Mod = 998244353;

LL Pow(LL x, LL e){
	LL ret = 1;
	while(e){
		if(e & 1) ret = ret * x % Mod;
		x = x * x % Mod;
		e >>= 1;
	}
	return ret;
}

int Begin[N], Next[N], to[N], deg[N], e;

void add(int u, int v){
	++deg[u];
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int col[N], n;

struct Num{
	int x, y;

	Num(int _x = 0, int _y = 0):x(_x), y(_y){}
};

namespace Solver1{

	Num DFS(int o, int f = 0){
		Num val;
		for(int i = Begin[o]; i; i = Next[i]){
			int u = to[i];
			if(u == f) continue;
			if(deg[u] == 1) ++val.y;
			else{
				Num v = DFS(u, o);
				val.x += v.x, val.y += v.y;
			}
		}

		LL coe = Pow((deg[o] - val.x + Mod) % Mod, Mod - 2);
		if(o != 1) return Num(coe, coe * (val.y + (col[o] * deg[o])) % Mod);
		else return Num(0, coe * (val.y + (col[o] * deg[o])) % Mod);
	}

	int main(){
		Num ans = DFS(1);
		return ans.y;
	}

};

namespace Solver2{
	
	Num DFS(int o, int f = 0){
		Num val;
		for(int i = Begin[o]; i; i = Next[i]){
			int u = to[i];
			if(u == f || deg[u] == 1) continue;
			if(!col[u]) ++val.y;
			Num v = DFS(u, o);
			val.x += v.x, val.y += v.y;
		}

		LL coe = Pow((deg[o] - val.x + Mod) % Mod, Mod - 2);
		if(o != 1) return Num(coe, coe * val.y % Mod);
		else return Num(0, coe * val.y % Mod);
	}

	int main(){
		Num ans = DFS(1);
		return ans.y + !col[1];
	}
};

int main(){

	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);

	scanf("%d", &n);

	int ty = 0;
	For(i, 1, n) scanf("%1d", &col[i]), ty |= 1 << col[i];

	For(i, 2, n){
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}
	For(i, 1, n) if(deg[i] == 1 && !col[i]) col[i] = 1;

	int ans = Solver1::main();
	if(ty == 2){
		printf("%d\n", ans);
		return 0;
	}

	ans += Solver2::main();
	printf("%d\n", ans % Mod);

	return 0;
}
