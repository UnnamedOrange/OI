#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;
typedef long long ll;
const int mod = 998244353;
int ch[1205][2], fail[1205], pos[1205], pos2[1205], fa[1205], sz = 1;
int v[1205][15], tp[1205], v2[1205][15], tp2[1205], g[1205];
int n, m;
char s[7][105];
int le[7];
void ins(int x){
	int p = 1;
	int len = strlen(s[x] + 1);
	for(int i = 1; i <= len; i ++){
		int t = s[x][i] - '0';
		if(!ch[p][t]) ch[p][t] = ++sz;
		fa[ch[p][t]] = p;
		p = ch[p][t];
	}
	pos[p] = x;
	p = 1;
	for(int i = len; i >= 1; i --){
		int t = s[x][i] - '0';
		t = t  ^ 1;
		if(!ch[p][t]) ch[p][t] = ++sz;
		fa[ch[p][t]] = p;
		p = ch[p][t];
	}
	pos2[p] = x;
}

void buildfail(){
	queue<int> q;
	q.push(1);
	while(!q.empty()){
		int x = q.front();
		q.pop();
		for(int i = 0; i < 2; i ++){
			if(ch[x][i] == 0) continue;
			int k = fail[x];
			while(!ch[k][i]) k = fail[k];
			fail[ch[x][i]] = ch[k][i];
			q.push(ch[x][i]);
		}
	}
}

int f[501][1201][1 << 6];
int main(){
    freopen("string.in", "r", stdin);
    freopen("string.out", "w", stdout);
	ch[0][0] = ch[0][1] = 1;
	int tn;
	scanf("%d%d", &tn, &m);
	for(int i = 1; i <= tn; i ++){
		n++;
		memset(s[n], 0, sizeof(s[n]));
		scanf("%s", s[n] + 1);
		le[n] = strlen(s[n] + 1);
		int flag = 1;
		for(int j = 1; j < n; j ++){
			if(le[n] != le[j]) continue;
			int fflag = 1;
			for(int k = 1; k <= le[n]; k ++){
				if(s[n][k] != s[j][k]){
					 fflag = 0;
					 break;
				}
			}
			if(fflag == 1){
				flag = 0;
				break;
			}
		}
		if(flag == 0) n--;
		else ins(n);
	}
	buildfail();
	for(int i = 1; i <= sz; i ++){
		int t = i;
		while(t != 1){
			if(pos[t]) v[i][++tp[i]] = pos[t];
			if(pos2[t]) v2[i][++tp2[i]] = pos2[t];
			t = fail[t];
		}
	}
//	for(int i = 1; i <= sz; i ++){
//		for(int j = 1; j <= tp[i]; j ++){
//			printf("%d ", v[i][j]);
//		}
//		printf("   %d\n", i);
//	}
	for(int i = 1; i <= sz; i ++){
		int t = i, rt = i;
		for(int j = 1; j <= tp[i]; j ++){
			g[i] |= (1 << (v[i][j] - 1));
		}
		while(rt != 1){
			int to = (ch[fa[rt]][1] == rt ? 0 : 1);
			while(!ch[t][to]){
				t = fail[t];
			}
			t = ch[t][to];
			for(int j = 1; j <= tp[t]; j ++){
				g[i] |= (1 << (v[t][j] - 1));
			}
			rt = fa[rt];
		}
	}
	f[0][1][0] = 1; int M = 1 << n;
	for(int i = 0; i < m; i ++){
		for(int j = 1; j <= sz; j ++){
			for(int k = 0; k < M; k ++){
				if(!f[i][j][k]) continue;
				int t = j;
				while(!ch[t][0]) t = fail[t];
				t = ch[t][0];
				int tmp = k;
				for(int l = 1; l <= tp[j]; l ++){
					tmp = tmp | (1 << (v[j][l] - 1));
				}
				for(int l = 1; l <= tp2[j]; l ++){
					tmp = tmp | (1 << (v[j][l] - 1));
					tmp = tmp | (1 << (v2[j][l] - 1));
				}
				f[i + 1][t][tmp] += f[i][j][k];
				if(f[i + 1][t][tmp] >= mod) f[i + 1][t][tmp] -= mod;
				t = j;
				while(!ch[t][1]) t = fail[t];
				t = ch[t][1];
				tmp = k;
				for(int l = 1; l <= tp[j]; l ++){
					tmp = tmp | (1 << (v[j][l] - 1));
				}
				for(int l = 1; l <= tp2[j]; l ++){
					tmp = tmp | (1 << (v[j][l] - 1));
					tmp = tmp | (1 << (v2[j][l] - 1));
				}
				f[i + 1][t][tmp] += f[i][j][k];
				if(f[i + 1][t][tmp] >= mod) f[i + 1][t][tmp] -= mod;
			}
		}
	}
	int ans = 0;
	int MX = M - 1;
	for(int i = 1; i <= sz; i ++){
		for(int j = 0; j < M; j ++){
		//	if(j & 1)printf("%d %d %d\n", i, j, f[m][i][j]);
			if((j | g[i]) == MX) ans = ans + f[m][i][j];
			if(ans >= mod) ans -= mod;
		}
	}
	printf("%d\n", ans);
	return 0;
}
