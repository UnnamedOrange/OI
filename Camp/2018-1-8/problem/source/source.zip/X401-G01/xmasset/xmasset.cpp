#include<cstdio>
using namespace std;
int n,T,i,t,tm,x,y;

int main()
{
  //freopen("1.in","r",stdin);
  //freopen("1.out","w",stdout);
  scanf("%d",&t);
  scanf("%d%d",&n,&T);
  if(t==1)
  {
  for(i=1;i<=T;i++)
    {
      t=n,tm=0;
	  scanf("%d%d",&x,&y);
	  while(1)
	    {
	      tm++;
		  if(x<=t && y>t) {printf("%d\n",tm);break;}
		  tm++;
		  if(x>t && y<=t) {printf("%d\n",tm);break;}
		  if(x>t) x-=t;
		  if(y>t) y-=t;
		  t=(t+1)/2;
		}
	}
   }
   else
    {
	  for(i=1;i<=T;i++)
	    {
		  t=n,tm=0;
		  scanf("%d%d",&x,&y);
		  while(1)
	    {
	      tm++;
		  if(tm==y) 
		    {
		     if(x<=t) printf("yes\n");
		     else printf("no\n");
			 break;
			}
		  tm++;
		  if(tm==y) 
		    {
		     if(x>t) printf("yes\n");
		     else printf("no\n");
			 break;
			}
		  if(x>t) x-=t;
		  t=(t+1)/2;
		}
		}
	}
}
