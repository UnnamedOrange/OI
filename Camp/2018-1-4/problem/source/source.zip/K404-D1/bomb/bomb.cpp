#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define N 1000010
#define M 1000010
using namespace std;
int n,m,id,ans,cnt,top,tot1,tot2;
int q[N],s[N],f[N],dfn[N],deg[N],siz[N],low[N],bel[N],head1[N],head2[N];
bool ins[N];
struct Map
{
    int r,next;
} line1[M],line2[M];
void add1(int x,int y)
{
    tot1++;
    line1[tot1].r=y;
    line1[tot1].next=head1[x];
    head1[x]=tot1;
}
void add2(int x,int y)
{
    tot2++;
    deg[y]++;
    line2[tot2].r=y;
    line2[tot2].next=head2[x];
    head2[x]=tot2;
}
void tarjan(int x)
{
    dfn[x]=low[x]=++id;
    s[++top]=x,ins[x]=true;
    for(int i=head1[x]; i; i=line1[i].next)
    {
        int rx=line1[i].r;
        if(!dfn[rx])
        {
            tarjan(rx);
            low[x]=min(low[x],low[rx]);
        }
        else if(ins[rx])
            low[x]=min(low[x],dfn[rx]);
    }
    if(dfn[x]==low[x])
    {
        cnt++;
        int now=-1;
        while(now!=x)
        {
            siz[cnt]++;
            now=s[top--];
            bel[now]=cnt;
            ins[now]=false;
        }
    }
}
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("bomb.in","r",stdin);
    freopen("bomb.out","w",stdout);
    n=read(),m=read();
    for(int i=1; i<=m; i++)
    {
        int a=read(),b=read();
        add1(a,b);
    }
    for(int i=1; i<=n; i++)
        if(!dfn[i])
            tarjan(i);
    for(int i=1; i<=n; i++)
        for(int k=head1[i]; k; k=line1[k].next)
        {
            int j=line1[k].r;
            if(bel[i]!=bel[j])
                add2(bel[i],bel[j]);
        }
    int hd=1,tl=0;
    for(int i=1; i<=cnt; i++)
        if(!deg[i])
            q[++tl]=i,f[i]=siz[i];
    while(hd<=tl)
    {
        int x=q[hd++];
        for(int i=head2[x]; i; i=line2[i].next)
        {
            int rx=line2[i].r;
            f[rx]=max(f[rx],f[x]+siz[rx]);
            if(!--deg[rx])
                q[++tl]=rx;
        }
    }
    for(int i=1; i<=cnt; i++)
        ans=max(ans,f[i]);
    printf("%d",ans);
    return 0;
}
