/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
#define MODP 998244353
#define MOD(x) ((x)%MODP)
typedef long long LL;
#define MAXN 100000
int n;
int p[MAXN+10];
namespace bl
{
LL ans=0;
bool b[10];
void check()
{
    memset(b,true,sizeof(b));
    for(int i=1; i<=n; ++i)
    {
        if (b[i])
        {
            int cnt=1;
            for(int j=p[i]; j!=i; j=p[j])
            {
                b[j]=false;
                ++cnt;
            }
            if (cnt%2==1) return;
        }
    }
    ++ans;
}
bool used[MAXN+10];
void dfs(int now)
{
    if (now>n)
    {
        check();
        return;
    }
    if (p[now]>0) dfs(now+1);
    else
    {
        for(int i=1; i<=n; ++i)
        {
            if (used[i])
            {
                p[now]=i;
                used[i]=false;
                dfs(now+1);
                p[now]=0;
                used[i]=true;
            }
        }
    }
}
LL main()
{
    memset(used,true,sizeof(used));
    for(int i=1; i<=n; ++i)
    {
        used[p[i]]=false;
    }
    dfs(1);
    return ans;
}
}
namespace pf
{
LL main()
{
    LL ans=1;
    for(LL i=1; i<=n; i+=2)
    {
        ans=MOD(ans*MOD(i*i));
    }
    return ans;
}
}
namespace X
{
bool b[MAXN+10],b2[MAXN+10];
bool dfs(int now,int start,int cnt)
{
    b2[now]=false;
    if (p[now]==start) return cnt%2==0;
    return dfs(p[now],start,cnt+1);
}
LL main()
{
    int x=0,y=0;
    memset(b,true,sizeof(b));
    memset(b2,true,sizeof(b2));
    for(int i=1; i<=n; ++i)
    {
        b[p[i]]=false;
    }
    for(int i=1; i<=n; ++i)
    {
        if (b[i])
        {
            b2[i]=false;
            int cnt=1;
            for(int j=p[i]; j!=0; j=p[j])
            {
                b2[j]=false;
                ++cnt;
            }
            if (cnt%2==0) ++x;
            else ++y;
        }
    }
	for(int i=1; i<=n; ++i)
	{
		if (b2[i] && !dfs(i,i,1)) return 0;
	}
    LL ans=1;
    for(int i=1; i<=y; i+=2)
    {
        ans=MOD(ans*MOD(i*i));
    }
    for(int i=1; i<=x; ++i)
    {
        ans=MOD(ans*(y+i));
    }
    return ans;
}
}
int main()
{
    freopen("permutation.in","r",stdin);
#ifndef MDEBUG
    freopen("permutation.out","w",stdout);
#endif
    scanf("%d",&n);
    if (n%2!=0)
    {
        puts("0");
        return 0;
    }
    bool flag=true;
    for(int i=1; i<=n; ++i)
    {
        scanf("%d",&p[i]);
        if (p[i]>0) flag=false;
    }
    LL ans;
    ans=X::main();
    printf("%lld\n",ans);
    return 0;
}
