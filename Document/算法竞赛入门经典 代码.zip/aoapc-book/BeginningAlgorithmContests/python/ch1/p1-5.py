from sys import stdin
a = map(int, stdin.readline().strip().split())
a.sort()
print a[0], a[1], a[2]

