#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define N 100010
#define mod 998244353
using namespace std;
typedef long long LL;
struct node{int to,next;}table[N<<1];
int tot,head[N];
void add(int a,int b){table[++tot]=(node){b,head[a]};head[a]=tot;}
int n,m,d[N],cnt[2020];
LL K,f[2][2020],ans[N],num[N];
int q[N],h,t;
void sol1()
{
	for(int x=1;x<=n;x++)
	for(int i=head[x];i;i=table[i].next)
	if(table[i].to==1)
	++f[1][x],++ans[x];
	for(int k=2;k<=n;k++)
	{
		LL tar=1;for(int i=1;i<=K;i++)tar=tar*(LL)k%mod;
		h=t=0;
		int o=k&1;
		memset(cnt,0,sizeof cnt);
		memset(f[o],0,sizeof f[o]);
		for(int i=1;i<=n;i++)
		if(!d[i])q[++t]=i;
		while(h!=t)
		{
			int x=q[++h];
			for(int i=head[x];i;i=table[i].next)
			{
				if(++cnt[table[i].to]==d[table[i].to])q[++t]=table[i].to;
				f[o][x]+=f[o^1][table[i].to];
				if(f[o][x]>=mod)f[o][x]-=mod;
			}
		}
		for(int i=1;i<=n;i++)ans[i]=(ans[i]+f[o][i]*tar)%mod; 
		 
	}
	for(int i=1;i<=n;i++)printf("%lld\n",ans[i]);
}
LL c[40][40],xs[N][40];
void sol2()
{
	c[0][1]=1;
	for(int i=1;i<=K;i++)
	for(int j=1;j<=i+1;j++)c[i][j]=c[i-1][j-1]+c[i-1][j];
	xs[1][0]=1;
	q[t=1]=1;
	while(h!=t)
	{
		int x=q[++h];
		ans[x]=xs[x][K];
		for(int i=head[x];i;i=table[i].next)
		{
			if(!--d[table[i].to])q[++t]=table[i].to;
			xs[table[i].to][0]+=xs[x][0];
			if(xs[table[i].to][0]>=mod)xs[table[i].to][0]-=mod;
			for(int j=0;j<K;j++)
			{
				LL tar=0;
				for(int l=0;l<=j+1;l++)tar=(tar+c[j+1][l+1]*xs[x][l])%mod;
				xs[table[i].to][j+1]+=tar;
				if(xs[table[i].to][j+1]>=mod)xs[table[i].to][j+1]-=mod;
			}
		}
	}
	for(int i=1;i<=n;i++)printf("%lld\n",ans[i]);
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%lld",&n,&m,&K);
	int u,v;
	bool f=(n<=2000&&m<=5000);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		if(f)add(v,u),++d[u];
		else add(u,v),++d[v];
	}
	if(f)sol1();
	else sol2();
	return 0;
}
/*
6 8 1 1 2 1 3 1 5 2 4 3 2 3 4 3 6 4 6

*/