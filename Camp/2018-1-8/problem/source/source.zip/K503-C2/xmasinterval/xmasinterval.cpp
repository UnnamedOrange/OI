#include <stdio.h>
#include <stdlib.h>
#define maxn 500010
#define modn 1000000009
struct arr
{
	int l,r;
}a[maxn];
int c[maxn]={0},b[maxn],n,m,i,x,y,s;
int getnum()
{
	char c=getchar();
	int s=0;
	for (;(c<'0') || (c>'9');c=getchar());
	for (;(c>='0') && (c<='9');c=getchar())
		s=s*10+c-48;
	return s;
}
int cmp1(const void *a,const void *b)
{
	if ((*(arr *)a).r!=(*(arr *)b).r) return (*(arr *)a).r-(*(arr *)b).r;
		else return (*(arr *)a).l-(*(arr *)b).l;
}
int cmp2(const void *a,const void *b)
{
	return *(int *)a-*(int *)b;
}
int find(int x)
{
	int l=1,r=m,mid=(l+r)/2,ans=0;
	for (;l<=r;mid=(l+r)/2)
		if (x<b[mid]) r=mid-1;
			else
			{
				ans=mid;
				l=mid+1;
			}
	return ans;
}
void update(int x,int y)
{
	int i;
	for (i=x;i<=m;i+=i&-i)
		c[i]=(c[i]+y)%modn;
}
int query(int x)
{
	int i,s=0;
	for (i=x;i>0;i-=i&-i)
		s=(s+c[i])%modn;
	return s;
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=getnum();
	m=getnum();
	for (i=1;i<=n;i++)
	{
		a[i].l=getnum();
		a[i].r=getnum();
	}
	qsort(a+1,n,sizeof(a[0]),cmp1);
	for (i=1;i<=m;i++)
		b[i]=getnum();
	qsort(b+1,m,sizeof(b[0]),cmp2);
	for (i=1;i<=n;i++)
	{
		x=find(a[i].l-1);
		y=find(a[i].r);
		s=query(y)-query(x-1);
		if (!x) s++;
		if (s<0) s+=modn;
		s%=modn;
		update(y,s);
	}
	x=query(m)-query(m-1);
	if (x<0) x+=modn;
	printf("%d",x);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
