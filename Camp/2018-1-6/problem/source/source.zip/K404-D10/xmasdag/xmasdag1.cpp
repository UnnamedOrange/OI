//© 2018 Jazengm/ZengXiangru, AllRightsReserved
#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int mxn=1<<18, p=998244353;

struct edge
{
    int v, o;
    In edge(int v=0, int o=0):
    v(v), o(o) {}
} e[mxn];

int head[mxn];

In void aE(int u, int v)
{St int tot=1; e[++tot]=edge(v, u[head]), u[head]=tot;}

#define fev for(Rg int i_=u[head], v; v=i_[e].v, i_>0; i_=i_[e].o)

In void upd(int& x, ll y){x=((ll)x+y)%p;}

int main()
{
    St int n, m, k;
    scanf("%d%d%d", &n, &m, &k);
    inc(0, i, m)
    {
        St int u, v;
        scanf("%d%d", &u, &v), aE(u, v);
    }
    getFrac:
    St int inv[mxn], frac[mxn], invF[mxn];
    inv[1]=1;
    inc(2, i, n+1)
        inv[i]=(ll)inv[p%i]*(p-p/i)%p;
    inc(frac[0]=invF[0]=1, i, k+1)
        frac[i]=(ll)frac[i-1]*i%p, invF[i]=(ll)invF[i-1]*inv[i]%p;
    getOrder:
    St int deg[mxn];
    inc(1, u, n+1)
        fev
            ++deg[v];
    St int q[mxn];
    Rg int t=0;
    inc(1, u, n+1)
        if(!deg[u])
            q[t++]=u;
    St int f[mxn][1<<9];
    inc(0, h, t)
    {
        Rg int u=q[h];
        if(u==1)
                f[1][0]=1;
        fev
        {
        //without NTT
            inc(0, x, k+1)
                inc(0, i, x+1)
                    upd(f[v][x], (ll)f[u][i]*invF[x-i]);
            if(!--deg[v])
                q[t++]=v;
        }
    }
    inc(1, i, n+1)
        printf("%d\n", (ll)f[i][k]*frac[k]%p);
    Re 0;
}
