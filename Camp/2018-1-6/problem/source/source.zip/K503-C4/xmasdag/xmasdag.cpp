#include<iostream>
#include<cstdio>
#define mod 998244353
#define maxn 100010
using namespace std;
int n,m,K,num,head[maxn],ans[maxn];
struct node{int to,pre;}e[maxn*2];
int Pow(int x,int y){
	int res=1;
	while(y){
		if(y&1)res=1LL*res*x%mod;
		x=1LL*x*x%mod;
		y>>=1;
	}
	return res;
}
void Insert(int from,int to){
	e[++num].to=to;
	e[num].pre=head[from];
	head[from]=num;
}
void dfs(int now,int len){
	for(int i=head[now];i;i=e[i].pre){
		int to=e[i].to;
		ans[to]=(ans[to]+Pow(len+1,K))%mod;
		dfs(to,len+1);
	}
}
int main(){
	freopen("xmasdag.in","r",stdin);freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	int x,y;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		Insert(x,y);
	}
	dfs(1,0);
	if(K==0)ans[1]=1;
	for(int i=1;i<=n;i++)printf("%d\n",ans[i]);
	return 0;
}
