#include <bits/stdc++.h>
#include <tr1/unordered_map>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 10000000;

bool notprime[N + 5];
int prime[N + 5], pcnt;

ll s[N + 5];
int mnv[N + 5], mu[N + 5], Mu[N + 5];

void sieve() {
    mu[1] = s[1] = 1; 
    for(int i = 2; i <= N; ++i) {
        if(!notprime[i]) {
            s[i] = 2;
            mu[i] = -1;
            mnv[i] = 1;
            prime[pcnt ++] = i;
        }
        static ll x;
        for(int j = 0; j < pcnt && (x = 1ll*i*prime[j]) <= N; ++j) {
            notprime[x] = true;

            if(i % prime[j] == 0) {
                mu[x] = 0;
                mnv[x] = mnv[i];
                if(mnv[x] == 1) {
                    s[x] = s[i] + 1;
                } else {
                    s[x] = s[x / mnv[x]] * s[mnv[x]];
                }
                break;
            }

            mnv[x] = i;
            mu[x] = -mu[i];
            s[x] = s[i] * 2;
        }
    }
    for(int i = 1; i <= N; ++i) {
        s[i] += s[i-1];
        Mu[i] = Mu[i-1] + (mu[i] * mu[i]);
    }
}

ll gets(int x) {
    if(x <= N) return s[x];

    ll res = 0;
    for(int i = 1, nxt; i <= x; i = nxt + 1) {
        nxt = x / (x / i);
        res += (nxt - i + 1) * (x / i);
    }
    return res;
}

ll getmu(int x) {
    if(x <= N)  return Mu[x]; 

    ll res = 0;
    for(int i = 1; i*i <= x; i++) {
        res += (x/i/i) * mu[i];
    }
    return res;
}

int main() {
    freopen("function.in", "r", stdin);
    freopen("function.out", "w", stdout);

    sieve();

    int T, n;
    read(T);
    while(T--) {
        read(n);

        ll res = 0, lst = 0, tmp;
        for(int i = 1, nxt; i <= n; i = nxt + 1) {
            nxt = n / (n / i);
            res = res + gets(n / i) * ll((tmp = getmu(nxt)) - lst);
            lst = tmp;
        }
        printf("%lld\n", res);
    }

    return 0;
}
