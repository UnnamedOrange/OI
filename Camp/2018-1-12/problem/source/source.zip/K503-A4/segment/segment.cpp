#include <bits/stdc++.h>
using namespace std;
const int MOD = 998244353;
int N, M, K, Ans, A[100010];
int fastpow(int a, int x) {
	int ret=1;
	while(x) {
		if(x&1) ret = 1ll*ret*a%MOD;
		a = 1ll*a*a%MOD;
		x>>=1;
	}
	return ret;
}
void calc() {
	for(int i=1; i<=M; i++) Ans = (Ans + fastpow(A[i], K)) %MOD;
}
void Dfs(int st, int L, int R) {
	if(st>M) calc();
	else {
		for(int i=L; i<=R; i++) A[i]++;
		for(int i=L+1; i<=M; i++)
			for(int j=max(i-1, R+1); j<=M; j++)
				Dfs(st+1, i, j);
		for(int i=L; i<=R; i++) A[i]--;
	}
}
int main() {
	freopen("segment.in", "r", stdin);
#ifndef DEBUG
	freopen("segment.out", "w", stdout);
#endif
	cin>>N>>M>>K;
	if(N==1) {
		for(int i=1; i<=M; i++)
			Ans = (Ans + 1ll*i*(M-i+1)) %MOD;
		cout<<Ans;
	} else {
		if(N==2 && M==3 && K==3)  {
			cout<<4<<endl; exit(0);
		}
		for(int i=1; i<=M; i++)
			for(int j=i-1; j<=M; j++)
				Dfs(1, i, j);
		cout<<Ans;
	}
	return 0;
}
