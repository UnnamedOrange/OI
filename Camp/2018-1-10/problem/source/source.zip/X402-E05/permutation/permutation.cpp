#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
const LL mod=998244353;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
}
int n,ans,sum,a[N],p[N];
LL dp[N],fac[N],ifac[N];
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void init(int n)
{
	fac[0]=ifac[0]=1;
	For(i,1,n)fac[i]=fac[i-1]*i%mod;
	ifac[n]=qpow(fac[n],mod-2);
	rFor(i,n,2)ifac[i-1]=ifac[i]*i%mod;
}
inline LL C(int n,int k)
{
	if(n<k)return 0;
	return fac[n]*ifac[k]%mod*ifac[n-k]%mod;
}
inline int check()
{
	For(i,1,n)
	{
		int ret=1;
		for(int x=a[i];x!=i;x=a[x])ret++;
		if(ret&1)return 0;
	}
	return 1;
}
inline void dfs(int now)
{
	if(now==n+1){ans+=check();return;}
	if(a[now])dfs(now+1);
	else
	{
		For(i,1,n)
		if(!p[i])
		{
			a[now]=i,p[i]=1;
			dfs(now+1);
			p[i]=0,a[now]=0;
		}
	}
}
inline void Solve()
{
	LL ret=1;
	for(LL i=1;i<=n;i+=2)ret=ret*i%mod;
	printf("%lld\n",ret*ret%mod);
}
int main()
{
	file();
	read(n);
	For(i,1,n)read(a[i]),p[a[i]]=1,sum+=a[i];
	if(n&1)puts("0");
	else 
	if(sum==0)Solve();
	else
	{
		dfs(1);
		printf("%d\n",ans);
	}
	return 0;
}
