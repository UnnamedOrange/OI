#include <bits/stdc++.h>
#include <windows.h>

int a[27];

int main() {
    char *t = new char;
    srand((long long)t * GetTickCount() ^ time(0));
    delete t;
    std::ios::sync_with_stdio(false);
    register int n = 100000, q = 100000;
    std::cout << n << ' ' << q << " 0\n";

    for (register int i = 1; i <= n; i++) {
        std::cout << rand() % n + 1 << ' ';
    }
    std::cout << '\n';
    for (register int i = 2; i <= n; i++) {
        std::cout << rand() % (i - 1) + 1 << ' ' << i << '\n';
    }
    for (register int i = 1; i <= q; i++) {
        register int cmd = rand() % 2 + 1;
        std::cout << cmd << ' ';
        switch (cmd) {
            case 1: {
                register int l = rand() % n + 1, r = rand() % n + 1;
                if (l > r) std::swap(l, r);
                std::cout << rand() % n + 1 << ' ' << l << ' ' << r << '\n';
                break;
            }
            case 2: {
                std::cout << rand() % n + 1 << ' ' << rand() % n + 1 << '\n';
                break;
            }
        }
    }
}