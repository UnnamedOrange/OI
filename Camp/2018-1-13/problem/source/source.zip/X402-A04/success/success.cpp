#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1000050;
const int mod=1e9+7;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int fac[N],finv[N];
int f[2050][2050];


void wj()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	int s=read(),t=read(),n=read(),m=read();
	if(m>s) {puts("0");return 0;}
	fac[0]=1; finv[0]=1;
	for(i=1;i<=s;++i) fac[i]=1ll*fac[i-1]*i%mod;
	finv[s]=qpow(fac[s],mod-2);
	for(i=s-1;i>=1;--i) finv[i]=1ll*finv[i+1]*(i+1)%mod;

	f[0][0]=1;
	for(i=1;i<=n;++i) for(j=1;j<=(s-m+n);++j)
	{
		for(int k=1;k<=t;++k) if(j-k>=0) f[i][j]=(f[i][j]+f[i-1][j-k])%mod;
	}
	int ans=0;
	for(int l=n;l<=s-m+n;l++) 
		ans=(ans+1ll*f[n][l]*fac[s-l]%mod*finv[m-n]%mod*finv[s-l-m+n]%mod)%mod;
	printf("%d\n",ans);
	return 0;
}
