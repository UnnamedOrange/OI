#include<bits/stdc++.h>
using namespace std;
#define N 100010
struct Edge {
	int u,v,nxt;
}e[N];
int cnt,head[N];
void add(int u,int v) {
	e[++cnt].u=u,e[cnt].v=v,e[cnt].nxt=head[u],head[u]=cnt;
}
int c[N],vis[N];
double f[N];
void dfs(int po,double p,int dep) {
	if(dep>20) return;
	if((!vis[po])||c[po]) f[po]+=p;
	vis[po]=1;
	int cnt=0;
	for(int i=head[po];i!=-1;i=e[i].nxt) {
		cnt++;
	}
	if(cnt==1) {
		vis[po]=0;
		return;
	}
	double tmp=f[po];
	f[po]=0;
	for(int i=head[po];i!=-1;i=e[i].nxt) {
		f[e[i].v]+=tmp/cnt;
		dfs(e[i].v,p/cnt,dep+1);
	}
	vis[po]=0;
}
int r[N];
int main() {
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	int n;
	memset(head,-1,sizeof(head));
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {
		char x;
		cin>>x;
		c[i]=x-'0';
	}
	for(int i=1;i<n;i++) {
		int u,v;
		scanf("%d%d",&u,&v);
		r[v]++;
		add(u,v);add(v,u);
	}
	dfs(1,1,0);
	double ans=0;
	for(int i=1;i<=n;i++) {
		if(r[i]==1) ans+=f[i];
	}
	printf("%d",(int)(ans+0.5));
}
