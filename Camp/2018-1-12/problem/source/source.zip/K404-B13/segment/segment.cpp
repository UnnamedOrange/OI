#include<bits/stdc++.h>
using namespace std;
#define mo 998244353
int n,m,k,ans=0;
void doit_1(){
	ans=0;
	for(int i=1;i<=m-1;i++){
		ans+=m-i;
		ans%=mo;
	}
}
void doit_2(){
	int p=0,k=0;
	for(int i=1;i<m;i++){
//		int tem=0;
		for(int j=1;j<m;j++){
			p+=(m-i-j)*(m-i-j);
		}
	}
	cout<<p<<endl<<k<<endl;
}
int a[50],as[50];
void dfs(int l,int r,int n){
//	printf("dfs %d~%d ,n=%d\n",l,r,n);
	if(n==0) {
		for(int i=1;i<=m;i++)
		as[a[i]]++;
		return;
	}
	for(int i=l+1;i<=m;i++){
		if(m-i+1<n)	break;
		for(int j=r+1;j<=m;j++){
			if(m-j+1<n) break;
			for(int k=i;k<j;k++)
				a[k]++;
			dfs(i,j,n-1);
			for(int k=i;k<j;k++)
				a[k]--;
		}	
	}
	
}
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	cin>>n>>m>>k;
	if(n==1) {
		doit_1();
	}
//	else if(n==2) {
//		doit_2();
//	}
	else if(m<=40) {
		dfs(0,0,n);
	}
	cout<<ans;
	return 0;
}
