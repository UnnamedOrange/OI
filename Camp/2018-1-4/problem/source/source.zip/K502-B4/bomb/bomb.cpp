#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,m,map[1010][1010],dp[2000],ans[1010];
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	for(int i=1;i<=1024;i++) dp[i]=1e8;
	scanf("%d%d",&n,&m);
	int x,y;
	for(int i=1;i<=m;i++) 
	{
		scanf("%d%d",&x,&y);
		map[x][y]=1;
	}
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(map[i][k]==1 && map[k][j]==1) map[i][j]=1;
	for(int i=1;i<(1<<n);i++)
	{
		int cnt[1010];
		memset(cnt,0,sizeof(cnt));
		for(int j=1;j<=n;j++)
			if(i&(1<<(j-1))) cnt[++cnt[0]]=j;
		bool flag=true;
		for(int j=1;j<=cnt[0];j++)
		{
			for(int k=1;k<=cnt[0];k++) 
			{
				if(j==k) continue;
				if(map[cnt[j]][cnt[k]]==1) 
				{
					flag=false;
				}
			}
		}
		if(flag) ans[++ans[0]]=i;
	}
	for(int i=0;i<(1<<n)-1;i++)
	{
		if(dp[i]==1e8) continue;
		for(int j=1;j<=ans[0];j++) dp[i|ans[j]]=min(dp[i|ans[j]],dp[i]+1);
		for(int j=1;j<=n;j++) dp[i|(1<<(j-1))]=min(dp[i|(1<<(j-1))],dp[i]+1);
	}
	printf("%d",dp[(1<<n)-1]);
	return 0;
}
