#include <bits/stdc++.h>
using namespace std;

const int Max = 1111111;
class Graph {
	public:
		struct Edge {
			int v;
			Edge *nxt;
		} pool[Max], *g[Max], *tail;

		Graph() {
			tail = pool;
		}
		inline void addedge(const int &u, const int &v) {
			tail->v = v;
			tail->nxt = g[u], g[u] = tail++;
		}
} g, dag;

int n, m, color[Max], st[Max], dfn[Max], low[Max];
int belong[Max], size[Max], dp[Max];

void tarjan(int u) {
	dfn[u] = low[u] = ++*dfn, st[++*st] = u, color[u] = -1;
	for (Graph::Edge *p = g.g[u]; p; p = p->nxt) {
		if (!color[p->v]) {
			tarjan(p->v), low[u] = min(low[u], low[p->v]);
		} else {
			if (color[p->v] == -1) {
				low[u] = min(low[u], dfn[p->v]);
			}
		}
	}
	if (dfn[u] == low[u]) {
		for (belong[u] = ++*belong, color[u] = 1; st[*st] != u; --*st) {
			belong[st[*st]] = *belong, color[st[*st]] = 1;
			++size[*belong];
		}
		--*st, ++size[*belong];
	}
}
int dfs(int u) {
	int &ret = dp[u];
	if (ret == -1) {
		ret = 0;
		for (Graph::Edge *p = dag.g[u]; p; p = p->nxt) {
			ret = max(ret, dfs(p->v));
		}
		ret += size[u];
	}
	return ret;
}

int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int a, b; m--; ) {
		scanf("%d%d", &a, &b);
		g.addedge(a, b);
	}
	for (int i = 1; i <= n; ++i) {
		if (!color[i]) {
			tarjan(i);
		}
	}
	for (int i = 1; i <= n; ++i) {
		for (Graph::Edge *p = g.g[i]; p; p = p->nxt) {
			if (belong[i] != belong[p->v]) {
				dag.addedge(belong[i], belong[p->v]);
			}
		}
	}
	memset(dp, -1, sizeof(dp));
	int ans = 0;
	for (int i = 1; i <= *belong; ++i) {
		ans = max(ans, dfs(i));
	}
	printf("%d\n", ans);
	return 0;
}
