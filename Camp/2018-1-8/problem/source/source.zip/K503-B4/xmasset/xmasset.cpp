#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
int num1[20],num2[20];
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
inline int get(int x,int y)
{
	for(int i=0;i<=9;i++)
	{
		if((x&(1<<i))!=(y&(1<<i)))
			return i+((x&(1<<i))==(1<<i))+1;
	}
	if(x%2)
		return 2;
	return 1;
}
inline bool check(int q,int h)
{
	h--;
	int res=0;
	if(h&1)
		res=1;
	h>>=1;
	return (q&(1<<h))==res*(1<<h);
}
int main()
{
	int t,n;
	read(t);
	if(t==1)
	{
		int n,T;
		read(n);
		read(T);
		for(int i=1,x,y;i<=T;i++)
		{
			read(x);
			read(y);
			printf("%d\n",get(x,y));
		}
	}
	else
	{
		int n,T;
		read(n);
		read(T);
		for(int i=1,q,h;i<=T;i++)
		{
			read(q);
			read(h);
			if(check(q,h))
				puts("yes");
			else
				puts("no");
		}
	}
	return 0;
}
