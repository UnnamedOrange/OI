#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("schooldays.in","r",stdin);freopen("schooldays.out","w",stdout);
	puts("-1");
	return 0;
} 
