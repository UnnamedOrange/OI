#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstdio>
using namespace std;

struct node
{
	int p;
	int w;
	int d;
};

const int MAXN = 31000;
int n, ans = 0;
int w[MAXN], r[MAXN], fa[MAXN], visit[MAXN], ank[MAXN], depth[MAXN];
vector<int> e[MAXN];
node a[MAXN], b[MAXN];

namespace Force
{
	void dfs(int p, int f)
	{
		fa[p] = f;
		for (auto i : e[p])
		{
			if (i != f)
				dfs(i, p);
		}
	}
	bool check()
	{
		for (int i = 1; i < n + 1; ++i)
		{
			if (visit[fa[i]] > visit[i])
				return false;
		}
		return true;
	}
	void dfs2(int p, int v)
	{
		if (p == n + 1)
		{
			if (check())
				ans = max(ans, v);
		}
		else if (p < n + 1)
		{
			for (int i = 1; i < n + 1; ++i)
			{
				if (!visit[i])
				{
					visit[i] = p;
					dfs2(p + 1, v + p * w[i]);
					visit[i] = 0;
				}
			}
		}
	}
	void main()
	{
		for (int i = 1; i < n + 1; ++i)
		{
			if (r[i] == 1)
			{
				dfs(i, 0);
				dfs2(1, 0);
			}
		}
		printf("%d\n", ans);
	}
}

namespace Greedy
{
	void dfs(int p, int f)
	{
		depth[p] = depth[f] + 1;
		for (auto i : e[p])
		{
			if (i != f)
				dfs(i, p);
		}
	}
	bool compare(const node &x, const node &y)
	{
		if (x.w == y.w)
			return x.p < y.p;
		else
			return x.w < y.w;
	}
	bool compare2(const node &x, const node &y)
	{
		return x.d > y.d;
	}
	void change(int l, int r)
	{
		node t = a[r];
		for (int i = r; i > l; --i)
		{
			a[i] = a[i - 1];
			ank[a[i].p] = i;
		}
		a[l] = t;
		ank[t.p] = l;
	}
	void calc()
	{
		for (int i = 1; i < n + 1; ++i)
		{
			a[i].w = w[i];
			a[i].p = i;
			b[i].d = depth[i];
			b[i].p = i;
		}
		sort(a + 1, a + n + 1, compare);
		for (int i = 1; i < n + 1; ++i)
			ank[a[i].p] = i;
		sort(b + 1, b + n + 1, compare2);
		for (int i = 1; i < n + 1; ++i)
		{
			int f = fa[b[i].p], p = b[i].p;
			if (ank[f] > ank[p])
				change(ank[p], ank[f]);
		}
		int ret = 0;
		for (int i = 1; i < n + 1; ++i)
			ret += w[i] * ank[i];
		ans = max(ans, ret);
	}
	void main()
	{
		for (int i = 1; i < n + 1; ++i)
		{
			if (r[i] == 1)
			{			
				dfs(i, 0);
				calc();
			}
		}
		printf("%d\n", ans);
	}
}

namespace Treap
{
	void main()
	{}
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	n = read();
	for (int i = 1; i < n; ++i)
	{
		int u = read(), v = read();
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for (int i = 1; i < n + 1; ++i)
	{
		w[i] = read();
		r[i] = read();
	}
	if (n <= 10)
		Force::main();
	else if (n <= 1000)
		Greedy::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
