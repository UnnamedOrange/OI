//by yjz
#include<bits/stdc++.h>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
//My i/o stream
struct fastio
{
	char s[100000];
	int it,len;
	fastio(){it=len=0;}
	inline char get()
	{
		if(it<len)return s[it++];it=0;
		len=fread(s,1,100000,stdin);
		if(len==0)return EOF;else return s[it++];
	}
	bool notend()
	{
		char c=get();
		while(c==' '||c=='\n')c=get();
		if(it>0)it--;
		return c!=EOF;
	}
}_buff;
#define geti(x) x=getnum()
#define getii(x,y) geti(x),geti(y)
#define getiii(x,y,z) getii(x,y),geti(z)
#define puti(x) putnum(x),putchar(' ')
#define putii(x,y) puti(x),puti(y)
#define putiii(x,y,z) putii(x,y),puti(z)
#define putsi(x) putnum(x),putchar('\n')
#define putsii(x,y) puti(x),putsi(y)
#define putsiii(x,y,z) putii(x,y),putsi(z)
inline ll getnum()
{
	ll r=0;bool ng=0;char c;c=_buff.get();
	while(c!='-'&&(c<'0'||c>'9'))c=_buff.get();
	if(c=='-')ng=1,c=_buff.get();
	while(c>='0'&&c<='9')r=r*10+c-'0',c=_buff.get();
	return ng?-r:r;
}
template<class T> inline void putnum(T x)
{
	if(x<0)putchar('-'),x=-x;
	register short a[20]={},sz=0;
	while(x)a[sz++]=x%10,x/=10;
	if(sz==0)putchar('0');
	for(int i=sz-1;i>=0;i--)putchar('0'+a[i]);
}
inline char getreal(){char c=_buff.get();while(c<=32)c=_buff.get();return c;}
bool np[1000111];
int p[100111],pn;
int mu[1000111],dcnt[1000111],pcnt[1000111];
ll psum[1000111];
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	np[1]=1;mu[1]=1;dcnt[1]=1;
	for(int i=2;i<=1000000;i++)
	{
		if(!np[i])
		{
			p[pn++]=i;
			mu[i]=-1;
			dcnt[i]=2;
			pcnt[i]=1;
		}
		for(int j=0;j<pn&&p[j]*i<=1000000;j++)
		{
			np[p[j]*i]=1;
			if(i%p[j]==0)
			{
				mu[p[j]*i]=0;
				pcnt[p[j]*i]=pcnt[i]+1;
				dcnt[p[j]*i]=dcnt[i]/(pcnt[i]+1)*(pcnt[i]+2);
				break;
			}
			else
			{
				mu[p[j]*i]=-mu[i];
				pcnt[p[j]*i]=1;
				dcnt[p[j]*i]=dcnt[i]<<1;
			}
		}
	}
	psum[1]=1;
	for(int i=2;i<=1000000;i++)psum[i]=psum[i-1]+dcnt[i]*dcnt[i];
	int Tn;
	cin>>Tn;
	while(Tn--)
	{
		int n;
		cin>>n;
		ll sum=0;
		for(int i=1;i<=n;i++)
		{
			sum+=mu[i]*psum[n/i];
		}
		cout<<sum<<endl;
	}
	return 0;
}
