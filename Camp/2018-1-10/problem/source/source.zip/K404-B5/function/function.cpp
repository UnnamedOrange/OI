#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 10000007;

int n;
int prm[MAXN], kp;
bool isp[MAXN];
int mu[MAXN], sig[MAXN];
LL psig[MAXN];



void init ();
void input ();
void work ();



int main ()
{
	init ();
	
	int T;
	scanf ( "%d", &T );
	while ( T-- ){
		input ();
		work ();
	}
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "function" );
	
	INIT ( isp, true );
	isp[0] = isp[1] = false;
	mu[0] = 0, mu[1] = 1;
	sig[0] = 0, sig[1] = 1;
	int v, t, tc;
	lp ( i, 2, MAXN ){
		if ( isp[i] ) prm[++kp] = i, mu[i] = -1, sig[i] = 2;
		for ( int j = 1; j <= kp && ( v = i * prm[j] ) < MAXN; ++j ){
			isp[v] = false;
			for ( t = i, tc = 0; t % prm[j] == 0; t /= prm[j], ++tc );
			sig[v] = sig[i] / ( tc + 1 ) * ( tc + 2 );
			if ( i % prm[j] ) mu[v] = -mu[i];
			else{
				mu[v] = 0;
				break;
			}
		}
	}
	
	lp ( i, 1, MAXN ) psig[i] = psig[i-1] + SC ( LL, sig[i] ) * sig[i];
}

void input ()
{
	scanf ( "%d", &n );
}

void work ()
{
	LL ans = 0;
	lpi ( i, 1, n ) ans += mu[i] * psig[n/i];
	
	cout << ans << endl;
}
