#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
int t,n,m;
int main(){
    freopen("xmasset.in","r",stdin);
    freopen("xmasset.out","w",stdout);
    read(t); read(m); read(n);
    if(t==1){
        for(int i=1;i<=n;i++){
            int x,y;
            read(x); read(y);
            for(int i=1;i<=10;i++) if(((x>>(i-1))&1)^((y>>(i-1))&1)){
                printf("%d\n",(x>>(i-1))&1?i:i+10); break;
            }
        }
    }
    else{
        for(int i=1;i<=n;i++){
            bool flag=0;
            int x,h; read(x); read(h);
            if(h>10) h-=10,flag^=1;
            if(!((x>>(h-1))&1)) flag^=1;
            puts(flag?"no":"yes");
        }
    }
    return 0;
}
