#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define mod 998244353
#define ll long long
#define N 100010
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int lj[N],fro[N],to[N],cnt,du[N];
void add(int a,int b){fro[++cnt]=lj[a];to[cnt]=b;lj[a]=cnt;}
int n,m,k;
bool vs[N];
void dfs(int x)
{
	vs[x]=1;
	for(int i=lj[x];i;i=fro[i]) if(!vs[to[i]]) dfs(to[i]);
}
int l,r,q[N];
ll mi[N];
namespace sub1
{
	#define M 2010
	ll ans[M];
	int ji[M][M];
	void Main()
	{
		q[r++]=1;
		int x,y;
		ji[1][0]=1;
		while(l<r)
		{
			x=q[l++];
			for(int i=1;i<=n;i++) (ans[x]+=mi[i]*ji[x][i])%=mod;
			for(int i=lj[x];i;i=fro[i])
			{
				y=to[i];
				for(int i=0;i<=n;i++) (ji[y][i+1]+=ji[x][i])%=mod;
				du[y]--;
				if(!du[y]) q[r++]=y;
			}
		}
		for(int i=1;i<=n;i++) printf("%lld\n",ans[i]);
	}
};
namespace sub2
{
	ll ans[N],ji[N];
	void Main()
	{
		q[r++]=1;
		int x,y;
		ji[1]=1;
		while(l<r)
		{
			x=q[l++];
			for(int i=lj[x];i;i=fro[i])
			{
				y=to[i];
				(ans[y]+=ans[x]+ji[x])%=mod;
				(ji[y]+=ji[x])%=mod;
				du[y]--;
				if(!du[y]) q[r++]=y;
			}
		}
		for(int i=1;i<=n;i++) printf("%lld\n",ans[i]);
	}
};
ll ksm(ll a,int b)
{
	ll sum=1;
	while(b)
	{
		if(b&1) sum=sum*a%mod;
		a=a*a%mod;b>>=1;
	}
	return sum;
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=rd();m=rd();k=rd();
	for(int i=1;i<=n;i++) mi[i]=ksm(i,k);
	for(int i=1,x,y;i<=m;i++)
	{
		x=rd();y=rd();
		add(x,y);du[y]++;
	}
	dfs(1);
	for(int i=1;i<=n;i++)
	{
		if(vs[i]) continue;
		for(int j=lj[i];j;j=fro[j]) du[to[j]]--;
	}
	if(n<=2000) sub1::Main();
	else if(k==1) sub2::Main();
	else 
	return 0;
}