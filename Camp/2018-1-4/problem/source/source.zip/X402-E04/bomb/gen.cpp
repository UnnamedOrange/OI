#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;

int main(){
	freopen("bomb.in","w",stdout);
	srand(time(0));
	int n=1000000,m=1000000;
	printf("%d %d\n",n,m);
	For(i,1,m){
		printf("%d %d\n",rand()%n+1,rand()%n+1);
	}
	return 0;
}
