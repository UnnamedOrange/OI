#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=510,INF=0x3f3f3f3f,Mod=1e9+7;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
}

char s[7][N];
int lab[7][N];
struct ac_auto{
	int f[N],w[N],ch[N][2],n,cnt,V[N];
	ac_auto(){cnt=1;}
	inline void insert(char *S,int id){
		int u=1,L=strlen(S+1),c;
		For(i,1,L){
			c=S[i]-'0',u=ch[u][c]?ch[u][c]:ch[u][c]=++cnt;
			if(lab[id][i])V[u]|=(1<<(id-1));
		}
		w[u]|=(1<<(id-1));
	}
	void get_fail(int u){
		For(i,0,1){
			int r=ch[f[u]][i],&v=ch[u][i];
			if(v)f[v]=r,w[v]|=w[r],V[v]|=V[r];
			else v=r;
		}
	}
	void Build(){
		int q[N],h=0,t=0,u;
		ch[0][1]=ch[0][0]=1;
		for(q[++t]=1;h<t;get_fail(u)){
			u=q[++h];
			For(i,0,1)if(ch[u][i])q[++t]=ch[u][i];
		}
	}
	void Pr(){
		For(i,1,cnt){
			if(V[i])printf("v %d %d\n",i,V[i]);
			if(w[i])printf("w %d %d\n",i,w[i]);
		}
		For(i,1,cnt)printf("%d %d\n",ch[i][0],ch[i][1]);
	}
}A,B;
int n,m;
void init(){
	read(n),read(m);
	For(i,1,n){
		scanf("%s",s[i]+1);
		int L=strlen(s[i]+1);
		For(j,1,L-1){
			if(L-j>j)continue;
			int y=j+1,x=j;
			while(s[i][x]!=s[i][y]&&y<=L)
				x--,y++;
			if(y==L+1)lab[i][j]=1;
		}
		A.insert(s[i],i);
		reverse(s[i]+1,s[i]+L+1);
		For(j,1,L-1){
			lab[i][j]=0;
			if(L-j>j)continue;
			int y=j+1,x=j;
			while(s[i][x]!=s[i][y]&&y<=L)
				x--,y++;
			if(y==L+1)lab[i][j]=1;
		}	

		B.insert(s[i],i);
	}
	A.Build(),B.Build();
}
int dp[2][N][N][1<<6],vis[1<<6];
inline void Add(int &x,int y){x=x+y<Mod?x+y:x+y-Mod;}
void solve(){
	dp[0][1][1][0]=1;
	int all=(1<<n)-1,now=0,nxt=1;
	For(i,1,m){
		For(j,1,A.cnt)For(k,1,B.cnt)For(mask,0,all)dp[nxt][j][k][mask]=0;
		For(j,1,A.cnt)
			For(k,1,B.cnt)
				For(mask,0,all)
					if(dp[now][j][k][mask]){
						For(C,0,1){
							int nj=A.ch[j][C],nk=B.ch[k][C^1],nmask;
							nmask=mask|A.w[nj]|B.w[nk];
							Add(dp[nxt][nj][nk][nmask],dp[now][j][k][mask]);
							//printf("%d %d %d %d \n",i,nj,nk,nmask);
						}
					}
		swap(now,nxt);
	}
	int ans=0;
	//puts("");
	For(j,1,A.cnt)
		For(k,1,B.cnt)
			For(mask,0,all){
				if((mask|A.V[j]|B.V[k])==all){
					Add(ans,dp[now][j][k][mask]);
				}
			}
	printf("%d\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
