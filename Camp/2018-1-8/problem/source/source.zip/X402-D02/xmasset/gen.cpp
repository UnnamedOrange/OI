#include<iostream>
#include<cstdio>
#include<cstring>

FILE *in0,*in1,*bin,*ans,*out;

int main()
{
	int n=920,T=(n*n-n)*2,ty;

	scanf("%d",&ty);

	if(ty==1)
	{
		in0=fopen("set0.in","w");
		bin=fopen("set.bin","w");
		ans=fopen("set.ans","w");

		fprintf(in0,"%d\n",ty);
		fprintf(in0,"%d %d\n",n,T);

		fprintf(ans,"%d\n",T);

		int cnt=0;

		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
			{
				if(i==j)continue;

				cnt++;
				fprintf(in0,"%d %d\n",i,j);
				fprintf(bin,"%d\n",i);
				fprintf(ans,"1\n");

				if(cnt==3677)fprintf(stderr,"%d %d %d\n",i,j,i);


				cnt++;
				fprintf(in0,"%d %d\n",i,j);
				fprintf(bin,"%d\n",j);
				fprintf(ans,"0\n");

				if(cnt==3677)fprintf(stderr,"%d %d %d\n",i,j,j);
			}
	}
	else 
	{
		out=fopen("set.out","r");
		bin=fopen("set.bin","r");
		in1=fopen("set1.in","w");
		int q,h,maxw=0;

		fprintf(in1,"%d\n",ty);
		fprintf(in1,"%d %d\n",n,T);
		
		while(T--)
		{
			fscanf(bin,"%d",&q);
			fscanf(out,"%d",&h);

			maxw=std::max(maxw,h);

			fprintf(in1,"%d %d\n",q,h);
		}

		fprintf(stderr,"done , maxw = %d\n",maxw);
	}
	return 0;
}
