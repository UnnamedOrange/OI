#include<iostream>
#include<cstdio>
#include<cstring>

namespace bf
{
	const int N=30,L=200;
	char s[N][L];
	char t[N*L];
	int len[N];
	int n,m,ans;
	void initialize()
	{
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)
			scanf("%s",s[i]+1),len[i]=strlen(s[i]+1);
	}
	bool judge(int i)
	{
		for(int pos=1;pos<=2*m-len[i]+1;pos++)
		{
			bool flag=1;
			for(int x=1;x<=len[i];x++)
				flag&=(s[i][x]==t[pos+x-1]);
			if(flag)return 1;
		}
		return 0;
	}
	bool check()
	{
		for(int i=1;i<=n;i++)
			if(!judge(i))return 0;
		return 1;
	}
	void dfs(int p=1)
	{
		if(p>m)
		{
			if(check())
			{
				printf("%s\n",t+1);
				ans++;
			}
			return;
		}
		t[p]='0',t[2*m-p+1]='1';
		dfs(p+1);
		t[p]='1',t[2*m-p+1]='0';
		dfs(p+1);
	}

	void solve()
	{
		initialize();
		ans=0,dfs();
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	bf::solve();
	return 0;
}
