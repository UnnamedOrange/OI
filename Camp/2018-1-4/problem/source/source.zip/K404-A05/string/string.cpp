//by yjz
#include<algorithm>
#include<bitset>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<deque>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<map>
#include<queue>
#include<set>
#include<string>
#include<stack>
#include<utility>
#include<vector>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=998244353;
int m;
struct AC
{
	int go[1211][2],msk[1211],fa[1211],fc[1211];
	int n,fail[1211],fgo[1211][2];
	bool pl[1205][14][105];
	void init()
	{
		n=1;
		memset(go,0,sizeof(go));
		memset(fail,0,sizeof(fail));
		memset(fgo,0,sizeof(fgo));
		memset(msk,0,sizeof(msk));
		memset(fa,0,sizeof(fa));
		memset(pl,0,sizeof(pl));
	}
	AC(){init();}
	void adds(char s[],int id,int mid)
	{
		int l=strlen(s);
		int p=1;
		for(int i=0;i<l;i++)
		{
			int &nxt=go[p][s[i]-'0'];
			if(!nxt)nxt=++n,fa[nxt]=p,fc[nxt]=s[i]-'0';
			p=nxt;
			pl[p][id][i+1]=1;
		}
		msk[p]|=1<<mid;
	}
	int q[1211],qn;
	void build()
	{
		qn=0;
		q[qn++]=1;
		for(int i=0;i<qn;i++)
		{
			int x=q[i];
			for(int j=0;j<2;j++)if(go[x][j])q[qn++]=go[x][j];
		}
		for(int i=0;i<qn;i++)
		{
			int x=q[i];
			if(x==1||fa[x]==1)fail[x]=1;
			else
			{
				int p=fail[fa[x]];
				while(p!=1&&!go[p][fc[x]])p=fail[p];
				if(go[p][fc[x]])fail[x]=go[p][fc[x]];
				else fail[x]=p;
			}
		}
		for(int i=0;i<qn;i++)
		{
			int x=q[i];
			for(int j=0;j<2;j++)
			{
				int p=x;
				while(p!=1&&!go[p][j])p=fail[p];
				if(go[p][j])fgo[x][j]=go[p][j];
				else fgo[x][j]=p;
			}
		}
		for(int i=1;i<qn;i++)
		{
			int x=q[i];
			msk[x]|=msk[fail[x]];
			for(int j=0;j<12;j++)
			{
				for(int t=0;t<=100;t++)
				{
					pl[x][j][t]|=pl[fail[x]][j][t];
				}
			}
		}
//		for(int i=2;i<=n;i++)cerr<<fa[i]<<"->"<<i<<" "<<fc[i]<<" "<<fail[i]<<" "<<msk[i]<<endl;
	}
}a;
void upd(int &x,int v){x=x+v>=mod?x+v-mod:x+v;}
int dp[1205][64];
int ndp[1205][64];
int n,le[10];
char s[111];
void solve()
{
	dp[1][0]=1;
	for(int t=0;t<n;t++)
	{
		memset(ndp,0,sizeof(ndp));
		for(int i=1;i<=a.n;i++)
		{
			for(int k=0;k<(1<<m);k++)
			{
				int &cur=dp[i][k];
				if(!cur)continue;
				for(int v=0;v<2;v++)
				{
					int nxt=a.fgo[i][v];
					upd(ndp[nxt][k|a.msk[nxt]],cur);
				}
			}
		}
		swap(dp,ndp);
	}
	int ans=0;
	for(int i=1;i<=a.n;i++)
	{
		int msk=0;
		for(int t=0;t<m;t++)
		{
			for(int tl=1;tl<le[t];tl++)
			{
				if(a.pl[i][t][tl]&&a.pl[i][t+m][le[t]-tl])msk|=1<<t;
			}
		}
		for(int k=0;k<(1<<m);k++)
		{
			if((k|msk)==((1<<m)-1))
			{
				upd(ans,dp[i][k]);
			}
		}
	}
	cout<<ans<<endl;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=0;i<m;i++)
	{
		scanf("%s",s);
		int l=strlen(s);
		le[i]=l;
		a.adds(s,i,i);
		reverse(s,s+l);
		for(int j=0;j<l;j++)s[j]='1'-(s[j]-'0');
		a.adds(s,i+m,i);
	}
	a.build();
	solve();
	return 0;
}
