#include<bits/stdc++.h>
using namespace std;
string procstatus(){
	ifstream t("/proc/self/status");
	return string(istreambuf_iterator<char>(t),istreambuf_iterator<char>());
}
const long long md=998244353;
const int maxn=100100;
long long pw[5010*5010/2];
long long f[maxn],g[maxn],dp[maxn];
long long fac[maxn],inv[maxn];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
long long C(int n,int m){
	return fac[n]*inv[m]%md*inv[n-m]%md;
}
int gete(int n){
	return n*(n-1)/2;
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	fac[0]=1;
	for(int i=1;i<=n;i++)
		fac[i]=fac[i-1]*i%md;
	inv[n]=powd(fac[n],md-2);
	for(int i=n;i>=1;i--)
		inv[i-1]=inv[i]*i%md;

	pw[0]=1;
	for(int i=1;i<=n*(n-1)/2+1;i++)
		pw[i]=pw[i-1]*2%md;
	if(k==3){
		printf("%lld\n",(pw[gete(n)]-fac[n]+md)%md);
		return 0;
	}
	for(int i=2;i<=n;i++)
		for(int j=1;j<i;j++)
			(f[i]+=pw[gete(j)+gete(i-j)]*C(i,j))%=md;
	g[1]=1;
	for(int i=2;i<=n;i++){
		for(int j=1;j<i;j++)
			(g[i]+=g[j]*(f[i-j]+pw[gete(i-j)+1])%md*C(i-1,i-j))%=md;
		g[i]=(pw[gete(i)]-g[i]+md)%md;
	}
	if(k==n){
		printf("%lld\n",g[n]);
		return 0;
	}
	dp[0]=1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<k&&j<=i;j++)
			(dp[i]+=dp[i-j]*g[j]%md*C(i,i-j))%=md;
	printf("%lld\n",(pw[gete(n)]-dp[n]+md)%md);
	return 0;
}
