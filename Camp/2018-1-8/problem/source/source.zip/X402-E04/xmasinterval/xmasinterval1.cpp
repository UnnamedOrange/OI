#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>k=;--i)
#define ll long long 
using namespace std;
const int N=100,INF=0x3f3f3f3f,Mod=1e9+9;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval1.out","w",stdout);
}
int n,m,x[N],l[N],r[N],p[N],ans;
void init(){
	read(n),read(m);
	For(i,1,n)read(l[i]),read(r[i]);
	For(i,1,m)read(x[i]);
}
void dfs(int now){
	if(now>n){
		For(i,1,m){
			int ok=0;
			For(j,1,n)if(p[j]&&x[i]>=l[j]&&x[i]<=r[j]){ok=1;break;}
			if(!ok)return ;
		}
		return void (ans++);
	}
	p[now]=1;
	dfs(now+1);
	p[now]=0;
	dfs(now+1);
}
void solve(){
	dfs(1);
	printf("%d\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
