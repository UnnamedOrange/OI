《算法竞赛入门经典——训练指南》代码仓库

第六章习题代码

注意：有些题目并没有在书中出现，但是仍然有一定的启发意义，所以一并放在这里，供读者参考。

代码组织与调试（Writing and Debugging Complex Codes）

LA2727/UVa1024 A Linking Loader 刘汝佳

几何专题（Selected Topics in Geometry）

UVa 1497（LA5719） A Letter to Programmers 陈锋
