#include <bits/stdc++.h>
#include <bitset>
using namespace std;
const int MAXN = 8192;

struct Edge {
	int v, next;
};
struct Query {
	int op, a, b, c;
};

int e_ptr, dfs_clock, N, Q, Online, LastAns, C0[MAXN+10], C[MAXN+10],
 Dfn[MAXN+10], Sz[MAXN+10], head[MAXN+10];
bool Mdf; Edge E[(MAXN<<2)+10]; Query Qst[MAXN+10];

//�ֿ�
struct BlockSet {
	int BlkSize, L[MAXN+10], R[MAXN+10], Blk[MAXN+10];
	bitset<MAXN> S[410];
	inline void Init() {
		BlkSize = (int)(sqrt(N) + 0.5);
		for(int i=0; BlkSize*i+1 <= N; i++) {
			int Lb = BlkSize*i+1, Rb = BlkSize*(i+1);
			for(int j=Lb; j<=Rb; j++) {
				L[j] = Lb; R[j] = Rb;
				Blk[j] = i; S[i].set(C[j]);
			}
		}
	}
	inline void Modify(int p, int x) {
		int cnt=0; 
		for(int i=L[Blk[p]]; i<=R[Blk[p]]; i++)
			if(C[i]==x) cnt++;
		if(cnt==1) S[Blk[p]].reset(C[p]);
		S[Blk[p]].set(x);
		C[p]=x;
	}
	inline int Query(int l, int r, int ql, int qr) {
		int Lb = Blk[l], Rb = Blk[r];
		bitset<MAXN> Ans=0;
		if(Lb==Rb) {
			for(int i=l; i<=r; i++)
				if(ql<=C[i] && C[i]<=qr) Ans.set(C[i]);
		} else {
			for(int i=l; Blk[i] == Blk[l]; i++) 
				if(ql<=C[i] && C[i]<=qr) Ans.set(C[i]);
			for(int i=r; Blk[i] == Blk[r]; i--)
				if(ql<=C[i] && C[i]<=qr) Ans.set(C[i]);
			//O(sqrt(n)log(n))
			for(int ib=Blk[l]+1; ib<=Blk[r]-1; ib++) 
				Ans |= S[ib];
		}
		return Ans.count();
	}
};

inline void AddEdge(int u, int v) {
	E[++e_ptr] = (Edge) { v, head[u] }; head[u] = e_ptr;
}

inline void AddPair(int u, int v) {
	AddEdge(u,v); AddEdge(v,u);
}

int Dfs(int u) {
	Dfn[u] = ++dfs_clock; Sz[u] = 1;
	for(int j=head[u]; j; j=E[j].next) {
		int v=E[j].v;
		if(Dfn[v]) continue;
		else Sz[u] += Dfs(v);
	}
	return Sz[u];
}

template<typename T>
inline void readint(T& x) {
	T f=1, r=0;
	char c=getchar();
	while(!isdigit(c)) {
		if(c=='-')f=-1;
		c=getchar();
	}
	while(isdigit(c)) {
		r=r*10+c-'0';
		c=getchar();
	}
	x=f*r;
}

inline void Init() {
	int u, v;
	readint(N); readint(Q); readint(Online);
	for(int i=1; i<=N; i++) readint(C0[i]);
	for(int i=1; i<=N-1; i++) {
		readint(u); readint(v);
		AddPair(u, v);
	}
	for(int i=1; i<=Q; i++) {
		readint(Qst[i].op);
		switch(Qst[i].op) {
			case 1:
				readint(Qst[i].a); readint(Qst[i].b); readint(Qst[i].c);
				if(Qst[i].b > Qst[i].c) swap(Qst[i].b, Qst[i].c);
				break;
			case 2:
				readint(Qst[i].a); readint(Qst[i].b); Mdf=true;
				break;
		}
	}
	Dfs(1);
	for(int i=1; i<=N; i++) {
		C[Dfn[i]] = C0[i];
	}
}

inline void MdfWork() {
	static BlockSet BT;
	int u, ql, qr, c;
	BT.Init();
	for(int i=1; i<=Q; i++) {
		switch(Qst[i].op) {
			case 1:
				u = Qst[i].a^LastAns, ql = Qst[i].b^LastAns, qr = Qst[i].c^LastAns;
				printf("%d\n", LastAns=BT.Query(Dfn[u], Dfn[u]+Sz[u]-1, ql, qr));
				break;
			case 2:
				u = Qst[i].a^LastAns, c = Qst[i].b^LastAns;
				BT.Modify(Dfn[u], c);
				break;
		}
		if(!Online) LastAns=0;
	}
}

int main() {
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);

	Init(); MdfWork();
}
