#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while(!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while(isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n = n * sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 511111;
const int MOD = INF;
int n, m, rt, tt;
struct segment{int l, r;} seg[N];
int a[N], first[N], last[N], f[N], sum[N], prv[N];
struct seg_tr{int lc, rc, v, t;} tr[N*60];
struct BIT{
	int tr[N];
	void modify(int x, int k){for (; x < N; x += x & -x) tr[x] = (tr[x] + k) % MOD;}
	int query(int x){int ans = 0; for (; x; x -= x & -x) ans = (ans + tr[x]) % MOD; return ans;}
} t1, t2;

bool cmp(segment a, segment b){return a.r < b.r||a.r == b.r&&a.l > b.l;}
bool within(int x, int y){return a[x] >= seg[y].l&&a[x] <= seg[y].r;}
ll mut(ll a, ll b){
	ll y = 1, t = a;
	for (; b; b >>= 1, t = t * t % MOD)
		if (b & 1) y = y * t % MOD;
	return y;
}
#define mid ((l + r) >> 1)
void pushdown(int x){
	if (!tr[x].t) return ; tr[x].v = tr[x].t;
	if (!tr[x].lc) tr[x].lc = ++tt; tr[tr[x].lc].t = tr[x].t;
	if (!tr[x].rc) tr[x].rc = ++tt; tr[tr[x].rc].t = tr[x].t;
	tr[x].t = 0;
}
void modify(int& x, int l, int r, int nl, int nr, int k){
	if (!x) x = ++tt; pushdown(x);
	if (nl <= l&&r <= nr){tr[x].t = k; return ;}
	if (nl <= mid) modify(tr[x].lc, l, mid, nl, nr, k);
	if (mid <  nr) modify(tr[x].rc, mid + 1, r, nl, nr, k);
}
int query(int& x, int l, int r, int p){
	if (!x) return 0; pushdown(x);
	if (l == r) return tr[x].v;
	if (p <= mid) return query(tr[x].lc, l, mid, p);
	else return query(tr[x].rc, mid + 1, r, p);
}
#undef mid
namespace bf{
	int ans, d[N];
	bool check(){
		rep(i, 1, m){
			bool flg = false;
			rep(j, 1, n) 
				if (d[j]&&within(i, j)) flg = true;
			if (!flg) return false;
		}
	//	rep(i, 1, n) cerr << d[i]; cerr << endl;
		return true;
	}
	void dfs(int x){
		if (x > n){ans = (ans + check()) % MOD; return ;}
		d[x] = 1, dfs(x + 1);
		d[x] = 0, dfs(x + 1);
	}
	int main(){
		dfs(1);
		printf("%d\n", ans);
		return 0;
	}
};

int main(){
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	read(n), read(m);
	rep(i, 1, n) read(seg[i].l), read(seg[i].r);
	rep(i, 1, m) read(a[i]);
	sort(a + 1, a + m + 1), sort(seg + 1, seg + n + 1, cmp);
	if (n <= 20) {bf::main(); return 0;}
	int j = 1;
	rep(i, 1, n){
		for (; j + 1 <= m&&a[j+1] <= seg[i].r; ++j) ;
		last[i] = j, first[i] = lower_bound(a + 1, a + m + 1, seg[i].l) - a;
	}
	rep(i, 1, n){
		prv[i] = query(rt, 0, INF, seg[i].l - 1);
		modify(rt, 0, INF, seg[i].l, INF, i);
	}
	rep(i, 1, n){
		if (first[i] == 1){
			f[i] = mut(2, i - 1), sum[i] = (sum[i-1] + f[i]) % MOD;
			continue;
		}
		int l = 0, r = i;
		while(l + 1 < r){
			int mid = (l + r) >> 1;
			if (a[first[i]-1] <= seg[mid].r) r = mid; else l = mid;
		}
		if (r == i){
			f[i] = 0, sum[i] = sum[i-1];
			continue;
		}
		f[i] = (sum[i-1] - sum[l] + MOD) % MOD;
		f[i] = (f[i] - (sum[i-1] - sum[prv[i]] + MOD) % MOD + MOD) % MOD;
		f[i] = (ll)f[i] * mut(2, i - prv[i] - 1) % MOD;
		sum[i] = (sum[i-1] + f[i]) % MOD;
	}
//	rep(i, 1, n) cerr << prv[i] << ' '; cerr << endl;
//	rep(i, 1, n) cerr << seg[i].l << ' ' << seg[i].r << endl;
//	rep(i, 1, n) cerr << f[i] << ' '; cerr << endl;
	int ans = 0;
	per(i, n, 1) if (last[i] == m) ans = (ans + f[i]) % MOD;
	printf("%d\n", ans);
	return 0;
}

