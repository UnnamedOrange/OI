cas=1
while true; do
	./test || break
	./xmastree3 ||break
	./xmastree31 || break
	diff ./xmastree3.out ./xmastree31.out || break
	echo $cas
	cas=`expr $cas + 1`
done
