#include <bits/stdc++.h>

namespace {

inline char read() {
    static const int IN_LEN = 1 << 18 | 1;
    static char buf[IN_LEN], *s, *t;
    return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
            s == t ? -1 : *s++;
}

template <typename T>
inline void read(T &x) {
    static char c;
    static bool iosig;
    for (c = read(), iosig = false; !isdigit(c); c = read()) {
        if (c == -1) return;
        iosig |= c == '-';
    }
    for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
    iosig && (x = -x);
}

inline int read(char *buf) {
    register int s = 0;
    register char c;
    while (c = read(), isspace(c) && c != -1)
        ;
    if (c == -1) {
        *buf = 0;
        return -1;
    }
    do
        buf[s++] = c;
    while (c = read(), !isspace(c) && c != -1);
    buf[s] = 0;
    return s;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
    (oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
    *oh++ = c;
}

template <typename T>
inline void print(T x) {
    static int buf[21], cnt;
    if (x != 0) {
        (x < 0) && (print('-'), x = -x);
        for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
        while (cnt) print((char)buf[cnt--]);
    } else {
        print('0');
    }
}

inline void print(const char *s) {
    for (; *s; s++) print(*s);
}

struct InputOutputStream {
    ~InputOutputStream() {
        fwrite(obuf, 1, oh - obuf, stdout);
    }

    template <typename T>
    inline InputOutputStream &operator>>(T &x) {
        read(x);
        return *this;
    }

    template <typename T>
    inline InputOutputStream &operator<<(const T &x) {
        print(x);
        return *this;
    }
} io;

const double INIT_T = 1000000;
const double EPS = 0.1;
const double DROP = 0.99999;

const int MAXN = 10000;

int n, w[MAXN], r[MAXN], fa[MAXN], id[MAXN], in[MAXN], out[MAXN], idx;

typedef unsigned int uint;

inline uint nextUint() {
    static uint x = 495;
    return x ^= x << 13, x ^= x >> 17, x ^= x << 5, x;
}
std::vector<int> edge[MAXN];

void dfs(const int u, const int pre) {
    in[u] = id[u] = ++idx;
    for (register int i = 0, v; i < (int)edge[u].size(); i++) {
        if ((v = edge[u][i]) != pre) {
            fa[v] = u;
            dfs(v, u);
        }
    }
    out[u] = idx;
}

std::vector<int> roots;


inline void addEdge(const int u, const int v) {
    edge[u].push_back(v);
    edge[v].push_back(u);
}

inline void solve() {
    io >> n;
    for (register int i = 1, u, v; i < n; i++) {
        io >> u >> v;
        addEdge(u, v);
    }
    for (register int i = 1; i <= n; i++) {
        io >> w[i] >> r[i];
        if (r[i]) roots.push_back(i);
    }
    register int ans = 0;
    for (register int i = 0; i < (int)roots.size(); i++) {
        fa[roots[i]] = 0;
        idx = 0;
        dfs(roots[i], 0);
        register int nowAns = 0, now = 0;
        for (register int i = 1; i <= n; i++) {
            now += w[i] * id[i];
        }
        nowAns = now;
        ans = std::max(ans, nowAns);
        for (register double T = INIT_T; T > EPS; T *= DROP) {
            register int u, v;
            for (;;) {
                do {
                    u = nextUint() % n + 1;
                    v = nextUint() % n + 1;
                } while (u == v);
                if (id[u] > id[v]) std::swap(u, v);
                if (!(in[v] >= in[u] && out[v] <= out[u])) break;
            }
            register int old = id[u] * w[u] + id[v] * w[v];
            std::swap(id[u], id[v]);
            register int tmp = id[u] * w[u] + id[v] * w[v], delta = tmp - old;
            nowAns = std::max(nowAns, now - old + tmp);
            if (delta >= 0 || exp(delta / T) * nextUint() >= UINT_MAX) {
                now += delta;
            } else {
                std::swap(id[u], id[v]);
            }
        }
        ans = std::max(ans, nowAns);
    }
    io << ans;
}
}

int main() {
    freopen("xmastree2.in", "r", stdin);
    freopen("xmastree2.out", "w", stdout);
    solve();
    return 0;
}