#include <iostream>
#include <cstdio>
using namespace std;
const int MOD = 1e9 + 7;
int s, t, n, m;
int f[110][110];
int main () {
	freopen ("success.in", "r", stdin);
	freopen ("success.out", "w", stdout);
	scanf ("%d%d%d%d", &s, &t, &n, &m);
	for (int i = 0; i <= s; i++) f[0][i] = 1;
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= s; j++)
			for (int k = 1; k <= min (j, i <= n ? t : s); k++)
				f[i][j] = (f[i][j] + f[i - 1][j - k]) % MOD;
	printf ("%d\n", f[m][s]);
	return 0;
}
