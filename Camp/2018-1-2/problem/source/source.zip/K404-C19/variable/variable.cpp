#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define o 2001
using namespace std;
int x[o],y[o],z[o],a[o],b[o],c[o],d[o],e[o],f[o],g[o],ax[o],ay[o],ar[o];
int n,W,p,q,T,ans;
int abs(int x){
	return x<0?-x:x;
}
int main(){
	scanf("%d",&T);
	while(T--){
		freopen("variable.in","r",stdin);
		freopen("variable.out","w",stdout);
		memset(f,-1,sizeof(f));
		ans=1e9;
		scanf("%d%d%d%d",&n,&W,&p,&q);
		for(int i=1;i<=p;i++)
			scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for(int i=1;i<=q;i++)
			scanf("%d%d%d",&ax[i],&ay[i],&ar[i]);
		for(int i=0;i<(1<<n);i++){
			for(int j=0;j<n;j++){
				if(i&(1<<j))
					g[j+1]=W;
				else
					g[j+1]=-W;
			} 
			bool ok=true;
			for(int j=1;j<=q;j++) {
				switch (ar[j]){
					case 0:{
						if(g[ax[j]]>g[ay[j]]) ok=false;
						break;
					}
					case 1:{
						if(g[ax[j]]!=g[ay[j]]) ok=false;
						break;
					}
					case 2:{
						if(g[ax[j]]>=g[ay[j]]) ok=false;
						break;
					}
				}
				if(!ok)break;
			}
			if(!ok)continue;
			int sum=0;
			for(int j=1;j<=n;j++) sum+=g[j];
			for(int j=1;j<=p;j++)
				sum+=a[j]*abs(g[x[j]]-g[y[j]])+b[j]*abs(g[z[j]]-g[y[j]])+c[j]*abs(g[z[j]]-g[x[j]])+d[j]*(g[x[j]]-g[y[j]])+e[j]*(g[y[j]]-g[z[j]])+f[j]*(g[z[j]]-g[x[j]]);
			ans=min(ans,sum);
		}	
		printf("%d\n",ans);
	}
}
