#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e5+5;

char str[N];
int n;
struct P_0{
	bool OK[1<<10];
	int dp[1<<10];
	void work(){
		rep(i,1,1<<n){
			static char s[11];
			int cnt=0;
			rep(j,0,n)if(i>>j&1)s[++cnt]=str[j];
			OK[i]=true;
			for(int a=1,b=cnt;a<b;++a,--b)if(s[a]!=s[b])OK[i]=false;
		}
		dp[0]=0;
		rep(i,1,1<<n){
			dp[i]=n+1;
			for(int j=i;j;j=(j-1)&i)
				if(!OK[j]){
					//��Ҫ��������
					int flag=1;
					rep(k,0,n){
						if(j>>k&1){
							if(flag==2){
								flag=-1;
								break;
							}
							flag=0;
						}else if(i>>k&1){
							if(!flag)flag=2;
						}
					} 
					if(~flag)Min(dp[i],dp[i^j]+1);
				}
		}
		if(dp[(1<<n)-1]>=n)dp[(1<<n)-1]=-1;
		ptn(dp[(1<<n)-1]);
	}
}P0;
struct P_1{
	bool mark[105][105];
	int dp[105];
	void work(){
		memset(mark,0,sizeof mark);
		rep(i,0,n){
			for(int a=i,b=i;a>=0&&b<n;--a,++b){
				if(str[a]!=str[b])break;
				mark[a][b]=true;
			}
			if(i){
				for(int a=i-1,b=i;a>=0&&b<n;--a,++b){
					if(str[a]!=str[b])break;
					mark[a][b]=true;
				}
			}
		}
		dp[n]=0;
		per(i,0,n){
			dp[i]=n+1;
			rep(j,i,n)if(!mark[i][j])Min(dp[i],dp[j+1]+1);
		}
		if(dp[0]>=n)dp[0]=-1;
		ptn(dp[0]);
	}
}P1;
int base1[N],base2[N];
struct P_2{
	#define P1 1000000007
	#define P2 1000000009
	struct HASH{
		char s[N];
		int hash1[N],hash2[N];
		void init(){
			per(i,0,n)s[i+1]=s[i];
			s[0]=0;
			rep(i,1,n+1){
				hash1[i]=(s[i]+(ll)hash1[i-1]*233)%P1;
				hash2[i]=(s[i]+(ll)hash2[i-1]*233)%P2;
			}
		}
		pii query(int l,int r){
			int a=(hash1[r+1]-hash1[l]*(ll)base1[r-l+1])%P1;
			if(a<0)a+=P1;
			int b=(hash2[r+1]-hash2[l]*(ll)base2[r-l+1])%P2;
			if(b<0)b+=P2;
			return pii(a,b);
		}
	}A,B;
	void work(){
		base1[0]=base2[0]=1;
		rep(i,1,n+1){
			base1[i]=(ll)base1[i-1]*233%P1;
			base2[i]=(ll)base2[i-1]*233%P2;
		}
		memcpy(A.s,str,sizeof str);
		memcpy(B.s,str,sizeof str);
		reverse(B.s,B.s+n);
		A.init(),B.init();
		if(A.query(0,n-1)!=B.query(0,n-1))ptn(1);
		else {
			int res=-1;
			rep(i,1,n-1){
				if(A.query(0,i)!=A.query(n-i-1,n-1)&&B.query(i+1,n-1)!=B.query(0,n-i-2)){
				   res=2;
				   break;
				}
			}
			ptn(res);
		}
	}
	#undef P1
	#undef P2
}P2;
void solve(){
	scanf("%d%s",&n,str);
	if(0);
	else if(n<=10)P0.work();
	else if(n<=100)P1.work();
	else if(n<=1000)P2.work();
}

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;rd(T);
	while(T--)solve();
	return 0;
}
