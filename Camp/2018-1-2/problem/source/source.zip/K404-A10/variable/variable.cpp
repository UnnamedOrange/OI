#include <bits/stdc++.h>

struct edge2 {
	int enext,to;
} ee[3003];int en2;
struct vertex {
	int p,k,w,ww;
	int estart;
} v[503];int temp[503];
bool mat[503][503];
struct edge {
	int a,b,k;
} e[3003];int en;
void dfs(int i,int j)
{
	mat[i][j] = true;
	for(int k = v[j].estart;k != -1;k = ee[k].enext) {
		int to = ee[k].to;
		if(!mat[i][to]) {
			mat[i][to] = true;
			dfs(i,to);
		}
	}
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int t,n,w,p,q;
	scanf("%d",&t);
	while(t--) {
		scanf("%d%d%d%d",&n,&w,&p,&q);en = en2 = 0;
		memset(mat,0,sizeof(mat));
		for(int i = 0;i < n;++i) {
			v[i].p = i;
			v[i].k = 1;
			v[i].w = 0;
			v[i].ww = 1;
			mat[i][i] = true;
			v[i].estart = -1;
		}
		for(int i = 0;i < p;++i) {
			int x,y,z,a,b,c,d,ee,f;
			scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&ee,&f);--x,--y,--z;
			v[x].k += d - f;
			v[y].k += ee - d;
			v[z].k += f - ee;
			e[en].a = x;e[en].b = y;e[en].k = a;++en;
			e[en].a = y;e[en].b = z;e[en].k = b;++en;
			e[en].a = z;e[en].b = x;e[en].k = c;++en;
		}
		for(int i = 0;i < q;++i) {
			int x,y,r;
			scanf("%d%d%d",&x,&y,&r);--x,--y;
			switch(r) {
				case 0:
					// x <= y
					ee[en2].to = y;ee[en2].enext = v[x].estart;v[x].estart = en2;++en2;
					break;
				case 1:
					ee[en2].to = y;ee[en2].enext = v[x].estart;v[x].estart = en2;++en2;
					ee[en2].to = x;ee[en2].enext = v[y].estart;v[y].estart = en2;++en2;
					break;
				case 2:
					v[x].w = v[x].ww = -1;
					v[y].w = v[y].ww = 1;
					break;
			}
		}
		for(int i = 0;i < n;++i) {
			dfs(i,i);
		}
		int ans = 0;
		for(int i = 0;i < en;++i) ans += abs(v[e[i].a].ww - v[e[i].b].ww) * e[i].k;
		for(int i = 0;i < n;++i) ans += v[i].ww * v[i].k;
		
		bool changed = true;
		while(changed) {
			changed = false;
			for(int i = 0;i < n;++i) {
				if(v[i].w == 0 && v[i].ww == 1) {
					for(int j = 0;j < n;++j) temp[j] = v[j].ww;
					temp[i] = -1;
					for(int j = 0;j < n;++j) if(mat[j][i] && v[j].ww == 1) temp[j] = -1;
					int newans = 0;
					for(int j = 0;j < en;++j) newans += abs(temp[e[j].a] - temp[e[j].b]) * e[j].k;
					for(int j = 0;j < n;++j) newans += temp[j] * v[j].k;
					if(newans < ans) {
						for(int j = 0;j < n;++j) v[j].ww = temp[j];
						changed = true;
						ans = newans;
					}
				} else if(v[i].w == 0 && v[i].ww == -1) {
					for(int j = 0;j < n;++j) temp[j] = v[j].ww;
					temp[i] = 1;
					for(int j = 0;j < n;++j) if(mat[i][j] && v[j].ww == 1) temp[j] = 1;
					int newans = 0;
					for(int j = 0;j < en;++j) newans += abs(temp[e[j].a] - temp[e[j].b]) * e[j].k;
					for(int j = 0;j < n;++j) newans += temp[j] * v[j].k;
					if(newans < ans) {
						for(int j = 0;j < n;++j) v[j].ww = temp[j];
						changed = true;
						ans = newans;
					}
				}
			}
		}
		printf("%d\n",ans);
	}
}
