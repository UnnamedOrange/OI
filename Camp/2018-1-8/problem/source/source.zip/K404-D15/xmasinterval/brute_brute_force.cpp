#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 10005
const int mod=1000000009;

int n,m;
int a[maxn],l[maxn],r[maxn];
int f[maxn][maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

struct interval{
	int l,r;
	bool operator <(const interval &a)const{return l<a.l||(l==a.l&&r<a.r);}
}p[maxn];

int main(){
	n=read(),m=read();
	for (int i=1;i<=n;i++) p[i].l=read(),p[i].r=read();
	for (int i=1;i<=m;i++) a[i]=read(); int ans=0;
	for (int i=1;i<(1<<n);i++){
		bool can=1;
		for (int j=1;j<=m;j++){
			bool flag=0;
			for (int k=1;k<=n;k++)
				if ((i>>(k-1)&1)&&a[j]>=p[k].l&&a[j]<=p[k].r){flag=1; break;}
			if (!flag){can=0; break;}
		}
		ans+=can;
	}
	cout<<ans<<endl;
	return 0;
}
