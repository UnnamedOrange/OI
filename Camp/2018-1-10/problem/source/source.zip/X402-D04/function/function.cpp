#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1000010;
const int N=1000000;
int n;
int isprime[maxn], prime[maxn], cnt;
ll sum[maxn], mu[maxn];
vector<int> g[maxn];

void init(){
	mu[1]=1;
	for(int i=2;i<maxn;i++){
		if(!isprime[i]){ prime[++cnt]=i; mu[i]=-1; }
		for(int j=1;j<=cnt && i*prime[j]<maxn;j++){
			isprime[i*prime[j]]=1; mu[i*prime[j]]=-mu[i];
			if(i%prime[j]==0){
				mu[i*prime[j]]=0;
				break; 
			}
		}
	}
	// for(int i=1;i<=10;i++) printf("%d ", mu[i]); puts("");
	for(int i=1;i<maxn;i++) for(int j=i;j<maxn;j+=i) g[j].push_back(i), sum[j]++;
	ll t=0;
	for(int i=1;i<maxn;i++) t+=sum[i];
	// printf("%lld\n", t);
	for(int i=1;i<maxn;i++) sum[i]=sum[i]*sum[i];
}

ll ans[maxn];
int main(){
	freopen("function.in","r",stdin),freopen("function.out","w",stdout);

	// for(int i=0;i<g[100].size();i++) printf("%d ", g[100][i]); puts("");
	// return 0;
	int T;
	scanf("%d", &T);
	if(!T){ return 0; }
	init();
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	ll t=0;
	for(int i=1;i<=N;i++){
		for(int j=0;j<g[i].size();j++){
			int d=g[i][j];
			t+=mu[d]*sum[i/d];
			ans[i]=ans[i-1]+mu[d]*sum[i/d];
		}
		ans[i]=t;
	}
	while(T--){
		scanf("%d", &n);
		printf("%lld\n", ans[n]);
	}
	cerr<<1.0*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
