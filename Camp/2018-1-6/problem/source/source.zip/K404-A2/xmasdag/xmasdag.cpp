#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<map>
#include<set>
#include<iomanip>
#include<ctime>
using namespace std;
typedef long long ll;
char xB[1<<15],*xT=xB,*xS=xB;
#define getchar() (xS==xT&&(xT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xT)?0:*xS++)
inline int read()
{
    int X=0,w=0; char ch=0;
    while(!isdigit(ch)) w|=ch=='-',ch=getchar();
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}
const int N=100010;
const int M=200010;
const int mod=998244353;
int n,m,k,op;
int to[M],nexl[M],edgecnt,head[N];
inline void addedge(int u,int v)
{
	to[++edgecnt]=v;nexl[edgecnt]=head[u];head[u]=edgecnt;
}
ll qpow(ll a,int b)
{
	ll ans=1;
	while(b)
	{
		if(b&1)ans=ans*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ans;
}
ll a[2][N],ans[N];
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	register int p,j,i,u,v;
	n=read();m=read();k=read();
	for(i=1;i<=m;++i)
	{
		u=read();v=read();
		addedge(u,v);
	}
	a[op][1]=1;
	for(i=1;i<=n;++i)
	{
		for(j=1;j<=n;++j)a[op^1][j]=0;
		for(j=1;j<=n;++j)
		{
			if(a[op][j]==0)continue;
			for(p=head[j];p;p=nexl[p])
			{
				a[op^1][to[p]]+=a[op][j];
			}
		}
		ll temp=qpow(i,k);
		for(j=1;j<=n;++j)ans[j]=(ans[j]+(temp*a[op^1][j])%mod)%mod;
		op^=1;
	}
	for(i=1;i<=n;++i)
	{
		printf("%d\n",ans[i]);
	}
}
/*
6 8 2
1 2
1 3
1 5
2 4
3 2
3 4
3 6
4 6
*/