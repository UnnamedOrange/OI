#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
using namespace std;
const int INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
}
int n;
namespace BF1{
	const int N=100010;
	int col[N],Begin[N],Next[N<<1],to[N<<1],e,q,t,cnt[N],fa[N],ans;
	inline void add(int x,int y){
		to[++e]=y,Next[e]=Begin[x],Begin[x]=e;
	}
	void dfs(int u){
		Rep(i,u)if(v!=fa[u])fa[v]=u,dfs(v);
	}
	void init(){
		read(q),read(t);
		For(i,1,n)read(col[i]);
		For(i,1,n-1){
			int x,y;
			read(x),read(y);
			add(x,y),add(y,x);
		}
		dfs(1);
	}
	void Dfs(int u,int l,int r){
		if(col[u]>=l&&col[u]<=r&&!cnt[col[u]])ans++,cnt[col[u]]=1;
		Rep(i,u)if(v!=fa[u])Dfs(v,l,r);
	}
	void solve(){
		int lastans=0;
		init();
		while(q--){
			int tp,u,l,r,c;
			read(tp);
			if(tp==1){
				read(u),read(l),read(r);
				if(t)u^=lastans,l^=lastans,r^=lastans;
				For(i,l,r)cnt[i]=0;
				ans=0;Dfs(u,l,r);
				printf("%d\n",lastans=ans);
			}else {
				read(u),read(c);
				if(t)u^=lastans,c^=lastans;
				col[u]=c;
			}
		}
	}
}

void solve(){
	read(n);
	BF1::solve();
}
int main(){
	file();
	solve();
	return 0;
}
