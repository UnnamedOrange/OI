#include<bits/stdc++.h>
using namespace std;

const int maxn = 1e+5 + 10;

struct edge{
	int v,n;
}e[maxn<<1];

int n,q,t,head[maxn],en;
int tim,tclr[maxn],dfn[maxn],siz[maxn],clr[maxn];

void read()
{
	int i,u,v;
	scanf("%d%d%d",&n,&q,&t);
	
	memset(head,-1,sizeof(head));
	for(i=1;i<=n;i++) scanf("%d",tclr+i);
	for(i=0;i<n-1;i++)
	{
		scanf("%d%d",&u,&v);
		e[i<<1].v=v;e[i<<1].n=head[u];head[u]=i<<1;
		e[i<<1|1].v=u;e[i<<1|1].n=head[v];head[v]=i<<1|1;
	}
}

void dfs(int x,int fa)
{
	int i;
	
	dfn[x]=tim;siz[x]=1;clr[tim++]=tclr[x];
	for(i=head[x];i!=-1;i=e[i].n) if(e[i].v!=fa)
	{
		dfs(e[i].v,x);siz[x]+=siz[e[i].v];
	}
}

int lastans;
void solve()
{
	int c,u,i,l,r;
	set<int> s;
	
	scanf("%d",&c);
	if(c==1) 
	{
		scanf("%d%d%d",&u,&l,&r);
		if(t) {u^=lastans;l^=lastans;r^=lastans;}
		s.clear();
		for(i=dfn[u];i<dfn[u]+siz[u];i++) if(clr[i]>=l && clr[i]<=r) s.insert(clr[i]);
		cout<<(lastans=s.size())<<endl;
	}
	else
	{
		scanf("%d%d",&u,&c);
		if(t){u^=lastans;c^=lastans;}
		clr[dfn[u]]=c;
	}
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	
	read();
	dfs(1,-1);
	lastans=0;
	while(q--) solve();
	
	return 0;
}
