#include <queue>
#include <cstdio>
#include <cstring>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

const int NON = 1000005;
int N, M, U[NON], V[NON],
	Head[NON], Next[NON], To[NON], In[NON], Dis[NON],
	DFN[NON], Low[NON], ID[NON], Size[NON], gIndex, tIndex, cIndex;

inline void addEdge(int u, int v) {
	Next[++gIndex] = Head[u]; To[Head[u] = gIndex] = v;
}

inline void Tarjan(int u) {
	static bool inStack[NON];
	static int Stack[NON];
	DFN[u] = Low[u] = ++tIndex;
	inStack[Stack[++Stack[0]] = u] = true;
	for(int e = Head[u], v; e; e = Next[e]) {
		if(!DFN[v = To[e]]) {
			Tarjan(v);
			if(Low[v] < Low[u]) Low[u] = Low[v];
		} else if(inStack[v] && DFN[v] < Low[u]) Low[u] = DFN[v];
	}
	if(DFN[u] == Low[u]) {
		int v;
		Size[++cIndex] = 0;
		do {
			inStack[v = Stack[Stack[0]--]] = false;
			Size[ID[v] = cIndex]++;
		} while(v != u);
	}
}

inline void solve() {
	static std::queue<int> Que;
	N = get_int(), M = get_int();
	for(int i = 1; i <= M; ++i)
		U[i] = get_int(), addEdge(U[i], V[i] = get_int());
	for(int i = 1; i <= N; ++i) if(!DFN[i]) Tarjan(i);
	memset(Head, 0, sizeof Head); gIndex = 0;
	for(int i = 1; i <= M; ++i)
		if(ID[U[i]] != ID[V[i]])
			addEdge(ID[U[i]], ID[V[i]]), In[ID[V[i]]]++;
	for(int i = 1; i <= cIndex; ++i)
		if(!In[i]) Que.push(i), Dis[i] = Size[i];
	while(!Que.empty()) {
		int u = Que.front();
		Que.pop();
		for(int e = Head[u], v; e; e = Next[e]) {
			v = To[e];
			if(Dis[v] < Dis[u] + Size[v])
				Dis[v] = Dis[u] + Size[v];
			if(!--In[v]) Que.push(v);
		}
	}
	int ans = 0;
	for(int i = 1; i <= cIndex; ++i)
		if(ans < Dis[i]) ans = Dis[i];
	printf("%d\n", ans);
}

#define PROBLEM_NAME	"bomb"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	solve();
	return 0;
}
