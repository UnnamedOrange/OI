#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=1010,inf=0X3f3f3f3f;

char s[N];
bool f[N][N];

int tot;
struct segment{int l,r;}seg[N];

void get_seg(int n)
{
	register int i,j,k;
	for(k=1;k<n;++k)
		for(i=1;i+k<=n;++i)
			f[i][i+k]=(f[i+1][i+k-1] && s[i]==s[i+k]);
	tot=0;
	for(j=2;j<=n;++j)
		for(i=1;i<j;++i)
			if(!f[i][j])
				seg[++tot]=(segment){i,j};
}

int g[N];

int get_ans(int n)
{
	register int i,now(1);
	g[0]=0;g[1]=inf;
	for(i=2;i<=n;++i)
	{
		g[i]=inf;
		while(seg[now].r==i && now<=tot)
		{
			g[i]=min(g[seg[now].l-1]+1,g[i]);
			now++;
		}
	}
	if(g[n]>=inf) return -1;
	return g[n];
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	
	register int i;
	for(i=1;i<N-1;++i) f[i][i]=f[i+1][i]=1;
	int T=read(),n;
	while(T--)
	{
		n=read();
		scanf("%s",s+1);
		get_seg(n);
		print(get_ans(n));
		putchar('\n');
	}
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}

