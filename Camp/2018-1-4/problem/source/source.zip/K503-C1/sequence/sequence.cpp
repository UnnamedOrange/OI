# include <bits/stdc++.h>
# define 	inf 	1e9
# define 	N 		21
# define 	T 		5000000
using namespace std;
int a[N],num[N],b[N],ansl[N],n,ans,cnt,ti;
void dfs(int k, int la){
	int flag=0;
	for (int i=2; i<=n; i++) 
		if (abs(a[i]-a[i-1])!=1) 
			flag++;
	if (flag==0&&a[2]>a[1]) ans=min(k-1,ans);
	if (k+flag>n+2||k>=ans) return; 
	ti++; if (ti>T) return;
	for (int i=2; i<=n-1; i++){
		if (abs(a[1]-a[i+1])!=1) continue;
		for (int j=1; j<=i/2; j++) swap(a[j],a[i-j+1]);
		dfs(k+1,i);
		for (int j=1; j<=i/2; j++) swap(a[j],a[i-j+1]);
	}
	for (int i=2; i<=n; i++){
		if (abs(a[i]-a[i+1])==1&&i!=n||la==i) continue;
		for (int j=1; j<=i/2; j++) swap(a[j],a[i-j+1]);
		dfs(k+1,i);
		for (int j=1; j<=i/2; j++) swap(a[j],a[i-j+1]);
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int opt,ca=1;
	for (scanf("%d",&opt); ca<=opt; ca++){
		ti=0;
		scanf("%d",&n);
		for (int i=1; i<=n; i++)
			scanf("%d",&a[i]);
		ans=inf; cnt=0;
		if (n<=12)
 			dfs(1,0);
 			else {
 				ans=n+1;
 				for (int i=1; i<=n-1; i++)
 					if (abs(a[i]-a[i+1])==1) ans--;
			 }
		printf("%d\n",ans);
	}
	return 0;
}

