#include<bits/stdc++.h>
using namespace std;

bool flag[900000];

int main(){
	int maxh=0;
	srand(time(0));
	int n=rand()%920+1,t=n*(n-1);
//	cerr<<"making input for a...\n";
	{
		FILE*in=fopen("xmasset1.in","w");
		fprintf(in,"1\n%d %d\n",n,t);
		for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
				if(i!=j)
					fprintf(in,"%d %d\n",i,j);
		fclose(in);
	}
//	cerr<<"running...\n";
	{
		system("./xmasset <xmasset1.in >xmasset1.out");
	}
//	cerr<<"making input for b...\n";
	{
		FILE*out=fopen("xmasset1.out","r");
		FILE*in=fopen("xmasset2.in","w");
		fprintf(in,"2\n%d %d\n",n,t);
		for(int i=1,cnt=0;i<=n;++i)
			for(int j=1;j<=n;++j)
				if(i!=j){
					++cnt;
					flag[cnt]=rand()&1;
					int h;fscanf(out,"%d",&h);
					if(h<=0){
						cerr<<"H<=0"<<endl;
						exit(0);
					}
					if(h>maxh)maxh=h;
					fprintf(in,"%d %d\n",flag[cnt]?i:j,h);
				}
		fclose(out);fclose(in);
	}
//	cerr<<"running...\n";
	{
		system("./xmasset <xmasset2.in >xmasset2.out");
	}
	cerr<<"judging...\n";
	{
		FILE*out=fopen("xmasset2.out","r");
		for(int i=1;i<=t;++i){
			char s[4];
			fscanf(out,"%s",s);
			if((s[0]=='y')!=flag[i]){
				cerr<<"WRONG!!!"<<' '<<i<<endl;
				exit(0);
			}
		}
		fclose(out);
	}
	cerr<<endl<<"MAXH:   "<<maxh<<endl;
}
