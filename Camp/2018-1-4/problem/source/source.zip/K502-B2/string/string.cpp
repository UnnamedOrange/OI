#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int P=998244353,B=233,BP=(int)1e9+7;
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
int n,m;
char A[12][105];
int len[12];
struct SHUI{
	int AA[35];
	bool check(int S){
		int cnt=0,mm=m+m;
		for(int i=0;i<m;i++)
			if((S>>i)&1)AA[i]='1',AA[mm-i-1]='0';
			else AA[i]='0',AA[mm-i-1]='1';
		for(int i=0;i<n;i++){
			for(int j=0;j+len[i]-1<mm;j++){
				bool f=true;
				for(int l=0;l<len[i];l++)if(AA[j+l]!=A[i][l]){f=false;break;}
				if(f){cnt++;break;}
			}
		}
		return (cnt==n);
	}
	void solve(){
		int ans=0;
		for(int i=0,up=(1<<m);i<up;i++)ans+=check(i);
		printf("%d\n",ans);
	}
}P10;
struct IHSU{
	int ch[365][2],tot,fal[365],val[365];
	void ADD(char *A,int l,int v){
		int p=0;
		for(int i=0,c;i<l;i++){
			c=A[i]-'0';
			if(ch[p][c]==0)ch[p][c]=++tot;
			p=ch[p][c];
		}
		val[p]|=v;
	}
	void init(){
		static int q[365],L,R,p;L=R=0;
		if(ch[0][0])q[R++]=ch[0][0];
		if(ch[0][1])q[R++]=ch[0][1];
		while(L<R){
			p=q[L++];val[p]|=fal[p];
			if(ch[p][0])fal[q[R++]=ch[p][0]]=ch[fal[p]][0];
			else ch[p][0]=ch[fal[p]][0];
			if(ch[p][1])fal[q[R++]=ch[p][1]]=ch[fal[p]][1];
			else ch[p][1]=ch[fal[p]][0];
		}
	}
	int dp[105][365][(1<<6)];
	void solve(){
		for(int i=0;i<n;i++){
			ADD(A[i],len[i],(1<<i));
			for(int l=0,r=len[i]-1;l<r;l++,r--)swap(A[i][l],A[i][r]);
			for(int j=0;j<len[i];j++)A[i][j]=1-A[i][j]+'0'+'0';
			ADD(A[i],len[i],(1<<i));
		}
		init();
		int ans=0;
		dp[0][0][0]=1;
		int mxl=0;
		for(int i=0;i<n;i++)if(mxl<len[i])mxl=len[i];
		for(int i=1,p=0,up=m-mxl/2,upp=(1<<n),v;i<=up;i++,p++)
			for(int j=0,nxj;j<=tot;j++)
				for(int k=0;k<upp;k++)
					if((v=dp[p][j][k])){
						nxj=ch[j][0];
						Add(dp[i][nxj][k|val[nxj]],v);
						nxj=ch[j][1];
						Add(dp[i][nxj][k|val[nxj]],v);
					}
		for(int i=0,ppp=m-mxl/2,v,mxl2=mxl/2,mxl22=mxl2*2,w=(1<<(mxl/2));i<=tot;i++)
			for(int j=0,up=(1<<n)-1,tmpi,tmpj;j<=up;j++)
				if((v=dp[ppp][i][j])){
					for(int p=0;p<w;p++){
						static int AAA[35];
						for(int t=0;t<mxl2;t++)
							if((p>>t)&1)AAA[t]=1,AAA[mxl22-t-1]=0;
							else AAA[t]=0,AAA[mxl22-t-1]=1;
						tmpi=i,tmpj=j;
						for(int t=0;t<mxl22;t++)
							tmpi=ch[tmpi][AAA[t]],tmpj|=val[tmpi];
						if(tmpj==up)Add(ans,v);
					}
				}
		printf("%d\n",ans);
	}
}P50;
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d %d",&n,&m);
	int mxl=0;
	for(int i=0;i<n;i++){
		scanf("%s",A[i]);
		len[i]=strlen(A[i]);
		if(mxl<len[i])mxl=len[i];
	}
//	if(0);
	if(m<=15)P10.solve();
	else if(mxl<=30)P50.solve();
	
	return 0;
}
