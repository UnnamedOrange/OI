#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
using namespace std;
int n, m;
int head[1000010], to[1000010], nxt[1000010], cnt;
inline void addedge (int u, int v) { cnt++, to[cnt] = v, nxt[cnt] = head[u], head[u] = cnt; }
int head2[1000010], to2[1000010], nxt2[1000010], cnt2, in[1000010], siz[1000010];
inline void addedge2 (int u, int v) { cnt2++, to2[cnt2] = v, nxt2[cnt2] = head2[u], head2[u] = cnt2; }
int dfn[1000010], low[1000010], ind;
stack <int> s; priority_queue <pair<int, int>, vector <pair<int, int> >, greater <pair<int, int> > > q;
bool ins[1000010];
int ltk[1000010], num;
inline void tarjan (int u) {
	dfn[u] = low[u] = ++ind;
	s.push (u), ins[u] = true;
	for (int e = head[u]; e; e = nxt[e]) {
		int v = to[e];
		if (!dfn[v]) tarjan (v), low[u] = min (low[u], low[v]);
		else if (ins[v]) low[u] = min(low[u], dfn[v]);
	}
	if (dfn[u] == low[u]) {
		num++;
		while (s.top () != u) {
			ltk[s.top ()] = num;
			ins[s.top ()] = false;
			s.pop ();
		}
		ltk[u] = num, ins[u] = false, s.pop ();
	}
}
int main () {
	freopen ("bomb.in", "r", stdin);
	freopen ("bomb.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) {
		int u, v;
		scanf ("%d%d", &u, &v);
		addedge (u, v);
	}
	for (int i = 1; i <= n; i++) if (!dfn[i]) tarjan (i);
	//for (int i = 1; i <= n; i++) printf ("%d%c", ltk[i], " \n"[i == n]);
	for (int u = 1; u <= n; u++) {
		siz[ltk[u]]++;
		for (int e = head[u]; e; e = nxt[e]) {
			int v = to[e];
			if (ltk[u] != ltk[v]) in[ltk[v]]++, addedge2 (ltk[u], ltk[v]);
		}
	}
	for (int i = 1; i <= num; i++) if (!in[i]) q.push (make_pair (siz[i], i));
	while (!q.empty ()) {
		pair <int, int> u = q.top (); q.pop ();
		//printf ("%d %d\n", u.first, u.second);
		for (int e = head2[u.second]; e; e = nxt2[e]) {
			int v = to2[e];
			in[v]--;
			if (!in[v]) siz[v] += u.first, q.push (make_pair (siz[v], v));
		}
	}
	int ans = siz[1]; for (int i = 1; i <= num; i++) ans = max (ans, siz[i]);
	printf ("%d\n", ans);
	return 0;
}
