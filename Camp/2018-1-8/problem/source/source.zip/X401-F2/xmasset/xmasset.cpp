#include<bits/stdc++.h>
template<class T>void read(T &x){
    x=0;int f=0;char ch=getchar();
    while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
    while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x=f?-x:x;
    return ;
}

int t,N;

int mk(int x,int y){return -x;}

bool Judge(int q,int h){return q==abs(h);}

int main()
{
    int T;
    read(t),read(N),read(T);t--;
    while(T--){
        int x,y;
		read(x),read(y);
        if(!t) printf("%d\n",mk(x,y));
        else puts(Judge(x,y)?"yes":"no");
    }
    return 0;
}
