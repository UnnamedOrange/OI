#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=10,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
#ifndef ONLINE_JUDGE
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
#endif 
}
int n,p[N],vis[N],ans=0;
void init(){
	read(n);
	For(i,1,n)read(p[i]),vis[p[i]]=1;
}
int col[N];
bool Dfs(int u,int c){
	if(!col[u])col[u]=c;
	else return col[u]==c;
	return Dfs(p[u],c^1);
}
bool check(){
	For(i,1,n)col[i]=0;
	For(i,1,n)if(!col[i])if(!Dfs(i,2))return 0;
	return 1;
}
void dfs(int now){
	if(now>n)return void(ans+=check());
	if(p[now])dfs(now+1);
	For(i,1,n)if(!vis[i]){
		p[now]=i;vis[i]=1;
		dfs(now+1);
		p[now]=0;vis[i]=0;
	}
}
void solve(){
	dfs(1);
	printf("%d\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
