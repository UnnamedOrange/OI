#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
const int mod=1000000007;
int s,t,n,m;
ll f[2][1000010];
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	f[0][0]=1;
	int v=1;
	for(int i=1;i<=n;i++,v^=1)
	{
		for(int j=0;j<=s;j++)
			f[v][j]=0;
		for(int j=i;j<=min(s,t*i);j++)
			for(int k=1;k<=min(j,t);k++)
				(f[v][j]+=f[v^1][j-k])%=mod;
	}
	for(int i=n+1;i<=m;i++,v^=1)
	{
		for(int j=0;j<=s;j++)
			f[v][j]=0;
		for(int j=i;j<=s;j++)
			for(int k=1;k<=j;k++)
				(f[v][j]+=f[v^1][j-k])%=mod;
	}
	ll ans=0;
	for(int i=1;i<=s;i++)
		(ans+=f[m&1][i])%=mod;
	printf("%lld",ans);						
	return 0;
}
