#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
inline void print(int x)
{
    if(!x){putchar('0'),putchar('\n');return;}
    static char s[10];
    static short len;
    for(len=0;x;x/=10)s[++len]=x%10;
    for(;len;putchar(s[len--]^48));
    putchar('\n');
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	#endif
}
const int MAXN=1e5+7;
static struct edge
{
    int v,next;
}p[MAXN<<1];
static struct query
{
    int opt,l,r,x;
}q[MAXN<<1];
static int n,m,t,c[MAXN],e,head[MAXN],fa[MAXN],sz[MAXN],dfn[MAXN];
inline void add(int u,int v){p[++e].v=v;p[e].next=head[u];head[u]=e;}
void dfs(int u)
{
    dfn[u]=++e;sz[u]=1;
    for(register int v=head[u];v;v=p[v].next)
        if(p[v].v^fa[u])fa[p[v].v]=u,dfs(p[v].v),sz[u]+=sz[p[v].v];
}
void init()
{
    read(n);read(m);read(t);
    Rep(i,1,n)read(c[i]);
    static int u,v;
    Rep(i,1,n-1)read(u),read(v),add(u,v),add(v,u);
    Rep(i,1,m)
    {
        read(q[i].opt);
        if(q[i].opt==1)read(q[i].x),read(q[i].l),read(q[i].r);
        else read(q[i].l),read(q[i].x);
    }
    e=0;
    dfs(1);
}
namespace Cheat1
{
    static int blc,lastans=0;
    static bitset<50003>G[320];
    static short cnt[320][50003];
    inline int query(int l,int r,int x,int y)
    {
        static bitset<50003>ans;
        if(ans.any())ans.reset();
        if((l-1)/blc==(r-1)/blc)
        {
            Rep(i,l,r)if(c[i]>=x&&c[i]<=y)ans[c[i]]=1;
            return ans.count();
        }
        for(;(l-1)%blc!=0;++l)if(c[l]>=x&&c[l]<=y)ans[c[l]]=1;
        if((l-1)/blc==(r-1)/blc)
        {
            Rep(i,l,r)if(c[i]>=x&&c[i]<=y)ans[c[i]]=1;
            return ans.count();
        }
        for(;r%blc!=0;--r)if(c[r]>=x&&c[r]<=y)ans[c[r]]=1;
        Rep(i,(l-1)/blc+1,(r-1)/blc+1)ans|=G[i];
        return (((ans>>x)<<x)^(ans>>(y+1)<<(y+1))).count();
    }
    inline void modify(int pos,int x)
    {
        if(x==c[pos])return;
        if(!(--cnt[(pos-1)/blc+1][c[pos]]))G[(pos-1)/blc+1][c[pos]]=0;
        ++cnt[(pos-1)/blc+1][c[pos]=x];
        G[(pos-1)/blc+1][x]=1;
    }
    void solve()
    {
        blc=sqrt(n);
        Rep(i,1,blc)Rep(j,blc*(i-1)+1,min(blc*i,n))G[i][c[j]]=1,++cnt[i][c[j]];
        Rep(i,1,m)
        {
            if(q[i].opt==1)
            {
                if(t)q[i].l^=lastans,q[i].r^=lastans,q[i].x^=lastans;
                print(lastans
                    =query(dfn[q[i].x],dfn[q[i].x]+sz[q[i].x]-1,q[i].l,q[i].r));
            }
            else
            {
                if(t)q[i].l^=lastans,q[i].x^=lastans;
                modify(dfn[q[i].l],q[i].x);
            }
        }
    }
}
int main(void){
	file();
    init();
	Cheat1::solve();
    return 0;
}

