#include<bits/stdc++.h>

using namespace std;

const int MOD = 1e9;

int main(){
	
	freopen("xmasinterval.in", "w", stdout);

	srand(time(NULL));

	int n = 500000, m = 500000;
	printf("%d %d\n", n, m);
	for(int i = 1;i <= n; ++i){
		int r = rand() % MOD + 1;
		int l = rand() % r + 1;
		printf("%d %d\n", l, r);
	}

	for(int i = 1;i <= m; ++i){
		int x = rand() % MOD + 1;
		printf("%d\n", x);
	}

	return 0;
}
