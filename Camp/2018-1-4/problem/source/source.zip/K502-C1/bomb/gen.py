import os
import random

N = random.randint(8, 10)
M = random.randint(10, 20)

f = open("bomb.in", "w")
f.write(str(N) + ' ' + str(M) + '\n')

for i in range(M):
	u = random.randint(1, N)
	v = random.randint(1, N)
	f.write(str(u) + ' ' + str(v) + '\n')
f.close()
