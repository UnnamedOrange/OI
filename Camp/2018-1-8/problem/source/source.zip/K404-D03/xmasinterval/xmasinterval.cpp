#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=500100;

int n,m;
int L[N],R[N],X[N];

namespace violence
{
	int ans;
	bool book[N];
	
	void dfs(int step)
	{
		if(step>n)
		{
			for(int i=1;i<=m;++i)
				if(!book[i])
					return ;
			ans++;
			return ;
		}
		bool tmp[11]={};
		for(int i=1;i<=m;++i)
			if(!book[i] && X[i]>=L[step] && X[i]<=R[step])
				book[i]=1,tmp[i]=1;
		dfs(step+1);
		for(int i=1;i<=m;++i)
			if(tmp[i])
				book[i]=0,tmp[i]=0;
		dfs(step+1);
	}
		
	void Main()
	{
		dfs(1);
		cout<<ans<<endl;
	}
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	
	n=read();m=read();
	register int i;
	for(i=1;i<=n;++i) L[i]=read(),R[i]=read();
	for(i=1;i<=m;++i) X[i]=read();
	violence::Main();
	return 0;
}

