#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl
typedef long long ll;
using namespace std;
const int maxn = 1000009;

int mul[maxn],d[maxn],s[maxn],prime[maxn];
ll f[maxn],g[maxn],h[maxn],sum[maxn];
bool vis[maxn];
int n,T;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

void init(int mr)
{
	mul[1]=1;
	for(int i=2;i<=mr;i++)
	{
		if(!vis[i]) prime[++prime[0]]=i,mul[i]=-1;
		for(int j=1;j<=prime[0]&&i*prime[j]<=mr;j++)
		{
			int num=i*prime[j];
			vis[num]=1;
			if(i%prime[j]==0)
			{
				mul[num]=0;
				break;
			}
			mul[num]=-mul[i];
		} 
	}
	for(int i=1;i<=mr;i++)
		for(int j=i;j<=mr;j+=i)   
			d[j]++;
	for(int i=1;i<=mr;i++) d[i]=d[i]*d[i];
	for(int i=1;i<=mr;i++)
		for(int j=i,k=1;j<=mr;j+=i,k++)
			f[j]+=mul[i]*d[k];
	for(int i=1;i<=mr;i++) sum[i]=sum[i-1]+f[i];
}

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	init(maxn-9);
	T=read();
	while(T--)
	{
		n=read();
		printf("%d\n",sum[n]);
	}
	return 0;
}
