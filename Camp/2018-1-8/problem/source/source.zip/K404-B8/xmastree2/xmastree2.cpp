#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl
typedef long long ll;
using namespace std;
const int maxn = 30009;

int first[maxn],fa[maxn],siz[maxn],val[maxn],p[maxn],rt[maxn],du[maxn];
ll sum[maxn];
bool ok[maxn],vis[maxn];
struct edg{int next,to;}e[maxn<<1];
int n,ans,e_sum,tot;


inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void add_edg(int x,int y)
{
	e_sum++;
	e[e_sum].next=first[x];
	first[x]=e_sum;
	e[e_sum].to=y;
}

int calc()
{
	int res=0;
	for(int i=1;i<=n;i++) ok[i]=rt[i];
	for(int i=1;i<=n;i++)
	{
		if(!ok[p[i]]) return 0;
		res+=i*val[p[i]];
		for(int j=first[p[i]];j;j=e[j].next) ok[e[j].to]=1;
	}
	return res;
}
void work1()
{
	for(int i=1;i<=n;i++) p[i]=i;
	do
	{
		ans=max(ans,calc());
	}while(next_permutation(p+1,p+1+n));
	cout<<ans<<endl;
	return ;
}

int cheat1(int x)
{
	int res=0,now=tot;memset(vis,0,sizeof vis);
	priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > > heap;
	heap.push(make_pair(val[x],x));vis[x]=1;
	while(!heap.empty())
	{
		pair<int,int> x=heap.top();heap.pop();
		res+=now;now-=x.first;
		for(int i=first[x.second];i;i=e[i].next)
		{
			int w=e[i].to;
			if(!vis[w])
			{
				vis[w]=1;
				heap.push(make_pair(val[w],w));
			}
		}
	}
	return res;
}
void dfs(int x,int last)
{
	fa[x]=last;
	for(int i=first[x];i;i=e[i].next) if(e[i].to!=last) dfs(e[i].to,x),du[x]++;
}
int cheat2(int x)
{
	int res=0;
	memset(du,0,sizeof du);
	dfs(x,0);
	priority_queue<pair<int,int> > heap;
	for(int i=1;i<=n;i++) if(!du[i]) heap.push(make_pair(val[i],i));
	for(int i=n;i>=1;i--)
	{
		int x=heap.top().second;heap.pop();
		res+=val[x]*i;du[fa[x]]--;
		if(du[fa[x]]==0) heap.push(make_pair(val[fa[x]],fa[x]));
	}
	return res;
}

void work2()
{
	for(int i=1;i<=n;i++)
		if(rt[i])
		{
			ans=max(ans,cheat1(i));
			ans=max(ans,cheat2(i));
		}
	cout<<ans<<endl;
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	n=read();
	for(int i=1;i<n;i++)
	{
		int x=read(),y=read();
		add_edg(x,y);add_edg(y,x);
	}
	for(int i=1;i<=n;i++) val[i]=read(),rt[i]=read(),tot+=val[i];
	if(n<=10) work1();
	else work2();
	return 0;
}
