#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;

int n,w,p,q,x[21],y[21],z[21],a[21],b[21],c[21],d[21],e[21],f[21],xx[21],yy[21],r[21];
int t[21];


void work()
{	
	scanf("%d%d%d%d",&n,&w,&p,&q);
	for (int i=1;i<=p;i++) 
	scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
	for (int i=1;i<=q;i++) scanf("%d%d%d",&xx[i],&yy[i],&r[i]);
	
	int ans=2e9,tmp;
	for (int s=0;s<(1<<n);s++) 
	{	
		tmp=0;
		for (int i=1;i<=n;i++) {t[i]=(s&(1<<i-1)) ? 1:-1;tmp+=t[i];}
		
		bool o=true;
		for (int i=1;i<=q;i++) 
		{
			if (r[i]==0&&t[xx[i]]>t[yy[i]]) o=false;
			if (r[i]==1&&t[xx[i]]!=t[yy[i]]) o=false;
			if (r[i]==2&&(t[xx[i]]!=-1||t[yy[i]]!=1)) o=false;
		}
		if (!o) continue;
		for (int i=1;i<=p;i++) 
		{
			tmp+=a[i]*abs(t[x[i]]-t[y[i]])+b[i]*abs(t[y[i]]-t[z[i]])+c[i]*abs(t[z[i]]-t[x[i]])+
			d[i]*(t[x[i]]-t[y[i]])+e[i]*(t[y[i]]-t[z[i]])+f[i]*(t[z[i]]-t[x[i]]);
		}
		ans=min(ans,tmp);
	}
	printf("%d\n",ans*w);
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);

	int T;
	scanf("%d",&T);
	while (T--) work();
	return 0;
}

