#include <bits/stdc++.h>

typedef long long int int64;
static const int64 mod = 1000000009LL;
int n,m;
int key[500003];
int st[500003];
struct sect {
	int left,right;
	int l,r;
	int next;
} sec[500003];
int64 dp[500003],dp2[500003];
bool comp1(const sect &a,const sect &b) {
	return a.r < b.r;
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1;i <= n;++i) {
		scanf("%d%d",&sec[i].left,&sec[i].right);
	}
	for(int i = 0;i < m;++i) {
		scanf("%d",&key[i]);
	}
	std::sort(key,key+m);
	memset(st,-1,sizeof(st));
	for(int i = 1;i <= n;++i) {
		sec[i].l = std::lower_bound(key,key+m,sec[i].left) - key;
		sec[i].r = std::upper_bound(key,key+m,sec[i].right) - key - 1;
		sec[i].next = st[sec[i].r];
		st[sec[i].r] = i;
	}
	dp[0] = dp2[0] = 1;
	for(int i = 0;i < m;++i) {
		dp2[i] = (dp[i] + dp2[i-1]) % mod;
		for(int j = st[i];j != -1;j = sec[j].next) {
			dp[i] = (dp[i] + dp2[i] - dp2[sec[j].l-1]) % mod;
			dp2[i] = (dp[i] + dp2[i - 1]) % mod;
		}
	}
	if(dp[m-1] < 0) dp[m-1] += mod;
	printf("%lld\n",dp[m-1]);
}
