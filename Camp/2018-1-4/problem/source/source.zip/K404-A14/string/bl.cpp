#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int N=40;
int c[N],hsh[N],len[N],a[N];
int ans;
int n,m;
char s[N];

int check(){
	int i,ok,j;
	rep(i,1,2*m)	c[i]=c[i-1]+(a[i]<<i-1);
	rep(i,1,n){
		ok=0;
		rep(j,len[i],2*m){
			if((c[j]>>(j-len[i]))==hsh[i])	ok=1;
		}
		if(!ok)	return false;
	}
	//rep(i,1,2*m)	printf("%d",a[i]);printf("\n");
	return true;
}

int main(){
	freopen("string.in","r",stdin);
	freopen("bl.out","w",stdout);
	int i,j,opt;
	scanf("%d%d",&n,&m);
	rep(i,1,n){
		scanf("%s",s+1);len[i]=strlen(s+1);
		rep(j,1,len[i])	hsh[i]+=((s[j]-'0')<<j-1);
	}
	rep(i,0,(1<<m)-1){
		rep(j,0,m-1){
			opt=i>>j&1;
			a[j+1]=opt;a[2*m-j]=opt^1;
		}
		if(check())	ans++;
	}
	printf("%d\n",ans);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
