#include<bits/stdc++.h>
using namespace std;
#define N 500010
#define p 1000000009
#define ll long long
struct poi{int pos,num,rank;}a[N*3];
struct tre{
	int l,r,num,tag;
}t[N*3*4];
int s[N],e[N],d[N];
int re(){
	int ret=0,f=1;char ch=getchar();
	while(ch<'0'||'9'<ch){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret*f;
}
bool swp(const poi &a,const poi &b){return a.pos<b.pos;}
void build(int l,int r,int pos){
	t[pos].l=l;t[pos].r=r;
	t[pos].num=0;t[pos].tag=1;
	if(l==r)
		return;
	int mid=l+r>>1;
	build(l,mid,pos<<1);
	build(mid+1,r,pos<<1|1);
	return;
}
void pushtag(int pos){
	if(t[pos].tag!=1){
		t[pos<<1].num=t[pos<<1].num*t[pos].tag%p;
		t[pos<<1|1].num=t[pos<<1|1].num*t[pos].tag%p;
		t[pos<<1].tag=t[pos].tag;
		t[pos<<1|1].tag=t[pos].tag;
		t[pos].tag=1;
	}
	return;
}
ll ser(int enl,int pos){
	if(t[pos].r<=enl)
		return t[pos].num;
	pushtag(pos);
	int mid=t[pos].l+t[pos].r>>1;
	ll ret=ser(enl,pos<<1);
	if(mid<enl)
		ret+=ser(enl,pos<<1|1);
	return ret%p;
}
void adt(int tar,int num,int pos){
	if(t[pos].l==t[pos].r){
		t[pos].num=(t[pos].num+num)%p;
		return;
	}
	int mid=t[pos].l+t[pos].r>>1;
	pushtag(pos);
	if(tar<=mid)
		adt(tar,num,pos<<1);
	else
		adt(tar,num,pos<<1|1);
	t[pos].num=(t[pos<<1].num+t[pos<<1|1].num)%p;
	return;
}
void qua(int sta,int pos){
	if(t[pos].l>=sta){
		t[pos].tag=t[pos].tag*2%p;
		t[pos].num=t[pos].num*2%p;
		return;
	}
	pushtag(pos);
	int mid=t[pos].l+t[pos].r>>1;
	qua(sta,pos<<1|1);
	if(sta<=mid)
		qua(sta,pos<<1);
	t[pos].num=(t[pos<<1].num+t[pos<<1|1].num)%p;
	return;
}
void del(int enl,int pos){
	if(t[pos].r<=enl){
		t[pos].tag=0;
		t[pos].num=0;
		return;
	}
	pushtag(pos);
	int mid=t[pos].l+t[pos].r>>1;
	del(enl,pos<<1);
	if(mid<enl)
		del(enl,pos<<1|1);
	t[pos].num=(t[pos<<1].num+t[pos<<1|1].num)%p;
	return;
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	int n,m;
	n=re();m=re();
	int ss,ee;
	int top=0;
	for(int i=0;i<n;i++){
		ss=re();ee=re();
		a[top++]=(poi){ss,1,i};
		a[top++]=(poi){ee,2,i};
	}
	for(int i=0;i<m;i++){
		ss=re();
		a[top++]=(poi){ss,0,i};
	}
	sort(a,a+2*n+m,swp);
	int z=1;
	for(int i=0;i<2*n+m;i++){
		if(a[i].num==0){
			d[a[i].rank]=z;
		}else{
			if(a[i].num==1)
				s[a[i].rank]=z;
			else
				e[a[i].rank]=z;
		}
		if(a[i].pos!=a[i+1].pos)
			z++;
	}
	z--;
	build(0,z,1);
	adt(0,1,1);
	for(int i=0;i<2*n+m;i++){
		if(a[i].num==0)
			del(d[a[i].rank]-1,1);
		if(a[i].num==1){
			qua(e[a[i].rank],1);
			adt(e[a[i].rank],ser(e[a[i].rank]-1,1),1);
		}
	}
	cout<<ser(z,1)<<endl;
	return 0;
}
