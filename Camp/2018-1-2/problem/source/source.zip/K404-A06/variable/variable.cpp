#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <algorithm>
using namespace std;

int test, n, p, q;
int x[1010], y[1010], z[1010];
int W, a[1010], b[1010], c[1010], d[1010], e[1010], f[1010];
int u[1010], v[1010], r[1010];

int work(int s) {
	for(int i = 1; i <= q; ++i)
		if(r[i] == 0) {
			if(((s>>(u[i]-1))&1) > ((s>>(v[i]-1))&1)) return 2147483647;
		} else if(r[i] == 1) {
			if(((s>>(u[i]-1))&1) != ((s>>(v[i]-1))&1)) return 2147483647;
		} else if(r[i] == 2) {
			if(((s>>(u[i]-1))&1) >= ((s>>(v[i]-1))&1)) return 2147483647;
		}
	//printf("s = %d\n", s);
	long long res = 0;
	for(int i = 1; i <= n; ++i)
		res += ((s>>(i-1))&1) ? 1 : -1;
	for(int i = 1; i <= p; ++i) {
		long long wx = ((s>>(x[i]-1))&1), wy = ((s>>(y[i]-1))&1), wz = ((s>>(z[i]-1))&1);
		if(!wx) wx = -1; if(!wy) wy = -1; if(!wz) wz = -1;
		res += a[i]*abs(wx-wy); res += d[i]*(wx-wy);
		res += b[i]*abs(wy-wz); res += e[i]*(wy-wz);
		res += c[i]*abs(wz-wx); res += f[i]*(wz-wx);
	}
	return res;
}

int main() {
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	scanf("%d", &test);
	while(test--) {
		scanf("%d%d%d%d", &n, &W, &p, &q);
		for(int i = 1; i <= p; ++i) {
			scanf("%d%d%d", x+i, y+i, z+i);
			scanf("%d%d%d%d%d%d", a+i, b+i, c+i, d+i, e+i, f+i);
		}
		for(int i = 1; i <= q; ++i) 
			scanf("%d%d%d", u+i, v+i, r+i);
		int ans = 2147483647;
		for(int i = 0; i < (1<<n); ++i)
			ans = std::min(ans, work(i));
		printf("%d\n", ans*W);
	} 
	return 0;
}
