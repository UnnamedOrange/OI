#include <cstdio>
#include <cstring>
#include <algorithm>
#define ele int
using namespace std;
#define maxn 100010
ele n,p[maxn];
char s[maxn];
inline bool test(ele i,ele j){
	while (i<=j){
		if (s[i]!=s[j]) return false;
		++i; --j;
	}
	return true;
}
inline bool solve(){
	if (p[n]*2>n) return (n-p[n])>2;
	return (p[n]+1)*2<=n || p[n]-p[p[n]]>1;
}
int main(){
	freopen("string.in","r",stdin); freopen("string.out","w",stdout);
	ele T;
	scanf("%d",&T);
	while (T--){
		scanf("%d%s",&n,s);
		if (!test(0,n-1)) puts("1");
		else{
			p[0]=p[1]=0;
			for (int i=1; i<n; ++i){
				ele j=p[i];
				while (j && s[i]!=s[j]) j=p[j];
				if (s[i]==s[j]) ++j;
				p[i+1]=j;
			}
			if (solve()) puts("2"); else puts("-1");
		}
	}
	return 0;
}