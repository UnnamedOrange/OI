#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <bitset>
using namespace std;

const int mod = 998244353;
const int S = 1<<6;

int n, m;

struct node {
	int cnt; int id, rev;
	int next[2];
	int parent, fail;
} t[1210]; 

int root, et;

void insert(char *s, int i) {
	int u = root; t[u].cnt++;
	for(; *s; s++) {
		if(!t[u].next[*s-'0']) {
			t[u].next[*s-'0'] = ++et;
			t[t[u].next[*s-'0']].parent = u;
		}
		u = t[u].next[*s-'0'];
		t[u].cnt++;
	}
	t[u].id |= 1<<i;
}

void bfs() {
	static int q[1210]; int l = 0, r = 0;
	q[r++] = root; 
	while(l < r) {
		int u = q[l++];
		//cerr << "u : " << u << " fail : " << t[u].fail << endl;
		for(int i = 0; i < 2; ++i)
			if(t[u].next[i]) {
				int x = t[u].fail;
				while(x && !t[x].next[i])
					x = t[x].fail;
				if(t[x].next[i] != t[u].next[i]) t[t[u].next[i]].fail = t[x].next[i];
				q[r++] = t[u].next[i];
			}
	}
}

char s[6][110]; int use[6][110];

void dfs(int u, char *s, int *a, int i) {
	 if(!(*s)) return;
	 if(!t[u].next[*s-'0']) return;
	 if(*a) t[t[u].next[*s-'0']].rev |= 1<<i;
	 dfs(t[u].next[*s-'0'], s+1, a+1, i);
}

int f[1210][510][S];

//f[i][j][s] : AC�Զ����ߵ���i���ڵ㣬����Ϊj������״̬ΪS�ķ����� 

void dp1(int j) {
	static int q[1210]; int l = 0, r = 0;
	q[r++] = root;
	while(l < r) {
		int u = q[l++];
		//cerr << "u: " << u << endl;
		for(int v = 0; v < 2; ++v) {
			int x = u;
			if(t[u].next[v]) q[r++] = t[u].next[v];
			while(x && !t[x].next[v])
				x = t[x].fail;
			if(t[x].next[v]) {
				x = t[x].next[v];
				for(int s = 0; s < (1<<n); ++s) {
					//cerr << "l : " << l << " and r : " << r << endl;
					//if(s == 1) cerr << "f[" << u << "][" << j << "][" << s << "] = " << f[u][j][s] << endl,
					//cerr << "to : f[" << x << "][" << j+1 << "][" << (s|t[x].id) << "]" << endl;
					(f[x][j+1][s|t[x].id] += f[u][j][s]) %= mod;
				}
			}
		}
	}
}

int ans;

void dp2(int j) {
	static int q[1210]; int l = 0, r = 0;
	q[r++] = root;
	while(l < r) {
		int u = q[l++];
		for(int s = 0; s < (1<<n); ++s) {
			if((s|t[u].rev) == (1<<n)-1) {
				//cerr << "f[" << u << "][" << j << "][" << s << "] = " << f[u][j][s] << endl;
				(ans += f[u][j][s]) %= mod;
			}
		}
		for(int v = 0; v < 2; ++v)
			if(t[u].next[v])
				q[r++] = t[u].next[v];
	}
	
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int x = 0; x < n; ++x) {
		memset(use[x], 0, sizeof use[x]);
		scanf("%s", s[x]);
		int len = strlen(s[x]);
		for(int i = 0; i < len-1; ++i) {
			int fg = 1;
			for(int j = 0; j <= i; j++) {
				int rev = i+i-j+1;
				if(rev >= len) continue;
				//cerr << rev << " and " << j << endl;
				if(s[x][j] == s[x][rev])
					fg = 0;
			}
			if(i+1 > m || (len-1-i) > m) fg = 0;
			use[x][i] = fg;
			//cerr << i << " : " << use[x][i] << endl;
		}
		use[x][len-1] = 1;
		insert(s[x], x);
	}
	for(int j = 0; j < n; ++j)
		for(int i = 0; i <= et; ++i)
			dfs(i, s[j], use[j], j);
	for(int x = 0; x < n; ++x) {
		reverse(s[x], s[x]+strlen(s[x]));
		int len = strlen(s[x]);
		for(int i = 0; i < len; ++i) s[x][i] ^= 1;
		//puts(s[x]);
		memset(use[x], 0, sizeof use[x]);
		for(int i = 0; i < len-1; ++i) {
			int fg = 1;
			for(int j = 0; j <= i; j++) {
				int rev = i+i-j+1;
				if(rev >= len) continue;
				//cerr << rev << " and " << j << endl;
				if(s[x][j] == s[x][rev])
					fg = 0;
			}
			if(i+1 > m || (len-1-i) > m) fg = 0;
			use[x][i] = fg;
			//cerr << i << " : " << use[x][i] << endl;
		}
		use[x][len-1] = 1;
		insert(s[x], x);
	}
	for(int j = 0; j < n; ++j)
		for(int i = 0; i <= et; ++i)
			dfs(i, s[j], use[j], j);
	bfs();
	f[root][0][0] = 1;
	for(int j = 0; j < m; ++j) dp1(j);
	//for(int j = 0; j < m; ++j) dp2(j+1);
	dp2(m);
	printf("%d\n", ans);
	return 0;
}
