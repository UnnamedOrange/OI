#include <bits/stdc++.h>

int type, N;
/*
int xia[10]={2,3,5,7,11,13,17,19,23,29};
int pri[1000];
bool bib(int x){
	for(int i=0;i<10;i++)
		if(x%xia[i]==0)
			return false;
	return true;
}
bool bis(int x){
	for(int i=0;i<5;i++)
		if(x%xia[i]==0)
			return false;
	return true;
}
void init(){
	
	memset(pri,0,sizeof(pri));
	int num=1;
	for(int i=0;i<10;i++)
		pri[xia[i]]=1;
	for(int i=30;i<=920;i++){
		bool g=true;
		for(int j=2;j*j<=i;j++){
			if(i%j==0){
				g=false;
				break;
			}
		}
		if(g)
			pri[i]=num++;
		while(pri[num])
			num++;
	}
}*/

int encode(int x, int y){
	
    return x;
}

bool decode(int q, int h)
{
	/*if(bib(q)){
		if(h==0)
			return true;
		if(h==1)
			return false;
		return q%xia[h-2]==0;
	}else{
		if(h==0)
			return false;
		if(h==1)
			return true;
		if(h>=6){
			q=pri[q];
			if(bis(q)){
				if(h==6)
					return true;
				if(h==7)
					return false;
			}else{
				if(h==6)
					return false;
				if(h==7)
					return true;
			}
			return q%xia[h-8]==0;	
		}
	}*/
    return q == h;
}
int main()
{
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
    int T;
    scanf("%d%d%d", &type, &N, &T);
    //init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
