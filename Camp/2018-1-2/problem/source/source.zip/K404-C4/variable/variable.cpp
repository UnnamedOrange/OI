#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
struct node
{
	int x,y,z,a,b,c,d,e,f;
	long long h;
	void in()
	{
		scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&e,&f);
		h=0;
	}
	void work(int wx,int wy,int wz)
	{
		h=1LL*a*abs(wx-wy)+1LL*b*abs(wy-wz)+1LL*c*abs(wz-wx)+1LL*d*(wx-wy)+1LL*e*(wy-wz)+1LL*f*(wz-wx);
	}
}h[1010];
struct ask
{
	int x,y,r;
	void in()
	{
		scanf("%d%d%d",&x,&y,&r);
	}
}b[1010];
const long long inf=1e14;
int t,n,w,p,q,a[510],c[510],cnt;
vector<int> v[510];
bool used[510];
long long ans;
bool cmp(ask x,ask y)
{
	return x.r>y.r;
}
void dfs(int x)
{
	used[x]=true;
	c[x]=cnt;
	for (int i=0;i<v[x].size();i++)
	{
		int y=v[x][i];
		if (!used[y])
		{
			a[y]=a[x];
			dfs(y);
		}
	}
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		memset(a,0,sizeof(a));
		memset(used,false,sizeof(used));
		memset(c,-1,sizeof(c));
		scanf("%d%d%d%d",&n,&w,&p,&q);
		for (int i=0;i<=n;i++)
		{
			v[i].clear();
		}
		for (int i=0;i<p;i++)
		{
			h[i].in();
		}
		for (int i=0;i<q;i++)
		{
			b[i].in();
		}
		sort(b,b+q,cmp);
		int k=0;
		for (;k<q;k++)
		{
			if (b[k].r<2)
			{
				break;
			}
			a[b[k].x]=-w;
			a[b[k].y]=w;
		}
		for (;k<q;k++)
		{
			if (b[k].r<1)
			{
				break;
			}
			v[b[k].x].push_back(b[k].y);
			v[b[k].y].push_back(b[k].x);
		}
		cnt=-1;
		for (int i=1;i<=n;i++)
		{
			if (a[i]!=0 && !used[i])
			{
				dfs(i);
			}
		}
		for (int i=1;i<=n;i++)
		{
			if (!used[i])
			{
				cnt++;
				dfs(i);
			}
		}
		cnt++;
		ans=inf;
		for (int mask=0;mask<(1<<cnt);mask++)
		{
			for (int i=1;i<=n;i++)
			{
				if (c[i]==-1)
				{
					continue;
				}
				if (mask&(1<<c[i]))
				{
					a[i]=w;
				}
				else
				{
					a[i]=-w;
				}
			}
			for (int i=0;i<p;i++)
			{
				h[i].work(a[h[i].x],a[h[i].y],a[h[i].z]);
			}
			long long s=0;
			for (int i=1;i<=n;i++)
			{
				s+=a[i];
			}
			for (int i=0;i<p;i++)
			{
				s+=h[i].h;
			}
			ans=min(ans,s);
			/*
			for (int i=1;i<=n;i++)
			{
				cout<<a[i]<<" ";
			}
			cout<<endl<<s<<endl;
			*/
		}
		printf("%lld\n",ans);
	}
	return 0;
}
