#include<cstdio>
#include<iostream>
#define mod 998244353
#define Mod 998244353
using namespace std;
typedef long long LL;
LL n,k;
LL jc(LL n){
	if (n==0) return 1;
	return (LL)jc(n-1)*n%mod;
}
LL Pow(LL x,LL y){
	LL ans=1;
	while (y){
		if (y&1) (ans*=x)%=mod;
		(x*=x)%=mod;
		y>>=1;
	}
	return ans;
}
LL ny(LL x){
	return Pow(x,mod-2);
}
LL C(LL n,LL m){
	return jc(n)*ny(jc(m))*ny(jc(n-m))%mod;
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	cin>>n>>k;
	LL ans=jc(n-1)%mod;
	LL x=(LL)n*(n-1)/2-k;
	x = Pow(2,x);
	//cout<<ans<<" "<<x<<endl;
	cout<<(ans*x)%Mod<<endl;
	/*
	LL ans = jc(n);
//	for (LL i = 0; i < k; ++i)
//		ans = (ans - Pow(2,i) + Mod)% Mod;
	ans = (ans - (C(n,k)-k + Mod) % Mod + Mod) % Mod;
	ans = (ans * Pow(2,k))%Mod;
	cout<<ans<<endl;
	*/
	return 0;
}
