#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int INF = 0x3f3f3f3f;
const int p = 998244353;
const int MAXN = 100010;

inline void gmin(int &x, int y){x = x < y ? x : y;}
inline void gmax(int &x, int y){x = x > y ? x : y;}
int n;
int a[MAXN];

namespace bruteforce{
	const int SN = 11;
	int ans;
	int t[SN];
	bool used[SN], vis[SN];
	void check(){
		memset(vis, 0, sizeof(vis));
		for(int i = 1; i <= n; i++) if(!vis[i]){
			int cnt = 1; vis[i] = true;
			for(int j = t[i]; j != i; j = t[j], cnt++) vis[j] = true;
			if(cnt & 1) return;
		}
		ans++;
	}
	void dfs(int x){
		if(x > n) return check();
		if(!a[x]) for(int i = 1; i <= n; i++){
			if(!used[i]){
				used[i] = true;
				t[x] = i;
				dfs(x + 1);
				used[i] = false;
			}
		}
		else{
			t[x] = a[x];
			dfs(x + 1);
		}
	}
	void solve(){
		ans = 0;
		memset(used, 0, sizeof(used));
		for(int i = 1; i <= n; i++) used[a[i]] = true;
		dfs(1);
		cout << ans << endl;
	}
	void surprise(){
		for(n = 2; n <= 10; n += 2){
			for(int i = 0; i <= n / 2; i++){
				printf("n = %d q = %d ans = ", n, i);
				for(int j = 1; j <= i; j++) a[j] = n - j + 1;
				for(int j = i + 1; j <= n; j++) a[j] = 0;
				bruteforce::solve();
			}
		}
	}
}
namespace AC{
	bool vis[MAXN], tag[MAXN];
	int newn, k;
	LL ans;
	void solve(){
		if(n & 1) return (void)puts("0");
		newn = k = 0;
		memset(vis, 0, sizeof(vis));
		memset(tag, 0, sizeof(tag));
		for(int i = 1; i <= n; i++) tag[a[i]] = true;
		for(int i = 1; i <= n; i++){
			if(a[i] && !vis[i]){
				int j, cnt = 1;
				vis[i] = true;
				for(j = a[i]; j != i && j && !vis[j]; j = a[j]){
					vis[j] = true;
					cnt++;
				}
				if(j == i){
					if(cnt & 1) return (void)puts("0");
				}
			}
		}
		for(int i = 1; i <= n; i++){
			if(!a[i]) newn++;
			else if(!tag[i]){
				int cnt = 0;
				for(int j = i; a[j]; j = a[j]) cnt++;
				if(cnt & 1) newn++, k++;
			}
		}
		
		if(k > newn / 2 || (newn & 1)) cerr<<"!";
		ans = 1;
		int pos = 1;
		for(int i = 1; i <= newn / 2 - k; i++) ans = ans * pos % p * pos % p, pos += 2;
		for(int i = 1; i <= k; i++) ans = ans * pos % p, pos++;
		cout << ans << endl;
	}
}
int main(){
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
	//if(n <= 8) bruteforce::solve();else
	AC::solve();
	return 0;
}
