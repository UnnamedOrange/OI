#include<bits/stdc++.h>
#define ll long long
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')c=getchar(),f=-1;
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

const int N=30005;
int n,w[N],r[N],a[N],fa[N],du[N];
int tot,first[N],nxt[N<<1],to[N<<1];
ll ans;
bool vis[N];
priority_queue<pair<int,int> >q;

void add(int x,int y)
{
	nxt[++tot]=first[x],first[x]=tot,to[tot]=y;
}

void dfs(int u)
{
	for(int e=first[u];e;e=nxt[e])
	{
		int v=to[e];
		if(v==fa[u])continue;
		fa[v]=u;
		dfs(v);
	}
}

void go(int x)
{
	if(x==n+1)
	{
		ll tmp=0;
		for(int i=1;i<=n;i++)tmp+=1ll*i*w[a[i]];
		if(tmp>ans)ans=tmp;
		return;
	}
	for(int i=1;i<=n;i++)
		if(vis[fa[i]]&&!vis[i])
		{
			vis[i]=1;a[x]=i;
			go(x+1);
			vis[i]=0;a[x]=0;
		}
}

void work1()
{
	for(int i=1;i<=n;i++)
		if(r[i])
		{
			memset(fa,0,sizeof(fa));
			memset(vis,0,sizeof(vis));
			memset(a,0,sizeof(a));
			dfs(i);
			vis[i]=1;a[1]=i;
			go(2);
		}
	cout<<ans;
}

void work2()
{
	for(int i=1;i<=n;i++)
		if(r[i])
		{
			memset(fa,0,sizeof(fa));
			memset(du,0,sizeof(du));
			dfs(i);ll tmp=0;
			for(int j=1;j<=n;j++)du[fa[j]]++;
			for(int j=1;j<=n;j++)if(!du[j])q.push(make_pair(w[j],j));
			int now=n;
			while(!q.empty())
			{
				int u=q.top().second;q.pop();
				tmp+=1ll*w[u]*now;
				now--;
				if(!(--du[fa[u]]))
					q.push(make_pair(w[fa[u]],fa[u]));
			}
			ans=max(ans,tmp);
		}
	cout<<ans;
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	int x,y;
	n=getint();
	for(int i=1;i<n;i++)
	{
		x=getint(),y=getint();
		add(x,y),add(y,x);
	}
	for(int i=1;i<=n;i++)w[i]=getint(),r[i]=getint();
	if(n<=10)work1();
	else work2();
	return 0;
}
