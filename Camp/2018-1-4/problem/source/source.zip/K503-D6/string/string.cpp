#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)

using namespace std;

const int N=2000,M=510,S=65,mod=998244353;

void inc(int &x,int y)
{
    (x+=y)<mod? 0:x-=mod;
}

int n,m,s,len[6],a[6][110],b[6][110],f[M][N][S],ans;
struct node
{
    int len[2][6],fin,con;
    node *c[2],*fail;
} ac[N],*tp=ac;

void insert(int *s,int id,bool f)
{
    node *x=ac;
    rep(i,1,len[id])
    {
        if (!x->c[s[i]])
            x->c[s[i]]=++tp,tp->fail=ac;
        x=x->c[s[i]];
        x->len[f][id]=i;
    }
    x->fin|=1<<id;
}

void bfs()
{
    static node *q[N];
    int h,t;
    q[h=t=0]=ac;
    for (node *x; h<=t; )
    {
        x=q[h++];
        if (x>ac)
        {
            rep(k,0,1)
                rep(i,0,n-1)
                    x->len[k][i]=max(x->len[k][i],x->fail->len[k][i]);
            x->con=x->fail->con,x->fin|=x->fail->fin;
            rep(i,0,n-1)
                x->con|=(x->len[0][i]+x->len[1][i]==len[i])<<i;
        }
        rep(c,0,1)
        {
            node *f=x->fail;
            for (; f && !f->c[c]; f=f->fail);
            if (x->c[c])
                q[++t]=x->c[c];
            (x->c[c]? x->c[c]->fail:x->c[c])=(f && f->c[c]? f->c[c]:ac);
        }
    }
}

int main()
{
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    scanf("%d%d",&n,&m),s=(1<<n)-1;
    rep(i,0,n-1)
    {
        static char s[110];
        scanf("%s",s+1),len[i]=strlen(s+1);
        rep(j,1,len[i])
            a[i][j]=s[j]-'0',b[i][len[i]-j+1]=!a[i][j];
        insert(a[i],i,0),insert(b[i],i,1);
    }
    bfs();
    f[0][0][0]=1;
    rep(i,0,m-1)
        for (node *j=ac; j<=tp; ++j)
            rep(k,0,s)
                rep(c,0,1)
                {
                    node *v=j->c[c];
                    inc(f[i+1][v-ac][k|v->fin],f[i][j-ac][k]);
                }
    for (node *i=ac; i<=tp; ++i)
        rep(j,0,s)
            if ((i->con|j)==s)
                inc(ans,f[m][i-ac][j]);
    printf("%d",ans);
    return 0;
}
