#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <deque>
#include <map>
#include <set>
#include <bitset>
#include <list>
typedef long long INT;
using std::cin;
using std::cout;
using std::endl;
INT readIn()
{
	INT a = 0;
	bool minus = false;
	char ch = getchar();
	while (!(ch == '-' || (ch >= '0' && ch <= '9'))) ch = getchar();
	if (ch == '-')
	{
		minus = true;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9')
	{
		a = a * 10 + (ch - '0');
		ch = getchar();
	}
	if (minus) a = -a;
	return a;
}
void printOut(INT x)
{
	char buffer[20];
	INT length = 0;
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	do
	{
		buffer[length++] = x % 10 + '0';
		x /= 10;
	}
	while (x);
	do
	{
		putchar(buffer[--length]);
	}
	while (length);
	putchar('\n');
}

const INT mod = 1000000009;
const INT maxn = 500005;
INT n, m;
struct Area
{
	INT l;
	INT r;
	void read()
	{
		l = readIn();
		r = readIn();
	}
} areas[maxn];
INT points[maxn];
INT V;
INT disc[maxn * 3];

#define RunInstance(x) delete new x
struct brute
{
	INT events[3][65];

	brute() : events()
	{
		INT ans = 0;
		INT U = 1 << n;
		for(int i = 1; i <= m; i++)
			events[1][points[i]]++;

		for(int S = 0; S < U; S++)
		{
			for(int i = 0; i < n; i++)
				if(S & (1 << i))
				{
					events[0][areas[i + 1].l]++;
					events[2][areas[i + 1].r]++;
				}

			INT cnt = 0;
			INT covered = 0;
			for(int i = 1; i <= V; i++)
			{
				cnt += events[0][i];
				if(cnt) covered += events[1][i];
				cnt -= events[2][i];
			}
			if(covered == m) ans++;

			for(int i = 0; i < n; i++)
				if(S & (1 << i))
				{
					events[0][areas[i + 1].l]--;
					events[2][areas[i + 1].r]--;
				}
		}
		printOut(ans);
	}
};
struct work
{
	work()
	{
		
	}
};

void discretize()
{
	for(int i = 1; i <= m; i++)
		disc[++disc[0]] = points[i];
	for(int i = 1; i <= n; i++)
	{
		disc[++disc[0]] = areas[i].l;
		disc[++disc[0]] = areas[i].r;
	}
	std::sort(disc + 1, disc + 1 + disc[0]);
	V = std::unique(disc + 1, disc + 1 + disc[0]) - (disc + 1);
	for(int i = 1; i <= m; i++)
		points[i] = std::lower_bound(disc + 1, disc + 1 + V, points[i]) - disc;
	for(int i = 1; i <= n; i++)
	{
		areas[i].l = std::lower_bound(disc + 1, disc + 1 + V, areas[i].l) - disc;
		areas[i].r = std::lower_bound(disc + 1, disc + 1 + V, areas[i].r) - disc;
	}
}
void run()
{
	n = readIn();
	m = readIn();
	for(int i = 1; i <= n; i++)
		areas[i].read();
	for(int i = 1; i <= m; i++)
		points[i] = readIn();
	std::sort(points + 1, points + 1 + m);
	discretize();

	if(n <= 20 && m <= 20)
		RunInstance(brute);
	else
		RunInstance(work);
}

int main()
{
#ifndef LOCAL
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
#endif
	run();
	return 0;
}
