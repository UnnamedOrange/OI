#include<cstdio>
using namespace std;
#define N 2005
#define M 5005
#define LL long long
#define mod 998244353
#define rep(i,j,k) for(i=j;i<=k;++i)
struct E{
	int to,nxt;
}ed[M];
int i,j,k,n,m,L,R,u,v,top;
int dp[N][N],q[N],du[N],head[N];
LL ans[N];
void read(int &p){
	p=0; char x=getchar(); 
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar(); }
}
void add(int u,int v){
	top++; ed[top].to=v; ed[top].nxt=head[u]; head[u]=top; du[v]++;
}
LL quick_mi(LL a,int b){
	LL sum=1;
	for(;b;b>>=1){
		if(b&1) sum=(sum*a)%mod;
		a=(a*a)%mod;
	}
	return sum;
}
void init(){
	read(n); read(m); read(k);
	rep(i,1,m){
		read(u); read(v);
		add(u,v);
	}
	dp[1][0]=1;
	L=1; R=1; q[1]=1;
	while(L<=R){
		int x=q[L]; L++;
		rep(j,0,n)
		if(dp[x][j]){
			for(i=head[x];i;i=ed[i].nxt) 
			dp[ed[i].to][j+1]+=dp[x][j];
		} 
		for(i=head[x];i;i=ed[i].nxt){
			du[ed[i].to]--;
			if(!du[ed[i].to]) R++,q[R]=ed[i].to;
		}
	}
	rep(i,1,n){
		ans[i]=0;
		rep(j,0,n)
		if(dp[i][j]){
			ans[i]+=(dp[i][j]*1ll*quick_mi(j,k))%mod;
			ans[i]%=mod;
		}
		printf("%lld\n",ans[i]);
	}
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	init();
	return 0;
} 
