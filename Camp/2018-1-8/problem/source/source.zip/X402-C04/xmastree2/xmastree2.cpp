#include<iostream>
#include<vector>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef vector<int>::iterator it;
typedef long long ll;
const int N=30009;

int n,to[N<<1],nxt[N<<1],beg[N],tot;
int fa[N],vis[N],w[N],r[N];
ll ans;

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void dfs(int u)
{
	for(int i=beg[u];i;i=nxt[i])
		if(to[i]!=fa[u])
		{
			fa[to[i]]=u;
			dfs(to[i]);
		}
}

inline void dfs2(int id,ll sum)
{
	if(id>n)
	{
		ans=max(ans,sum);
		return;
	}
	for(int i=1;i<=n;i++)
	{
		if(vis[i])continue;
		else if(!fa[i] || vis[fa[i]])
		{
			vis[i]=1;
			dfs2(id+1,sum+(ll)w[i]*id);
			vis[i]=0;
		}
	}
}

namespace greedy
{
	int cnt;
	vector<int> stk; 
	ll cans;

	int main()
	{
		for(int o=1;o<=n;o++)
			if(r[o])
			{

				int u=o;
				stk.push_back(u);

				cans=0;
				for(int i=1;i<=n;i++)
				{
					it mv=stk.begin();
					for(it j=stk.begin();j!=stk.end();j++)
						if(w[*j]<w[*mv])
							mv=j;

					u=(*mv);
					cans+=i*w[u];
					stk.erase(mv);

					for(int j=beg[u];j;j=nxt[j])
						if(to[j]!=fa[u])
						{
							fa[to[j]]=u;
							stk.push_back(to[j]);
						}

				}
				ans=max(ans,cans);
			}
		printf("%lld\n",ans);
		return 0;
	}
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);

	n=read();
	for(int i=1,u,v;i<n;i++)
	{
		u=read(),v=read();
		add(u,v);add(v,u);
	}
	for(int i=1;i<=n;i++)
		w[i]=read(),r[i]=read();
	if(n>=1)
		return greedy::main();
	for(int i=1;i<=n;i++)
		if(r[i])
		{
			memset(fa,0,sizeof(fa));
			dfs(i);
			dfs2(1,0);
		}

	printf("%lld\n",ans);
	return 0;
}
