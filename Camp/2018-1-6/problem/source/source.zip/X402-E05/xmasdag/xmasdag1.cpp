#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=4010;
const int M=200010;
const int inf=0x3f3f3f3f;
const LL mod=998244353;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag1.out","w",stdout);
}
int n,m,K,ans[N];
int dp[N][N],deg[N],vis[N];
int bgn[N],nxt[M],to[M],E;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void Add(int &x,int y){x=x+y<mod?x+y:x+y-mod;}
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void bfs(int x)
{
	queue<int>q;
	q.push(x);
	while(!q.empty())
	{
		int u=q.front();q.pop();
		for(int v,i=bgn[u];i;i=nxt[i])
		{
			deg[v=to[i]]++;
			if(!vis[v])vis[v]=1,q.push(v);
		}
	}
}
int main()
{
	int x,y;
	file();
	read(n),read(m),read(K);
	For(i,1,m)read(x),read(y),add_edge(x,y);
	bfs(1);
	queue<int>q;
	dp[1][0]=1;
	q.push(1);
	while(!q.empty())
	{
		int u=q.front();q.pop();
		For(i,1,n)Add(ans[u],1ll*dp[u][i]*qpow(i,K)%mod);
		for(int v,i=bgn[u];i;i=nxt[i])
		{
			if(!--deg[v=to[i]])q.push(v);
			For(j,1,n)Add(dp[v][j],dp[u][j-1]);
		}
	}
	For(i,1,n)printf("%d\n",ans[i]);
	return 0;
}
