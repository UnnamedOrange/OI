#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define ll long long
#define db double
#define N 1000010
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int n,w[N];
db ans;
namespace sub1
{
	#define M 1510
	int q[M],tot;
	void Main()
	{
		register int i,j,k;
		for(i=1;i<=n;i++)
		{
			tot=0;db ta;
			for(j=i;j<=n;j++)
			{
				q[++tot]=w[j];
				sort(q+1,q+tot+1);ta=0;
				for(k=1;k<=tot;k++) ta=(ta+q[k])*1.0/2;
				ans+=ta/n/n;
			}
		}
		printf("%.5lf\n",ans);
	}
};
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=rd();
	for(int i=1;i<=n;i++) w[i]=rd();
	if(n<=1500) sub1::Main();
	return 0;
}