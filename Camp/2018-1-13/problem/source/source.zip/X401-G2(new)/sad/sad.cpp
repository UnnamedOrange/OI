#include<bits/stdc++.h>
#define MO 998244353
#define N 100050
using namespace std;
inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}

int u,v,tot,d[N],a[N],c[N*2][2],du[N],v_[56],n,f_[N],s_[N],f[N],sh[N],er;
inline int ksm(int p, int k)
{
	v_[0]=p; 
	for(int i=1; i<=29; ++i)v_[i]=(long long )v_[i-1]*v_[i-1]%MO;
	int ss=1;
	for(int i=29; i>=0; --i)if(1<<i<=k)
	{
		ss=(long long)ss*v_[i]%MO;
		k-=1<<i;
	}
	return ss;
}

inline int ni(int p)
{
	if(p<0)p=p%MO+MO;  
	return ksm(p,MO-2);
}

void dfs(int p, int faa)
{
	if(du[p]==1)
	{
		sh[p]=0;
	    f[p]=1;
	    return;
	}
	int uu=ni(du[p]); 
	if(p==1)
	{
		int tt=0;
		for(int o=a[p]; o; o=c[o][1])
		{
		    dfs(c[o][0],p);
		    f_[++tt]=f[c[o][0]];
		    s_[tt]=sh[c[o][0]];
	    }
	    int ff=0,ss=0,gg; 
	    for(int i=1; i<=tt; ++i)ff=(ff+f_[i])%MO;
	    for(int i=1; i<=tt; ++i)ss=(ss+s_[i])%MO;
	    gg=1-(long long)uu*ss%MO;
	    if(d[p])f[p]=((long long)uu*(ss+ff)%MO*ni(gg)%MO+1)%MO;
	    else f[p]=((long long)uu*ff%MO*ni(gg)%MO+1)%MO;
	    return;
    }
	for(int o=a[p]; o; o=c[o][1])
	{
		if(c[o][0]==faa)continue;
		dfs(c[o][0],p);
	}
	int ss=0,ff=0,gg;
	for(int o=a[p]; o; o=c[o][1])
	{
		if(c[o][0]==faa)continue;
		ff=(ff+f[c[o][0]])%MO;
		ss=(ss+sh[c[o][0]])%MO;
	}
	gg=1-(long long)uu*ss%MO; //ni*ss
	if(d[p])f[p]=(long long)uu*(ff+ss)%MO*ni(gg)%MO+1;
	else f[p]=(long long)uu*(ff)%MO*ni(gg)%MO+1;
	sh[p]=(long long)uu*ni(gg)%MO;
//		sh[p]=er+er*(sh[c[o][0]]*sh[p])
//		f[p]=er*(f[c[o][0]]+sh[c[o][0]]*(f[p]+1))              //+1;
//	}
}

int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	n=read(); 
	for(int i=1; i<=n; ++i)
	{
		d[i]=getchar();
		while(d[i]>49 || d[i]<48)d[i]=getchar();
	}
	for(int i=1; i<=n; ++i)d[i]-=48;
	for(int i=1; i<n; ++i)
	{
		u=read(); v=read();
		c[++tot][0]=v; c[tot][1]=a[u]; a[u]=tot;
		c[++tot][0]=u; c[tot][1]=a[v]; a[v]=tot;
		++du[u]; ++du[v];
	}
	dfs(1,0);
	printf("%d\n",f[1]);
}
