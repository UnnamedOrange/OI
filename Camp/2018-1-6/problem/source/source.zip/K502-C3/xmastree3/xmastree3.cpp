#include<cstdio>
#include<iostream>
#include<vector>
#include<cstring>
#define NN 50+5
#define KK 15+5
#define mod 998244353
using namespace std;
long long dp[NN][KK]={0};
int n,k;
int fa[NN]={0};
int p[NN];
struct node{
	int xt;
	int to;
}e[2*NN];
bool fal[20]={0};
long long get_permut(int step,int lim,int pos,long long num,int fa){
	if(step==0){
		return num;
	}
	if(e[pos].to==fa)return get_permut(step,lim,e[pos].xt,num,fa);
	long long ans=0;
	for(int i=lim+1;i<=k;++i){
		if(!fal[i]){
			fal[i]=1;
			ans+=get_permut(step-1,lim,e[pos].xt,(num*dp[e[pos].to][i])%mod,fa);
			ans%=mod;
			fal[i]=0;
		}
	}
	return ans;
}
			
		
//niconiconi!!
void dfs(int x,bool fl){
	int cnt=0;
	for(int i=p[x];i;i=e[i].xt){
		if(e[i].to==fa[x])continue;
		int now=e[i].to;
		fa[now]=x;
		dfs(e[i].to,!fl);
		++cnt;
	}
	if(fl){
		for(int i=0;i<=k;++i){
			dp[x][i]=1;
		}
		for(int j=p[x];j;j=e[j].xt){
			long long sum=0;
			for(int i=k;i>=0;--i){
				if(e[j].to!=fa[x]){
					(dp[x][i]*=dp[e[j].to][i])%=mod;
				}
			}
		}
	}
	else{
		memset(fal,0,sizeof fal);
		for(int i=0;i<=n;++i){
			dp[x][i]=get_permut(cnt,i,p[x],1,fa[x]);
		}
	}
}
long long tree_dp(int x){
	memset(dp,0,sizeof dp);
	memset(fa,0,sizeof fa);
	dfs(x,1);
	long long ans=0;
	for(int i=1;i<=k;++i){
		(ans+=dp[x][i])%=mod;
	}
	return ans;
}
int cnt=1;
void add_edge(int a,int b){
	e[cnt].to=b;
	e[cnt].xt=p[a];
	p[a]=cnt++;
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	int tp,tp1;
	for(int i=1;i<n;++i){
		scanf("%d%d",&tp,&tp1);
		add_edge(tp,tp1);
		add_edge(tp1,tp);
		
	}
	long long ans=0;
	for(int i=1;i<=n;++i){
		(ans+=tree_dp(i))%=mod;
	}
	printf("%d",ans);
}
