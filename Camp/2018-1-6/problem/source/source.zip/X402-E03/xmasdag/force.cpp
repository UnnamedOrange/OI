#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( LL &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const LL maxn = 1e5+5, maxm = 2e5+5 ;
LL n, m, Begin[maxn], e, Next[maxm], k, To[maxm] ;
LL f[2005][5005], modd = 998244353 ;
void add ( LL x, LL y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
LL deg[maxn] ;
bool vis[maxn] ;
void dfs ( LL x ) {
	if (vis[x]) return ;
	vis[x] = 1 ;
	LL i, j, u ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		dfs(u) ;
		for ( j = 1 ; j <= m ; j ++ )
			(f[x][j] += f[u][j - 1]) %= modd ;
	}
}
LL Qpow ( LL a, LL b ) {
	LL rec = 1 ;
	for ( ; b ; b >>= 1, (a *= a) %= modd )
		if (b&1) (rec *= a) %= modd ;
	return rec ;
}
int main() {
	freopen ( "xmasdag.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;
	//freopen ( "xmasdag.out", "w", stdout ) ;
	
	LL i, j, u, x ;
	Read(n) ; Read(m) ; Read(k) ;
	for ( i = 1 ; i <= m ; i ++ ) {
		Read(u) ; Read(x) ;
		add(x, u) ;
		++ deg[u] ;
	}
	vis[1] = 1 ;
	f[1][0] = 1 ;
	for ( i = 2 ; i <= n ; i ++ )
		if (!deg[i]) dfs(i) ;
	++ m ;
	LL rec ;
	for ( j = 0 ; j < m ; j ++ ) {
		rec = Qpow(j, k) ;
		for ( i = 1 ; i <= n ; i ++ )
			(f[i][m] += rec*f[i][j]%modd) %= modd ;
	}
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%lld\n", f[i][m] ) ;
	return 0 ;
}
