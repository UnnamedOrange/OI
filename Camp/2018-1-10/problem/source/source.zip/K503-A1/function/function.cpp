#include<bits/stdc++.h>
using namespace std;
const int m=5000000;
int T,n,p[5000000],a[m+5],r[m+5],cnt[m+5],fai[m+5];
long long f[m+5],ans[m+5];
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	r[1]=1;cnt[1]=0;f[1]=1;fai[1]=1;ans[1]=1;
	for (int i=2;i<=m;i++){
		if (!a[i]){p[++p[0]]=i;a[i]=i;}
		for (int j=1;(p[j]*i<=m)&&(p[j]<=a[i])&&(j<=p[0]);j++)
		a[p[j]*i]=p[j];
		if (i/a[i]%a[i]) {r[i]=i/a[i];cnt[i]=1;fai[i]=-fai[i/a[i]];}
		else {r[i]=r[i/a[i]];cnt[i]=cnt[i/a[i]]+1;fai[i]=0;}
		f[i]=(f[r[i]]*(cnt[i]+1)*(cnt[i]+1));
		ans[i]=ans[r[i]]*(f[i/r[i]]-f[i/r[i]/a[i]]);
	}
	for (int i=2;i<=m;i++) ans[i]+=ans[i-1];
	scanf("%d",&T);
	for (int i=1;i<=T;i++){
		scanf("%d",&n);
		printf("%lld\n",ans[n]);
	}
	return 0;
}
