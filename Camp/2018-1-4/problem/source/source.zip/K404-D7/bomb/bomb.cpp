#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-')p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v=-v;
}
vector<int>q[1000005], nq[1000005], fa[1000005];
int n, m;
int dfn[1000005], low[1000005], indx, st[1000005], bl[1000005], siz[1000005], chu[1000005], f[1000005];
int cnt, top;
bool inst[1000005];
inline void tarjan(int x) {
	dfn[x] = low[x] = ++indx;
	st[++top] = x;
	inst[x] = 1;
	int v;
	for(int i = 0; i < q[x].size(); ++i) {
		v = q[x][i];
		if(!dfn[v]) {
			tarjan(v);
			low[x] = min(low[x], low[v]);
		} else if(inst[v]) {
			low[x] = min(low[x], dfn[v]);
		}
	}
	if(low[x] == dfn[x]) {
		++cnt;
		while(st[top] != x) {
			inst[st[top]] = 0;
			bl[st[top]] = cnt;
			++siz[cnt];
			--top;
		}
		inst[st[top]] = 0;
		bl[st[top]] = cnt;
		++siz[cnt];
		--top;
	}
}
int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	R(n), R(m);
	int x, y;
	for(int i = 1; i <= m; ++i) {
		R(x), R(y);
		q[x].push_back(y);
	}
	for(int i = 1 ; i <= n; ++i) {
		if(!dfn[i]) {
			tarjan(i);
		}
	}
	int v;
	for(int i = 1; i <= n; ++i) {
//		printf("bl[%d] = %d\n", i, bl[i]);
		for(int j = 0; j < q[i].size(); ++j) {
			v = q[i][j];
			if(bl[i] != bl[v]) {
				nq[bl[i]].push_back(bl[v]);
				fa[bl[v]].push_back(bl[i]);
				++chu[bl[i]];
			}	
		}
	}
	static queue<int> que;
	for(int i = 1; i <= cnt; ++i) {
//		printf("siz[%d] = %d\n", i, siz[i]);
		if(!chu[i]) {
			f[i] = siz[i];
			que.push(i);
		}
	}
	int ans = 0;
	while(!que.empty()) {
		x = que.front();
		que.pop();
		for(int i = 0 ; i < nq[x].size(); ++i) {
			v = nq[x][i];
			f[x] = max(f[x], f[v] + siz[x]);
		}
		ans = max(ans, f[x]);
		for(int i = 0 ; i < fa[x].size(); ++i) {
			v = fa[x][i];
			chu[v]--;
			if(!chu[v]) que.push(v);
		}	
	}
	cout<<ans<<'\n';
	return 0;
}
