#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
typedef long long ll;
using namespace std;
const int maxn = 500009;
const int mod = 1e9+9;

struct sg_tree{int sum,mul;}node[maxn<<2];
struct line{int l,r;}b[maxn];
int a[maxn];
int n,m;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
inline int MOD(int x)
{
	if(x>=mod) x-=mod;
	return x;
}
bool cmp(const line &x,const line &y){return x.l<y.l;}

void update(int rt){node[rt].sum=MOD(node[rt<<1].sum+node[rt<<1|1].sum);}
void make_plus(int rt,int delta)
{
	node[rt].sum=1ll*node[rt].sum*delta%mod;
	node[rt].mul=1ll*node[rt].mul*delta%mod;
}
void down(int rt)
{
	if(node[rt].mul!=1)
	{
		make_plus(rt<<1,node[rt].mul);
		make_plus(rt<<1|1,node[rt].mul);
		node[rt].mul=1;
	}
}
void build(int l,int r,int rt)
{
	node[rt].mul=1;
	if(l==r) return ;
	int mid=(l+r)>>1;
	build(lson);build(rson);
}
inline void insert(int l,int r,int rt,int pos,int delta)
{
	if(l==r)
	{
		node[rt].sum=MOD(node[rt].sum+delta);
		return ;
	}down(rt);
	int mid=(l+r)>>1;
	if(pos<=mid) insert(lson,pos,delta);
	else insert(rson,pos,delta);
	update(rt);
}
inline void modify(int l,int r,int rt,int left,int right)
{
	if(l==left&&right==r)
	{
	//	make_plus(rt,2);
		node[rt].sum=MOD(node[rt].sum<<1);
		node[rt].mul=MOD(node[rt].mul<<1);
		return ;
	}down(rt);
	int mid=(l+r)>>1;
	if(right<=mid) modify(lson,left,right);
	else if(left>mid) modify(rson,left,right);
	else modify(lson,left,mid),modify(rson,mid+1,right);
	update(rt);
}
inline int query(int l,int r,int rt,int left,int right)
{
	if(l==left&&right==r) return node[rt].sum;
	down(rt);int mid=(l+r)>>1;
	if(right<=mid) return query(lson,left,right);
	else if(left>mid) return query(rson,left,right);
	else return MOD(query(lson,left,mid)+query(rson,mid+1,right));
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++) b[i]=(line){read(),read()};
	for(int i=1;i<=m;i++) a[i]=read();
	sort(a+1,a+1+m);
	for(int i=1;i<=n;i++)
	{
		b[i].l=lower_bound(a+1,a+1+m,b[i].l)-a;
		b[i].r=upper_bound(a+1,a+1+m,b[i].r)-a-1;
	}
	sort(b+1,b+1+n,cmp);
	build(0,m,1);
	insert(0,m,1,0,1);
	for(int i=1;i<=n;i++)
	{
		int x=query(0,m,1,max(0,b[i].l-1),b[i].r);
		insert(0,m,1,b[i].r,x);
		if(b[i].r+1<=m) modify(0,m,1,b[i].r+1,m);
	}
	printf("%d\n",query(0,m,1,m,m));
	return 0;
}
