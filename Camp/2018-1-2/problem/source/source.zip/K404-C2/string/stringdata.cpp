#include<algorithm>
#include<unistd.h>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<ctime>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
int c[100005];

int main()
{
	freopen("string.in","w",stdout);
	srand(time(0)+getpid());
	int T=20;
	printf("%d\n",T);
	while(T--)
	{
		int n=10-rand()%10;
		printf("%d\n",n);
		rep(i,1,n/2) c[i]=c[n-i+1]=rand()%3;
		rep(i,1,n) printf("%c",'a'+c[i]);
		puts("");
	}
}
