#include<bits/stdc++.h>
using namespace std;
struct lt { 
	int size;
	vector<int>po;
};
lt point[12300];
vector<int>ed[12300];
vector<int>edp[12300];
int n,m;
int nw;
bool wing;
int mad,ma;
int dist[12300];
int t_cnt=1;
int lt_cnt=1;
int lt_num[12300];
int mint[12300];
int t[12300];
stack<int>sth;
void tarjan(int nw) {
	sth.push(nw); 
	mint[nw]=t[nw]=t_cnt,t_cnt++;
	for(int i=0;i<ed[nw].size();++i) { 
		int tar=ed[nw][i];
		if(lt_num[tar]==0) { 
			if(mint[tar]!=0)
				mint[nw]=min(mint[tar],mint[nw]);
			else tarjan(tar),mint[nw]=min(mint[tar],mint[nw]);
		} 
	} 
	if(mint[nw]==t[nw]) { 
		lt jcq;
		jcq.size=0;
		jcq.po.clear();
		int p=0;
		do { 
			p=sth.top();
			sth.pop();
			jcq.po.push_back(p);
			lt_num[p]=lt_cnt;
			jcq.size++;
		} while(p!=nw);
		point[lt_cnt]=jcq;
		lt_cnt++;
	} 
} 

void gt() { 
	for(int i=1;i<=lt_cnt;++i) { 
		for(int j=0;j<point[i].size;++j) { 
			int nw=point[i].po[j];
			for(int k=0;k<ed[nw].size();++k) { 
				int tar=ed[nw][k];
				if(lt_num[tar]!=lt_num[nw]) 
					edp[lt_num[nw]].push_back(lt_num[tar]);
			} 
		} 
	} 
} 

void lp(int k) { 
	for(int i=0;i<edp[k].size();++i) { 
		int tar=edp[k][i];
		if(dist[tar]==0) lp(tar);
		dist[k]=max(dist[k],point[k].size+dist[tar]);
	} 
	if(dist[k]==0) dist[k]=point[k].size;
	return;
} 

int main() { 
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d %d",&n,&m);
	int p1,p2;
	for(int i=0;i<m;++i) { 
		scanf("%d%d",&p1,&p2);
		ed[p1].push_back(p2);
	} 
	for(int i=1;i<=n;++i) { 
		if(lt_num[i]==0) { 
			tarjan(i);
		} 
	} 
	lt_cnt--;
	/*
	for(int i=1;i<=lt_cnt;++i) {
		printf("%d :   size = %d \n",i,point[i].size);
		for(int j=0;j<point[i].size;++j) {
			printf("%d ",point[i].po[j]);
		}
		printf("\n");
	}
	printf("\n \n");
	*/
	gt();
	/*
	for(int i=1;i<=lt_cnt;++i) { 
		printf("%d : ",i);
		for(int j=0;j<edp[i].size();++j) 
			printf("%d ",edp[i][j]);
		printf("\n");
	} 
	*/
	int ma=-123;
	for(int i=1;i<=lt_cnt;++i) {
		if(dist[i]==0) {
			lp(i);
			ma=max(ma,dist[i]);
		}
	}
	printf("%d",ma);
	return 0;
} 
