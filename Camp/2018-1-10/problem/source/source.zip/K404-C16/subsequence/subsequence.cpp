#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0;char ch=getchar();
	while(ch<'0'||'9'<ch)ch=getchar();
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret;
}
#define N 4010
int a[N],b[N],n,m,k;
int nea[N][N],neb[N][N];
int g[N][N];
int r(int ap,int bp){
	if(g[ap][bp])
		return g[ap][bp];
	g[ap][bp]=N*5;
	for(int i=1;i<=k;i++)
		g[ap][bp]=min(r(min(nea[ap][i]+1,n+1),min(neb[bp][i]+1,m+1))+1,g[ap][bp]);
	return g[ap][bp];
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	n=re(),m=re(),k=re();
	for(int i=0;i<n;i++)
		a[i]=re();
	for(int i=0;i<m;i++)
		b[i]=re();
	for(int i=1;i<=k;i++)
		nea[n][i]=n;
	for(int i=n-1;i>=0;i--){
		for(int j=1;j<=k;j++)
			nea[i][j]=nea[i+1][j];
		nea[i][a[i]]=i;
	}
	for(int i=1;i<=k;i++)
		neb[m][i]=m;
	for(int i=m-1;i>=0;i--){
		for(int j=1;j<=k;j++)
			neb[i][j]=neb[i+1][j];
		neb[i][b[i]]=i;
	}
	memset(g,0,sizeof(g));
	g[n+1][m+1]=1;
	cout<<r(0,0)-1<<endl;
	return 0;
}
