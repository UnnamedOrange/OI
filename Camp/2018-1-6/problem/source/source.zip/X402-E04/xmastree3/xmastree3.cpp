#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=8,INF=0x3f3f3f3f,Mod=998244353;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
}
int n,k,Begin[N],Next[N<<1],to[N<<1],e=1,dp[N][N],fa[N],Ban[N<<1];
inline void add(int x,int y){
	to[++e]=y,Next[e]=Begin[x],Begin[x]=e;
}
void init(){
	read(n),read(k);
	For(i,1,n-1){
		int x,y;
		read(x),read(y);
		add(x,y),add(y,x);
	}
}
vector<int>G[N];
int ans=0;/*
void dp(int u){
	int ok=1,S=G[u].size();
	For(j,1,k)dp[u][j]=1;
	For(i,0,S-1){
		int v=G[u][i];dp(v);
		For(j,1,k)
			dp[u][j]=1ll*dp[u][j]*dp[v][j+1]%Mod;
	}
	Forr(j,k-1,1)dp[u][j]=(dp[u][j]+dp[u][j+1])%Mod;
}
bool check(){
	For(i,1,n)if(fa[i]==-1)return 0;
	return 1;
}
void dfs(int s,int f){
	int st[N],vis[N]={0},h=0,t=0;
	vis[s]=1;st[++t]=s;
	
	while(h<t){
		int r=st[++h];
		Rep(i,r)if(!vis[v]&&!Ban[i])st[++t]=v,vis[v]=1;
	}
	if(check()){
		int rt;
		For(i,1,n)if(fa[i]==0){dp(rt=i);break;}
		For(i,1,k)ans=(ans+dp[rt][i])%Mod;
		return ;
	}
	For(j,1,t){
		int u=st[j];
		fa[u]=f;
		Rep(i,u)if(!Ban[i]){
			Ban[i]=Ban[i^1]=1;
			dfs(v,u);
		}
		fa[u]=-1;
	}
}*/
void solve(){
	For(i,1,n)fa[i]=-1;
	//dfs(1,0);
	printf("%d\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
