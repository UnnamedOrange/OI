#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<set>
using namespace std;
set<int> s[100005];
set<int> :: iterator it;
int read()
{
	char ch=getchar();int x=0,f=1;
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int root[500005],n,pos[100005],npos[100005],q,type,b[100005];
int a[100005],tot,head[100005],tim,fa[100005],pr[100005];
int ch[20000005][2],w[20000005],sz;
struct node
{
	int from;
	int to;
	int next;
}edge[200005];
void add(int u,int v)
{
	edge[tot].from=u;
	edge[tot].to=v;
	edge[tot].next=head[u];
	head[u]=tot++;
}
void dfs(int x)
{
	pos[x]=++tim;
	npos[tim]=x;
	for(int i=head[x];i!=-1;i=edge[i].next)
	{
		if(edge[i].to!=fa[x])
		{
			fa[edge[i].to]=x;
			dfs(edge[i].to);
		}
	}
}
int lowbit(int x)
{
	return x&-x;
}
void ins(int x,int y)
{
	for(int i=x;i<=n;i+=lowbit(i))
	{
		b[i]+=y;
	}
}
int ask(int x)
{
	int ret=0;
	for(int i=x;i;i-=lowbit(i))
	{
		ret+=b[i];
	}
	return ret;
}
int pre(int x)
{
	it=s[a[npos[x]]].find(x);
	return it==s[a[npos[x]]].begin()?0:*--it;
}
void modify(int &p,int l,int r,int x,int y)
{
	if(!p) p=++sz;
	int mid=l+r>>1;
	w[p]++;
	if(x<=mid) modify(ch[p][0],l,mid,x,y);
	else modify(ch[p][1],mid+1,r,x,y);
}
void modify(int p,int l,int r,int x,int y,int z)
{
	int mid=l+r>>1;
	modify(root[p],1,n,y,z);
	if(l==r) return;
	if(x<=mid) modify(p<<1,l,mid,x,y,z);
	else modify(p<<1|1,mid+1,r,x,y,z);
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout); 
	memset(head,-1,sizeof(head));
	n=read();q=read();type=read();
	puts("������ά����n^5/3����nlog^3n"); 
	puts("���б�ĸ��ӶȵĻ�orzzzzz");
	return 0;
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	for(int i=1;i<n;i++)
	{
		int u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	dfs(1);
	for(int i=1;i<=n;i++)
	{
		s[a[npos[i]]].insert(i);
		int p=pre(i);
		pr[i]=p;
		if(!p)
		{
			ins(i,1);
		}
		else
		{
			modify(1,1,n,i,pr[i],a[npos[i]]);
		}
	}
	//�������� 
}
