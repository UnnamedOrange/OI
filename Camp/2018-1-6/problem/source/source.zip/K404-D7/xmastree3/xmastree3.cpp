#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int fa[55], label[55];
int n, m, k;
int ma[55][55],temp[55][55];
queue<int> que;
int d[55];
int top;
bool vis[55];
inline void bianli(int x, int fa) {
	for(int i = 1; i <= n; ++i) {
		if(ma[x][i] && i != fa) {
			vis[i] = 1;
			bianli(i, x);
		}
	}
}
inline void dfs(int s, int f, int x) {
	int u;
	memset(vis, 0, sizeof(vis));
	bianli(s, s);
	top = 0;
	for(int i = 1; i <= n; ++i) {
		if(vis[i]) d[++top] = i;
	}
	if(!top) return;
	if(x == k) return;
	u = d[rand() % top + 1];
	fa[u] = f;
	label[u] = x;
	top = 0;
	for(int i = 1; i <= n; ++i) {
		if(ma[u][i]) d[++top] = i;
	}
	if(!top) return;
	int v;
	v = d[rand() % top + 1];
	ma[u][v] = ma[v][u] = 0;
	dfs(v, u, x + (rand() % (k - x) + 1));
}
vector<int>quchong;
set< vector<int> > chong;
int ans;
int main() {
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
srand(time(0));
	R(n), R(k);
	if(k > n || n > 4) {
		puts("0");
		return 0;
	}
	int x, y;
	for(int i = 1; i < n; ++i) {
		R(x), R(y);
		temp[x][y] = ma[x][y] = 1;
		temp[y][x] = ma[y][x] = 1;

	}
	for(int t = 1; t <= 500000; ++t) {
		for(int i = 1; i <= n; ++i) {
			for(int j = 1; j <= k - n + 1; ++j) {
				for(int t = 1; t <= n; ++t) {
					for(int l = 1; l <= n; ++l) {
						ma[t][l] = temp[t][l];
					}
				}
				dfs(i, 0, j);
				quchong.clear();
				for(int t = 1; t <= n; ++t) {
					quchong.push_back(fa[t]);
					quchong.push_back(label[t]);
				}
				if(chong.find(quchong) == chong.end()) {
					++ans;
					chong.insert(quchong);
				}
			}
		}
	}
	printf("%d\n", ans);
	return 0;
}
