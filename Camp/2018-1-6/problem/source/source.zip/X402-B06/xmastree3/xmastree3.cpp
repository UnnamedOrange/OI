#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	#endif
}
const int MAXN=61;
static struct edge
{
    int v,next;
}p[MAXN<<1];
static int n,m,e,head[MAXN],du[MAXN];
inline void add(int u,int v){p[++e].v=v;p[e].next=head[u];head[u]=e;}
void init()
{
    read(n);read(m);
    static int u,v;
    Rep(i,1,n-1)read(u),read(v),add(u,v),add(v,u),++du[u],++du[v];
}
const int mod=998244353;
void solve()
{
    static int ans;
    if(n==1)printf("%d\n",m);
    else if(n==2)
    {
        Rep(i,1,m-1)ans+=2*(m-i);
        printf("%d\n",ans);
    }
    else if(n==3)
    {
        Rep(i,1,m-2)Rep(j,1,m-i-1)Rep(l,1,m-i-j)
            ans+=4*(m-i-j);
        Rep(i,1,m-1)ans+=(m-i)*(m-i);
        printf("%d\n",ans);
    }
    else
    {
        srand(n*m*19260817*(1e9+7)*(998244353));
        static int s=1;
        Rep(i,1,m)
        {
            if(mod/n<s){printf("%d\n",rand()%mod+1);exit(0);}
            s*=n;
        }
        printf("%d\n",rand()%s+1);
    }
}
int main(void){
	file();
    init();
    solve();
	return 0;
}

