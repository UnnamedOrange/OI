/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 100000 + 10;
const int MAXK = 500 + 10;
const int mod = 998244353;

int n, m, x, y, k;
int f[MAXN][MAXK], s[MAXK][MAXK];
std::vector<int> edge[MAXN], top;
bool vis[MAXN];

inline void add(int &x, int t) {
	x += t, (x >= mod) ? (x -= mod) : (x);
}

inline void add_edge(int x, int y) {
	edge[x].push_back(y);
}

inline void read_in() {
	R(n), R(m), R(k);
	for (int i = 1; i <= m; ++i) R(x), R(y), add_edge(x, y);
}

inline void pre(int n) {
	s[0][0] = 1;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= i; ++j) {
			add(s[i][j], (long long)j * s[i - 1][j] % mod);
			add(s[i][j], s[i - 1][j - 1]);
		}
}

inline void dfs(int cur) {
	vis[cur] = true;
	for (int p = 0; p < edge[cur].size(); ++p) {
		int v = edge[cur][p];
		if (!vis[v]) dfs(v);
	}
	top.push_back(cur);
}

inline void solve() {
	dfs(1), pre(k), f[1][0] = 1;
	for (int i = top.size() - 1; i >= 0; --i) {
		int cur = top[i];
		for (register int p = 0; p < edge[cur].size(); ++p) {
			int v = edge[cur][p];
			add(f[v][0], f[cur][0]);
			for (register int j = 1; j <= k; ++j) {
				add(f[v][j], (long long)j * f[cur][j - 1] % mod);
				add(f[v][j], f[cur][j]);
			}
		}
	}
	
	for (int cur = 1; cur <= n; ++cur) {
		int ans = 0;
		for (int i = 0; i <= k; ++i)
			add(ans, (long long)s[k][i] * f[cur][i] % mod);
		W(ans), write_char('\n');
	}
}

int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	read_in();
	solve();
	flush();
}
