#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int n,m,ans;
int a[40],len[10],num[10][110];
char s[10][110];
bool check()
{
    for(int i=1; i<=n; i++)
    {
        bool flag=false;
        for(int j=0; j<=2*m-len[i]; j++)
        {
            int k;
            for(k=1; k<=len[i]; k++)
                if(a[j+k]!=num[i][k])
                    break;
            if(k==len[i]+1)
            {
                flag=true;
                break;
            }
        }
        if(!flag)
            return false;
    }
    return true;
}
void dfs(int step)
{
    if(step==m+1)
    {
        int j=m;
        for(int i=m+1; i<=2*m; i++,j--)
            a[i]=a[j]^1;
        if(check())
            ans++;
    }
    else
    {
        a[step]=0;
        dfs(step+1);
        a[step]=1;
        dfs(step+1);
    }
}
int main()
{
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1; i<=n; i++)
    {
        scanf("%s",&s[i][1]);
        len[i]=strlen(&s[i][1]);
        for(int j=1; j<=len[i]; j++)
            num[i][j]=s[i][j]-'0';
    }
    if(m<=15)
    {
        dfs(1);
        printf("%d\n",ans);
    }
    else puts("0");
    return 0;
}
