#include<cstdio>
#include<vector>
#include<set>
using namespace std;

const int maxn = 5e3 + 5;
int color[maxn];
int fa[maxn];
int n, q, flag, opt, u, l, r, old = 0, c;
vector<int> point[maxn];
set<int> s;

inline void putit()
{
	int c, u, v;
	scanf("%d%d%d", &n, &q, &flag);
	for(int i = 1; i <= n; ++i)
	{
		scanf("%d", &c);
		color[i] = c;
	}
	for(int i = 1; i < n; ++i)
	{
		scanf("%d%d", &u, &v);
		point[u].push_back(v); point[v].push_back(u);
	}	
}

void build(int t)
{
	for(int i = point[t].size() - 1; i >= 0; --i)
	{
		int now = point[t][i];
		if(now == fa[t])	continue;
		fa[now] = t;
		build(now);	
	}
}

inline void query(int t)
{
	if(l <= color[t] && color[t] <= r)
	s.insert(color[t]);
	for(int i = point[t].size() - 1; i >= 0; --i)
	{
		if(point[t][i] != fa[t])
		{
			query(point[t][i]);
		}
	}
}

inline void workk_1()
{
	s.clear();
	scanf("%d%d%d", &u, &l, &r);
	if(flag == 1)
	{
		u = u ^ old; l = l ^ old; r = r ^ old;
	}
	query(u);
	if(flag == 1)
	{
		old = s.size();
		printf("%d\n", old);	
	}
	else
	{
		printf("%d\n", s.size());
	}
}

inline void workk_2()
{
	scanf("%d%d", &u, &c);
	if(flag == 1)	
	{
		u = u ^ old;
		c = c ^ old;
	}
	color[u] = c;
}

int main()
{
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	putit();
	build(1);
	for(int v = 1; v <= q; ++v)
	{
		scanf("%d", &opt);
		if(opt == 1)	workk_1();
		else workk_2();
	}
	return 0;
}
