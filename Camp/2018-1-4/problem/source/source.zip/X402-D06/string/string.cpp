#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=10;
const int maxlen=1e2+10;
const int maxm=5e2+10;
const int mod=998244353;
char str[maxn][maxlen];
int q[maxm<<1],len[maxn];
int n,m;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int ans=0;
inline int check(){
	int i,j,k;
	for(i=m+1;i<=2*m;i++)q[i]=q[2*m-i+1]^1;
	int cnt=0;
	for(i=1;i<=n;i++){
		int f=0;
		for(j=1;j<=2*m-len[i]+1;j++){
			int flag=0;
			for(k=1;k<=len[i];k++)
				if(str[i][k]-'0'!=q[j+k-1]){
					flag=1;
					break;
				}
			if(!flag){
				f=1;
				break;
			}
		}
		cnt+=f;
	}
	return cnt==n;
}
void dfs(int cur,int goal){
	if(cur>goal){
		ans+=check();
		return;
	}
	q[cur]=0;
	dfs(cur+1,goal);
	q[cur]=1;
	dfs(cur+1,goal);
}
int main(){
	int i,j,k;
#ifndef ONLINE_JUDGE
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	n=read();m=read();
	for(i=1;i<=n;i++){
		scanf("%s",str[i]+1);
		len[i]=strlen(str[i]+1);
	}
	if(n==1){
		int fans=0;
		for(i=1;i+len[1]-1<=2*m;i++){
			int tmpans=1;
			memset(q,-1,sizeof(q));
			for(j=i;j<=i+len[1]-1;j++)
				q[j]=str[1][j-i+1]-'0';
			for(j=1;j<=m;j++){
				if(q[j]<0 && q[2*m-j+1]<0)tmpans=tmpans*2%mod;
				else if(q[j]>=0 && q[2*m-j+1]>=0 && q[j]+q[2*m-j+1]!=1)tmpans=0;
			}
			fans=(fans+tmpans)%mod;
		}
		printf("%d\n",fans);
		return 0;
	}
	else if(m<=15){
		dfs(1,m);
		printf("%d\n",ans);
	}
	else puts("0");
	return 0;
}

