#include<bits/stdc++.h>
using namespace std;

const int maxn=30;
int n;
int a[maxn];

void chkmin(int& x,int y){ if(x>y) x=y; }

int ans;
bool check(){
	for(int i=1;i<=n;i++) if(a[i]!=i) return false;
	return true;
}
int calc(){
	int ret=0; a[n+1]=n+1;
	for(int i=2;i<=n+1;i++) ret+=abs(a[i]-a[i-1])==1;
	return n-ret;
}
void dfs(int x,int lst){
	if(check()){ 
		// printf("x = %d\n", x);
		chkmin(ans, x); return; }
	if(x+calc()>=ans) return;
	int b[maxn]={0};
	memcpy(b,a,sizeof(a));
	for(int i=n;i>=1;i--) if(i!=lst){
		for(int j=1;j*2<=i;j++) swap(a[j], a[i-j+1]);
		dfs(x+1,i);
		memcpy(a,b,sizeof(a));
	}
}

int main(){
	freopen("sequence22.in","r",stdin),freopen("sequence.out","w",stdout);

	int T;
	scanf("%d", &T);
	while(T--){
		scanf("%d", &n);
		ans=n*2;
		for(int i=1;i<=n;i++) scanf("%d", &a[i]);
		dfs(0,0);
		printf("%d\n", ans);
	}
	return 0;
}
