#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int mod=998244353;
int n, m, k;
int ans, a[maxn];
int pw[maxn];

ll Pow(ll x,ll y){
	ll ret=1;
	while(y){ if(y&1) ret=ret*x%mod; x=x*x%mod; y>>=1; }
	return ret;
}

void dfs(int l,int r,int cnt){
	// printf("%d %d %d\n", l, r, cnt);
	if(cnt==n){
		for(int i=1;i<=m;i++) (ans+=pw[ a[i] ])%=mod;
		// for(int i=1;i<=m;i++) printf("%d ", a[i]); puts("");
		return;
	}
	for(int i=l+1;i<=m;i++) for(int j=max(i, r+1);j<=m;j++){
		for(int k=i;k<j;k++) a[k]++;
		dfs(i, j, cnt+1);
		for(int k=i;k<j;k++) a[k]--;
	}
}

void solve(){
	int ret=0;
	for(int i=0;i<m;i++) ret=(ret+1ll*(m-i)*i%mod)%mod;
	printf("%d\n", ret);
}

int dp[50][50][51], f[50][50][51], cnt[50][50][51];
void solve2(){
	dp[0][0][0]=0; f[0][0][0]=1; cnt[0][0][0]=1;
	for(int i=0;i<=m;i++) for(int j=i;j<=m;j++) for(int k=0;k<n;k++) if(f[i][j][k]){
		for(int ii=i+1;ii<=m;ii++) for(int jj=max(ii, j+1);jj<=m;jj++) (dp[ii][jj][k+1]+=dp[i][j][k]+(jj-ii)*cnt[i][j][k])%=mod, f[ii][jj][k+1]=1, (cnt[ii][jj][k+1]+=cnt[i][j][k])%=mod;
	}
	// printf("dp = %d\n", dp[2][3][2]);
	// for(int i=n;i<=m;i++,puts("")) for(int j=i;j<=m;j++) printf("%d ", dp[i][j][n]);
	for(int i=n;i<=m;i++) for(int j=i;j<=m;j++) (ans+=dp[i][j][n])%=mod;
	printf("%d\n", ans);
}

void solve1(){
	dp[0][0][0]=0, f[0][0][0]=1, cnt[0][0][0]=1;
	for(int i=0;i<=m;i++) for(int j=i;j<=m;j++) for(int k=0;k<n;k++) if(f[i][j][k]){
		for(int ii=i+1;ii<=m;ii++) for(int jj=max(ii, j+1);jj<=m;jj++)
			(dp[ii][jj][k+1]+=dp[i][j][k]+(jj-max(ii, max(j, 0)))*cnt[i][j][k])%=mod,
				f[ii][jj][k+1]=1, (cnt[ii][jj][k+1]+=cnt[i][j][k])%=mod;
	}
	// printf("dp = %d\n", dp[1][3][1]);
	// for(int i=n;i<=m;i++,puts("")) for(int j=i;j<=m;j++) printf("%d ", dp[i][j][n]);
	for(int i=n;i<=m;i++) for(int j=i;j<=m;j++) (ans+=dp[i][j][n])%=mod;
	printf("%d\n", ans);
}

int main(){
	freopen("segment.in","r",stdin),freopen("segment.out","w",stdout);

	scanf("%d%d%d", &n, &m, &k);
	for(int i=1;i<=m;i++) pw[i]=Pow(i, k);
	// for(int i=1;i<=m;i++) printf("%d ", pw[i]); puts("");
	if(n>=m){ puts("0"); return 0; }
	if(n==1){ solve(); return 0; }
	if(k==1){ solve2(); return 0; }
	if(k==998244352){ solve1(); return 0; }
	ans=0;
	dfs(0, 0, 0);
	printf("%d\n", ans);
	return 0;
}
