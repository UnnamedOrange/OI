#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
#define maxn 1000010
using namespace std;
vector<int>group[maxn];
int n,m,head[maxn],num,head2[maxn],num2,belong[maxn],g,du[maxn];
int low[maxn],dfn[maxn],top,st[maxn],cnt,sz[maxn],ans;
bool in[maxn];
struct node{
	int to,pre;
}e[maxn*2],e2[maxn*2];
void Insert(int from,int to){
	e[++num].to=to;
	e[num].pre=head[from];
	head[from]=num;
}
void Insert2(int from,int to){
	e2[++num2].to=to;
	e2[num2].pre=head2[from];
	head2[from]=num2;
}
void Tarjan(int u){
	cnt++;st[++top]=u;in[u]=1;low[u]=dfn[u]=cnt;
	for(int i=head[u];i;i=e[i].pre){
		int v=e[i].to;
		if(!dfn[v]){
			Tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else{
			if(in[v])low[u]=min(low[u],dfn[v]);
		}
	}
	if(dfn[u]==low[u]){
		g++;
		while(st[top]!=u){
			int x=st[top];
			top--;
			in[x]=0;
			group[g].push_back(x);
			belong[x]=g;
		}
		top--;in[u]=0;
		belong[u]=g;
		group[g].push_back(u);
	}
}
bool v[maxn];
void dfs(int now,int w){
	ans=max(ans,w);
	for(int i=head2[now];i;i=e2[i].pre){
		int to=e2[i].to;
		if(!v[to]){
			v[to]=1;
			dfs(to,w+sz[to]);
			v[to]=0;
		}
	}
}
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("bomb.in","r",stdin);freopen("bomb.out","w",stdout); 
	scanf("%d%d",&n,&m);
	int x,y;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		Insert(x,y);
	}
	for(int i=1;i<=n;i++){
		if(!dfn[i])Tarjan(i);
	}
	for(int i=1;i<=g;i++)sz[i]=group[i].size();
	for(int i=1;i<=g;i++)
		for(int j=0;j<group[i].size();j++){
			int from=group[i][j];
			for(int k=head[from];k;k=e[k].pre){
				int to=e[k].to;
				if(belong[from]!=belong[to])
					Insert2(belong[from],belong[to]),du[belong[to]]++;
			}
		}
	for(int i=1;i<=g;i++){
		if(du[i]==0){//ru du wei 0
			v[i]=1;
			dfs(i,sz[i]);
			v[i]=0;
		}
	}
	printf("%d",ans);
	return 0;
}
