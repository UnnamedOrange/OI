#include <cstdio>
#include <cstdlib>
#include <process.h>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

using namespace std;

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

void rands(int n,int mx=2)
{
    rep(i,1,n)
        putchar('a'+rand(mx));
    puts("");
}

int main()
{
    srand(_getpid()^(unsigned long long)new char);
    freopen("xmasinterval.in","w",stdout);
    int n=rand(1,20),m=rand(1,20),mx=rand(1,1000);
    printf("%d %d\n",m,n);
    rep(i,1,m)
    {
        int l=rand(1,mx),r=rand(1,mx);
        if (l>r)
            swap(l,r);
        printf("%d %d\n",l,r);
    }
    rep(i,1,n)
        printf("%d\n",rand(1,mx));
    return 0;
}
