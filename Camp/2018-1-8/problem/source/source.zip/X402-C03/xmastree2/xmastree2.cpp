#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=3e4+10;
int n,w[maxn],r[maxn],p[maxn],fa[maxn];
ll ans;
vector<int> g[maxn];

void dfs(int pos){
	for(int i=0;i<g[pos].size();++i)
		if(g[pos][i]!=fa[pos]){
			fa[g[pos][i]]=pos;
			dfs(g[pos][i]);
		}
}

int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	for(int i=1,u,v;i<n;++i){
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	for(int i=1;i<=n;++i)
		scanf("%d%d",&w[i],&r[i]);
	for(int i=1;i<=n;++i)
		if(r[i]==1){
			fa[i]=0;
			dfs(i);
			for(int j=1;j<=n;++j)
				p[j]=j;
			do{
				ll res=0;
				for(int j=1;j<=n;++j)
					if(p[fa[j]]>p[j])
						goto hell;
				for(int j=1;j<=n;++j)
					res+=p[j]*w[j];
				if(ans<res)
					ans=res;
hell:
				;
			}
			while(next_permutation(p+1,p+n+1));
		}
	printf("%lld\n",ans);
	return 0;
}
