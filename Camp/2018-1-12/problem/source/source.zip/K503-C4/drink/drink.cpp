#include<iostream>
#include<cstdio>
#include<algorithm>
#define maxn 1000010
using namespace std;
int n,w[maxn],a[maxn],cnt;
double now,ans,N;
int find(double now){
	int l=1,r=cnt,res=0;
	while(l<=r){
		int mid=(l+r)>>1;
		if(a[mid]>now)res=mid,r=mid-1;
		else l=mid+1;
	}
	return res;
}
int main(){
//	freopen("Cola.txt","r",stdin);
	freopen("drink.in","r",stdin);freopen("drink.out","w",stdout);
	scanf("%d",&n);
	N=(double)n*n;
	for(int i=1;i<=n;i++)scanf("%d",&w[i]);
	for(int l=1;l<=n;l++){
		for(int r=l;r<=n;r++){
			cnt=0;
			for(int i=l;i<=r;i++)a[++cnt]=w[i];
			sort(a+1,a+cnt+1);now=0;
			int pos=find(now);
			while(pos){
				a[pos]=now=(double)(now+a[pos])/2.0;
				pos=find(now);
			}
			ans+=now/N;
		}
	}
	printf("%.12lf",ans);
}
