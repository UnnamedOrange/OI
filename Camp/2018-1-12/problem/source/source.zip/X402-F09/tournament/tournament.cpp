#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=998244353;
int n,k,ed[9][9],l[9],ans,f[9],r;
int dfs2(int x,int d){
	if (d==k-1){
		For(i,1,l[x])
			if (ed[x][i]==r) return 1;
		return 0;
	}
	f[x]=1;
	For(i,1,l[x])
		if (!f[ed[x][i]])
			if (dfs2(ed[x][i],d+1)) {f[x]=0; return 1;}
	f[x]=0; return 0;
}
int ju(){
	For(i,1,n){
		r=i; if (dfs2(i,0)) return 1;
	}
	return 0;
}
void dfs(int x,int y){
	if (x==n-1&&y==n){
		ed[x][++l[x]]=y; if (ju()) ++ans; --l[x];
		ed[y][++l[y]]=x; if (ju()) ++ans; --l[y];
		return;
	}
	ed[x][++l[x]]=y; 
	if (y<n) dfs(x,y+1); else dfs(x+1,x+2);
	--l[x]; ed[y][++l[y]]=x;
	if (y<n) dfs(x,y+1); else dfs(x+1,x+2);
	--l[y];
}
int main(){
	freopen("tournament.in","r",stdin); freopen("tournament.out","w",stdout);
	n=read(),k=read(); int r,an; long long s;
	if (n<=6&&k<=6) dfs(1,2),printf("%d\n",ans);
	else if (k==3){
		r=n*(n-1)>>1; an=1; s=1;
		For(i,1,r) {an<<=1; if (an>=mo) an-=mo;}
		For(i,2,n) s=s*i%mo;
		an-=s; if (an<0) an+=mo; printf("%d\n",an);
	}
	return 0;
}
