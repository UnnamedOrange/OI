#include <queue>
#include <cctype>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <functional>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)
#define repd(i,x,y) for (int i=x; i>=(y); --i)
#define repe(i,x) for (edge *i=fst[x]; i; i=i->nxt)

using namespace std;

int get()
{
    char c;
    while (!isdigit(c=getchar()) && c!='-');
    int s=c=='-'? -1:1,k=~s? c-'0':0;
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return s*k;
}

const int N=1e6+10,M=1e6+10;

struct edge
{
    int v;
    edge *nxt;
} pool[M],*tp=pool,*fst[N];
int n,m,idx,dfn[N],low[N],top,stk[N],tot,bel[N],size[N],deg[N],ans;
vector<int> vtx[N];
bool inst[N];
struct data
{
    int x,s;
    bool operator>(const data &t) const
    {
        return s>t.s;
    }
};
priority_queue<data,vector<data>,greater<data> > h;

void tarjan(int x)
{
    dfn[x]=low[x]=++idx,stk[++top]=x,inst[x]=1;
    repe(i,x)
        if (!dfn[i->v])
            tarjan(i->v),low[x]=min(low[x],low[i->v]);
        else if (inst[i->v])
            low[x]=min(low[x],dfn[i->v]);
    if (dfn[x]==low[x])
    {
        ++tot;
        do
        {
            int x=stk[top];
            bel[x]=tot,inst[x]=0,++size[tot],vtx[tot].push_back(x);
        } while (stk[top--]!=x);
    }
}

int main()
{
    freopen("bomb.in","r",stdin);
    freopen("bomb.out","w",stdout);
    n=get(),m=get();
    rep(i,1,m)
    {
        int u=get(),v=get();
        *tp=(edge){v,fst[u]},fst[u]=tp++;
    }
    rep(i,1,n)
        if (!dfn[i])
            tarjan(i);
    rep(x,1,n)
        repe(i,x)
            if (bel[x]!=bel[i->v])
                ++deg[bel[i->v]];
    rep(i,1,tot)
        if (!deg[i])
            h.push((data){i,size[i]});
    for (int c=0,x,s,y; h.size();)
    {
        x=h.top().x,s=h.top().s-c,h.pop(),ans+=s,c+=s;
        rep(_,0,size[x]-1)
        {
            int u=vtx[x][_];
            repe(i,u)
                if (x!=(y=bel[i->v]) && !--deg[y])
                    h.push((data){y,size[y]+c});
        }
    }
    printf("%d",ans);
    return 0;
}
