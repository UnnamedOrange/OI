#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const ll maxn=1e3+5;
const ll INF=1e17;
ll n,W,p,q,xi[maxn],yi[maxn],zi[maxn],ai[maxn];
ll bi[maxn],ci[maxn],di[maxn],ei[maxn],fi[maxn];
ll ri[maxn],X[maxn],Y[maxn],ans,bit[25],wi[maxn];
ll hi[maxn];
inline void read(ll &now)
{
	char Cget;
	now=0;
	ll if_z=1;
	while((Cget=getchar())>'9'||Cget<'0')
		if(Cget=='-')
			if_z=-1;
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
	now*=if_z;
}
ll getval(ll S)
{
	ll res=0;
	for(ll i=1;i<=n;i++)
	{
		if(S&bit[i])
			wi[i]=W;
		else
			wi[i]=-W;
		res+=wi[i];
	}
	for(ll i=1;i<=q;i++)
		if(ri[i]==0)
		{
			if(wi[X[i]]>wi[Y[i]])
				return INF;
		}
		else if(ri[i]==1)
		{
			if(wi[X[i]]!=wi[Y[i]])
				return INF;
		}
		else if(wi[X[i]]>=wi[Y[i]])
			return INF;
	for(ll i=1;i<=p;i++)
	{
		hi[i]=ai[i]*std::abs(wi[xi[i]]-wi[yi[i]])+bi[i]*std::abs(wi[yi[i]]-wi[zi[i]]);
		hi[i]+=ci[i]*std::abs(wi[zi[i]]-wi[xi[i]])+di[i]*(wi[xi[i]]-wi[yi[i]]);
		hi[i]+=ei[i]*(wi[yi[i]]-wi[zi[i]])+fi[i]*(wi[zi[i]]-wi[xi[i]]);
		res+=hi[i];
	}
	return res;
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	ll T;
	read(T);
	bit[1]=1;
	for(ll i=2;i<=15;i++)
		bit[i]=bit[i-1]<<1;
	while(T--)
	{
		read(n);
		read(W);
		read(p);
		read(q);
		for(ll i=1;i<=p;i++)
		{
			read(xi[i]);
			read(yi[i]);
			read(zi[i]);
			read(ai[i]);
			read(bi[i]);
			read(ci[i]);
			read(di[i]);
			read(ei[i]);
			read(fi[i]);
		}
		for(ll i=1;i<=q;i++)
		{
			read(X[i]);
			read(Y[i]);
			read(ri[i]);
		}
		if(n<15)
		{
			ans=INF;
			for(ll i=0;i<(1<<n);i++)
				ans=std::min(ans,getval(i));
			printf("%lld\n",ans);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
