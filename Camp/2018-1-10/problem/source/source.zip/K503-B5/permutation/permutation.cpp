#include<bits/stdc++.h>
using namespace std;
const int p=998244353;
int a[200000],du[200000];
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int n;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%d",a+i);
		du[a[i]]++;
	}
	if (n&1){
		puts("0");
		return 0;
	}
	int x=0,y=0;
	for (int i=1;i<=n;i++)
		if (!du[i]){
			int p=i,t=0;
			while (p){
				p=a[p];
				t++;
			}
			if (t&1) x++;
			else y++;
		}
	for (int i=1;i<=n;i++){
		if (!du[i]) continue;
		int p=a[i],t=1;
		while (p&&p!=i){
			p=a[p];
			t++;
		}
		if (p==i&&t&1){
			puts("0");
			return 0;
		}
	}
	int ans=1;
	for (int i=1;i<x;i+=2)
		ans=(long long)ans*i%p*i%p;
	for (int i=1;i<=y;i++)
		ans=(long long)ans*(x+i)%p;
	printf("%d\n",ans);
	return 0;
}
