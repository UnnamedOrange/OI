#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
int T,opt,n,a,b,cc,fla;
int j,k,f[maxn],ha[maxn],ff[maxn],r,ans1,ans2,ans3,ans4;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void checking(){
	int i,t1,t2,tt;
	r=0;
	for (i=1;i<=n;i++){
		if (ha[i]==1){
			r++; ff[r]=f[i];
		}
	}
	if (r==0){
		ans4++;
		return;
	}
	tt=0;
	for (i=1;i<=r;i++){
		ff[i]=ff[i]%cc;
		if (ff[i]>=b) tt++;
	}
	sort(ff+1,ff+r+1);
	for (i=1;i<=r/2;i++) swap(ff[i],ff[r-i+1]);
	if (tt%2==1) t1=1;
	else{
		tt=0;
		for (i=1;i<=r;i++){
			if ((ff[i]<b)&&(ff[i]>=a)){
				tt=1; break;
			}
		}
		if (ff[1]/a>=2) tt=1;
		if (tt==1) t1=1;
		else t1=0;
	}
	tt=0;
	for (i=1;i<=r;i++){
		if (ff[i]>=b) tt++;
	}
	if (tt%2==0) t2=1;
	else{
		tt=0;
		for (i=1;i<=r;i++){
			if ((ff[i]<b)&&(ff[i]>=a)){
				tt=1; break;
			}
		}
		if ((r>=2)&&(ff[2]/a>=2)) tt=1;
		if (tt==1) t2=1;
		else t2=0;
	}
	if ((t1==1)&&(t2==1)){
		if (fla==0){
			ans1++;
		}
		else ans2++;
	}
	if ((t1==0)&&(t2==0)){
		if (fla==0){
			ans2++;
		}
		else ans1++;
	}
	if ((t1==1)&&(t2==0)){
		ans3++;
	}
	if ((t1==0)&&(t2==1)){
		ans4++;
	}
}
void work(int x){
	if (x==n+1){
		checking();
		return;
	}
	ha[x]=0; work(x+1);
	ha[x]=1; work(x+1);
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n=read(); a=read(); b=read();
	if (a>b){fla=1;swap(a,b);}
	else fla=0;
	cc=(a+b);
	for (j=1;j<=n;j++){
		f[j]=read();
	}
	work(1);
	printf("%d %d %d %d\n",ans1,ans2,ans3,ans4);
	return 0;
}
