#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0;char ch=getchar();
	while(ch<'0'||'9'<ch)ch=getchar();
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret;
}
#define N 1000010
int a[N];
double mi[30];
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int n=re();
	for(int i=1;i<=n;i++)
		a[i]=re();
	mi[0]=1;
	for(int i=1;i<=25;i++)
		mi[i]=mi[i-1]*0.5;
	int g[30];
	int pos;
	double pre=0;
	double ans=0;
	for(int l=1;l<=n;l++){
		pre=0;
		memset(g,0,sizeof(g));
		for(int r=l;r<=n;r++){
			if(a[r]>g[25]){
				pos=24;
				while(g[pos]<a[r]&&pos)
					pos--;
				pos++;
				for(int i=25;i>pos;i--){
					pre+=(g[i-1]-g[i])*mi[i];
					g[i]=g[i-1];
				}
				pre+=(a[r]-g[pos])*mi[pos];
				g[pos]=a[r];
			}
			ans+=pre;
		}
	}
	ans/=n*n;
	printf("%.5f",ans);
	return 0;
}
