#include <cstdio>
#include <cstring>
#include <algorithm>
#define ele int
using namespace std;
#define maxn 23
ele n,m,k,ans,a[maxn],b[maxn];
bool dfs(ele i,ele j,ele p){
	if (p==ans) return i==n && j==m;
	for (int r=1; r<=k; ++r){
		ele i1=min(n,i+1),j1=min(m,j+1);
		while (i1<n && a[i1]!=r) ++i1;
		while (j1<m && b[j1]!=r) ++j1;
		if (dfs(i1,j1,p+1)) return true;
	}
	return false;
}
int main(){
	freopen("subsequence.in","r",stdin); freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=0; i<n; ++i) scanf("%d",a+i);
	for (int i=0; i<m; ++i) scanf("%d",b+i);
	ans=1;
	while (!dfs(-1,-1,0)) ++ans;
	printf("%d\n",ans);
	return 0;
}