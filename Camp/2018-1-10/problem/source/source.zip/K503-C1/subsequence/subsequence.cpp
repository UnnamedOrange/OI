# include <bits/stdc++.h>
# define 	N 		310
# define 	inf 	1e9
using namespace std;
int a[N],b[N],fa[N][N],fb[N][N],f[N][N],n,m,k;
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1; i<=n; i++) scanf("%d",&a[i]);
	for (int i=1; i<=m; i++) scanf("%d",&b[i]);
	for (int i=1; i<=k; i++) fa[n][i]=fa[n+1][i]=n+1;
	for (int i=n-1; i>=0; i--){
		for (int j=1; j<=k; j++) fa[i][j]=fa[i+1][j];
		fa[i][a[i+1]]=i+1;
	}
	for (int i=1; i<=k; i++) fb[m][i]=fb[m+1][i]=m+1;
	for (int i=m-1; i>=0; i--){
		for (int j=1; j<=k; j++) fb[i][j]=fb[i+1][j];
		fb[i][b[i+1]]=i+1;
	}
	for (int i=0; i<=n; i++)
		for (int j=0; j<=m; j++)
			f[i][j]=inf;
	for (int i=1; i<=k; i++){
		int nxa=fa[0][i]-1, nxb=fb[0][i]-1;
		f[nxa][nxb]=1;
	}
	for (int i=0; i<=n; i++)
		for (int j=0; j<=m; j++){
			if (f[i][j]==inf) continue;
			for (int t=1; t<=k; t++){
				int nxa=fa[i+1][t]-1, nxb=fb[j+1][t]-1;
				f[nxa][nxb]=min(f[nxa][nxb],f[i][j]+1);
			}
		}	
	printf("%d\n",f[n][m]);
	return 0;
}

