#include<iostream>
#include<cstdio>
#define MOD 998244353
#define NN 100000+100
#define LL long long
#define mo(x) x%=MOD
using namespace std;
LL ksm(LL a,int b){
	LL op=1;
	while(b){
		if(b&1){
			(op*=a)%=MOD;
		}
		b>>=1;
		(a*=a)%=MOD;
	}
	return op;
}
int l,n,k;
LL fact[NN]={0},rev[NN]={0};
void create_list(int n){
	fact[0]=1;
	for(int i=1;i<=n;++i){
		fact[i]=(fact[i-1]*i)%MOD;
	}
	rev[n]=ksm(fact[n],MOD-2);
	rev[0]=1;
	rev[1]=1;
	for(int i=n-1;i>=1;--i){
		rev[i]=(rev[i+1]*(i+1))%MOD;
	}
}
LL tot_len(){
	LL ans=0,tp=0;
	LL rev2=ksm(2,MOD-2);
	create_list(l);
	for(int i=l;i>n;--i){
		//fact[i]*fact[i-1]*rev[n]*rev[n-1]*rev[i-n]*rev[i-n]*(i-n)*rev2;
		tp=fact[i]*fact[i-1];
		mo(tp);
		tp*=rev[n];
		mo(tp);
		tp*=rev[n-1];
		mo(tp);
		tp*=rev[i-n];
		mo(tp);
		tp*=rev[i-n];
		mo(tp);
		tp*=(i-n);
		mo(tp);
		tp*=rev2;
		mo(tp);
		(ans+=tp)%=MOD;
	}
	return ans;
}
int sgt[30]={0};
LL check(){
	LL ans=0;
	for(int i=1;i<=n;++i){
		(ans+=ksm(sgt[i],k))%=MOD;
	}
	return ans;
}
LL dfs(int cnt,int pl,int pr){
	if(cnt==n+1){
		return check();
	}
	LL ans=0;
	for(int ll=pl+1,topl=l-n+cnt;ll<=topl;++ll){
		for(int rr=max(pr+1,ll),topr=l-n+cnt;rr<=topr;++rr){
			for(int i=ll;i<rr;++i){
				++sgt[i];
			}
			(ans+=dfs(cnt+1,ll,rr))%=MOD;
			for(int i=ll;i<rr;++i){
				--sgt[i];
			}
		}
	}
	return ans;
}
LL brute_force(){
	return dfs(1,0,0);
}
LL tri1(){
	//(n+1)*n*n/2-(n+1)*n*(2n+1)/6
	LL ans=((l+1)*l/2)%MOD;
	ans%=MOD;
	(ans*=l)%=MOD;
	LL minus=(2*n+1)*(n+1)%MOD;
	(minus*=n)%=MOD;
	(minus*=ksm(6,MOD-2))%=MOD;
	ans-=minus;
	(ans+=MOD)%=MOD;
	return ans;
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&l,&k);
	if(l<=n){
		printf("0");
		return 0;
	}
	if(l<=7){
		printf("%lld",brute_force());
		return 0;
	}
	if(n==1){
		printf("%lld",tri1());
		return 0;
	}
	if(k==1){
		printf("%lld",tot_len());
	}
}
