#include<bits/stdc++.h>
using namespace std;

const int maxn=510;
int n, w, p, q, ans;
int a[maxn], b[maxn], c[maxn], d[maxn], e[maxn], f[maxn], x[maxn], y[maxn], z[maxn];
struct limit{ int x, y, r; }l[maxn];
int use[maxn];

bool check(){
	for(int i=1;i<=q;i++){
		if(l[i].r==0 && use[l[i].x]>use[l[i].y]) return false;
		if(l[i].r==1 && use[l[i].x]!=use[l[i].y]) return false;
		if(l[i].r==2 && use[l[i].x]>=use[l[i].y]) return false;
	}
	return true;
}
int calc(){
	int ret=0;
	for(int i=1;i<=n;i++) ret+=use[i];
	for(int i=1;i<=p;i++){
		int t1=use[x[i]]-use[y[i]], t2=use[y[i]]-use[z[i]], t3=use[z[i]]-use[x[i]];
		ret+=a[i]*abs(t1)+b[i]*abs(t2)+c[i]*abs(t3)+d[i]*t1+e[i]*t2+f[i]*t3;
	}
	return ret*w;
}

int main(){
	freopen("variable.in","r",stdin),freopen("variable.out","w",stdout);

	int T;
	scanf("%d",&T);
	while(T--){
		ans=2e9;
		scanf("%d%d%d%d",&n,&w,&p,&q);
		for(int i=1;i<=p;i++){
			scanf("%d%d%d%d%d%d%d%d%d",&x[i], &y[i], &z[i], &a[i], &b[i], &c[i], &d[i], &e[i], &f[i]); 
		}
		for(int i=1;i<=q;i++) scanf("%d%d%d", &l[i].x, &l[i].y, &l[i].r);
		for(int i=0;i<(1<<n);i++){
			for(int j=1;j<=n;j++) if(i & (1<<(j-1))) use[j]=1; else use[j]=-1;
			if(!check()) continue;
			ans=min(ans, calc());
		}
		printf("%d\n", ans);
	}
	return 0;
}
