#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

using namespace std;

const int S=1e5+10,N=110,inf=0x3f3f3f3f;
int tc,n,ans,f[N][N],mx[N][N];
bool flag[N][N];
char str[S],a[S*2];

bool check(int l,int r,int x,int y)
{
    int d=mx[l][y];
    if (l+d<=r && y-d>=x)
        return 0;
    if (l+d>r && y-d<x)
        return 1;
    return r-l>y-x? flag[l+d][r]:flag[l][r-d];
}

void special()
{
    static int f[S*2];
    memset(f,0,sizeof(f));
    rep(i,1,n)
        if (str[i]!=str[n-i+1])
            return puts("1"),void();
    rep(i,1,n)
        a[i*2]=str[i];
    a[0]='$',a[n*2+2]='%';
    rep(i,0,n)
        a[i<<1|1]='#';
    n=n*2+2;
    for (int i=1,p=0,mx=0; i<n; ++i)
    {
        if (i>mx)
            p=i;
        for (f[i]=f[p*2-i]; a[i+f[i]+1]==a[i-f[i]-1]; ++f[i]);
        if (f[i]>=mx)
            p=i,mx=f[i];
    }
    rep(i,1,n)
    {
        if (i-f[i]==1)
            continue;
        int l=i-f[i]-1,r=i+f[i]+1,x=r+2,y=n-l,j=(x+y)>>1;
        if (x<j-f[j] && j+f[j]<y)
            return puts("2"),void();
    }
    puts("-1");
}

void work()
{
    scanf("%d%s",&n,str+1);
    if (n>100)
        return special();
    memset(f,63,sizeof(f));
    memset(flag,0,sizeof(flag));
    memset(mx,128,sizeof(mx));
    rep(i,1,n)
    {
        flag[i][i]=1,flag[i][i+1]=str[i]==str[i+1];
        mx[i][i]=1,flag[i][i+1]? mx[i][i+1]=2:0;
        flag[i][i+1]? 0:f[i][i+1]=1;
    }
    rep(k,3,n)
        rep(i,1,n-k+1)
        {
            int j=i+k-1;
            flag[i][j]=flag[i+1][j-1] && str[i]==str[j];
            mx[i][j]=flag[i][j]? j-i+1:mx[i+1][j-1]+1;
            if (!flag[i][j])
            {
                f[i][j]=1;
                continue;
            }
            rep(l,i+2,j-1)
                if (!flag[i][l-1])
                    f[i][j]=min(f[i][j],1+f[l][j]);
            rep(r,i+1,j-2)
                if (!flag[r+1][j])
                    f[i][j]=min(f[i][j],1+f[i][r]);
            rep(l,i+1,j-1)
                rep(r,l+1,j-1)
                    if (!check(i,l-1,r+1,j))
                        f[i][j]=min(f[i][j],1+f[l][r]);
        }
    printf("%d\n",ans=f[1][n]<inf? f[1][n]:-1);
    if (ans>2)
        throw 1;
}

int main()
{
    freopen("string.in","r",stdin);
    freopen("string.out","w",stdout);
    for (scanf("%d",&tc); tc--; work());
    return 0;
}
