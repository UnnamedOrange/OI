#include <cstdio>
#include <cstring>
#include <algorithm>
#define ele int
using namespace std;
#define maxn 1000010
struct edge{
	ele v;
	edge *nxt;
}ep[maxn<<2],*ecnt;
ele n,m,tcnt,bcnt,blg[maxn],f[maxn],evt[maxn<<1],flag[maxn],s[maxn];
edge *h[maxn],*ht[maxn],*h1[maxn];
inline void addedge(edge *h[],ele u,ele v){
	edge *p=ecnt++;
	p->v=v; p->nxt=h[u];
	h[u]=p;
}
void dfs1(ele i){
	flag[i]=1;
	++tcnt;
	for (edge *j=h[i]; j; j=j->nxt)
		if (!flag[j->v]) dfs1(j->v);
	evt[tcnt++]=i;
	flag[i]=2;
}
void dfs2(ele i){
	flag[i]=0; blg[i]=bcnt; ++s[bcnt];
	for (edge *j=ht[i]; j; j=j->nxt)
		if (flag[j->v]) dfs2(j->v);
}
ele solve(ele i){
	ele&res=f[i];
	if (~res) return res;
	res=s[i];
	for (edge *j=h1[i]; j; j=j->nxt) res=max(res,s[i]+solve(j->v));
	return res;
}
int main(){
	freopen("bomb.in","r",stdin); freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	ecnt=ep; memset(h,0,sizeof(h)); memset(ht,0,sizeof(ht)); memset(h1,0,sizeof(h1));
	for (int i=0; i<m; ++i){
		ele u,v;
		scanf("%d%d",&u,&v); --u,--v;
		addedge(h,u,v); addedge(ht,v,u);
	}
	tcnt=0; memset(evt,-1,sizeof(evt)); memset(flag,0,sizeof(flag));
	for (int i=0; i<n; ++i)
		if (!flag[i]) dfs1(i);
	bcnt=0; memset(s,0,sizeof(s));
	for (int i=(n<<1)-1; ~i; --i)
		if (~evt[i] && flag[evt[i]]){
			dfs2(evt[i]);
			++bcnt;
		}
	for (int i=0; i<n; ++i)
		for (edge *j=h[i]; j; j=j->nxt)
			if (blg[i]!=blg[j->v]) addedge(h1,blg[i],blg[j->v]);
	memset(f,-1,sizeof(f));
	ele ans=0;
	for (int i=0; i<bcnt; ++i) ans=max(ans,solve(i));
	printf("%d\n",ans);
	return 0;
}