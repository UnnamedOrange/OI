#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
const int Mod=1000000007;
struct node
{
	int l,r;
};
struct ans
{
	int mx,ans;
}f[1000010];
int n,c[1000010],d[1000010];
vector<node> v;
bool cmp(node x,node y)
{
	return x.r<y.r;
}
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++)
	{
		c[i]=read();
		d[i]=read();
	}
	for (int i=1;i<=n;i++)
	{
		int mn=c[i];
		int mx=d[i];
		for (int j=i;j<=n;j++)
		{
			mn=max(mn,c[j]);
			mx=min(mx,d[j]);
			int s=j-i+1;
			if (s>=mn && s<=mx)
			{
				//cout<<i<<" "<<j<<endl;
				v.push_back((node){i,j});
			}
		}
	}
	sort(v.begin(),v.end(),cmp);
	f[0].ans=1;
	int size=v.size();
	for (int i=0;i<size;i++)
	{
		int l=v[i].l;
		int r=v[i].r;
		if (f[l-1].mx+1>f[r].mx)
		{
			f[r].mx=f[l-1].mx+1;
			f[r].ans=f[l-1].ans;
		}
		else if (f[l-1].mx+1==f[r].mx)
		{
			f[r].ans=(f[r].ans+f[l-1].ans)%Mod;
		}
	}
	/*
	for (int i=1;i<=n;i++)
	{
		printf("%d %d %d\n",i,f[i].mx,f[i].ans);
	}
	*/
	if (f[n].mx==0)
	{
		puts("-1");
		return 0;
	}
	printf("%d %d\n",f[n].mx,f[n].ans);
	return 0;
}
