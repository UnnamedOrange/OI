#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 100005, S = 7776, P = 1000000007;
int n, a, b, x[N], mx, pw[10], dpa[S], dpb[S];
int cnt_fi, cnt_se, cnt_a, cnt_b;

int getdigit(int x, int p){
	return x / pw[p - 1] % 6;
}
void debug(int x){
	for(int i = 1; i <= n; i++) printf("%d ", getdigit(x, i));
}
void solve1(){
	pw[0] = 1;
	for(int i = 1; i <= 6; i++)
		pw[i] = pw[i - 1] * 6;
	int st = 0;
	for(int i = n; i; i--)
		st = st * 6 + x[i];
	for(int i = 0; i <= st; i++){
		for(int j = 1; j <= n; j++){
			if(getdigit(i, j) >= a)
				dpa[i] |= !dpb[i - a * pw[j - 1]];
			if(getdigit(i, j) >= b)
				dpb[i] |= !dpa[i - b * pw[j - 1]];
		}
	}
	for(int i = 0; i < (1 << n); i++){
		int st = 0;
		for(int j = n; j; j--){
			st *= 6;
			if((i >> (j - 1)) & 1)
				st += x[j];
		}
		if(dpa[st] && dpb[st]) cnt_fi++;
		else if(!dpa[st] && !dpb[st]) cnt_se++;
		else if(dpa[st] && !dpb[st]) cnt_a++;
		else cnt_b++;
	}
	printf("%d %d %d %d\n", cnt_a, cnt_b, cnt_fi, cnt_se);
}
ll qpow(ll a, ll x){
	ll ret = 1;
	while(x){
		if(x & 1) ret = ret * a % P;
		a = a * a % P;
		x >>= 1;
	}
	return ret;
}

int main(){
	
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	
	read(n), read(a), read(b);
	for(int i = 1; i <= n; i++) 
		read(x[i]), mx = max(mx, x[i]);
	if(n <= 5 && mx <= 5){
		solve1();
		return 0;
	}
	else if(a == b){
		ll tmp = qpow(2, (n - 1));
		if(a >= mx) printf("0 0 %lld %lld\n", tmp, tmp);
		else printf("0 0 0 %lld\n", tmp * 2 % P);
	}
	
	return 0;
}
/*
2 2 3
2 3
*/
