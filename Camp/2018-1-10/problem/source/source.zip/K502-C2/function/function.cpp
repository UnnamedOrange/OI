#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long

using namespace std;

const int M = (int) 1e6 + 5;

ll sum[M];
bool mark[M];
int prime[M], sz, mu[M], d[M], n, summu[M];

void Init() {
	mu[1] = 1;
	for (int i = 2; i < M; i++) {
		if (!mark[i]) prime[++sz] = i, mu[i] = -1;
		for (int j = 1; j <= sz && prime[j] * i < M; j++) {
			mark[prime[j] * i] = true;
			if (i % prime[j] == 0) {
				mu[prime[j] * i] = 0;
				break;
			} else mu[prime[j] * i] = mu[i] * mu[prime[j]];
		}
	}
	for (int i = 1; i < M; i++)
		for (int j = i; j < M; j += i)
			d[j]++;
//	static int g[M];
//	int T = 20;
//	for (int i = 1; i <= T; i++) {
////		int rs = mu[i];
////		for (int j = 2; j <= i; j++)
////			if (i % j == 0) rs -= d[j] * d[j] * g[i / j];
////		g[i] = rs;
////		printf("i = %d g = %d\n", i, g[i]);
//		int rs = 0;
//		for (int j = 1; j <= i; j++)
//			if (i % j == 0) rs += d[i / j] * d[i / j] * j * mu[j];
//		printf("i = %d g = %d\n", i, rs);
//	}
//	for (int j = 1; j <= T; j++)
//		for (int k = 1; k <= T; k++) {
//			bool f = true;
//			for (int t = 2; t <= min(j, k); t++)
//				if (j % t == 0 && k % t == 0) f = false;
//			if (f && j * k <= T) printf("j = %d k = %d %d %d\n", j, k, g[j] * g[k], g[j * k]);
//		}
	for (int i = 1; i < M; i++) {
		sum[i] = sum[i - 1] + d[i] * d[i];
		summu[i] = summu[i - 1] + mu[i];
	}
}

namespace Subtask1 {
	
	void solve() {
		ll ans = 0;
		for (int i = 1; i <= n; i++) {
			int nxt = n / (n / i);
			ans += (sum[nxt] - sum[i - 1]) * summu[n / i];
			i = nxt;
		}
		cout << ans << endl;
	}
	
}

int main() {
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	Init();
	int T; scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		if (n <= (int) 1e6) Subtask1::solve();
	}
	return 0;
}
