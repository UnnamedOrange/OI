#include<bits/stdc++.h>
using namespace std;

int input(int x,int y)
{
	int a=0;
	while(x%4==y%4) x/=4,y/=4,a++;
	return a*4+x%4+1;
}

bool check(int x,int h)
{
	h--;
	int a=h/4,b=h%4;
	while(a--) x/=4;
	return x%4==b;
}

int main()
{
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	
	int i,n,T,type,x,y;
	
	scanf("%d%d%d",&type,&n,&T);
	for(i=0;i<T;i++)
	{
		scanf("%d%d",&x,&y);
		if(type==1) cout<<input(x,y)<<endl;
		else if(check(x,y)) printf("yes\n");
		else printf("no\n");
	}
	
	return 0;
}
