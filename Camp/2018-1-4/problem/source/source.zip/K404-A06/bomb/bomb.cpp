#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <iostream>
using namespace std;

const int Maxn = 1000010, Maxm = 1000010;

int n, m;

struct edge { int to; edge *next; };

#define edge_for(G, it, x) for(edge *(it) = (G).last[(x)]; (it); (it) = (it)->next)

struct graph {
	edge e[Maxm], *last[Maxn], *et;
	int deg[Maxn];
	graph() { et = e; }
	void add(int u, int v) { *++et = (edge) {v, last[u]}, last[u] = et; deg[v]++; }
} G, T;

int cnt[Maxn];

int dfn[Maxn], ck, low[Maxn], stk[Maxn], in[Maxn], top, scc, be[Maxn];

void tarjan(int u) {
	in[stk[++top] = u] = 1;
	low[u] = dfn[u] = ++ck;
	edge_for(G, it, u)
		if(!dfn[it->to]) {
			tarjan(it->to);
			low[u] = min(low[u], low[it->to]);
		} else if(in[it->to])
			low[u] = min(low[u], dfn[it->to]);
	if(low[u] == dfn[u]) {
		int v; ++scc;
		do {
			v = stk[top--];
			in[v] = 0;
			be[v] = scc;
			++cnt[scc];
			//cerr << "x : " << v << " in scc : " << scc << endl;
		} while(v != u);
	}
}

void build() {
	for(int i = 1; i <= n; ++i)
		if(!dfn[i]) tarjan(i);
	for(int i = 1; i <= n; ++i)
		edge_for(G, it, i) {
			if(be[i] != be[it->to]) {
				T.add(be[i], be[it->to]);
			}
		} 
	n = scc;
	//cerr << "scc = " << n << endl;
}

int f[Maxn];

int bfs() {
	static int q[Maxn]; int l = 0, r = 0;
	for(int i = 1; i <= n; ++i)
		if(!T.deg[i]) q[r++] = i;
	while(l < r) {
		int u = q[l++]; f[u] += cnt[u];
		edge_for(T, it, u) {
			T.deg[it->to]--;
			f[it->to] = max(f[it->to], f[u]);
			if(!T.deg[it->to]) q[r++] = it->to;
		}
	}
	int ans = 0;
	for(int i = 1; i <= n; ++i)
		ans = max(ans, f[i]);
	return ans;
}

int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; ++i) {
		int u, v;
		scanf("%d%d", &u, &v);
		if(u != v) G.add(u, v);
	}
	build();
	int ans = bfs();
	printf("%d\n", ans);
	return 0;
}
