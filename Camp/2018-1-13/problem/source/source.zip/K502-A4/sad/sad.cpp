#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=100005,mod=998244353;
void add_mod(int &a,int b){if((a+=b)>=mod)a-=mod;}
int Pow(int x,int y){
	int res=1;
	for(;y;y>>=1,x=(ll)x*x%mod)
		if(y&1)res=(ll)res*x%mod;
	return res;
}
int head[N],deg[N],tot_edge,n;
char str[N];
pii G[N<<1];
struct P_0{
	int X[N],C[N];
	void dfs(int x,int par){
		if(deg[x]==1){
			X[x]=0;C[x]=1;
			return ;
		}
		for(int i=head[x];i;i=G[i].se){
			int y=G[i].fi;
			if(y==par)continue;
			dfs(y,x);
			add_mod(X[x],X[y]);
			add_mod(C[x],C[y]);
		}
		int mom=1,inv=Pow(deg[x],mod-2);
		add_mod(mom,mod-X[x]*(ll)inv%mod);
		C[x]=((ll)C[x]*inv+1)%mod;
		mom=Pow(mom,mod-2);
		X[x]=(ll)inv*mom%mod;
		C[x]=(ll)C[x]*mom%mod;
	}
	void work(){
		dfs(1,0);
		ptn(C[1]);
	}
}P0;
struct P_1{
	int ID[1<<6][6],allc;
	int E[300][300];
	void Guess(){
		int p=1;
		rep(i,1,allc){
			int k=p;
			rep(j,p,allc)if(E[j][i]){
				k=j;
				break;
			}
			if(!E[k][i]){
//				rep(j,1,p)assert(!E[j][i]);
				continue;
			}
			if(k!=p){
				rep(j,0,allc)swap(E[p][j],E[k][j]);
				k=p;
			}
			if(E[p][i]<0)
				rep(j,0,allc)E[p][j]*=-1;
			
			rep(j,1,allc)if(j!=p&&E[j][i]){
				int inv=E[j][i]*(ll)Pow(E[p][i],mod-2)%mod;
				rep(k,0,allc)E[j][k]=(E[j][k]-(ll)inv*E[p][k])%mod;
			}
			++p;
		}
		rep(i,1,allc){
//			rep(j,0,allc)if(i!=j&&j)assert(!E[i][j]);
			if(E[i][i]<0)E[i][i]*=-1,E[i][0]*=-1;
			E[i][0]=(ll)E[i][0]*Pow(E[i][i],mod-2)%mod;
			if(E[i][0]<0)E[i][0]+=mod;
			E[i][i]=1;
		}
	}
	void work(){
		rep(i,0,1<<n)
			rep(j,0,n)ID[i][j]=++allc;
		allc++;
		rep(i,0,n){
			if(deg[i+1]==1){
				rep(j,0,1<<n)E[ID[j][i]][0]=E[ID[j][i]][ID[j][i]]=1;
				continue;
			}
			int inv=Pow(deg[i+1],mod-2);
			rep(j,0,1<<n){
				E[ID[j][i]][ID[j][i]]=-1;
				if((j>>i&1)&&str[i+1]=='0'){
					for(int k=head[i+1];k;k=G[k].se){
						int y=G[k].fi-1;
						add_mod(E[ID[j][i]][ID[j][y]],inv);
					}
				}else {
					E[ID[j][i]][0]=-1;
					for(int k=head[i+1];k;k=G[k].se){
						int y=G[k].fi-1;
						add_mod(E[ID[j][i]][ID[j|(1<<i)][y]],inv);
					}
				}
			}
		}
		Guess();
		ptn(E[ID[0][0]][0]);
	}
}P1;
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	scanf("%d%s",&n,str+1);
	for(int x,y,i=1;i<n;++i){
		rd(x),rd(y);
		++deg[x];++deg[y];
		G[++tot_edge]=pii(y,head[x]);head[x]=tot_edge;
		G[++tot_edge]=pii(x,head[y]);head[y]=tot_edge;
	}
	bool flag=true;
	rep(i,1,n+1)if(deg[i]!=1&&str[i]=='0'){flag=false;break;}
	if(0);
	else if(flag)P0.work();
	else if(n<=6)P1.work();
	else P0.work();
	return 0;
}
