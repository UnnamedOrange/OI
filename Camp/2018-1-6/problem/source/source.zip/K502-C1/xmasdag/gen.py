import os
import random

N = random.randint(2000, 2000)
M = random.randint(5000, 5000)
K = random.randint(1, 30)

f = open("xmasdag.in", "w")
f.write(str(N) + ' ' + str(M) + ' ' + str(K) + '\n')

for i in range(M):
	u = random.randint(1, N - 1)
	v = random.randint(u + 1, N)
	f.write(str(u) + ' ' + str(v) + '\n')
f.close()