#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
int n,x,y,rot,anss;
int dp[maxn],a[maxn],b[maxn],siz[maxn],tot[maxn],c[maxn];
int f1[maxn],f2[maxn],f3[maxn],r;
int i,j,k;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void work(int x,int fa){
	int i=f1[x];
	siz[x]=1;
	tot[x]=a[x];
	while (i!=0){
		if (f2[i]!=fa){
			work(f2[i],x);
			siz[x]=siz[x]+siz[f2[i]];
			tot[x]=tot[x]+tot[f2[i]];
		}
		i=f3[i];
	}
}
void dfs(int x,int fa){
	int i,j,ans=tot[x],r=0,t1=0,t2=0,t3=0,t4=0;
	i=f1[x];
	while (i!=0){
		if (f2[i]!=fa){
			dfs(f2[i],x);
		}
		i=f3[i];
	}
	i=f1[x];
	r=0;
	while (i!=0){
		if (f2[i]!=fa){
			t1=0;
			for (j=1;j<=r;j++){
				t1=t1+tot[c[j]];
			}
			t2=0; t3=0; t4=0;
			for (j=0;j<=r;j++){
				if (t2<t1*siz[f2[i]]+t4*tot[f2[i]]+dp[f2[i]]){
					t2=t1*siz[f2[i]]+t4*tot[f2[i]]+dp[f2[i]]; t3=j;
				}
				if (j!=r){
					t1=t1-tot[c[j+1]];
					t4=t4+siz[c[j+1]];
				}
			}
			ans=ans+t2;
			for (j=r;j>=t3+1;j--){
				c[j+1]=c[j];
			}
			c[t3+1]=f2[i]; r++;
		}
		i=f3[i];
	}
	dp[x]=ans;
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	n=read();
	memset(f1,0,sizeof(f1)); r=0;
	for (i=1;i<=n-1;i++){
		x=read(); y=read();
		r++; f2[r]=x; f3[r]=f1[y]; f1[y]=r;
		r++; f2[r]=y; f3[r]=f1[x]; f1[x]=r;
	}
	for (i=1;i<=n;i++){
		a[i]=read(); b[i]=read();
	}
	anss=0;
	for (i=1;i<=n;i++){
		if (b[i]==1){
			rot=i;
			memset(siz,0,sizeof(siz));
			memset(tot,0,sizeof(tot));
			work(rot,0);
			memset(dp,0,sizeof(dp));
			dfs(rot,0);
			anss=max(anss,dp[rot]);
		}
	}
	printf("%d\n",anss);
	return 0;
}
