#include <bits/stdc++.h>
using namespace std;

const int Maxn = 22, MaxS = (1<<Maxn)+10;
struct Edge {
	int v;
	Edge *nxt;
} pool[Maxn*2], *tree[Maxn], *tail = pool;
inline void addedge(const int &u, const int &v) {
	tail->v = v;
	tail->nxt = tree[u], tree[u] = tail++;
}

int n, w[Maxn], rt[Maxn], dp[MaxS], q[MaxS];
bool visited[MaxS];

int main() {
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1, x, y; i < n; ++i) {
		scanf("%d%d", &x, &y);
		addedge(x, y), addedge(y, x);
	}
	for (int i = 1; i <= n; ++i) {
		scanf("%d%d", &w[i], &rt[i]);
	}
	int ans = 0;
	for (int i = 1; i <= n; ++i) {
		if (rt[i]) {
			memset(visited, false, sizeof(visited));
			memset(dp, 0, sizeof(dp));
			q[1] = 1<<i, dp[1<<i] = w[i];
			for (int l = 1, r = 1; l <= r; ++l) {
				for (int j = 1; j <= n; ++j) {
					if (q[l]>>j&1) {
						for (Edge *p = tree[j]; p; p = p->nxt) {
							if (!(q[l]>>p->v&1)) {
								int nxtS = q[l]|(1<<p->v);
								dp[nxtS] = max(dp[nxtS], dp[q[l]]+w[p->v]*__builtin_popcount(nxtS));
								if (!visited[nxtS]) {
									visited[nxtS] = true, q[++r] = nxtS;
								}
							}
						}
					}
				}
			}
			ans = max(ans, *max_element(dp, dp+MaxS));
		}
	}
	printf("%d\n", ans);
	return 0;
}
