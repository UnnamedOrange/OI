#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <queue>

using namespace std;
typedef long long ll;
const ll mod = 1e9 + 7;


int n, a, b;
int d[100005];
int c1, c2;
ll qpow(ll x, ll y){
	ll ret = 1;
	for(; y; y >>= 1, x = x * x % mod){
		if(y & 1) ret = ret * x % mod; 
	}
	return ret;
}
int main(){
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	scanf("%d%d%d", &n, &a, &b);
	for(int i = 1; i <= n; i ++){
		scanf("%d", &d[i]);
		d[i] /= a;
		if(d[i] % 2 == 0) c2 ++;
		else c1 ++;
	}
	if(c1 == 0){
		printf("0 0 0 %lld", qpow(2, c2));
	}else{
		printf("0 0 %lld %lld", qpow(2, c2 + c1 - 1), qpow(2, c2 + c1 - 1));
	}
	return 0;
}
