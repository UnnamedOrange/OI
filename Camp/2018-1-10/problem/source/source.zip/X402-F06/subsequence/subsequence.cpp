#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmax(int &x,int y){return (y>x)?(x=y,1):0;}
const int maxn=4000+10;
int a[maxn],b[maxn],c[maxn];
int n,m,k;
int f[maxn][maxn];
bool check(int len){
	REP(i,1,n)
		REP(j,1,len){
			f[i][j]=max(f[i-1][j],f[i][j-1]);
			if(a[i]==c[j]) chkmax(f[i][j],f[i-1][j-1]+1);
		}
	if(f[n][len]==len) return 0;
	REP(i,1,m)
		REP(j,1,len){
			f[i][j]=max(f[i-1][j],f[i][j-1]);
			if(b[i]==c[j]) chkmax(f[i][j],f[i-1][j-1]+1);
		}
	if(f[m][len]==len) return 0;
	return 1;
}
int dp[300+10][300+10][2];
ll C(int x,int y){
	if(y>x) return 0;
	ll num=1,Min=min(y,x-y);
	REP(i,max(y,x-y)+1,x){
		num*=i;
		if(Min && num%Min==0) num/=Min,--Min;
	}
	return num;
}
int DP(int x){
	REP(i,1,n)
		REP(j,1,m){
			dp[i][j][x]=dp[i-1][j][x^1]+dp[i][j-1][x^1];
			if(a[i]==b[j]) dp[i][j][x]+=dp[i-1][j-1][x];
		}
	return dp[n][m][x];
}
bool find_dp(int len){
	ll num=1;
	REP(i,1,len) num*=k;
	num-=C(n,len)+C(m,len);
	if(num>0) return 1;
	num+=DP(len&1);
	return num>0;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
#endif
	n=read(),m=read(),k=read();	
	if(k==2 && n<=18 && m<=18){
		REP(i,1,n) a[i]=read();
		REP(i,1,m) b[i]=read();
		REP(l,1,max(n,m)){
			REP(i,0,(1<<l)-1){
				REP(j,1,l)
					if(i&(1<<j-1)) c[j]=2;
					else c[j]=1;
				if(check(l)){
					printf("%d\n",l);
					return 0;
				}
			}
		}
	}
	REP(i,1,n) a[i]=read();
	REP(i,1,m) b[i]=read();
	REP(l,1,max(n,m)){
		if(find_dp(l)){
			printf("%d\n",l);
			return 0;
		}
	}
	return 0;
}
