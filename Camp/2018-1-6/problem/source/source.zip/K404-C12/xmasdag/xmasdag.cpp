#include <iostream>
#include <cstring>
#include <cstdio>
#define MOD 998244353
using namespace std; 
typedef long long ll; 
int C[505][505], dp[100005][35], que[100005];
int lst[100005], to[200005], pre[200005], tot, deg[100005]; 
inline void upd(int &x, int y)
{
	x += y; 
	if (x >= MOD)
		x -= MOD; 
}
namespace brute
{
	int dp[2005][5005]; 
	inline ll quick_pow(ll a, int n)
	{
		ll res = 1; 
		while (n)
		{
			if (n & 1)
				res = res * a % MOD; 
			a = a * a % MOD; 
			n >>= 1; 
		}
		return res; 
	}
	inline void solve(int n, int m, int k)
	{
		int he = 0, ta = 0; 
		que[ta++] = 0; 
		dp[0][0] = 1; 
		while (he < ta)
		{
			int u = que[he++]; 
			for (int i = lst[u]; ~i; i = pre[i])
			{
				int v = to[i]; 
				for (int j = 0; j <= m; j++)
					upd(dp[v][j + 1], dp[u][j]); 
				if (!--deg[v])
					que[ta++] = v; 
			}
		}
		for (int i = 0; i < n; i++)
		{
			int ans = 0; 
			for (int j = 1; j <= m; j++)
				upd(ans, quick_pow(j, k) * dp[i][j] % MOD); 
			printf("%d\n", ans); 
		}
	}
}
inline int getint()
{
	int ch = getchar(), res = 0; 
	for (; ch < 48; ch = getchar()); 
	for (; ch >= 48; ch = getchar())
		res = res * 10 + ch - 48; 
	return res; 
}
inline void add_edge(int u, int v)
{
	to[tot] = v; 
	pre[tot] = lst[u]; 
	deg[v]++; 
	lst[u] = tot++; 
}
int main()
{
	freopen("xmasdag.in", "r", stdin); 
	freopen("xmasdag.out", "wt", stdout); 
	memset(lst, -1, sizeof(lst)); 
	int n = getint(), m = getint(), k = getint();
	for (int i = 0; i < m; i++)
	{
		int u = getint(), v = getint();
		add_edge(--u, --v); 
	}
	if (k > 30)
	{
		brute::solve(n, m, k); 
		return 0; 
	}
	for (int i = 0; i < 505; i++)
	{
		C[i][0] = 1; 
		for (int j = 1; j <= i; j++)
		{
			C[i][j] = C[i - 1][j]; 
			upd(C[i][j], C[i - 1][j - 1]); 
		}
	}
	int he = 0, ta = 0; 
	que[ta++] = 0; 
	dp[0][0] = 1; 
	while (he < ta)
	{
		int u = que[he++];
		for (int i = lst[u]; ~i; i = pre[i])
		{
			int v = to[i]; 
			for (int t = 0; t <= k; t++)
			{
				if (!dp[u][t])
					continue; 
				for (int y = 0; y + t <= k; y++)
					upd(dp[v][y + t], (ll)C[y + t][y] * dp[u][t] % MOD); 
			}
			if (!--deg[v])
				que[ta++] = v; 
		}
	}
	for (int i = 0; i < n; i++)
		printf("%d\n", dp[i][k]); 
	return 0; 
}

