#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int N=29;
const int edge=6;

int n,ans;
int a[N],b[N];

inline int mov1()
{
	int ret=0;
	for(int i=2;i<=n;i++)
		if(a[i-1]<a[i])
			ret++;
		else
			ret--;
	if(ret<0)ret=-ret+1;
	return ret;
}

inline int mov2()
{
	int ret=0;
	a[n+1]=n+1;
	for(int i=2;i<=n+1;i++)
		if(a[i-1]!=a[i]-1 && a[i-1]!=a[i]+1)
			ret++;
	return abs(ret);
}

inline bool dfss(int dep)
{
	if(dep==0)
	{
		for(int i=1;i<=n;i++)
			if(a[i]!=i)
				return false;
		return true;
	}

	if(mov2()>dep)return false;
	//if(mov1()>dep)return false;
	for(int i=1;i<=n;i++)
	{
		reverse(a+1,a+i+1);
		if(dfss(dep-1))
			return true;
		reverse(a+1,a+i+1);
	}
	return false;
}

int mian()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);

	for(ans=0;;ans++)
		if(dfss(ans))
			break;
	printf("%d\n",ans);
	return 0;
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequences.out","w",stdout);

	int T;
	scanf("%d",&T);
	while(T--)
		mian();

	return 0;
}

