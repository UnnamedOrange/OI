#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0*clock()/CLOCKS_PER_SEC << std::endl
#define _X first
#define _Y second

template <class T> inline T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = 1;
	for(;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 5e5 + 10, mod = 1e9 + 7;

void add(int &a, int b)
{
	a += b; if(a >= mod) a -= mod;
}

int n, m, tot, R[N], x[N];

struct Interval
{
	int l, r;
	bool operator < (const Interval& rhs)const
	{
		return l == rhs.l? r > rhs.r : l < rhs.l;
	}
}P[N];

namespace bf_dp
{
	const int N = 5e3 + 10;

	int dp[N][N];

	void main()
	{
		dp[0][0] = 1;
		for(int i = 1; i <= n; ++i){
			int r = std::lower_bound(R + 1, R + tot + 1, P[i].r) - R;
			for(int _r = 0; _r <= tot; ++_r) dp[i][_r] = dp[i-1][_r];
			for(int _r = r+1; _r <= tot; ++_r) dp[i][_r] = dp[i][_r] * 2LL % mod;

			int key = std::lower_bound(x + 1, x + m + 1, P[i].l) - x - 1;
			int l = std::lower_bound(R, R + tot + 1, x[key]) - R;

			for(int _r = l; _r <= r; ++_r) add(dp[i][r], dp[i-1][_r]);
		}

		int ans = 0;
		int p = std::lower_bound(R + 1, R + tot + 1, x[m]) - R;
		for(int i = p; i <= tot; ++i) add(ans, dp[n][i]);
		printf("%d\n", ans);
	}
}

namespace SEGT
{
	#define lc (h << 1)
	#define rc (lc | 1)

	const int T = N << 2;

	int sum[T], mul[T];

	void clear()
	{
		for(int i = 0; i < T; ++i) 
			sum[i] = 0, mul[i] = 1;
	}

	inline void push_down(int h)
	{
		if(mul[h] != 1){
			register int &c = mul[h];
			sum[lc] = 1LL * sum[lc] * c % mod;
			sum[rc] = 1LL * sum[rc] * c % mod;
			mul[lc] = 1LL * mul[lc] * c % mod;
			mul[rc] = 1LL * mul[rc] * c % mod;
			c = 1;
		}
	}

	void modify(int h, int l, int r, int u, int x)
	{
		if(l == r) add(sum[h], x);
		else{
			push_down(h);

			int mid = (l + r) >> 1;
			if(u <= mid) modify(lc, l, mid, u, x);
			else modify(rc, mid + 1, r, u, x);

			sum[h] = (sum[lc] + sum[rc]) % mod;
		}
	}

	void multy(int h, int l, int r, int ql, int qr)
	{
		if(ql <= l && r <= qr){
			sum[h] = 2LL * sum[h] % mod;
			mul[h] = 2LL * mul[h] % mod;
		}else
		{
			push_down(h);

			int mid = (l + r) >> 1;
			if(ql <= mid) multy(lc, l, mid, ql, qr);
			if(qr > mid) multy(rc, mid + 1, r, ql, qr);

			sum[h] = (sum[lc] + sum[rc]) % mod;
		}
	}

	int query(int h, int l, int r, int ql, int qr)
	{
		if(ql <= l && r <= qr) return sum[h];
		else
		{
			push_down(h);

			int mid = (l + r) >> 1, ret = 0;
			if(ql <= mid) ret = query(lc, l, mid, ql, qr);
			if(qr > mid) add(ret, query(rc, mid + 1, r, ql, qr));

			return ret;
		}
	}
	
	#undef lc
	#undef rc
}

int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);

	read(n), read(m);
	for(int i = 1; i <= n; ++i) read(P[i].l), R[i] = read(P[i].r);
	for(int i = 1; i <= m; ++i) read(x[i]);

	std::sort(x + 1, x + m + 1);
	std::sort(R + 1, R + n + 1);
	std::sort(P + 1, P + n + 1);
	m = std::unique(x + 1, x + m + 1) - x - 1;
	tot = std::unique(R + 1, R + n + 1) - R - 1;

//  SEGT From 0 to tot;
//	bf_dp::dp[0][0] = 1;
	SEGT::clear();
	SEGT::modify(1, 0, tot, 0, 1);
	for(int i = 1; i <= n; ++i){
		int r = std::lower_bound(R + 1, R + tot + 1, P[i].r) - R;
//		for(int _r = 0; _r <= tot; ++_r) bf_dp::dp[i][_r] = bf_dp::dp[i-1][_r];
//		for(int _r = r+1; _r <= tot; ++_r) bf_dp::dp[i][_r] = bf_dp::dp[i][_r] * 2LL % mod;
		if(r < tot){
			SEGT::multy(1, 0, tot, r+1, tot);
	//		std::cerr << bf_dp::dp[i][tot] << " " << SEGT::query(1, 0, tot, tot, tot) << std::endl;
		}

		int key = std::lower_bound(x + 1, x + m + 1, P[i].l) - x - 1;
		int l = std::lower_bound(R, R + tot + 1, x[key]) - R;

//		for(int _r = l; _r <= r; ++_r) add(bf_dp::dp[i][r], bf_dp::dp[i-1][_r]);
		int addition = SEGT::query(1, 0, tot, l, r);
		SEGT::modify(1, 0, tot, r, addition);
//		std::cerr << SEGT::query(1, 0, tot, r, r) << " " << bf_dp::dp[i][r] << std::endl;
	}

	int p = std::lower_bound(R + 1, R + tot + 1, x[m]) - R;
	int ans = SEGT::query(1, 0, tot, p, tot);
	printf("%d\n", ans);
//	int check = 0;
//	for(int i = p; i <= tot; ++i){
//		std::cerr << bf_dp::dp[n][i] << " " << SEGT::query(1, 0, tot, i, i) << std::endl;
//		add(check, bf_dp::dp[n][i]);
//	}
//	std::cerr << check << " " << ans << std::endl;
//	cerr_clock();

	return 0;
}
