/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 5000000 + 10;
const int MAXX = 1000000 + 10;

int prime_cnt, t, x;
long long prime[MAXN], mul[MAXN], mul_a1[MAXN], cnt[MAXN], min_cnt[MAXN];
long long sum[MAXN];
bool not_prime[MAXN];

inline void seive(int n) {
	not_prime[1] = true, sum[1] = 1;
	for (int i = 2; i < n; ++i) {
		if (!not_prime[i]) {
			prime[++prime_cnt] = i, min_cnt[i] = 1, sum[i] = 3, mul[i] = i;
		}
		for (int j = 1; j <= prime_cnt && prime[j] * i < n; ++j) {
			int cur = prime[j] * i;
			if (i % prime[j]) {
				not_prime[cur] = true, min_cnt[cur] = 1;
				sum[cur] = sum[i] * 3, mul[cur] = prime[j];
			} else {
				min_cnt[cur] = min_cnt[i] + 1, mul[cur] = mul[i] * prime[j];
				sum[cur] = sum[i] + sum[cur / mul[cur]] * 2;
				not_prime[cur] = true;
				break ;
			}
		}
	}
	for (int i = 2; i < n; ++i) sum[i] += sum[i - 1];
}

int main() {
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	R(t), seive(MAXN);
	while (t--) R(x), W(sum[x]), write_char('\n');
	flush();
	return 0; 
}
