#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
int n=5000,q=5000;
int main(){
    freopen("xmastree1.in","w",stdout);
    srand(time(0));
    printf("%d %d 0\n",n,q);
    for(int i=1;i<=n;i++) printf("%d ",rand()%n+1);
    for(int i=2;i<=n;i++) printf("%d %d\n",rand()%(i-1)+1,i);
    for(int i=1;i<=q;i++){
        int op=rand()%2;
        if(op){
            int l=rand()%n+1,r=l+rand()%(n-l+1);
            printf("1 %d %d %d\n",rand()%n+1,l,r);
        }
        else printf("2 %d %d\n",rand()%n+1,rand()%n+1);
    }
    return 0;
}
