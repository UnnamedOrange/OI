#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48 && c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}

int main()
{
	freopen("subquence.in","r",stdin);
	freopen("subquence.out","w",stdout);
	n=read(); m=read(); k=read()
	for(int i=1; i<=n; ++i)a[i]=read();
	for(int j=1; j<=m; ++j)b[j]=read();
	if(n<=18)
	{
		dfs(1);
		exit(0); //bz
//		return 0; //bz
	}
	for(int i=1; i<=n; ++i)++o[a[i]];
	for(int i=1; i<=m; ++i)++p[b[i]];
	mi=n+1;
	for(int i=1; i<=k; ++i)
}
