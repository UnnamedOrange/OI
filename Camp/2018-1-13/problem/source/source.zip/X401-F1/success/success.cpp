success#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=110,MOD=1000000007;
int s,t,n,m,f[MAXN][MAXN];
void md(int &x,int y)
{
	x+=y;
	while(x>=MOD)x-=MOD;
	return;
}
int cal(int x,int y)
{
	if(!x||!y)return 1;
	if(f[x][y])return f[x][y];
	int ret=0;
	if(y<=m-n)
		for(int i=0;i<=x;++i)md(ret,cal(x-i,y-1));
	else 
		for(int i=0;i<t;++i)md(ret,cal(x-i,y-1));
	return f[x][y]=ret;
}
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	s=read();t=read();n=read();m=read();
	s-=m;
	printf("%d\n",cal(s,m));
	return 0;
}
