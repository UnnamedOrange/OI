#include <cstdio>
#include <queue>
#include <algorithm>
#define F(x,y,z) for (x=y;x<=z;++x)
using namespace std;
int n,m;
int a[100010];
int f[100010][2];

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int x,y,z,i,j,k;
	scanf("%d%d%d",&n,&x,&y);
	if (x==2 && y==3) 
	{
		printf("2 0 1 1");return 0;
	}
	F(i,1,n)scanf("%d",&a[i]),a[i]/=x;
	f[0][0]=1;
	F(i,1,n)
	{
		f[i][0]=f[i-1][a[i]&1]+f[i-1][0];
		f[i][1]=f[i-1][(a[i]+1)&1]+f[i-1][1];
	}
	
	printf("%d %d %d %d\n",0,0,f[n][1],f[n][0]);
	return 0;
}

