//© 2018, Jzengm/Zeng Xiangru, All Rights Reserved
#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int mxn=1<<5;

int n;

In int check(int* a)
{
    for(Rg int i=n;; --i)
        if(!i || a[i]!=i) Re
        n-i;
}

In void rev(int* a, int m)
{
    inc(1, i, m/2+1)
        swap(a[i], a[m-i+1]);
}

int a[mxn], ans;

In int guess()
{
    Rg int r=0;
    inc(1, i, n-1)
        if(a[i]==a[i+1]-1 && a[i+1]==a[i+2]-1 || a[i]==a[i+1]+1 && a[i+1]==a[i+2]+1)
            ++r;
//    printf("guess: %d\n", r);
    Re r;
}

void DFS(int step)
{
    if(step>=ans) Re;
    Rg int x=check(a), y=guess();
    if(x==n)
        ans=step;
    inc(2, i, n-x+1)
    {
        rev(a, i);
        if(y<=guess())
            DFS(step+1);
        rev(a, i);
    }
}

In int greed()
{
    St int b[mxn];
    memcpy(b, a, sizeof a);
    for(Rg int cnt=0;;)
    {
        Rg int x=check(b);
        if(x==n) Re cnt;
        Rg int y;
        inc(1, i, n+1)
            if(b[i]==n-x)
                y=i;
        if(y>1)
            rev(b, y), ++cnt;
        rev(b, n-x), ++cnt;
//        inc(1, i, n+1)
//            printf("%d ", b[i]);
//        puts("");
    }
}

int main()
{
    freopen("sequence.in", "r", stdin);
    freopen("sequence.out", "w", stdout);
    St int t;
    for(scanf("%d", &t); t--;)
    {
        scanf("%d", &n);
        inc(1, i, n+1)
            scanf("%d", a+i);
        ans=greed();
//        printf("ans: %d\n", ans);
        DFS(0);
        printf("%d\n", ans);
    }
    Re 0;
}
