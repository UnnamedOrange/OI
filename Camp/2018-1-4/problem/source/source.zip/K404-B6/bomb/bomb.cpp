#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 1000001
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define add_edge2(u,v) nxt2[++cnt2]=head2[u],head2[u]=cnt2,to2[cnt2]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
int n,m,ti,kind,top,st[N],dfn[N],low[N],sy[N],siz[N],f[N];
int cnt,head[N],nxt[N],to[N];
int cnt2,head2[N],nxt2[N],to2[N];
bool on[N];
void tarjan(int u)
{
	dfn[u]=low[u]=++ti;
	st[++top]=u;on[u]=1;
	for(int i=head[u],v;i;i=nxt[i])
		if(!dfn[v=to[i]])
		{
			tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(on[v])
			low[u]=min(low[u],dfn[v]);
	if(dfn[u] == low[u])
	{
		++kind;
		do
		{
			++siz[kind];
			sy[st[top]]=kind;
			on[st[top]]=0;
		}while(st[top--]!=u);	
	}
}
int dfs(int u)
{
	if(f[u])return f[u];
	for(int i=head2[u];i;i=nxt2[i])
		f[u]=max(f[u],dfs(to2[i]));
	return f[u]+=siz[u];
}
int main()
{
	open(bomb);
	re(n),re(m);
	for(int i=1,u,v;i<=m;++i)
	{
		re(u),re(v);
		add_edge(u,v);
	}
	for(int i=1;i<=n;++i)
		if(!dfn[i])
			tarjan(i);
	for(int i=1;i<=n;++i)
		for(int j=head[i];j;j=nxt[j])
			if(sy[i] != sy[to[j]])
				add_edge2(sy[i],sy[to[j]]);
	int ans=0;
	for(int i=1;i<=kind;++i)
		ans=max(ans,dfs(i));
	printf("%d\n",ans);
}
