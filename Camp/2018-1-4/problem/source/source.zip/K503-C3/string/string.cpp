#include <bits/stdc++.h>
#define N 10
#define M 110
#define L 510
#define P 998244353
using namespace std;
int n,m,g[N][M][2],a[N][M],b[M],s[M],ans(0),f[2][M][M];
char z[N][M];

void pre(){
	int fl;
	for (int i=1;i<=n;i++){
		for (int j=0;j<=a[i][0];j++){
			g[i][j][a[i][j+1]]=j+1;
			g[i][j][a[i][j+1]^1]=0;
			b[j+1]=a[i][j+1]^1;
			for (int k=2;k<=j+1;k++){
				fl=0;
				for (int l=1;!fl && l<=j+2-k;l++)
					if (b[k]!=a[i][l])
						fl=1;
				if (!fl){
					g[i][j][a[i][j+1]^1]=j+2-k;
					break;
				}
			}
			b[j+1]=a[i][j+1];
		}
	}
}


void search(int dep){
	if (dep>m){
		int fl,fl_;
		for (int i=m+1;i<=2*m;i++)
			s[i]=s[2*m-i+1]^1;
		for (int i=1;i<=n;i++){
			fl=0;
			for (int j=1;j<=2*m-a[i][0]+1 && !fl;j++){
				fl_=0;
				for (int k=1;k<=a[i][0] && !fl_;k++)
					if (a[i][k]!=s[j+k-1])
						fl_=1;
				if (!fl_)
					fl=1;
			}
			if (!fl) return;
		}
		ans++;
		return;
	}
	s[dep]=1;
	search(dep+1);
	s[dep]=0;
	search(dep+1);
}

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++){
		scanf(" %s",z[i]);
		a[i][0]=strlen(z[i]);
		for (int j=1;j<=a[i][0];j++)
			a[i][j]=z[i][j-1]-'0';
	}
	if (m<=15){
		search(1);
		printf("%d\n",ans);
		return 0;
	}
	
	return 0;
}
