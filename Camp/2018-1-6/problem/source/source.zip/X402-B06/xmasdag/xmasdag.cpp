#include<bits/stdc++.h>
#include<cctype>
#define For(i,a,b) for(i=(a),i##end=(b);i<=i##end;++i)
#define Forward(i,a,b) for(i=(a),i##end=(b);i>=i##end;--i)
#define Rep(i,a,b) for(register int i=(a),i##end=(b);i<=i##end;++i)
#define Repe(i,a,b) for(register int i=(a),i##end=(b);i>=i##end;--i)
using namespace std;
template<typename T>inline void read(T &x){
	T s=0,f=1;char k=getchar();
	while(!isdigit(k)&&k^'-')k=getchar();
	if(!isdigit(k)){f=-1;k=getchar();}
	while(isdigit(k)){s=s*10+(k^48);k=getchar();}
	x=s*f;
}
void file(void){
	#ifndef ONLINE_JUDGE
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	#endif
}
static int n,m,k;
const int MAXN=1e5+7;
static struct edge
{
    int v,next;
}p[MAXN];
static int head[MAXN],e,in[MAXN];
static long long mod=998244353ll;
inline void add(int u,int v){p[++e].v=v;p[e].next=head[u];head[u]=e;}
void init()
{
    read(n);read(m);read(k);
    static int u,v;
    Rep(i,1,m)read(u),read(v),add(u,v),++in[v];
}
inline long long power(long long u,long long v,long long mod)
{
    static long long sum;
    for(sum=1;v;v>>=1,(u*=u)%=mod)if(v&1)
        (sum*=u)%=mod;
    return sum;
}
namespace Cheat1
{
    static int f[3001][3001];
    void solve()
    {
        f[1][0]=1;
        static int que[3001],h=0,t=0;
        que[++t]=1;
        while(h<t)
        {
            ++h;for(register int v=head[que[h]];v;v=p[v].next)
            {
                Rep(i,1,n-1)f[p[v].v][i]+=f[que[h]][i-1];
                if(!(--in[p[v].v]))que[++t]=p[v].v;
            }
        }
        static long long ans;
        Rep(i,1,n)
        {
            ans=0ll;
            Rep(j,1,n-1)if(f[i][j])(ans+=f[i][j]*power(j,k,mod)%mod)%=mod;
            printf("%lld\n",ans);
        }
    }
}
namespace Cheat2
{
    static int f[MAXN][2],que[MAXN],h=0,t=0;
    void solve()
    {
        f[1][1]=1;
        que[++t]=1;
        while(h<t)
        {
            ++h;
            for(register int v=head[que[h]];v;v=p[v].next)
            {
                (f[p[v].v][1]+=f[que[h]][1])%=mod;
                (f[p[v].v][0]+=f[que[h]][0]+f[que[h]][1])%=mod;
                if(!(--in[p[v].v]))que[++t]=p[v].v;
            }
        }
        Rep(i,1,n)printf("%d\n",f[i][0]);
    }
}
namespace Cheat3
{
    static int f[MAXN][35],que[MAXN],h=0,t=0,C[41][41];
    void predone(int x)
    {
        C[0][0]=1;
        Rep(i,1,x)Rep(j,0,i)
        {
            if(!j||j==i)C[i][j]=1;
            else C[i][j]=C[i-1][j]+C[i-1][j-1];
        }
    }
    void solve()
    {
        predone(k);
        que[++t]=1;
        f[1][0]=1;
        while(h<t)
        {
            static int u;u=que[++h];
            for(register int v=head[que[h]];v;v=p[v].next)
            {
                Rep(i,0,k)Rep(j,0,i)(f[p[v].v][i]+=f[u][j]*C[i][j]%mod)%=mod;
                if(!(--in[p[v].v]))que[++t]=p[v].v;
            }
        }
        Rep(i,1,n)printf("%d\n",f[i][k]);
    }
}
namespace Cheat4
{
    static int f[MAXN][601],que[MAXN],h=0,t=0,C[601][601];
    void predone(int x)
    {
        C[0][0]=1;
        Rep(i,1,x)Rep(j,0,i)
        {
            if(!j||j==i)C[i][j]=1;
            else C[i][j]=C[i-1][j]+C[i-1][j-1];
        }
    }
    void solve()
    {
        predone(k);
        que[++t]=1;
        f[1][0]=1;
        while(h<t)
        {
            static int u;u=que[++h];
            for(register int v=head[que[h]];v;v=p[v].next)
            {
                Rep(i,0,k)Rep(j,0,i)(f[p[v].v][i]+=f[u][j]*C[i][j]%mod)%=mod;
                if(!(--in[p[v].v]))que[++t]=p[v].v;
            }
        }
        Rep(i,1,n)printf("%d\n",f[i][k]);
    }
}
int main(void){
	file();
    init();
    if(n<=2000)Cheat1::solve();
    else if(k==1)Cheat2::solve();
    else if(k<=30)Cheat3::solve();
    else Cheat4::solve();
    return 0;
}

