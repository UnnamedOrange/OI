#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int Mod=998244353; 
struct node{
	int to,next;
}a[200010],s[200010];
int head[100010],fr[100010];
int n,m,k,cnt=0,tot=0;
int p[100010],ans[100010];
int mult(int x,int y){
	x%=Mod;y%=Mod;
	return (int)((long long)x*(long long)y%(long long)Mod);	
}
int add(int x,int y){
	x%=Mod;y%=Mod;
	return ((x+y)%Mod+Mod)%Mod;	
}
int Pow(int x,int y){
	int res=1;
	while (y){
		if (y%2) res=mult(res,x);
		x=mult(x,x);
		y/=2; 	
	}
	return res;
}
void init(int u,int v){
	a[++cnt].to=v;
	a[cnt].next=head[u];
	head[u]=cnt;	
}
void init2(int u,int v){
	s[++tot].to=v;
	s[tot].next=fr[u];
	fr[u]=tot;	
}
void dfs(int x,int t){
	ans[x]=add(ans[x],Pow(t,k));
	for (int i=head[x];i;i=a[i].next)
		dfs(a[i].to,t+1);
}
void solve(int x){
	if (ans[x]) return;
	ans[x]=p[x]=0;
	if (x==1) p[x]=1;
	for (int i=fr[x];i;i=s[i].next){
		int y=s[i].to;
		solve(y);
		ans[x]=add(ans[y],add(ans[x],p[y]));
		p[x]=add(p[x],p[y]);	
	}
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read();m=read();k=read();
	for (int i=1;i<=m;++i){
		int u=read(),v=read();
		init(u,v);
		if (k==1) init2(v,u);	
	}
	if (k==1){
		for (int i=1;i<=n;++i)
			if (!head[i])
				solve(i);
		for (int i=1;i<=n;++i)
			printf("%d\n",ans[i]);
		return 0;
	}
	if (n<=2000){
		dfs(1,0);	
		for (int i=1;i<=n;++i)
			printf("%d\n",ans[i]);
		return 0;
	}
	return 0;
}

