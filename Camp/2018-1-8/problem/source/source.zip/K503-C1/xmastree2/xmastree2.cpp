# include <bits/stdc++.h>
# define 	N 		100010
using namespace std;
struct node{
	int data,next;
}e[N];
int dad[N],head[N],use[N],tag[N],w[N],place,n,ans;
void build(int u, int v){
	e[++place].data=v; e[place].next=head[u]; head[u]=place;
	e[++place].data=u; e[place].next=head[v]; head[v]=place;
}
void dfs(int x, int fa){
	dad[x]=fa;
	for (int ed=head[x]; ed!=0; ed=e[ed].next)
		if (e[ed].data!=fa) dfs(e[ed].data,x);
}
void check(){
	int num=0;
	for (int i=1; i<=n; i++) num=num+w[i]*use[i];
	ans=max(num,ans);
}
void getans(int k){
	if (k>n){
		check();
		return;
	}
	for (int i=1; i<=n; i++){
		if (use[i]==0&&use[dad[i]]!=0){
			use[i]=k;
			getans(k+1);
			use[i]=false;
		}
	}
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	int u; int v;
	for (int i=1; i<n; i++){
		scanf("%d%d",&u,&v);
		build(u,v);
	}
	for (int i=1; i<=n; i++)
		scanf("%d%d",&w[i],&tag[i]);
	use[0]=true;
	for (int i=1; i<=n; i++){
		if (tag[i]==true){
			dfs(i,0);
			getans(1);
		}
	}
	printf("%d\n",ans);
}
