#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1e5+10,MAXM=2e5+10,MOD=998244353;
int n,m,k,head[MAXN],cnt;
struct edge
{
	int v,next;
}e[MAXM];
void addedge(int x,int y)
{
	e[++cnt]=(edge){y,head[x]};
	head[x]=cnt;
	return;
}
namespace case1
{
	int val[2010];
	int qpow(int a,int b)
	{
		int ret=1;
		for(;b;b>>=1,a=(LL)a*a%MOD)
			if(b&1)ret=(LL)ret*a%MOD;
		return ret;
	}
	void dfs(int u,int dep)
	{
		val[u]=((LL)val[u]+qpow(dep,k))%MOD;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].v;
			dfs(v,dep+1);
		}
		return;
	}
	void solve()
	{
		dfs(1,0);
		for(int i=1;i<=n;++i)printf("%d\n",val[i]);
		return;
	}
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read();
		addedge(x,y);
	}
	if(n<=2000)case1::solve();
	return 0;
}
