#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){return a<b?a=b,1:0;}
template<class T> inline bool chkmin(T& a,T b){return a>b?a=b,1:0;}
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=30;
int ans,a[maxn],n;
bool check(){
    for(int i=1;i<=n;i++) if(a[i]!=i) return 0;
    return 1;
}
int F(){
    int ret=0;
    for(int i=1;i<n;i++) if(abs(a[i+1]-a[i])>1) ++ret;
    return ret;
}
bool dfs(int u){
    if(u+F()>ans) return 0;
    if(check()) return 1;
    for(int i=2;i<=n;i++){
        reverse(a+1,a+i+1);
        if(dfs(u+1)) return 1;
        reverse(a+1,a+i+1);
    }
    return 0;
}
int main(){
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
    int _; read(_);
    while(_--){
        read(n); ans=0;
        for(int i=1;i<=n;i++) read(a[i]);
        while(!dfs(0)) ++ans;
        printf("%d\n",ans);
    }
    return 0;
}
