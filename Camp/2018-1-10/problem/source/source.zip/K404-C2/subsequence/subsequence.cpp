#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
const int N=4005;
int ans,n,m,k,a[N],b[N],c[N],nxta[N][N],nxtb[N][N],f[N][N];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void task1()
{
	rep(i,1,n+1) rep(j,1,m+1) f[i][j]=1000000000;
	rep(i,1,k) f[nxta[0][i]][nxtb[0][i]]=1;
	rep(i,1,n+1)
		rep(j,1,m+1)
			if(f[i][j]!=1000000000)
				rep(x,1,k)
					f[nxta[i][x]][nxtb[j][x]]=min(f[nxta[i][x]][nxtb[j][x]],f[i][j]+1);
	printf("%d\n",f[n+1][m+1]);
}

void task2()
{
	f[0][0]=1;
	for(int ans=1; ; ++ans)
	{
		repd(i,n+1,0)
			repd(j,m+1,0)
				if(f[i][j])
				{
					rep(x,1,k)
						f[nxta[i][x]][nxtb[j][x]]=1;
					f[i][j]=0;
				}
		if(f[n+1][m+1])
		{
			printf("%d\n",ans);
			break;
		}
	}
}

int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);	
	n=getint(),m=getint(),k=getint();
	rep(i,1,n) a[i]=getint();
	rep(i,1,m) b[i]=getint();
	if(k==1)
	{
		printf("%d\n",max(n,m)+1);
		return 0;
	}
	rep(i,1,k) nxta[n+1][i]=c[i]=n+1;
	repd(i,n,0)
	{
		rep(j,1,k) nxta[i][j]=c[j];
		c[a[i]]=i;
	}
	rep(i,1,k) nxtb[m+1][i]=c[i]=m+1;
	repd(i,m,0)
	{
		rep(j,1,k) nxtb[i][j]=c[j];
		c[b[i]]=i;
	}
	if(n<=300 && m<=300 && k<=300) task1();
	else task2();
	return 0;
}
