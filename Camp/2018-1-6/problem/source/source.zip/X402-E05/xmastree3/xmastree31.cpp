#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define bitcnt(x) __builtin_popcount(x)
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=110;
const int L=16;
const int mod=998244353;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree31.out","w",stdout);
}
int n,K;
int bgn[N],nxt[N<<1],to[N<<1],E;
int dp[1<<21][L],S[1<<21][L];
vector<int>G;
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void Add(int &x,int y){x=x+y<mod?x+y:x+y-mod;}
inline int dfs(int u,int f,int x)
{
	int now=1<<(u-1);
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		if((x>>(v-1))&1)now|=dfs(v,u,x);
	}
	return now;
}
inline void Solve()
{
	For(x,1,(1<<n)-1)
	{
		if(bitcnt(x)==1)For(j,1,K)dp[x][j]=1;
		else
		{
			For(u,1,n)
			if((x>>(u-1))&1)
			{
				for(int v,i=bgn[u];i;i=nxt[i])if((x>>((v=to[i])-1))&1)G.pb(dfs(v,u,x));
				//printf("x:%d u:%d :",x,u);
				//For(j,0,SZ(G)-1)printf("%d ",G[j]);
				//puts("");
				For(i,1,K)
				{
					LL ret=1;
					For(j,0,SZ(G)-1)ret=ret*S[G[j]][i-1]%mod;
					Add(dp[x][i],ret);
				}
				G.clear();
			}
		}
		For(i,1,K)Add(S[x][i]=dp[x][i],S[x][i-1]);
		//For(i,1,K)printf("%d %d: %d\n",x,i,dp[x][i]);
	}
	printf("%d\n",S[(1<<n)-1][K]);
}
int main()
{
	int x,y;
	file();
	read(n),read(K);
	For(i,2,n)read(x),read(y),add_edge(x,y),add_edge(y,x);
	Solve();
	return 0;
}
