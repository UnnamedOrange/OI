#include <bits/stdc++.h>

int type, N;

void init() {
	
}

int encode(int x, int y) {
	int v = x ^ y;
	for (int i = 0; i < 10; ++i) {
		if (v & (1 << i)) {
			return i + ((x & (1 << i)) ? 0 : 10);
		}
	}
	return 0;
}

bool decode(int q, int v) {
	if (v >= 10) {
		v -= 10;
		if (q & (1 << v)) {
			return 0;
		} else {
			return 1;
		}
	} else {
		if (q & (1 << v)) {
			return 1;
		} else {
			return 0;
		}
	}
}

int main() {
	int T;
	scanf("%d%d%d", &type, &N, &T);
	init();
	while (T--) {
		int x, y;
		scanf("%d%d", &x, &y);
		if (type == 1) {
			printf("%d\n", encode(x, y));
		} else {
			puts(decode(x, y) ? "yes" : "no");
		}
	}
}
