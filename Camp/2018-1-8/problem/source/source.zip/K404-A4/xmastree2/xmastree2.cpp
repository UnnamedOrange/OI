#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int maxn=1010;
bool r[1010],vis[1010];
int n,w[maxn],sum[maxn],a[maxn][maxn],sz[maxn],tmp[maxn],fa[1010],q[1010],ans=0;
struct edge
{
	int t;
	edge *next;
}*con[1010];
void ins(int x,int y)
{
	edge *p=new edge;
	p->t=y;
	p->next=con[x];
	con[x]=p;
}
void find(int v)
{
	if(v>n)
	{
		int cal=0;
		for(int i=1;i<=n;i++)
			cal+=i*w[q[i]];
		ans=max(ans,cal);
		//if(cal==87) {for(int i=1;i<=n;i++) cout<<w[q[i]]<<' ';cout<<endl;}
		return ;	
	}
	for(int i=1;i<=n;i++)
		if(vis[i])
		{
			vis[i]=0;
			for(edge *p=con[i];p;p=p->next)
				if(p->t!=fa[i]) fa[p->t]=i,vis[p->t]=1;
			q[v]=i;
			find(v+1);
			q[v]=0;
			for(edge *p=con[i];p;p=p->next)
				if(p->t!=fa[i]) fa[p->t]=0,vis[p->t]=0;
			vis[i]=1;			
		}
}
void dfs(int v,int fa)
{
	for(edge *p=con[v];p;p=p->next)
		if(p->t!=fa)
		{
			dfs(p->t,v);
			for(int tv=1,tp=1,top=0;tv<=sz[v]||tp<=sz[p->t];)
			{
				if(tv>sz[v]||(tp<=sz[p->t]&&a[p->t][tp]<a[v][tv])) tmp[++top]=a[p->t][tp++];
				else tmp[++top]=a[v][tv++];
			}
			sz[v]+=sz[p->t];
			for(int i=1;i<=sz[v];i++)
				a[v][i]=tmp[i];
		}	
	sz[v]++;
	for(int i=sz[v];i>1;i--)
		a[v][i]=a[v][i-1];
	a[v][1]=w[v];	
//		
//	cout<<v<<":"<<endl;
//	for(int i=1;i<=sz[v];i++)
//		cout<<a[v][i]<<' ';
//	cout<<endl;		
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y);
		ins(y,x);
	}
	for(int i=1;i<=n;i++)
		scanf("%d%d",&w[i],&r[i]);
	if(n<=10)
	{	
		for(int i=1;i<=n;i++)
			if(r[i])
			{
				memset(vis,0,sizeof(vis));
				vis[i]=1;
				find(1);
			}
	}
	else
	{	
		for(int i=1;i<=n;i++)
			if(r[i])
			{
				//cout<<"root:"<<i<<endl;
				memset(sum,0,sizeof(sum));
					memset(sz,0,sizeof(sz));
				memset(a,0,sizeof(a));
				dfs(i,0);
				int cal=0;
				for(int j=1;j<=n;j++)
					cal+=a[i][j]*j;	
				ans=max(ans,cal);
				//cout<<"cal:"<<cal<<endl;
			}
	}
	printf("%d",ans);	
	return 0;
}
