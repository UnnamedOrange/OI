#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int a[100005], b[100005];
int ans;
const int mod = 998244353;
bool vis[15];
int n;
int cnt;
inline void gao() {
	for(int i = 1; i <= n; ++i) {
		if(a[i] && b[i] != a[i]) return;
	}
	memset(vis, 0, sizeof(vis));
	int x, cnt = 0;
	for(int i = 1; i <= n; ++i) {
		if(!vis[i]) {
			x = i;
			++cnt;
			vis[i] = 1;
			while(!vis[b[x]]) {
				vis[b[x]] = 1;
				x = b[x];
				++cnt;
			}
			if(cnt & 1) return;
		}
	}
	++ans;
}
int main() {
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	R(n);
	for(int i = 1; i <= n; ++i) {
		R(a[i]);
		if(a[i]) ++cnt;
	}
	if(n <= 8) {
		for(int i = 1; i <= n; ++i) {
			b[i] = i;
		}
		do {
			gao();
		} while(next_permutation(b + 1, b + n + 1));
		printf("%d\n", ans);
		return 0;
	} else {
		for(int i = 1; i <= n; ++i) {
			if(a[i] == i) {
				puts("0");
				return 0;
			}
		}
		if(n & 1) {
			puts("0");
			return 0;
		} else {
			int ans = 1;
			int lef = n;
			lef -= cnt;
			for(int i = 2; i <= n && lef; i += 2) {
				if(lef >= 2) {
					ans = (long long)ans * ((long long)(i - 1) * (i - 1) % mod) % mod;
					lef -= 2;
				} else {
					if(lef == 1) {
						ans = (long long)ans * (long long)(i - 1) % mod;
						lef-=1;
					} else {
						break;
					}
				}
			}
			printf("%d\n", ans);
		}
	}
	return 0;
}
