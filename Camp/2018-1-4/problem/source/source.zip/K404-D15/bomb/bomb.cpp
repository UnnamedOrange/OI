#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 1000005

int n,m,tot,idx,cnt,top;
int now[maxn],pre[maxn],son[maxn],dfn[maxn],low[maxn];
int stack[maxn],size[maxn],bel[maxn],f[maxn],deg[maxn];
bool instack[maxn];
vector<int> v[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

void add(int a,int b){son[++tot]=b,pre[tot]=now[a],now[a]=tot;}
void link(int a,int b){add(a,b);}

struct edge{int x,y; edge(){} edge(int _x,int _y){x=_x,y=_y;}}e[maxn];

void tarjan(int x){
	dfn[x]=low[x]=++idx,stack[++top]=x,instack[x]=1;
	for (int p=now[x];p;p=pre[p]){
		if (!dfn[son[p]]) tarjan(son[p]),low[x]=min(low[x],low[son[p]]);
		else if (instack[son[p]]) low[x]=min(low[x],dfn[son[p]]);
	}
	if (dfn[x]==low[x]){
		int s=1; instack[x]=0,bel[x]=++cnt;
		while (stack[top]!=x) ++s,instack[stack[top]]=0,bel[stack[top--]]=cnt;
		size[cnt]=s,--top;
	}
}

int q[maxn];

int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read(),m=read();
	for (int i=1,x,y;i<=m;i++) x=read(),y=read(),e[i]=edge(x,y),link(x,y);
	for (int i=1;i<=n;i++) if (!dfn[i]) tarjan(i);
	for (int i=1;i<=m;i++){
		int x=e[i].x,y=e[i].y;
		if (bel[x]!=bel[y]) v[bel[x]].push_back(bel[y]),++deg[bel[y]];
	}
	int head=1,tail=0; memset(f,63,sizeof(f));
	for (int i=1;i<=cnt;i++) if (!deg[i]) q[++tail]=i,f[i]=size[i];
	while (head<=tail){
		int x=q[head++];
		for (int i=0,s=v[x].size();i<s;i++){
			int pps=v[x][i];
			f[pps]=min(f[pps],f[x]+size[pps]);
			if (--deg[pps]==0) q[++tail]=pps;
		}
	}
	int ans=0;
	for (int i=1;i<=cnt;i++) ans=max(ans,f[i]);
	cout<<ans<<endl;
	return 0;
}
