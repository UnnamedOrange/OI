#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define inf (1ll<<60)
#define N 510
long long t,n,m,w,q,g[N],x[N],y[N],z[N],a[N],
b[N],c[N],d[N],e[N],f[N],u[N],v[N],opt[N],ans;
long long aabs(long long x)
{
	return x<0?-x:x;
}
void dfs(int k)
{
	if(k==n+1)
	{
		fr(i,1,q)
		{
			if(opt[i]==0&&g[u[i]]>g[v[i]])
				return;
			if(opt[i]==1&&g[u[i]]!=g[v[i]])
				return;
			if(opt[i]==2&&g[u[i]]>=g[v[i]])
				return;
		}
		long long th=0;
		fr(i,1,n)
			th+=g[i];
		fr(i,1,m)
			th+=a[i]*aabs(g[x[i]]-g[y[i]])+b[i]*aabs(g[y[i]]-g[z[i]])+
				c[i]*aabs(-g[x[i]]+g[z[i]])+d[i]*(g[x[i]]-g[y[i]])+
				e[i]*(g[y[i]]-g[z[i]])+f[i]*(-g[x[i]]+g[z[i]]);
		ans=min(ans,th);
//		fr(i,1,n)
//			printf("%d ",g[i]);
//		printf("%d\n",th);
		return;
	}
	g[k]=1;
	dfs(k+1);
	g[k]=-1;
	dfs(k+1);
}
int main()
{
	freopen("variable.out","w",stdout);
	freopen("variable.in","r",stdin);
	t=read();
	while(t--)
	{
		n=read();
		w=aabs(read());
		m=read();
		q=read();
		fr(i,1,m)
		{
			x[i]=read();
			y[i]=read();
			z[i]=read();
			a[i]=read();
			b[i]=read();
			c[i]=read();
			d[i]=read();
			e[i]=read();
			f[i]=read();
		}
		fr(i,1,q)
		{
			u[i]=read();
			v[i]=read();
			opt[i]=read();
		}
		ans=inf;
		dfs(1);
		printf("%lld\n",ans*w);
	}
	return 0;
}