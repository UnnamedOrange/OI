#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=1e6+5;
int n,m,i,j,v,a,b,tm,ans;
int En,fst[N],nxt[N],to[N];
int blc,En2,fst2[N],nxt2[N],to2[N],size[N];
int top,instk[N],bel[N],stk[N],dfn[N],low[N],depth[N];
void read(int &ret)
{
	char ch; ret=0;
	for (ch=getchar();ch<'0' || ch>'9';ch=getchar());
	for (;ch>='0' && ch<='9';ch=getchar()) ret=ret*10+ch-'0';
}
void add(int a,int b) {
	En++; nxt[En]=fst[a]; fst[a]=En; to[En]=b;
}
void add2(int a,int b) {
	En2++; nxt2[En2]=fst2[a]; fst2[a]=En2; to2[En2]=b;
}
void Tarjan(int x)
{
	stk[++top]=x; instk[x]=1;
	dfn[x]=low[x]=++tm;
	int j,v;
	for (j=fst[x];j;j=nxt[j])
	{
	   v=to[j];
	   if (!dfn[v]) {
	   	  Tarjan(v);
	   	  low[x]=min(low[x],low[v]);
	   }
	   else if (instk[v]) low[x]=min(low[x],dfn[v]);
    }
    if (dfn[x]==low[x])
    {
    	++blc;
    	while (stk[top+1]!=x)
    	{
    		v=stk[top];
    		instk[v]=0;
    		bel[v]=blc;
    		size[blc]++;
    		top--;
		}
	}
}
void Init()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	read(n); read(m);
	rep(i,1,m)
	{
		read(a); read(b);
		add(a,b);
	}
	rep(i,1,n)
	  if (!dfn[i]) Tarjan(i);
	rep(i,1,n)
	  for (j=fst[i];j;j=nxt[j])
	  {
	  	v=to[j];
	    if (bel[i]!=bel[v])
	      add2(bel[i],bel[v]);
      }
}
void DFS(int x)
{
	if (depth[x]) return;
	int j,v;
	for (j=fst2[x];j;j=nxt2[j])
	{
		v=to2[j];
		DFS(v);
		depth[x]=max(depth[x],depth[v]);
	}
	depth[x]+=size[x];
}
void Work()
{
	rep(i,1,blc)
	  if (!depth[i]) DFS(i);
    rep(i,1,blc)
      ans=max(ans,depth[i]);
    printf("%d\n",ans);
}
int main()
{
	Init();
	Work();
	return 0;
}
