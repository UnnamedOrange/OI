#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn = 1e3 + 5;
struct edge {
	int v, next;
}e[maxn << 1];
int head[maxn], cnt, nodew[maxn], size[maxn], dfn, ans, mxans;
int vs[maxn][maxn], mx[maxn];
bool cmp(const int &a, const int &b) {
	return size[a] < size[b];
}
void adde(const int &u, const int &v) {
	e[++cnt] = (edge) {v, head[u]};
	head[u] = cnt;
}
int n, m, root[15], mxrt, a, b;
void dfs(int u, int fa) {
	size[u] = nodew[u];
	for(register int i = head[u]; i; i = e[i].next) {
		int v = e[i].v;
		if(v == fa) continue;
		dfs(v, u), size[u] += size[v];
		vs[u][++mx[u]] = v;
	}
	sort(vs[u] + 1, vs[u] + mx[u] + 1, cmp);
}
void Xuanxue(int u) {
	++dfn, ans += nodew[u] * dfn;
	for(register int i = 1; i <= mx[u]; ++i) 
		Xuanxue(vs[u][i]);
}
int main() {
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	scanf("%d", &n);;
	for(register int i = 1; i < n; ++i)
		scanf("%d%d", &a, &b), adde(a, b), adde(b, a);
	for(register int i = 1; i <= n; ++i) {
		scanf("%d%d", &a, &b), nodew[i] = a;
		if(b) root[++mxrt] = i;
	}
	for(register int i = 1; i <= mxrt; ++i)
		dfs(root[i], 0), dfn = ans = 0, Xuanxue(root[i]), mxans = max(mxans, ans);
	printf("%d\n", mxans);
	return 0;
}
