#include<iostream>
#include<cstdio>
#include<cstring>
#define G(x) (x==0?0:(1<<(x-1)))
using namespace std;
const int mod=998244353;
const int maxp=3010;
int n,m,cnt,cs[110],len[8],a[maxp][2],fa[maxp],pl[maxp],uf[maxp],dl[maxp],f[2][maxp][70][2];
bool bk[maxp][2];
char s[8][110];
void ins(int *t,int len,int id,int* lab)
{
	int p=0;
	for(int i=1;i<=len;p=a[p][t[i]],i++)
		if(!a[p][t[i]]) bk[p][t[i]]=1,a[p][t[i]]=++cnt;
	//cout<<cnt<<endl;	
//	cout<<id<<' '<<p<<endl;	
	lab[p]|=(1<<(id-1)); 
}
void check(int *t,int len,int id,int d)
{
//	cout<<"check:"<<len<<' '<<id<<' '<<d<<endl;	
//	for(int i=1;i<=len;i++)
//		cout<<t[i]<<' ';
//	cout<<endl;	
	for(int i=1;i<=len;i++)
	{
		//cout<<"cmp"<<i<<' '<<2*d-i+1<<endl;
		if(2*d-i+1>0&&2*d-i+1<=len&&t[i]==t[2*d-i+1]) {return ;}
	}
	int w[110];
	if(d>len/2)
	{
		for(int i=1;i<=d;i++)
			w[i]=t[d-i+1];
//		for(int i=1;i<=d;i++)
//			cout<<w[i]<<',';
//		cout<<endl;	
		ins(w,d,id,uf);	
	}
	else
	{
		for(int i=d+1;i<=len;i++)
			w[i-d]=(t[i]^1);
//		
//		for(int i=1;i<=len-d;i++)
//			cout<<w[i]<<',';
//		cout<<endl;
		ins(w,len-d,id,uf);
	}
}
void getac()
{
	for(int hd=1,tl=1,v=0;hd<=tl;v=dl[++hd])
		for(int ic=0;ic<=1;ic++)
			if(a[v][ic])
			{
				int p=fa[v];
				while(p&&!a[p][ic]) p=fa[p];
				if(a[p][ic]!=a[v][ic]) fa[a[v][ic]]=a[p][ic],pl[a[v][ic]]|=pl[a[p][ic]];
				dl[++tl]=a[v][ic];
			}
			else a[v][ic]=a[fa[v]][ic];				
}
void dp()
{
	memset(f,0,sizeof(f));
	f[0][0][pl[0]|uf[0]][0]=1;
	for(int i=1,v=1;i<=m;v^=1,i++)
	{
		memset(f[v],0,sizeof(f[v]));
		for(int j=0;j<=cnt;j++)
			for(int s=0;s<(1<<n);s++)
				if(f[v^1][j][s][0]||f[v^1][j][s][1])
				for(int ic=0;ic<=1;ic++)
				{
					int to=a[j][ic];
					(f[v][to][ pl[to] | s ][1]+=f[v^1][j][s][1])%=mod;
					if(bk[j][ic]) (f[v][to][ pl[to] | uf[to] | s ][0]+=f[v^1][j][s][0])%=mod;
					else (f[v][to][ pl[to] | s ][1]+=f[v^1][j][s][0])%=mod;
					//printf("%d %d->%d %d:%d %d\n",i,j,to,s,f[v][to][pl[to]|uf[to]|s][0],f[v][to][pl[to]|s][1]);
				}
	}
}
void outp()
{
	for(int i=0;i<=cnt;i++)
		for(int ic=0;ic<=1;ic++)
			if(a[i][ic])
				printf("%d->%d->%d %d\n",i,ic,a[i][ic],bk[i][ic]);
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		//puts("*****************************");
		scanf("%s",s[i]+1);
		len[i]=strlen(s[i]+1);
		for(int j=1;j<=len[i];j++)
			cs[j]=s[i][len[i]-j+1]-'0';
		ins(cs,len[i],i,pl);
		
		for(int j=1;j<=len[i];j++)
			cs[j]=((s[i][j]-'0')^1);
		ins(cs,len[i],i,pl);
		
		for(int j=1;j<=len[i];j++)
			cs[j]=s[i][j]-'0';
		for(int j=1;j<len[i];j++)
			check(cs,len[i],i,j);	
	}
//	puts("pl");
//	for(int i=0;i<=cnt;i++)
//		cout<<pl[i]<<' ';
//	cout<<endl;
	//outp();
	//puts("############################");
	getac();
//	puts("fa");
//	for(int i=0;i<=cnt;i++)
//		cout<<fa[i]<<' ';
//	cout<<endl;	
//	
//	puts("pl");
//	for(int i=0;i<=cnt;i++)
//		cout<<pl[i]<<' ';
//	cout<<endl;
//	puts("uf");
//	for(int i=0;i<=cnt;i++)
//		cout<<uf[i]<<' ';
//	cout<<endl;		
	//outp();
	dp();
	int ans=0;
	for(int i=0;i<=cnt;i++)
	{
		(ans+=f[m&1][i][(1<<n)-1][0])%=mod,(ans+=f[m&1][i][(1<<n)-1][1])%=mod;
		//cout<<i<<' '<<f[m&1][i][(1<<n)-1][0]<<' '<<f[m&1][i][(1<<n)-1][1]<<endl;
	}
	printf("%d",ans);	
	return 0;
}
