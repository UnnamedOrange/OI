#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <ctime>
using namespace std;
int x[30],t,n; 
inline bool judge()
{
	for(int i=1;i<n;i++)
	{
		if(x[i]>x[i+1])return 0;
	}
	return 1;
}
inline void turn(int y)
{
	for(int i=y;i>1;i--)
	{
		swap(x[i],x[i-1]);
	}
}
bool dfs(int k,int lim,int last=0)
{
	if(k==lim)
	{
		return judge();
	}
	for(int i=2;i<=n;i++)
	{
		turn(i);
		if(i==last)continue; 
		bool flag=dfs(k+1,lim,i);
		if(flag)
		{
			return 1;
		}
	}
	for(int i=1,j=n;i<=j;i++,j--)
	{
		swap(x[i],x[j]);
	} 
	return 0;
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>t;
	int toki=clock();
	while(t--)
	{
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			cin>>x[i];
		}
		bool flag=1;
		for(int i=1;i<n;i++)
		{
			flag&=(x[i]<x[i+1]);
		}
		if(flag)
		{
			cout<<0<<endl;
			continue;
		}
		int l=1,r=n-2;
		flag=0;
		for(int i=1;i<=100;i++)
		{
//			cout<<i<<endl;
			if(dfs(0,i))
			{
				cout<<i<<endl;
				break;
			}
		}
	}
//	cout<<clock()-toki<<endl;
	return 0;
}
/*
5
10
5 7 4 3 1 8 2 9 10 6
10
5 7 4 3 1 8 2 9 10 6 
10
5 7 4 3 1 8 2 9 10 6
10
5 7 4 3 1 8 2 9 10 6
10
5 7 4 3 1 8 2 9 10 6

*/
