#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

const int N = 25;

int n, m;
int L[N], R[N], X[N];

int main(){
	
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.ans", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) scanf("%d%d", &L[i], &R[i]);
	For(i, 1, m) scanf("%d", &X[i]);

	int ans = 0;

	For(i, 0, (1 << n) - 1){
		bool ok = true;
		For(j, 1, m){
			bool found = false;
			For(k, 0, n - 1) if((i & (1 << k)) && R[k + 1] >= X[j] && L[k + 1] <= X[j]){
				found = true;
				break;
			}
			if(!found){
				ok = false;
				break;
			}
		}
		ans += ok;
	}

	printf("%d\n", ans);

	return 0;
}
