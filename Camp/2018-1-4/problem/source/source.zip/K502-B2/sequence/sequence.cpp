#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=35;
int n,a[M];
struct SHUI{
	int ans;
	void dfs(int stp){
		bool f=true;
		for(int i=1;i<=n;i++)if(i!=a[i]){f=false;break;}
		if(f){
			ans=stp;
			return;
		}
		if(stp+1>=ans)return;
		stp++;
		for(int i=2;i<=n;i++){
			for(int l=1,r=i;l<r;l++,r--)swap(a[l],a[r]);
			dfs(stp);
			for(int l=1,r=i;l<r;l++,r--)swap(a[l],a[r]);
		}
	}
	void solve(){
		ans=n*2;
		dfs(0);
		printf("%d\n",ans);
	}
}P16;
struct IHSU{
	int ans,b[M];
	void dfs(int stp,int x){
		while(x>=1&&a[x]==x)x--;
		if(x==0){
			stp=ans;
			return;
		}
		bool f=true;
		int ps=1;
		int id[M];
		for(int i=1;i<=x;i++){
			if(a[i]==1)ps=i;
			id[a[i]]=i;
		}
		for(int i=1;i<ps;i++)if(a[i]!=a[i+1]+1)f=false;
		for(int i=ps+1;i<x;i++)if(a[i]!=a[i+1]-1)f=false;
		if(f){
			ans=stp+1;
			return;
		}
		if(stp+2>=ans)return;
		if(b[1]==x){
			for(int l=1,r=x;l<r;l++,r--)swap(a[l],a[r]);
			dfs(stp+1,x);
			for(int l=1,r=x;l<r;l++,r--)swap(a[l],a[r]);
		}else {
			stp++;
			for(int i=x;i>=1;i--){
				for(int l=1,r=id[i];l<r;l++,r--)swap(a[l],a[r]);
				dfs(stp,x);
				for(int l=1,r=id[i];l<r;l++,r--)swap(a[l],a[r]);
			}
		}
	}
	void solve(){
		ans=0;
		for(int i=1;i<=n;i++)b[i]=a[i];
		for(int i=n,ps;i>=1;i--){
			if(b[i]==i)continue;
			ps=1;
			for(int j=1;j<i;j++)if(b[j]==i){ps=j;break;}
			if(ps!=1){
				ans++;
				for(int l=1,r=ps;l<r;l++,r--)swap(b[l],b[r]);
			}
			ans++;
			for(int l=1,r=i;l<r;l++,r--)swap(b[l],b[r]);
		}
		dfs(0,n);
		printf("%d\n",ans);
	}
}PPP;
void solve(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
//	if(0);
	if(n<=6)P16.solve();
	else PPP.solve();
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int cas;
	scanf("%d",&cas);
	while(cas--)solve();
	return 0;
}
