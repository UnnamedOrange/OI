#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
#define ll long long
using namespace std;
int n;
struct seg{int l,r;}t[100010];
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)scanf("%d%d",&t[i].l,&t[i].r);
	puts("-1");
	return 0;
}
