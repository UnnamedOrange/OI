#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int mod=998244353;
const int N=12,M=(1<<12)+5;
int n,K;int ans;
int f[N];int dp[M][N];int num[M];
struct node{
	int to,next;
};node edge[N*2];
int graph[N],tot;

void addedge(int i,int x,int y){
	edge[i].to=y;edge[i].next=graph[x];graph[x]=i;
}

void dfs(int x,int pre,int mask){
	int i,y;
	f[x]=1<<(x-1);
	for(i=graph[x];i;i=edge[i].next){
		y=edge[i].to;
		if(y==pre)	continue;
		if(!(mask>>(y-1)&1))	continue;
		dfs(y,x,mask);
		f[x]|=f[y];
	}
}

int solve(int mask,int k){
	if(dp[mask][k]!=-1)	return dp[mask][k];
	if(num[mask]==1)	return (dp[mask][k]=1);
	int &ret=dp[mask][k];int tmp,now,i,j,l,y;
	ret=0;
	rep(i,1,n) if(mask>>(i-1)&1){
		tmp=1;
		dfs(i,0,mask);
		for(j=graph[i];j;j=edge[j].next){
			y=edge[j].to;
			if(mask>>(y-1)&1){
				now=0;
				rep(l,k+1,K){				
					(now+=solve(f[y],l))%=mod;
				}
				tmp=1ll*tmp*now%mod;
			}
		}
		(ret+=tmp)%=mod;		
	}
	return ret;
}
	

int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	int i,x,y;
	memset(dp,-1,sizeof(dp));
	scanf("%d%d",&n,&K);
	rep(i,1,(1<<n)-1)	num[i]=num[i>>1]+(i&1);	
	rep(i,1,n-1){
		scanf("%d%d",&x,&y);
		tot++;addedge(tot,x,y);
		tot++;addedge(tot,y,x);
	}
	rep(i,1,K)	(ans+=solve((1<<n)-1,i))%=mod;
	printf("%d\n",ans);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
