#include <bits/stdc++.h>
using namespace std;

pair<int, int> vals[110];
double ans[110];

int main() {
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	int n;
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		cin >> vals[i].first;
		vals[i].second = i;
	}
	for (int i = 1; i <= n; ++i) {
		for (int j = i; j <= n; ++j) {
			vector<pair<int, int>> sub(vals + i, vals + j + 1);
			sort(sub.begin(), sub.end(), greater<pair<int, int>>());
			double f = 1;
			for (auto p : sub) {
				f /= 2;
				ans[p.second] += f;
			}
		}
	}
	double ret = 0;
	for (int i = 1; i <= n; ++i) {
		ret += ans[i] * vals[i].first;
	}
	cout << fixed << setprecision(4);
	cout << endl << ret / n / n << endl;
}
