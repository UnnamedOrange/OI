#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

void output(int len)
{
	while(len--)printf("%c",rand()%2+'0');
	printf("\n");
}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("string.in","w",stdout);//look at here

	int n=2,m=3;
	printf("%d %d\n",n,m);
	while(n--)output(rand()%3+1);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
