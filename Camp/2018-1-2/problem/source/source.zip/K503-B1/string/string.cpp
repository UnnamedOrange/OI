#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
int T,opt,n,fla,tot;
int ha[410];
int i;
char a[maxn];
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	for (opt=1;opt<=T;opt++){
		scanf("%d",&n);
		scanf("\n");
		memset(ha,0,sizeof(ha));
		for (i=1;i<=n;i++){
			scanf("%c",&a[i]);
			ha[a[i]]=1;
		}
		fla=1;
		for (i=2;i<=n;i++){
			if (a[i]!=a[i-1]){
				fla=0;
				break;
			}
		}
		if (fla==1){
			printf("-1\n");
			continue;
		}
		if (n%2==1){
			tot=0;
			for (i=0;i<=400;i++){
				tot=tot+ha[i];
			}
			if (tot==2){
				fla=1;
				for (i=2;i<=n;i++){
					if (a[i]==a[i-1]){
						fla=0; break;
					}
				}
				if (fla==1){
					printf("-1\n");
					continue;
				}
				fla=0;
				memset(ha,0,sizeof(ha));
				for (i=1;i<=n;i++){
					ha[a[i]]++;
				}
				for (i=0;i<=400;i++){
					if (ha[i]==1){
						fla=1; break;
					}
				}
				if (fla==1){
					printf("-1\n");
					continue;
				}
			}
		}
		fla=1;
		for (i=1;i<=n/2;i++){
			if (a[i]!=a[n-i+1]){
				fla=0;
				break;
			}
		}
		if (fla==1){
			printf("2\n");
			continue;
		}
		printf("1\n");
	}
	return 0;
}
