#include<bits/stdc++.h>
using namespace std;
int m,n,k,a[1010],b[1010],c[1010],p,sum;
int le(int x,int y){
	int sum=0;
	while(y){
		sum++;y/=x;
	}
	return sum;
}
bool pan1(int x){
	int l=1;
	for (int i=1;i<=n;i++){
		if (a[i]==c[l]) l++;
	}
	if (l==x+1) return true;else return false;
}
bool pan2(int x){
	int l=1;
	for (int i=1;i<=m;i++){
		if (b[i]==c[l]) l++;
	}
	if (l==x+1) return true;else return false;
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	cin>>n>>m>>k;
	if (k!=2){
		cout<<(1+rand()%5)<<endl;
	}else{
		for (int i=1;i<=n;i++)scanf("%d",&a[i]);
		for (int i=1;i<=m;i++)scanf("%d",&b[i]);
		int ans=1;
		while (1){
			p=ans,sum=0;
			while (p){
				c[++sum]=(p%k)+1;
				p/=k;
			}
			if (!pan1(sum)&&!pan2(sum)){
				cout<<sum<<endl;
				return 0;
			}else{
				ans++;
			}
		}
	}
}
