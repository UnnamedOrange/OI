# include <bits/stdc++.h>
# define 	N 		100010
# define 	ll 		long long
# define 	P 		998244353
using namespace std;
ll use[N],a[N],num1,num2,n,tag[N];
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%lld",&n);
	for (ll i=1; i<=n; i++) scanf("%lld",&a[i]);
	if (n%2!=0){
		printf("0\n");
		return 0;
	}
	for (ll i=1; i<=n; i++) tag[a[i]]++;
	for (ll i=1; i<=n; i++){
		if (tag[i]!=0) continue;
		if (a[i]!=0&&use[i]==false){
			ll len=0,j=i;
			while (j!=0&&use[j]==false){
				use[j]=true;
				len++; j=a[j];
			}
			if (j==0)
				if (len%2==1) num1++; else num2++; 
		} 
	}
	for (int i=1; i<=n; i++){
		if (use[i]==false&&a[i]!=0){
			ll len=0, j=i;
			while (j!=0&&use[j]==false){
				use[j]=true; len++;
				j=a[j];
			}
			if (len%2==1){
				printf("0\n");
				return 0;
			}
		}
	}
	for (ll i=1; i<=n; i++) 
		if (use[i]==false) num1++;
	ll ans=1;
	for (ll i=2; i<=num1; i+=2) ans=ans*(i-1)%P;
	ans=ans*ans%P;
	for (ll i=1; i<=num2; i++) ans=ans*(num1+i)%P;
	printf("%lld\n",ans);
	return 0;
}

