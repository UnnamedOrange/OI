#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

const int N = 2e5 + 10;

int n;
char S[N], T[N];
int len[N], val[N], sum[N];

bool check(int l, int r){
	l = l << 1 | 1, r = r << 1 | 1;
	int m = (l + r) >> 1;
	return len[m] >= r - m;
}

bool Manacher(){
	T[0] = '#';
	For(i, 0, n - 1)
		T[i << 1 | 1] = S[i], T[(i + 1) << 1] = '#';

	int x = 0, mx = 0;
	For(i, 0, 2 * n){
		len[i] = val[i] = sum[i] = 0;
		if(i < mx) len[i] = min(mx - i, len[x - (i - x)]);
		while(i > len[i] && i + len[i] < 2 * n && 
				T[i + len[i] + 1] == T[i - len[i] - 1])
			++len[i];
		if(i + len[i] > mx) mx = i + len[i], x = i;
	}

	For(l, 0, n - 1) For(r, l, n - 1 - l)
		if(!check(l, r) && !check(r + 1, n - 1 - l)) return true;
	return false;

	/*
	For(i, 0, 2 * n){
		if(i) val[i] += val[i - 1], sum[i] = sum[i - 1] + val[i];

		int l = len[i] + 3, r = min(i, 2 * n - i);
		if(l > r + 1) continue;

		val[i + l]++, val[i + r + 1]--;

		if(sum[i - l] - sum[i - r - 1]) return true;
	}
	return false;
	*/
}

int main(){

	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);

	int Case;
	scanf("%d", &Case);
	while(Case--){
	
		scanf("%d%s", &n, S);
		
		bool par = true;
		For(i, 0, n - 1) if(S[i] ^ S[n - 1 - i]) par = false;
		
		if(!par){
			puts("1");
			continue;
		}

		if(Manacher()) puts("2");
		else puts("-1");
	
	}

	return 0;
}
