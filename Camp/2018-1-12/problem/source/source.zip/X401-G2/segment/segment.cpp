#include<bits/stdc++.h>
#define MO 998244353
using namespace std;
inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}
int  l,L,ll,Ll,LL,lL;

int h[100005],mm,m_,zz,ans,v[35],n,m,k,dp[41][41][41][421]; 

inline void upt(int & a, int b)
{
	a=(a+b)%MO;
}

inline int ksm(int p, int k)
{
	v[0]=p;
	for(int i=1; i<=29; ++i)
		v[i]=(long long)v[i-1]*v[i-1]%MO; 
	int s=1;
	for(int i=29; i>=0; --i)
	{
		if(k>=1<<i)
		{
			s=(long long)s*v[i]%MO;
			k-=1<<i;
	    }
	}
	return s;
}


//dfs no inline
void dfs(int p, int l ,int r)
{
	if(p==n)
	{
//		int s=0;
		for(int i=1; i<m; ++i)upt(ans,ksm(h[i],k));
		return;
	}
	int mm=m-n+p+1;
	for(int i=l+1; i<=mm; ++i)
	for(int j=max(i,r+1); j<=mm; ++j)
	{
		//k
		for(int kk=i; kk<j; ++kk)++h[kk];
		dfs(p+1,i,j);
		for(int kk=i; kk<j; ++kk)--h[kk];
	}
} 

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=read(); m=read(); k=read();
	if(n>m)
	{
		puts("0");
		return 0;
	}
	if(n==1)
	{
		for(int i=1; i<m; ++i)upt(ans,(long long)i*(m-i)%MO);
		printf("%d\n",ans);
		return 0;
	} 

	if(k==1&& m<=40)
	{
		dp[0][0][0][0]=1; zz=(m-m/2)*(m/2+1);
		for(int i=0; i<n; ++i)//xianhou  cout //cerr throw   re//
		{
		    mm=m-n+i;
		    m_=mm+1;
		    for(int j=0; j<=mm; ++j)
		    for(int l=j; l<=mm; ++l)
		    for(int z=0; z<=zz; ++z)if(dp[i][j][l][z])
		    {
			    for(int jj=j+1; jj<=m_; ++jj)
			    for(int ll=max(jj,l+1); ll<=m_; ++ll)upt(dp[i+1][jj][ll][z+ll-jj],dp[i][j][l][z]);
			}
		}
		for(int i=2; i<=m; ++i)
		for(int j=i; j<=m; ++j)
		for(int z=1; z<=zz; ++z)upt(ans,(long long)dp[n][i][j][z]*z%MO);
		printf("%d\n",ans);
		exit(0);
	}	
//	dfs(0,0,0);
//	printf("%d\n",ans);//
	if(k==998244352&& m<=40)
	{
		dp[0][0][0][0]=1;
		for(int i=0; i<n; ++i)
		{
		    mm=m-n+i;
		    m_=mm+1;
		    for(int j=0; j<=mm; ++j)
		    for(int l=j; l<=mm; ++l)
		    for(int z=0; z<m; ++z)if(dp[i][j][l][z])
		    {
			    for(int jj=j+1; jj<=m_; ++jj)
			    for(int ll=max(jj,l+1); ll<=m_; ++ll)upt(dp[i+1][jj][ll][z+min(ll-jj,ll-l+1)],dp[i][j][l][z]);
			}
		}
		for(int i=2; i<=m; ++i)
		for(int j=i; j<=m; ++j)
		for(int z=1; z<m; ++z)upt(ans,(long long)dp[n][i][j][z]*z%MO);
		printf("%d\n",ans);
		return 0;
	}	
	dfs(0,0,0);
	printf("%d\n",ans);//
}
