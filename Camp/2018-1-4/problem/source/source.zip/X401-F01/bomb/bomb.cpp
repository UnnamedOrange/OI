#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1e6+10;
int n,m,stac[MAXN],head[MAXN],head1[MAXN],cnt,tot,dfn[MAXN],low[MAXN],time,top,belog[MAXN],fa[MAXN],sum[MAXN],ans;
bool vis[MAXN];
struct edge
{
	int u,v,next;
}e[MAXN],e1[MAXN];
void addedge(int x,int y)
{
	e[++cnt]=(edge){x,y,head[x]};
	head[x]=cnt;
	return;
}
void addedge1(int x,int y)
{
	e1[++cnt]=(edge){x,y,head1[x]};
	head1[x]=cnt;
	return;
}
int getfa(int x)
{
	return fa[x]==x?x:fa[x]=getfa(fa[x]);
}
void tarjan(int u)
{
	dfn[u]=low[u]=++time;
	vis[u]=true;
	stac[++top]=u;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].v;
		if(!dfn[v])
		{
			tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(vis[v])low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int i;
		++tot;
		do
		{
			i=stac[top--];
			vis[i]=false;
			belog[i]=tot;
			++sum[tot];
		}while(i!=u);
	}
	return;
}
void dfs(int u)
{
	vis[u]=true;
	int _max=0;
	for(int i=head1[u];i;i=e1[i].next)
	{
		int v=e1[i].v;
		if(!vis[v])dfs(v);
		_max=max(_max,sum[v]);
	}
	sum[u]+=_max;
	ans=max(sum[u],ans);
	return;
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;++i)
	{
		int x=read(),y=read();
		addedge(x,y);
	}
	for(int i=1;i<=n;++i)
		if(!dfn[i])
			tarjan(i);
	for(int i=1;i<=tot;++i)fa[i]=i;
	cnt=0;
	for(int i=1;i<=m;++i)
		if(belog[e[i].u]!=belog[e[i].v])
			addedge1(belog[e[i].u],belog[e[i].v]),fa[belog[e[i].v]]=belog[e[i].u];
	for(int i=1;i<=tot;++i)
		if(fa[i]==i)
			dfs(i);
	printf("%d\n",ans);
	return 0;
}
