#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

const int N = 1e5 + 10;

int n;
int dp[1 << 12];
char S[N], T[N];

int main(){

	freopen("string.in", "r", stdin);
	freopen("string.ans", "w", stdout);

	int Case;
	scanf("%d", &Case);
	while(Case--){
	
		scanf("%d%s", &n, S);

		memset(dp, 0x3f, sizeof dp);
		dp[0] = 0;
		For(i, 0, (1 << n) - 1){
			int s = ((1 << n) - 1) ^ i, b[20], c = 0;

			For(j, 0, n - 1) if(s & (1 << j)) b[++c] = j;

			For(l, 1, c) For(r, l, c){
				int m = -1, k = 0;
				For(j, l, r) k |= 1 << b[j];

				if(dp[i | k] <= dp[i] + 1) continue;

				For(j, 0, n - 1) 
					if(k & (1 << j)) T[++m] = S[j];

				bool flag = true;
				For(j, 0, m) if(T[j] != T[m - j]){
					flag = false;
					break;
				}

				if(!flag) dp[i | k] = dp[i] + 1;
			}
		}

		int ans = dp[(1 << n) - 1];

		assert(ans <= 2 || ans > 1e9);
		printf("%d\n", ans > n ? -1 : ans);
	
	}

	return 0;
}
