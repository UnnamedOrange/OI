#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<set>
#include<algorithm>
#define ll long long
using namespace std;
set<int> s;
set<int> :: iterator it;
int read()
{
	char ch=getchar();int f=0,x=1;
	while(ch<'0'||ch>'9'){if(ch=='-') x=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){f=(f<<1)+(f<<3)+ch-'0';ch=getchar();}
	return f*x;
}
int n;
struct data
{
	int x;
	int id;
}a[1000005];
bool cmp(const data &x,const data &y)
{
	return x.x>y.x;
}
int prel[47],prer[47];
double po[55];
void getprel(int x)
{
	it=s.find(x);
	for(int i=1;i<=45;i++)
	{
		if(it==s.begin()) break;
		prel[i]=*--it;
	}
}
void getprer(int x)
{
	it=s.find(x);
	for(int i=1;i<=45;i++)
	{
		if(++it==s.end()) break;
		prer[i]=*it;
	}
}
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		a[i].x=read();
		a[i].id=i;
	}
	sort(a+1,a+n+1,cmp);
	long double ans=0;
	ll ss=1;
	for(int i=1;i<=45;i++)
	{
		ss<<=1LL;
		po[i]=ss;
	}
	s.clear();
	for(int i=1;i<=n;i++)
	{
		memset(prel,0,sizeof(prel));
		memset(prer,0,sizeof(prer));
		s.insert(a[i].id);
		//cout<<*it<<endl;
		getprel(a[i].id);
		getprer(a[i].id);
		prel[0]=a[i].id;
		prer[0]=a[i].id;
		for(int j=1;j<=45;j++)
		{
			for(int k=1;k<=45;k++)
			{
				if(j+k-1>45) break;
				if(!prer[k]) prer[k]=n+1;
				ans+=1.0*a[i].x*(prel[j-1]-prel[j])*(prer[k]-prer[k-1])/po[j+k-1]/n/n;
				//cout<<a[i].id-prel[j]<<" "<<(prer[k]-a[i].id)<<" "<<ans<<endl;
				if(prer[k]==n+1) 
				{
					prer[k]=0;
					break;
				}
			}
			if(!prel[j]) break;
		}
	}
	printf("%.10Lf",ans);
	return 0;
}

