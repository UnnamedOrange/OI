#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=30005;
vector<int>E[maxn];
int n,w[maxn];
bool p[maxn],vis[maxn];
ll ans=0;
void dfs(int step,ll now){
	if(step>n){chkmax(ans,now);return;}
	REP(i,1,n)if((p[i])&&(!vis[i])){
		vis[i]=1;
		REP(j,0,E[i].size()-1)p[E[i][j]]=1;
		dfs(step+1,now+1ll*w[i]*step);
		vis[i]=0;
		REP(j,0,E[i].size()-1)if(!vis[E[i][j]])p[E[i][j]]=0;
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
#endif
	n=read();
	int u,v;
	REP(i,1,n-1)
		u=read(),v=read(),E[u].pb(v),E[v].pb(u);
	REP(i,1,n)w[i]=read(),p[i]=read();
	dfs(1,0);
	write(ans,'\n');
	return 0;
}
