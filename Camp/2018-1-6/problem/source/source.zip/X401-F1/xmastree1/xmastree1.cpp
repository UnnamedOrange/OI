#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1e5+10,MAX=2e7+10;
int n,q,T,col[MAXN],head[MAXN],cnt,pre[MAXN];
struct edge
{
	int v,next;
}e[MAXN*2];
void addedge(int x,int y)
{
	e[++cnt]=(edge){y,head[x]};
	head[x]=cnt;
	return;
}
namespace case1
{
	int fa[MAXN];
	bool vis[MAXN];
	void dfs1(int u,int lst)
	{
		fa[u]=lst;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].v;
			if(v==lst)continue;
			dfs1(v,u);
		}
		return;
	}
	int query(int u,int l,int r)
	{
		int ret=0;
		if(col[u]>=l&&col[u]<=r)
			if(!vis[col[u]])++ret,vis[col[u]]=true;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].v;
			if(v==fa[u])continue;
			ret+=query(v,l,r);
		}
		return ret;
	}
	void solve()
	{
		dfs1(1,0);
		int lstans=0;
		while(q--)
		{
			int opt=read();
			if(opt==1)
			{
				int x=read()^lstans,l=read()^lstans,r=read()^lstans;
				memset(vis,0,sizeof(vis));
				printf("%d\n",lstans=query(x,l,r));
				if(!T)lstans=0;
			}
			else
			{
				int x=read()^lstans,c=read()^lstans;
				col[x]=c;
			}
		}
		return;
	}
}
struct Seg_T1
{
	int numv[MAX]={0},sumv[MAX]={0},lc[MAX]={0},rc[MAX]={0},cnt=0;
	void push_up(int o)
	{
		numv[o]=numv[lc[o]]+numv[rc[o]];
		return;
	}
	void update(int &o,int l,int r,int y,int k)
	{
		if(!y)return;
		if(!o)o=++cnt;
		if(l==r)
		{
			if(k==1&&!sumv[o])++numv[o];
			sumv[o]+=k;
			if(k==-1&&!sumv[o])--numv[o];
			return;
		}
		int mid=(l+r)>>1;
		if(y<=mid)update(lc[o],l,mid,y,k);
		else update(rc[o],mid+1,r,y,k);
		push_up(o);
		return;
	}
	int query(int &o,int l,int r,int yl,int yr)
	{
		if(!o)o=++cnt;
		if(yl<=l&&r<=yr)return numv[o];
		int mid=(l+r)>>1,ret=0;
		if(yl<=mid)ret=query(lc[o],l,mid,yl,yr);
		if(yr>mid)ret+=query(rc[o],mid+1,r,yl,yr);
		return ret;
	}
}T1;
struct Seg_T2
{
	int root[MAXN]={0};
	void update(int o,int l,int r,int y,int yy)
	{
		T1.update(root[o],1,n,col[pre[y]],-1);
		T1.update(root[o],1,n,yy,1);
		if(l==r)return;
		int mid=(l+r)>>1;
		if(y<=mid)update(o<<1,l,mid,y,yy);
		else update(o<<1|1,mid+1,r,y,yy);
		return;
	}
	int query(int o,int l,int r,int yl,int yr,int yll,int yrr)
	{
		if(yl<=l&&r<=yr)return T1.query(root[o],1,n,yll,yrr);
		int mid=(l+r)>>1,ret=0;
		if(yl<=mid)ret=query(o<<1,l,mid,yl,yr,yll,yrr);
		if(yr>mid)ret+=query(o<<1|1,mid+1,r,yl,yr,yll,yrr);
		return ret;
	}
}T2;
struct point
{
	int sum[MAXN],son[MAXN],fa[MAXN],sub[MAXN],top[MAXN],depth[MAXN],cnt;
	void dfs1(int u,int lst,int dep)
	{
		fa[u]=lst;
		sum[u]=1;
		depth[u]=dep;
		int t=0;
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].v;
			if(v==lst)continue;
			dfs1(v,u,dep+1);
			if(sum[v]>t)t=sum[v],son[u]=v;
			sum[u]+=sum[v];
		}
		return;
	}
	void dfs2(int u,int tp)
	{
		top[u]=tp;
		sub[u]=++cnt;
		pre[cnt]=u;
		if(son[u])dfs2(son[u],tp);
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].v;
			if(v==fa[u]||v==son[u])continue;
			dfs2(v,v);
		}
		return;
	}
}P;
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read();q=read();T=read();
	for(int i=1;i<=n;++i)col[i]=read();
	for(int i=1;i<n;++i)
	{
		int x=read(),y=read();
		addedge(x,y);addedge(y,x);
	}
	if(n<=5000)return case1::solve(),0;
	P.dfs1(1,0,1);
	P.dfs2(1,1);
	for(int i=1;i<=n;++i)
	{
		int x=col[i];col[i]=0;
		T2.update(1,1,n,P.sub[i],x);
		col[i]=x;
	}
	int lstans=0;
	while(q--)
	{
		int opt=read();
		if(opt==1)
		{
			int x=read()^lstans,l=read()^lstans,r=read()^lstans;
			printf("%d\n",lstans=T2.query(1,1,n,P.sub[x],P.sub[x]+P.sum[x]-1,l,r));
			if(!T)lstans=0;
		}
		else
		{
			int x=read()^lstans,c=read()^lstans;
			T2.update(1,1,n,P.sub[x],c);
			col[x]=c;
		}
	}
	return 0;
}
