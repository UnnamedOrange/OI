#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline LL read()
{
	LL x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=1e6+10;
LL n,sum,pri[MAXN],tot;
LL ans,mi[51];
bool ispri[MAXN];
void cal_prime()
{
	for(LL i=2;i<=LL(1e6);++i)
	{
		if(!ispri[i])pri[++tot]=i;
		for(LL j=1;j<=tot&&i*pri[j]<=LL(1e6);++j)
		{
			ispri[i*pri[j]]=true;
			if(i%pri[j]==0)break;
		}
	}
	return;
}
void init()
{
	cal_prime();
	mi[0]=1;
	for(LL i=1;i<=50;++i)mi[i]=(i+1)*(i+1);
	return;
}
LL cal(LL x,LL dep)
{
	LL cnt=0;
	while(x%pri[dep]==0)
	{
		x/=pri[dep];
		++cnt;
	}
	LL k=x==1?1:cal(x,dep+1),ret=0;
	if(!cnt)return k;
	for(LL i=0;i<=cnt;++i)
		ret+=(i&1?-1:1)*mi[i];
	sum+=cnt;
	return ret*k;
}
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	LL T=read();
	if(!T)return 0;
	init();
	while(T--)
	{
		n=read();
//		LL i=n;
		for(LL i=1;i<=n;++i)
		{
			sum=0;
			ans+=cal(i,1)*(sum&1?-1:1);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
