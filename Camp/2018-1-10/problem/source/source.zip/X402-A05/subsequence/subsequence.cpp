#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl
#define fst first
#define snd second

typedef long long LL;
typedef std::pair<int, int> Pii;

#ifdef __linux__
#define getchar getchar_unlocked
#endif
template <typename T> inline bool maximum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T> inline bool minimum(T &a, T b) { return a > b? a = b, 1 : 0; }
template <typename T>
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 4e3 + 10;

int n, m, k;
int A[N], B[N];

namespace bfer
{
	int C[N], ans = INT_MAX;

	bool check(int len)
	{
		int j = 1;
		for(int i = 1; i <= n; ++i){
			if(A[i] == C[j]) ++j;
			if(j > len) return false;
		}

		j = 1;
		for(int i = 1; i <= m; ++i){
			if(B[i] == C[j]) ++j;
			if(j > len) return false;
		}

		return true;
	}

	void dfs_search(int dep)
	{
		if(dep >= ans) return ;

		if(dep && check(dep)){
			minimum(ans, dep);
			return ;
		}

		for(int i = 1; i <= k; ++i){
			C[dep + 1] = i;
			dfs_search(dep + 1);
			C[dep + 1] = 0;
		}
	}

	void main()
	{
		dfs_search(0);
		printf("%d\n", ans);

		return ;
	}
}

namespace solver
{
	bool dp[2][N][N];
	int Next[N][N][2];

	void init()
	{
		for(int i = 0; i <= n; ++i){
			for(int c = 1; c <= k; ++c){
				if(i && Next[i-1][c][0] > i){
					Next[i][c][0] = Next[i-1][c][0];
					continue;
				}
				for(int j = i + 1; j <= n; ++j)
					if(A[j] == c){
						Next[i][c][0] = j;
						break;
					}
			}
		}
		for(int i = 0; i <= m; ++i){
			for(int c = 1; c <= k; ++c){
				if(i && Next[i-1][c][1] > i){
					Next[i][c][1] = Next[i-1][c][1];
					continue;
				}
				for(int j = i + 1; j <= m; ++j)
					if(B[j] == c){
						Next[i][c][1] = j;
						break;
					}
			}
		}
	}

	void main()
	{
		init();

		dp[0][0][0] = 1;
		for(int len = 0; ; ++len){
			int cur = len & 1, nxt = cur ^ 1;

			if(len && dp[cur][0][0]){
				printf("%d\n", len);
				return ;
			}

			for(int a = 0; a <= n; ++a){
				for(int b = 0; b <= m; ++b){
					if(!dp[cur][a][b]) continue;
					for(int i = 1; i <= k; ++i){
						int p1 = len && !a? 0 : Next[a][i][0];
						int p2 = len && !b? 0 : Next[b][i][1];
						dp[nxt][p1][p2] = 1;
					}
				}
			}

			memset(dp[cur], 0, sizeof dp[cur]);
		}

		return ;
	}
}

int main()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);

	read(n), read(m), read(k);
	for(int i = 1; i <= n; ++i) read(A[i]);
	for(int i = 1; i <= m; ++i) read(B[i]);

	if(n <= 18 && m <= 18 && k == 2) bfer::main();
	else solver::main();

	return 0;
}
