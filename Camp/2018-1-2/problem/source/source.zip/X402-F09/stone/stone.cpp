#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int mo=1000000007;
int w[100005];
int main(){
	freopen("stone.in","r",stdin); freopen("stone.out","w",stdout);
	int n=read(),a=read(),b=read(),x=1;
	For(i,1,n) w[i]=read();
	if (a==b){
		For(i,1,n-1) x=x<<1,x=(x>=mo)?x-mo:x;
		printf("0 0 %d %d\n",x,x);
	}
	return 0;
}
