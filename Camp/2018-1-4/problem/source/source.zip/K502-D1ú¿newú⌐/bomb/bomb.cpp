#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;

const int MAXN = 1e7 + 10;
int cnt = 0;
int ans = 0;
int tot = 0;
int top = 0; 
int head[MAXN];
int vis[MAXN];
int s[MAXN];
int col[MAXN];
int e[MAXN][2];
int dfn[MAXN];
int low[MAXN];
int in[MAXN];
int num[MAXN];
int f[MAXN];
int qq[MAXN];
int step[MAXN];
int wait[MAXN];
int color = 0;
int n, m;
struct edge {
	int v;
	int next;
} g[MAXN];

queue<int> q;
void addedge(int u, int v)
{
	g[++cnt].v = v;
	g[cnt].next = head[u];
	head[u] = cnt;
}
void open()
{
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
}


void tuopu()
{
	for(int i = 1; i <= color; i++) {
		if(in[i] == 0) {
			f[i] = num[i];
			q.push(i);
		}
	}
	while(!q.empty()) {
		int t = q.front();
		q.pop();
		for(int j = head[t]; j; j = g[j].next) {
			int to = g[j].v;
			f[to] = max(f[t], f[to]);
			in[to]--;
			if(in[to] == 0) {
				f[to] += num[to];
				q.push(to);
			}
		}
	}
}

void tuopu2()
{
	int ta = 0;
	int ha = 0;
	for(int i = 1; i <= color; i++) {
		if(in[i] == 0) {
			f[i] = num[i];
			ta++;
			qq[ta - 1] = i;
		}
	}
	while(ha < ta) {
		int t = qq[ha];
		ha++;
		for(int j = head[t]; j; j = g[j].next) {
			int to = g[j].v;
			f[to] = max(f[t], f[to]);
			in[to]--;
			if(in[to] == 0) {
				f[to] += num[to];
				ta++;
				qq[ta - 1] = to;
			}
		}
	}
}
int tarjan(int x)
{
	s[top++] = x;
	vis[x] = 1;
	dfn[x] = low[x] = ++tot;
	for(int j = head[x]; j; j = g[j].next) {
		int to = g[j].v;
		if(vis[to] == 1) {
			low[x] = min(low[x], dfn[to]);
		} else if(!vis[to]) {
			tarjan(to);
			low[x] = min(low[x], low[to]);
		}
	}
	if(dfn[x] == low[x]) {
	//	cout<<x<<endl;
		color++;
		while(s[top - 1] != x) {
			vis[s[top - 1]] = 2;
			col[s[top - 1]] = color;
			num[color]++;
			top--;
		}
		vis[x] = 2;
		col[x] = color;
		num[color]++;
		top--;
	}
}
void close()
{
	fclose(stdin);
	fclose(stdout);
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}
int main()
{
	open();
	n = read(), m = read();
	for(int i = 1; i <= m; i++) {
		e[i][0] = read(), e[i][1] = read();
		addedge(e[i][0], e[i][1]); 
	}
	for(int i = 1; i <= n; i++) {
		if(!vis[i]) {
			tarjan(i);
		} 
	}
	memset(head, 0, sizeof head);
	cnt = 0;
	/*for(int i = 1; i <= n ;i++) {
		cout<<col[i]<<" ";
	}
	cout<<endl;*/
	for(int i  = 1; i <= m; i++) {
		int a = col[e[i][0]], b = col[e[i][1]];
		if(a != b) {
			in[b]++;
			addedge(a, b);
		}
	}
	//cout<<color<<endl;
	/*for(int i = 1; i <= color; i++) {
		cout<<num[i]<<" ";
	}
	cout<<endl;*/
	if(n <= 1000) {
		tuopu();
	} else {
		tuopu2();
	}
	//cout<<ans<<endl;
	for(int i = 1; i <= color; i++) {
		ans = max(ans, f[i]); 
	//	cout<<f[i]<<endl;
	}
	//cout<<endl;
	printf("%d\n", ans);
	close();
	return 0;
}
