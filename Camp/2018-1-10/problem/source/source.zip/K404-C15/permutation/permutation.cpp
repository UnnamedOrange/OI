#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 100005, P = 998244353;
int n, a[N], per[12], fac = 1;
ll ans = 0;
bool vis[12], flag = 1;
bool check(){
	for(int i = 1; i <= n; i++){
		vis[i] = 0;
		if(a[i] && a[i] != per[i])
			return 0;
		}
	for(int i = 1; i <= n; i++)
		if(!vis[i]){
			vis[i] = 1;
			int cnt = 1;
			for(int j = per[i]; j != i; j = per[j])
				cnt++, vis[j] = 1;
			if(cnt & 1) return 0;
		}
	return 1;
}

int main(){
	
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	
	read(n);
	if(n & 1){
		puts("0");
		return 0;
	}
	for(int i = 1; i <= n; i++){
		read(a[i]);
		if(a[i]) flag = 0;
	}
	if(n <= 8){
		for(int i = 1; i <= n; i++)
			per[i] = i, fac *= i;
		for(int i = 1; i <= fac; i++){
			if(check()) ans++;
			next_permutation(per + 1, per + n + 1);
		}
		write(ans), enter;
		return 0;
	}
	if(flag){
		ans = 1;
		for(int i = 1; i <= n; i += 2)
			ans = ans * i % P * i % P;
		write(ans), enter;
		return 0;
	}
	puts("0");
	
	return 0;
}
