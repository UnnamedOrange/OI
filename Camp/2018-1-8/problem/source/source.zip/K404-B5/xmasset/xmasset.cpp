#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define PDI pair < long double, int >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 60000007;
const int BUFSIZE = 20000007;
const int BS = 3;
const int MAXS = 43;

int t;
char buf[BUFSIZE], *pb;
int rt;
string str[MAXS];
int nxt[MAXS][2];



void init ();
void input ();
void work ();

int read ()
{
	int num = 0;
	char ch;
	for ( ch = *(pb++); ch < '0' || ch > '9'; ch = *(pb++) );
	for ( ; ch >= '0' && ch <= '9'; ch = *(pb++) ) num = num * 10 + ch - '0';
	return num;
}

namespace task1
{
	int n, q;
	int vx[MAXN], vy[MAXN];
	int a[MAXN];
	string cur;
	
	void input ()
	{
		n = read (), q = read ();
		lpi ( i, 1, q ) vx[i] = read (), vy[i] = read ();
	}
	
	int enc ( int x, int y )
	{
		int t = 0;
		while ( ( x & 1 ) == ( y & 1 ) ) ++t, x >>= 1, y >>= 1;
		return ( t << 1 | ( x & 1 ) );
	}
	
	void work ()
	{
		lpi ( i, 1, q ) a[i] = enc ( vx[i], vy[i] );
		
		lpi ( i, 1, q ) cur += str[a[i]];
		
		if ( cur.size () > q * 3 ){
			cout << "ERROR!" << endl;
			return;
		}
		
		int size = cur.size ();
		lp ( i, 0, 10 ) cur += '0';
		int tt = 0, cv;
		for ( int i = 0; i < size; i += 3 ){
			++tt;
			cv = ( ( cur[i] - '0' ) << 2 ) + ( ( cur[i+1] - '0' ) << 1 ) + ( cur[i+2] - '0' );
			if ( cv == 0 ) cv = 9;
			printf ( "%d\n", cv );
		}
		for ( ; tt < q; ++tt ) printf ( "0\n" );
	}
}

namespace task2
{
	int n, q;
	int vn[MAXN], h[MAXN];
	string cur;
	
	void input ()
	{
		n = read (), q = read ();
		lpi ( i, 1, q ) vn[i] = read (), h[i] = read ();
	}
	
	int dfs ( int now, int &ip )
	{
		if ( nxt[now][0] == -1 && nxt[now][1] == -1 ) return now;
		int tmp = cur[ip] - '0';
		++ip;
		dfs ( nxt[now][tmp], ip );
	}
	
	void work ()
	{
		lpi ( i, 1, q ){
			if ( h[i] == 9 ) h[i] = 0;
			cur += ( h[i] >> 2 & 1 ) + '0';
			cur += ( h[i] >> 1 & 1 ) + '0';
			cur += ( h[i] & 1 ) + '0';
		}
		
		int il = 0;
		int nv, np;
		lpi ( i, 1, q ){
			nv = dfs ( rt, il );
			np = nv >> 1;
			nv &= 1;
			if ( ( vn[i] >> np & 1 ) == nv ) printf ( "yes\n" );
			else printf ( "no\n" );
		}
	}
}



int main ()
{
	init ();
	input ();
	work ();
}



void dfs ( int now, string ps )
{
	if ( now == -1 ) return;
//	cerr << now << " " << ps << endl;
	str[now] = ps;
	dfs ( nxt[now][0], ps + '0' );
	dfs ( nxt[now][1], ps + '1' );
}

void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "xmasset" );
	
	fread ( buf, 1, BUFSIZE, stdin );
	pb = buf;
	
	INIT ( nxt, -1 );
	PQ < PDI, AR(PDI), greater < PDI > > pq;
	LD cur = 0.5;
	lp ( i, 0, 10 ){
		cur /= 2;
		pq.push ( MP ( cur, i << 1 ) );
		pq.push ( MP ( cur, i << 1 | 1 ) );
	}
	PDI mini, sm;
	int kc = 19;
	while ( !pq.empty () ){
		mini = pq.top (); pq.pop ();
		if ( pq.empty () ) break;
		sm = pq.top (); pq.pop ();
		++kc;
		nxt[kc][0] = mini.SS, nxt[kc][1] = sm.SS;
		pq.push ( MP ( mini.FF + sm.FF, kc ) );
	}
	rt = pq.top ().SS;
	dfs ( rt, string ( "" ) );
}

void input ()
{
	t = read ();
	if ( t == 1 ) task1::input ();
	else task2::input ();
}

void work ()
{
	if ( t == 1 ) task1::work ();
	else task2::work ();
}
