#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
const int maxn=1e5+5;
int n,xi[maxn],a,b,ai[maxn][2],bit[25],ans1,ans2,ans3,ans4;
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
void solve1()
{
	bit[1]=1;
	for(int i=2;i<=n;i++)
		bit[i]=bit[i-1]<<1;
	ans3++;
	for(int s=1,v,s1,s0;s<(1<<n);s++)
	{
		s1=0;
		s0=0;
		for(v=1;v<=n;v++)
			if(bit[v]&s)
			{
				s1^=ai[v][1];
				s0^=ai[v][0];
			}
		if(s1&&s0)
			ans1++;
		if(s1&&!s0)
			ans2++;
		if(!s1&&s0)
			ans3++;
		if(!s1&&!s0)
			ans4++;
	}
	printf("%d %d %d %d\n",ans1,ans4,ans2,ans3);
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	read(n);
	read(a);
	read(b);
	for(int i=1;i<=n;i++)
	{
		read(xi[i]);
		if(xi[i]%(a+b)>=a)
			ai[i][1]=1;
		if(xi[i]%(a+b)<b)
			ai[i][0]=1;
	}
	if(n<=20)
		solve1();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
