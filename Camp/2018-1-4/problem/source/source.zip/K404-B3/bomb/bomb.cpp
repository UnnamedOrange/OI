#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<ctime>
using namespace std;
#define inf 1000000007
#define ll long long
#define N 1000010
char xB[1<<15],*xS=xB,*xTT=xB;
#define getc() (xS==xTT&&(xTT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xTT)?0:*xS++)
#define isd(c) (c>='0'&&c<='9')
inline int rd(){
	char xchh;
	int xaa;
    while(xchh=getc(),!isd(xchh));(xaa=xchh-'0');
    while(xchh=getc(),isd(xchh))xaa=xaa*10+xchh-'0';return xaa;
}
int lj[N],fro[N],to[N],cnt;
inline void add(int a,int b){fro[++cnt]=lj[a];to[cnt]=b;lj[a]=cnt;}
int n,m;
int dfn[N],low[N],tim,q[N],tq,num[N],tot,sz[N];
bool vs[N];
void tar(int x)
{
	dfn[x]=low[x]=++tim;
	q[++tq]=x;vs[x]=1;
	for(int i=lj[x];i;i=fro[i])
	{
		if(!dfn[to[i]])
		{
			tar(to[i]);
			low[x]=min(low[x],low[to[i]]);
		}
		else if(vs[to[i]]) low[x]=min(low[x],dfn[to[i]]);
	}
	if(dfn[x]==low[x])
	{
		++tot;sz[tot]=1;
		while(q[tq]!=x){num[q[tq]]=tot;vs[q[tq--]]=0;sz[tot]++;}
		num[x]=tot;vs[x]=0;tq--;
	}
}
int Lj[N],Fro[N],To[N],Cnt;
inline void Add(int a,int b){Fro[++Cnt]=Lj[a];To[Cnt]=b;Lj[a]=Cnt;}
int du[N];
void rebuild()
{
	register int i,j;
	for(i=1;i<=n;i++)
	{
		for(j=lj[i];j;j=fro[j])
		{
			if(num[i]==num[to[j]]) continue;
			Add(num[to[j]],num[i]);
			du[num[i]]++;
		}
	}
}
int mx[N],l,r;
void bfs()
{
	register int x,y,i;
	while(l<r)
	{
		x=q[l++];
		mx[x]+=sz[x];
		for(i=Lj[x];i;i=Fro[i])
		{
			y=To[i];
			mx[y]=max(mx[y],mx[x]);
			du[y]--;if(!du[y]) q[r++]=y;
		}
	}
}
int ans;
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=rd();m=rd();
	register int x,y,i;
	for(i=1;i<=m;i++)
	{
		x=rd();y=rd();
		add(x,y);
	}
	for(i=1;i<=n;i++) if(!dfn[i]) tar(i);
	rebuild();
	for(i=1;i<=tot;i++)
		if(!du[i]) q[r++]=i;
	bfs();
	for(i=1;i<=tot;i++) ans=max(ans,mx[i]);
	printf("%d\n",ans);
	return 0;
}
/*
5 4
1 2
2 3
3 1
4 5
*/