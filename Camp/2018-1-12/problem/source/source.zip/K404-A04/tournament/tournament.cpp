#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
const int maxn=100010;
const int mod=998244353;
int n,K;
bool mp[10][10][10];
ll ans;
ll ksm(ll a,int b){ll r=1;for(;b;b>>=1){if(b&1)r=r*a%mod;a=a*a%mod;}return r;}
void find(int x,int y)
{
	if(x>n)
	{
		for(int k=2;k<=K;k++)
		{
			memset(mp[k],0,sizeof(mp[k]));
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)
					if(i!=j||k==K)
					for(int d=1;d<=n;d++)
						mp[k][i][j]|=(mp[k-1][i][d]&&mp[1][d][j]);
		}
		for(int i=1;i<=n;i++)
			if(mp[K][i][i]) {ans++;break;}							 
		return;
	}
	if(y>n) {find(x+1,x+2);return;}
	mp[1][x][y]=1;
	find(x,y+1);
	mp[1][x][y]=0;
	mp[1][y][x]=1;
	find(x,y+1);
	mp[1][y][x]=0;
}
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&K);
	
	if(K==3)
	{
		ans=1;
		for(int i=1;i<=n;i++)
			ans=ans*i%mod;	
		ans=(ksm(2,n*(n-1)/2)-ans+mod)%mod;	
	}
	else find(1,2);
	printf("%lld",ans);
	return 0;
}
