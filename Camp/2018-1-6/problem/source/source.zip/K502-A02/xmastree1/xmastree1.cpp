#include<cstdio>
#include<iostream>
#include<vector>
#include<cstring>
#define maxn 1010
using namespace std;
vector<int> g[maxn];
int a[maxn],d[maxn],f[maxn],sum=0;
void DFS(int now,int fa){
	f[now]=fa;
	for (int i=0;i<g[now].size();i++){
		int son=g[now][i];
		if (son!=fa) DFS(son,now);
	}
}
void dfs(int now,int fa,int l,int r){
	//printf("%d $%d$\n",now,a[now]);
	if (!d[a[now]] && a[now]>=l && a[now]<=r) sum++,d[a[now]]=1;
	for (int i=0;i<g[now].size();i++){
		int son=g[now][i];
		if (son!=fa) dfs(son,now,l,r);
	}
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int n,q,t;
	cin>>n>>q>>t;
	for (int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for (int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		g[x].push_back(y);
		g[y].push_back(x);
	}
	DFS(1,0);
	int lans=0;
	for (int i=1;i<=q;i++){
		int k;
		scanf("%d",&k);
		//for (int i=1;i<=n;i++) cout<<a[i]<<" "; cout<<endl;
		if (k==1){
			int u,l,r;
			scanf("%d%d%d",&u,&l,&r);
			if (t) {u^=lans; l^=lans; r^=lans;}
			sum=0;
			memset(d,0,sizeof(d));
			dfs(u,f[u],l,r);
			lans=sum;
			printf("%d\n",sum);
		}else{
			int u,c;
			scanf("%d%d",&u,&c);
			if (t) {u^=lans; c^=lans;}
			//cout<<u<<" "<<c<<endl;
			a[u]=c;
		}
	}
	return 0;
}
