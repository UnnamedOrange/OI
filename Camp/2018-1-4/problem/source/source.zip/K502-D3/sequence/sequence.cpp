#include <cstdio>
#include <cstring>
#include <algorithm>
#define ele int
using namespace std;
#define maxn 30
ele n,ans,a[maxn];
bool dfs(ele i){
	if (i==ans){
		for (int j=0; j<n-1; ++j)
			if (a[j]>a[j+1]) return false;
		return true;
	}
	bool res=false;
	for (int j=0; j<n; ++j){
		for (int k=0; k<j-k; ++k) swap(a[k],a[j-k]);
		res=res || dfs(i+1);
		for (int k=0; k<j-k; ++k) swap(a[k],a[j-k]);
		if (res) return true;
	}
	return false;
}
int main(){
	freopen("sequence.in","r",stdin); freopen("sequence.out","w",stdout);
	ele T;
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n);
		for (int i=0; i<n; ++i) scanf("%d",a+i);
		ans=0;
		while (!dfs(0)) ++ans;
		printf("%d\n",ans);
	}
	return 0;
}