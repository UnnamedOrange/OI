#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
const long long Mod=998244353;
const double eps=1e-8;
int n,du[100010],size[100010];
char c[100010];
long long ans;
int cnt,head[100010],to[200010],nxt[200010];
bool vis[100010];
double ss;
void add(int x,int y)
{
	cnt++;
	to[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
void dfs(int x,int fa)
{
	size[x]=1;
	for (int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if (y==fa)
		{
			continue;
		}
		dfs(y,x);
		size[x]+=size[y];
	}
}
void solve()
{
	dfs(1,0);
	ans=1;
	for (int i=head[1];i;i=nxt[i])
	{
		int y=to[i];
		ans=ans*size[y]%Mod;
	}
	ans++;
	if (ans>=Mod)
	{
		ans-=Mod;
	}
	printf("%lld\n",ans);
}
void work(int x,int k,double now,double p)
{
	bool f=false;
	if (c[x]=='1' || !vis[x])
	{
		now+=1.0;
		f=true;
	}
	if (du[x]==1 || k==30)
	{
		ss+=now*p;
		if (f)
		{
			now-=1.0;
		}
		return;
	}
	vis[x]=true;
	for (int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		work(y,k+1,now,p/(double)du[x]);
	}
	vis[x]=false;
	if (f)
	{
		now-=1.0;
	}
}
long long pw(long long x,long long y)
{
	long long res=1;
	while (y)
	{
		if (y&1)
		{
			res=res*x%Mod;
		}
		y>>=1;
		x=x*x%Mod;
	}
	return res;
}
void print(int x,int y)
{
	printf("%lld\n",pw(x,Mod-2)*y%Mod);
}
int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",c+1);
	for (int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
		du[x]++;
		du[y]++;
	}
	bool f=true;
	for (int i=2;i<=n;i++)
	{
		if (du[i]>1 && c[i]=='0')
		{
			f=false;
			break;
		}
	}
	if (n>10 || f)
	{
		solve();
		return 0;
	}
	work(1,0,0.0,1.0);
	//printf("%.12lf\n",ss);
	double i=1.0;
	while (true)
	{
		int x=(ss*i+eps);
		if (fabs((double)(x)-ss*i)<=eps)
		{
			print((int)(i+eps),x);
			//printf("%.0lf %d",i,x);
			return 0;
		}
		i+=1.0;
	}
	return 0;
}
/*
6
000000
1 2
1 3
3 4
4 5
2 6
*/
