#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;

#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
int TYPE, N, T, t;
void init()
{
    
}
int encode(int x, int y)
{for(t = 0; t < 10 && !(((x^y)>>t)&1); t++); return (t<<1|1)+((x>>t)&1);}
bool decode(int q, int h)
{
	switch(h)
	{
		case  1: return !((q>>0)&1);
		case  2: return (q>>0)&1;
		case  3: return !((q>>1)&1);
		case  4: return (q>>1)&1;
		case  5: return !((q>>2)&1);
		case  6: return (q>>2)&1;
		case  7: return !((q>>3)&1);
		case  8: return (q>>3)&1;
		case  9: return !((q>>4)&1);
		case 10: return (q>>4)&1;
		case 11: return !((q>>5)&1);
		case 12: return (q>>5)&1;
		case 13: return !((q>>6)&1);
		case 14: return (q>>6)&1;
		case 15: return !((q>>7)&1);
		case 16: return (q>>7)&1;
		case 17: return !((q>>8)&1);
		case 18: return (q>>8)&1;
		case 19: return !((q>>9)&1);
		case 20: return (q>>9)&1;
	}
}
int main()
{
	TYPE = read(), N = read(), T = read(), init();
    for(int x, y; T--; x = read(), y = read(), TYPE<2 ? printf("%d\n", encode(x, y)) : puts(decode(x, y) ? "yes" : "no")); return 0;
}
/*
A
1
5 6
1 2
4 5
1 2
3 5
4 5
5 2

B
2
5 6
1 2
4 1
2 2
3 2
5 1
2 2
*/
