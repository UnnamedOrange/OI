#include <cstdio>
#include <cstdlib>
#include <ctime>

inline int read(){
    char ch=getchar(); int x=0,sgn=1;
    for (;ch<'0'||ch>'9';ch=getchar())
        if (ch=='-') sgn=-1;
    while (ch>='0'&&ch<='9')
        x=x*10+ch-'0',ch=getchar();
    return x*sgn;
}

#define N ((int)1e5+10)
int color[N];

struct Tree{
	int head[N],to[N<<1],next[N<<1],cnt;
	void addedge(int x, int y){
		to[++cnt]=x,next[cnt]=head[y],head[y]=cnt;
		to[++cnt]=y,next[cnt]=head[x],head[x]=cnt;
	}
	int dfn[N],end[N],node[N],time;
	void dfs(int x){
		dfn[x]=++time,node[time]=x;
		for (int i=head[x];i;i=next[i])
			if (!dfn[to[i]]) dfs(to[i]);
		end[x]=time;
	}
}tree;

struct Treap{
    int l[N*100],r[N*100],v[N*100];
    int w[N*100],size[N*100],c[N*100],cnt;
    void rotate(int &k, bool d){
        int t=(d?l[k]:r[k]);
        d?(l[k]=r[t],r[t]=k):(r[k]=l[t],l[t]=k);
        size[t]=size[k],size[k]=size[l[k]]+size[r[k]]+1,k=t;
    }
    int insert(int &k, int x){
        if (k==0){
            k=++cnt,v[k]=x,
            size[k]=1,c[k]=1,w[k]=rand();
            return 1;
        }
        if (v[k]==x) {c[k]++; return 0;}
        else{
            int *t=((x<v[k])?(&l[k]):(&r[k]));
            int mark=insert(*t,x); size[k]+=mark;
            if (w[*t]<w[k]) rotate(k,x<v[k]);
            return mark;
        }
    }
    int del(int &k, int x){
        if (k==0) return 0;
        if (x==v[k]){
            if (c[k]>1) {c[k]--; return 0;}
            else if (!l[k]||!r[k])
				{k=l[k]+r[k]; return 1;}
            else{
                rotate(k,w[l[k]]<w[r[k]]);
                return del(k,x);
            }
        }
        else{
        	int mark=x<v[k]?del(l[k],x):del(r[k],x);
            size[k]-=mark; return mark;
		}
    }
    int rank(int k, int x){
        if (k==0) return 0;
        if (x<=v[k]) return rank(l[k],x);
        else return rank(r[k],x)+size[l[k]]+1;
    }
    int query(int rt, int l, int r){
    	return rank(rt,r+1)-rank(rt,l);
	}
}tr;

struct Segment_tree{
    int rt[N<<2];
    #define lson k<<1
    #define rson k<<1|1
	#define mid (l+r>>1)
    inline void build(int l, int r, int k){
    	for (int i=l;i<=r;i++)
    		tr.insert(rt[k],color[tree.node[i]]);
    	if (l<r)
    		build(l,mid,lson),
    		build(mid+1,r,rson);
    }
    inline void update(int l, int r, int k, int p, int oldc, int newc){
    	tr.del(rt[k],oldc); tr.insert(rt[k],newc);
    	if (l==p&&r==p) return;
    	if (p<=mid) update(l,mid,lson,p,oldc,newc);
    	else update(mid+1,r,rson,p,oldc,newc);
	}
    inline int query(int l, int r, int k, int L, int R, int lc, int rc){
        if (L<=l&&r<=R) return tr.query(rt[k],lc,rc);
        int ans=0;
        if (L<=mid) ans+=query(l,mid,lson,L,R,lc,rc);
        if (mid<R) ans+=query(mid+1,r,rson,L,R,lc,rc);
        return ans;
    }
}seg;

int main(){
	srand((int)time(NULL));
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int n=read(),m=read(),t=read();
	for (int i=1;i<=n;i++)
		color[i]=read();
	for (int i=1;i<n;i++)
		tree.addedge(read(),read());
	tree.dfs(1); seg.build(1,n,1);
	for (int ans=0;m--;ans*=t){
		if (read()==1){
			int x=read()^ans,
				l=read()^ans,
				r=read()^ans;
			ans=seg.query(1,n,1,tree.dfn[x],tree.end[x],l,r);
			printf("%d\n",ans);
		}
		else{
			int x=read()^ans,
				c=read()^ans;
			seg.update(1,n,1,tree.dfn[x],color[x],c);
			color[x]=c;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

