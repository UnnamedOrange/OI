#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define ll long long
#define N 110
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
//I'm too young too simple,and sometimes naive.
int T,n,a[N],ans;
void rev(int p)
{
	for(int i=1;i<=(p>>1);i++) swap(a[i],a[p-i+1]);
}
void sol(int x)
{
	int p;
	for(int i=1;i<x;i++) if(a[i]==x){p=i;break;}
	if(p!=1){ans++;rev(p);}
	ans++;rev(x);
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	T=rd();
	while(T--)
	{
		n=rd();ans=0;
		for(int i=1;i<=n;i++) a[i]=rd();
		for(int i=n;i;i--) if(a[i]!=i) sol(i);
		printf("%d\n",ans);
	}
	return 0;
}