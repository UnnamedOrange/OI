#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=3001000;
int prim[maxn],ilem;
bool vis[maxn];
int mu[maxn],d[maxn],las[maxn],cnt[maxn];
long long sum[maxn];
void csh(int n){
	int v;
	cnt[1]=0,d[1]=1,mu[1]=1,las[1]=1;
	for(int i=2;i<=n;i++){
		if(!vis[i]){
			prim[++ilem]=i;
			las[i]=1;
			cnt[i]=1;
			d[i]=d[las[i]]*(2*cnt[i]+1);
			mu[i]=-1;
		}
		for(int j=1;j<=ilem;j++){
			v=i*prim[j];
			if(v>n) break;
			vis[v]=1;
			if(i%prim[j]==0){
				las[v]=las[i];
				cnt[v]=cnt[i]+1;
				d[v]=d[las[v]]*(2*cnt[v]+1);
				break;
			}
			las[v]=i;
			cnt[v]=1;
			d[v]=d[las[v]]*(2*cnt[v]+1);
			mu[v]=-mu[i];
		}
	}
	for(int i=1;i<=n;i++)
		sum[i]=sum[i-1]+d[i];
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	csh(3000000);
	int T,n;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		printf("%lld\n",sum[n]);
	}
	return 0;
}
