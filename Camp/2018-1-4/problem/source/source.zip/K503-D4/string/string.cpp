#include<bits/stdc++.h>
#define maxn 2000
using namespace std;
string a[10];
int n,m,ch[maxn],len[10],ans;
void sc()
{
	for (int i=1;i<=m;i++)
		ch[2*m-i+1]=1-ch[i];
	for (int i=1;i<=n;i++)
	{
		int flag=0;
		for (int j=1;j<=2*m-len[i]+1;j++)
		{
			flag=1;
			for (int k=0;k<=len[i]-1;k++)
				if (ch[j+k]!=(a[i][k]-'0')) {flag=0; break;}
			if (flag) break;
		}
		if (flag==0) return;
	}
	ans++;
}
void work(int dep)
{
	if (dep>m) sc();
	else
	for (int i=0;i<=1;i++)
	{
		ch[dep]=i;
		work(dep+1);
	}
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
	{
		cin>>a[i];
		len[i]=a[i].length();
	}
	work(1);
	printf("%d\n",ans);
	return 0;
}
