#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#define LL long long
using namespace std;
template<class T>
inline T read(T& x)
{
	x=0;char ch=getchar();int w=1;
	while(ch>'9'||ch<'0'){if(ch=='-')w=-1;ch=getchar();};
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();};
	x*=w;
}
LL t,n,W,p,q,x[100010],y[100010],z[100010],a[100010],b[100010],c[100010],d[100010],e[100010],f[100010],w[100010],r[100010],X[100010],Y[100010];
bool judge()
{
	bool flag=1;
	for(int i=1;i<=q;i++)
	{
		if(r[i]==0)
		{
			flag&=(w[X[i]]<=w[Y[i]]);
		}
		if(r[i]==1)
		{
			flag&=(w[X[i]]==w[Y[i]]);
		}
		if(r[i]==2)
		{
			flag&=(w[X[i]]<w[Y[i]]);
		}
	}
	return flag;
}
LL solve()
{
	LL ret=0;
	for(int i=1;i<=p;i++)
	{
		ret+=a[i]*abs(w[x[i]]-w[y[i]])+b[i]*abs(w[y[i]]-w[z[i]])+c[i]*abs(w[z[i]]-w[x[i]])+d[i]*(w[x[i]]-w[y[i]])+e[i]*(w[y[i]]-w[z[i]])+f[i]*(w[z[i]]-w[x[i]]);
	}
//	cout<<ret<<endl;
	for(int i=1;i<=n;i++)
	{
//		cout<<w[i]<<' ';
		ret+=w[i];
	}
//	cout<<endl;
	return ret;
}
int main()
{
//	freopen("variable.in","r",stdin);
//	freopen("variable.out","w",stdout);
	read(t);
	while(t--)
	{
		read(n);
		read(W);
		read(p);
		read(q);
		for(int i=1;i<=p;i++)
		{
			read(x[i]);
			read(y[i]);
			read(z[i]);
			read(a[i]);
			read(b[i]);
			read(c[i]);
			read(d[i]);
			read(e[i]);
			read(f[i]);
		}
		for(int i=1;i<=q;i++)
		{
			read(X[i]);
			read(Y[i]);
			read(r[i]);
		}
		LL ret=1e18;
		for(int i=0;i<(1<<n);i++)
		{
			int temp=i;
			for(int j=1;j<=n;j++)
			{
				w[j]=(temp&1)?W:-W;
				temp>>=1;
			}
			if(judge())
			{
				ret=min(ret,solve());
			}
		}
		cout<<ret<<endl;
	}
	return 0;
}
