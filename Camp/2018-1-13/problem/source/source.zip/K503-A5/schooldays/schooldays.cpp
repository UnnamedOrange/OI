#include <iostream>
using namespace std;
int main() {
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	cout << -1 << endl;
	return 0;
}

