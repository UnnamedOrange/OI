import os
import time

T = 10000

for i in range(T):
	os.system("gen.py")
	os.system("xmasdag.exe")
	os.system("2.exe")
	s = os.system("fc xmasdag.out 2.out")
	if (s != 0):
		print("FOUND")
		break
	print("SUCCESS" + str(i))

time.sleep(10000)