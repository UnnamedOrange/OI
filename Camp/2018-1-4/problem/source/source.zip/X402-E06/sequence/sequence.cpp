#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 100;

int ans;
int x[N + 5], n;

bool chk() {
    for(int i = 1; i <= n; ++i) 
        if(x[i] != i) return false;
    return true;
}

int expect() {
    int res = 0;
    for(int i = 1; i <= n; ++i) {
        res += (std::abs(x[i] - x[i+1]) != 1);
    }
    return res;
}

bool dfs(int cur) {
    if(expect() + cur > ans) return false;
    if(chk()) { return true; }

    for(int i = 1; i <= n; ++i) {
        std::reverse(x + 1, x + i + 1);
        if(dfs(cur + 1)) return true;
        std::reverse(x + 1, x + i + 1);
    }
    return false;
}

void solve() {
    read(n);
    for(int i = 1; i <= n; ++i) read(x[i]);
    x[n+1] = n+1;

    for(ans = 0; ; ++ ans) {
        if(dfs(0)) break;
    }
    printf("%d\n", ans);
}

int main() {
    freopen("sequence.in", "r", stdin);
    freopen("sequence.out", "w", stdout);

    int T;
    read(T);
    while(T--) solve();

    return 0;
}
