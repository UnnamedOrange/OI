#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v=-v;
}
vector<int> q[15];
int fa[15];
int w[15], r[15];
inline void dfs(int x) {
	int v;
	for(int i = 0 ; i < q[x].size(); ++i) {
		v = q[x][i];
		if(v != fa[x]) {
			fa[v] = x;
			dfs(v);
		}
	}
}
int a[15];
bool vis[15];
int ans;
int n;

inline void calc() {
	memset(vis, 0, sizeof(vis));
	int ret = 0;
	vis[0] = 1;
	for(int i = 1; i <= n; ++i) {
		if(vis[fa[a[i]]]) {
			ret += i * w[a[i]];
			vis[a[i]] = 1;
		} else {
			return;
		}
	}
	ans = max(ans, ret);
	return;
}
int main () {
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	R(n);
	int x, y;
	for(int i = 1; i < n; ++i) {
		R(x), R(y);
		q[x].push_back(y);
		q[y].push_back(x);
	}
	for(int i = 1; i <= n; ++i) {
		R(w[i]), R(r[i]);
	}
	for(int rt = 1; rt <= n; ++rt) {
		if(r[rt]) {
			memset(fa, 0, sizeof(fa));
			dfs(rt);
		}
		for(int i = 1; i <= n; ++i) {
			a[i] = i;
		}
		do {
			calc();
		} while(next_permutation(a + 1, a + n + 1));
	}
	printf("%d", ans);
}
