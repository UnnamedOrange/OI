#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MOD = 998244353;
const int MAXN = int(2e5);

int n;

int p[MAXN + 5], indeg[MAXN + 5];

inline void input()
{
	n = read<int>();
	for(int i = 1; i <= n; ++i) ++indeg[p[i] = read<int>()];
}

inline int calc(int n0)
{
	if(n0 & 1) return 0;
	int res = 1;
	for(int i = 1; i < n0; i += 2) res = LL(res) * i % MOD;
	return int(LL(res) * res % MOD);
}

int vis[MAXN + 5], cnt, flag;

inline void dfs(int u)
{
	++cnt, vis[u] = 1;
	if(!p[u]) return;

	if(vis[p[u]])
	{
		flag = 1;
		return;
	}
	else dfs(p[u]);
}

inline void solve()
{
	int n0 = 0, m0 = 0;
	for(int i = 1; i <= n; ++i)
		if(!indeg[i] && !vis[i])
		{
			flag = 0, cnt = 0, dfs(i);
			if(flag && (cnt & 1))
			{
				puts("0");
				return;
			}
			if(!flag)
			{
				if(cnt & 1) ++n0;
				else ++m0;
			}
		}
	for(int i = 1; i <= n; ++i)
		if(!vis[i])
		{
			flag = 0, cnt = 0, dfs(i);
			if(flag && (cnt & 1))
			{
				puts("0");
				return;
			}
			if(!flag)
			{
				if(cnt & 1) ++n0;
				else ++m0;
			}
		}

	int ans = calc(n0);
	for(int i = 1; i <= m0; ++i) ans = LL(ans) * (n0 + i) % MOD;

	printf("%d\n", ans);
}

int main()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);

	input();
	solve();

	return 0;
}

