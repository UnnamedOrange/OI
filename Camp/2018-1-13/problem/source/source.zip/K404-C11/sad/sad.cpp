#include <bits/stdc++.h>

int main() {
    freopen("sad.in", "r", stdin);
    freopen("sad.out", "w", stdout);
    puts("3");
    return 0;
}