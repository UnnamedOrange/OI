#include<bits/stdc++.h>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

int main(){
//	freopen("data.in","w",stdout);
	srand(time(NULL));
	int n=rand()%5000+1,m=rand()%5000+1;
//	n=(int)5e5,m=(int)5e5;
	ptk(n),ptn(m);
	rep(i,1,n+1){
		int l=rand()%10000+1,r=rand()%100000+1;
		if(l>r)swap(l,r);
		ptk(l),ptn(r);
	}
	rep(i,1,m+1)ptn(rand()%100000+1);
	return 0;
}
