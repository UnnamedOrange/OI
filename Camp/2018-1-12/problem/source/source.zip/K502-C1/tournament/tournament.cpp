#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
using namespace std;

const int MOD = 998244353;
int n, k;
long long ans;

namespace Force
{
	bool ok;
	int a[20][20];
	int depth[20], visit[20];
	void tarjan(int p, int fa)
	{
		visit[p] = 1;
		depth[p] = depth[fa] + 1;
		for (int i = 1; i < n + 1; ++i)
		{
			if (a[p][i] == 1 && visit[i] == 0)
				tarjan(i, p);
			else if (a[p][i] == 1 && visit[i] == 1)
			{
				if (depth[p] - depth[i] + 1 == k)
					ok = true;
			}
		}
		visit[p] = 2;
	}
	bool check()
	{
		for (int i = 1; i < n + 1; ++i)
		{
			ok = false;
			depth[0] = 0;
			memset(visit, 0, sizeof visit);
			tarjan(i, 0);
			if (ok)
				return true;
		}
		return false;
	}
	void dfs(int p, int d)
	{
		if (p == n)
			ans = (ans + check()) % MOD;
		else
		{
			a[p][d] = 1;
			a[d][p] = 0;
			if (d == n)
				dfs(p + 1, p + 2);
			else
				dfs(p, d + 1);
			a[p][d] = 0;
			a[d][p] = 1;
			if (d == n)
				dfs(p + 1, p + 2);
			else
				dfs(p, d + 1);
		}
	}
	void main()
	{
		dfs(1, 2);
		printf("%lld\n", ans);
	}
}

int main()
{
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	cin >> n >> k;
	Force::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
