#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

int n, k, ans;
bool mp[10][10], vis[10];

bool fc(int u, int S, int step) {
	vis[u] = 1;
	int i;
	rep(i, 1, n)
	if(mp[u][i]) {
		if(!vis[i]) {
			if(fc(i, S, step-1)) return 1;
		} else
			if(step == 1 && i == S) return 1;
	}
	vis[u] = 0;
	return 0;
}

bool check() {
	int i;
	rep(i, 1, n) {
		memset(vis, 0, sizeof vis);
		if(fc(i, i, k)) return 1;
	}
	return 0;
}

void dfs(int a, int b) {
	if(b > n) {++a; b = a + 1;}
	if(a >= n) {
		//int i, j;
		//rep(i, 1, n) {rep(j, 1, n) printf("%d ", mp[i][j]); puts("");}
		//printf("--%d--\n", check());
		ans += check(); return;
	}
	mp[a][b] = 1; mp[b][a] = 0;
	dfs(a, b + 1);
	mp[a][b] = 0; mp[b][a] = 1;
	dfs(a, b + 1);
}

int main() {
	freopen("tournament.in", "r", stdin); freopen("tournament.out", "w", stdout);
	scanf("%d %d", &n, &k);
	dfs(1, 2);
	printf("%d\n", ans);
	return 0;
}
