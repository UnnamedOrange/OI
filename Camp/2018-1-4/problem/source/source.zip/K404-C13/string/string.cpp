#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

const int N=1005;

int n,m,sz,ans,tag,flag,cnt;
int a[N],l[N];
char c[N][N];

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int i,j,s,k;
	scanf("%d%d",&n,&m);
	for (i=1;i<=n;i++){
		scanf("%s",c[i]+1);
		l[i]=strlen(c[i]+1);
	}
	if (m<=15){
		sz=(1<<m)-1;
		for (s=0;s<(1<<m);s++){
			cnt=0;
			for (i=1;i<=m;i++) a[i]=(s>>i-1)&1;
			for (i=1;i<=m;i++) a[m+m-i+1]=1-a[i];
			for (i=1;i<=n;i++){
				flag=0;
				for (j=1;j<=m+m-l[i]+1;j++){
					tag=1;
					for (k=1;k<=l[i];k++)
						if (a[j+k-1]!=c[i][k]-'0') tag=0;
					flag|=tag;
				}
				cnt+=flag;
			}
			if (cnt==n) ans++;
		}
		printf("%d\n",ans);
		return 0;
	}
	else printf("0\n");
	if (m>500) printf("ysy��Ůװ");
	return 0;
}
