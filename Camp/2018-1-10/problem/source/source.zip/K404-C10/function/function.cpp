#include <cstdio>
#include <cmath>
using namespace std;
#define N 1000050
int d0[N],miu[N],su[N],i,m,j,ans[N];
bool vis[N];
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int t;scanf("%d",&t);d0[1]=miu[1]=1;
	for (i=2;i<=1000000;i++){
		if (!vis[i]){
			miu[i]=-1;d0[i]=2;su[++m]=i;
		}
		for (j=1;j<=m;j++){
			if (i*su[j]>1000000) break;
			if (i%su[j]){
				vis[i*su[j]]=true;
				miu[i*su[j]]=miu[i]*miu[su[j]];
				d0[i*su[j]]=d0[i]*d0[su[j]];
			}else{
				vis[i*su[j]]=true;
				miu[i*su[j]]=0;
				int x=i,psz=2;
				while (x%su[j]==0) x/=su[j],psz++;
				d0[i*su[j]]=d0[x]*psz;
				break;
			}
		}
	}for (i=2;i<=1000000;i++) d0[i]*=d0[i];
	for (i=1;i<=1000000;i++)
	for (j=1;j<=1000000/i;j++) ans[i*j]+=miu[i]*d0[j];
	for (i=1;i<=1000000;i++) ans[i]+=ans[i-1];
	while (t--){
		int n;scanf("%d",&n);
		printf("%d\n",ans[n]);
	}
	return 0;
}
