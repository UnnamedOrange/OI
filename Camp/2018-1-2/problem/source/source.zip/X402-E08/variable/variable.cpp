/*
Author: CNYALI_LK
LANG: C++
PROG: variable.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll w[102424];
struct H{
	ll x,y,z,a,b,c,d,e,f;
	ll js(){
		return abs(w[x]-w[y])*a+abs(w[y]-w[z])*b+abs(w[z]-w[x])*c+(w[x]-w[y])*d+(w[y]-w[z])*e+(w[z]-w[x])*f;
	}
	void init(){
		x=read();y=read();z=read();a=read();b=read();
		c=read();d=read();e=read();f=read();
	}
};
struct Judger{
	ll a,b,c;
	void init(){
		a=read();b=read();c=read();
	}
	ll judge(){
		if(c==2)return w[a]<w[b];
		if(c==1)return w[a]==w[b];
		return w[a]<=w[b];
	}
};
H a[102424];
Judger b[102424];
#ifndef cnyali_lk
#define cnyali_lk
#endif

int main(){
#ifdef cnyali_lk
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
#endif
	ll n,W,p,q,t;
	t=read();
	while(t){
		--t;
		n=read();
		W=read();p=read();q=read();
		for(ll i=1;i<=p;++i){
			a[i].init();
		}
		for(ll i=1;i<=q;++i)b[i].init();
		ll mn=0x3f3f3f3f3f3f3f,sm;
		for(ll j=0;j<(1<<n);++j){
			sm=0;
			for(ll i=0;i<n;++i)sm+=(w[i+1]=((j&(1<<i))?W:-W));
			ll ok=1;
			for(ll i=1;i<=q;++i)if(!(ok=b[i].judge()))break;
			if(!ok)continue;
			for(ll i=1;i<=p;++i)sm+=a[i].js();

			chkmin(mn,sm);
		}
		printf("%lld\n",mn);
	}
	return 0;
}

