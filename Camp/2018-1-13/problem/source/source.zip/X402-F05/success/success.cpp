#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

const int N = 110;
const int Mod = 1e9 + 7;

int dp[N][N];
int n, m, s, t;

int main(){
	
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);

	scanf("%d%d%d%d", &s, &t, &n, &m);
	
	--t, s -= m;
	dp[0][0] = 1;
	For(i, 1, m + 1) For(j, 0, s)
		For(k, 0, (i <= n ? t : s))
			dp[i][j] = (dp[i][j] + dp[i - 1][j - k]) % Mod;
	printf("%d\n", dp[m + 1][s]);

	return 0;
}
