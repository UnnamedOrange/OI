#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<< " = "<<(x)<<" "
#define debug(x) cerr<<#x<< " = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=55,mod=998244353;
void add_mod(int &a,int b){if((a+=b)>=mod)a-=mod;}
int head[N],tot_edge,n,K;
pii G[N<<1];
struct P_0{
	int dp[1<<15][15];//dp[S][�������Ϊ x] 
	int nxt[1<<15][15][15];
	int Mask;
	void dfs(int x,int par,int &res){
		if(Mask>>x&1){
			res|=1<<x;
			for(int i=head[x];i;i=G[i].se)if(G[i].fi!=par)
				dfs(G[i].fi,x,res); 
		}
	}
	int solve(int S,int k){
		if(k==K)return 0;
		int &res=dp[S][k];
		if(res==-1){
			res=!S;
			rep(i,0,n)if(S>>i&1){
				int cnt=1;
				for(int j=head[i];j;j=G[j].se)if(S>>G[j].fi&1)
					cnt=(ll)cnt*solve(nxt[S][i][G[j].fi],k+1)%mod;
				add_mod(res,cnt);
			}
			res+=solve(S,k+1);
		}
		return res;
	}
	void work(){
		rep(i,0,1<<n){
			Mask=i;
			rep(j,0,n)if(i>>j&1){
				for(int k=head[j];k;k=G[k].se)if(i>>G[k].fi&1){
					dfs(G[k].fi,j,nxt[i][j][G[k].fi]);
				}
			}
		}
		memset(dp,-1,sizeof dp);
		ptn(solve((1<<n)-1,0)); 
	}
}P0;
int main(){
//	debug((sizeof(P0))>>20);
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	rd(n),rd(K);
	for(int x,y,i=1;i<n;++i){
		rd(x),rd(y);--x,--y;
		G[++tot_edge]=pii(y,head[x]);head[x]=tot_edge;
		G[++tot_edge]=pii(x,head[y]);head[y]=tot_edge;
	}
	if(n<=7&&K<=7)P0.work();
	else P0.work();
	return 0;
}
