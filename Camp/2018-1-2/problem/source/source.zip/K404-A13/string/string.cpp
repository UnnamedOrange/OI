#include<cstdio>
#include<cstring>
#include<algorithm>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
using namespace std;
const int maxn = 1e2 + 5;
const int inf = 0x3f3f3f3f;
int dp[maxn][maxn], n, t;
bool is_PLD[maxn][maxn];
char s[maxn];

bool j_PLD(int l, int r) {
	while(l < r) {
		if(s[l] != s[r]) return false;
		++l, --r;
	}
	return true;
}

bool j_SX() {
	for(register int i = 0; i <= n - 4; ++i)
		if(s[i] == s[i + 2] && s[i + 1] == s[i + 3]) continue;
		else return false;
	return true;
}

void init_PLD() {
	For(i, 0, n - 1) For(j, i, n - 1)
		is_PLD[i][j] = j_PLD(i, j);
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n), scanf("%s", s);
		if(n <= 0) {
			memset(dp, inf, sizeof(dp)), init_PLD();
			For(i, 1, n - 1) For(j, 0, n - 1 - i) {
				if(!is_PLD[j][i + j]) {
					dp[j][j + i] = 1;
					continue ;
				}
				For(k, j, j + i) {
					dp[j][j + i] = min(dp[j][j + i], dp[j][j + k] + dp[j + k + 1][i + j]);
				}
			}
			printf("%d\n", dp[0][n - 1] == inf ? -1 : dp[0][n - 1]);
		} else {
			if(!j_PLD(0, n - 1)) printf("1\n");
			else {
				if(j_SX()) printf("-1\n");
				else printf("2\n");
			}			
		}
	}
	return 0;
}
