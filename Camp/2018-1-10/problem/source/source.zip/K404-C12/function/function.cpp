#include <iostream>
#include <cstdio>
#define MAX_N 1000005
using namespace std; 
typedef long long ll; 
int mu[MAX_N], d[MAX_N], p[MAX_N], tot; 
bool np[MAX_N]; 
ll m[MAX_N], sig[MAX_N]; 
int main()
{
	freopen("function.in", "r", stdin); 
	freopen("function.out", "wt", stdout); 
	mu[1] = 1; 
	for (int i = 2; i < MAX_N; i++)
	{
		if (!np[i])
		{
			mu[i] = -1;
			p[tot++] = i; 
		}
		for (int j = 0; j < tot && i * p[j] < MAX_N; j++)
		{
			np[i * p[j]] = true; 
			if (!(i % p[j]))
			{
				mu[i * p[j]] = 0; 
				break; 
			}
			mu[i * p[j]] = -mu[i]; 
		}
	}
	for (int i = 1; i < MAX_N; i++)
	{
		m[i] = m[i - 1] + mu[i]; 
		for (int j = i; j < MAX_N; j += i)
			d[j]++;
	}
	for (int i = 1; i < MAX_N; i++)
		sig[i] = sig[i - 1] + (ll)d[i] * d[i]; 
	int t; 
	scanf("%d", &t); 
	while (t--)
	{
		int n; 
		scanf("%d", &n); 
		ll ans = 0; 
		for (int i = 1, j; i <= n; i = j + 1)
		{
			j = n / (n / i); 
			ans += (sig[j] - sig[i - 1]) * m[n / i]; 
		}
		printf("%lld\n", ans); 
	}
	return 0; 
}

