#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define N 1000100
// 256
using namespace std;
struct node{int to,next;}table[N<<1],tb[N<<1];
int tot,head[N],tt,hd[N],to[N];
void add(int a,int b){table[++tot]=(node){b,head[a]};head[a]=tot;}
void add2(int b,int a){tb[++tt]=(node){b,hd[a]};hd[a]=tt;++to[b];}
int n,m,cn;
int dfn[N],low[N],cnt,sta[N],tp,num[N],be[N];
bool ins[N];
void tarjan(int x)
{
	dfn[x]=low[x]=++cnt;
	ins[sta[++tp]=x]=1;
	for(int i=head[x];i;i=table[i].next)
	{
		int j=table[i].to;
		if(!dfn[j])tarjan(j),low[x]=min(low[x],low[j]);
		else if(ins[j])low[x]=min(low[x],low[j]);
	}
	if(low[x]==dfn[x])
	{
		++cn;
		while(sta[tp]!=x)
		{
			ins[sta[tp]]=0;
			num[cn]++;
			be[sta[tp]]=cn;
			--tp;
		}
		ins[sta[tp]]=0;
		num[cn]++;
		be[sta[tp]]=cn;
		--tp;
	}	
}
int ans;
int q[N],h,t,pre[N];
void qwq()
{
	for(int i=1;i<=n;i++)
	if(!to[i])q[++t]=i;
	while(h!=t)
	{
		int x=q[++h];
		if(pre[x]==ans)++ans;
		for(int i=hd[x];i;i=tb[i].next)
		{
			--to[tb[i].to];
			pre[tb[i].to]=ans;
			if(!to[tb[i].to])q[++t]=tb[i].to;
		}
	}
}
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x;
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	int a,b;
	for(int i=1;i<=m;i++)
	{
		a=read(),b=read();
		add(a,b);
	}
	for(int i=1;i<=n;i++)
	if(!dfn[i])tarjan(i);
	for(int i=1;i<=cn;i++)num[i]+=num[i-1];
	for(int x=1;x<=n;x++)
	for(int i=head[x];i;i=table[i].next)
	if(be[x]!=be[table[i].to])add2(num[be[x]],num[be[table[i].to]-1]+1);
	for(int i=1;i<=cn;i++)
	for(int j=num[i-1]+1;j<num[i];j++)add2(j,j+1);
	qwq();
	printf("%d\n",ans); 
	return 0;
}