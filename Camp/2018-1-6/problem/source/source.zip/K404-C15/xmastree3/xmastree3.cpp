#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 11, P = 998244353, HA = 19260817;
int n, k;
int ecnt, adj[N], nxt[2 * N], go[2 * N];
int fa[N], stk[N], top;
ll ans, f[N][N], g[N][N];
bool mark[N], notleaf[N], vis[HA];

void add(int u, int v){
	go[++ecnt] = v;
	nxt[ecnt] = adj[u];
	adj[u] = ecnt;
}
void check(){
	memset(f, 0, sizeof(f));
	memset(g, 0, sizeof(g));
	memset(notleaf, 0, sizeof(notleaf));
	for(int i = top; i; i--){
		int v = stk[i], u = fa[v];
		notleaf[u] = 1;
		for(int j = 1; j <= k; j++){
			if(!notleaf[v]) f[v][j] = 1;
			g[v][j] = (f[v][j] + g[v][j - 1]) % P;
			if(!f[u][j + 1]) f[u][j + 1] = 1;
			f[u][j + 1] = f[u][j + 1] * g[v][j] % P;
		}
	}
	ans = (ans + g[stk[1]][k]) % P;
}
void dfs(int s, int f){
	//printf("dfs(%d, %d)\n", s, f);
	int que[N] = {0}, qr;
	bool inq[N] = {0};
	que[qr = 1] = s, inq[s] = 1;
	for(int ql = 1; ql <= qr; ql++)
		for(int u = que[ql], e = adj[u], v; e; e = nxt[e])
			if(!inq[v = go[e]] && !mark[v]) que[++qr] = v, inq[v] = 1;
	int u = que[rand() % qr + 1];
	fa[u] = f, mark[u] = 1, stk[++top] = u;
	for(int e = adj[u], v; e; e = nxt[e])
		if(!mark[v = go[e]]) dfs(v, u);
}

int main(){
	
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
	
	srand(time(0));
	read(n), read(k);
	for(int i = 1, u, v; i < n; i++)
		read(u), read(v), add(u, v), add(v, u);
	int T = 233333;
	while(T--){
		top = 0;
		memset(mark, 0, sizeof(mark));
		dfs(1, 0);
		int hsh = 0;
		for(int i = 1; i <= n; i++)
			hsh = (hsh * (n + 1) + fa[i]) % HA;
		if(!vis[hsh]){
			check();
			vis[hsh] = 1;
		}
	}
	write(ans), enter;
	
	return 0;
}
/*
3 3
3 2
1 3
*/
/*
7 7
1 2
1 3
1 4
3 5
3 6
6 7
*/
