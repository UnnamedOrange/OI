#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

const int N=30;

int n,T,now,ans,flag,sum;
int a[N],b[N];

void dfs(int step){
	bool tag; int i,j;
	if (flag) return;
	if (step>ans){
		tag=1;
		for (i=1;i<=n;i++)
			if (a[i]!=i) tag=0;
		if (tag) flag=1;
		return;
	}
	for (i=2;i<=n;i++){
		if (flag) return;
		for (j=1;j<=i/2;j++) swap(a[j],a[i-j+1]);
		dfs(step+1);
		for (j=1;j<=i/2;j++) swap(a[j],a[i-j+1]);
	}
}

int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int i,j;
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n); now=n; ans=0; flag=0;
		for (i=1;i<=n;i++) scanf("%d",&a[i]);
		for (i=1;i<=n;i++) b[i]=a[i];
		if (n>=10){
			for (ans=0;ans<=n/2;ans++){
				dfs(1);
				if (flag){
					printf("%d\n",ans);
					break;
				}
			}
			if (flag) continue;
			for (i=1;i<=n;i++) a[i]=b[i];
			sum=0; ans=n+n;
			while (now>1){
				for (j=1;j<=n;j++)
					if (a[j]==now) break;
				if (j==now){
					now--;
					continue;
				}
				if (j!=1){
					for (i=1;i<=j/2;i++) swap(a[i],a[j-i+1]);
					sum++;
				}
				for (i=1;i<=now/2;i++) swap(a[i],a[now-i+1]);
				sum++; now--;
			}
			ans=min(ans,sum);
			for (i=1;i<=n;i++) a[i]=b[i];
			now=1; sum=1;
			while (now<n){
				for (j=1;j<=n;j++)
					if (a[j]==now) break;
				if (now==n-j+1){
					now++;
					continue;
				}
				if (j!=1){
					for (i=1;i<=j/2;i++) swap(a[i],a[j-i+1]);
					sum++;
				}
				for (i=1;i<=(n-now+1)/2;i++) swap(a[i],a[n-now+1-i+1]);
				sum++; now++;
			}
			ans=min(ans,sum);
			printf("%d\n",ans);
		}
		else{
			for (ans=0;ans<=n*n;ans++){
				dfs(1);
				if (flag){
					printf("%d\n",ans);
					break;
				}
			}
		}
	}
	return 0;
}
