cas=1
while true; do
    python3 ./gen.py || break
    ./bf || break
    ./xmasdag || break

    diff ./bf.out ./xmasdag.out || break

    echo $cas
    cas=`expr $cas + 1`
done
