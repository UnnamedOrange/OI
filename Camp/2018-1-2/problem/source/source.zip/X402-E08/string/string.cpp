/*
Author: CNYALI_LK
LANG: C++
PROG: string.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}
int n;
char s[102];
void getstr(char *s){
	while(!isalpha(*(++s)=getchar())){--s;}
	while(isalpha(*(++s)=getchar()));
	*s=0;
}
#ifndef cnyali_lk
#define cnyali_lk
#endif
int NotHW(char *l,char *r){
	int mid=(r-l);
	char *sl,*sr;
	if(mid&1){
		sl=l+(mid>>1),sr=l+(mid>>1)+1;
	}
	else{
		sl=sr=l+(mid>>1);	
	}
	while(sl>=l){
		if(*sl!=*sr)return 1;
		--sl;++sr;
	}
	return 0;	

}
int Qmin(char *s,int n){
	if(!n)return 0;
	char a[102];
	int ans=0x3f3f3f3f;
	for(int l=1;l<=n;++l)	for(int r=l;r<=n;++r)if(NotHW(s+l,s+r)){
		for(int i=1;i<l;++i)a[i]=s[i];
		for(int i=r+1;i<=n;++i)a[i-r+l]=s[i];
		a[n+1-r+l]=0;
		chkmin(ans,Qmin(a,n-(r-l+1))+1);
	}
	return ans;
}
int main(){
#ifdef cnyali_lk
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	int	t;
	t=read();
	while(t){
		--t;
		n=read();
		getstr(s);
		int a=Qmin(s,n);
		if(a^0x3f3f3f3f)printf("%d\n",a);
		else printf("-1\n");
	}
	return 0;
}

