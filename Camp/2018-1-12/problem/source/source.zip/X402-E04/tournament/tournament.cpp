#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=100010,INF=0x3f3f3f3f,Mod=998244353;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
}
ll qpow(ll a,ll b){
	ll ret=1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
int main(){
	file();
	ll n,k;
	read(n),read(k);
	if(k==3){
		ll fac=1;
		For(i,1,n)fac=fac*i%Mod;
		printf("%lld\n",(qpow(2,n*(n-1)/2)+Mod-fac)%Mod);
	}else if(n==k){
		if(n==4)puts("32");
		else if(n==5)puts("704");
		else if(n==6)puts("26624");
	}
	return 0;
}
