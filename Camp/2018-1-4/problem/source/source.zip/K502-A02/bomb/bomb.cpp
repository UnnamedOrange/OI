#include<cstdio>
#include<iostream>
#include<vector>
#include<stack>
#define maxn 1000010
using namespace std;
stack<int> S;
vector<int> g[maxn],gr[maxn];
int v[maxn],d[maxn],low[maxn],c[maxn],f[maxn],pre[maxn];
int n,m,dfn=0,cnt=0;
void tarjan(int now){
	d[now]=low[now]=++dfn;
	v[now]=1;
	S.push(now);
	for (int i=0;i<g[now].size();i++){
		int son=g[now][i];
		if (!d[son]) tarjan(son), low[now] = min(low[now], low[son]);
		else if (v[son])low[now]=min(low[now], d[son]);
		//low[now]=min(low[now],low[son]);
	}
	if (d[now]==low[now]){
		pre[now]=++cnt;
		int x=0;
		while (x!=now){
			x=S.top();
			v[x] = 0;
			S.pop();
			pre[x]=cnt;
		}
	}
}
void dfs(int now){
	int Sum = c[now];
	for (int i=0;i<gr[now].size();i++){
		int son=gr[now][i];
		if (!f[son]) dfs(son);
		Sum=max(Sum,f[son]+c[now]);
	}
	f[now] = Sum;
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		g[x].push_back(y);
	}
	for (int i=1;i<=n;i++)
		if (!d[i]) tarjan(i);
	for (int i=1;i<=n;i++){
		for (int j=0;j<g[i].size();j++){
			int son=g[i][j];
			if (pre[i]!=pre[son])
				gr[pre[i]].push_back(pre[son]);
		}
		c[pre[i]]++;
	}/*
	for (int i=1;i<=n;i++){
		int u=low[i];
		for (int j=0;j<gr[u].size();j++){
			int son=gr[u][j];
			printf("%d %d\n",u,son);
		}
	}
	*/
	int ans=0;
	for (int i=1;i<=cnt;i++){
		if (!f[i]) dfs(i);
		ans=max(ans,f[i]);
	}
	cout<<ans<<endl;
	return 0;
}
