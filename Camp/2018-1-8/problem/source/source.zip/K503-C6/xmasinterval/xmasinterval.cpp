#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <queue>
#include <vector>

#define lc k << 1
#define rc k << 1 | 1

using namespace std;
typedef long long ll;
const ll mod = 1e9 + 9;

ll qpow(ll a, ll b){
	ll ret = 1;
	for(; b; b >>= 1, a = a * a % mod){
		if(b & 1) ret = ret * a % mod;
	}
	return ret;
}
int lowbit(int x){
	return x & -x;
}

struct seg{
	int l, r, t, u;
}d[500005];

int n, m, MAXN;
int BIT[500005];
void add(int pos, int x){
	//printf("a %d\n", pos);
	for(int i = pos; i <= m + 1; i += lowbit(i)){
		BIT[i] += x;
	}
}
void cl(int pos){
	//printf("c %d\n", pos);
	for(int i = pos; i <= m + 1; i += lowbit(i)){
		BIT[i] = 0;
	}
}
int query(int pos){
	int sum = 0;
	for(int i = pos; i; i -= lowbit(i)){
		sum += BIT[i];
	}
	return sum;
}
int BIT2[500005];
void add2(int pos, int x){
	//printf("a %d\n", pos);
	for(int i = pos; i <= m + 1; i += lowbit(i)){
		BIT2[i] += x;
	}
}
void cl2(int pos){
	//printf("c %d\n", pos);
	for(int i = pos; i <= m + 1; i += lowbit(i)){
		BIT2[i] = 0;
	}
}
int query2(int pos){
	int sum = 0;
	for(int i = pos; i; i -= lowbit(i)){
		sum += BIT2[i];
	}
	return sum;
}


int a[500005];
int tmp[1500005], tmpn;
int cmp(seg x, seg y){
	if(x.u == y.u) return x.t < y.t;
	return x.u < y.u;
}
struct node{
    ll dat, tag1, tag2;
    int l, r;
};

struct Segment{
    node d[2000005];
    
    void pushup(int k){
        d[k].dat = d[lc].dat + d[rc].dat;
        if(d[k].dat >=mod) d[k].dat -= mod;
    }
    
    void build(int k, int l, int r){
        d[k].l = l; d[k].r = r; d[k].tag1 = 0; d[k].tag2 = 1;
        if(l == r){
            d[k].dat = 0;
            return;
        }
        int mid = (l + r) >> 1;
        build(lc, l, mid);
        build(rc, mid + 1, r);
        pushup(k);
    }
    
    void add(int k, ll x){
        ll len = d[k].r - d[k].l + 1;
        d[k].dat = (d[k].dat + x * len) % mod;
        d[k].tag1 = (d[k].tag1 + x) % mod;
    }
    
    void mul(int k, ll x){
        d[k].dat = d[k].dat * x % mod;
        d[k].tag1 = d[k].tag1 * x % mod;
        d[k].tag2 = d[k].tag2 * x % mod;
    }
    
    void pushdown(int k){
        if(d[k].tag2 != 1){
            mul(lc, d[k].tag2);
            mul(rc, d[k].tag2);
            d[k].tag2 = 1;
        }
        if(d[k].tag1 != 0){
            add(lc, d[k].tag1);
            add(rc, d[k].tag1);
            d[k].tag1 = 0;
        }
    }
    
    void add(int k, int l, int r, ll x){
        if(l <= d[k].l && d[k].r <= r){
            add(k, x); return;
        }
        pushdown(k);
        int mid = (d[k].l + d[k].r) >> 1;
        if(l <= mid) add(lc, l, r, x);
        if(r > mid) add(rc, l, r, x);
        pushup(k);
    }
    
    void mul(int k, int l, int r, ll x){
        if(l <= d[k].l && d[k].r <= r){
            mul(k, x); return;
        }
        pushdown(k);
        int mid = (d[k].l + d[k].r) >> 1;
        if(l <= mid) mul(lc, l, r, x);
        if(r > mid) mul(rc, l, r, x);
        pushup(k);
    }
    
    ll query(int k, int l, int r){
        if(l <= d[k].l && d[k].r <= r){
            return d[k].dat;
        }
        pushdown(k); ll sum = 0;
        int mid = (d[k].l + d[k].r) >> 1;
        if(l <= mid) sum = (sum + query(lc, l, r)) % mod;
        if(r > mid) sum = (sum + query(rc, l, r)) % mod;
        return sum;
    }
    
}Seg;

ll pw[500005], f[500005];
int vis[500005];
int main(){
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; i ++){
		scanf("%d%d", &d[i].l, &d[i].r);
		tmp[++tmpn] = d[i].l, tmp[++tmpn] = d[i].r;
	}
	for(int i = 1; i <= m; i ++){
		scanf("%d", &a[i]);
		tmp[++tmpn] = a[i];
	}
	sort(tmp + 1, tmp + tmpn + 1);
	tmpn = unique(tmp + 1, tmp + tmpn + 1) - tmp - 1; MAXN = tmp[tmpn];
	for(int i = 1; i <= n; i ++){
		d[i].l = lower_bound(tmp + 1, tmp + tmpn + 1, d[i].l) - tmp;
		d[i].r = lower_bound(tmp + 1, tmp + tmpn + 1, d[i].r) - tmp;
	}
	for(int i = 1; i <= m; i ++){
		a[i] = lower_bound(tmp + 1, tmp + tmpn + 1, a[i]) - tmp;
	}
	sort(a + 1, a + m + 1);
	m = unique(a + 1, a + m + 1) - a - 1;
	int p = 0;
	a[m + 1] = MAXN + 1;
	a[0] = 0;
	for(int i = 1; i <= n; i ++){
		d[i].t = lower_bound(a, a + m + 1, d[i].l) - a - 1;
		d[i].u = upper_bound(a, a + m + 1, d[i].r) - a - 1;
		//printf("%d %d %d %d\n", d[i].l, d[i].r, d[i].t, d[i].u);
	}
	sort(d + 1, d + n + 1, cmp);
//	for(int i = 1; i <= n; i ++){
	//	printf("%d %d %d %d\n", d[i].l, d[i].r, d[i].t, d[i].u);
//	}
	Seg.build(1, 1, m + 1);	
	f[0] = 1; Seg.add(1, 1, 1, 1);
	for(int i = 0; i <= m; i ++){
		pw[i] = 1;
	}
	for(int i = 1; i <= m; i ++){
		while(d[p + 1].t == d[p + 1].u && p < n){
			p ++;
		}
		int rp = p;
		while(d[p + 1].u < i + 1 && d[p + 1].t != d[p + 1].u && p < n){
			p ++;
			add(d[p].t + 1, 1);
			//cl(d[p].t + 1);
		}
	//	printf("%d %d\n", rp, p);
		int lst = 0;
		for(int j = rp + 1; j <= p; j ++){
			if(!vis[d[j].t]){
				if(j != rp + 1){
					//printf("%d %d %d\n", i, d[j].t, query(i) - query(d[j].t));
					f[i] = (f[i] + Seg.query(1, d[j - 1].t + 1, d[j].t) * (qpow(2, query(d[j].t)) - 1) % mod * (qpow(2, query(i) - query(d[j].t)))) % mod;
//					printf("%d %d %lld\n", i, d[j].t, query(d[j].t));
				}
				vis[d[j].t] = 1;
			}
		}
		if(rp != p){
			f[i] = (f[i] + Seg.query(1, d[p].t + 1, i) * (qpow(2, query(i)) - 1)) % mod;
		}
		for(int j = rp + 1; j <= p; j ++){
			vis[d[j].t] = 0;
			if(d[j].t)Seg.mul(1, 1, d[j].t, 2);
			add(d[j].t + 1, -1);
		}
		//printf("%d %d\n", query(6), query(2));
		Seg.add(1, i + 1, i + 1, f[i]);
	}
	for(int i = 1; i <= m + 1; i ++){
	//	printf("%lld\n", Seg.query(1, i, i));
	}
	ll cnt = 0;
	for(int i = 1; i <= n; i ++){
		if(d[i].t == d[i].u) cnt++;
	}
	printf("%lld\n", f[m] * qpow(2, cnt) % mod);
	return 0;
}
