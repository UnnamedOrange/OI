#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int mod=998244353;

int n,m,k;

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

namespace task1{
	const int maxn=2005,maxm=5005;
	int tot,now[maxn],pre[maxm],son[maxm],deg[maxn];
	int f[maxn][maxn];
	void add(int a,int b){son[++tot]=b,pre[tot]=now[a],now[a]=tot;}
	void link(int a,int b){add(a,b),++deg[b];}
	int q[maxn];
	int power(int a,int k){
		int ret=1;
		for (;k;k>>=1,a=1ll*a*a%mod) if (k&1) ret=1ll*ret*a%mod;
		return ret;
	}
	void solve(){
		for (int i=1,x,y;i<=m;i++) x=read(),y=read(),link(x,y);
		int head=1,tail=0;
		for (int i=1;i<=n;i++) if (!deg[i]) q[++tail]=i,f[i][0]=1;
		while (head<=tail){
			int x=q[head++];
			for (int p=now[x];p;p=pre[p]){
				for (int j=1;j<=n;j++)
					f[son[p]][j]=(f[son[p]][j]+f[x][j-1])%mod;
				if (--deg[son[p]]==0) q[++tail]=son[p];
			}
		}
		for (int i=1;i<=n;i++){
			int res=0;
			for (int j=1;j<=n;j++)
				if (f[i][j]) res=(res+1ll*f[i][j]*power(j,k))%mod;
			printf("%d\n",res);
		}
	}
}

namespace task2{
	const int maxn=100005,maxm=200005;
	int tot,now[maxn],pre[maxm],son[maxm],deg[maxn],f[maxn],g[maxn];
	void add(int a,int b){son[++tot]=b,pre[tot]=now[a],now[a]=tot;}
	void link(int a,int b){add(a,b),++deg[b];}
	int q[maxn];
	void solve(){
		for (int i=1,x,y;i<=m;i++) x=read(),y=read(),link(x,y);
		int head=1,tail=0;
		for (int i=1;i<=n;i++) if (!deg[i]) q[++tail]=i,f[i]=0,g[i]=1;
		while (head<=tail){
			int x=q[head++];
			for (int p=now[x];p;p=pre[p]){
				g[son[p]]=(g[son[p]]+g[x])%mod,f[son[p]]=(1ll*f[son[p]]+f[x]+g[x])%mod;
				if (--deg[son[p]]==0) q[++tail]=son[p];
			}
		}
		for (int i=1;i<=n;i++) printf("%d\n",f[i]);
	}
}

int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read(),m=read(),k=read();
	if (n<=2000&&m<=5000) task1::solve();
	else task2::solve();
	return 0;
}
