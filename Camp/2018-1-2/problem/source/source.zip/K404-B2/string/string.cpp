#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define ull unsigned long long
using namespace std;
char s[200005];
ull p[100005],h[100005],h2[100005];
ull base=233;
bool f[105][105];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	cin>>T;
	while(T--)
	{
		int n;
		cin>>n;
		scanf("%s",s+1);
		if(n<=100)
		{
			int flag=0;
			memset(f,0,sizeof(f));
			f[0][0]=1;
			memset(h,0,sizeof(h));
			memset(h2,0,sizeof(h2));
			p[0]=1;
			for(int i=1;i<=n;i++)
			{
				p[i]=p[i-1]*base;
				h[i]=h[i-1]*base+s[i]-'a'+1;
			}
			for(int i=n;i;i--)
			{
				h2[i]=h2[i+1]*base+s[i]-'a'+1;
			}
			for(int i=1;i<=n;i++)
			{
				for(int j=1;j<=n;j++)
				{
					if(f[i-1][j])
					{
						f[i][j]=1;
						continue;
					}
					for(int k=0;k<j;k++)
					{
						if(f[i-1][k])
						{
							if(h[j]-h[k]*p[j-k]!=h2[k+1]-h2[j+1]*p[j-k])
							{
								f[i][j]=1;
								break;
							}
						}
					}
				}
				if(f[i][n])
				{
					flag=i;
					break;
				}
			}
			if(flag)
			printf("%d\n",flag);
			else puts("-1");
			continue;
		}
		bool ac=1;
		for(int i=1;i<=n;i++)
		{
			if(s[i]!=s[n-i+1])
			{
				ac=0;
				break;
			}
		}
		if(!ac)
		{
			puts("1");
			continue;
		}
		if(n==1)
		{
			puts("-1");
			continue;
		}
		for(int i=2;i<=n;i++)
		{
			if(s[i]!=s[1])
			{
				if(n&1)
				{
					if(i!=n/2+1)
					{
						ac=0;
						break;
					}
				}
				else ac=0;
			}
		}
		if(!ac)
		{
			memset(h,0,sizeof(h));
			memset(h2,0,sizeof(h2));
			p[0]=1;
			for(int i=1;i<=n;i++)
			{
				p[i]=p[i-1]*base;
				h[i]=h[i-1]*base+s[i]-'a'+1;
			}
			for(int i=n;i;i--)
			{
				h2[i]=h2[i+1]*base+s[i]-'a'+1;
			}
			for(int i=1;i<n;i++)
			{
				if(h[i]-h[0]*p[i]!=h2[1]-h2[i+1]*p[i]&&h[n]-h[i]*p[n-i]!=h2[i+1]-h2[n+1]*p[n-i])
				{
					ac=1;
					break;
				}
			}
			if(ac)
			puts("2");
			else puts("-1");
		}
		else puts("-1");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
