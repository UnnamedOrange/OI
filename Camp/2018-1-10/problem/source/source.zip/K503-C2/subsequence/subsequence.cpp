#include <stdio.h>
#define maxn 4010
int a[maxn],b[maxn],c[maxn],n,m,k,i,ans=4000;
bool check(int a[],int n,int b[],int m)
{
	int i,j=1;
	for (i=1;i<=n;i++)
	{
		if (a[i]==b[j]) j++;
		if (j>m) return true;
	}
	return false;
}
void work(int x)
{
	int i;
	if (x>ans) return;
	if (!check(a,n,c,x-1) && !check(b,m,c,x-1))
	{
		ans=x-1;
		return;
	}
	for (i=1;i<=k;i++)
	{
		c[x]=i;
		work(x+1);
	}
}
int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for (i=1;i<=m;i++)
		scanf("%d",&b[i]);
	work(1);
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
