#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e6+5;

int T,a[15],mx,mu[N],pr_pow[N],pr[N],prime[N>>1],prime_cnt,f[N],sum[N];
void init(){
	int j,p,t;
	f[1]=mu[1]=1;
	rep(i,2,mx){
		if(!pr[i])prime[prime_cnt++]=pr[i]=pr_pow[i]=i;
		if(pr_pow[i]==i)mu[i]=-(i==pr[i]),f[i]=f[i/pr[i]]+1;
		else mu[i]=mu[i/pr_pow[i]]*mu[pr_pow[i]],f[i]=f[i/pr_pow[i]]*f[pr_pow[i]];
		for(j=0;j<prime_cnt&&(p=prime[j])<=pr[i]&&(t=p*i)<mx;++j){
			pr[t]=p;
			pr_pow[t]=pr[i]==p?p*pr_pow[i]:p;
		}
	}
}
struct P_0{
	void work(){
		++mx;
		init();
		int j;
		rep(i,1,mx){
			if(mu[i]){
				for(j=mx/i;j;--j)
					sum[i*j]+=mu[i]*(ll)f[j]*f[j];
			}
			sum[i]+=sum[i-1];
		}
		rep(t,0,T)ptn(sum[a[t]]);
	}
}P0;
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	rd(T);
	rep(i,0,T)rd(a[i]),Max(mx,a[i]);
	if(!T);
	else if(mx<N)P0.work();
	return 0;
}
