#include <stdio.h>
#include <algorithm>
using namespace std;

#define ll long long int

const int maxn=1000001;
ll w[maxn],temp[maxn];
double ans=0;
ll n;

inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

double g(ll x,ll y)
{
	ll i;
	for(i=x;i<=y;i++)
		temp[i-x+1]=w[i];
	sort(temp+1,temp+y-x+2);
	double sum=0;
	for(i=1;i<=y-x+1;i++)
	{
		if(sum<temp[i])
			sum=(sum+temp[i])/2;
	} 
	return sum;
}

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	ll i;
	for(i=1;i<=n;i++)
		w[i]=read();
	ll j;
	for(i=1;i<=n;i++)
	{
		for(j=i;j<=n;j++)
		{
			ans=(ans+g(i,j)/(n*n));
		} 
	}
	printf("%lf",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
