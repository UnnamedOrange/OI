#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <iostream>
using namespace std;

int t, n, a[30], x[30], rev[30];

bool check(int a[]) {
	for(int i = 1; i <= n; ++i)
		if(a[i] != i) return 0;
	return 1;
}

bool dfs(int dep, int ans, int k) {
	if(dep-1 > ans) { return 0; }
	if(dep-1 == ans) if(check(a)) { return 1; }
	for(int i = n; i > 1; --i) {
		if(i == k) continue;
		reverse(a+1, a+i+1);
		if(dfs(dep+1, ans, i)) return 1;
		reverse(a+1, a+i+1);
	}
	return 0;
}

int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		for(int i = 1; i <= n; ++i) scanf("%d", a+i);
		int ans = 2*n-2;
		for(int i = 0; i <= ans; ++i) {
			if(dfs(1, i, 0)) ans = i;
		}
		printf("%d\n", ans);
	}
	return 0;
}
