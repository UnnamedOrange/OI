#include<cstdio>
using namespace std;
int main()
{
	freopen("xmasset.in", "r", stdin);
	freopen("xmasset.out", "w", stdout);
	int t, n, T, x, y, h, q;	scanf("%d %d %d", &t, &n, &T);
	if(t == 1)
	{
		for(int i = 1; i <= T; ++i)
		{
			scanf("%d%d", &x, &y);
			printf("%d\n", x);
		}
	}
	else
	{
		for(int i = 1; i <= T; ++i)
		{
			scanf("%d%d", &q, &h);
			if(q == h)	printf("yes\n");
			else printf("no\n");			
		}
	}
	return 0;
}
