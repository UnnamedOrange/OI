#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <queue>

using namespace std;
typedef long long ll;
const ll mod = 998244353;

struct edge{
	int to, nxt;
}e[200005];
struct query{
	int l, r, t, a, b, id, ans;
}d[100005];
struct modify{
	int p, x1, x2;
}md[100005];
int h[100005], cnt;

void addedge(int x, int y){
	cnt++; e[cnt].to = y; e[cnt].nxt = h[x]; h[x] = cnt;
	cnt++; e[cnt].to = x; e[cnt].nxt = h[y]; h[y] = cnt;
}
int id[100005], end[100005], dfn;
void dfs(int x, int fa){
	id[x] = ++dfn; end[x] = id[x];
	for(int i = h[x]; i; i = e[i].nxt){
		if(e[i].to == fa) continue;
		dfs(e[i].to, x);
		end[x] = end[e[i].to];
	}
}
int n, q, T;
int c[100005], c2[100005];
int vis[5005];
int k, pos[100005], L[100005], R[100005], M;

int cmp(query x, query y){
	if(pos[x.l] != pos[y.l]) return pos[x.l] < pos[y.l];
	if(pos[x.r] != pos[y.r]) return pos[x.r] < pos[y.r];
	return x.t < y.t;
}
int tmpc[100005];
int n1 = 0, n2 = 0;
int cntans[100005];

void add1(int x){
	vis[c[x]] ++;
	if(vis[c[x]] == 1) cntans[pos[c[x]]] ++;
}

void add2(int x){
	vis[c[x]] --;
	if(vis[c[x]] == 0) cntans[pos[c[x]]] --;
}


void modify(int l, int r, int x){
	if(md[x].p >= l && md[x].p <= r){
		add2(md[x].p);
	}
	c[md[x].p] = md[x].x2;
	if(md[x].p >= l && md[x].p <= r){
		add1(md[x].p);
	}
}

void modify2(int l, int r, int x){
	if(md[x].p >= l && md[x].p <= r){
		add2(md[x].p);
	}
	c[md[x].p] = md[x].x1;
	if(md[x].p >= l && md[x].p <= r){
		add1(md[x].p);
	}
}

int cal(int l, int r){
	int sum = 0;
	if(pos[l] == pos[r]){
		for(int i = l; i <= r; i ++){
			if(vis[i]) sum ++;
		}
		return sum;
	}
	for(int i = l; i <= R[pos[l]]; i ++){
		if(vis[i]) sum ++;
	}
	for(int i = L[pos[r]]; i <= r; i ++){
		if(vis[i]) sum ++;
	}
	for(int i = pos[l] + 1; i <= pos[r] - 1; i ++){
		sum += cntans[i];
	}
	return sum;
}

void solve(){
	int l = 1, r = 0, t = 0;
	for(int i = 1; i <= n1; i ++){
		while(t < d[i].t){
			t++;
			modify(l, r, t);
		}
		while(t > d[i].t){
			modify2(l, r, t);
			t--;
		}
		while(t > d[i].t){
			modify2(l, r, t);
			t--;
		}
		while(r < d[i].r){
			r++;
			add1(r);
		}
		while(l > d[i].l){
			l--;
			add1(l);
		}
		while(r > d[i].r){
			add2(r);
			r--;
		}
		while(l < d[i].l){
			add2(l);
			l++;
		}
		d[i].ans = cal(d[i].a, d[i].b);
	}
}
int Ans[100005];
int main(){
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &T);
	for(int i = 1; i <= n; i ++){
		scanf("%d", &c2[i]);
	}
	int lstans = 0;
	for(int i = 1; i < n; i ++){
		int x, y;
		scanf("%d%d", &x, &y);
		addedge(x, y);
	}
	
	dfs(1, 0);
	
	for(int i = 1; i <= n; i ++){
		c[id[i]] = c2[i];
	}
	if(n <= 5000 && q <= 5000){
		while(q--){
			int opt, u, l, r;
			scanf("%d", &opt);
			if(opt == 1){
				scanf("%d%d%d", &u, &l, &r);
				if(T) u ^= lstans, l ^= lstans, r ^= lstans;
				lstans = 0;
				for(int i = id[u]; i <= end[u]; i ++){
					if(!vis[c[i]] && c[i] >= l && c[i] <= r){
						vis[c[i]] = 1; lstans ++;
					}
				}
				for(int i = id[u]; i <= end[u]; i ++){
					if(vis[c[i]]){
						vis[c[i]] = 0;
					}
				}
				printf("%d\n", lstans);
			}else{
				scanf("%d%d", &u, &l);
				if(T) u ^= lstans, l ^= lstans;
				c[id[u]] = l;
			}
		}
		return 0;
	}
	k = ceil(pow(n, 1.0 / 3));
	for(int i = 1; i <= n; i ++) pos[i] = (i - 1) / k + 1;
	M = pos[n];
	for(int i = 1; i <= M; i ++){
		L[i] = (i - 1) * k + 1;
		R[i] = i * k;
	}
	R[M] = n;
	for(int i = 1; i <= n; i ++){
		tmpc[i] =  c[i];
	}
	for(int i = 1; i <= q; i ++){
		int opt, u, l, r;
		scanf("%d", &opt);
		if(opt == 1){
			scanf("%d%d%d", &u, &l, &r);
			n1 ++; d[n1].l = id[u], d[n1].r = end[u], d[n1].a = l, d[n1].b = r; d[n1].t = n2;
			d[n1].id = n1;
		}else{
			n2 ++;
			scanf("%d%d", &md[n2].p, &md[n2].x2);
			md[n2].p = id[md[n2].p];
			md[n2].x1 = tmpc[md[n2].p];
			tmpc[md[n2].p] = md[n2].x2;
		}
	}
	sort(d + 1, d + n1 + 1, cmp);
	solve();
	for(int i = 1; i <= n1; i ++){
		Ans[d[i].id] = d[i].ans;
	}
	for(int i = 1; i <= n1; i ++){
		printf("%d\n", Ans[i]);
	}
	
	return 0;
}
