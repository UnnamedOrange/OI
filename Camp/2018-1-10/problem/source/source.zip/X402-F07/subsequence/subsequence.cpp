#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=4005,inf=0x3f3f3f3f;
int n,m,k,a[maxn],b[maxn];
int dp[2][maxn],f[2][maxn][maxn],pos[2][maxn][maxn],Min[2][maxn];
void init(){
	memset(Min,inf,sizeof(Min));
	Min[0][0]=Min[1][0]=1;
	DREP(i,n,0)
		REP(j,1,k){
			pos[0][i][j]=j==a[i]?i:pos[0][i+1][j];
			chkmin(Min[0][i],Min[0][pos[0][i+1][j]]+1);
		}
	DREP(i,m,0)
		REP(j,1,k){
			pos[1][i][j]=j==b[i]?i:pos[1][i+1][j];
			chkmin(Min[1][i],Min[1][pos[1][i+1][j]]+1);
		}
	memset(f,-1,sizeof(f));
	f[0][0][0]=f[1][0][0]=0;
	REP(j,0,min(n,m))
		REP(i,j,n-1){
			int p=f[0][i][j];
			if(p==-1)continue;
			REP(l,1,k)
				if((pos[0][i+1][l])&&(pos[1][p+1][l]))
					chkmax(f[0][pos[0][i+1][l]][j+1],pos[1][p+1][l]);
		}
	REP(j,0,min(n,m))
		REP(i,j,m-1){
			int p=f[1][i][j];
			if(p==-1)continue;
			REP(l,1,k)
				if((pos[1][i+1][l])&&(pos[0][p+1][l]))
					chkmax(f[1][pos[1][i+1][l]][j+1],pos[0][p+1][l]);
		}
}
int solve0(){
	static int vis[maxn];
	int cnt=0,res=inf;
	REP(i,0,n)
		REP(j,0,min(i,m)){
			int p=f[0][i][j];
			if(p==-1)continue;
			REP(l,1,k)if((!pos[0][i+1][l])&&(!pos[1][p+1][l]))chkmin(res,j+1);
		}
	REP(i,0,m)
		REP(j,0,min(n,i)){
			int p=f[1][i][j];
			if(p==-1)continue;
			REP(l,1,k)if((!pos[1][i+1][l])&&(!pos[0][p+1][l]))chkmin(res,j+1);
		}
	return res;
}
int solve1(){
	int res=inf;
	memset(dp,inf,sizeof(dp));
	REP(i,0,n)
		REP(j,0,min(i,m)){
			int p=f[0][i][j];
			if(p==-1)continue;
			REP(l,1,k)
				if((pos[0][i+1][l])&&(!pos[1][p+1][l]))chkmin(dp[0][pos[0][i+1][l]],j);
		}
	REP(i,0,m)
		REP(j,0,min(n,i)){
			int p=f[1][i][j];
			if(p==-1)continue;
			REP(l,1,k)
				if((pos[1][i+1][l])&&(!pos[0][p+1][l]))chkmin(dp[1][pos[1][i+1][l]],j);
		}
	REP(i,1,n)chkmin(res,dp[0][i]+Min[0][i]);
	REP(i,1,m)chkmin(res,dp[1][i]+Min[1][i]);
	return res;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
#endif
	n=read(),m=read(),k=read();
	REP(i,1,n)a[i]=read();
	REP(i,1,m)b[i]=read();
	init();
	int ans=min(solve0(),solve1());
	write(ans,'\n');
	return 0;
}
