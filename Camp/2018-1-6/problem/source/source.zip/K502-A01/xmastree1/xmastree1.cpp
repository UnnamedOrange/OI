#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;
const int Maxn = 200000 + 100;
int N, Q, T, lastans;
int Begin[Maxn], To[Maxn], Next[Maxn], e;
int A[Maxn], dfn[Maxn], Index;
inline void add(int x, int y)
{
	To[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}
int Ans, fa[Maxn], P[Maxn];
inline void dfs1(int x)
{
	dfn[x] = ++Index;
	for (int i = Begin[x]; i; i = Next[i])
	{
		int y = To[i];
		if (fa[x] == y) continue;
		fa[y] = x;
		dfs1(y);
	}
}
inline void dfs(int x, int l, int r)
{
	if (A[x] >= l && A[x] <= r && !P[A[x]]) ++Ans, P[A[x]] = 1;
	for (int i = Begin[x]; i; i = Next[i])
	{
		int y = To[i];
		if (y == fa[x]) continue;
		dfs(y, l, r);
	}
}
inline void BF1()
{
	dfs1(1);
	while (Q--)
	{
		int type;
		scanf("%d", &type);
		if (type == 1)
		{
			int u, l, r;
			Ans = 0;
			memset(P, 0, sizeof(P));
			scanf("%d%d%d", &u, &l, &r);
			if (T) u ^= lastans, l ^= lastans, r ^= lastans;
			dfs(u, l, r);
			cout<<Ans<<endl;
			lastans = Ans;
		}
		else 
		{
			int u, c;
			scanf("%d%d", &u, &c);
			if (T) u ^= lastans, c ^= lastans;
			A[u] = c;
		}
	}
}
int main()
{
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	scanf("%d%d%d", &N, &Q, &T);
	for (int i = 1; i <= N; ++i)
		scanf("%d", &A[i]);
	for (int i = 1; i < N; ++i)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		add(x, y);
		add(y, x);
	}
//	if (T)
//	{
		BF1();
//	}
//	else BF2();
	return 0;
}
