//2018-1-12
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000+5)
const int P = 998244353;

struct node{
	int u, v;
}po[N];

int n, m, nn;
vector<int> G[N];
bool vis[N];

bool Dfs(int now, int sy, int st){
	if(sy == 1){
		For(i, 0, G[now].size()-1) if(G[now][i] == st) return true;
		return false;
	}

	vis[now] = true;
	For(i, 0, G[now].size()-1)
		if(!vis[G[now][i]] && Dfs(G[now][i], sy-1, st)){
			vis[now] = false; return true;
		}
	vis[now] = false;

	return false;
}

bool Check(){
	For(i, 1, n) if(Dfs(i, m, i)) return true;
	return false;
}

int main(){
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);

	scanf("%d%d", &n, &m);

	if(m == 3){
		int tmp = n*(n-1)/2, ret = 1;
		For(i, 1, tmp) ret = 1ll * ret * 2 % P;
		
		tmp = 1;
		For(i, 2, n) tmp = 1ll * tmp * i % P;
		ret -= tmp; if(ret < 0) ret += P;

		printf("%d\n", ret);
		return 0;
	}

	For(i, 1, n) For(j, i+1, n) po[++nn] = (node){i, j};

	int ans = 0;
	For(i, 0, (1<<nn)-1){
		For(j, 1, n) G[j].clear();
		For(j, 1, nn)
			if(i & (1<<(j-1))) G[po[j].u].pb(po[j].v);
			else G[po[j].v].pb(po[j].u);
		
		if(Check()) ++ans;
	}
	printf("%d\n", ans);

	return 0;
}
