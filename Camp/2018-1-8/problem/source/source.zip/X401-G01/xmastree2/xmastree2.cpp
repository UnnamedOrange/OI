#include<cstdio>
#include<algorithm>
#include<cstring>
#define NN 300200
#define LL long long
using namespace std;
LL ans,ANS,sum[NN],rlsum[NN],tot;
int fir[NN],dad[NN],wz[NN],roadto[2*NN],road[2*NN],ROAD[2*NN],ROADTO[2*NN],b[NN],num[NN],r[NN],v[NN],n,WZ[NN];

struct S
{
  int n,nm;
  LL s;
}dui[4*NN],a[NN];

bool cmp(S t1,S t2)
{
  return t1.s*t2.n<t2.s*t1.n;
}

bool sma(int t1,int t2)
{
  return dui[t1].s*dui[t2].n<dui[t2].s*dui[t1].n;
}

int findad(int x)
{
  if(!dad[x]) return x;
  else return dad[x]=findad(dad[x]);
}

void gx(int num)
{
  if(sma(num,num/2)) swap(dui[num],dui[num/2]),gx(num/2);
  else if(sma(num*2,num) || sma(num*2+1,num))
    {
	  if(sma(num*2+1,num*2))
	    swap(dui[num],dui[num*2+1]),gx(num*2+1);
	  else 
	    swap(dui[num],dui[num*2]),gx(num*2);
	}
}

void dfs(int numb,int from)
{
  int t=wz[numb],i,tt=0,t1,t2;
  num[numb]=1,sum[numb]=rlsum[numb]=v[numb];
  while(t)
  {
  if(road[t]!=from)
    {
     dfs(road[t],numb);
    }
  t=roadto[t];
  }
  t=wz[numb];
  while(t)
  {
  if(road[t]!=from)
    {
     a[++tt].nm=road[t];
	 a[tt].s=sum[road[t]];
	 a[tt].n=num[road[t]];
    }
  t=roadto[t];
  }
  sort(a+1,a+1+tt,cmp);
  for(i=1;i<=tt;i++)
    {
	  if(sum[numb]*a[i].n>a[i].s*num[numb])
	   {
	    rlsum[numb]+=(num[numb])*sum[a[i].nm]+rlsum[a[i].nm];
	    num[numb]+=a[i].n,sum[numb]+=a[i].s;
	    t1=findad(numb),t2=findad(a[i].nm);
	    if(t1!=t2) dad[t2]=t1;
	    roadto[fir[a[i].nm]]=wz[numb],wz[numb]=wz[a[i].nm];
	   }
	}
}

void dfs2(int numb,int from,int prv)
{
  int t,dd,i,tt;
  tot=1,dui[1].nm=numb,dui[1].n=num[numb],dui[1].s=sum[numb];
  while(tot)
    {
	  t=wz[dui[1].nm],dd=findad(dui[1].nm);
	  b[dui[1].nm]=1,ans+=(prv)*sum[dui[1].nm]+rlsum[dui[1].nm],prv+=num[dui[1].nm];
	  dui[1]=dui[tot],dui[tot].s=dui[tot].n=0,tot--,gx(1);
	  while(t)
	    {
	      tt=findad(road[t]);
		  if(!b[tt] && tt!=dd)
		    {
			  dui[++tot].nm=road[t];
			  dui[tot].n=num[road[t]];
			  dui[tot].s=sum[road[t]];
			  gx(tot);
			}
		  t=roadto[t];
		}
	}
}

int main()
{
  int i,j,x,y;
  freopen("xmastree2.in","r",stdin);
  freopen("xmastree2.out","w",stdout);
  scanf("%d",&n);
  for(i=1;i<n;i++)
    {
	  scanf("%d%d",&x,&y);
	  roadto[++tot]=ROADTO[tot]=wz[x],road[tot]=ROAD[tot]=y,WZ[x]=wz[x]=tot;
	  roadto[++tot]=ROADTO[tot]=wz[y],road[tot]=ROAD[tot]=x,WZ[y]=wz[y]=tot;
	  if(!roadto[wz[x]]) fir[x]=wz[x];
	  if(!roadto[wz[y]]) fir[x]=wz[y];
	}
  for(i=1;i<=n;i++) scanf("%d%d",&v[i],&r[i]);
  for(i=1;i<=n;i++)
	  if(r[i])
	  {
	   dfs(i,0),ans=0;
	   dfs2(i,0,0),ANS=max(ANS,ans);
	   memset(num,0,sizeof(num));
	   memset(sum,0,sizeof(sum));
	   memset(dad,0,sizeof(dad));
	   memset(b,0,sizeof(b));
	   memset(rlsum,0,sizeof(rlsum));
	   for(j=1;j<=n;j++) wz[j]=WZ[j];
	   for(j=1;j<=(n-1)*2;j++) road[j]=ROAD[j],roadto[j]=ROADTO[j];
	  }
  printf("%lld\n",ANS);
}

