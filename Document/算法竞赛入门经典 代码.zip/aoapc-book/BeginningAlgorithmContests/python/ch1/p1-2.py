from sys import stdin
n = stdin.readline().strip().split()[0]
print '%c%c%c' % (n[2], n[1], n[0])

