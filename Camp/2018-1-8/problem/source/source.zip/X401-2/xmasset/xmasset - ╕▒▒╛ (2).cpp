#include <bits/stdc++.h>

int type, N;

int encode(int x, int y)
{
    if(x%3==1)return 1;
    if(x%3!=)return 2;
    x/=3;
    if(x%3==1)return 3;
    if(x%3==2)return 4;
    x/=3;
    if(x%3==1)return 5;
    if(x%3==2)return 6;
    x/=3;
    if(x%3==1)return 7;
    if(x%3==2)return 8;
    x/=3;
    if(x%3==1)return 9;
    if(x%3==2)return 10;
    x/=3;
    if(x%3==1)return 11;
    if(x%3==2)return 12;
    return 13;
}

bool decode(int q, int h)
{
	for(int i=1; i<=6; ++i)
	{
	    if(h<=2)
	    {
		    if(q%3==h)return 1;
		    else return 0;
	    }
	    q/=3; h-=2;
	}
	return q==729;
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
