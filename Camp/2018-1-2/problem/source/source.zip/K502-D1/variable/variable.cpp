#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>
#include <cmath>

using namespace std;

int T;
int n, W, p, q;
long long x[1100], y[1100], z[1100], a[1100], b[1100], c[1100], d[1100], e[1100], f[1100];
struct com {
	int x;
	int y;
	int r;
} co[1100];
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

long long ans = 0;
long long w[600];
void open()
{
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}
bool judge()
{
	for(int i = 1; i <= q; i++) {
		if(co[i].r == 0) {
			if(w[co[i].x] > w[co[i].y]) {
				return false;
			}
		} else if(co[i].r == 1) {
			if(w[co[i].x] != w[co[i].y]) {
				return false;
			}
		} else {
			if(w[co[i].x] >= w[co[i].y]) {
				return false;
			}
		}
	}
	return true;
}
long long cal(int k)
{
	return a[k] * abs(w[x[k]]-w[y[k]]) + b[k] * abs(w[y[k]] - w[z[k]]) + c[k] * abs(w[z[k]] - w[x[k]]) + d[k] * (w[x[k]] - w[y[k]]) + e[k] * (w[y[k]] - w[z[k]]) + f[k] * (w[z[k]] - w[x[k]]);
}
void DFS(int k, long long sum)
{
	if(k == n + 1) {
		if(judge()) {
			for(int i = 1; i <= p; i++) {
				sum += cal(i);
			}
			if(ans > sum) {
				ans = sum;
			}
		}
		return ;
	}
	w[k] = W;
	DFS(k + 1, sum + W);
	w[k] = -1 * W;
	DFS(k + 1, sum - W);
}
int main()
{
	open();
	T = read();
	while(T--) {
		ans = 1e9;
		n = read(), W = read(), p = read(), q = read();
		for(int i = 1; i <= p; i++) {
			x[i] = read(), 	y[i] = read(), z[i] = read(), a[i] = read(), b[i] = read(), c[i] = read(), d[i] = read(), e[i] = read(), f[i] = read();		
		}
		for(int i = 1; i <= q; i++) {
			co[i].x = read(), co[i].y = read(), co[i].r = read();
		}
		DFS(1, 0);
		printf("%lld\n", ans);
	}
	close();
	return 0;
}
