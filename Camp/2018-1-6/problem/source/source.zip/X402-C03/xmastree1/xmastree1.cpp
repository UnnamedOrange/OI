#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}
inline void write(int x){
	if(x>9)write(x/10);
	putchar(x%10+48);
}

const int maxn=1e5+10;
int n,q,t,c[maxn],lastans;
int fa[maxn],size[maxn],id[maxn],dfn,rnk[maxn];
bitset<maxn> res;
vector<int> g[maxn];

void dfs(int pos){
	size[pos]=1;
	rnk[id[pos]=++dfn]=pos;
	for(int i=0,v;i<g[pos].size();++i)
		if((v=g[pos][i])!=fa[pos]){
			fa[v]=pos;
			dfs(v);
			size[pos]+=size[v];
		}
}
namespace segt{
	const int maxsize=300;
	bitset<maxn> st[maxsize];
	vector<int> vec[maxn<<2];
	inline void bottom(int rt,int pos){
		if(rt<maxsize){
			st[rt]=0;
			st[rt][c[pos]]=true;
		}
		else
			vec[rt][0]=c[pos];
	}
	inline void push_up(int rt){
		if(rt>=maxsize){
			vec[rt].clear();
			vector<int>&l=vec[rt<<1],&r=vec[rt<<1|1],&now=vec[rt];
			vector<int>::iterator p=vec[rt<<1].begin(),q=vec[rt<<1|1].begin();
			while(p!=l.end()&&q!=r.end())
				if((*p)<(*q))
					now.push_back(*p),++p;
				else if((*p)>(*q))
					now.push_back(*q),++q;
				else
					now.push_back(*p),++p,++q;
			while(p!=l.end())
				now.push_back(*p),++p;
			while(q!=r.end())
				now.push_back(*q),++q;
		}
		else
			if((rt<<1)<maxsize)
				st[rt]=st[rt<<1]|st[rt<<1|1];
			else{
				st[rt]=0;
				for(int i=0;i<vec[rt<<1].size();++i)
					st[rt][vec[rt<<1][i]]=true;
				for(int i=0;i<vec[rt<<1|1].size();++i)
					st[rt][vec[rt<<1|1][i]]=true;
			}
	}
	void build(int rt,int l,int r){
		if(l==r){
			if(rt<maxsize)
				st[rt][c[rnk[l]]]=true;
			else
				vec[rt].push_back(c[rnk[l]]);
			return;
		}
		int mid=l+r>>1;
		build(rt<<1,l,mid);
		build(rt<<1|1,mid+1,r);
		push_up(rt);
	}
	void modify(int rt,int l,int r,int pos){
		if(l==r){
			bottom(rt,rnk[l]);
			return;
		}
		int mid=l+r>>1;
		if(pos<=mid)
			modify(rt<<1,l,mid,pos);
		else
			modify(rt<<1|1,mid+1,r,pos);
		push_up(rt);
	}
	void query(int rt,int l,int r,int x,int y){
		if(l==x&&r==y){
			if(rt<maxsize)
				res|=st[rt];
			else
				for(int i=0;i<vec[rt].size();++i)
					res[vec[rt][i]]=true;
			return;
		}
		int mid=l+r>>1;
		if(y<=mid)
			query(rt<<1,l,mid,x,y);
		else if(x>mid)
			query(rt<<1|1,mid+1,r,x,y);
		else{
			query(rt<<1,l,mid,x,mid);
			query(rt<<1|1,mid+1,r,mid+1,y);
		}
	}
}

int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read();q=read();t=read();
	for(int i=1;i<=n;++i)
		c[i]=read();
	for(int i=1,u,v;i<n;++i){
		u=read();v=read();
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs(1);
	segt::build(1,1,n);
	while(q--){
		int opt=read(),u,l,r;
		if(t)
			u=read()^lastans;
		else
			u=read();
		if(opt==1){
			if(t)
				l=read()^lastans,r=read()^lastans;
			else
				l=read(),r=read();
			res=0;
			segt::query(1,1,n,id[u],id[u]+size[u]-1);
			write(lastans=((res>>l)<<l+maxn-r-1).count());
			putchar('\n');
		}
		else{
			if(t)
				l=read()^lastans;
			else
				l=read();
			c[u]=l;
			segt::modify(1,1,n,id[u]);
		}
	}
	return 0;
}
