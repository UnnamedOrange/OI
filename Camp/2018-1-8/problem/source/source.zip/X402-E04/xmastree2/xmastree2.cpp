#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=100010,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
}
int n,r[N],w[N],p[N],Begin[N],Next[N<<1],e,to[N<<1];
inline void add(int x,int y){
	to[++e]=y,Next[e]=Begin[x],Begin[x]=e;
}
void init(){
	read(n);
	For(i,1,n-1){
		int x,y;
		read(x),read(y);
		add(x,y),add(y,x);
	}
	For(i,1,n)read(w[i]),read(r[i]);
}
int fa[N];
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
void dfs(int u,int f){
	fa[u]=f;
	Rep(i,u)
		if(fa[u]^v)dfs(v,u);
}
int vis[N],ans=0;
void Dfs(int now,int val){
	if(now>n)
		return void (ans=max(ans,val));
	For(i,1,n)if(!vis[i]&&vis[fa[i]]){
		vis[i]=1;
		Dfs(now+1,val+now*w[i]);
		vis[i]=0;
	}
}
void solve(){
	vis[0]=1;
	For(i,1,n)if(r[i]){
		dfs(i,0);
		Dfs(1,0);
	}
	printf("%d\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
