#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define maxn 1000010
inline int read(){
	int ret=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ret=ret*10+ch-'0';
		ch=getchar();
	}
	return ret*f;
}

int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	printf("0 0 3 1\n");
	return 0;
}

