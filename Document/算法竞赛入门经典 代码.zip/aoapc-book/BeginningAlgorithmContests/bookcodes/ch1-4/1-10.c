#include<stdio.h>
int main(){
  int a, b;
  scanf("%d%d", &a, &b);
  printf("%d %d\n", b, a);
  return 0;
}
