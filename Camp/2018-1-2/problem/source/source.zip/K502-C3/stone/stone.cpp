#include<iostream>
#include<cstdio>
#define cur_dp dp[sit[0]][sit[1]][sit[2]][sit[3]][sit[4]]
#define mod 1000000007
using namespace std;
int dp[8][8][8][8][8]={0};
int num[8]={0};
int use[8]={0};
int n;
int b,a;
int ans[5]={0};//1==first_win,2==second_win,3==bob
bool too_small(int sit[]){
	for(int i=0;i<5;++i){
		if(sit[i]>=min(a,b)){
			return false;
		}
	}
	return true;
}
int dy_p(int sit[]){
	if(cur_dp)return cur_dp;
	if(too_small(sit)){
		cur_dp=4;
		return 4;
	}
	int exist[2][5]={0};
	if(sit[0]>=b){
		sit[0]-=b;
		exist[0][dy_p(sit)]=1;
		sit[0]+=b;
	}
	if(sit[1]>=b){
		sit[1]-=b;
		exist[0][dy_p(sit)]=1;
		sit[1]+=b;
	}
	if(sit[2]>=b){
		sit[2]-=b;
		exist[0][dy_p(sit)]=1;
		sit[2]+=b;
	}
	if(sit[3]>=b){
		sit[3]-=b;
		exist[0][dy_p(sit)]=1;
		sit[3]+=b;
	}
	if(sit[4]>=b){
		sit[4]-=b;
		exist[0][dy_p(sit)]=1;
		sit[4]+=b;
	}
	if(sit[0]>=a){
		sit[0]-=a;
		exist[1][dy_p(sit)]=1;
		sit[0]+=a;
	}
	if(sit[1]>=a){
		sit[1]-=a;
		exist[1][dy_p(sit)]=1;
		sit[1]+=a;
	}
	if(sit[2]>=a){
		sit[2]-=a;
		exist[1][dy_p(sit)]=1;
		sit[2]+=a;
	}
	if(sit[3]>=a){
		sit[3]-=a;
		exist[1][dy_p(sit)]=1;
		sit[3]+=a;
	}
	if(sit[4]>=a){
		sit[4]-=a;
		exist[1][dy_p(sit)]=1;
		sit[4]+=a;
	}
	if((exist[0][4]||exist[0][2])&&(exist[1][4]||exist[1][1]))cur_dp=3;
	if(!(exist[0][4]||exist[0][2])&&!(exist[1][4]||exist[1][1]))cur_dp=4;
	if(!(exist[1][1]||exist[1][4])&&(exist[0][2]||exist[0][4]))cur_dp=2;
	if((exist[1][1]||exist[1][4])&&!(exist[0][2]||exist[0][4]))cur_dp=1;
	return cur_dp;
}

void brute_force(){
	for(int i=0;i<n;++i){
		scanf("%d",&num[i]);
	}
	int sit=(1<<n)-1;
	for(int son=0;son<=sit;++son){
		for(int i=0;i<n;++i){
			if(son&(1<<i)){
				use[i]=num[i];
			}
			else use[i]=0;
		}
		++ans[dy_p(use)];
	}
	for(int i=1;i<=4;++i)printf("%d ",ans[i]);
}
long long ksm(long long a,long long b){
	long long op=1;
	while(b){
		if(b&1){
			(op*=a)%=mod;
		}
		b>>=1;
		(a*=a)%=mod;
	}
	return op;
}
void spec_same(){
	printf("0 0");
	int now=0;
	int cnt[2],tp;
	for(int i=1;i<=n;++i){
		scanf("%d",&tp);
		++cnt[(tp/a)&1];
	}
	if(!cnt[1])printf(" 0 %lld",ksm(2,n));
	else printf(" %lld %lld",ksm(2,n-1),ksm(2,n-1));
	return;
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d",&n);
	scanf("%d%d",&a,&b);
	if(n<=5)brute_force();
	if(a==b)spec_same();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
