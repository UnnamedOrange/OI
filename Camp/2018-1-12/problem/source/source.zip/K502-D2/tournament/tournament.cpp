#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

const int N = 100000 + 1000;
const int mod = 998244353;

#define LL long long

int n, k;
int F[10], v[110], f[110], nex[110], ban[110], EID = 1, tot = 0, ans = 0, vis[10], flag = 0;
LL fac[N], inv[N];

namespace file{
	inline void open()
	{
		freopen("tournament.in", "r", stdin);
		freopen("tournament.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

namespace input{
	inline int read()
	{
		int a = 0;
		char ch;
		int f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}

	
	inline void Get()
	{
		n = read(), k = read();
	}
}

namespace math{
	inline LL ksm(LL a, int b)
	{
		LL base = a, ret = 1;
		while(b > 0)
		{
			if(b & 1)
				ret = ret * base % mod;
			base = base * base % mod;
			b >>= 1;
		}
		return ret;
	}
}

namespace brute{
	inline void add(int u, int t)
	{
		nex[EID] = F[u];
		v[EID] = t;
		f[EID] = u;
		ban[EID] = 1;
		F[u] = EID++;
	}
	
	inline void scan(int p, int d)
	{
		vis[p] = d;
		for(int i = F[p];i;i = nex[i])
		{
			if(ban[i] == 1)
				continue;
			int t = v[i];
			if(vis[t] && abs(d - vis[t]) + 1 == k)
			{
				flag = 1;
				return;
			}
			//cout << p << " " << t << " " << vis[t] << endl;
			if(!vis[t])
				scan(t, d + 1);
			if(flag == 1)
				return;
		}
		vis[p] = 0;
	}
	
	inline bool check()
	{
		flag = 0;
		memset(vis, 0, sizeof vis);
		for(int i = 1;i <= n;++i)
		{
			scan(i, 0);
			if(flag == 1)
				return true;
		}
		return false;
	}
	
	inline void dfs(int x)
	{
		if(x == tot + 1)
		{
			if(check())
				++ans;
			/*for(int i = 1;i <= tot * 2;++i)
				if(ban[i] == 0)
					printf("from %d to %d\n", f[i], v[i]);
			printf("%d\n", ans);
			printf("---------------------\n");*/
			return;
		}
		ban[2 * x - 1] = 0;
		dfs(x + 1);
		ban[2 * x - 1] = 1;
		ban[2 * x] = 0;
		dfs(x + 1);
		ban[2 * x] = 1;
	}
	
	inline void solve()
	{
		for(int i = 1;i <= n;++i)
			for(int j = i + 1;j <= n;++j)
				add(i, j), add(j, i), ++tot;
		dfs(1);
		printf("%d\n", ans);
	}
}

namespace eq{
	inline void init()
	{
		fac[0] = inv[0] = 1;
		for(int i = 1;i <= n;++i)
		{
			fac[i] = fac[i - 1] * i % mod;
			inv[i] = math::ksm(fac[i], mod - 2);
		}
	}
	
	inline LL C(int x, int y)
	{
		return fac[x] * inv[y] % mod * inv[x - y] % mod;
	}
	
	inline void solve()
	{
		printf("19260817\n");
	}
}

namespace method{
	inline void solve()
	{
		printf("19260817\n");
	}
}

namespace check{
	inline void deter()
	{
		if(n <= 6)
			brute::solve();
		else
			method::solve();
	}
}

int main()
{
	open();
	input::Get();
	check::deter();
	close();
	return 0;
} 
