#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	freopen("sad.out", "wt", stdout); 
	puts("0"); 
	return 0; 
}

