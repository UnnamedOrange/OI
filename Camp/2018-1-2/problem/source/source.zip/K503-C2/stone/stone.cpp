#include <stdio.h>
#define maxn 100010
#define modn (long long)(1e9+7)
int a[4]={0},ans[4]={0},p[maxn],n,x,y,k,num,i;
void swap(int &x,int &y)
{
	int t=x;
	x=y;
	y=t;
}
int power(int x,int y)
{
	long long s=1,i=x;
	for (;y>0;y=(y>>1))
	{
		if (y&1) s=(s*i)%modn;
		i=(i*i)%modn;
	}
	return s;
}
int c(int x,int y)
{
	return (long long)p[y]*(long long)power(p[x],modn-2)%modn*(long long)power(p[y-x],modn-2)%modn;
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&x,&y);
	if (x<=y) k=0;
		else
		{
			swap(x,y);
			k=1;
		}
	p[0]=1;
	for (i=1;i<=n;i++)
		p[i]=(long long)p[i-1]*(long long)i%modn;
	for (i=0;i<n;i++)
	{
		scanf("%d",&num);
		num%=(x+y);
		if (num<x) a[0]++;
			else if (num<y) a[1]++;
				else if (num<x*2) a[2]++;
					else a[3]++;
	}
	for (i=0;i<=a[2];i+=2)
	{
		ans[2]=(ans[2]+(long long)power(2,a[0])*(long long)c(i,a[2])%modn*(long long)a[3]%modn)%modn;
		ans[3]=(ans[3]+(long long)power(2,a[0])*(long long)c(i,a[2])%modn)%modn;
	}
	for (i=1;i<=a[2];i+=2)
		ans[2]=(ans[2]+(long long)power(2,a[0])*(long long)c(i,a[2])%modn)%modn;
	ans[k]=((power(2,n)-ans[2]+modn)%modn-ans[3]+modn)%modn;
	printf("%d %d %d %d",ans[0],ans[1],ans[2],ans[3]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
