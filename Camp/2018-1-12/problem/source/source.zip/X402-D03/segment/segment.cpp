#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 998244353;
const int MAXN = 100010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, K;
ll ans, inv2;

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

inline ll sum(ll a, ll b) {
	return (a+b)*(b-a+1)%MOD*inv2%MOD;
}

int l[MAXN], r[MAXN];
int a[MAXN];

void dfs(int u) {
	int i, j, k;
	if(u == n+1) {
		/*for(i = 1; i <= n; i++)
			printf("%d %d\n", l[i], r[i]);
		printf("\n");*/
		for(i = 1; i <= m; i++) ans = (ans+qpow(a[i], K))%MOD;
		return;
	}
	for(i = l[u-1]+1; i <= m; i++) {
		for(j = max(i, r[u-1]+1); j <= m; j++) {
			l[u] = i, r[u] = j;
			for(k = i; k < j; k++) a[k]++;
			dfs(u+1);
			for(k = i; k < j; k++) a[k]--;
		}
	}
}

ll dp[360][360][360], pre[360][360];

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

inline void solve1() {
	int i, j, k;
	for(i = 0; i <= m; i++) dp[0][0][i] = 1;
	for(i = 1; i <= m; i++) {
		update(dp[0][i][i], dp[0][i-1][i]);
		for(j = i+1; j <= m; j++) {
			update(dp[0][i][j], dp[0][i-1][j]);
			update(dp[0][i][j], dp[0][i][j-1]);
			update(dp[0][i][j], MOD-dp[0][i-1][j-1]);
		}
	}
	for(k = 1; k <= n; k++) {
		for(i = 1; i <= m; i++) 
			for(j = i; j <= m; j++) 
				dp[k][i][j] = dp[k-1][i-1][j-1];
		for(i = 0; i <= m; i++) dp[k][0][i] = 0;
		for(i = 1; i <= m; i++) {
			update(dp[k][i][i], dp[k][i-1][i]);
			for(j = i+1; j <= m; j++) {
				update(dp[k][i][j], dp[k][i-1][j]);
				update(dp[k][i][j], dp[k][i][j-1]);
				update(dp[k][i][j], MOD-dp[k][i-1][j-1]);
			}
		}
	}
	for(i = 1; i <= m; i++) {
		for(j = i; j <= m; j++) {
			pre[i][j] = 0;
			for(k = 0; k < n; k++) 
				update(pre[i][j], dp[k][i-1][j-1]*dp[n-1-k][m-j][m-i]%MOD);
		}
	}
	for(i = 1; i <= m; i++) 
		for(j = 1; j <= i; j++) 
			for(k = i+1; k <= m; k++) 
				update(ans, pre[j][k]);
	printf("%lld\n", ans);
}

int main() {
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);

	inv2 = qpow(2, MOD-2);
	n = read(), m = read(), K = read();
	if(n > m) {
		printf("0\n");
		return 0;
	}
	if(n == 1) 
		printf("%lld\n", (m+1)*m%MOD*(m-1)%MOD*qpow(6, MOD-2)%MOD);
	else if(n == 2) {
		ll val = qpow(2, K);
		int l1, r1, i, j;
		for(l1 = 1; l1 <= m; l1++) 
			for(r1 = l1; r1 <= m; r1++) {
				ll s = 0;
				for(i = l1+1; i <= r1; i++) {
					ll res = (m-r1)*((i-l1+val*(r1-i)%MOD)%MOD)%MOD;
					res = (res+sum(1, m-r1))%MOD;
					ans = (ans+res)%MOD;
					s = (s+res)%MOD;
				}
				//printf("%lld\n", s);
				for(i = r1+1; i <= m; i++) {
					ll res = (sum(0, m-i)+(m-i+1)*(r1-l1)%MOD)%MOD;
					ans = (ans+res)%MOD;
					s = (s+res)%MOD;
				}
				//printf("%d %d %lld\n", l1, r1, s);
			}
		printf("%lld\n", ans);
	}
	else if(K == 1) solve1();
	else {
		dfs(1);
		printf("%lld\n", ans);
	}
	return 0;
}
