#include<queue>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=1e5+5,inf=2147483647;
int head[maxn],dis[maxn];
bool INQ[maxn],cnt[maxn];
int num;
queue<int> q;
struct cp{
	int color,to,next;
}e[maxn];
void swap(int &x,int &y){
	x^=y^=x^=y;
}
inline void add(int u,int v){
	if(dis[u]<=dis[v]) dis[v]=dis[u]+1;
	else swap(u,v),dis[v]=dis[u]+1;
	e[++num].to=v;
	e[num].next=head[u];
	head[u]=num;
}
int BFS(int s,int ll,int rr){
	memset(INQ,0,sizeof(INQ));
	memset(cnt,0,sizeof(cnt));
	int ans=0;
	q.push(s);
	INQ[s]=1;
	if(e[s].color>=ll&&e[s].color<=rr&&!cnt[e[s].color]){
		ans++;
		cnt[e[s].color]=1;
	}
	while(!q.empty()){
		int u=q.front();
		q.pop();
		INQ[u]=0;
		for(int i=head[u];i;i=e[i].next){
			int v=e[i].to;
			if(e[v].color>=ll&&e[v].color<=rr&&!cnt[e[v].color]){
				ans++;
				cnt[e[v].color]=1;
			}
			if(!INQ[v]){
				q.push(v);
				INQ[v]=1; 
			}
		}
	}
	return ans;
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int n,q,t,x,u,l,r,c,ans1=0,ans2=0,F,G,f=0;
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++) dis[i]=inf;
	dis[1]=0;
	for(int i=1;i<=n;i++) scanf("%d",&e[i].color);
	for(int i=1;i<n;i++){
		scanf("%d%d",&F,&G);
		add(F,G);
	}
	for(int i=1;i<=q;i++){
		scanf("%d",&x);
		if(x==1){
			f++;
			scanf("%d%d%d",&u,&l,&r);
			ans2=BFS(u,l,r);
			if(t==1&&f>1){
				if(ans1==ans2){
					printf("1\n");
					continue;
				}
				else{
					printf("0\n");
					continue;
				}
			}
			printf("%d\n",ans2);
			ans1=ans2;
		}
		else scanf("%d%d",&u,&c),e[u].color=c;
	}
	return 0;
}
