//by yjz
#include<bits/stdc++.h>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1000000009;
//My i/o stream
struct fastio
{
	char s[100000];
	int it,len;
	fastio(){it=len=0;}
	inline char get()
	{
		if(it<len)return s[it++];it=0;
		len=fread(s,1,100000,stdin);
		if(len==0)return EOF;else return s[it++];
	}
	bool notend()
	{
		char c=get();
		while(c==' '||c=='\n')c=get();
		if(it>0)it--;
		return c!=EOF;
	}
}_buff;
#define geti(x) x=getnum()
#define getii(x,y) geti(x),geti(y)
#define getiii(x,y,z) getii(x,y),geti(z)
#define puti(x) putnum(x),putchar(' ')
#define putii(x,y) puti(x),puti(y)
#define putiii(x,y,z) putii(x,y),puti(z)
#define putsi(x) putnum(x),putchar('\n')
#define putsii(x,y) puti(x),putsi(y)
#define putsiii(x,y,z) putii(x,y),putsi(z)
inline ll getnum()
{
	ll r=0;bool ng=0;char c;c=_buff.get();
	while(c!='-'&&(c<'0'||c>'9'))c=_buff.get();
	if(c=='-')ng=1,c=_buff.get();
	while(c>='0'&&c<='9')r=r*10+c-'0',c=_buff.get();
	return ng?-r:r;
}
template<class T> inline void putnum(T x)
{
	if(x<0)putchar('-'),x=-x;
	register short a[20]={},sz=0;
	while(x)a[sz++]=x%10,x/=10;
	if(sz==0)putchar('0');
	for(int i=sz-1;i>=0;i--)putchar('0'+a[i]);
}
inline char getreal(){char c=_buff.get();while(c<=32)c=_buff.get();return c;}
struct node
{
	int lz,sum;
	void addlz(int v)
	{
		sum=1ll*sum*v%mod;
		lz=1ll*lz*v%mod;
	}
	node(){lz=1;sum=0;}
}a[2000111];
#define ls p<<1
#define rs p<<1|1
void pushdown(int p)
{
	if(a[p].lz!=1)
	{
		a[ls].addlz(a[p].lz);
		a[rs].addlz(a[p].lz);
		a[p].lz=1;
	}
}
void update(int p)
{
	a[p].sum=a[ls].sum+a[rs].sum>=mod?a[ls].sum+a[rs].sum-mod:a[ls].sum+a[rs].sum;
}
void modify(int x,int y,int l,int r,int p=1)
{
	if(x<=l&&r<=y)
	{
		a[p].addlz(2);
		return;
	}
	pushdown(p);
	int m=l+r>>1;
	if(x<=m)modify(x,y,l,m,ls);
	if(m<y)modify(x,y,m+1,r,rs);
	update(p);
}
void add(int x,int v,int l,int r,int p=1)
{
	if(l==r)
	{
		a[p].sum=(a[p].sum+v)%mod;
		return;
	}
	pushdown(p);
	int m=l+r>>1;
	if(x<=m)add(x,v,l,m,ls);
	else add(x,v,m+1,r,rs);
	update(p);
}
int query(int x,int y,int l,int r,int p=1)
{
	if(x<=l&&r<=y)return a[p].sum;
	pushdown(p);
	int m=l+r>>1,ret=0;
	if(x<=m)ret+=query(x,y,l,m,ls);
	if(m<y)ret+=query(x,y,m+1,r,rs);
	while(ret>=mod)ret-=mod;
	return ret;
}
int n,m;
pair<int,int> sg[500111];
int p[500111];
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	getii(n,m);
	for(int i=1;i<=n;i++)
	{
		int l,r;
		getii(l,r);
		sg[i]=MP(l,r);
	}
	for(int i=1;i<=m;i++)geti(p[i]);
	sort(p+1,p+m+1);
	sort(sg+1,sg+n+1);
	add(0,1,0,m);
	for(int i=1;i<=n;i++)
	{
		int l=sg[i].FF,r=sg[i].SS;
		l=lower_bound(p+1,p+m+1,l)-p;
		r=lower_bound(p+1,p+m+1,r+1)-p-1;
		int cur=query(l-1,r,0,m);
		add(r,cur,0,m);
		if(r<m)modify(r+1,m,0,m);
	}
	int ans=query(m,m,0,m);
	cout<<ans<<endl;
	return 0;
}
