#include <cmath>
#include <cctype>
#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)

using namespace std;
typedef long long ll;

int get()
{
    char c;
    while (!isdigit(c=getchar()) && c!='-');
    int s=c=='-'? -1:1,k=~s? c-'0':0;
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return s*k;
}
const int p=998244353,N=360;
int n,m,k,pw[N],f[2][N][N],s[2][N][N];

int power(int a,int b)
{
    int t=1;
    for (; b>0; b>>=1,a=1ll*a*a%p)
        b&1? t=1ll*t*a%p:0;
    return t;
}

void inc(int &x,int y)
{
    (x+=y)<p? 0:x-=p;
}

int main()
{
    freopen("segment.in","r",stdin);
    freopen("segment.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    if (n>m)
    {
        puts("0");
        return 0;
    }
    rep(i,1,m)
        pw[i]=power(i,k);
    f[0][0][0]=1;
    rep(i,1,m)
    {
        int x=i&1,y=x^1;
        rep(j,0,n)
            rep(k,0,n)
                f[x][j][k]=s[x][j][k]=0;
        rep(j,0,min(i,n))
            rep(k,0,j)
            {
                int &nf=f[x][j][k]=0,&ns=s[x][j][k]=0;
                inc(nf,f[y][j][k]),inc(ns,s[y][j][k]);
                if (j)
                    inc(nf,f[y][j-1][k]),inc(ns,s[y][j-1][k]);
                if (k)
                    inc(nf,f[y][j][k-1]),inc(ns,s[y][j][k-1]);
                if (j && k)
                    inc(nf,f[y][j-1][k-1]),inc(ns,s[y][j-1][k-1]);
                ns=(ns+1ll*nf*pw[j-k])%p;
            }
    }
    printf("%d",s[m&1][n][n]);
    return 0;
}
