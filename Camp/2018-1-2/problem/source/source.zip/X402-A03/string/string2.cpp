#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define inf (1<<20)
#define N 100010
int t,n;
char s[N];
bool check(int l,int r)
{
	while(l<r)
	{
		if(s[l]!=s[r])
			return 1;
		l++;
		r--;
	}
	return 0;
}
int main()
{
	freopen("string2.out","w",stdout);
	freopen("string.in","r",stdin);
	t=read();
	while(t--)
	{
		n=read();
		scanf("%s",s+1);
		int ans;
		if(check(1,n))
			ans=1;
		else
		{
			ans=-1;
			fr(i,1,n-1)
				if(check(1,i)&&check(i+1,n))
					ans=2;
		}
		printf("%d\n",ans);
	}
	return 0;
}