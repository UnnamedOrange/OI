#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<map>
#include<set>
#include<iomanip>
#include<ctime>
using namespace std;
typedef long long ll;
char xB[1<<15],*xT=xB,*xS=xB;
#define getchar() (xS==xT&&(xT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xT)?0:*xS++)
inline int read()
{
    int X=0,w=0; char ch=0;
    while(!isdigit(ch)) w|=ch=='-',ch=getchar();
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}
int t,n,x[25],ans;
bool dfs(int deep,int le,int p)
{
	if(le==0&&x[1]==1)return 1;
	int a[25],lr=le;
	for(int i=1;i<=n+1;++i)
	{
		a[i]=x[i];
	}
	for(int i=2;i<=n;++i)
	{
		if(p!=i)
		{
			lr=le;
			lr-=(abs(x[i+1]-x[i])>1);
			lr+=(abs(x[i+1]-x[1])>1);
			if(lr+deep+1>ans)continue;
			for(int l=1;l<=i;++l)x[l]=a[i-l+1];
			for(int l=i+1;l<=n;++l)x[l]=a[l];
			if(dfs(deep+1,lr,i))return 1;
		}
	}
	for(int i=1;i<=n;++i)x[i]=a[i];
	return 0;
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	register int i;
	t=read();
	while(t--)
	{
		n=read();
		for(i=1;i<=n;++i)
		{
			x[i]=read();
		}
		x[n+1]=n+1;
		for(i=1;i<=n;++i)
		{
			if(abs(x[i+1]-x[i])>1)++ans;
		}
		int minn=ans;
		while(!dfs(0,minn,0))++ans;
		printf("%d\n",ans);
	}
}
