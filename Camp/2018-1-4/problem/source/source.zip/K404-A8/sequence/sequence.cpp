#include <cstdio>

const int MAXN = 25 + 10;
int T, N;
int A[MAXN], B[MAXN];
int ans;

inline void swap( int &a, int &b ) {
	int temp = a; a = b; b = temp;
}

inline void Dfs( int t ) {
	register int i, j;
	if( t == 1 )
		return;
	for( i = 1; i <= N; ++i )
		if( A[i] == t ) {
			if( i == t ) {
				Dfs( t - 1 );
				return;
			}
			if( i == 1 ) {
				for( j = 1; j <= t >> 1; ++j )
					swap( A[j], A[t - j + 1] );
				++ans;
				Dfs( t - 1 );
			}
			else {
				for( j = 1; j <= i >> 1; ++j )
					swap( A[j], A[i - j + 1] );
				for( j = 1; j <= t >> 1; ++j )
					swap( A[j], A[t - j + 1] );
				ans += 2;
				Dfs( t - 1 );
			}
			return;
		}
}

inline void Dfs2( int t ) {
	if( t >= ans )
		return;
	register int i, j;
	bool flag = 1;
	for( i = 2; i <= N; ++i )
		if( B[i - 1] > B[i] )
			flag = 0;
	if( flag ) {
		ans = t;
		return;
	}
	for( i = 2; i <= N; ++i ) {
		for( j = 1; j <= i >> 1; ++j )
			swap( B[j], B[i - j + 1] );
		Dfs2( t + 1 );
		for( j = 1; j <= i >> 1; ++j )
			swap( B[j], B[i - j + 1] );
	}
}

int main() {
	freopen( "sequence.in", "r", stdin );
	freopen( "sequence.out", "w", stdout );
	register int i;
	scanf( "%d", &T );
	while( T-- ) {
		ans = 0;
		scanf( "%d", &N );
		for( i = 1; i <= N; ++i )
			scanf( "%d", A + i ), B[i] = A[i];
		Dfs( N );
		if( N <= 10 )
			Dfs2( 1 );
		printf( "%d\n", ans );
	}
	return 0;
}
