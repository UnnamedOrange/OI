#include<bits/stdc++.h>
using namespace std;
const long long md=1e9+7;
const int maxn=100100;
long long fac[maxn],inv[maxn];
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
int n,a,b;
int pd(int x){
	x=x%(a+b);
	if(x<a) return 0;
	else if(x<b) return 1;
	else return 2;
}
//0代表后,1代表A,2代表先
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int x;
	bool rev=0;
	scanf("%d%d%d",&n,&a,&b);

	fac[0]=1;
	for(int i=1;i<=n;i++)
		fac[i]=fac[i-1]*i%md;
	inv[n]=powd(fac[n],md-2);
	for(int i=n;i>=1;i--)
		inv[i-1]=inv[i]*i%md;

	if(a>b){
		swap(a,b);
		rev^=1;
	}
	int cntA=0,cnt2A=0,cnt20=0;
	int v;
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		v=pd(x);
		if(v==0) continue;
		if(v==1) cntA++;
		if(v==2){
			v=pd(x-a);
			if(v==0) cnt20++;
			else cnt2A++;
		}
	}
	long long ansA=0,ans2=0,ans0=0,get2;
	get2=cnt20==0?0:powd(2,cnt20-1);
	ans0=(powd(2,cnt20)-get2+md)%md;
	ansA=(powd(2,cntA)-1+md)*powd(2,cnt20+cnt2A)%md;
	ansA=(ansA+(powd(2,cnt2A)-1+md)%md*(powd(2,cnt20)+md))%md;
	ansA=(ansA-cnt2A*ans0%md+md)%md;
	ans2=(get2+cnt2A*ans0%md)%md;

	int num=n-cnt20-cnt2A-cntA;
	ansA=ansA*powd(2,num)%md;
	ans2=ans2*powd(2,num)%md;
	ans0=ans0*powd(2,num)%md;
	if(rev)
		printf("0 %lld %lld %lld\n",ansA,ans2,ans0);
	else
		printf("%lld 0 %lld %lld\n",ansA,ans2,ans0);
	return 0;
}
