#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)1e5+5,P=998244353;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
void Del(int &x,int y){
	x-=y;
	if(x<0)x+=P;
}
int fast(int x,int p){
	int re=1;
	while(p){
		if(p&1)re=(long long)re*x%P;
		x=(long long)x*x%P,p>>=1;
	}return re;
}
struct W{
	int to,nx;
}Lis[M*2];
int Head[M],tot;
void eAdd(int &x,int y){
	Lis[++tot]=(W){y,Head[x]};
	Head[x]=tot;
}
int n;
char C[M];
struct SHUI{
	int id[7][(1<<6)],TTT;
	int v[265][265];
	int deg[7];
	int gauss(int vvv){
		for(int i=1;i<=TTT;i++){
			int k=i;
			for(int j=i;j<=TTT;j++)
				if(v[j][i]){
					k=j;
					break;
				}
			if(k!=i)
				for(int j=0;j<=TTT;j++)
					swap(v[i][j],v[k][j]);
			for(int j=i+1,inv;j<=TTT;j++){
				if(v[j][i]==0)continue;
				inv=(long long)v[j][i]*fast(v[i][i],P-2)%P;
				for(int l=0;l<=TTT;l++)Del(v[j][l],(long long)v[i][l]*inv%P);
			}
		}
		for(int i=TTT;i>=1;i--){
			int vv=(long long)v[i][0]*fast(v[i][i],P-2)%P;
			if(i==vvv)return vv;
			for(int j=i-1;j>=1;j--)Del(v[j][0],(long long)v[j][i]*vv%P);
		}return 233;
	}
	void solve(){
		for(int i=1;i<=n;i++){
			int c=0;
			for(int j=Head[i];j;j=Lis[j].nx)c++;
			deg[i]=c;
			if(c>1){
				for(int j=0;j<(1<<n);j++)
					id[i][j]=++TTT;
			}
		}
		for(int i=1;i<=n;i++){
			int inv=fast(deg[i],P-2);
			if(deg[i]>1){
				for(int j=0,rs;j<(1<<n);j++){
					v[id[i][j]][id[i][j]]=P-1;
					for(int k=Head[i],to;k&&(to=Lis[k].to,1);k=Lis[k].nx){
						rs=j|((to-1)<<1);
						if(C[to]=='1'||rs!=j)Del(v[id[i][j]][0],inv);
						if(deg[to]!=1)v[id[i][j]][id[to][rs]]=inv;
					}
				}
			}
		}
		printf("%d\n",(1+gauss(id[1][1]))%P);
	}
}P10;
int deg[M];
struct IHSU{
	int a[M],b[M];
	int d;
	void dfs(int x,int f,int dd){
		if(x==1)d=dd;
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(to!=f)
				dfs(to,x,dd+1);
	}
	void solve(){
		a[2]=1,b[2]=0;
		for(int i=3;i<n;i++){
			a[i]=((2LL*a[i-1]-a[i-2])%P+P)%P;
			b[i]=((2LL*b[i-1]-b[i-2]-2)%P+P)%P;
		}
		int v=(long long)(P-b[n-1])%P*fast((a[n-1]-1+P)%P,P-2)%P;
		for(int i=1;i<=n;i++)if(deg[i]==1){dfs(i,i,1);break;}
		printf("%lld\n",((long long)a[d]*v+b[d]+1)%P);
	}
}P10_1;
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	Rd(n);
	scanf("%s",C+1);
	for(int i=1,x,y;i<n;i++)Rd(x),Rd(y),eAdd(x,y),eAdd(y,x),deg[x]++,deg[y]++;
	bool is_lian=true,is_all_black=true;
	for(int i=1;i<=n;i++)if(deg[i]>2)is_lian=false;
	for(int i=1;i<=n;i++)if(C[i]!='1')is_all_black=false;
//	if(0);
	if(n<=6)P10.solve();
	else if(is_lian&&is_all_black)P10_1.solve();
	
	return 0;
}
