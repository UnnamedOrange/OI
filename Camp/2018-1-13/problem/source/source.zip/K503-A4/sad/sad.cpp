//0-10pts
#include <bits/stdc++.h>
using namespace std;

struct Edge {
	int v, next;
};

const int MAXN = 1e5, MOD = 998244353, REV = 499122177;
int N, e_ptr, C[MAXN+10], head[MAXN+10];
Edge E[(MAXN<<2)+10];

inline void AddEdge(int u, int v) {
	E[++e_ptr]=(Edge){v, head[u]}; head[u]=e_ptr;
}

inline void AddPair(int u, int v) {
	AddEdge(u, v); AddEdge(v, u);
}

template<typename T>
inline void readint(T& x) {
	T f=1, r=0; char c=getchar();
	while(!isdigit(c)) { if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)) { r=r*10+c-'0'; c=getchar(); }
	x = f * r;
}

inline char readc() {
	char c=getchar();
	while(!isalnum(c) && !ispunct(c)) c=getchar();
	return c;
}

void Init() {
	int u, v;
	readint(N);
	for(int i=1; i<=N; i++) 
		C[i] = readc() - '0';
	for(int i=1; i<=N-1; i++) {
		readint(u); readint(v);
		AddPair(u, v);
	}
}

long double Dfs(int step, int u) {
	if(step>30) {
		return 0;
	}
	if(!E[head[u]].next) return 1;
	else {
		long double ret;
		if(C[u] == 0) {
			C[u] = -1;
			ret =  (1 + .5*Dfs(step+1, E[head[u]].v) + 
				.5*Dfs(step+1, E[E[head[u]].next].v));
			C[u] = 0;
		} else if(C[u] == -1)
			ret = (.5*Dfs(step+1, E[head[u]].v) + 
				.5*Dfs(step+1, E[E[head[u]].next].v));
		else //C[u]==1
			ret =  (1 + .5*Dfs(step+1, E[head[u]].v) + 
				.5*Dfs(step+1, E[E[head[u]].next].v));
		return ret;
	}
}

void Work() {
	printf("%lld", ((long long)(Dfs(1, 1)+.5))%MOD);
}

int main() {
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	Init(); Work();
}
