#include<stdio.h>
#include<algorithm>
#include<cctype>
using namespace std;
#define rep(i, a, b) for(int i = (a), i##_end_ = (b); i <= i##_end_ ; ++i)
int read() {
	int x = 0; char c = getchar();
	while(!isdigit(c)) c = getchar();
	while(isdigit(c)) {
		x = x * 10 + c - 48;
		c = getchar();
	}
	return x;
}
#define Maxn (309)
int n, m, k;
int ans, a[Maxn], b[Maxn];
int main(){
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	n = read(), m = read(), k = read();
	rep(i, 1, n) a[i] = read();
	rep(i, 1, m) b[i] = read();
	return 0;
}
