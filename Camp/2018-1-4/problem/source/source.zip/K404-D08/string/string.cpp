#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define per(a,b,c) for (int a=b;a>=c;a--)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=1250,M=510,P=998244353;
int hav[N],hav2[N],fa[N],to[N][2],f_to[N][2],len[10];
bool dfs_hav_vis[N];
int n,m,all,ns;
char s[10][110];
int ends(int u,int l,int s){
	s|=hav2[u];
	return s==all;
}
//bool vis[65][N][M];
int f[M][65][N];
int dfs(int u,int l,int s){
	if (l==m) return f[l][s][u]=ends(u,l,s);
//	if (vis[s][u][l]) return f[s][u][l];
//	vis[s][u][l]=1;
	return f[l][s][u]=(
		f[l+1][s|hav[f_to[u][0]]][f_to[u][0]]+
		f[l+1][s|hav[f_to[u][1]]][f_to[u][1]]  )%P;
}
void trans(char *s,int len){
	rep(i,1,len/2) swap(s[i],s[1+len-i]);
	rep(i,1,len) s[i]='0'-s[i]+'1';
}
void ins(char *s,int len,int k){
	int nw;
	rep(_,0,1){
		nw=1;
		rep(i,1,len){
			int d=s[i]-'0';
			if (!to[nw][d]) to[nw][d]=++ns;
			nw=to[nw][d];
		}
		hav[nw]|=k;
		trans(s,len);
	}
}
void dfs_hav(int u){
	if (dfs_hav_vis[u]) return;
	dfs_hav_vis[u]=1;
	if (fa[u]) dfs_hav(fa[u]);
	hav[u]|=hav[fa[u]];
}
int q[N*2],h,t;
void build_fail(){
	fa[1]=0;
	to[0][0]=to[0][1]=1;
	q[h=t=1]=1;
	while (h<=t){
		int u=q[h++];
		rep(i,0,1){
			int v=to[u][i];
			if (!v) continue;
			q[++t]=v;
			int k=fa[u];
			while (!to[k][i]) k=fa[k];
			fa[v]=to[k][i];
		}
	}
}
char s0[N*2],s1[N*2];
void get_hav2(int u,int d){
	rep(i,0,1) if (to[u][i]){
		s0[d+1]='0'+i;
		get_hav2(to[u][i],d+1);
	}
	rep(i,1,d){
		s1[i]=s0[i];
		s1[1+d+d-i]='0'-s0[i]+'1';
	}
	int nw=1,tps=0;
	rep(i,1,d+d){
		int dr=s1[i]-'0';
		while (!to[nw][dr]) nw=fa[nw];
		nw=to[nw][dr];
		tps|=hav[nw];
	}
	hav2[u]=tps;
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	ns=1;
	all=(1<<n)-1;
	rep(i,1,n) scanf("%s",&s[i][1]),len[i]=strlen(&s[i][1]);
	rep(i,1,n) ins(s[i],len[i],1<<(i-1));
	build_fail();
	rep(i,1,ns){
		int k=i;
		while (!to[k][0]) k=fa[k];
		f_to[i][0]=to[k][0];
		k=i;
		while (!to[k][1]) k=fa[k];
		f_to[i][1]=to[k][1];
	}
	rep(i,1,ns) dfs_hav(i);
	get_hav2(1,0);
	per(i,m,0){
		rep(j,1,ns) rep(k,0,all) dfs(j,i,k);
	}
	int ans=dfs(1,0,0);
	ans=(ans+P)%P;
	printf("%d\n",ans);
	return 0;
}

