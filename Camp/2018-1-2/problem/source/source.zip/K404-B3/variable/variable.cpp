#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define ll long long
#define N 100010
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int T,n,p,q,W;
struct qaz{int x,y,z,a,b,c,d,e,f;}a[N];
int x[N],y[N],r[N];
namespace sub1
{
	ll ans;
	int w[N];
	bool ck(int i)
	{
		if(!r[i]) return w[x[i]]<=w[y[i]];
		else if(r[i]^1) return w[x[i]]<w[y[i]];
		return w[x[i]]==w[y[i]];
	}
	void sol(int x)
	{
		ll sum=0;
		for(int i=0;i<n;i++)
		{
			w[i+1]=(x&(1<<i))?W:-W;
			sum+=w[i+1];
		}
		for(int i=1;i<=q;i++)
			if(!ck(i)) return;
		for(int i=1;i<=p;i++)
		{
			sum+=a[i].a*abs(w[a[i].x]-w[a[i].y]);
			sum+=a[i].b*abs(w[a[i].y]-w[a[i].z]);
			sum+=a[i].c*abs(w[a[i].z]-w[a[i].x]);
			sum+=a[i].d*(w[a[i].x]-w[a[i].y]);
			sum+=a[i].e*(w[a[i].y]-w[a[i].z]);
			sum+=a[i].f*(w[a[i].z]-w[a[i].x]);
		}
		ans=min(ans,sum);
	}
	void Main()
	{
		ans=(ll)inf*inf;
		for(int i=0;i<(1<<n);i++) sol(i);
		printf("%lld\n",ans);
	}
};
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	T=rd();
	while(T--)
	{
		n=rd();W=rd();p=rd();q=rd();
		for(int i=1;i<=p;i++)
		{
			a[i].x=rd();a[i].y=rd();a[i].z=rd();
			a[i].a=rd();a[i].b=rd();a[i].c=rd();
			a[i].d=rd();a[i].e=rd();a[i].f=rd();
		}
		for(int i=1;i<=q;i++)
		{
			x[i]=rd();y[i]=rd();r[i]=rd();
		}
		if(n<=15) sub1::Main();
	}
	return 0;
}
/*
1
3 1 1 1
1 2 3 1 1 1 1 1 1
1 2 2
*/