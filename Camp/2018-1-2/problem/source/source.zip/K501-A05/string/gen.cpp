#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

int main()
{
	freopen("seed.txt", "r", stderr);
	int seed;
	fscanf(stderr, "%d", &seed);
	srand(seed);

	freopen("string.in", "w", stdout);

	const int T = 20, n = 49999, cset = 2;
	printf("%d\n", T);
	REP(zjm, 0, T)
	{
		int fg = rand() % 2;
		printf("%d\n", n * 2 + fg);

		stack<char> S;
		REP(i, 0, n)
		{
			S.push(rand() % cset + 'a');
			putchar(S.top());
		}
		if(fg) putchar(rand() % cset + 'a');
		while(!S.empty()) putchar(S.top()), S.pop();
		puts("");
	}

	int Rand = rand();
	srand(time(0));
	freopen("seed.txt", "w", stderr);
	fprintf(stderr, "%d\n", Rand ^ rand());

	return 0;
}

