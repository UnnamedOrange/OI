#include<cstdio>
#include<vector>
#define ls k<<1,l,mid
#define rs k<<1|1,mid+1,r
using namespace std;
const int inf=2147483647,maxn=2002,mod=1000000007;
int n,c[maxn],d[maxn];
std::vector<int>v[maxn];
int f[maxn][maxn][2],sum[maxn][maxn];
int up,down,_u,_d,ans1,ans2,las;
inline int min(int a,int b){return a<b?a:b;}
inline int max(int a,int b){return a>b?a:b;}
namespace Segment_Tree{
	int tr1[maxn<<2],tr2[maxn<<2];
	inline void build(int k=1,int l=1,int r=n){
		if(l==r){
			tr1[k]=c[l];tr2[k]=d[l];
			return;
		}
		int mid=(l+r)>>1;
		build(ls);build(rs);
		tr1[k]=max(tr1[k<<1],tr1[k<<1|1]);
		tr2[k]=min(tr2[k<<1],tr2[k<<1|1]);
	}
	inline int query_max(int x,int y,int k=1,int l=1,int r=n){
		if(x<=l&&r<=y)return tr1[k];
		int mid=(l+r)>>1,ret=0;
		if(x<=mid)ret=query_max(x,y,ls);
		if(mid<y)ret=max(ret,query_max(x,y,rs));
		return ret;
	}
	inline int query_min(int x,int y,int k=1,int l=1,int r=n){
		if(x<=l&&r<=y)return tr2[k];
		int mid=(l+r)>>1,ret=inf;
		if(x<=mid)ret=query_min(x,y,ls);
		if(mid<y)ret=min(ret,query_min(x,y,rs));
		return ret;
	}
}
using namespace Segment_Tree;
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	f[0][0][0]=1;
	sum[0][0]=1;
	for(register int i=1;i<=n;++i)
		scanf("%d%d",c+i,d+i);
	build();
	for(register int k=1;k<=n;++k){
		for(register int i=k;i<=n;++i){
			down=c[i];up=d[i];
			for(register int j=i;j<min(i+d[i],n+1);++j){
				down=max(down,c[j]);up=min(up,d[j]);
				if(down>up)break;
				_d=query_max(j-down+1,j);
				_u=query_min(j-down+1,j);
				if(_u<_d)continue;
				for(register int l=down;l<=up;++l){
					_d=max(c[j-l+1],_d);
					_u=min(d[j-l+1],_u);
					if(_u<_d)break;
					if(_d<=l&&l<=_u){
						if(f[j][l][k&1])continue;
						v[j].push_back(l);
						f[j][l][k&1]=(f[j][l][k&1]+sum[j-l][k-1])%mod;
						sum[j][k]+=f[j][l][k&1];
						if(j==n&&sum[j][k]){
							ans1=k;
							ans2=sum[j][k];
						}
					}
				}
			}
		}	
		--k;
		for(register int i=k;i<=n;++i){
			down=c[i];up=d[i];
			for(register int j=i;j<min(i+d[i],n+1);++j){
				down=max(down,c[j]);up=min(up,d[j]);
				if(down>up)break;
				_d=query_max(j-down+1,j);
				_u=query_min(j-down+1,j);
				if(_u<_d)continue;
				for(register int l=down;l<=up;++l){
					_d=max(c[j-l+1],_d);
					_u=min(d[j-l+1],_u);
					if(_u<_d)break;
					if(_d<=l&&l<=_u)
						f[j][l][k&1]=0;
				}
			}
		}
		++k;
	}
	if(ans1&&ans2){
		printf("%d %d\n",ans1,ans2);
		return 0;
	}
	puts("-1");
	return 0;
}
