#include<algorithm>
#include<unistd.h>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<ctime>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;

int main()
{
	freopen("string.in","w",stdout);
	srand(time(0)+getpid());
	int n=1,m=15-rand()%5,len=rand()%(m*2)+1;
	printf("%d %d\n",n,m);
	rep(i,1,len) putchar('0'+rand()%2);
	puts("");
}
