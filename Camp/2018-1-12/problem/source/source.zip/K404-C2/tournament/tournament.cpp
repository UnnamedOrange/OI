#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
typedef long long LL;
const int N=100005,mod=998244353;
int n,k;
LL f[N][2],h[N],g[N],inv[N],flv[N];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

LL getmi(LL a,LL x)
{
	LL rt=1;
	while(x)
	{
		if(x&1) rt=rt*a%mod;
		a=a*a%mod,x>>=1;
	}
	return rt;
}

LL C(int n,int m)
{
	return (LL)flv[n]*inv[m]%mod*inv[n-m]%mod;
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	n=getint(),k=getint(),flv[0]=1;
	rep(i,1,n) flv[i]=(LL)flv[i-1]*i%mod;
	inv[n]=getmi(flv[n],mod-2);
	repd(i,n,1) inv[i-1]=(LL)inv[i]*i%mod;
	g[1]=1,g[3]=2;
	
	h[0]=1;
	rep(i,1,n)
	{
		rep(j,1,i-1)
			if(i-j>=0)
				h[i]=(h[i]+h[i-j]*g[j]%mod*inv[j])%mod;
		g[i]=(getmi(2,(LL)i*(i-1)/2)+mod-h[i]*flv[i]%mod)%mod;
		h[i]=(h[i]+g[i]*inv[i])%mod;
	}

	f[0][0]=1;
	rep(i,0,n-1)
		rep(j,1,n)
			rep(tp,0,1)
				if(i+j<=n)
				{
					LL tmp=f[i][tp];
					if(j>=k) f[i+j][1]=(f[i+j][1]+f[i][tp]*C(n-i,j)%mod*g[j])%mod;
					else f[i+j][tp]=(f[i+j][tp]+f[i][tp]*C(n-i,j)%mod*g[j])%mod;
				}
	printf("%lld\n",f[n][1]);
	return 0;
}
