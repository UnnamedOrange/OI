#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 100005

int n,q,red_sun_pps,idx,ans,tot,mx;
int c[maxn],now[maxn],pre[maxn*2],son[maxn*2];
int seq[maxn],l[maxn],r[maxn],vis[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

void add(int a,int b){son[++tot]=b,pre[tot]=now[a],now[a]=tot;}
void link(int a,int b){add(a,b),add(b,a);}

void dfs(int x,int fa){
	l[x]=++idx,seq[idx]=c[x];
	for (int p=now[x];p;p=pre[p])
		if (son[p]!=fa) dfs(son[p],x);
	r[x]=idx;
}

int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read(),q=read(),red_sun_pps=read();
	for (int i=1;i<=n;i++) c[i]=read(),mx=max(mx,c[i]);
	for (int i=1,x,y;i<n;i++) x=read(),y=read(),link(x,y);
	dfs(1,0);
	for (int i=1;i<=q;i++){
		int op=read();
		if (op==1){
			int x=read(),a=read(),b=read();
			if (red_sun_pps) x^=ans,a^=ans,b^=ans;
			ans=0;
			for (int j=l[x];j<=r[x];j++)
				if (vis[seq[j]]!=i&&seq[j]>=a&&seq[j]<=b) ans++,vis[seq[j]]=i;
			printf("%d\n",ans);
		}
		else{
			int x=read(),y=read();
			if (red_sun_pps) x^=ans,y^=ans;
			seq[l[x]]=y;
		}
	}
	return 0;
}
