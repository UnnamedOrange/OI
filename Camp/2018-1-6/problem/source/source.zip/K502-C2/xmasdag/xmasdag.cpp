#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<vector>
#define ll long long

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while (c = getchar(), c >= '0');
}

void Pn(int x) {
	if (!x) return;
	Pn(x / 10);
	putchar(x % 10 ^ 48);
}

void Pf(int x) {
	if (!x) putchar('0');
	Pn(x);
	putchar('\n');
}

const int N = 100005;
const int M = 200005;
const int K = 505;
const int P = 998244353;

struct Node {int to, nxt;} Edge[M];
int n, m, k, Head[N], tot, Q[N], deg[N], C[K][K];

inline void Addedge(int a, int b) {
	Edge[tot] = (Node) {b, Head[a]}; Head[a] = tot++; deg[b]++;
}

inline void Add(int &a, int b) {
	a += b;
	if (a >= P) a -= P;
}

int Pow(int x, int k) {
	int rs = 1;
	while (k) {
		if (k & 1) rs = (ll) rs * x % P;
		x = (ll) x * x % P;
		k >>= 1;
	}
	return rs;
}

void Topo() {
	int l = 1, r = 0;
	for (int i = 1; i <= n; i++) if (!deg[i]) Q[++r] = i;
	while (l <= r) {
		int now = Q[l++];
		for (int i = Head[now]; ~i; i = Edge[i].nxt) {
			int to = Edge[i].to;
			deg[to]--;
			if (!deg[to]) Q[++r] = to;
		}
	}
}

namespace Subtask1 {
	
	int f[2005][2005], Ans[2005];
	
	void solve() {
		f[1][0] = 1;
		for (int i = 1; i <= n; i++) {
			int id = Q[i];
			for (int j = 0; j <= n; j++) {
				if (!f[id][j]) continue;
				for (int k = Head[id]; ~k; k = Edge[k].nxt) {
					int to = Edge[k].to;
					Add(f[to][j + 1], f[id][j]);
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			int pw = Pow(i, k);
			for (int j = 1; j <= n; j++)
				Add(Ans[j], (ll) f[j][i] * pw % P);
		}
		if (!k) Ans[1] = 1;
		for (int i = 1; i <= n; i++)
			printf("%d\n", Ans[i]);
	}
	
}

void Init() {
	for (int i = 0; i < K; i++) {
		C[i][0] = 1;
		for (int j = 1; j <= i; j++)
			C[i][j] = (C[i - 1][j] + C[i - 1][j - 1]) % P;
	}
}

int f[N][K];
	
namespace Subtask2 {
	
	void solve() {
		for (int i = Head[1]; ~i; i = Edge[i].nxt) {
			int to = Edge[i].to;
			Add(f[to][k], 1);
		}
		for (int i = 1; i <= n; i++) {
			int id = Q[i];
			for (int j = 0; j <= k; j++) {
				if (!f[id][j]) continue;
				for (int p = Head[id]; ~p; p = Edge[p].nxt) {
					int to = Edge[p].to;
					for (int t = 0; t <= j; t++)
						Add(f[to][t], (ll) f[id][j] * C[j][t] % P);
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			int ans = 0;
			for (int j = 0; j <= k; j++) Add(ans, f[i][j]);
			if (i == 1 && !k) ans = 1;
			printf("%d\n", ans);
		}
	}
	
}

namespace Subtask3 {
	
	int g[K << 3], t[K << 3], rs[K << 3], rev[K << 3], fact[K], invfact[K], pwG[K << 3], invpwG[K << 3];
	vector <int> G[N];
	
	void NTT(int *A, int n, bool type) {
		for (int i = 0; i < n; i++)
			if (rev[i] < i) swap(A[i], A[rev[i]]);
		for (int k = 2; k <= n; k <<= 1) {
			int wn = pwG[k];
			if (type) wn = invpwG[k];
			for (int i = 0; i < n; i += k) {
				int m = k >> 1, w = 1;
				for (int j = 0; j < m; j++) {
					int l = A[i + j], r = A[i + j + m];
					A[i + j] = (l + (ll) r * w % P) % P;
					A[i + j + m] = (l - (ll) r * w % P + P) % P;
					w = (ll) w * wn % P;
				}
			}
		}
		if (type) {
			int inv = Pow(n, P - 2);
			for (int i = 0; i < n; i++) A[i] = (ll) A[i] * inv % P;
		}
	}
	
	void solve() {
		for (int i = 1; i <= n; i++)
			for (int j = Head[i]; ~j; j = Edge[j].nxt) {
				int to = Edge[j].to;
				G[to].push_back(i);
			}
		int p = 1;
		while ((1 << p) <= 2 * k) p++;
		for (int i = 0; i < (1 << p); i++)
			rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (p - 1));
		p = 1 << p;
		
		for (int i = 1; i <= p; i <<= 1) {
			pwG[i] = Pow(3, (P - 1) / i);
			invpwG[i] = Pow(pwG[i], P - 2);
		}
		
		fact[0] = 1;
		for (int i = 1; i <= k; i++) fact[i] = (ll) fact[i - 1] * i % P;
		invfact[k] = Pow(fact[k], P - 2);
		for (int i = k - 1; i >= 0; i--) invfact[i] = (ll) invfact[i + 1] * (i + 1) % P;
		
		for (int i = 0; i <= k; i++) g[i] = invfact[k - i];
		NTT(g, p, 0);
		
		for (int i = Head[1]; ~i; i = Edge[i].nxt) {
			int to = Edge[i].to;
			Add(f[to][k], 1);
		}
		for (int i = 1; i <= n; i++) {
			int id = Q[i];
			for (int j = 0; j < p; j++) t[j] = 0;
			for (int it = 0; it < (int) G[id].size(); it++) {
				int to = G[id][it];
				for (int j = 0; j < p; j++)
					Add(t[j], f[to][j]);
			}
			for (int j = 0; j < p; j++) t[j] = (ll) t[j] * fact[j] % P;
			NTT(t, p, 0);
			for (int j = 0; j < p; j++) rs[j] = (ll) t[j] * g[j] % P;
			NTT(rs, p, 1);
			for (int j = 0; j <= k; j++)
				Add(f[id][j], (ll) rs[j + k] * invfact[j] % P);
		}
		for (int i = 1; i <= n; i++) {
			int ans = 0;
			for (int j = 0; j <= k; j++) Add(ans, f[i][j]);
			if (i == 1 && !k) ans = 1;
			Pf(ans);
		}
	}
	
}

int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	Rd(n), Rd(m), Rd(k);
	memset(Head, -1, sizeof(Head));
	for (int i = 1; i <= m; i++) {
		int a, b;
		Rd(a), Rd(b);
		Addedge(a, b);
	}
	Topo();
	if (n <= 2000 && m <= 2000) Subtask1::solve();
	else {
		Init();
		if (k <= 30) Subtask2::solve();
		else Subtask3::solve();
	}
	return 0;
}

/*
  memory!
*/
