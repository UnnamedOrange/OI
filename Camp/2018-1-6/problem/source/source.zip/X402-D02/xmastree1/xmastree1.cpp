#include<iostream>
#include<cstdio>
#include<cstring>
#include<map>

namespace PaoBuChuLai
{
	const int N=5050,M=N*2;
	std::map<int,bool> mw;
	int begin[N],next[M],to[M];
	int col[N];
	int n,m,t,e;
	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}
	void initialize()
	{
		scanf("%d%d%d",&n,&m,&t);
		for(int i=1;i<=n;i++)
			scanf("%d",col+i);
		for(int i=1,u,v;i<n;i++)
			scanf("%d%d",&u,&v),add(u,v);
	}

	int fa[N];

	void predfs(int p,int h=0)
	{
		fa[p]=h;
		for(int i=begin[p];i;i=next[i])
			if(to[i]!=h)predfs(to[i],p);
	}

	void dfs(int p,int l,int r)
	{
		if(col[p]>=l && col[p]<=r)mw[col[p]]=1;
		for(int i=begin[p];i;i=next[i])
			if(to[i]!=fa[p])dfs(to[i],l,r);
	}
	
	int query(int p,int l,int r)
	{
		mw.clear();
		dfs(p,l,r);
		return mw.size();
	}

	void solve()
	{
		initialize();
		predfs(1);
		int lans=0;
		while(m--)
		{
			int ty,p,l,r;
			scanf("%d",&ty);
			if(ty==1)
			{
				scanf("%d%d%d",&p,&l,&r);
				p^=t*lans;
				l^=t*lans;
				r^=t*lans;
				printf("%d\n",lans=query(p,l,r));
			}
			else 
			{
				scanf("%d%d",&p,&r);
				p^=t*lans;
				r^=t*lans;
				col[p]=r;
			}
		}
	}

}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	PaoBuChuLai::solve();
	return 0;
}
