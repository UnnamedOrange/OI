#include <stdio.h>
#include <algorithm>
using namespace std;

long long int wa[1001],x[1001],y[1001],z[1001],a[1001],b[1001],c[1001],d[1001],e[1001],f[1001],xi[1001],yi[1001],r[1001];
long long int t,n,w,p,q,ans=1e9+7; 
 
inline long long int read()
{
    char ch;
    bool flag = false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

bool check()
{
	int i;
	for(i=1;i<=q;i++)
	{
		if(r[i]==0)
		{
			if(wa[xi[i]]>wa[yi[i]])
				return false;
		}
		if(r[i]==1)
		{
			if(wa[xi[i]]!=wa[yi[i]])
				return false;
		}
		if(r[i]==2)
		{
			if(wa[xi[i]]>=wa[yi[i]])
				return false;
		}
	}
	return true;
}

long long int cou()
{
	long long int i,sum=0;
	for(i=1;i<=n;i++)
		sum+=wa[i];
	for(i=1;i<=p;i++)
		sum+=a[i]*abs(wa[x[i]]-wa[y[i]])+b[i]*abs(wa[y[i]]-wa[z[i]])+c[i]*abs(wa[z[i]]-wa[x[i]])+d[i]*(wa[x[i]]-wa[y[i]])+e[i]*(wa[y[i]]-wa[z[i]])+f[i]*(wa[z[i]]-wa[x[i]]);
	return sum;
}

void dfs(int x)
{
	if(x==n+1)
	{
		if(!check())
			return;
		else
		{
			ans=(long long int)min(ans,cou());
			return;
		}
	}
	wa[x]=w;
	dfs(x+1);
	wa[x]=-w;
	dfs(x+1);
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	t=read();
	while(t--)
	{
		ans=1e9+7;
		n=read(),w=read(),p=read(),q=read(); 
		long long int i;
		for(i=1;i<=p;i++)
			x[i]=read(),y[i]=read(),z[i]=read(),a[i]=read(),b[i]=read(),c[i]=read(),d[i]=read(),e[i]=read(),f[i]==read();
		for(i=1;i<=q;i++)
			xi[i]=read(),yi[i]=read(),r[i]=read();
		dfs(1);
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout); 
	return 0;
}
