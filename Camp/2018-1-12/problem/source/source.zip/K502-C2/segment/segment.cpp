#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long

using namespace std;

int n, m, k;

const int P = 998244353;

inline void Add(int &a, int b) {
	a += b;
	if (a >= P) a -= P;
}

int Pow(int x, int k) {
	int rs = 1;
	while (k) {
		if (k & 1) rs = (ll) rs * x % P;
		x = (ll) x * x % P;
		k >>= 1;
	}
	return rs;
}

namespace Subtask1 {
	
	const int M = 50;
	
	int dp[M][M][M][M];
	
	void solve() {
		int ans = 0;
		n = min(n, m);
		for (int p = 1; p <= m; p++) {
			for (int i = 0; i <= n; i++)
				for (int j = 0; j <= m; j++)
					for (int k = j; k <= m; k++)
						for (int c = 0, *q = dp[i][j][k]; c <= n; c++, q++)
							(*q) = 0;
			dp[0][0][0][0] = 1;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j <= m; j++) {
					for (int k = j; k <= m; k++) {
						for (int c = 0, *q = dp[i][j][k]; c <= n; c++, q++) {
							if (!(*q)) continue;
							for (int l = j + 1; l <= m; l++)
								for (int r = max(l, k + 1); r <= m; r++)
									Add(dp[i + 1][l][r][c + (l <= p && p < r)], (*q));
						}
					}
				}
			}
			for (int i = 0; i <= n; i++) {
				int pw = Pow(i, k);
				for (int l = 1; l <= m; l++)
					for (int r = l; r <= m; r++)
						Add(ans, (ll) dp[n][l][r][i] * pw % P);
			}
		}
		printf("%d\n", ans);
	}
	
}

namespace Subtask2 {
	
	void solve() {
		int ans = 0;
		for (int i = 1; i < m; i++)
			Add(ans, (ll) i * (m - i) % P);
		printf("%d\n", ans);
	}
	
}

namespace Subtask3 {
	
	void solve() {
		int pw2 = Pow(2, k), ans = 0;
		for (int l1 = 1; l1 <= m; l1++) {
			for (int r1 = l1; r1 <= m; r1++) {
				for (int l2 = l1 + 1; l2 <= m; l2++) {
					if (l2 <= r1) {
						int cnt1pre = l2 - l1;
						int cnt2 = r1 - l2;
						int mx = m - r1;
						Add(ans, (ll) mx * ((ll) cnt2 * pw2 % P + cnt1pre) % P);
						Add(ans, (ll) (1 + mx) * mx % P * ((P + 1) >> 1) % P);
					} else {
						int cnt1pre = r1 - l1;
						int mx = m - l2;
						Add(ans, (ll) cnt1pre * (mx + 1) % P);
						Add(ans, (ll) (1 + mx) * mx % P * ((P + 1) >> 1) % P);
					}
				}
			}
		}
		printf("%d\n", ans);
	}
	
}

namespace Subtask4 {
	
	const int M = 50;
	
	int dp[2][M][M][M];
	
	void solve() {
		int ans = 0;
		n = min(n, m);
		for (int p = 1; p <= m; p++) {
			memset(dp, 0, sizeof(dp));
			dp[0][0][0][0] = 1;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j <= m; j++) {
					for (int k = j; k <= m; k++) {
						for (int c = 0; c < 2; c++) {
							if (!dp[c][i][j][k]) continue;
							for (int l = j + 1; l <= m; l++)
								for (int r = max(l, k + 1); r <= m; r++)
									Add(dp[c | (l <= p && p < r)][i + 1][l][r], dp[c][i][j][k]);
						}
					}
				}
			}
			for (int l = 1; l <= m; l++)
				for (int r = l; r <= m; r++)
					Add(ans, dp[1][n][l][r]);
		}
		printf("%d\n", ans);
	}
	
}

int main() {
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	scanf("%d %d %d", &n, &m, &k);
	if (m <= 6) Subtask1::solve();
	else if (n == 1) Subtask2::solve();
	else if (n == 2 && m <= 350) Subtask3::solve();
	else if (k == 998244352) Subtask4::solve();
	else Subtask1::solve();
	return 0;
}
