cas=1
while true; do
	./test || break
	./bomb ||break
	./bomb1 || break
	diff ./bomb.out ./bomb1.out || break
	echo $cas
	cas=`expr $cas + 1`
done
