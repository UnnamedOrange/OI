
#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=300010,INF=0x3f3f3f3f,Mod=1e9+7;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
}

ll s,t,n,m,fac[N],ifac[N];
inline ll C(ll a,ll b){
	if(a<0||b<0||a<b)return 0;
	return fac[a]*ifac[b]%Mod*ifac[a-b]%Mod;
}
ll qpow(ll a,ll b){
	ll ret=1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
void init(){
	read(s),read(t),read(n),read(m);
	fac[0]=1;
	For(i,1,s)fac[i]=1ll*fac[i-1]*i%Mod;
	ifac[s]=qpow(fac[s],Mod-2);
	Forr(i,s,1)ifac[i-1]=ifac[i]*i%Mod;
}
struct Poly{
	int a[N],p;
	Poly(){p=0;a[0]=1;}
}dp;

Poly c;
Poly operator *(Poly A, Poly B){
	c.p=min(B.p+A.p,(int)(s-m));
	For(i,0,c.p)c.a[i]=0;
	For(i,0,A.p)
		For(j,0,B.p)if(i+j<=c.p)
			c.a[i+j]=(c.a[i+j]+1ll*A.a[i]*B.a[j])%Mod;
	return c;
}
Poly operator ^(Poly a,ll b) {
	Poly ret,A=a;
	For(i,1,b)ret=ret*A;
	return ret;
}
void f(){
	dp.p=t-1;
	For(i,0,t-1)dp.a[i]=1;
	dp=dp^n;
}
void solve(){
	ll ans=0;
	f();
	For(i,m-n,s-n)
		ans=(ans+C(i,m-n)*dp.a[s-i-n])%Mod;
	printf("%lld\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
