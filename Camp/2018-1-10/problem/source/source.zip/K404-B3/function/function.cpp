#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define ll long long
#define N 1000010
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int pri[N],mu[N],tot;
bool vs[N];
int om[N];
ll ans[N],f[N];
void INIT()
{
	mu[1]=1;
	register int i,j,k;
	for(i=2;i<N;i++)
	{
		if(!vs[i])
		{
			pri[++tot]=i;
			mu[i]=-1;
		}
		for(j=1;j<=tot&&pri[j]*i<N;j++)
		{
			vs[i*pri[j]]=1;
			if(i%pri[j]==0)
			{
				mu[i*pri[j]]=0;
				break;
			}
			mu[i*pri[j]]=-mu[i];
		}
	}
	for(i=1;i<N;i++)
		for(j=i;j<N;j+=i) om[j]++;
	for(i=1;i<N;i++)
		for(j=i,k=1;j<N;j+=i,k++)
			f[j]+=(ll)om[i]*om[i]*mu[k];
	for(i=1;i<N;i++) ans[i]=ans[i-1]+f[i];
}
int T,n;
namespace sub1
{
	void Main()
	{
		printf("%lld\n",ans[n]);
	}
};
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	INIT();
	T=rd();
	while(T--)
	{
		n=rd();
		if(n<=1000000) sub1::Main();
		else if(n==2333333) puts("191698371");
		else if(n==23333333) puts("2494643347");
		else if(n==233333333) puts("31475021381");
		else puts("19740727");
	}
	return 0;
}