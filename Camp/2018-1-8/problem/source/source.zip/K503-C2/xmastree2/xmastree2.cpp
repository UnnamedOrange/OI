#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define maxn 30010
int head[maxn],e[maxn][2],w[maxn],n,i,j,x,y,t=0,ans=0;
bool mark[maxn],b[maxn],r[maxn];
void addedge(int x,int y)
{
	e[++t][1]=y;
	e[t][0]=head[x];
	head[x]=t;
}
void dfs(int x,int y,int z)
{
	int i;
	if (y==n)
	{
		if (z+y*w[x]>ans) ans=z+y*w[x];
		return;
	}
	mark[x]=false;
	b[x]=false;
	for (i=head[x];i>0;i=e[i][0])
		if (mark[e[i][1]]) b[e[i][1]]=true;
	for (i=1;i<=n;i++)
		if (b[i]) dfs(i,y+1,z+w[x]*y);
	for (i=head[x];i>0;i=e[i][0])
		if (mark[e[i][1]]) b[e[i][1]]=false;
	mark[x]=true;
	b[x]=true;
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	for (i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		addedge(x,y);
		addedge(y,x);
	}
	for (i=1;i<=n;i++)
		scanf("%d%d",&w[i],&r[i]);
	for (i=1;i<=n;i++)
		if (r[i])
		{
			memset(mark,true,sizeof(mark));
			memset(b,false,sizeof(mark));
			dfs(i,1,0);
		}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
