#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int maxn = 5e+5 + 10;
const int mod = 1e+9 + 9;

inline int MOD(int x){return x<mod?x:x-mod;}
struct qj{
	int l,r;
}a[maxn];

struct tree{
	int a[maxn];
	void add(int x,int d){for(x++;x<maxn;x+=x&-x) a[x]=MOD(a[x]+d);}
	int qsum(int x){int ans=0;for(x++;x>0;x-=x&-x) ans=MOD(ans+a[x]);return ans;}
	inline int sum(int l,int r){if(l>r) return 0;return MOD(qsum(r)-qsum(l-1)+mod);}
}f;

int n,m,x[maxn];
int pre[maxn],nxt[maxn];

bool cmpl(qj aa,qj bb){return aa.l<bb.l;}
void read()
{
	int i;
	
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++) scanf("%d%d",&a[i].l,&a[i].r);
	for(i=0;i<m;i++) scanf("%d",x+i);
	
	sort(x,x+m);sort(a,a+n,cmpl);
//	for(i=0;i<n;i++) cout<<a[i].l<<' '<<a[i].r<<endl;
}

inline int findqj(int ix)
{
	int l=-1,r=n,mid;
	while(l+1<r)
	{
		mid=(l+r)>>1;
		if(a[mid].l<=ix) l=mid;
		else             r=mid; 
	}
	return l;
}
inline int findpoint(int ix)
{
	int l=-1,r=m,mid;
	while(l+1<r)
	{
		mid=(l+r)>>1;
		if(x[mid]>ix) r=mid;
		else          l=mid;
	}
	return r;
}
void init()
{
	int i;
	pre[m]=n;
	for(i=0;i<m;i++) pre[i]=findqj(x[i]);//,cout<<pre[i]<<' ';cout<<endl;
	for(i=0;i<n;i++) nxt[i]=pre[findpoint(a[i].r)];//,cout<<nxt[i]<<' ';cout<<endl;
}

void solve()
{
	int i;
	
	f.add(n,1);
	for(i=n-1;i>=0;i--) f.add(i,f.sum(i+1,nxt[i]));
	
	for(i=0;i<n && a[i].l<=x[0];i++);
	cout<<f.sum(0,i-1);
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	
	read();
	init();
	solve();
	
	return 0;
}
