#include<bits/stdc++.h>
#define maxn 4010
#define INF 100000
using namespace std;
int a[maxn], b[maxn], nxt1[maxn][maxn], nxt2[maxn][maxn], f[maxn][maxn], ans = INF;
int out1[maxn], out2[maxn];
int main()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	int n, m, k;
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	for (int i = 1; i <= m; i++)
		scanf("%d", &b[i]);
	for (int i = n; i >= 0; i--)
		for (int j = 1; j <= k; j++)
			if (a[i + 1] == j) nxt1[i][j] = i + 1;
			else nxt1[i][j] = nxt1[i + 1][j];
	for (int i = m; i >= 0; i--)
		for (int j = 1; j <= k; j++)
			if (b[i + 1] == j) nxt2[i][j] = i + 1;
			else nxt2[i][j] = nxt2[i + 1][j];
	out1[0] = out2[0] = 1;
	for (int i = n; i >= 1; i--)
	{
		out1[i] = INF;
		for (int j = 1; j <= k; j++)
			out1[i] = min(out1[i], out1[nxt1[i][j]] + 1);
	}
	for (int i = m; i >= 1; i--)
	{
		out2[i] = INF;
		for (int j = 1; j <= k; j++)
			out2[i] = min(out2[i], out2[nxt2[i][j]] + 1);
	}
	for (int i = 0; i <= n; i++)
		for (int j = 0; j <= m; j++)
			f[i][j] = INF;
	f[0][0] = 0;
	for (int i = 0; i <= n; i++)
		for (int j = 0; j <= m; j++)
		{
			if (f[i][j] == INF) continue;
			for (int ch = 1; ch <= k; ch++)
			{
				int nxti = nxt1[i][ch], nxtj = nxt2[j][ch];
				if (nxti == 0) ans = min(ans, f[i][j] + out2[nxtj]);
				else if (nxtj == 0) ans = min(ans, f[i][j] + out1[nxti]);
				else f[nxti][nxtj] = min(f[nxti][nxtj], f[i][j] + 1);
			}
		}
	printf("%d\n", ans);
	return 0;
}
