#include<cstdio>
#include<algorithm>
#include<set>
#include<queue>
#include<cmath>
using namespace std;

const int maxn = 30;
int n, up;
int ini[maxn];

struct lpl
{
	int data[maxn];
	int z;
	bool operator == (lpl &aaa)const
	{
		for(int i = 1; i <= n; ++i)
		{
			if(aaa.data[i] != data[i])	return false;
		}
		return true;
	}
}lin, qwe;

queue<lpl> q;
set<unsigned long long> s;

inline bool check()
{
	unsigned long long u = 0, mi = 1, gu = 0;
	for(int i = n; i >= 1; --i)
	{
		u += mi * qwe.data[i]; mi *= 10;
	}
	if(s.count(u) == 1)	return false;
	for(int i = 2; i <= n; ++i)
	{
		if(abs(qwe.data[i - 1] - qwe.data[i]) > 1)	gu++;
	}
	if(gu + qwe.z >= up)	return false;
	return true;
}

inline bool print()
{
	for(int i = 1; i <= n; ++i)
	{
		if(qwe.data[i] != i)	return false;
	}
	printf("%d\n", qwe.z); return true;
}

inline void workk()
{
	for(int i = 1; i <= n; ++i)
		lin.data[i] = ini[i];
	lin.z = 0; q.push(lin);
	while(!q.empty())
	{
		lin = q.front(); q.pop(); qwe = lin; qwe.z = lin.z + 1;
		for(int i = 2; i <= n; ++i)
		{
			for(int j = i; j >= 0; --j)
			{
				qwe.data[j] = lin.data[i - j + 1];
			}
			for(int j = i + 1; j <= n; ++j)
			{
				qwe.data[j] = lin.data[j];
			}
			if(check())
			{
				q.push(qwe);
				if(print())	return;
			}
		}
	}
}

int main()
{
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	int v; scanf("%d", &v);
	while(v--)
	{
		scanf("%d", &n); up = 2 * n - 1;
		for(int i = 1; i <= n; ++i)
			scanf("%d", &ini[i]);
		s.clear(); 
		workk();
	}
	return 0;
}
