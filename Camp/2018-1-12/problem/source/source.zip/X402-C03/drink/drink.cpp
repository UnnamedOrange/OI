#include<bits/stdc++.h>
using namespace std;

const int maxn=2e6+10;
int n,w[maxn],len;
double ans;

namespace fft{
	const double pi2=acos(-1)*2;
	complex<double> a[maxn],b[maxn],c[maxn];
	inline int rev(int id,int len){
		int res=0;
		for(int i=1;i<len;i<<=1,id>>=1)
			if(id&1)
				res=res<<1|1;
			else
				res<<=1;
		return res;
	}
	inline void fft(complex<double>*a,int len,int dft){
		for(int i=0,j;i<len;++i)
			if(i<(j=rev(i,len)))
				swap(a[i],a[j]);
		for(int i=2;i<=len;i<<=1){
			complex<double> w(cos(pi2/i*dft),sin(pi2/i*dft));
			for(int j=0;j<len;j+=i){
				complex<double> ww(1,0);
				for(int k=0;k<(i>>1);++k,ww*=w){
					complex<double> x=a[j+k],y=ww*a[j+k+(i>>1)];
					a[j+k]=x+y;
					a[j+k+(i>>1)]=x-y;
				}
			}
		}
		if(dft==-1)
			for(int i=0;i<len;++i)
				a[i]/=len;
	}
	inline void mul(){
		fft(a,len,1);
		fft(b,len,1);
		for(int i=0;i<len;++i)
			c[i]=a[i]*b[i];
		fft(c,len,-1);
	}
}

int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&w[i]);
	len=1;while(n>len)len<<=1;
	for(int i=1;i<=n;++i){
		int tmp;
		fft::a[tmp=0]=1;
		for(int j=i-1;j;--j)
			if(w[j]>=w[i])
				fft::a[++tmp]=1;
			else
				fft::a[tmp]+=1;
		for(int j=tmp+1;j<len;++j)
			fft::a[j]=0;
		fft::b[tmp=0]=1;
		for(int j=i+1;j<=n;++j)
			if(w[j]>w[i])
				fft::b[++tmp]=1;
			else
				fft::b[tmp]+=1;
		for(int j=tmp+1;j<len;++j)
			fft::b[j]=0;
		fft::mul();
		double res=0;
		for(int j=len-1;j>=0;--j)
			res=(res+fft::c[j].real())/2;
		ans+=w[i]*res;
	}
	printf("%.6f\n",ans/n/n);
	return 0;
}
