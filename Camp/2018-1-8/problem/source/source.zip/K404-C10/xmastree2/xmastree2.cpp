#include <cstdio>
#include <vector>
using namespace std;
#define N 30050
vector<int> g[N];
bool vis[N];
int w[N],r[N],fa[N],n,i,ans,q[N],a[N],sz[N];
void dfs(int now,int lst)
{
	fa[now]=lst;sz[now]=1;
	for (int ii=0;ii<g[now].size();ii++) if (g[now][ii]!=lst) dfs(g[now][ii],now),sz[now]+=sz[g[now][ii]];
}
void dfs2(int dep,int tot)
{
	if (dep==n+1){
		ans=max(ans,tot);return;
	}int now=q[dep];
	for (int ii=a[fa[now]]+1;ii<=n-sz[now]+1;ii++) if (!vis[ii]){
		a[now]=ii;vis[ii]=true;dfs2(dep+1,tot+ii*w[now]);vis[ii]=false;
	}
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	for (i=1;i<n;i++){
		int x,y;scanf("%d%d",&x,&y);
		g[x].push_back(y);g[y].push_back(x);
	}for (i=1;i<=n;i++) scanf("%d%d",&w[i],&r[i]);
	for (i=1;i<=n;i++) if (r[i]){
		dfs(i,0);
		int l=0,r=1;q[r]=i;
		while (l<r){
			int psz=q[++l];
			for (int ii=0;ii<g[psz].size();ii++) if (g[psz][ii]!=fa[psz]) q[++r]=g[psz][ii];
		}dfs2(1,0);
	}printf("%d\n",ans);
	return 0;
}
