#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("sad.in","r",stdin),freopen("sad.out","w",stdout);

	int n;
	scanf("%d", &n);
	printf("%d\n", n-1);
	return 0;
}
