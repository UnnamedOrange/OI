#include<cstdio>
#include<string>
using namespace std;

const int maxn = 1e5 + 5;
char a[maxn];
int n;

inline bool check()
{
	int mid = (1 + n) / 2;
	for(int i = 1; i <= mid; ++i)
	{
		if(a[i] != a[n - i + 1])	return false;
	}
	return true;
}

inline bool check2()
{
	for(int i = 1; i <= n - 2; i++)
	{
		if(a[i] != a[i + 2])	return false;
	}
	return true;
}

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int v; scanf("%d", &v);
	for(int i = 1; i <= v; ++i)
	{
		scanf("%d", &n);
		scanf("%s", a + 1);
		if(!check())
		{
			printf("1\n");
			continue;
		}
		if(check2())
		{
			printf("-1\n");
			continue;
		}
		printf("2\n");
	}
	return 0;
}
