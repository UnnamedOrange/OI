from sys import stdin
a, b = map(int, stdin.readline().strip().split())
print b, a

