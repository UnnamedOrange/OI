#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
bool vis[2000];

int main()
{
	rep(i,1,920)
		rep(j,1,920)
			vis[i^j]=1;
	rep(x,0,1023)
		if(vis[x])
		{
			int y=x;
			rep(k,0,9) printf("%d",(y&1)),y>>=1;
			puts("");
		}
	rep(i,0,1023) if(vis[i]) printf("%d\n",i);
	return 0;
}
