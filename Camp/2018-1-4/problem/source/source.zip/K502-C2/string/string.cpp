#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

const int P = 998244353;

int n, m, len[10];
char str[10][105];

namespace Subtask1 {
	
	char s[35];
	
	void solve() {
		int ans = 0;
		for (int i = 0; i < (1 << m); i++) {
			int tmp = i;
			for (int j = 1; j <= m; j++) {
				s[j] = (tmp & 1) ^ 48;
				s[m + m - j + 1] = s[j] ^ 1;
				tmp >>= 1;
			}
			bool can = true;
			for (int j = 0; j < n; j++) {
				bool flag = false;
				for (int k = 1; k <= m + m - len[j] + 1; k++) {
					bool f = true;
					for (int t = 0; t < len[j]; t++)
						f &= (s[k + t] == str[j][t + 1]);
					flag |= f;
				}
				if (!flag) can = false;
			}
			ans += can;
		}
		printf("%d\n", ans);
	}
	
}

namespace Subtask2 {
	
	int fail[105], trans[2][105][2], dp[505][105][105];
	char s[205];
	
	inline void Add(int &a, int b) {
		a += b;
		if (a >= P) a -= P;
	}
	
	void Getfail(int op) {
		fail[1] = 0;
		for (int i = 2; i <= len[0]; i++) {
			int j = fail[i - 1];
			while (j && str[0][j + 1] != str[0][i]) j = fail[j];
			fail[i] = j + (str[0][j + 1] == str[0][i]);
		}
		for (int i = 0; i < len[0]; i++) {
			for (int c = 0; c < 2; c++) {
				int j = i;
				while (j && str[0][j + 1] != '0' + c) j = fail[j];
				trans[op][i][c] = j + (str[0][j + 1] == '0' + c);
			}
		}
	}
	
	void solve() {
		Getfail(0);
		reverse(str[0] + 1, str[0] + len[0] + 1);
		Getfail(1);
		dp[0][0][0] = 1;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < len[0]; j++) {
				for (int k = 0; k < len[0]; k++) {
					if (!dp[i][j][k]) continue;
					Add(dp[i + 1][trans[0][j][0]][trans[1][k][1]], dp[i][j][k]);
					Add(dp[i + 1][trans[0][j][1]][trans[1][k][0]], dp[i][j][k]);
				}
			}
		}
		reverse(str[0] + 1, str[0] + len[0] + 1);
		int ans = 1;
		for (int i = 1; i <= m; i++) Add(ans, ans);
		for (int i = 0; i < len[0]; i++)
			for (int j = 0; j < len[0]; j++) {
				if (i + j == len[0]) continue;
				if (i + j < len[0]) Add(ans, P - dp[m][i][j]);
				else {
					int l = 0;
					for (int k = 1; k <= i; k++) s[++l] = str[0][k];
					for (int k = j; k >= 1; k--) s[++l] = str[0][len[0] - k + 1];
					s[l + 1] = 0;
					bool flag = false;
					for (int k = 1; k <= l - len[0] + 1; k++) {
						bool f = true;
						for (int t = 0; t < len[0]; t++) {
							if (s[k + t] != str[0][t + 1]) {
								f = false;
								break;
							}
						}
						if (f) {
							flag = true;
							break;
						}
					}
					if (!flag) Add(ans, P - dp[m][i][j]);
				}
			}
		printf("%d\n", ans);
	}
	
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for (int i = 0; i < n; i++) scanf("%s", str[i] + 1), len[i] = strlen(str[i] + 1);
	if (m <= 15) Subtask1::solve();
	else if (n == 1) Subtask2::solve();
	return 0;
}
