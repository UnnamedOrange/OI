#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e5+5,mod=(int)1e9+7;
int n,x[N],a,b;
struct P_0{
	int dp[2][500000];
	void change(int s,int *a){
		static int i;
		for(i=0;i<6;++i)a[i]=s%6,s/=6;
	}
	int Get(int *a){
		static int res,i;
		for(res=i=0;i<6;++i)res=res*6+a[i];
		return res;
	}
	int dfs(int tp,int x){
		int &res=dp[tp][x];
		if(~res)return res;
		if(tp){//A
			int A[6];
			res=0;
			change(x,A);
			rep(i,0,6)if(A[i]>=a){
				A[i]-=a;
				if(!dfs(0,Get(A)))return res=1;
				A[i]+=a;
			}
		}else {//B
			int A[6];
			res=0;
			change(x,A);
			rep(i,0,6)if(A[i]>=b){
				A[i]-=b;
				if(!dfs(1,Get(A)))return res=1;
				A[i]+=b;
			}
		}
		return res;
	}
	void work(){
		memset(dp,-1,sizeof dp);
		int cnt[4]={0};
		rep(i,0,1<<n){
			int a[6]={0};
			rep(j,0,n)if(i>>j&1)a[j]=x[j+1];
			int fa=dfs(1,Get(a)),fb=dfs(0,Get(a));
			if(fa&&fb)++cnt[2];
			if(!fa&&!fb)++cnt[3];
			if(fa&&!fb)++cnt[0];
			if(!fa&&fb)++cnt[1];
		}
		rep(i,0,4){
			if(i)putchar(' ');
			prin(cnt[i]);
		}
		putchar('\n');
	}
}P0;
int Pow(int x,int y){
	int res=1;
	for(;y;y>>=1,x=(ll)x*x%mod)
		if(y&1)res=(ll)res*x%mod;
	return res;
}
struct P_1{
	int fac[N],ifac[N];
	int C(int n,int m){
		if(n<m)return 0;
		return fac[n]*(ll)ifac[m]%mod*ifac[n-m]%mod;
	}
	void work(){
		int cnt[2]={0},ans[2]={0};
		fac[0]=ifac[0]=1;
		rep(i,1,n+1)cnt[(x[i]/a)&1]++,fac[i]=(ll)fac[i-1]*i%mod,ifac[i]=Pow(fac[i],mod-2);
		int res=Pow(2,cnt[0]);
		rep(i,0,cnt[1]+1){
			ans[i&1]=(ans[i&1]+C(cnt[1],i)*(ll)res)%mod;
		}
		ptk(0),ptk(0),ptk(ans[1]),ptn(ans[0]);
	}
}P1;
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int mx=0;
	rd(n);rd(a),rd(b);
	rep(i,1,n+1)rd(x[i]),Max(mx,x[i]);
	if(0);
	else if(n<=5&&mx<=5)P0.work();
	else if(a==b)P1.work();
	return 0;
}
