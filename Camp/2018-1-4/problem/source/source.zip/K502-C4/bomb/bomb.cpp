#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

//���ִ�������������α����������һ����������������������� 

int n,m,a,b,head[1000005],reh[1000005],top,out[1000005],mark[1000005];
int ans,l[1000005],dfn[1000005],low[1000005],c[1000005],sum;
int vislow[1000005],nlow,toplow,rhlow[1000005];

struct edge
{
	int v,next;
} s[2000005],res[2000005],rslow[2000005];

struct node
{
	int vlow,num,bigmark;
} cir[1000005];

void del(int now,int deg)
{
	for(int i=reh[now];i!=0;i=res[i].next)
	{
		int fa=res[i].v;
		out[fa]--;
		mark[fa]=max(mark[fa],deg+1);
		if(out[fa]==0) del(fa,mark[fa]);
	}
}

void Tarjan(int now)
{
	dfn[now]=++sum;
	low[now]=sum;
	for(int i=head[now];i!=0;i=s[i].next)
	{
		int to=s[i].v;
		if(out[to]==0) continue;
		if(low[to]==0) Tarjan(to);
		low[now]=min(low[now],low[to]);
	}
}

void add_edge(int now)
{
	for(int i=reh[now];i!=0;i=res[i].next)
	{
		int fa=res[i].v;
		if(low[fa]==low[now]) continue;
		rslow[++toplow].v=low[fa]; rslow[toplow].next=rhlow[low[now]]; rhlow[low[now]]=toplow;
	}
}

bool cmp(node a,node b)
{
	if(a.bigmark==0&&b.bigmark==0)
	{
		int flag=0;
		for(int i=rhlow[a.vlow];i!=0;i=rslow[i].next)
		{
			if(rslow[i].v==b.vlow) { flag=1; break; }
		}
		if(flag==1) return true;
		else return false;
	}
	if(a.bigmark==0) return false;
	if(b.bigmark==0) return true;
	return a.bigmark<b.bigmark;
}

void work()
{
	if(cir[1].bigmark==0) ans=max(ans,cir[1].num);
	else ans=max(ans,cir[1].bigmark+cir[1].num-1);
	for(int i=rhlow[cir[1].vlow];i!=0;i=rslow[i].next)
	{
		int to=rslow[i].v;
		int pos=0;
		while(cir[pos].vlow!=to  &&pos<nlow) pos++;
		cir[pos].bigmark=max(cir[pos].bigmark,cir[1].bigmark+cir[1].num+1);
	}
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&a,&b);
		s[++top].v=b; s[top].next=head[a]; head[a]=top;
		res[top].v=a; res[top].next=reh[b]; reh[b]=top;
		out[a]++;
	}
	for(int i=1;i<=n;i++)
	{
		if(out[i]==0)
		{
			mark[i]=max(mark[i],1);
			del(i,1);
		}
	}
	top=0;
	for(int i=1;i<=n;i++)
	{
		if(out[i]!=0) l[++top]=i;
		else ans=max(ans,mark[i]);
	}
	for(int i=1;i<=top;i++)
		if(low[l[i]]==0) Tarjan(l[i]);
	for(int i=1;i<=top;i++)
	{
		if(vislow[ low[l[i]] ]==0)
		{
			vislow[low[l[i]]]=++nlow;
			cir[nlow].num++;
			cir[nlow].vlow=low[l[i]];
			cir[nlow].bigmark=max(cir[nlow].bigmark,mark[l[i]]);
		}
		else
		{
			cir[vislow[low[l[i]]]].num++;
			cir[vislow[low[l[i]]]].bigmark=max(cir[vislow[low[l[i]]]].bigmark,mark[l[i]]);
		}
	}
	for(int i=1;i<=top;i++)
		add_edge(i);
	while(nlow)
	{
		sort(cir+1,cir+nlow+1,cmp);
		work();
		swap(cir[1],cir[nlow]);
		nlow--;
	}
	printf("%d",ans);
	return 0;
} 
