#include <cstdio>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

char s[100010];
int n, T; bool fl;

void work()
{
	scanf("%d%s", &n, s + 1);
	fl = 1;
	FOR(i, 2, n) if (s[i] != s[1]) {fl = 0; break;}
	if (fl) {puts("-1"); return;} //aaaaa
	if (n & 1)
	{
		fl = 1;
		FOR(i, 2, n) if (i != (n + 1) / 2) 
			if (s[i] != s[1]) fl = 0;
		if (fl) {puts("-1"); return;}
	} //aabaa
	fl = 1;
	FOR(i, 1, n >> 1) if (s[i] != s[n - i + 1]) {fl = 0; break;}
	if (!fl) {puts("1"); return;} //abab
	FOR(i, 3, n) if (s[i] != s[i - 2]) {fl = 0; break;}
	if (fl && (n & 1)) {puts("-1"); return;} //ababa
	puts("2");
}

int main()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &T);
	while (T--) work();
	return 0;
}
