#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <set>

using namespace std;
#define MAXN 1500
#define db double
#define EPS 1e-9
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
db w[MAXN+5], pow, ans; int n; typedef multiset<db> Set; Set S; Set::reverse_iterator it;
int main()
{
	freopen("drink.in","r",stdin), freopen("drink.out","w",stdout);
	n = read(); for(rint i = 1; i <= n; w[i++] = read());
	for(rint l = 1, r; l <= n; l++)
		for(S.clear(), r = l; r <= n; r++)
			for(S.insert(w[r]), pow = .5, it = S.rbegin(); it != S.rend() && *it*pow >= EPS; ans += *it*pow, pow /= 2, it++);
	printf("%.15f\n",ans/n/n); return 0;
}
