#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#include<vector>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
typedef long long LL;
const int N=63000,mod=998244353;
int n,m,f[N],ans,len[10],nxt[10][105];
char s[10][105];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void get_nxt(int nxt[],int id)
{
	rep(i,2,len[id])
	{
		int k=nxt[i-1];
		while(k && s[id][k+1]!=s[id][i]) k=nxt[k];
		if(s[id][k+1]==s[id][i]) nxt[i]=k+1;
		else nxt[i]=0;
	}
}

bool check(int nxt[],int id)
{
	int nw=0;
	rep(i,1,2*m)
	{
		while(nw && s[id][nw+1]-48!=f[i]) nw=nxt[nw];
		if(s[id][nw+1]-48==f[i]) ++nw;
		if(nw==len[id]) return 1;
	}
	return 0;
}

void task1()
{
	rep(i,1,n)
	{
		scanf("%s",s[i]+1);
		len[i]=strlen(s[i]+1),get_nxt(nxt[i],i);
	}
	rep(i,0,(1<<m)-1)
	{
		rep(j,1,2*m)
			if(j<=m) f[j]=(bool)(i&(1<<j-1));
			else f[j]=!f[2*m-j+1];
		bool jdg=0;
		rep(j,1,n)
			if(!check(nxt[j],j))
			{
				jdg=1;
				break;
			}
		if(!jdg) ++ans;
	}
	printf("%d\n",ans);
}

void inc(int &x,int y)
{
	if((x+=y)>=mod) x-=mod;
}

int getmi(int a,int x)
{
	int rt=1;
	while(x)
	{
		if(x&1) rt=(LL)rt*a%mod;
		a=(LL)a*a%mod,x>>=1;
	}
	return rt;
}

bool check1(int x)
{
	int l=len[0]-x;
	rep(i,1,x)
		if(s[0][l+i]==s[0][l-i+1]) return 0;
	return 1;
}

bool check2(int x)
{
	int l=x;
	rep(i,1,x)
		if(s[0][l+i]==s[0][l-i+1]) return 0;
	return 1;
}

int g[505][105][105];

void task2()
{
	scanf("%s",s[0]+1),len[0]=strlen(s[0]+1);
	get_nxt(nxt[0],0),len[1]=len[0];
	rep(i,1,len[0]) s[1][i]=s[0][len[0]-i+1];
	get_nxt(nxt[1],1);
	g[0][0][0]=1;
	rep(i,0,m-1)
		rep(j,0,len[0]-1)
			rep(k,0,len[0]-1)
				if(g[i][j][k])
					rep(l,0,1)
					{
						int nw1=j,nw2=k;
						while(nw1 && s[0][nw1+1]-48!=l) nw1=nxt[0][nw1];
						if(s[0][nw1+1]-48==l) ++nw1;
						
						while(nw2 && s[1][nw2+1]-48==l) nw2=nxt[1][nw2];
						if(s[1][nw2+1]-48!=l) ++nw2;
						
						inc(g[i+1][nw1][nw2],g[i][j][k]);
					}
	rep(i,1,m)
	{
		rep(j,0,len[0])
			ans=(ans+(LL)g[i][len[0]][j]*getmi(2,m-i))%mod;
		rep(j,0,len[0]-1)
			ans=(ans+(LL)g[i][j][len[0]]*getmi(2,m-i))%mod;
	}
	rep(i,1,len[0])
		rep(j,1,len[0])
			if(i<=(len[0]>>1) && check1(i) || j<=(len[0]>>1) && check2(j))
				inc(ans,g[m][len[0]-i][len[0]-j]);
	printf("%d\n",ans);
}		

int main()
{
	freopen("string.in","r",stdin);
	freopen("strings.out","w",stdout);
	n=getint(),m=getint();
	task2();
	return 0;
}
