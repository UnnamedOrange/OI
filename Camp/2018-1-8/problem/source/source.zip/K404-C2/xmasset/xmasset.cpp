#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
int n,T,x,y,q,h;

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void solveA()
{
	n=getint(),T=getint();
	while(T--)
	{
		x=getint(),y=getint();
		rep(i,1,10)
		{
			if((x&1)!=(y&1)) {printf("%d\n",i+10*(x&1)); break;}
			x>>=1,y>>=1;
		}
	}
}

void solveB()
{
	n=getint(),T=getint();
	while(T--)
	{
		q=getint(),h=getint(),x=0;
		if(h>10) h-=10,x=1;
		q>>=(h-1);
		if((q&1)!=x) puts("no");
		else puts("yes");
	}
}

int main()
{
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	int tp=getint();
	if(tp==1) solveA();
	else solveB();
	return 0;
}
