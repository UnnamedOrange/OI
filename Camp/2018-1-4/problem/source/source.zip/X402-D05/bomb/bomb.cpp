#include<bits/stdc++.h>
using namespace std;
void chkmin(int &x,int y){
	x=x<y?x:y;
}
int Max(int x,int y){
	return x>y?x:y;
}
void readl(int &x){
	x=0;
	char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
const int maxn=1001000;
struct node{
	int s,t;
}w[maxn];
int beg[maxn],tto[maxn],nex[maxn],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
void clear_graph(){
	e=0;
	memset(beg,0,sizeof(beg));
}
int val[maxn];
int pre[maxn],low[maxn],dfs_time;
bool instk[maxn];
int stk[maxn],top;
int bccnum;
int f[maxn];
void tarjan(int u){
	pre[u]=low[u]=++dfs_time;
	stk[++top]=u;
	instk[u]=1;
	for(int i=beg[u];i;i=nex[i]){
		if(!pre[tto[i]]){
			tarjan(tto[i]);
			chkmin(low[u],low[tto[i]]);
		}
		else if(instk[tto[i]])
			chkmin(low[u],pre[tto[i]]);
	}
	if(low[u]>=pre[u]){
		int num=0;
		bccnum++;
		while(stk[top]!=u){
			f[stk[top]]=bccnum;
			instk[stk[top]]=0;
			num++;
			top--;
		}
		f[stk[top]]=bccnum;
		instk[stk[top]]=0;
		num++;

		top--;
		val[bccnum]=num;
	}
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		readl(w[i].s),readl(w[i].t);
		putin(w[i].s,w[i].t);
	}
	for(int i=1;i<=n;i++)
		if(!pre[i])
			tarjan(i);
	clear_graph();
	static int q[maxn],d[maxn],g[maxn];
	int l=1,r=0;
	for(int i=1;i<=m;i++){
		if(f[w[i].s]!=f[w[i].t]){
			putin(f[w[i].s],f[w[i].t]);
			d[f[w[i].t]]++;
		}
	}
	for(int i=1;i<=bccnum;i++)
		if(!d[i]) q[++r]=i,g[i]=val[i];
	int u;
	while(l<=r){
		u=q[l],l++;
		for(int i=beg[u];i;i=nex[i]){
			d[tto[i]]--;
			g[tto[i]]=Max(g[tto[i]],g[u]);
			if(d[tto[i]]==0) q[++r]=tto[i],g[tto[i]]+=val[tto[i]];
		}
	}
	int ans=0;
	for(int i=1;i<=bccnum;i++)
		ans=Max(ans,g[i]);
	printf("%d\n",ans);
	return 0;
}
