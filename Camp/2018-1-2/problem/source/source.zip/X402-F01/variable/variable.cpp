#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1000+5;
bool cmax(ll &a,ll b){return (a<b)?a=b,1:0;}
bool cmin(ll &a,ll b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("variable.in","r",stdin);
		freopen("variable.out","w",stdout);
	#endif
}
int n,w,p,q;
struct A
{
	int x,y,z,a,b,c,d,e,f;
}e[N];
struct B
{
	int opt,x,y;
}a[N];
int l[N],fa[N];
int find(int x){return fa[x]==x?x:fa[x]=find(fa[x]);}
void input()
{
	n=read<int>();w=read<int>();p=read<int>();q=read<int>();
	For(i,1,p)
	{
		e[i].x=read<int>();e[i].y=read<int>();e[i].z=read<int>();
		e[i].a=read<int>();e[i].b=read<int>();e[i].c=read<int>();
		e[i].d=read<int>();e[i].e=read<int>();e[i].f=read<int>();
	}
	For(i,1,q)
	{
		a[i].x=read<int>();
		a[i].y=read<int>();
		a[i].opt=read<int>();
	}
}
const ll inf=1e18;
int num[N];
ll ans;
bool check()
{
	For(i,1,q)
	{
		if(a[i].opt==0&&num[a[i].x]<=num[a[i].y])continue;
		else if(a[i].opt==1&&num[a[i].x]==num[a[i].y])continue;
		else if(a[i].opt==2&&num[a[i].x]<num[a[i].y])continue;
		return 0;
	}
	return 1;
}
void cal(bool flag)
{
	if(flag)For(i,1,n)num[i]=num[find(i)];
	if(!check())return;
	ll sum=0;
	int num1,num2,num3;
	For(i,1,p)
	{
		num1=num[e[i].x]-num[e[i].y];
		num2=num[e[i].y]-num[e[i].z];
		num3=num[e[i].z]-num[e[i].x];
		sum+=abs(num1)*e[i].a+abs(num2)*e[i].b+abs(num3)*e[i].c;
		sum+=num1*e[i].d+num2*e[i].e+num3*e[i].f;
	}
	sum*=w;
	For(i,1,n)sum+=num[i];
	cmin(ans,sum);
}
void dfs(int dep)
{
	if(dep==n+1){cal(0);return;}
	num[dep]=1;dfs(dep+1);
	num[dep]=-1;dfs(dep+1);
}
void work1()
{
	ans=inf;
	dfs(1);
	printf("%lld\n",ans);
}
int T;
void deal()
{
	l[0]=0;
	For(i,1,n)fa[i]=i;
	For(i,1,q)
	{
		if(a[i].opt==2)num[a[i].x]=-1,num[a[i].y]=1;
		else if(a[i].opt==1)fa[find(a[i].y)]=find(a[i].x);
	}
	For(i,1,n)if(num[i]!=0)num[find(i)]=num[i];
	For(i,1,n)num[i]=num[find(i)];
	For(i,1,n)if(num[i]==0&&find(i)==i)l[++l[0]];
}
void work2()
{
	srand(time(NULL));
	ans=inf;
	int tim=10000000/T;
	deal();
	if(l[0])
	{
		tim/=l[0];
		while(tim--)
		{
			For(i,1,l[0])num[l[i]]=(rand()%2==0?-1:1);		
			cal(1);
		}
	}
	else cal(1);
	printf("%lld\n",ans);
}
int main()
{
	file();
	T=read<int>();
	For(i,1,T)
	{
		input();
		if(n<=15)work1();
		else work2();
		//work2();
	}
	return 0;
}
