#include<bits/stdc++.h>
using namespace std;
const long long md=998244353;
const int maxn=100100;
long long powd(long long x,long long y){
	long long res=1;
	while(y){
		if(y&1) res=res*x%md;
		x=x*x%md;
		y>>=1;
	}
	return res;
}
long long pw[maxn];
int dp[400][400];
int dq[400][400];
int f[400][400],g[400][400];
void Mo(int &x){
	x=x>=md?x-md:x;
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int n,m,K;
	scanf("%d%d%d",&n,&m,&K);
	if(n>m){
		printf("0\n");
		return 0;
	}
	for(int i=1;i<=n;i++)
		pw[i]=powd(i,K);
	dp[0][0]=1;
	for(int i=1;i<=m;i++){
		for(int j=0;j<=n;j++)
			for(int k=0;k<=j;k++){
				if(k>0){
					Mo(dq[j][k]+=dp[j-1][k-1]);
					Mo(g[j][k]+=f[j-1][k-1]);
				}
				if(j>0){
					Mo(dq[j][k]+=dp[j-1][k]);
					Mo(g[j][k]+=f[j-1][k]);
				}
				if(k<n){
					Mo(dq[j][k]+=dp[j][k+1]);
					Mo(g[j][k]+=f[j][k+1]);
				}
				Mo(dq[j][k]+=dp[j][k]);
				Mo(g[j][k]+=f[j][k]);
				g[j][k]=(g[j][k]+pw[k]*dq[j][k])%md;
			}
		for(int j=0;j<=n;j++){
			for(int k=0;k<=j;k++){
				dp[j][k]=dq[j][k],dq[j][k]=0;
				f[j][k]=g[j][k],g[j][k]=0;
			}
		}
		dp[0][0]=1;
	}
	printf("%d\n",f[n][0]);
	return 0;
}
