#include <bits/stdc++.h>
#define LL long long
#define MAXN 1000000
using namespace std;
int T,n,prime[MAXN+10],p_num;
LL tot,c[MAXN+10];
bool isprime[MAXN+10];
void init()
{
	memset(isprime,1,sizeof(isprime));
	isprime[1]=0;
	for(int i=2;i<=MAXN;i++)
	{
		if(isprime[i])
		{
			prime[++p_num]=i;
			if(i*i<=MAXN)
			{
				for(int j=2;i*j<=MAXN;j++)
				{
					isprime[i*j]=0;
				}
			}
		}
	}
}
LL calc(int x)
{
	if(c[x])
	{
		return c[x];
	}
	LL ret=1;
	for(int i=1;i<=p_num&&x!=1&&prime[i]*prime[i]<=x&&(!isprime[x]);i++)
	{
		int cnt=0;
		while(x%prime[i]==0)x/=prime[i],cnt++;
		ret*=(2*cnt+1);
	}
	if(x!=1)
	{
		ret*=3;
	}
	return c[x]=ret;
}
LL solve(int x)
{
	LL ret=0;
	for(int i=1;i<=x;i++)
	{
		ret+=calc(i);
	}
	return ret;
}
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	init();
 	cin>>T;
// 	T=5,n=1000000;
	while(T--)
	{
		cin>>n;
		cout<<solve(n)<<endl;
	}
}
/*
2*p+1
6
2 3
3*3
1*4*4
-1*2*2
-1*2*2
1*1*1
*/
