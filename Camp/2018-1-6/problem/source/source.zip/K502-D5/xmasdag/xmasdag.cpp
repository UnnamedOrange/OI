#include<bits/stdc++.h>
using namespace std;

const int mod = 998244353;
const int maxn = 1e+5 + 10;
const int maxk = 500 + 10;

int n,m,k,rd[maxn],f[maxn][maxk],g[2010][5010];
stack<int> e[maxn];
int com[maxk][maxk];

inline int C(int n,int r)
{
	if(com[n][r]) return com[n][r];
	if(n==r || !r) return com[n][r]=1;
	return com[n][r]=(C(n-1,r-1)+C(n-1,r))%mod;
}
inline int MOD(int x){return x>mod?x-mod:x;}

void read()
{
	int i,u,v;
	scanf("%d%d%d",&n,&m,&k);
	for(i=0;i<m;i++)
	{
		scanf("%d%d",&u,&v);
		e[u].push(v);rd[v]++;
	}
}

void solve1()
{
	int i,j,u,v;
	queue<int> q;
	
	f[1][0]=1;
	q.push(1);
	while(!q.empty())
	{
		u=q.front();q.pop();
		while(!e[u].empty())
		{
			v=e[u].top();e[u].pop();
			for(i=0;i<=k;i++)
			for(j=0;j<=i;j++) f[v][i]=MOD(f[v][i]+1ll*f[u][j]*C(i,j)%mod);				
			if(!(--rd[v])) q.push(v);
		}
	}
	for(i=1;i<=n;i++) printf("%d\n",f[i][k]);
}

int powk[maxn];
int qpow(int a,int x)
{
	int ans=1;
	for(;x;a=1ll*a*a%mod,x>>=1) if(x&1) ans=1ll*ans*a%mod;
	return ans;
}
void pre2()
{
	for(int i=0;i<=m;i++) powk[i]=qpow(i,k);
}
void solve2()
{
	int i,j,u,v;
	queue<int> q;q.push(1);g[1][0]=1;
	while(!q.empty())
	{
		u=q.front();q.pop();
		while(!e[u].empty())
		{
			v=e[u].top();e[u].pop();
			for(i=0;i<m;i++) g[v][i+1]=MOD(g[v][i+1]+g[u][i]);
			if(!(--rd[v])) q.push(v);
		}
	}
	
	pre2();
	for(i=1;i<=n;i++) 
	{
		int ans=0;
		for(j=0;j<=m;j++) ans=MOD(ans+1ll*g[i][j]*powk[j]%mod);
		cout<<ans<<endl;
	}
}

void solve()
{
	if(m<=5000) solve2();
	else solve1();
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	
	read();
	solve();
	
	return 0;
}
