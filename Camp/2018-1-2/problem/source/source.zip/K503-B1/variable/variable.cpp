#include<bits/stdc++.h>
using namespace std;
const int maxn=3010;
int T,opt,n,w,p,q,x[maxn],y[maxn],z[maxn],a[maxn],b[maxn],c[maxn],d[maxn],e[maxn],f[maxn],xi1[maxn],xi2[maxn],xi3[maxn],th[maxn];
int i,j,k,ans,anss;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void checking(){
	int i,t1=0;
	for (i=1;i<=q;i++){
		if (xi3[i]==0){
			if (th[xi1[i]]<=th[xi2[i]]) t1++;
		}
		if (xi3[i]==1){
			if (th[xi1[i]]==th[xi2[i]]) t1++;
		}
		if (xi3[i]==2){
			if (th[xi1[i]]<th[xi2[i]]) t1++;
		}
	}
	if (t1!=q) return;
	anss=0;
	for (i=1;i<=p;i++){
		anss=anss+a[i]*abs(th[x[i]]-th[y[i]])+b[i]*abs(th[y[i]]-th[z[i]])+c[i]*abs(th[z[i]]-th[x[i]]);
		anss=anss+d[i]*(th[x[i]]-th[y[i]])+e[i]*(th[y[i]]-th[z[i]])+f[i]*(th[z[i]]-th[x[i]]);
	}
	for (i=1;i<=n;i++){
		anss=anss+th[i];
	}
	if (anss<ans) ans=anss;
}
void work(int x){
	if (x==n+1){
		checking();
		return;
	}
	th[x]=-w; work(x+1);
	th[x]=w; work(x+1);
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	T=read();
	for (opt=1;opt<=T;opt++){
		n=read(); w=read(); p=read(); q=read();
		ans=(1e9)+10;
		for (i=1;i<=p;i++){
			x[i]=read(); y[i]=read(); z[i]=read();
			a[i]=read(); b[i]=read(); c[i]=read(); d[i]=read(); e[i]=read(); f[i]=read();
		}
		for (i=1;i<=q;i++){
			xi1[i]=read(); xi2[i]=read(); xi3[i]=read();
		}
		work(1);
		printf("%d\n",ans);
	}
	return 0;
}
