#include <bits/stdc++.h>
#define LL long long
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x =10*x + c - '0' ;
}
const int maxn = 1e5+5, modd = 1e9+7 ;
int n, d[maxn], m ;
int a, b, val ;
LL ans[5] ;
bool dfs ( int *t, bool now ) {
	register int i, v = now? b:a ;
	register bool fg = 1 ;
	for ( i = 1 ; i <= m ; i ++ )
		if (t[i] >= v) {
			t[i] -= v ;
			fg &= dfs(t, now^1) ;
			t[i] += v ;
			if (fg == 0) return 1 ;
		}
	return 0 ;
}
int t[maxn] ;
int calc ( int x ) {
	register int fg0, fg1 ;
	register int i ;
	for ( m = 0, i = 1 ; i <= n ; i ++, x >>= 1 )
		if (x&1) t[++m] = d[i] ;
	fg0 = dfs(t, 0) ;
	fg1 = dfs(t, 1) ;
	if (fg0 == 0 && fg1 == 0) return 0 ;
	if (fg0 == 1 && fg1 == 1) return 1 ;
	if (fg0 == 1) return 2 ;
	return 3 ;
}
int main() {
	freopen ( "stone.in", "r", stdin ) ;
	freopen ( "stone.out", "w", stdout ) ;

	register int i, x ;
	Read(n) ; Read(a) ; Read(b) ;
	for ( i = 1 ; i <= n ; i ++ ) {
		Read(d[i]) ;
		d[i] %= (a+b) ;
	}
	x = 1<<n ;
	for ( i = 0 ; i < x ; i ++ )
		(++ ans[calc(i)]) %= modd ;
	printf ( "%lld %lld %lld %lld\n", ans[2]%modd, ans[3]%modd, ans[0]%modd, ans[1]%modd ) ;
	//cerr << (double)clock()/CLOCKS_PER_SEC << endl ;
	return 0 ;
}
