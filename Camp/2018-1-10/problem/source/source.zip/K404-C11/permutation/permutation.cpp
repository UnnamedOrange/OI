#include <bits/stdc++.h>

int main() {
    freopen("permutation.in", "r", stdin);
    freopen("permutation.out", "w", stdout);
    puts("0");
    return 0;
}