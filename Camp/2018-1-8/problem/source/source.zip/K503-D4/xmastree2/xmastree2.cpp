#include<bits/stdc++.h>
#define maxn 100
using namespace std;
int head[maxn], nxt[maxn], a[maxn], edge, v[maxn], able[maxn], use[maxn], father[maxn], ans, n;
void create(int u, int v)
{
	edge++; a[edge] = v; nxt[edge] = head[u]; head[u] = edge;
}
void getfa(int u, int fa)
{
	father[u] = fa;
	for (int i = head[u]; i; i = nxt[i])
	{
		int v = a[i];
		if (v != fa) getfa(v, u);
	}
}
void work(int dep, int cur)
{
	if (dep > n) ans = max(ans, cur);
	else
	for (int i = 1; i <= n; i++)
	{
		if (dep == 1)
		{
			if (able[i] == 0) continue;
			getfa(i, 0);
			use[i] = 1;
			work(dep + 1, cur + dep * v[i]);
			use[i] = 0;
		}
		else
		{
			if (use[i] == 1 || use[father[i]] == 0) continue;
			use[i] = 1;
			work(dep + 1, cur + dep * v[i]);
			use[i] = 0;
		}
	}
}
int main()
{
	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n - 1; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		create(u, v); create(v, u);
	}
	for (int i = 1; i <= n; i++)
		scanf("%d%d", &v[i], &able[i]);
	work(1, 0);
	printf("%d\n", ans);
	return 0;
}
