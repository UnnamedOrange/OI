#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <bitset>
#define MOD 1000000007
#define LL long long
using namespace std;
template<class T>
inline T read(T& x)
{
	x=0;char ch=getchar();int w=1;
	while(ch>'9'||ch<'0'){if(ch=='-')w=-1;ch=getchar();};
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();};
	x*=w;
}
int n,a,b,x[100010],r[2][2];
int d[6][6][6][6][6][2];
int dp(int x1,int x2,int x3,int x4,int x5,int i)
{
	if(d[x1][x2][x3][x4][x5][i]>=0)return d[x1][x2][x3][x4][x5][i];
	int flag=0;
	if(i)
	{
		//bob���� 
		flag=1;
		if(x1>=b)flag&=(dp(x1-b,x2,x3,x4,x5,0));
		if(x2>=b)flag&=(dp(x1,x2-b,x3,x4,x5,0));
		if(x3>=b)flag&=(dp(x1,x2,x3-b,x4,x5,0));
		if(x4>=b)flag&=(dp(x1,x2,x3,x4-b,x5,0));
		if(x5>=b)flag&=(dp(x1,x2,x3,x4,x5-b,0));
	}
	else
	{
		//alice���� 
		flag=0;
		if(x1>=a)flag|=(dp(x1-a,x2,x3,x4,x5,1));
		if(x2>=a)flag|=(dp(x1,x2-a,x3,x4,x5,1));
		if(x3>=a)flag|=(dp(x1,x2,x3-a,x4,x5,1));
		if(x4>=a)flag|=(dp(x1,x2,x3,x4-a,x5,1));
		if(x5>=a)flag|=(dp(x1,x2,x3,x4,x5-a,1));
	}
	return flag;
}
long long f[100010][2];
int main()
{
//	freopen("stone.in","r",stdin);
//	freopen("stone.out","w",stdout);
	cin>>n>>a>>b;
	for(int i=1;i<=n;i++)
	{
		read(x[i]);
	}
	if(a!=b)
	{
		for(int i=0;i<(1<<n);i++)
		{
			bitset<10> b(i<<1);
			memset(d,-1,sizeof(d));
			bool alice=dp(b[1]*x[1],b[2]*x[2],b[3]*x[3],b[4]*x[4],b[5]*x[5],0);
			bool bob=dp(b[1]*x[1],b[2]*x[2],b[3]*x[3],b[4]*x[4],b[5]*x[5],1);
			r[alice][bob]++;
		}
		cout<<r[1][1]<<' '<<r[0][0]<<' '<<r[1][0]<<' '<<r[0][1]<<endl;
	}
	else
	{
		for(int i=1;i<=n;i++)
		{
			x[i]=(x[i]/a)%2;
		}
		f[0][0]=1;
		for(int i=1;i<=n;i++)
		{
			if(x[i])
			{
				f[i][1]=(f[i-1][0]+f[i-1][1])%MOD;
				f[i][0]=(f[i-1][0]+f[i-1][1])%MOD;
			}
			else
			{
				f[i][1]=(2*f[i-1][1])%MOD;
				f[i][0]=(2*f[i-1][0])%MOD;
			}
		}
		cout<<0<<' '<<0<<' '<<f[n][1]<<' '<<f[n][0]<<endl;
	}
	return 0;
}

*/
