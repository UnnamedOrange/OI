#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v=-v;
}
int kind;
int n, T;
int mx[15], my[15], lenx, leny, nx[15], ny[15], h;
int mq[15], lenq;
int main() {
	R(kind);
	R(n), R(T);
	if(kind == 1) { //����
	//	freopen("in.in", "w",stdout);
		int x, y;
		while(T--) {
			R(x), R(y);
			memset(mx, 0, sizeof(mx));
			memset(my, 0, sizeof(my));
			int tx, ty;
			tx = x, ty = y;
			int fx = tx, fy = ty;
			lenx = 0, leny = 0;
			// ���x �� y ��ԭʼ����
			mx[++lenx] = fx % 5;
			fx /= 5;
			while(fx) {
				mx[++lenx] = fx % 3;
				fx /= 3;
			}
			my[++leny] = fy % 5;
			fy /= 5;
			while(fy) {
				my[++leny] = fy % 3;
				fy /= 3;
			}
			bool pd = 0;
			h = 1;
			if(mx[1] != my[1]) {
				h += mx[1];
				pd = 1;
			}
			if(!pd) {
				h += 5;
				for(int i = 2; pd == 0 && i <= max(lenx, leny); ++i) {
					if(mx[i] != my[i]) {
						h += mx[i];
						pd = 1;
						break;
					}
					h += 3;
				}
			}
			printf("%d\n", h);
		}
	} else {
		int q, h;
		while(T--) {
			R(q), R(h);
			memset(mq, 0, sizeof(mq));
			lenq = 0;
			mq[++lenq] = q % 5;
			q /= 5;
			while(q) {
				mq[++lenq] = q % 3;
				q /= 3;
			}
			int yi = 1, er = 0;
			if(h <= 5) {
				yi = 1, er = h - 1;
			} else {
				++yi;
				h-=5;
				while(h > 3) {
					++yi;
					h -= 3;
				}
				er = h - 1;
			}
			if(mq[yi] == er) {
				puts("yes");
			} else {
				puts("no");
			}
		}
	}
}
