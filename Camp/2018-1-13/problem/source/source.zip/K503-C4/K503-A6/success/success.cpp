#include<cstdio>
using namespace std;
#define N 1000006
#define LL long long
#define mod 1000000007
#define rep(i,j,k) for(i=j;i<=k;++i)
int s,t,n,m,i,j,k,cur,sum,ans;
int c[1005][1005],f[2][N];
void read(int &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
}
void init(){
	read(s); read(t); read(n); read(m);
	rep(i,0,1000){
		c[i][0]=c[i][i]=1;
	  	rep(j,1,i-1) c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
	}	
	f[0][0]=1; 
	rep(i,1,n){
		sum=0; cur=(i&1);
		rep(j,1,s-m+n){
			sum=(sum+f[cur^1][j-1])%mod;
			f[cur][j]=sum;
			if(j-t>=0){
				sum=(((sum-f[cur^1][j-t])%mod)+mod)%mod;
			}
		}
		f[cur^1][0]=0;
	}
	rep(i,n,s-m+n){
		ans+=(f[n&1][i]*1LL*c[s-i][m-n])%mod;
		ans%=mod;
	}
	printf("%d\n",ans);
}
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	init();
	return 0; 
}
