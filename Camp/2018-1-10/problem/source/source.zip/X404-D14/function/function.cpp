#include<cstdio>
#include<iostream>
using namespace std;
int prim[100010];
int cnt;
int n,m;
int summ[1000010];
long long sumc[1000010];
int e[1000010],C[1000010];
int mu[1000010];
long long ans;
bool vis[1000010];
void get_prim(int x)
{
	mu[1]=1;C[1]=1;
	for (int i=2;i<=x;i++)
	{
		if (!vis[i])
			mu[i]=-1,prim[++cnt]=i,C[i]=2,e[i]=1;
		for (int j=1;j<=cnt&&i*prim[j]<=x;j++)
		{
			vis[i*prim[j]]=1;
			if (i%prim[j]==0) {C[i*prim[j]]=C[i]/(e[i]+1)*(e[i]+2);e[i*prim[j]]=e[i]+1;mu[i*prim[j]]=0;break;}
			mu[i*prim[j]]=-mu[i];
			C[i*prim[j]]=C[i]*C[prim[j]];
			e[i*prim[j]]=1;
		}
	}
	for (int i=1;i<=x;i++)
	{
		summ[i]=summ[i-1]+mu[i];
		sumc[i]=sumc[i-1]+1ll*C[i]*C[i];
	}
	
}
int main()
{
	freopen("function","r",stdin);
	freopen("function","w",stdout);
	get_prim(1000000);
	int T=0;
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		ans=0;
		int last=0;
		for (int i=1;i<=n;i=last+1)
		{
			last=n/(n/i);
			ans+=1ll*(summ[last]-summ[i-1])*sumc[n/i];
		}
		printf("%lld\n",ans);
	}
}
