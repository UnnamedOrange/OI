#include<cstdio>
const int mod=998244353;
int t[1<<23],keep[8011];
int a[5011],b[5011],c[8011],las[8011],f[8011][8011];
int n,m,k,ans;
inline int max(int a,int b){
	return a>b?a:b;
}
inline int min(int a,int b){
	return a<b?a:b; 
}
inline void dfs(int now,int s){
	t[s]=1;
	if(now==n+1){
		return;
	}
	dfs(now+1,s*k+a[now]);
	dfs(now+1,s*k);
}
inline void False_Dp(){
	for(register int i=1;i<=n+m;++i){
		f[i][1]=1;
		for(register int j=1;j<=k;++j)
			if(las[j])
				for(register int l=1;l<=i;++l)
					f[i][l]=(f[i][l]+f[las[j]][l-1])%mod;
		las[c[i]]=i;
	}
	for(register int i=1;i<=k;++i)
		for(register int j=1;j<=n+m;++j)
			keep[j]=(keep[j]+f[las[i]][j])%mod;
}
inline void clear(){
	for(register int i=0;i<=n+m;++i)
		for(register int j=0;j<=k;++j)f[i][j]=0;
	for(register int i=1;i<=n+m;++i)keep[i]=0;
	for(register int i=1;i<=k;++i)las[i]=0;
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(n<=18&&m<=18){
		for(register int i=1;i<=n;++i){
			scanf("%d",a+i);
			--a[i];
		}
		dfs(1,0);
		for(register int i=1;i<=m;++i){
			scanf("%d",a+i);
			--a[i];
		}
		dfs(1,0);
		for(register int i=1;;++i){
			if(!t[i]){
				while(i){
					i>>=1;
					++ans;
				}
				printf("%d\n",ans);
				return 0;
			}
		}
	}
	for(register int i=1;i<=n;++i)scanf("%d",a+i);
	for(register int i=1;i<=m;++i)scanf("%d",b+i);
	for(register int i=1;i<=n;++i)c[i]=a[i];
	for(register int i=n+1;i<=n+m;++i)c[i]=b[i-n];
	False_Dp();
	for(register int i=1,sum=1;;++i){
		sum=1ll*sum*k%mod;
		if(sum!=keep[i]){
			ans=i;
			break;
		}
	}
	clear();
	for(register int i=1;i<=m;++i)c[i]=b[i];
	for(register int i=m+1;i<=n+m;++i)c[i]=a[i-m];
	False_Dp();
	for(register int i=1,sum=1;;++i){
		sum=1ll*sum*k%mod;
		if(sum!=keep[i]){
			printf("%d",min(ans,min(i,max(n,m))));
			return 0;
		}
	}
	return 0;
}
