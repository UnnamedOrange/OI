/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
typedef long long LL;
using namespace std;
#define MAXN 1000000
int p[MAXN+10],pcnt;
void initP()
{
    p[pcnt=1]=2;
    for(int i=3; i<=MAXN; ++i)
    {
        bool flag=true;
        for(int j=1; j<=pcnt; ++j)
        {
            if (i%p[j]==0)
            {
                flag=false;
                break;
            }
        }
        if (flag) p[++pcnt]=i;
    }
}
int tong[MAXN+10];
int calcMu(int n)
{
    if (n==1) return 1;
    for(int i=2; i*i<=n; ++i)
    {
        int cnt=0;
        while(n%i==0)
        {
            n/=i;
            ++cnt;
        }
		if (cnt>1) return 0;
    }
	return 1;
}
int calcX(int n)
{
	int ans=1;
	for(int i=1; p[i]*p[i]<=n; ++i)
	{
		int cnt=0;
		while(n%p[i]==0)
		{
			n/=p[i];
			++cnt;
		}
		ans*=(cnt+1);
	}
	if (n>1) ans*=2;
	return ans;
}
LL calcFun(int n)
{
	LL ans=0;
	for(int i=1; i*i<=n; ++i)
	{
		if (n%i==0)
		{
			int d=i;
			LL t=calcX(n/d);
			ans+=calcMu(d)*t*t;
			d=n/i;
			t=calcX(n/d);
			ans+=calcMu(d)*t*t;
		}
	}
	return ans;
}
int main()
{
	freopen("function.in","r",stdin);
#ifndef MDEBUG
    freopen("function.out","w",stdout);
#endif
    int T;
    cin>>T;
    if (T==0) return 0;
    initP();
    while(T--)
    {
		int n;
		cin>>n;
		LL ans=0;
		for(int i=1; i<=n; ++i)
		{
			ans+=calcFun(i);
		}
		cout<<ans<<endl;
    }
    return 0;
}
