#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<cstdio>
#include<algorithm>
#define ll long long
using namespace std;

const int N=505;
const ll inf=1000000000000000ll;

struct Q{
	int x,y,r;
}g[N];
int T,n,p,q,W,tag;
ll sum,ans;
int a[N],b[N],c[N],d[N],e[N],f[N],w[N],x[N],y[N],z[N];
ll h[N];

int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int s,i;
	scanf("%d",&T);
	while (T--){
		scanf("%d%d%d%d",&n,&W,&p,&q); ans=inf;
		for (i=1;i<=p;i++)
		scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for (i=1;i<=q;i++) scanf("%d%d%d",&g[i].x,&g[i].y,&g[i].r);
		for (s=0;s<(1<<n);s++){
			for (i=1;i<=n;i++)
				if ((s>>i-1)&1) w[i]=-W;
			else w[i]=W;
			tag=1; sum=0;
			for (i=1;i<=q;i++){
				if (g[i].r==2&&w[g[i].x]>=w[g[i].y]) tag=0;
				if (g[i].r==1&&w[g[i].x]!=w[g[i].y]) tag=0;
				if (g[i].r==0&&w[g[i].x]> w[g[i].y]) tag=0;
			}
			if (!tag) continue;
			for (i=1;i<=p;i++)
			h[i]=1ll*a[i]*abs(w[x[i]]-w[y[i]])+1ll*b[i]*abs(w[y[i]]-w[z[i]])+1ll*c[i]*abs(w[z[i]]-w[x[i]])
				+1ll*d[i]*   (w[x[i]]-w[y[i]])+1ll*e[i]*   (w[y[i]]-w[z[i]])+1ll*f[i]*   (w[z[i]]-w[x[i]]);
			for (i=1;i<=n;i++) sum+=1ll*w[i];
			for (i=1;i<=p;i++) sum+=1ll*h[i];
			ans=min(ans,sum);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
/*
1
3 1 1 1
1 2 3 1 1 1 1 1 1
1 2 2
*/
