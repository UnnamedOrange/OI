#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int N=4010;
int nxt[2][N][N],dp[N][2*N];
int a[N],b[N],c[N];
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	register int i,j,k,x,y;
	int n,m,K,lim;
	scanf("%d%d%d",&n,&m,&K);lim=n/K+m/K+2;
	rep(i,1,n)	scanf("%d",&a[i]);
	rep(i,1,m)	scanf("%d",&b[i]);
	if(n>m){
		rep(i,1,n)	c[i]=a[i];
		rep(i,1,n)	a[i]=b[i];
		rep(i,1,n)	b[i]=c[i];
		swap(n,m);
	}
	rep(i,1,K)	nxt[0][n+1][i]=nxt[0][n+2][i]=n+1;
	for(i=n;i;i--){
		memcpy(nxt[0][i],nxt[0][i+1],sizeof(nxt[0][i]));
		nxt[0][i][a[i]]=i;
	}
	rep(i,1,K)	nxt[1][m+1][i]=nxt[1][m+2][i]=m+1;
	for(i=m;i;i--){
		memcpy(nxt[1][i],nxt[1][i+1],sizeof(nxt[1][i]));
		nxt[1][i][b[i]]=i;
	}
	rep(i,1,K)	dp[nxt[0][1][i]][1]=nxt[1][1][i];
	rep(i,1,n+1) rep(j,1,lim-1) if(dp[i][j]){
		rep(k,1,K){
			x=nxt[0][i+1][k];y=nxt[1][dp[i][j]+1][k];
			dp[x][j+1]=max(dp[x][j+1],y);
		}
	}
	//rep(i,1,n+1) rep(j,1,lim) if(dp[i][j]) printf("dp[%d][%d]=%d\n",i,j,dp[i][j]);
	rep(j,1,lim) if(dp[n+1][j]==m+1) {printf("%d\n",j);return 0;}
	return 0;
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
