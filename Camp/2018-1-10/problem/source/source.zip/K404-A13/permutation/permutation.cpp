#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
#define LL long long
using namespace std;
const int maxn = 1e5 + 5, mod = 998244353;
int P[maxn], sec, n, vis[maxn], len, lnkc[2];
LL ans = 1;
bool iscir, d[maxn];
int circle(int x, int st, bool & is_cir) {
	if(x == st) return vis[x] = is_cir = 1;
	if(x == 0) return (is_cir = 0), 1;
	vis[x] = 1;
	return circle(P[x], st, is_cir) + 1;
}
LL GetAns(int x) {
	LL ans = 1;
	for(register int i = 1; i <= x; i += 2) 
		ans = ans * i * i % mod;
	return ans;
}
LL GetA(int a, int b) {
	LL ans = 1;
	For(i, 0, b - 1) 
		ans = ans * (a - i) % mod;
	return ans;
}
int main() {
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	scanf("%d", &n), sec = n;
	For(i, 1, n) scanf("%d", &P[i]), d[P[i]] = 1;
	if(n % 2) {printf("0");return 0;}
	For(i, 1, n) {
		if(d[i] || !P[i]) continue;
		len = circle(P[i], i, iscir);
		++lnkc[len % 2], sec -= len - 1;
	}
	For(i, 1, n) {
		if(!vis[i] && P[i]) {
			len = circle(P[i], i, iscir);
			if(iscir && len % 2 == 1) {printf("0");return 0;}
			if(iscir) sec -= len;
		}
	}
	printf("%lld\n", GetA(sec, lnkc[0]) * GetAns(sec - lnkc[0]) % mod);
}
