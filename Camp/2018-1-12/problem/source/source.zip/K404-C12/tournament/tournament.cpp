#include <iostream>
#include <cstdio>
#define MOD 998244353
using namespace std; 
typedef long long ll;
inline ll quick_pow(ll a, ll n)
{
	ll res = 1; 
	while (n)
	{
		if (n & 1)
			res = res * a % MOD; 
		a = a * a % MOD; 
		n >>= 1; 
	}
	return res;
}
int main()
{
	freopen("tournament.in", "r", stdin); 
	freopen("tournament.out", "wt", stdout); 
	int n, m; 
	scanf("%d%d", &n, &m); 
	if (m == 3)
	{
		ll ans = 1; 
		for (int i = 1; i <= n; i++)
			ans = ans * i % MOD; 
		printf("%lld\n", (quick_pow(2, (ll)n * (n - 1) / 2) - ans + MOD) % MOD); 
		return 0;
	}
	return 0; 
}

