from sys import stdin
n, = map(int, stdin.readline().strip().split())
print n*(n+1)/2
