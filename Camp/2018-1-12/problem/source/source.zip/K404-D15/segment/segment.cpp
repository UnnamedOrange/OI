#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 100005
const int mod=998244353;

int n,m,k,ans,res;
int a[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

int power(int a,int k){
	int ret=1;
	for (;k;k>>=1,a=1ll*a*a%mod) if (k&1) ret=1ll*ret*a%mod;
	return ret;
}

int calc(){
	int ret=0; ++res;
	for (int i=1;i<=m;i++) ret=(ret+power(a[i],k))%mod;
	return ret;
}

void dfs(int x,int l,int r){
	if (x>n){ans=(ans+calc())%mod; return;}
	for (int i=l+1;i<=m;i++)
		for (int j=max(r+1,i);j<=m;j++){
			for (int k=i;k<j;k++) a[k]++;
			dfs(x+1,i,j);
			for (int k=i;k<j;k++) a[k]--;
		}
}

void solve1(){
	int ans=0;
	for (int i=1;i<=m;i++) ans=(ans+1ll*i*(m-i))%mod;
	printf("%d\n",ans);
}

int f[maxn],fac[maxn],inv[maxn];

void solve2(){
	int ans=0;
	for (int i=1;i<=m;i++) f[i]=(f[i-1]+1ll*i*(i+1))%mod;
	fac[0]=1; for (int i=1;i<=m;i++) fac[i]=1ll*fac[i-1]*i%mod;
	for (int i=1;i<m;i++){
		ans=(ans+(1ll*(m-i)*(m-i)%mod*(m-i+1)-f[m-i])%mod*i)%mod;
		ans=(ans+(1ll*(i-1)*(i-1)%mod*i-f[i-1])%mod*(m-i))%mod;
		ans=(ans+1ll*power(2,k)*fac[i-1]%mod*fac[max(0,m-i-1)])%mod;
	}
	ans=1ll*ans*power(2,mod-1)%mod;
	printf("%d\n",(ans+mod)%mod);
}

int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=read(),m=read(),k=read();
	if (m<=6){dfs(1,0,0); cout<<ans<<endl; return 0;}
	if (n==1){solve1(); return 0;}
	if (n==2){solve2(); return 0;}
	return 0;
}
