#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 3000010;

const int maxm = 3000000;

int n, prime[maxn], vis[maxn], Min[maxn], miu[maxn], ys[maxn], cnt;

ll sum[maxn], f[maxn];

void Get(){
	n = read();
}

void pre_work(){
	miu[1] = 1;
	ys[1] = 1;
	sum[1] = 1;
	f[1] = 1;

	For(i, 2, maxm){
		if(!vis[i]){
			prime[++cnt] = i;
			vis[i] = 1;

			miu[i] = -1;
			ys[i] = 2;
			Min[i] = 1;
		}

		for(int j = 1;j <= cnt && 1ll * prime[j] * i <= 1ll * maxm; ++j){
			int k = i * prime[j];
			vis[k] = 1;
			if(i % prime[j] == 0){
				miu[k] = 0;
				Min[k] = Min[i] + 1;

				ys[k] = ys[i] / (Min[i] + 1) * (Min[k] + 1);
				break;
			}

			miu[k] = -miu[i];

			ys[k] = ys[i] * ys[prime[j]];
			Min[k] = 1;
		}

		sum[i] = sum[i-1] + 1ll * ys[i] * ys[i];
		f[i] = 1ll * ys[i] * ys[i];
	}
}

void solve_bf(){
	ll Ans = 0;
	For(i, 1, n){
		Ans += miu[i] * sum[n / i];
	}

	printf("%lld\n", Ans);
}

void guess(){
	ll ans = 0;
	For(i, 1, 100){
		ll Ans = 0;
		For(j, 1, i){
			if(i % j == 0){
				Ans += ys[j];
			}
		}

		printf("i : %d, f : %lld\n", i, Ans);
		ans += Ans;
	//	printf("i : %d, all : %lld\n", i, ans);
	}
}

int main(){
	
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);

	int _ = read();
	if(!_) return 0;

	pre_work();

	while(_ --){
		Get();
		solve_bf();
	}

	return 0;
}
