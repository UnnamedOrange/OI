#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int cnt = 0;
int vis[60];
int f[70][20];
int n, k;
long long ans = 0;
struct edge {
	int v;
	int next;
} g[200];
int head[60];
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}
void open()
{
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}

void addedge(int u, int v)
{
	g[++cnt].v = v;
	g[cnt].next = head[u];
	head[u] = cnt;
}

void DFS(int x)
{
	vis[x] = 1;
	for(int i = 1; i <= k; i++) {
		f[x][i] = 1;
	}
	for(int j = head[x]; j; j = g[j].next) {
		int to = g[j].v;
		if(!vis[to]) {
			DFS(to);
			long long sum = 0;
			for(int i = k; i >= 1; i--) {
				f[x][i] *= sum;
				sum += f[to][i];
			}
		}
	}
}
int main()
{
	n = read(), k = read();
	for(int i = 1; i < n; i++) {
		int u, v;
		u = read(), v = read();
		addedge(u, v);
		addedge(v, u);
	}
	for(int i = 1; i <= n; i++) {
		memset(vis, 0, sizeof vis);
		DFS(i);
		for(int j = 1; j <= k; j++) {
			ans += f[i][j];
			cout<<f[i][j]<<" ";
		}
		cout<<endl;
	}
	printf("%lld\n", ans);
	return 0;
}
