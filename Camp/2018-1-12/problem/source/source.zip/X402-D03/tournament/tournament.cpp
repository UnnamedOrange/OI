#include<bits/stdc++.h>
using namespace std;

const int MAXN = 10;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, K, ans;
bool g[MAXN][MAXN];

void DFS(int u, int v) {
	//printf("%d %d\n", u, v);
	if(v == n+1) u++, v = u+1;
	if(u == n) {
		if(K == 3) {
			int i, j, k;
			/*for(i = 1; i <= n; i++) {
				for(j = 1; j <= n; j++)
					printf("%d ", g[i][j]);
				printf("\n");
			}
			printf("\n");*/
			for(i = 1; i <= n; i++) {
				for(j = 1; j <= n; j++) {
					if(j == i) continue;
					for(k = 1; k <= n; k++) {
						if(k == i || k == j) continue;
						if(g[i][j] && g[j][k] && g[k][i]) break;
					}
					if(k <= n) break;
				}
				if(j <= n) break;
			}
			if(i <= n) ans++;
			return;
		}
	}
	g[u][v] = true;
	g[v][u] = false;
	DFS(u, v+1);
	g[u][v] = false;
	g[v][u] = true;
	DFS(u, v+1);
	g[v][u] = false;
}

int main() {
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);

	n = read(), K = read();

	DFS(1, 2);
	printf("%d\n", ans);
	return 0;
}
