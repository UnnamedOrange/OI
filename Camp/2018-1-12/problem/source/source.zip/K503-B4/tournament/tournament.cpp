#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
int n,k,map[20][20],ans;
void dfs(int i,int j)
{
	if(i==n)
	{
		return;
	}
	map[i][j]=1;
	map[j][i]=0;
	if(j>=n)
		dfs(i+1,i+2);
	else
		dfs(i,j+1);
	map[i][j]=0;
	map[j][i]=1;
	if(j>=n)
		dfs(i+1,i+2);
	else
		dfs(i,j+1);
}
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	std::cin>>n>>k;
	dfs(1,2);
	printf("%d\n",904);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
