#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

typedef long long LL;

using namespace std;

const int N = 1.8e6 + 10, K = 2e5 + 10;

int prm[N], mu[N], fac[N], cfac[N], tot;

void init(int n){
	
	mu[1] = 1, fac[1] = 1;
	For(i, 2, n){
		if(!prm[i]) prm[++tot] = i, mu[i] = -1, cfac[i] = 2, fac[i] = 2;
		for(int j = 1; j <= tot && i * prm[j] <= n; ++j){
			int x = i * prm[j];
			prm[x] = 1;
			if(i % prm[j]){
				mu[x] = -mu[i];
				cfac[x] = 2, fac[x] = fac[i] << 1;
			}
			else{
				cfac[x] = cfac[i] + 1;
				fac[x] = fac[i] / cfac[i] * cfac[x];
				break;
			}
		}
	}
	
}

int num[N], n, m;
LL G[K], F[K], S[K], M[K], D[K];
LL s[N], g[N], d[N], Mu[N];

int main(){

	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);

	int mx = N - 5;
	init(mx);

	For(i, 1, mx){
		for(int j = i; j <= mx; j += i) g[j] += fac[i];
		g[i] += g[i - 1];
		s[i] = s[i - 1] + 1ll * fac[i] * fac[i];
		Mu[i] = mu[i] + Mu[i - 1];
		d[i] = d[i - 1] + fac[i];
	}

	int Case;
	scanf("%d", &Case);

	while(Case--){
		
		scanf("%d", &n);
		LL ans = 0;

		ans = 0;
		m = 0;
		for(int i = n, nxt; i; i = nxt){
			num[++m] = i;
			nxt = n / (n / i + 1);
		}
		reverse(num + 1, num + m + 1);

		For(i, 1, m){
			int x = num[i];
			if(x <= mx){
				M[i] = Mu[x], G[i] = g[x], D[i] = d[x], S[i] = s[x];
				F[i] = 0;
				for(int j = 1; j * j <= x; ++j) F[i] += g[x / j / j] * mu[j];
			}
			else{
				int p = 1;
				D[i] = G[i] = S[i] = M[i] = F[i] = 0;
				M[i] = 1;
				for(int j = x, nxt; j; j = nxt){
					nxt = x / (x / j + 1);
					while(x / j > num[p]) ++p;
					D[i] += 1ll * (j - nxt) * (x / j);
					if(j != 1) M[i] -= (j - nxt) * M[p];
				}

				for(int j = x, l = i, r = i, nxt; j; j = nxt, l = r){
					nxt = x / (x / j + 1);
					while(nxt < num[r]) --r;
					G[i] += (D[l] - D[r]) * (x / j);
				}

				p = 1;

				for(int j = sqrt(x); j; --j){
					while(x / j / j > num[p]) ++p;
					F[i] += G[p] * mu[j];
				}

				p = 1;
				for(int j = x, nxt; j; j = nxt){
					nxt = x / (x / j + 1);
					while(x / j > num[p]) ++p;
					S[i] += (j - nxt) * F[p];
				}

			}
		}

		int p = m;
		For(i, 1, m){
			while(n / num[i] < num[p]) --p;
			ans += (M[i] - M[i - 1]) * S[p];
		}
		printf("%lld\n", ans);
	}

	//cerr << 1.0 * clock() / CLOCKS_PER_SEC << endl;

	return 0;
}
