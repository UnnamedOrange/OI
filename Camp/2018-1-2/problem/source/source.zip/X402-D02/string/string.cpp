#include<iostream>
#include<cstdio>
#include<cstring>

namespace hahahahahahahaha
{
	const int N=101000;
	char s[N];
	int n;
	int calc_odd()
	{
		int mid=(n+1)/2;
		bool flag=1;
		for(int i=2;i<mid;i++)
			flag&=(s[i]==s[i-1]);
		if(flag)return -1;

		flag=1;
		for(int i=3;i<=n;i+=2)
			flag&=(s[i]==s[i-2]);
		for(int i=4;i<=n;i+=2)
			flag&=(s[i]==s[i-2]);

		if(flag)return -1;
		return 2;
	}
	int calc()
	{
		for(int i=1;i<=n;i++)
			if(s[i]!=s[n-i+1])return 1;

		if(n%2)return calc_odd();

		bool flag=1;
		for(int i=2;i<=n;i++)
			flag&=(s[i]==s[i-1]);
		if(flag)return -1;
		return 2;
	}
	void solve()
	{
		scanf("%d",&n);
		scanf("%s",s+1);
		printf("%d\n",calc());
	}
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	for(scanf("%d",&T);T--;hahahahahahahaha::solve());
	return 0;
}
