#include<bits/stdc++.h>
using namespace std;
typedef double db;
typedef long double ldb;
typedef long long ll;

const int maxn = 1e+6 + 10;
/*
struct longdb{
	ldb x;int e;
	longdb(){x=e=0;}
	longdb(ldb xx,int ee)
	{
		x=xx;e=ee;
		while(x>10) x/=10,e++;
		while(x<0.1) x*=10,e--;
	}
	longdb operator = (const int &s){x=s;e=0;}
	longdb operator * (const longdb &s) const{return longdb(x*s.x,e+s.e);}
	longdb operator * (const int &s) const{return longdb(x*s,e);}
	longdb operator / (const longdb &s) const{return longdb(x/s.x,e-s.e);}
	longdb operator / (const int &s) const{return longdb(x/s,e);}
	void operator +=(const longdb &s)
	{
		longdb ts=s;
		while(e<s.e) x/=10,e++;
		while(s.e<e) ts.x/=10,e++;
		x+=ts.x;
	}
	inline ldb cdb(){while(e>0) x*=10;while(e<0) x/=10;return x;}
};*/

ldb ldbpool[maxn<<1],*p2;
void initpow2()
{
	int i;
	p2=ldbpool+maxn;p2[0]=1;
	for(i=1;i<maxn-5;i++) p2[i]=p2[i-1]*2;
	for(i=-1;i>-maxn+5;i--) p2[i]=p2[i+1]/2;
}

struct water{
	int x,id;
	bool operator < (const water &s) const{return x<s.x;}
};
struct node{
	ldb sum;int tag,is;
	inline void div(int d){sum=sum/p2[d];is+=d;tag+=d;}
};
struct segmenttree{
	node nt[maxn<<2];
	int l,r,d;
	
	inline void up(int p)
	{
		int lc=p<<1,rc=lc|1;
		nt[p].sum=nt[lc].sum;
		nt[p].sum+=nt[rc].sum;
	}
	
	inline void down(int p)
	{
		if(!nt[p].tag) return;
		int lc=p<<1,rc=lc|1;
		nt[lc].div(nt[p].tag);nt[rc].div(nt[p].tag);
		nt[p].tag=0;
	}
	
	void firstset(int p,int tl,int tr)
	{
		nt[p].tag=nt[p].is=0;
		if(tl+1==tr){nt[p].sum=1;return;}
		int lc=p<<1,rc=lc|1,mid=(tl+tr)>>1;
		firstset(lc,tl,mid);firstset(rc,mid,tr);
		up(p);
	}
	
	void div2(int p,int tl,int tr)
	{
		if(l<=tl && tr<=r){nt[p].div(d);return;}
		
		down(p);
		int lc=p<<1,rc=lc|1,mid=(tl+tr)>>1;
		if(l<mid) div2(lc,tl,mid);
		if(mid<r) div2(rc,mid,tr);
		up(p);
	}
	
	ldb sum(int p,int tl,int tr)
	{
		if(l<=tl && tr<=r) return nt[p].sum;
		
		down(p);
		int lc=p<<1,rc=lc|1,mid=(tl+tr)>>1;ldb ans=0;
		if(l<mid) ans+=sum(lc,tl,mid);
		if(mid<r) ans+=sum(rc,mid,tr);
		return ans;
	}
	
	int getkey(int p,int tl,int tr)
	{
		if(l<=tl && tr<=r) return nt[p].is;
		
		down(p);
		int lc=p<<1,rc=lc|1,mid=(tl+tr)>>1;
		if(l<mid) return getkey(lc,tl,mid);
		return getkey(rc,mid,tr);
	}
	
	inline void dv(int ll,int rr,int dd){l=ll;r=rr+1;d=dd;div2(1,0,maxn);}
	inline ldb sm(int ll,int rr){l=ll;r=rr+1;return sum(1,0,maxn);}
	inline int gk(int pos){l=pos;r=pos+1;return getkey(1,0,maxn);}
}TL,TR,test;

int n;
priority_queue<water> q;

void input()
{
	int i;water tmp;
	
	scanf("%d",&n);
	for(i=1;i<=n;i++) scanf("%d",&tmp.x),tmp.id=i,q.push(tmp);
}

void solve()
{
	int i=0;
	water u;db fans=0;
	while(!q.empty())
	{i++;
		u=q.top();q.pop();//if(i==45) cerr<<TL.sm(1,u.id)<<' '<<p2[TL.gk(u.id)]<<' '<<TR.sm(u.id,n)<<' '<<p2[TR.gk(u.id)]<<endl;
		//if(i==45) cerr<<u.x*TL.sm(1,u.id)*p2[TL.gk(u.id)]*TR.sm(u.id,n)*p2[TR.gk(u.id)]/2<<endl;
		fans+=TL.sm(1,u.id)*p2[TL.gk(u.id)]*TR.sm(u.id,n)*p2[TR.gk(u.id)]/2*u.x/n/n;//printf("%.15lf\n",fans);
		if(i&1) TL.dv(1,u.id,1),TR.dv(u.id,n,1);
		else    TL.dv(u.id+1,n,-1),TR.dv(1,u.id-1,-1);
	}
	printf("%.15lf",fans);
}

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	
	initpow2();
	TL.firstset(1,0,maxn);
	TR.firstset(1,0,maxn);
	input();
	solve();
	/*
	test.firstset(1,0,maxn);
	initpow2();
	int l,r;char c;
	while(1)
	{
		cin>>c>>l;
		if(c=='d') 
		{
			cin>>r;
			for(int i=0;i<10;i++) test.dv(l,r);
		}
		if(c=='s') cin>>r,cout<<test.sm(l,r)<<endl;
		if(c=='g') cout<<p2[test.gk(l)]<<' '<<test.sm(l,l)<<' '<<p2[test.gk(l)]*test.sm(l,l)<<endl;
	}*/
	
	return 0;
}
