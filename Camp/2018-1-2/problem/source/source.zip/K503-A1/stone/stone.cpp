#include<bits/stdc++.h>
using namespace std;
int n,f[20],a[1000],b[50],ans[4];
bool work(int t){
	int i=b[0];
	while ((i)&&(b[i]>=f[t])){i--;t=!t;}
	return t;
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d %d %d",&n,f,f+1);
	for (int i=1;i<=n;i++) scanf("%d",a+i);
	for (int i=1;i<=n;i++) a[i]%=f[0]+f[1];
	sort(a+1,a+n+1);
	for (int i=0;i<(1<<n);i++){
		b[0]=0;
		for (int j=1;j<=n;j++)
		if ((1<<(j-1))&i) b[++b[0]]=a[j];
		bool x=work(0),y=work(1);
		if (x&&y) ans[0]++;
		if ((!x) && (!y)) ans[1]++;
		if (x && (!y)) ans[2]++;
		if ((!x) && y) ans[3]++;
	}
	printf("%d %d %d %d\n",ans[0],ans[1],ans[2],ans[3]);
	return 0;
}
