#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<stack>
using namespace std;
const int maxn=100005;
char s[maxn];
int f[maxn];
inline bool isstr(int l,int r){
	while(l<r){
		if(s[l]!=s[r]) return 0;
		l++,r--;
	}
	return 1;
}
inline void dp(int n){
	f[0]=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=i;j++)
			if(!isstr(j,i)) f[i]=min(f[i],f[j-1]+1);
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		scanf("%d%s",&n,s+1);
		memset(f,0x3f,sizeof(f));
		dp(n);
		printf("%d\n",f[n]>1000000000?-1:f[n]);
	}
	return 0;
}
