#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,cnt,val[30010],rt[110],ans,tot,fa[1010],vis[1010],q[1010]; 
struct node 
{
	int v;
	node *next_;
}pool[60010],*h[30010];
void addedge(int u,int v)
{
	node *p=&pool[++cnt];
	p->v=v;p->next_=h[u];h[u]=p;
	p=&pool[++cnt];
	p->v=u;p->next_=h[v];h[v]=p;
}
void get_fa(int u)
{
	for(node *p=h[u];p;p=p->next_)
	{
		int v=p->v;
		if(fa[u]==v) continue;
		fa[v]=u;get_fa(v);
	}
}
void check()
{
	int res=0;
	for(int i=2;i<=n;i++)
	{
		bool flag=false;
		for(int j=1;j<i;j++) if(fa[q[i]]==q[j]) flag=true;
		if(!flag) return ;
	}
	for(int i=1;i<=n;i++) res+=val[q[i]]*i;
	ans=max(ans,res);
}
void dfs(int dep)
{
	if(dep>n)
	{
		check();
		return ;
	}
	for(int i=1;i<=n;i++)
	{
		if(!vis[i]) 
		{
			q[dep]=i;vis[i]=1;
			dfs(dep+1),vis[i]=0;
		}
	}
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	int u,v,tmp;
	for(int i=1;i<n;i++) scanf("%d%d",&u,&v),addedge(u,v);
	for(int i=1;i<=n;i++) 
	{
		scanf("%d%d",&val[i],&tmp);
		if(tmp==1) rt[++rt[0]]=i;
	}
	for(int i=1;i<=rt[0];i++) 
	{
		get_fa(rt[i]);
		memset(vis,0,sizeof(vis));
		q[1]=rt[i];vis[rt[i]]=1;
		dfs(2);
	}
	printf("%d",ans);
	return 0;
}
/*
5
1 2
1 3
2 4
3 5
4 1
3 0
4 0
3 0
1 0
*/
