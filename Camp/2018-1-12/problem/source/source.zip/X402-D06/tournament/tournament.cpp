#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int mod=998244353;
const int maxn=100;
int G[maxn][maxn],a[maxn],b[maxn],flag[maxn],vis[maxn];
int dist,ans=0,n,cnt,f;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
void Dfs(int x,int st){
	int i;
	if(f)return;
	if(x==st && cnt==dist){
		f=1;return;
	}
	cnt++;
	vis[x]=1;
	for(i=1;i<=n;i++){
		if((vis[i] && i!=st) || !G[x][i])continue;
		Dfs(i,st);
	}
	cnt--;
	vis[x]=0;
}
void dfs(int cur,int tot){
	if(cur>tot){
		int i;
		memset(G,0,sizeof(G));
		for(i=1;i<=tot;i++){
			if(flag[i])G[a[i]][b[i]]=1;
			else G[b[i]][a[i]]=1;
		}
		for(i=1;i<=n;i++){
			memset(vis,0,sizeof(vis));
			cnt=f=0;
			Dfs(i,i);
			if(f){
				ans++;
				return;
			}
		}
		return;
	}
	flag[cur]=0;
	dfs(cur+1,tot);
	flag[cur]=1;
	dfs(cur+1,tot);
}
int main(){
	int i,j;
#ifndef ONLINE_JUDGE
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
#endif
	n=read();dist=read();
	if(dist==3){
		int ans=1;
		for(i=1;i<=n*(n-1)/2;i++)ans=(ans+ans)%mod;
		int fac=1;
		for(i=1;i<=n;i++)fac=1ll*fac*i%mod;
		printf("%d\n",(ans-fac+mod)%mod);
		return 0;
	}
	int edge=0;
	for(i=1;i<n;i++)
		for(j=i+1;j<=n;j++){
			edge++;
			a[edge]=i;
			b[edge]=j;
		}
	dfs(1,n*(n-1)/2);
	printf("%d\n",ans);
	return 0;
}

