#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXM = 507;
const int MAXS = 607;
const int MAXL = 107;
const int MAXN = 9;
const int MAXSS = ( 1 << 6 ) + 3;
const int MOD = 998244353;

class amT
{
public:
	void clear ()
	{
		INIT ( ch, -1 );
	}
	
	void addtrie ( char cs[], int id )
	{
		int nl = strlen ( cs ), nc, now = 0;
		lp ( i, 0, nl ){
			nc = cs[i] - '0';
			if ( ~ch[now][nc] ) now = ch[now][nc];
			else{
				++kc;
				memcpy ( s[kc], s[now], sizeof ( s[now] ) );
				len[kc] = len[now] + 1;
				s[kc][len[kc]-1] = nc;
				now = ch[now][nc] = kc;
			}
		}
		sta[now] |= ( 1 << id );
	}
	
	void buildac ()
	{
		int l = 0, r = 0, now, v, f;
		q[r++] = 0;
		fail[0] = 0;
		while ( l < r ){
			now = q[l++];
			lp ( i, 0, 2 ){
				if ( ~ch[now][i] ){
					v = ch[now][i];
					q[r++] = v;
					f = fail[now];
					while ( f && ch[f][i] == -1 ) f = fail[f];
					fail[v] = ( now && ( ~ch[f][i] ) ) ? ch[f][i] : 0;
				}else ch[now][i] = ( ~ch[fail[now]][i] ) ? ch[fail[now]][i] : 0;
			}
			
			sta[now] |= sta[fail[now]];
		}
	}
	
	void debug ()
	{
		cerr << "kc: " << kc << endl;
		lpi ( i, 0, kc ){
			cerr << i << ":   s: ";
			lp ( j, 0, len[i] ) cerr << s[i][j] << " ";
			cerr << "   ch: " << ch[i][0] << " " << ch[i][1] << "   sta: " << sta[i] << endl;
		}
	}
	
	int kc, ch[MAXS][2], fail[MAXS], q[MAXS], sta[MAXS], len[MAXS];
	int s[MAXS][MAXL];
}fw, rev;

int n, m;
char s[MAXN][MAXL];
int dp[2][MAXSS][MAXS][MAXS];
int cto[MAXS][MAXS], kt[MAXS];



void init ();
void input ();
void work ();

bool issuffix ( int s[], int t[], int ns, int nt );
int getsta ( int vf, int vr );

void addv ( int &x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
}

int add ( int x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
	return x;
}



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "string" );
	
//	freopen ( "error.log", "w", stderr );
}

void input ()
{
	scanf ( "%d%d", &n, &m );
	lp ( i, 0, n ) scanf ( "%s", s[i] );
}

void work ()
{
	fw.clear ();
	lp ( i, 0, n ) fw.addtrie ( s[i], i );
	fw.buildac ();
	rev.clear ();
	lp ( i, 0, n ) reverse ( s[i], s[i]+strlen(s[i]) ), rev.addtrie ( s[i], i );
	rev.buildac ();
	
//	cerr << "fw:" << endl;
//	fw.debug ();
//	cerr << "rev:" << endl;
//	rev.debug ();
	
	lpi ( i, 0, fw.kc ){
		lpi ( j, 0, rev.kc ){
			if ( issuffix ( fw.s[i], rev.s[j], fw.len[i], rev.len[j] ) ) cto[i][++kt[i]] = j;
		}
	}
	
//	cerr << "cto:" << endl;
//	lpi ( i, 0, fw.kc ){
//		cerr << i << ": ";
//		lpi ( j, 1, kt[i] ) cerr << cto[i][j] << " ";
//		cerr << endl;
//	}
//	
//	cerr << "dp:" << endl;
	int t, rs, ms = ( 1 << n );
	dp[0][0][0][0] = 1;
	lpi ( i, 1, m ){
		t = i & 1;
		lp ( st, 0, ms ){
			lpi ( j, 0, fw.kc ){
				lpi ( k, 1, kt[j] ){
					dp[t][st][j][cto[j][k]] = 0;
				}
			}
		}
		lp ( st, 0, ms ){
			lpi ( j, 0, fw.kc ){
				lpi ( k, 1, kt[j] ){
					rs = cto[j][k];
					if ( dp[t^1][st][j][rs] ){
//						cerr << i << " " << st << " " << j << " " << rs << " " << fw.ch[j][0] << " " << rev.ch[rs][1] << " " << ( st|fw.sta[fw.ch[j][0]]|rev.sta[rev.ch[rs][1]] ) << endl;
						addv ( dp[t][st|fw.sta[fw.ch[j][0]]|rev.sta[rev.ch[rs][1]]][fw.ch[j][0]][rev.ch[rs][1]], dp[t^1][st][j][rs] );
						addv ( dp[t][st|fw.sta[fw.ch[j][1]]|rev.sta[rev.ch[rs][0]]][fw.ch[j][1]][rev.ch[rs][0]], dp[t^1][st][j][rs] );
					}
				}
			}
		}
//		lp ( st, 0, ms ){
//			lpi ( j, 0, fw.kc ){
////				cerr << "-" << i << " " << st << " " << j << " " << fw.kc << endl;
//				lpi ( k, 1, kt[j] ){
////					cerr << i << " " << st << " " << j << " " << cto[j][k] << endl;
//					if ( dp[t][st][j][cto[j][k]] ) cerr << i << " " << st << " " << j << " " << cto[j][k] << " : " << dp[t][st][j][cto[j][k]] << endl;
//				}
//			}
//		}
	}
	
	int ns, ans = 0;
	lpi ( i, 0, fw.kc ){
		lpi ( j, 0, rev.kc ){
			ns = getsta ( i, j );
//			cerr << i << " " << j << " " << ns << endl;
			rs = ( ms - 1 ) ^ ns;
			for ( int st = ns; ; st = ( st - 1 ) & ns ){
				addv ( ans, dp[m&1][st|rs][i][j] );
//				if ( dp[m&1][st|rs][i][j] ) cerr << "add : " << ( st | rs ) << " " << i << " " << j << " " << ns << " : " << dp[m&1][st|rs][i][j] << endl;
				if ( !st ) break;
			}
		}
	}
	
//	int ans = 0;
//	lp ( st, 0, ms ){
//		lpi ( i, 0, fw.kc ){
//			lpi ( j, 0, rev.kc ){
//				if ( ( st | getsta ( i, j ) ) == ( ms - 1 ) ) addv ( ans, dp[m&1][st][i][j] );
//			}
//		}
//	}
	
	printf ( "%d\n", ans );
}



bool issuffix ( int s[], int t[], int ns, int nt )
{
	int mini = qmin ( ns, nt );
	lpi ( i, 1, mini ){
		if ( s[ns-i] == t[nt-i] ){
			return false;
		}
	}
	return true;
}

int getsta ( int vf, int vr )
{
	int now = vf, len = rev.len[vr];
	int *cs = rev.s[vr];
	int ans = fw.sta[now];
	lpdi ( i, len-1, 0 ){
		now = fw.ch[now][cs[i]];
		ans |= fw.sta[now];
	}
	return ans;
}
