# include <bits/stdc++.h>
# define 	K 		50
# define 	N 		100010
# define 	M 		200010
# define 	P 		998244353
# define 	ll 		long long
using namespace std;
struct node{
	int data,next;
}e[M];
int n,m,k,f[N][K],mp[K][K],u,v,tag[N],q[N],head[N],place,len[N],g[2010][2010],la[N];
int read(){
	int tmp=0, fh=1; char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') fh=-1; ch=getchar();}
	while (ch>='0'&&ch<='9'){tmp=tmp*10+ch-'0'; ch=getchar();}
	return tmp*fh;
}
int mypow(ll x, int y){
	ll i=x; x=1;
	while (y>0){
		if (y%2==1) x=x*i%P;
		i=i*i%P;
		y/=2;
	}
	return x;
}
void build(int u, int v){
	e[++place].data=v; e[place].next=head[u]; head[u]=place;
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read(); m=read(); k=read();
	mp[0][0]=1;
	for (int i=1; i<=k; i++)
		for (int j=0; j<=i; j++)
			mp[i][j]=(mp[i-1][j-1]+mp[i-1][j])%P;
	for (int i=1; i<=m; i++){
		u=read(); v=read();
		build(u,v);
		tag[v]++;
	}
	for (int i=1; i<=n; i++) la[i]=tag[i];
	if (n>2000){
	f[1][0]=1; for (int i=1; i<=k; i++) f[1][i]=0;
	int pl=1, pr=1; q[1]=1;
	while (pl<=pr){
		int x=q[pl++];
		for (int ed=head[x]; ed!=0; ed=e[ed].next){
			tag[e[ed].data]--;
			if (tag[e[ed].data]==0) q[++pr]=e[ed].data;
			for (int j=0; j<=k; j++){
				for (int t=0; t<=j; t++)
					f[e[ed].data][j]=(f[e[ed].data][j]+(long long)(mp[j][t])*(long long)f[x][t]%P)%P;
			}
		}
	}
	for (int i=1; i<=n; i++)
		printf("%d\n",f[i][k]);
	}
	else {
		g[1][0]=1;
		int pl=1, pr=1; q[1]=1;
		for (int i=1; i<=n; i++) tag[i]=la[i];
		while (pl<=pr){
			int x=q[pl++];
			for (int ed=head[x]; ed!=0; ed=e[ed].next){
				tag[e[ed].data]--;
				if (tag[e[ed].data]==0) q[++pr]=e[ed].data;
				for (int i=1; i<=n; i++) g[e[ed].data][i]=(g[e[ed].data][i]+g[x][i-1])%P;
			}
		}
		for (int i=0; i<=n; i++) len[i]=mypow(i,k);
		for (int i=1; i<=n; i++){
			long long ans=0;
			for (int j=0; j<=n; j++)
				ans=((long long)(g[i][j])*(long long)(len[j])+ans)%P;
			printf("%lld\n",ans);
		}
	}
	return 0;
}

