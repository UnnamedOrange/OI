//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<queue>
#include<cmath>
const int N=1007;
typedef long long LL;
using namespace std;
int T,n,p,q,X[N],Y[N],Z[N],A[N],B[N],C[N],D[N],E[N],F[N],lim[N][3];
LL ans,ansnow,W,w[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') f=-1,ch=getchar();
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
#endif
	read(T);
	while(T--) {
		read(n); read(W); read(p); read(q);
		ans=ansnow=1e18;
		for(int i=1;i<=p;i++) {
			read(X[i]); read(Y[i]); read(Z[i]);
			read(A[i]); read(B[i]); read(C[i]);
			read(D[i]); read(E[i]); read(F[i]);
		}
		for(int i=1;i<=1;i++) for(int j=0;j<3;j++) read(lim[i][j]);
		int nn=(1<<n);
		for(int i=0;i<nn;i++) {
			ansnow=0;
			for(int j=0;j<n;j++) {
				if(i&(1<<j)) w[j+1]=W;
				else w[j+1]=-W;
				ansnow+=w[j+1];
			}
			int fl=1;
			for(int j=1;j<=q;j++) {
				int x=lim[j][0],y=lim[j][1],r=lim[j][2];
				if((r==0&&w[x]>w[y])||(r==1&&(w[x]!=w[y]))||(r==2&&(w[x]>=w[y]))) {
					fl=0; break;
				}
			}
			if(!fl) continue;
			for(int j=1;j<=p;j++) {
				int a=A[j],b=B[j],c=C[j],x=X[j],y=Y[j],z=Z[j],d=D[j],e=E[j],f=F[j];
				ansnow+=a*abs(w[x]-w[y])+b*abs(w[y]-w[z])+c*abs(w[x]-w[z])
					  +d*(w[x]-w[y])+e*(w[y]-w[z])+f*(w[z]-w[x]);
			}
			ans=min(ans,ansnow);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
