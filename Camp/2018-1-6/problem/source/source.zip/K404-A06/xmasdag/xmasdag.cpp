#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

const int mod = 998244353;

int fpow(int a, int x) {
	int res = 1;
	for(; x; x >>= 1) {
		if(x&1) res = 1ll*res*a%mod;
		a = 1ll*a*a%mod;
	}
	return res;
}

int inv(int x) { return fpow(x, mod-2); }

int inc(int a, int b) { return a+b >= mod ? a+b-mod : a+b; }

int dec(int a, int b) { return a-b < 0 ? a-b+mod : a-b; }

int f[2][100010], n, m;

int deg[100010], num[100010];

struct edge { int to; edge *next; } e[200010], *et = e, *last[100010];

void add(int u, int v) { *++et = (edge) {v, last[u]}, last[u] = et; deg[v]++; }

void dp(int k) {
	int i = k&1;
	static int q[100010]; int l = 0, r = 0;
	for(int j = 1; j <= n; ++j) num[j] = deg[j], f[i][j] = 0;
	for(int j = 1; j <= n; ++j)
		if(!num[j]) q[r++] = j;
	while(l < r) {
		int u = q[l++];
		for(edge *it = last[u]; it; it = it->next) {
			num[it->to]--;
			f[i][it->to] = inc(f[i][it->to], f[i^1][u]);
			if(!num[it->to])
				q[r++] = it->to;
		}
	}
}

int ans[100010], k;

int g[510][100010], C[510][510];

void dp2(int k) {
	static int q[100010]; int l = 0, r = 0;
	for(int j = 1; j <= n; ++j) num[j] = deg[j];
	for(int j = 1; j <= n; ++j)
		if(!num[j]) q[r++] = j;
	while(l < r) {
		int u = q[l++];
		int x = 0;
		for(int i = 0; i <= k; ++i)
			x = inc(x, 1ll*g[i][u]*C[k][i]%mod);
		for(edge *it = last[u]; it; it = it->next) {
			num[it->to]--;
			g[k][it->to] = inc(g[k][it->to], x);
			if(!num[it->to])
				q[r++] = it->to;
		}
	}
}

int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	C[0][0] = 1;
	for(int i = 1; i <= k; ++i) {
		C[i][0] = 1;
		for(int j = 1; j <= i; ++j)
			C[i][j] = inc(C[i-1][j], C[i-1][j-1]);
	}
	for(int i = 1; i <= m; ++i) {
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v);
	}
	if(n <= 2000 && k) {
		f[0][1] = 1;
		for(int l = 1; l <= n; ++l) { 
			dp(l); 
			for(int i = 1; i <= n; ++i)
				ans[i] = inc(ans[i], 1ll*f[l&1][i]*fpow(l, k)%mod);
		}
		for(int i = 1; i <= n; ++i)
			printf("%d\n", ans[i]);
	} else {
		g[0][1] = 1;
		for(int i = 0; i <= k; ++i) dp2(i);
		for(int i = 1; i <= n; ++i) printf("%d\n", g[k][i]);
	}
	return 0;
}
