#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
int n,m,k,ans=-1,flag=0;
int a[4010],b[4010],q[20];
int na[4010][4010],nb[4010][4010];
void solve(int x,int y,int now){
	if (ans!=-1 && now+1>=ans) return;
	for (int i=1;i<=k;++i){
		if (!na[x][i] && (!nb[y][i] || y==m)){
			if (ans==-1 || ans>now+1)
				ans=now+1; 
			return;		
		}
		if (na[x][i] && (nb[y][i] || y==m))
			solve(na[x][i],nb[y][i],now+1);
		else if (na[x][i] && !(nb[y][i] || y==m))
			solve(na[x][i],y,now+1);
		else if (!na[x][i] && nb[y][i])
			solve(x,nb[y][i],now+1);
	}	
}
void check(){
	int u=0,v=0;
	for (int i=1;i<=ans;++i){
		if (!na[u][q[i]] && !nb[v][q[i]]){
			flag=1;
			return;	
		}
		if (na[u][q[i]]) u=na[u][q[i]];
		if (nb[v][q[i]]) v=nb[v][q[i]];
	}
}
void work(int x){
	if (x>ans){
		check();
		return;	
	} 
	if (flag) return;
	q[x]=1;
	work(x+1);
	q[x]=2;
	work(x+1);
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	n=read();m=read();k=read();
	for (int i=1;i<=n;++i) a[i]=read();
	for (int i=1;i<=m;++i) b[i]=read();
	if (k==1){
		ans=n>m?(n+1):
		(m+1);
		printf("%d\n",ans);
		return 0;
	}
	if (n<=18 && m<=18 && k==2){
		ans=1;
		for (int i=0;i<n;++i)
			for (int j=i+1;j<=n;++j)
				if (na[i][a[j]]==0)
					na[i][a[j]]=j;
		for (int i=0;i<m;++i)
			for (int j=i+1;j<=m;++j)
				if (nb[i][b[j]]==0)
					nb[i][b[j]]=j;
		while (1){
			work(1);
			if (flag) break;
			ans++;
		}
		printf("%d\n",ans);
		return 0;
	}
	if (n<m){
		int t=n;n=m;m=t;	
	}
	for (int i=0;i<n;++i)
		for (int j=i+1;j<=n;++j)
			if (na[i][a[j]]==0)
				na[i][a[j]]=j;
	for (int i=0;i<m;++i)
		for (int j=i+1;j<=m;++j)
			if (nb[i][b[j]]==0)
				nb[i][b[j]]=j;
	for (int i=1;i<=k;++i)
		nb[m][i]=m;
	solve(0,0,0);
	printf("%d\n",ans);
	return 0;
}


