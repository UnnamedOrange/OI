#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const int mod=1e9+7;
const int maxn=1e6+5;
int n,f[maxn],g[maxn],ci[maxn],di[maxn];
inline void read(int &now)
{
	char Cget;
	now=0;
	while(!isdigit(Cget=getchar()));
	while(isdigit(Cget))
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++)
	{
		read(ci[i]);
		read(di[i]);
	}
	f[0]=1;
	g[0]=1;
	for(int i=1;i<=n;i++)
	{
		ll tmpf=0,tmpg=0;
		for(int v=i,len=1,C=ci[i],D=di[i];v>=1;v--,len++)
		{
			if(ci[v]>C)
				C=ci[v];
			if(di[v]<D)
				D=di[v];
			if(len>=C&&len<=D)
			{
				if(f[v-1]>tmpf)
				{
					tmpf=f[v-1];
					tmpg=g[v-1];
				}
				else if(f[v-1]==tmpf)
					(tmpg+=g[v-1])%=mod;
			}
		}
		if(tmpf)
		{
			f[i]=tmpf+1;
			g[i]=tmpg;
		}
	}
	if(!f[n])
		puts("-1");
	else
		std::cout<<f[n]-1<<' '<<g[n];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
