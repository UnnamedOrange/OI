#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
long long Mod=998244353;
int n,a[100010],p[100010],b[100010],cnt;
long long ans,inv[100010];
bool vis[100010],used[100010];
long long pw(long long x,long long y)
{
	long long res=1;
	while (y)
	{
		if (y&1)
		{
			res=res*x%Mod;
		}
		x=x*x%Mod;
		y>>=1;
	}
	return res;
}
bool dfs(int x,int k)
{
	if (vis[x])
	{
		if (k&1)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	vis[x]=true;
	if (!p[x])
	{
		return true;
	}
	return dfs(p[x],k+1);
}
bool check()
{
	memset(vis,false,sizeof(vis));
	for (int i=1;i<=n;i++)
	{
		if (!vis[i] && p[i])
		{
			if (!dfs(i,0))
			{
				return false;
			}
		}
	}
	return true;
}
void solve()
{
	ans=1;
	for (int i=3;i<=n;i+=2)
	{
		ans=(ans*i%Mod)*i%Mod;
		//cout<<i<<" "<<ans<<endl;
	}
}
void solve2()
{
	for (int i=1;i<=n;i++)
	{
		p[i]=i;
	}
	do
	{
		bool f=true;
		for (int i=1;i<=n;i++)
		{
			if (a[i] && a[i]!=p[i])
			{
				f=false;
				break;
			}
		}
		if (!f)
		{
			continue;
		}
		if (check())
		{
			ans++;
			/*
			for (int i=1;i<=n;i++)
			{
				cout<<p[i]<<" ";
			}
			cout<<endl;
			*/
		}
	}while (next_permutation(p+1,p+n+1));
	printf("%lld\n",ans);
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	if (n&1)
	{
		puts("0");
		return 0;
	}
	bool flag=true;
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		if (a[i])
		{
			flag=false;
			cnt++;
			b[cnt]=i;
		}
		p[i]=a[i];
	}
	if (flag)
	{
		solve();
		printf("%lld\n",ans);
		return 0;
	}
	if (!check())
	{
		puts("0");
		return 0;
	}
	if (n<=8)
	{
		solve2();
		return 0;
	}
	for (int i=1;i<=n;i++)
	{
		inv[i]=pw(i,Mod-2);
	}
	solve();
	bool o=true;
	for (int i=1;i<=cnt;i++)
	{
		int now=n-i+1;
		if (!used[b[i]])
		{
			now--;
		}
		//cout<<ans<<" "<<now<<endl;
		if (o && (now&1))
		{
			ans=ans*inv[now]%Mod;
		}
		else if (!o && !(now&1))
		{
			ans=ans*inv[now]%Mod;
			o=true;
		}
		else if (o)
		{
			if (a[b[i]]<b[i])
			{
				ans=ans*inv[now+1];
			}
			else
			{
				ans=((ans*inv[now+1]%Mod)*inv[now-1]%Mod)*now%Mod;
				o=false;
			}
		}
		else
		{
			ans=ans*inv[now]%Mod;
		}
		used[a[b[i]]]=true;
	}
	printf("%lld\n",ans);
	return 0;
}
/*
10
0 0 0 0 0 0 0 0 0 0
*/
