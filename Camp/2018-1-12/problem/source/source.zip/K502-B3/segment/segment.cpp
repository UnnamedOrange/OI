#include <stdio.h>
using namespace std;

#define ll long long int

const int mod=998244353;
ll n,m,k;

inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=read(),m=read(),k=read();
	if(n==1)
	{
		ll i,j,ans=0;
		for(i=1;i<=m;i++)
			ans=(ans+((m-i)*(m-i+1))/2)%mod;
		printf("%lld",ans%mod);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

