#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std; 
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}
const int maxn=10001;

int n;

double T[maxn],so[maxn];

double ans;

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	read(n);double nouf;
	for(int i=1;i<=n;i++) scanf("%lf",&T[i]);
	for(int l=1;l<=n;++l)
		for(int r=l;r<=n;++r){
			nouf=0;
			for(int i=l;i<=r;i++) so[i]=T[i];
			sort(so+l,so+r+1);
			for(int i=l;i<=r;i++) nouf=(nouf+so[i])/2;
			ans+=nouf;
		}
	printf("%lf\n",ans/(n*n));
	return 0;
}
