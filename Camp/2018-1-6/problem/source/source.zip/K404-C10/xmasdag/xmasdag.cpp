#include <cstdio>
#include <queue>
using namespace std;
#define Mod 998244353
#define N 100050
int n,m,k,id,in[N],v[N<<1],nxt[N<<1],hd[N],i,c[505][505],f[2005][2005],g[N][505],pw[N],j,ans[N];
queue<int> q;
inline int qmi(int di,int zhi)
{
	int ret=1,x=di;
	while (zhi){
		if (zhi&1) ret=1LL*ret*x%Mod;x=1LL*x*x%Mod;zhi>>=1;
	}return ret;
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	while (m--){
		int x,y;scanf("%d%d",&x,&y);in[y]++;
		int psz=++id;v[psz]=y;nxt[psz]=hd[x];hd[x]=psz;
	}for (i=1;i<=n;i++) if (!in[i]) q.push(i);
	for (i=0;i<=n;i++) pw[i]=qmi(i,k);
	c[0][0]=1;
	for (i=1;i<=500;i++)
	for (j=0;j<=i;j++) if (j==0||j==i) c[i][j]=1;else c[i][j]=(c[i-1][j]+c[i-1][j-1])%Mod;
	if (n<=2000){
		f[1][0]=1;
		while (!q.empty()){
			int psz=q.front();q.pop();
			for (int gh=hd[psz];gh;gh=nxt[gh]){
				for (i=1;i<=n;i++) f[v[gh]][i]=(f[v[gh]][i]+f[psz][i-1])%Mod;
				if (--in[v[gh]]==0) q.push(v[gh]);
			}
		}
		for (i=1;i<=n;i++)
		for (j=0;j<=n;j++) ans[i]=(1LL*pw[j]*f[i][j]+ans[i])%Mod;
		for (i=1;i<=n;i++) printf("%d\n",ans[i]);
		return 0;
	}g[1][0]=1;
	while (!q.empty()){
		int psz=q.front();q.pop();
		for (int gh=hd[psz];gh;gh=nxt[gh]){
			for (i=0;i<=k;i++)
			for (j=0;j<=i;j++) g[v[gh]][i]=(1LL*c[i][j]*g[psz][j]+g[v[gh]][i])%Mod;
			if (--in[v[gh]]==0) q.push(v[gh]);
		}
	}for (i=1;i<=n;i++) printf("%d\n",g[i][k]);
	return 0;
}
