//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
const int maxn=1e6+7;
int n,m,totans;

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

int fir[maxn],nxt[maxn],to[maxn],e=0;
void add(int x,int y) {
	to[++e]=y; nxt[e]=fir[x]; fir[x]=e;
}

int ff[maxn],nn[maxn],tt[maxn],ind[maxn],ee=0;
void add2(int x,int y) {
	tt[++ee]=y; nn[ee]=ff[x]; ff[x]=ee; ++ind[y];
}

bool vis[maxn],g[maxn];
int id[maxn],bel[maxn],sum[maxn],zz[maxn],top[maxn],t,toth;
void dfs(int pos) {
	vis[pos]=1; g[pos]=1; 
	zz[++t]=pos; id[pos]=top[pos]=t;
	int y,z;
	for(y=fir[pos];y;y=nxt[y]) {
		z=to[y];
		if(vis[z]) {
			if(g[z]) top[pos]=min(top[pos],top[z]);
			continue;
		}
		dfs(z); 
		top[pos]=min(top[pos],top[z]);
	}
	if(top[pos]==id[pos]) {
		sum[++toth]=1;
		bel[pos]=toth; g[pos]=0;
		while(t&&zz[t]!=pos) {
			bel[zz[t]]=toth;
			++sum[toth];
			g[zz[t--]]=0;
		}
		t--;
	}
}

int ans[maxn];
void get_tp() {
	int s=1,t=0,x,y,z;
	for(int i=1;i<=toth;++i) if(!ind[i]) zz[++t]=i;
	while(s<=t) {
		x=zz[s++];
		totans=max(totans,ans[x]+=sum[x]);
		for(y=ff[x];y;y=nn[y]) {
			z=tt[y];
			ans[z]=max(ans[z],ans[x]);
			if(!(--ind[z])) zz[++t]=z;
		}
	}
}

int main() {
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read(); m=read();
	int x,y,z;
	for(int i=1;i<=m;++i) {
		x=read(); y=read();
		add(x,y);
	}
	for(int i=1;i<=n;++i) if(!vis[i]) {
		t=0; dfs(i);
	}
	for(int i=1;i<=n;++i) {
		for(y=fir[i];y;y=nxt[y]) 
			if(bel[z=to[y]]!=bel[i]) add2(bel[i],bel[z]);
	}
	get_tp();
	printf("%d",totans);
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
5 4
1 2
2 3
3 1
4 5
*/
