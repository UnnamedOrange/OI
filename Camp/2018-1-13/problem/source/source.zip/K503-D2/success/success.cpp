#include<bits/stdc++.h>
using namespace std;
int m,n,s,t,f[6010][6010]={0},ansn=0;
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d %d %d %d",&s,&t,&n,&m);
	f[0][0]=1;
	for (int i=1;i<=m;i++){
		if (i<=n){
			for (int j=1;j<=t;j++){
				for (int k=j;k<=s;k++){
					f[i][k]+=f[i-1][k-j];
				}
			}
		}else{
			for (int j=1;j<=s;j++){
				for (int k=j;k<=s;k++){
					f[i][k]+=f[i-1][k-j];
				}
			}
		}
	}
	for (int i=1;i<=s;i++) ansn+=f[m][i];
	cout<<ansn<<endl;
}
