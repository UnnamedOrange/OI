#include<cstdio>
#include<iostream>
using namespace std;
const int mod=998244353;
inline int min(int a,int b){
	return a<b?a:b;
}
inline int max(int a,int b){
	return a>b?a:b;
}
int a[66666],b[66666];
int K_mi[666666];
int n,m,k,ans;
inline int fp(int a,int b){
	int ret=1;
	while(b){
		if(b&1)ret=1ll*a*ret%mod;
		a=1ll*a*a%mod;
		b>>=1;
	}
	return ret;
}
inline void dfs(int now,int l,int r){
	if(l>r||l>m||r>m)return;
	if(now==n){
		b[0]=0;
		for(register int i=1;i<=m;++i)
			b[i]=b[i-1]+a[i];
		for(register int i=1;i<=m;++i){
			ans+=K_mi[b[i]];
			ans%=mod;
		}
		return ;
	}
	for(register int i=l+1;i<=m;++i)
		for(register int j=max(r+1,i);j<=m;++j){
			++a[i];--a[j];
			dfs(now+1,i,j);
			--a[i];++a[j];
	}
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	n=min(n,m-n);
	k%=(mod-1);
	for(register int i=1;i<=n;++i)
		K_mi[i]=fp(i,k);
	for(register int i=1;i<=m;++i)
		for(register int j=i;j<=m;++j){
			++a[i];--a[j];
			dfs(1,i,j);
			--a[i];++a[j];
		}
	printf("%d\n",ans);
	return 0;
}
/*
1 4 998244353
*/
