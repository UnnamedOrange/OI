#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<string>
#include<cassert>
#include<ctime>
#include<map>
#include<set>
#include<cmath>
#include<cstring>
using namespace std;
namespace whatever{
	char buffer[80000000];
	int buffer_pos=-1;
	#undef getchar
	#define getchar() buffer[++buffer_pos]
	int readu(){
		char ch=getchar();
		while(ch<'0'||ch>'9')
			ch=getchar();
		int value=ch-'0';
		ch=getchar();
		while(ch>='0'&&ch<='9'){
			value=value*10+ch-'0';
			ch=getchar();
		}
		return value;
	}
	char readc(){
		char ch=getchar();
		while(ch==' '||ch=='\n')
			ch=getchar();
		return ch;
	}
	struct edge_type{
		int to,next;
	};
	edge_type edges[1100000];
	int edge_cnt=0;
	int first[1100000];
	inline void add_edge(int from, int to){
		edges[edge_cnt].to=to;
		edges[edge_cnt].next=first[from];
		first[from]=edge_cnt;
		++edge_cnt;
	}
	struct type{
		int index,low,comp,root,size;
		bool pushed;
	};
	type a[1100000];
	int stack[1100000];
	int top=0;
	int comp_cnt;
	int cur_time;
	void tarjan(int cur){
		a[cur].index=a[cur].low=cur_time;
		++cur_time;
		stack[top]=cur;
		++top;
		a[cur].pushed=true;
		for(int e=first[cur];e!=-1;e=edges[e].next){
			int to=edges[e].to;
			if(a[to].pushed){
				if(a[cur].low>a[to].index)
					a[cur].low=a[to].index;
			}
			else if(a[to].index==-1){
				tarjan(to);
				if(a[cur].low>a[to].low)
					a[cur].low=a[to].low;
			}
		}
		if(a[cur].index==a[cur].low){
			int comp_size=0;
			do{
				++comp_size;
				--top;
				int stack_top=stack[top];
				a[stack_top].root=cur;
				a[stack_top].pushed=false;
				a[stack_top].comp=comp_cnt;
			}while(stack[top]!=cur);
			a[cur].size=comp_size;
			++comp_cnt;
		}
	}
	#if 0
	int index[1100000],low[1100000],comp[1100000];
	int stack[1100000];
	bool pushed[1100000];
	int root[1100000];
	int size[1100000];
	int top=0;
	int comp_cnt;
	int cur_time;
	void tarjan(int cur){
		index[cur]=cur_time;
		low[cur]=cur_time;
		++cur_time;
		stack[top]=cur;
		++top;
		pushed[cur]=true;
		for(int e=first[cur];e!=-1;e=edges[e].next)
			if(pushed[edges[e].to]){
				if(low[cur]>index[edges[e].to])
					low[cur]=index[edges[e].to];
			}
			else if(index[edges[e].to]==-1){
				tarjan(edges[e].to);
				if(low[cur]>low[edges[e].to])
					low[cur]=low[edges[e].to];
			}
		if(index[cur]==low[cur]){
			int comp_size=0;
			do{
				++comp_size;
				--top;
				root[stack[top]]=cur;
				pushed[stack[top]]=false;
				comp[stack[top]]=comp_cnt;
			}while(stack[top]!=cur);
			size[cur]=comp_size;
			++comp_cnt;
		}
	}
	#endif
	edge_type contracted_edges[1100000];
	int contracted_edge_cnt=0;
	int contracted_first[1100000];
	inline void add_contracted_edge(int from, int to){
		contracted_edges[contracted_edge_cnt].to=to;
		contracted_edges[contracted_edge_cnt].next=contracted_first[from];
		contracted_first[from]=contracted_edge_cnt;
		++contracted_edge_cnt;
	}
	void contract(int cur){
		for(int e=first[cur];e!=-1;e=edges[e].next)
			if(a[edges[e].to].comp!=a[cur].comp){
	//			assert(root[cur]!=root[edges[e].to]);
				add_contracted_edge(a[cur].root,a[edges[e].to].root);
			}
	//		else
	//			assert(root[cur]==root[edges[e].to]);
	}
	int length[1100000];
	void dfs(int cur){
	//	assert(root[cur]==cur);
		if(length[cur]!=-1)
			return;
		length[cur]=0;
		for(int e=contracted_first[cur];e!=-1;e=contracted_edges[e].next){
			int to=contracted_edges[e].to;
	//		assert(to!=cur);
	//		assert(root[to]==to);
	//		assert(root[to]!=root[cur]);
	//		assert(comp[to]!=comp[cur]);
	//		if(length[to]==-1)
			dfs(to);
			if(length[cur]<length[to])
				length[cur]=length[to];
		//	length[cur]=max(length[cur],length[to]);
		}
		length[cur]+=a[cur].size;
	}
	void run(){
		freopen("bomb.in","r",stdin);
		freopen("bomb.out","w",stdout);
		fread(buffer,1,sizeof(buffer),stdin);
		int n,m;
		n=readu();
		m=readu();
		memset(first,-1,sizeof(first));
	//	cout<<__LINE__<<endl;
		for(int i=0;i<m;++i){
	//	cout<<__LINE__<<endl;
			int from,to;
			from=readu();
			to=readu();
			add_edge(from,to);
	//	cout<<__LINE__<<endl;
		}
	//	cout<<__LINE__<<endl;
	#if 0
		memset(index,-1,sizeof(index));
		memset(low,-1,sizeof(low));
		memset(root,-1,sizeof(root));
		memset(size,-1,sizeof(size));
		memset(comp,-1,sizeof(comp));
	#endif
	//cout<<clock()/(double)CLOCKS_PER_SEC<<endl;
	for(int i=0;i<1100000;++i){
		a[i].index=a[i].low=a[i].root=a[i].size=a[i].comp=-1;
	}
	//	cout<<__LINE__<<endl;
	//	cout<<__LINE__<<endl;
	//cout<<clock()/(double)CLOCKS_PER_SEC<<endl;
		for(int i=1;i<=n;++i){
			if(a[i].index==-1)
				tarjan(i);
	//		assert(top==0);
		}
	//cout<<clock()/(double)CLOCKS_PER_SEC<<endl;
	//	cout<<__LINE__<<endl;
	//	assert(cur_time==n);
	//	for(int i=1;i<=n;++i){
	//		assert(index[i]!=-1);
	//		assert(low[i]!=-1);
	//		assert(root[i]!=-1);
	//		assert(!pushed[i]);
	//		assert(comp[i]!=-1);
	//		if(root[i]==i){
	//			assert(size[i]>0);
	//			assert(index[i]==low[i]);
	//		}
	//		else{
	//			assert(size[i]==-1);
	//			assert(low[i]<index[i]);
	//		}
	//	}
		memset(contracted_first,-1,sizeof(contracted_first));
		for(int i=1;i<=n;++i)
			contract(i);
	//cout<<clock()/(double)CLOCKS_PER_SEC<<endl;
		memset(length,-1,sizeof(length));
		for(int i=1;i<=n;++i)
			if(a[i].root==i)
				dfs(i);
//	cout<<clock()/(double)CLOCKS_PER_SEC<<endl;
	//	for(int i=1;i<=n;++i)
	//		if(root[i]==i)
	//			cout<<size[i]<<endl;
		int ans=0;
		for(int i=1;i<=n;++i)
			if(a[i].root==i){
	//			assert(length[i]!=-1);
				if(ans<length[i])
					ans=length[i];
			}
	//		else
	//			assert(length[i]==-1);
		cout<<ans<<endl;
	}
}

int main(){
	whatever::run();
}
