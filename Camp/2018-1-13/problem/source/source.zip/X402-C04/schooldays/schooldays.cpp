#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}


typedef long long ll;
const int N=1000009;
const ll md=1e9+7;

int n,c[N],d[N],rec[N],top;
ll rmx[N],rmn[N],f[N],fans[N];

inline bool chkmax(ll &a,ll b){if(a<b){a=b;return 1;}return 0;}
inline bool chkmin(ll &a,ll b){if(a>b){a=b;return 1;}return 0;}
inline void chk(ll &a){if(a>=md)a-=md;}

int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);

	n=read();
	for(int i=1;i<=n;i++)
	{
		c[i]=read(),d[i]=read();
		f[i]=-1e9;
	}

	f[0]=0;fans[0]=1;
	for(int i=1;i<=n;i++)
	{
		rmx[i]=c[i];rmn[i]=d[i];
		for(int j=i-1;j>=1;j--)
		{
			chkmin((rmn[j]=rmn[j+1]),d[j]);
			chkmax((rmx[j]=rmx[j+1]),c[j]);
		}

		top=0;
		for(int j=0;j<i;j++)
			if(rmx[j+1]<=i-j && i-j<=rmn[j+1])
			{
				if(chkmax(f[i],f[j]+1))
					rec[top=1]=j;
				else if(f[i]==f[j]+1)
					rec[++top]=j;
			}
		
		fans[i]=0;
		for(int j=1;j<=top;j++)
			chk(fans[i]+=fans[rec[j]]);

		//printf("%d:%d %d\n",i,f[i],fans[i]);
	}

	if(f[n]<0)return puts("-1"),0;
	printf("%d %lld\n",f[n],fans[n]);
	return 0;
}
