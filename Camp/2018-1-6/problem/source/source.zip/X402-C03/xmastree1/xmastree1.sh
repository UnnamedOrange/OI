while true
do
./data
./bf
./xmastree1
diff xmastree1.out xmastree1.txt||break
printf "#"
done
