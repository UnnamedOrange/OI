#include <bits/stdc++.h>
#define N 21
using namespace std;
int t,n,m,q[N],x,y,d,h;

template <class Aqua>
inline void read(Aqua &s){
	s=0; char c=getchar();
	while (!isdigit(c)) c=getchar(); // -?
	while (isdigit(c)) s=s*10+c-'0',c=getchar();
}

int main(){
//	freopen("b.out","w",stdout);
	read(t);
	read(n),read(m);
	q[0]=1;
	for (int i=1;i<=10;i++)
		q[i]=q[i-1]<<1;
	for (int i=1;i<=m;i++){
	if (t==1){
		read(x),read(y);
		for (int i=0;i<10;i++){
			if ((q[i]&x)>0 && (q[i]&y)==0){
				printf("%d\n",11+i); break;
			}
			if ((q[i]&y)>0 && (q[i]&x)==0){
				printf("%d\n",1+i); break;
			}
		}
	}
	else{
		read(x),read(y);
		d=y/10; y%=10;
		if (y==0)
			y+=10,d--;
		x&=q[y-1];
		x=(x>0);
		if (x^d)
			puts("no");
		else
			puts("yes");
	}
	}
	return 0;
}
