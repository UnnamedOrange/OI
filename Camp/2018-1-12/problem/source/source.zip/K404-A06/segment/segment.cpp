#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
using namespace std;
const int mod=998244353;
int n,m,k;
int fpow(int a,int x){int v=1;for(;x;x>>=1)x&1?v=1ll*v*a%mod:1,a=1ll*a*a%mod;return v;}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int ans=0;
	scanf("%d%d%d",&n,&m,&k);
	printf("%d\n",ans);
	return 0;
}
