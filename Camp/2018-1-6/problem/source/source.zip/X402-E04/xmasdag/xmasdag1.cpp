#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define Rep(i,u) for(int i=Begin[u],v=to[i];i;i=Next[i],v=to[i])
#define ll long long 
using namespace std;
const int N=2010,INF=0x3f3f3f3f,Mod=998244353;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
inline void file(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag1.out","w",stdout);
}
ll qpow (ll a,ll b){
	ll ret=1;
	for(;b;b>>=1,a=a*a%Mod)if(b&1)ret=ret*a%Mod;
	return ret;
}
int dp[N][N],Begin[N],Next[N*5],to[N*5],e,n,m,k,deg[N];
inline void add(int x,int y){
	to[++e]=y,Next[e]=Begin[x];Begin[x]=e;deg[y]++;
}
void init(){
	read(n),read(m),read(k);
	For(i,1,m){
		int x,y;
		read(x),read(y);
		add(x,y);
	}
}
void solve(){
	queue<int>q;
	q.push(1);dp[1][0]=1;
	while(!q.empty()){
		int u=q.front();q.pop();
		Rep(i,u){
			For(j,1,n)
				dp[v][j]=(dp[v][j]+dp[u][j-1])%Mod;
			if(!(--deg[v]))q.push(v);
		}	
	}
	For(i,1,n){
		int ans=0;
		For(j,1,n)
			ans=(ans+qpow(j,k)*dp[i][j])%Mod;
		printf("%d\n",ans);
	}
}
int main(){
	file();
	init();
	solve();
	return 0;
}
