import sys
from random import *

sys.stdout = open("sequence.in", "w")

print (5)

for i in range(5):
    print (25)

    x = []
    for j in range(25): 
        x.append(j + 1)

    shuffle(x)
    for j in range(25): 
        print (x[j], end = ' ')
    print ()
