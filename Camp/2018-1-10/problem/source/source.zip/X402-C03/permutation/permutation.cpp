#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=1e5+10,mod=998244353;
int n,p[maxn],q[maxn],odd,even;
bool vis[maxn];
ll ans;

int tmp[maxn];
int dfs(int pos,int cnt){
	int res=0;
	if(pos==odd)
		for(int i=1;i<=cnt;++i)
			if(tmp[i]&1)
				return 0;
	if(pos==odd+even)
		return 1;
	++tmp[cnt+1];
	res=dfs(pos+1,cnt+1);
	--tmp[cnt+1];
	for(int i=1;i<=cnt;++i){
		++tmp[i];
		(res+=(tmp[i]-1ll)*dfs(pos+1,cnt))%=mod;
		--tmp[i];
	}
	return res;
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&p[i]),q[p[i]]=i;
	for(int i=1;i<=n;++i)
		if(!vis[i]){
			vis[i]=true;
			int pos,size=1;
			pos=p[i];
			while(pos!=0&&!vis[pos])
				vis[pos]=true,++size,pos=p[pos];
			if(pos==i)
				if(size&1){
					puts("0");
					return 0;
				}
				else
					continue;
			pos=q[i];
			while(pos!=0&&!vis[pos])
				vis[pos]=true,++size,pos=q[pos];
			if(size&1)
				++odd;
			else
				++even;
		}
	if(odd&1){
		puts("0");
		return 0;
	}
	ans=1;
	for(int i=1;i<=odd;i+=2)
		ans=ans*i%mod;
	ans=ans*ans%mod;
	for(int i=1;i<=even;++i)
		ans=ans*(odd+i)%mod;
	if(n<=8)
		printf("%d\n",dfs(0,0));
	else
		printf("%lld\n",ans);
	return 0;
}
