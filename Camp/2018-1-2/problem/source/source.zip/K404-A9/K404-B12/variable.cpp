#include<vector>
#include<string>
#include<algorithm>
#include<cstdio>
#include<ctime>
#include<cmath>
#include<cstdlib>
#include<set>
#include<iostream>
#include<map>
#include<cstring>
#include<cassert>
#include<utility>
using namespace std;
namespace whatever{
	int reads(){
		char ch=getchar();
		while((ch<'0'||ch>'9')&&ch!='-')
			ch=getchar();
		int sign=1;
		if(ch=='-'){
			sign=-1;
			ch=getchar();
		}
		int value=ch-'0';
		ch=getchar();
		while(ch>='0'&&ch<='9'){
			value=value*10+ch-'0';
			ch=getchar();
		}
		return value*sign;
	}
	struct term_type{
		int x,y,z,a,b,c,d,e,f;
	};
	struct cons_type{
		int x,y,type;//0:<= 1:= 2:<
	};
	/*
	struct term_type{
		int x,y,z,a,b,c,d,e,f;
	};*/
	int var_cnt,multiplier,term_cnt,cons_cnt;
	term_type term[1000];
	cons_type cons[1000];
	int must_be[501];//-1:-1 0:no constraint 1:1
	int coeff[501];/*term part two*/
	int mapping[501];
	struct cons_t{
		int x,y;/*w[x]<=w[y]*/
	};
	cons_t con[1000];
	int con_cnt;
	struct term_t{
		int x,y,a;
	};
	term_t tm[3000];
	int tm_cnt;
	int rep[501];
	bool is_super[501];
	int super_cnt;
	int super_list[501];
	int super_id[501];
	int cluster_size[501];
	int find(int x){
		return rep[x]==x?x:(rep[x]=find(rep[x]));
	}
	int find2(int x){
		return super_id[find(x)];
	}
	void transform(){
		for(int i=0;i<cons_cnt;++i){
			if(cons[i].x==cons[i].y)
				continue;
			if(cons[i].type==1){
				rep[find(cons[i].x)]=find(cons[i].y);
				assert(find(cons[i].x)==find(cons[i].y));
			}
		}
		for(int i=1;i<=var_cnt;++i)
			if(find(i)==i){
				assert(is_super[i]==false);
				is_super[i]=true;
				assert(super_list[super_cnt]==0);
				super_list[super_cnt]=i;
				super_id[i]=super_cnt;
				++super_cnt;
			}
		for(int i=1;i<=var_cnt;++i)
			++cluster_size[super_id[find(i)]];
	//	for(int i=0;i<super_cnt;++i)
	//		cout<<cluster_size[i]<<' ';
	//	cout<<endl;
		for(int i=0;i<term_cnt;++i){
			term[i].x=find2(term[i].x);
			term[i].y=find2(term[i].y);
			term[i].z=find2(term[i].z);
		//	cout<<term[i].x<<' '<<term[i].y<<' '<<term[i].z<<endl;
		}
		for(int i=0;i<cons_cnt;++i){
			cons[i].x=find2(cons[i].x);
			cons[i].y=find2(cons[i].y);
		}
		for(int i=0;i<term_cnt;++i){
			coeff[term[i].x]+=term[i].d;
			coeff[term[i].y]-=term[i].d;
			coeff[term[i].y]+=term[i].e;
			coeff[term[i].z]-=term[i].e;
			coeff[term[i].z]+=term[i].f;
			coeff[term[i].x]-=term[i].f;
			
		//	cout<<"tm_cnt: "<<tm_cnt<<endl;
			if(term[i].x!=term[i].y){
				tm[tm_cnt].x=term[i].x;
				tm[tm_cnt].y=term[i].y;
				tm[tm_cnt].a=term[i].a;
				++tm_cnt;
			}
		//	cout<<"tm_cnt: "<<tm_cnt<<endl;
			if(term[i].y!=term[i].z){
				tm[tm_cnt].x=term[i].y;
				tm[tm_cnt].y=term[i].z;
				tm[tm_cnt].a=term[i].b;
				++tm_cnt;
			}
		//	cout<<"tm_cnt: "<<tm_cnt<<endl;
			if(term[i].z!=term[i].x){
				tm[tm_cnt].x=term[i].z;
				tm[tm_cnt].y=term[i].x;
				tm[tm_cnt].a=term[i].c;
				++tm_cnt;
			}
		//	cout<<"tm_cnt: "<<tm_cnt<<endl;
	//		term[i].a=reads();
	//		term[i].b=reads();
	//		term[i].c=reads();
		}
		for(int i=0;i<cons_cnt;++i){
			if(cons[i].x==cons[i].y)
				continue;
			if(cons[i].type==1)
				continue;
			if(cons[i].type==2){
				assert(must_be[cons[i].x]!=1);
				assert(must_be[cons[i].y]!=-1);
				must_be[cons[i].x]=-1;
				must_be[cons[i].y]=1;
				continue;
			}
			assert(cons[i].type==0);
			con[con_cnt].x=cons[i].x;
			con[con_cnt].y=cons[i].y;
			++con_cnt;
		}
	//	cout<<"super mapping: \n";
	//	for(int i=1;i<=var_cnt;++i)
	//		cout<<find2(i)<<' ';
	//	cout<<endl;
	}
	int assignment[501];//1 -1
	int check(){
		for(int i=0;i<super_cnt;++i)
			assert(assignment[i]==1||assignment[i]==-1);
		for(int i=0;i<super_cnt;++i)
			if(must_be[i]!=0&&must_be[i]!=assignment[i])
				assert(0);
		for(int i=0;i<cons_cnt;++i)
			if(assignment[con[i].x]>assignment[con[i].y])
				return 2000000000;
		int coeff_term=0;
		for(int i=0;i<super_cnt;++i)
			coeff_term+=coeff[super_list[i]]*assignment[i];
		int tm_term=0;
	//	cout<<"tm_term: "<<tm_cnt<<" ";
		for(int i=0;i<tm_cnt;++i){
			int diff=assignment[tm[i].x]-assignment[tm[i].y];
			if(diff<0)
				diff=-diff;
			tm_term+=diff*tm[i].a;
		}
		int ass_term=0;
		for(int i=0;i<super_cnt;++i)
			assert(cluster_size[i]>0);
		for(int i=0;i<super_cnt;++i)
			ass_term+=assignment[i]*cluster_size[i];
	//	cout<<"check: \n";
	//	cout<<coeff_term<<' '<<tm_term<<' '<<ass_term<<": ";
	//	for(int i=0;i<super_cnt;++i)
	//		cout<<assignment[i]<<' ';
	//	cout<<endl;
		return coeff_term+tm_term+ass_term;
	}
	int dfs(int cur_super){
	//	cout<<"dfs: "<<cur_super<<endl;
		if(cur_super==super_cnt)
			return check();
		if(must_be[cur_super]!=0){
			assert(assignment[cur_super]==0||assignment[cur_super]==must_be[cur_super]);
			assignment[cur_super]=must_be[cur_super];
			return dfs(cur_super+1);
		}
		assert(assignment[cur_super]==0);
		int result=2000000000;
		assignment[cur_super]=-1;
		int r=dfs(cur_super+1);
		if(result>r)
			result=r;
		assignment[cur_super]=1;
		r=dfs(cur_super+1);
		if(result>r)
			result=r;
		assignment[cur_super]=0;
		return result;
	}
	void solve(){
		memset(term,0,sizeof(term));
		memset(cons,0,sizeof(cons));
		memset(must_be,0,sizeof(must_be));
		memset(coeff,0,sizeof(coeff));
		memset(mapping,0,sizeof(mapping));
		memset(con,0,sizeof(con));
		memset(tm,0,sizeof(tm));
		memset(is_super,0,sizeof(is_super));
		memset(super_list,0,sizeof(super_list));
		memset(assignment,0,sizeof(assignment));
		memset(super_id,-1,sizeof(super_id));
		memset(cluster_size,0,sizeof(cluster_size));
		con_cnt=0;
		tm_cnt=0;
		super_cnt=0;
		for(int i=0;i<501;++i)
			rep[i]=i;
		var_cnt=reads();
		//super_start=500;
		multiplier=reads();
		if(multiplier<0)
			multiplier=-multiplier;
		term_cnt=reads();
		cons_cnt=reads();
		for(int i=0;i<term_cnt;++i){
			term[i].x=reads();
			term[i].y=reads();
			term[i].z=reads();
			term[i].a=reads();
			term[i].b=reads();
			term[i].c=reads();
			term[i].d=reads();
			term[i].e=reads();
			term[i].f=reads();
		}
		for(int i=0;i<cons_cnt;++i){
			cons[i].x=reads();
			cons[i].y=reads();
			cons[i].type=reads();
		}
		transform();
		printf("%d",dfs(0)*multiplier);
	}
	void run(){
		freopen("variable.in","r",stdin);
		freopen("variable.out","w",stdout);
		int t=reads();
		while(--t!=-1)
			solve();
		fclose(stdin);
		fclose(stdout);
	}
}
int main(){
	whatever::run();
}
