#include<bits/stdc++.h>
using namespace std;
int fa[5100],c[5100];
int n,m,t;
vector<int>ed[5100];
bool app[5100];
int cnt=0;
int la=0;
void getf(int k) { 
	for(int i=0;i<ed[k].size();++i) { 
		int tar=ed[k][i];
		if(fa[tar]==0) fa[tar]=k,getf(tar);
	} 
} 
void dfs(int k,int l,int r) { 
	if(app[c[k]]==0&&c[k]>=l&&c[k]<=r) app[c[k]]=1,cnt++;
	for(int i=0;i<ed[k].size();++i) { 
		int tar=ed[k][i];
		if(tar==fa[k]) continue;
		dfs(tar,l,r);
	} 
} 
int main() { 
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int rot=1,a,b;
	scanf("%d%d%d",&n,&m,&t);
	for(int i=1;i<=n;++i) scanf("%d",&c[i]);
	for(int i=1;i<n;++i) { 
		scanf("%d%d",&a,&b);
		ed[a].push_back(b),ed[b].push_back(a);
	} 
	fa[1]=-1;
	getf(1);
	int mark,u,l,r;
	for(int i=0;i<m;++i) {
		scanf("%d",&mark);
		if(mark==1) {
			scanf("%d%d%d",&u,&l,&r),
			cnt=0,memset(app,0,sizeof(app));
			u^=la,l^=la,r^=la;
			dfs(u,l,r);
			int na=cnt;
			if(t==1) la=na;
			printf("%d\n",na);
		}
		if(mark==2) {
			scanf("%d%d",&u,&l);
			u^=la,l^=la;
			c[u]=l;
		}
	}
	return 0;
} 
