//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const lovelive mod=1e9+7;
void read(lovelive &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
lovelive jc[1000010],rev[1000010];
lovelive pow1(lovelive x,lovelive k)
{
  lovelive r=1;
  while(k)
  {
  	if(k&1)
  	  r*=x;
  	x*=x;
  	r%=mod;
  	x%=mod;
  	k>>=1;
  }
  return r;
}
lovelive calc(lovelive n,lovelive m)
{
  if(n<m)
    return 0;
  return ((jc[n]*rev[m]%mod)*rev[n-m])%mod;
}
int main()
{
  freopen("success.in","r",stdin);
  freopen("success.out","w",stdout);
  lovelive s,t,n,m,ans=0,tmp;
  read(s);read(t);read(n);read(m);
  jc[0]=rev[0]=1;
  for(lovelive i=1;i<=s;i++)
    jc[i]=jc[i-1]*i%mod;
  rev[s]=pow1(jc[s],mod-2);
  for(int lovelive i=s;i>=1;i--)
    rev[i-1]=rev[i]*i%mod;
  for(lovelive i=0;i<=n&&i*t<=s;i++)
  {
    tmp=calc(n,i)*calc(s-i*t,m)%mod;
    if(i&1)
      ans+=mod-tmp;
    else
      ans+=tmp;
    ans%=mod;
  }
  cout<<ans<<"\n";
  return 0;
}
/*
6 2 3 4
*/
