#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#define ll long long
using namespace std;
int read()
{
	char ch=getchar();int x=0,f=1;
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
struct node
{
	int from;
	int to;
	int next;
}edge[500005];
int tot,head[100005];
int n,a[100005],w[100005],r[100005],pos[100005];
int fa[15],ans;
bool vis[15];
void add(int u,int v)
{
	edge[tot].from=u;
	edge[tot].to=v;
	edge[tot].next=head[u];
	head[u]=tot++;
}
void dfs(int x)
{
	for(int i=head[x];i!=-1;i=edge[i].next)
	{
		if(edge[i].to!=fa[x])
		{
			fa[edge[i].to]=x;
			dfs(edge[i].to);
		}
	}
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.ans","w",stdout);
	memset(head,-1,sizeof(head));
	n=read();
	for(int i=1;i<n;i++)
	{
		int u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	for(int i=1;i<=n;i++)
	{
		w[i]=read(),r[i]=read();
	}
	for(int i=1;i<=n;i++)
	{
		a[i]=i;
	}
	do
	{
		bool ac=1;
		for(int i=1;i<=n;i++)
		{
			if(a[i]==1&&r[i]==0)
			{
				ac=0;
				break;
			}
		}
		if(!ac) continue;
		//cout<<"ok";
		memset(vis,0,sizeof(vis));
		for(int i=1;i<=n;i++)
		{
			pos[a[i]]=i;
		}
		memset(fa,0,sizeof(fa));
		
		dfs(pos[1]);
		//for(int i=1;i<=n;i++)
		//cout<<fa[i]<<" ";
		//cout<<endl;
		vis[pos[1]]=1;
		for(int i=2;i<=n;i++)
		{
			if(!vis[fa[pos[i]]])
			{
				ac=0;
				break;
			}
			vis[pos[i]]=1;
		}
		if(ac)
		{
			int temp=0;
			for(int i=1;i<=n;i++)
			{
				temp+=w[i]*a[i];
			}
			ans=max(ans,temp);
		}
	}while(next_permutation(a+1,a+n+1));
	cout<<ans;
}
