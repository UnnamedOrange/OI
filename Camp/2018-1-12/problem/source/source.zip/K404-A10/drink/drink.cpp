#include <bits/stdc++.h>

struct sectree {
	int left,right,mid;
	int l,r;
	double s,p;
} t[400003];int tn;
int w[100003],x[100003];
bool comp(int a,int b) {
	return w[a] > w[b];
}
void pull(int i) {
	t[i].p = t[t[i].l].p * t[t[i].r].p;
	t[i].s = t[t[i].l].s * t[t[i].r].p + t[t[i].r].s;
}
void build(int i,int a,int b) {
	t[i].left = a,t[i].right = b,t[i].mid = (a + b) >> 1;
	t[i].s = t[i].p = 1;
	if(a != b) {
		build(t[i].l = tn++,a,t[i].mid);
		build(t[i].r = tn++,t[i].mid+1,b);
		pull(i);
	} else {
		t[i].s = 1;
	}
}
void mul(int i,int a,double v) {
	if(a == t[i].left && a == t[i].right) {
		t[i].s *= v;
		t[i].p *= v;
	} else {
		if(a <= t[i].mid) mul(t[i].l,a,v);
		if(a > t[i].mid) mul(t[i].r,a,v);
		pull(i);
	}
}
void sp(int i,int a,double &s,double &p) {
	if(a >= t[i].right) {
		s = t[i].s,p = t[i].p;
	} else if(a <= t[i].mid) {
		sp(t[i].l,a,s,p);
	} else {
		sp(t[i].r,a,s,p);
		s += p * t[t[i].l].s;
		p *= t[t[i].l].p;
	}
}
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	int n;
	scanf("%d",&n);
	tn = 2;build(0,0,n-1);build(1,0,n-1);
	for(int i = 0;i < n;++i) {
		scanf("%d",&w[i]);
		x[i] = i;
	}
	std::sort(x,x+n,comp);
	double ans = 0;
	for(int i = 0;i < n;++i) {
		double temp,s1,s2;
		sp(0,x[i],s1,temp);
		sp(1,n-1-x[i],s2,temp);
		//printf("%d %d %.08f %.08f\n",x[i],w[x[i]],s1,s2);
		ans += (s1 / n) * (s2 / n) * (w[x[i]] / 2);
		mul(0,x[i],0.5);mul(1,n-1-x[i],0.5);
	}
	printf("%.8f\n",ans);
}
