#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl
using namespace std;
const int maxn = 100009;

vector<int> to[maxn];
struct task{int l,r,ll,rr,tim,idx;}q[maxn];
struct change{int x,y,tim;}c[maxn];
int arr[maxn],L[maxn],R[maxn],col[maxn],ans[maxn],sum[maxn],cnt[maxn],val[maxn],bel[maxn];
bool vis[maxn];
int n,m,tot,siz,type,lastans,Q,C;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
inline int get()
{
	if(type) return read()^lastans;
	return read();
}

void dfs(int x,int last)
{
	arr[++tot]=x;L[x]=tot;
	int sz=to[x].size();
	for(int i=0;i<sz;i++) if(to[x][i]!=last) dfs(to[x][i],x);
	R[x]=tot;
}

int query(int x,int l,int r)
{
	int res=0;
	for(int i=L[x];i<=R[x];i++)
	{
		int x=col[arr[i]];
		if(!vis[x]&&x>=l&&x<=r) res++,vis[x]=1;
	}
	for(int i=L[x];i<=R[x];i++) vis[col[arr[i]]]=0;
	return res;
}

bool cmp(const task &x,const task &y)
{
	if(bel[x.l]==bel[x.r])
	{
		if(x.r==y.r) return x.tim<y.tim;
		return x.r<y.r;
	}return bel[x.l]<bel[y.l];
}
void update(int x,int opt)
{
	x=col[x];
	if(opt==1)
	{
		cnt[x]++;
		if(cnt[x]==1) val[x]++,sum[bel[x]]++,vis[x]=1;
	}
	else
	{
		cnt[x]--;
		if(cnt[x]==0) val[x]--,sum[bel[x]]--,vis[x]=0;
	}
}
void modify(int idx)
{
	int x=c[idx].x,y=c[idx].y;
	if(vis[x]) update(x,-1);
	col[x]=y;
	if(vis[x]) update(x,1);
}
int query(int l,int r)
{
	int res=0;
	if(bel[r]-bel[l]<=1)
	{
		for(int i=l;i<=r;i++) res+=val[i];
		return res;
	}
	for(int i=l;bel[i]==bel[l];i++) res+=val[i];
	for(int i=r;bel[i]==bel[r];i--) res+=val[i];
	for(int i=bel[l]+1;i<=bel[r]-1;i++) res+=sum[i];
	return res;
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read();m=read();type=read();
	for(int i=1;i<=n;i++) col[i]=read();
	for(int i=1;i<n;i++)
	{
		int x=read(),y=read();
		to[x].push_back(y);
		to[y].push_back(x);
	}
	dfs(1,-1);
	if(type)
	{
		while(m--)
		{
			int opt=read();
			if(opt==1)
			{
				int x=get(),l=get(),r=get();
//				printf("%d %d %d %d\n",opt,x,l,r);
				lastans=query(x,l,r);
				printf("%d\n",lastans);
			}
			else
			{
				int x=read(),y=read();
//				printf("%d %d %d\n",opt,x,y);
				col[x]=y;
			}
		}
	}
	else
	{
		siz=sqrt(n+0.5);
		for(int i=1;i<=n;i++) bel[i]=(i-1)/siz+1;
		for(int i=1;i<=m;i++)
		{
			int opt=read(),x=read();
			if(opt==1) Q++,q[Q]=(task){L[x],R[x],read(),read(),C,Q};
			else C++,c[C]=(change){x,read(),C};
		}
		sort(q+1,q+1+Q,cmp);
//		for(int i=1;i<=Q;i++) printf("%d %d %d %d %d %d\n",q[i].l,q[i].r,q[i].ll,q[i].rr,q[i].tim,q[i].idx);
		int l=1,r=0,now=0;
		for(int i=1;i<=Q;i++)
		{
			while(now>q[i].tim) modify(now),now--;
			while(now<q[i].tim) now++,modify(now);
			while(l>q[i].l) l--,update(arr[l],1);
			while(r<q[i].r) r++,update(arr[r],1);
			while(l<q[i].l) update(arr[l],-1),l++;
			while(r>q[i].r) update(arr[r],-1),r--;
//			debug(l);debug(r);debug(now);
			ans[q[i].idx]=query(q[i].ll,q[i].rr);
		}
		for(int i=1;i<=Q;i++) printf("%d\n",ans[i]);
	}
	return 0;
}
