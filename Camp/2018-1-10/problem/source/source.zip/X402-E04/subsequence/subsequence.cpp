#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=20,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
int n,m,k,A[N],B[N],ans=INF,p[N];
inline void file(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence1.out","w",stdout);
}
void init(){
	read(n),read(m),read(k);
	For(i,1,n)read(A[i]);
	For(i,1,m)read(B[i]);
	ans=max(n,m);
}
int dp[N][N];
bool check(int l){
	For(i,1,n)
		For(j,1,l){
			dp[i][j]=0;
			if(A[i]==p[j])
				dp[i][j]=max(dp[i][j],dp[i-1][j-1]+1);
			dp[i][j]=max(dp[i][j],max(dp[i-1][j],dp[i][j-1]));
		}
	if(dp[n][l]==l)return 0;
	For(i,1,m)
		For(j,1,l){
			dp[i][j]=0;
			if(B[i]==p[j])
				dp[i][j]=max(dp[i][j],dp[i-1][j-1]+1);
			dp[i][j]=max(dp[i][j],max(dp[i-1][j],dp[i][j-1]));
		}
	if(dp[n][l]==l)return 0;
	return 1;
}
void dfs(int now){
	if(now>ans)return ;
	if(check(now-1))ans=min(ans,now);
	For(i,1,k)p[now]=i,dfs(now+1);
}
void solve(){
	dfs(1);
	printf("%d\n",ans);
}
int main(){
	file();
	init();
	solve();
	return 0;
}
