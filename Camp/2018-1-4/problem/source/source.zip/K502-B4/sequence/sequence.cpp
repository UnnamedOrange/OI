#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int T,n,map[30],mul[40],vis[4000010];
struct node
{
	int map[30];
	int dep;
};
queue<node> Q;
int kangtuo(node x)
{
	int res=1;
	for(int i=1;i<n;i++)
	{
		int t=0;
		for(int j=i+1;j<=n;j++) if(x.map[i]>x.map[j]) t++;
		res+=t*mul[n-i];
	}
	return res;
}
int bfs()
{
	while(!Q.empty())
	{
		node u=Q.front();
		Q.pop();
		for(int i=2;i<=n;i++)
		{
			node r;
			for(int j=1;j<=n;j++) r.map[j]=u.map[j];
			for(int j=1;j<=i;j++) r.map[j]=u.map[i-j+1];
			if(vis[kangtuo(r)]) continue;
			if(kangtuo(r)==1) return u.dep+1;
			vis[kangtuo(r)]=1;
			r.dep=u.dep+1;
			Q.push(r);
		}
	}
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&T);
	mul[0]=1;
	for(int i=1;i<=10;i++) mul[i]=mul[i-1]*i;
	while(T--)
	{
		memset(map,0,sizeof(map));
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&map[i]);
		node u;
		for(int i=1;i<=n;i++) u.map[i]=map[i];
		if(kangtuo(u)==1) 
		{
			printf("0\n");
			continue;
		}
		u.dep=0;Q.push(u);
		printf("%d\n",bfs());
	}
	return 0;
}
