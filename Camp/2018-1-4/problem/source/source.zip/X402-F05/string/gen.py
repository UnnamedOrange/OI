from random import *

f = open('string.in', 'w')

n = randint(6, 6)
m = randint(12, 16)

f.write('{} {}\n'.format(n, m))

for i in range(0, n):
	l = randint(1, randint(1, randint(5, 2 * m)))
	for j in range(0, l):
		f.write('{}'.format(randint(0, 1)))
	f.write('\n')
