#include <cstdio>
#include <queue>
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
#define la (x-1)&1
#define F(x,y,z) for (x=y;x<=z;++x)
#define LL long long
using namespace std;
const int N=200100;
struct gsqq{
	int b,ne;
}d[N*2];
int n,m,q,t,dl,c[N],st[N],ans,cr,cl;
int f[N];
int vis[N];
void add(int x,int y){d[++dl].b=y;d[dl].ne=st[x];st[x]=dl;}

void ask(int x)
{
	if (vis[c[x]]!=q && c[x]>=cl && c[x]<=cr)
		vis[c[x]]=q,++ans;
	if (ans==cr-cl+1) return;
	int i;
	for (i=st[x];i;i=d[i].ne)
		if (d[i].b!=f[x])
			ask(d[i].b);
}

void dfs(int x,int fa)
{
	f[x]=fa;
	for (int i=st[x];i;i=d[i].ne)
		if (d[i].b!=fa)
			dfs(d[i].b,x);
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int i,j,x,y,z,o,lasta=0;
	scanf("%d%d%d",&n,&q,&t);
	F(i,1,n) vis[i]=-1;
	F(i,1,n) scanf("%d",&c[i]);
	F(i,1,n-1)
		scanf("%d%d",&x,&y),add(x,y),add(y,x);
	dfs(1,0);
	while (q--)
	{
		scanf("%d",&o);
		if (o==1)
		{
			ans=0;
			scanf("%d%d%d",&x,&cl,&cr);
			if (t==1) x^=lasta,cl^=lasta,cr^=lasta;
			ask(x);
			printf("%d\n",ans);
			lasta=ans;
		}
		else
		{
			scanf("%d%d",&x,&y);
			if (t==1) x^=lasta,y^=lasta;
			c[x]=y;
		}
	}
	return 0;
}

