#include<bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}

int main() {
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	puts("2");
	return 0;
}

