#include <cstdio>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

int Bit[9][101];
int Len[8], N, M;

inline void init() {
	N = get_int(), M = get_int();
	for(int i = 1; i <= N; ++i) {
		int ch = getch();
		while((unsigned)(ch ^ '0') > 1) ch = getch();
		Bit[i][Len[i] = 1] = ch ^ '0';
		while(ch = getch(), (unsigned)(ch ^ '0') < 2)
			Bit[i][++Len[i]] = (ch ^ '0');
	}
}

inline bool match(int pos, int k) {
	if((M << 1) - pos + 1 < Len[k]) return false;
	for(int i = 0; i < Len[k]; ++i)
		if(Bit[0][pos + i] != Bit[k][i + 1]) return false;
	return true;
}

inline bool check(int x) {
	bool matched[8] = {0, 0, 0, 0, 0, 0, 0, 0}; // {0};
	int cnt = 0;
	for(int i = 1; i <= M; ++i)
		Bit[0][(M << 1) - i + 1] = !(Bit[0][i] = (x & (1 << (i - 1))) != 0);
	for(int i = 1; i <= (M << 1) && cnt < N; ++i)
		for(int j = 1; j <= N; ++j)
			if(!matched[j]) cnt +=(matched[j] = match(i, j));
	return cnt == N;
}

inline void solve() {
	if(M > 20) puts("0");
	else {
		int U = 1 << M, ans = 0;
		for(int x = 0; x < U; ++x)
			ans += check(x);
		printf("%d\n", ans);
	}
}

#define PROBLEM_NAME	"string"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	init();
	solve();
	return 0;
}
