#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=505,M=1005;

struct node{
	int x,y,z,a,b,c,d,e,f;
	void read(){
		rd(x),rd(y),rd(z);
		rd(a),rd(b),rd(c);
		rd(d),rd(e),rd(f);
	}
}arr[M];
struct ss{
	int x,y,r;
	void read(){
		rd(x),rd(y),rd(r);
	}
}ARR[M];
int n,W,P,Q;
struct P_0{
	int les[30][30];
	int lese[30][30];
	int big[30][30];
	int e[30][30];
	int bige[30][30];
	int ans,w[30];
	void dfs(int t){
		if(t>n){
//			rep(i,1,Q+1){
//				if(ARR[i].r==1&&w[ARR[i].x]!=w[ARR[i].y])return ;
//				if(ARR[i].r==0&&w[ARR[i].x]>w[ARR[i].y])return ;
//				if(ARR[i].r==2&&w[ARR[i].x]>=w[ARR[i].y])return ;
//			}
			int res=0;
			rep(i,1,t)res+=w[i];
			#define a arr[i].a
			#define b arr[i].b
			#define c arr[i].c
			#define d arr[i].d
			#define e arr[i].e
			#define f arr[i].f
			#define x arr[i].x
			#define y arr[i].y
			#define z arr[i].z
			rep(i,1,P+1){
				res+=a*abs(w[x]-w[y])+b*abs(w[y]-w[z])+c*abs(w[x]-w[z])
				+d*(w[x]-w[y])+e*(w[y]-w[z])+f*(w[z]-w[x]);
			}
			Min(ans,res);
			#undef a
			#undef b
			#undef c
			#undef d
			#undef e
			#undef f
			#undef x
			#undef y
			#undef z
			return ;
		}
		int i;
		for(w[t]=-1;w[t]<2;++w[t])if(w[t]){
			bool flag=true;
			for(i=1;i<=les[t][0]&&flag;++i)if(w[les[t][i]]>=w[t])flag=false;
			for(i=1;i<=lese[t][0]&&flag;++i)if(w[lese[t][i]]>w[t])flag=false;
			for(i=1;i<=e[t][0]&&flag;++i)if(w[e[t][i]]!=w[t])flag=false;
			for(i=1;i<=big[t][0]&&flag;++i)if(w[big[t][i]]<=w[t])flag=false;
			for(i=1;i<=bige[t][0]&&flag;++i)if(w[bige[t][i]]<w[t])flag=false;
			if(flag)
			dfs(t+1);
		}
	}
	void work(){
		memset(lese,0,sizeof lese);
		memset(les,0,sizeof les);
		memset(e,0,sizeof e);
		memset(big,0,sizeof big);
		memset(bige,0,sizeof bige);
		#define y ARR[i].y
		#define x ARR[i].x
		rep(i,1,Q+1){
			if(x<y){
				if(ARR[i].r==0)lese[y][++lese[y][0]]=x;
				else if(ARR[i].r==1)e[y][++e[y][0]]=x;
				else les[y][++les[y][0]]=x;
			}else if(x>y){
				if(ARR[i].r==0)bige[x][++bige[x][0]]=y;
				else if(ARR[i].r==1)e[x][++e[x][0]]=y;
				else big[x][++big[x][0]]=y;
			}
		}
		#undef y
		#undef x
		ans=(int)1e9;
		dfs(1);
		ptn((ll)ans*W);
	}
}P0;
const int SZ=1520;
const ll inf=(ll)1e17;
struct P_1{
	int S,T,tot_edge,head[SZ];
	struct node{
		int to,nxt;
		ll cap;
	}G[M*100];
	void add_edge(int x,int y,ll c){
		G[tot_edge]=(node){y,head[x],c};head[x]=tot_edge++;
		G[tot_edge]=(node){x,head[y],0};head[y]=tot_edge++;
	}
	int cnt[N];
	int level[SZ],que[SZ],ite[SZ];
	bool BFS(){
		memset(level ,-1, (T+1)<<2);
		int l=0,r=0;
		que[r++]=S;level[S]=0;
		while(l<r){
			for(int x=que[l++],i=head[x];~i;i=G[i].nxt)if(G[i].cap>0){
				int y=G[i].to;
				if(level[y]==-1){
					level[y]=level[x]+1;
					que[r++]=y;
				}
			}
		}
		return level[T]!=-1;
	}
	ll dfs(int x,ll flow){
		if(x==T||!flow)return flow;
		ll res=0;
		for(int &i=ite[x];~i;i=G[i].nxt)if(G[i].cap>0){
			int y=G[i].to;
			if(level[y]==level[x]+1){
				ll tmp=dfs(y,min(flow,G[i].cap));
				G[i].cap-=tmp;G[i^1].cap+=tmp;
				res+=tmp;
				flow-=tmp;
				if(!flow)break;
			}
		}
		return res;
	}
	ll max_flow(){
		ll ans=0;
		while(BFS()){
			memcpy(ite,head,(T+1)<<2);
			ans+=dfs(S,inf);
		}
		return ans;
	}
	void work(){
		memset(head,-1,sizeof head);
		S=0;T= 3 * n + 1;
		rep(i,1,n+1)cnt[i]=1;
		rep(i,1,Q+1){
			cnt[arr[i].x]+=arr[i].d-arr[i].f;
			cnt[arr[i].y]+=arr[i].e-arr[i].d;
			cnt[arr[i].z]+=arr[i].f-arr[i].e;
		}
		int mi=0;
		rep(i,1,n+1)
			Min(mi,cnt[i]),Min(mi,-cnt[i]);
		mi=-mi;
		rep(i,1,n+1){
			add_edge(S,i*3-2,inf);
			add_edge(i*3-2,i*3-1,-cnt[i]+mi);
			add_edge(i*3-1,i*3,cnt[i]+mi);
			add_edge(i*3,T,inf);
		}
		rep(i,1,Q+1){
			add_edge(arr[i].x*3-1,arr[i].y*3-1,2*arr[i].a);
			add_edge(arr[i].y*3-1,arr[i].x*3-1,2*arr[i].a);
			add_edge(arr[i].y*3-1,arr[i].z*3-1,2*arr[i].b);
			add_edge(arr[i].z*3-1,arr[i].y*3-1,2*arr[i].b);
			add_edge(arr[i].z*3-1,arr[i].x*3-1,2*arr[i].c);
			add_edge(arr[i].x*3-1,arr[i].z*3-1,2*arr[i].c);
		}
		rep(i,1,P+1){
			if(ARR[i].r==2){
				add_edge(ARR[i].x*3-2,ARR[i].y*3-1,inf);
				add_edge(ARR[i].x*3-1,ARR[i].y*3,inf);
			}else if(ARR[i].r==1){
				add_edge(ARR[i].x*3-1,ARR[i].y*3-1,inf);
				add_edge(ARR[i].y*3-1,ARR[i].x*3-1,inf);
			}else {
				add_edge(ARR[i].x*3-1,ARR[i].y*3-1,inf);
			}
		}
		ll ans=max_flow()-(ll)n*mi;
//		rep(x,1,n+1){
//			for(int i=head[x*3-2];~i;i=G[i].nxt)if(G[i].cap==0){
//				if(G[i].to==x*3-1)bug(x),debug(-1);
//			}
//			for(int i=head[x*3-1];~i;i=G[i].nxt)if(G[i].cap==0){
//				if(G[i].to==x*3)bug(x),debug(-2);
//			}
//		}
		ptn(ans*W);
	}
}P1;
void solve(){
	rd(n),rd(W),rd(P),rd(Q);
	rep(i,1,P+1)arr[i].read();
	rep(i,1,Q+1)ARR[i].read();
	if(0);
	else if(n<=15&&P<=20&&Q<=20)P0.work();
	else P1.work();
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T;rd(T);
	while(T--)solve();
	return 0;
}
