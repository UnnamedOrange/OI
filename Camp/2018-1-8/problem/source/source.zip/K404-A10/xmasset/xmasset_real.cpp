#include <bits/stdc++.h>

int type, N;

void init()
{
    
}

int encode(int x, int y)
{
	for(int i = 0;i < 10;++i) {
		if((x & (1 << i)) > 0 && (y & (1 << i)) == 0)
			return 2 * i + 1;
		else if((x & (1 << i)) == 0 && (y & (1 << i)) > 0)
			return 2 * i + 2;
	}
}

bool decode(int q, int h)
{
	if(h % 2 == 1 && (q & (1 << ((h - 1) / 2))) > 0)
		return true;
	else if(h % 2 == 0 && (q & (1 << ((h - 1) / 2))) == 0)
		return true;
	else
		return false;
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
