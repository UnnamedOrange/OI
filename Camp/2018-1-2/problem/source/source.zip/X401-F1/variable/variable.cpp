#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define INF 0x3f3f3f3f
using namespace std;
typedef long long LL;
typedef double db;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') { if(ch=='-')f=-1; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+ch-'0'; ch=getchar(); }
	return x*f;
}
const int MAXN=30;
int n,W,p,q,ans,w[MAXN];
struct node
{
	int x,y,z,a,b,c,d,e,f;
}a[MAXN];
struct node2
{
	int x,y,r;
}b[MAXN];
bool check()
{
	for(int i=1;i<=q;++i)
		if(b[i].r==0&&w[b[i].x]>w[b[i].y]||b[i].r==1&&w[b[i].x]!=w[b[i].y]||b[i].r==2&&w[b[i].x]>=w[b[i].y])return false;
	return true;
}
void cal()
{
	int ret=0;
	for(int i=1;i<=p;++i)
		ret+=a[i].a*abs(w[a[i].x]-w[a[i].y])+a[i].b*abs(w[a[i].y]-w[a[i].z])+a[i].c*abs(w[a[i].z]-w[a[i].x])+a[i].d*(w[a[i].x]-w[a[i].y])+a[i].e*(w[a[i].y]-w[a[i].z])+a[i].f*(w[a[i].z]-w[a[i].x]);
	for(int i=1;i<=n;++i)
		ret+=w[i];
	ans=min(ans,ret);
	return;
}
void dfs(int dep)
{
	if(dep==n+1)
	{
		if(check())cal();
		return;
	}
	w[dep]=W;
	dfs(dep+1);
	w[dep]=-W;
	dfs(dep+1);
	return;
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T=read();
	while(T--)
	{
		n=read();W=read();p=read();q=read();
		ans=INF;
		for(int i=1;i<=p;++i)a[i].x=read(),a[i].y=read(),a[i].z=read(),a[i].a=read(),a[i].b=read(),a[i].c=read(),a[i].d=read(),a[i].e=read(),a[i].f=read();
		for(int i=1;i<=q;++i)b[i].x=read(),b[i].y=read(),b[i].r=read();
		dfs(1);
		printf("%lld\n",ans);
	}
	return 0;
}
