#include<bits/stdc++.h>
using namespace std;
 
int getint()
{
    int i=0,f=1;char c;
    for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
    if(c=='-')c=getchar(),f=-1;
    for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
    return i*f;
}

const int N=200005;
int T,n,m,R[N];
char s[N],t[N];

void manacher()
{
	int mx=0,po=0;
	for(int i=1;i<=m;i++)
	{
		if(i<mx)R[i]=min(mx-i,R[2*po-i]);
		else R[i]=1;
		while(s[i-R[i]]==s[i+R[i]])R[i]++;
		if(i+R[i]>mx)mx=i+R[i],po=i;
	}
}

bool check(int l,int r)
{
	int mid=l+r;
	if(R[mid]>r-l+1)return true;
	return false;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	T=getint();
	while(T--)
	{
		n=getint();m=0;
		scanf("%s",t+1);
		s[0]='?',s[++m]='#';
		for(int i=1;i<=n;i++)
			s[++m]=t[i],s[++m]='#';
		manacher();
		if(!check(1,n))
		{
			puts("1");continue;
		}
		int bz=1;
		for(int i=1;i<n;i++)
			if(!check(1,i)&&!check(i+1,n))
			{bz=0;puts("2");break;}
		if(bz)puts("-1");
	}
	return 0;
}
