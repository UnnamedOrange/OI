#include<bits/stdc++.h>
#define debug(x) cout<<#x<<"="<<x<<endl
using namespace std;
const int maxn = 100009;
const int mod = 1e9+7;

int a[maxn],sg[maxn],f[maxn][2];
int n,A,B,cnt;

// 0: last 1: first 2: min

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
inline void update(int &x,int y)
{
	x += y;
	x -= x >= mod ? mod : 0;
}
int PowerMod(int x,int y)
{
	int res=1;
	while(y)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;y>>=1;
	}return res;
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n=read();A=read();B=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++)
	{
		int x=a[i]%(A+B);
		if(x<min(A,B)) sg[i]=0;
		else if(x>=min(A,B)&&x<max(A,B)) sg[i]=2;
		else sg[i]=1;
	}
	f[0][0]=1;
	for(int i=0;i<n;i++)
	{
		f[i+1][0]=f[i][0];
		f[i+1][1]=f[i][1];
		if(sg[i+1]==2) cnt++;
		else
		{
			update(f[i+1][sg[i+1]],f[i][0]); 
			update(f[i+1][sg[i+1]^1],f[i][1]);
		}
	}
	if(cnt==0) printf("0 0 %d %d\n",f[n][1],f[n][0]);
	else
	{
		int res=(PowerMod(2,cnt)+mod-1)%mod;
		if(A<B)	printf("%d 0 %d %d\n",(int)(1ll*res*(f[n][0]+f[n][1])%mod),f[n][1],f[n][0]);
		else printf("0 %d %d %d\n",(int)(1ll*res*(f[n][0]+f[n][1])%mod),f[n][1],f[n][0]);
	}
	return 0;
}
