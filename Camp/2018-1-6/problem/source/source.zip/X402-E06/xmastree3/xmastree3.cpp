#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;

string procStatus() {
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}

template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 50;
const int K = 15;
const int mo = 998244353;

int n, k;
vector<int> G[N + 5];
void addedge(int x, int y) { G[x].pb(y); G[y].pb(x); }

namespace hash_map {
    const int P = 15000000;
    const int MOD = 16666667;

    int tot = 0;
    ll S[P + 5];
    int U[P + 5], L[P + 5];
    int dp[P + 5], nxt[P + 5], st[MOD + 5];

    void clear() { memset(dp, -1, sizeof dp); }
    inline int hash(ll s, int u, int l) {
        return (1ll * (s * n + u) % MOD * (k+1) + l) % MOD;
    }

    int& find(ll s, int u, int l) {
        int hs = hash(s, u, l);
        for(int i = st[hs]; i; i = nxt[i]) 
            if(S[i] == s && U[i] == u && L[i] == l) return dp[i];

        nxt[++ tot] = st[hs]; st[hs] = tot;
        S[tot] = s, U[tot] = u, L[tot] = l; 
        return dp[tot];
    }
}

ll chk(int u, ll s, int f = -1) {
    ll res = 1ll << u;
    for(int i = 0; i < int(G[u].size()); ++i) if(G[u][i] != f) {
        if(!(s >> G[u][i] & 1)) { res |= chk(G[u][i], s, u); }
    }
    return res;
}

int dfs(ll s, int u, int l) {
    ll ap = chk(u, s);
    int &ans = hash_map::find(s, u, l);

    if(ans >= 0) return ans;
    if(ap == (1ll << u)) return k-l;

    ans = 0;
    for(int v = 0; v < n; ++v) if(ap >> v & 1) {
        for(int _l = l+1; _l <= k; ++_l) {
            int res = 1;
            for(int w = 0; w < int(G[v].size()); ++w) if(ap >> G[v][w] & 1) {
                res = 1ll * res * dfs(s | (1ll << v), G[v][w], _l) % mo;
            } 
            ans = (ans + res) % mo;
        }
    }
    return ans;
}

int main() {
    freopen("xmastree3.in", "r", stdin);
    freopen("xmastree3.out", "w", stdout);

    read(n), read(k);
    for(int i = 1; i < n; ++i) {
        static int u, v;
        read(u), read(v); 
        -- u, -- v; addedge(u, v);
    }

    hash_map::clear();
    printf("%d\n", dfs(0, 0, 0));

    //std::cout << procStatus() << std::endl;
    return 0;
}
