#include <cctype>
#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)
#define repd(i,x,y) for (int i=x; i>=(y); --i)
#define repe(i,x) for (edge *i=fst[x]; i; i=i->nxt)

using namespace std;

int get()
{
    char c;
    while (!isdigit(c=getchar()) && c!='-');
    int s=c=='-'? -1:1,k=~s? c-'0':0;
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return s*k;
}

const int N=1e6+10,M=1e6+10;
int n,m;

void force()
{
    const int N=12,S=1<<N;
    static bool w[N][N],flag[S];
    static int f[S];
    rep(i,1,m)
    {
        int u=get()-1,v=get()-1;
        w[u][v]=1;
    }
    rep(k,0,n-1)
        rep(i,0,n-1)
            rep(j,0,n-1)
                w[i][j]|=w[i][k] && w[k][j];
    flag[0]=1;
    rep(i,1,(1<<n)-1)
    {
        int x=0;
        for (; !((i>>x)&1); ++x);
        if (!flag[i^(1<<x)])
            continue;
        flag[i]=1;
        rep(v,x+1,n-1)
            if (((i>>v)&1) && (w[x][v] || w[v][x]))
            {
                flag[i]=0;
                break;
            }
    }
    memset(f,63,sizeof(f)),f[0]=0;
    rep(i,1,(1<<n)-1)
        for (int j=i; j; --j&=i)
            if (flag[j])
                f[i]=min(f[i],f[i^j]+1);
    printf("%d\n",f[(1<<n)-1]);
}

int main()
{
    freopen("bomb.in","r",stdin);
    freopen("force.out","w",stdout);
    n=get(),m=get();
    force();
    return 0;/*
    rep(i,1,m)
    {
        int u=get(),v=get();
        *tp=(edge){v,fst[u]},fst[u]=tp++;
    }
    rep(i,1,n)
        if (!dfn[i])
            tarjan(i);
    rep(x,1,n)
        repe(i,x)
            if (bel[x]!=bel[i->v])
                ++deg[bel[i->v]];
    for (int t=tot,mn; t; )
    {
        mn=n;
        rep(i,1,tot)
            if (size[i] && !deg[i])
                mn=min(mn,size[i]);
        ans+=mn;
        rep(x,1,tot)
            if (size[x] && !deg[x] && !(size[x]-=mn))
            {
                --t;
                rep(_,0,int(vtx[x].size())-1)
                {
                    int u=vtx[x][_];
                    repe(i,u)
                        if (x!=bel[i->v])
                            --deg[bel[i->v]];
                }
            }
    }
    printf("%d",ans);
    return 0;*/
}
