#include<cstdio>
using namespace std;
const int maxn=100005,mod=998244353;
int head[maxn];
int num;
struct cp{
	int to,next;
}edge[maxn];
inline void add(int u,int v){
	edge[++num].to=v;
	edge[num].next=head[u];
	head[u]=num;
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int n,s=0,x;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		if(x) add(i,x);
		else s++;
	}
	if(n%2){printf("0\n"); return 0;}
	if(s==n){
		if(n==2) {printf("1\n"); return 0;}
		if(n==4) {printf("5\n"); return 0;}
		if(n==6) {printf("225\n"); return 0;}
	}
	else{
		printf("998244352\n"); return 0;
	}
	return 0;
}
