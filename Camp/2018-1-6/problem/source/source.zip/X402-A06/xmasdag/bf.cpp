#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 200010;

int Begin[maxn], to[maxn], e, Next[maxn], n, m, K, rd[maxn];

void add(int x,int y){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get(){
	n = read(), m = read(), K = read();
	For(i, 1, m){
		int x = read(), y = read();
		add(x, y); ++ rd[y];
	}
}

int q[maxn];

int dp[2010][5010], Max[maxn];

const int mod = 998244353;

int ksm(int x,int k){
	int s = 1;
	while(k){
		if(k & 1) s = 1ll * s * x % mod;
		x = 1ll * x * x % mod;
		k >>= 1;
	}

	return s;
}

int ans[maxn];

void solve_bf(){
	dp[1][0] = 1;
	int l = 0, r = 1;
	q[r] = 1;
	Max[1] = 0;

	while(l < r){
		int now = q[++l];
		for(int i = Begin[now];i ;i = Next[i]){
			int v = to[i];

			Max[v] = max(Max[v], Max[now] + 1);
			For(j, 0, Max[now]){
				(dp[v][j+1] += dp[now][j]) %= mod;
			}

			if(!(--rd[v])){
				q[++r] = v;
			}
		}
	}

	For(i, 1, n){
		int Ans = 0;
		For(j, 0, Max[i]){
			(Ans += 1ll * dp[i][j] * ans[j] % mod) %= mod;
		}
		printf("%d\n", Ans);
	}
}

int kind[maxn], tot[maxn];

void solve_spe(){
	int l = 0, r = 1;
	q[r] = 1;
	kind[1] = 1;
	
	while(l < r){
		int now = q[++l];
		for(int i = Begin[now];i ;i = Next[i]){
			int v = to[i];

			(tot[v] += (tot[now] + kind[now]) % mod) %= mod;
			(kind[v] += kind[now]) %= mod;

			if(!(--rd[v])){
				q[++r] = v;
			}
		}
	}

	For(i, 1, n) printf("%d\n", tot[i]);
}

int f[100010][50], C[1010][1010];

//remember to larger the shuzu

void pre_work(){
	For(i, 0, 1000) C[i][0] = 1;
	For(i, 1, 1000){
		For(j, 1, i){
			C[i][j] = (C[i-1][j] + C[i-1][j-1]) % mod;
		}
	}

	For(i, 0, 5000) ans[i] = ksm(i, K);
}

int mo(int x){
	if(x >= mod) x -= mod;
	return x;
}

void solve(){
	int l = 0, r = 1;
	q[r] = 1;
	f[1][0] = 1;

	while(l < r){
		int now = q[++l];
		for(int i = Begin[now];i ;i = Next[i]){
			int v = to[i];

			For(i, 0, K){
				int nowans = 0;
				For(j, 0, i){
					nowans += 1ll * C[i][j] * f[now][j] % mod;
					nowans = mo(nowans);
				}

				f[v][i] += nowans;
				f[v][i] = mo(f[v][i]);
			}//时间复杂度的瓶颈在于k^2枚举

			if(!(-- rd[v])) q[++r] = v;
		}
	}

	For(i, 1, n) printf("%d\n", f[i][K]);
}

int main(){

	//freopen("xmasdag.in", "r", stdin);
	//freopen("xmasdag.out", "w", stdout);

	Get();
	pre_work();
	solve_bf();

	return 0;
}
