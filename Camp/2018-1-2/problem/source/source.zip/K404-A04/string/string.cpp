#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int maxn=100010;
int n,ans,len[12];
char s[maxn],t[maxn],st[12][12];
bool check(char *s,int l,int r)
{
	for(int i=l;i<=(l+r)>>1;i++)
		if(s[i]!=s[r+l-i]) return 0;
	return 1;	
}
void find(int d)
{
	if(d>=ans) return;
	if(!check(st[d],1,len[d])) {ans=min(ans,d);return ;}
	for(int l=1;l<=len[d];l++)
		for(int r=l;r<=len[d];r++)
			if(!check(st[d],l,r))
			{
				len[d+1]=0;
				for(int i=1;i<l;i++) st[d+1][++len[d+1]]=st[d][i];
				for(int i=r+1;i<=len[d];i++) st[d+1][++len[d+1]]=st[d][i];
				find(d+1);
			}
}
int spc1()
{
	for(int l=1;l<=n;l++)
		for(int r=l;r<=n;r++)
			if(!check(s,l,r))
			{
				int le=0;
				for(int i=1;i<l;i++) t[++le]=s[i];
				for(int i=r+1;i<=n;i++) t[++le]=s[i];
				if(!check(t,1,le)) return 2;
			}
	return -1;		
}
int spc2()
{
	bool flag=1;
	for(int i=1;i<=n/2;i++)
		if(s[i]!=s[1]) {flag=0;break;}
	for(int i=n-n/2+1;i<=n;i++)
		if(s[i]!=s[1]) {flag=0;break;}
	if(flag) return -1;
	if(n&1)
	{
		flag=1;
		for(int i=1;i<=n;i++)
		{
			if(i&1) {if(s[i]!=s[1]){flag=0;break;}}
			else if(s[i]!=s[2]){flag=0;break;}
		}
		if(flag) return -1;
	}
	return 2; 		
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int ca;
	scanf("%d",&ca);
	while(ca--)
	{
		//puts("********************");
		scanf("%d%s",&n,s+1);
		if(!check(s,1,n)) {puts("1"); continue;}
		if(n<=10) 
		{
			ans=1e9;len[1]=n;
			for(int i=1;i<=n;i++) st[1][i]=s[i];
			find(1);
			printf("%d\n",ans==1e9?-1:ans);
		}
		else if(n<=100) printf("%d\n",spc1());
		else printf("%d\n",spc2());	
	}
	return 0;
}
/*2 
7 
abcdcba
3
xxx*/
