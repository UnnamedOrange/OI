#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 100010
#define ll long long
using namespace std;
inline int read() 
{ 
    int x=0,f=1;char ch=getchar(); 
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();} 
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
    return x*f; 
}
int T,n,top;
char s[N],b[N];
bool ck_s()
{
	int l=1,r=n;
	while(l<=r)
	{
		if(s[l]!=s[r])return 0;
		l++,r--;
	}
	return 1;
}
bool ck_b()
{
	int l=1,r=top;
	while(l<=r)
	{
		if(b[l]!=b[r])return 0;
		l++,r--;
	}
	return 1;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read();
		scanf("%s",s+1);top=0;
		if(!ck_s())
		{
			puts("1");
			continue ;
		}
		for(int i=1;i<n;i++)
		if(s[i]!=s[i+1])
		{
			for(int j=1;j<i;j++)
			b[++top]=s[j];
			for(int j=i+2;j<=n;j++)
			b[++top]=s[j];
			break ;
		}
		if(!ck_b())puts("2");
		else puts("-1");
	}
}