#include <cstdio>
#include <algorithm>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

namespace OUTBUFFER {
	char buf[1048576];
	int pt;
	inline void putch(register char ch) { buf[pt++] = ch; }
	inline void flush() { if(pt) fwrite(buf,sizeof(char),pt,stdout), pt = 0; }
	inline void check() { if(pt > 1000000) flush(); }
}

template <class T>
inline void put_int(register T x) {
	char temp[23];
	register int top;
	if(x == 0) return OUTBUFFER::putch('0');
	if(x < 0) OUTBUFFER::putch('-'), x = -x;
	for(top = 0; x; temp[++top] = x % 10, x /= 10);
	do OUTBUFFER::putch(temp[top] ^ '0'); while(--top);
	OUTBUFFER::check();
}

struct OUT {
	OUT() { OUTBUFFER::pt = 0; }
	~OUT() { OUTBUFFER::flush(); }
	const OUT &operator << (const char *str) const {
		while(*str) OUTBUFFER::putch(*str++);
		OUTBUFFER::check();
		return *this;
	}
	const OUT &operator << (register char ch) const {
		return OUTBUFFER::putch(ch), *this;
	}
	const OUT &operator << (register int x) const {
		return put_int<int>(x), *this;
	}
	const OUT &operator << (register long long x) const {
		return put_int<long long>(x), *this;
	}
} out;

int N, seq[25];

inline void init() {
	N = get_int();
	for(int i = 1; i <= N; ++i) seq[i] = get_int();
}

inline void solve() {
	int cnt = 0;
	while(N) {
		while(seq[N] == N) --N;
		if(N <= 1) break;
		int pt;
		for(pt = 1; pt < N && seq[pt] != N; ++pt);
		if(pt != 1) std::reverse(seq + 1, seq + pt + 1), ++cnt;
		std::reverse(seq + 1, seq + N + 1), ++cnt;
	}
	printf("%d\n", cnt);
}

#define PROBLEM_NAME	"sequence"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	int T = get_int();
	while(T--) {
		init();
		solve();
	}
	return 0;
}
