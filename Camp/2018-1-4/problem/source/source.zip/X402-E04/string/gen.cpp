#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
int main(){
	int n=1,m=500;;
	freopen("string.in","w",stdout);
	printf("%d %d\n",n,m);
	srand(time(0));
	int L=100;
	For(i,1,n){
		For(j,1,L)printf("%d",rand()%2);
		puts("");
	}
	return 0;
}
