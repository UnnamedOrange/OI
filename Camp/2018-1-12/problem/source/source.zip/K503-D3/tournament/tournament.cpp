#include <cstdio>

#define N (int)1e5+10
#define modp 998244353

int a[5000][2],b[100][100],d[100];
int f[N],C[5010][5010],p[30000000],w[10000],ans=0;
bool mark[100];

int power(int x, int p){
	int k=x,s=1;
	for (;p;p>>=1,k=1LL*k*k%modp)
		if (p&1) s=1LL*s*k%modp;
	return s;
}

bool dfs2(int x, int n, int k){
	for (int i=1;i<=n;i++)
		if (b[x][i]&&!mark[i]){
			d[i]=d[x]+1; mark[i]=true;
			if (dfs2(i,n,k)) return true;
			mark[i]=false;
		}
		else if (b[x][i]&&d[x]-d[i]==k-1)
			return true;
	return false;
}

bool check(int n, int k){
	for (int j=1;j<=n;j++)
		mark[j]=false;
	for (int i=1;i<=n;i++){
		for (int j=1;j<=n;j++)
			d[j]=-10000;
		d[i]=1; mark[i]=true;
		if (dfs2(i,n,k)) return true;
		mark[i]=false;
	}
	return false;
}

void dfs(int x, int cnt, int n, int k){
	if (x>cnt){
		ans+=check(n,k);
		if (ans>=modp) ans-=modp;
		return;
	}
	b[a[x][0]][a[x][1]]=0,
	b[a[x][1]][a[x][0]]=1;
	dfs(x+1,cnt,n,k);
	b[a[x][0]][a[x][1]]=1,
	b[a[x][1]][a[x][0]]=0;
	dfs(x+1,cnt,n,k);
}

int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	int n,k,cnt=0; scanf("%d%d",&n,&k);
	if (k==3){
		f[0]=1;
		for (int i=1;i<=n;i++)
			f[i]=1LL*f[i-1]*i%modp;
		ans=(power(2,n*(n-1)/2)-f[n])%modp;
		if (ans<0) ans+=modp;
	}
	else if (n==k){
		for (int i=0;i<=n;i++){
			C[i][0]=1;
			for (int j=1;j<=i;j++)
				C[i][j]=(C[i-1][j]+C[i-1][j-1])%modp;
		}
		p[0]=1;
		for (int i=1;i<=C[n][2];i++)
			p[i]=2LL*p[i-1]%modp;
		w[1]=1,w[2]=0,w[3]=2;
		for (int i=4;i<=n;i++){
			w[i]=p[C[i][2]];
			for (int j=1;j<=i-1;j++)
				w[i]=(w[i]-1LL*C[i][j]*w[j]%modp*p[C[i-j][2]]%modp)%modp;
		}
		ans=w[n]; if (ans<0) ans+=modp;
	}
	else{
		for (int i=1;i<=n;i++)
			for (int j=i+1;j<=n;j++)
				a[++cnt][0]=i,a[cnt][1]=j;
		dfs(1,cnt,n,k);
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

