#include<bits/stdc++.h>
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')c=getchar(),f=-1;
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

const int N=500005,mod=1e9+9;
struct node
{
	int l,r;
	inline friend bool operator <(const node &a,const node &b)
	{return a.l<b.l;}
}b[N];
int n,m,a[N];
int sum[N<<2],tag[N<<2];

int Mod(int x)
{
	return x>=mod?x-mod:x;
}

void build(int k,int l,int r)
{
	tag[k]=1;
	if(l==r)
	{
		if(!l)sum[k]=1;
		return;
	}
	int mid=l+r>>1;
	build(k<<1,l,mid),build(k<<1|1,mid+1,r);
	sum[k]=Mod(sum[k<<1]+sum[k<<1|1]);
}

void pushdown(int k)
{
	sum[k<<1]=1ll*sum[k<<1]*tag[k]%mod;
	sum[k<<1|1]=1ll*sum[k<<1|1]*tag[k]%mod;
	tag[k<<1]=1ll*tag[k<<1]*tag[k]%mod;
	tag[k<<1|1]=1ll*tag[k<<1|1]*tag[k]%mod;
	tag[k]=1;
}

int query(int k,int l,int r,int x,int y)
{
	if(x==l&&y==r)return sum[k];
	if(tag[k]!=1)pushdown(k);
	int mid=l+r>>1;
	if(y<=mid)return query(k<<1,l,mid,x,y);
	else if(x>mid)return query(k<<1|1,mid+1,r,x,y);
	else return (query(k<<1,l,mid,x,mid)+query(k<<1|1,mid+1,r,mid+1,y))%mod;
}

void add(int k,int l,int r,int p,int v)
{
	if(l==r)
	{
		sum[k]=Mod(sum[k]+v);
		return;
	}
	if(tag[k]!=1)pushdown(k);
	int mid=l+r>>1;
	if(p<=mid)add(k<<1,l,mid,p,v);
	else add(k<<1|1,mid+1,r,p,v);
	sum[k]=Mod(sum[k<<1]+sum[k<<1|1]);
}

void mul(int k,int l,int r,int x,int y)
{
	if(x==l&&y==r)
	{
		sum[k]=Mod(sum[k]<<1);
		tag[k]=Mod(tag[k]<<1);
		return;
	}
	if(tag[k]!=1)pushdown(k);
	int mid=l+r>>1;
	if(y<=mid)mul(k<<1,l,mid,x,y);
	else if(x>mid)mul(k<<1|1,mid+1,r,x,y);
	else mul(k<<1,l,mid,x,mid),mul(k<<1|1,mid+1,r,mid+1,y);
	sum[k]=Mod(sum[k<<1]+sum[k<<1|1]);
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=getint(),m=getint();
	for(int i=1;i<=n;i++)b[i].l=getint(),b[i].r=getint();
	for(int i=1;i<=m;i++)a[i]=getint();
	sort(a+1,a+m+1);a[m+1]=0x3f3f3f3f;
	for(int i=1;i<=n;i++)
	{
		b[i].l=lower_bound(a+1,a+m+1,b[i].l)-a;
		b[i].r=upper_bound(a+1,a+m+1,b[i].r)-a-1;
	}
	sort(b+1,b+n+1);
	build(1,0,m);
	for(int i=1;i<=n;i++)
	{
		int v=query(1,0,m,b[i].l-1,b[i].r);
		add(1,0,m,b[i].r,v);
		if(b[i].r<m)mul(1,0,m,b[i].r+1,m);
	}
	cout<<query(1,0,m,m,m);
	return 0;
}
