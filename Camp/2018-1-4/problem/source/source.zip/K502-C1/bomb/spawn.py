import os
import time

T = 10000

for i in range(T):
	os.system("gen.py")
	os.system("bomb.exe")
	os.system("2.exe")
	s = os.system("fc bomb.out 2.out")
	if (s != 0):
		print("FOUND")
		break
	print("SUCCESS" + str(i))

time.sleep(1000)
