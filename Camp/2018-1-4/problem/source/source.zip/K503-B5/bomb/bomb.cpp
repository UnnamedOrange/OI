#include<bits/stdc++.h>
using namespace std;
vector<int> e[2000000],e2[2000000];
bool instk[2000000];
int dfn[2000000],low[2000000],belong[2000000],s[2000000],du[2000000],q[2000000],cnt[2000000],f[2000000],tot=0,scc=0,top=0;
inline void ins(int u,int v){
	e[u].push_back(v);
}
void dfs(int u,int fa){
	dfn[u]=low[u]=++tot;
	s[++top]=u;
	instk[u]=1;
	for (int i=0;i<e[u].size();i++){
		int v=e[u][i];
		if (v==fa) continue;
		if (!dfn[v]){
			dfs(v,u);
			low[u]=min(low[u],low[v]);
		}
		else if (instk[v]) low[u]=min(low[u],dfn[v]);
	}
	if (low[u]==dfn[u]){
		scc++;
		while (s[top]!=u){
			belong[s[top]]=scc;
			instk[s[top]]=0;
			top--;
		}
		belong[u]=scc;
		instk[u]=0;
		top--;
	}
}
inline void ins2(int u,int v){
	e2[u].push_back(v);
	du[v]++;
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		ins(u,v);
	}
	for (int i=1;i<=n;i++)
		if (!dfn[i]) dfs(i,0);
	for (int i=1;i<=n;i++){
		cnt[belong[i]]++;
		for (int j=0;j<e[i].size();j++){
			int v=e[i][j];
			if (belong[i]!=belong[v]) ins2(belong[i],belong[v]);
		}
	}
	int l=0,r=0;
	for (int i=1;i<=scc;i++)
		if (!du[i]) q[r++]=i;
	int ans=0;
	while (l<r){
		int u=q[l++];
		for (int i=0;i<e2[u].size();i++){
			int v=e[u][i];
			f[v]=max(f[v],f[u]+cnt[v]);
			ans=max(ans,f[v]);
			du[v]--;
			if (!du[v]) q[r++]=v;
		}
	}
	printf("%d\n",ans);
	return 0;
}
