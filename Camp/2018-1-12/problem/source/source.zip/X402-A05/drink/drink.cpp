#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0*clock()/CLOCKS_PER_SEC << std::endl
#define fst first
#define snd second

#ifndef __linux__
#define getchar getchar_unlocked
#endif
template <typename T> inline bool maximum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T> inline bool minimum(T &a, T b) { return a > b? a = b, 1 : 0; }
template <typename T> 
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 1e4 + 10;

int n, a[N];
int m, Map[N];

void Init()
{
	read(n);
	for(int i = 1; i <= n; ++i) Map[i] = read(a[i]);

	std::sort(Map + 1, Map + n + 1);
	m = std::unique(Map + 1, Map + n + 1) - Map - 1;
}

namespace SEGT
{
#define lc (h << 1)
#define rc (lc | 1)

	int cnt[N << 2];

	void clear()
	{
		for(int i = 1; i <= n << 2; ++i) cnt[i] = 0;
	}

	void modify(int h, int l, int r, int u)
	{
		++cnt[h];

		int mid = (l + r) >> 1;
		if(l ^ r)
			u <= mid? modify(lc, l, mid, u) : modify(rc, mid + 1, r, u);
	}

	int query(int h, int l, int r, int u)
	{
		if(l == r) return cnt[h];

		int mid = (l + r) >> 1;
		return (u > mid? query(rc, mid + 1, r, u) : 0) + query(lc, l, mid, u);
	}
}

long double Ans;
int stk[N];

int fpm(int e, int x)
{
	int res = 1;
	for(; x; x >>= 1){
		if(x & 1) res = res * e;
		e = e * e;
	}
	return res;
}

void solver()
{
	for(int l = 1; l <= n; ++l){
		for(int r = l; r <= n; ++r){
			int top = 0;
			for(int i = l; i <= r; ++i) 
				stk[++top] = a[i];

			std::sort(stk + 1, stk + top + 1);

			long double res = 0;
			for(int i = 1; i <= top; ++i)
				res = (res + stk[i]) / 2;

			Ans += res;
		}
	}
	printf("%.4LF\n", Ans/(n*n));
}

int main()
{
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);

	Init();
	solver();

	cerr_clock();
	return 0;
}
//TODO GKKAK
