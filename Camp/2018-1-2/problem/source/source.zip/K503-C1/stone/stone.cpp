# include <bits/stdc++.h>
# define 	N 		100010
# define 	ll 		long long
using namespace std;
struct node{
	ll a,b,p;
}im[N];
ll l,n,now[N],num[N],a,b,ans1,ans2,ans3,ans4;
bool use[N];
bool cmp(node x, node y){
	return x.p>y.p;
}
bool fight(ll nowa, ll nowb){
	ll tx=0,ty=0,c=0;
	for (ll i=1; i<=l; i++){
		now[i]=now[i]%(nowa+nowb);
		if (now[i]<nowa) {
			ty=ty+now[i]/nowb;
			continue;
		}
		if (now[i]<nowb) {
			tx=tx+now[i]/nowa;
			continue;
		}
		im[++c].a=now[i]/nowa, im[c].b=now[i]/nowb; im[c].p=im[c].a+im[c].b;
	}	
	sort(im+1,im+c+1,cmp);
	for (ll i=1; i<=c; i++)
		if (i%2==1) tx=tx+im[i].a;
			else ty=ty+im[i].b;
	if (tx>ty) return true; else return false;
}
void check(){
	l=0;
	for (ll i=1; i<=n; i++)
		if (use[i]==true) now[++l]=num[i];
 	bool f1=fight(a,b),f2=fight(b,a);
	if (f1==true&&f2==false) ans1++;
	if (f1==false&&f2==true) ans2++;
	if (f1==true&&f2==true) ans3++;
	if (f1==false&&f2==false) ans4++;	
}
void dfs(ll x){
	if (x>n) {
		check();
		return;
	}
	use[x]=false; dfs(x+1);
	use[x]=true; dfs(x+1);
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%lld%lld%lld",&n,&a,&b);
	for (ll i=1; i<=n; i++)
		scanf("%lld",&num[i]);
	dfs(1);
	printf("%lld %lld %lld %lld\n",ans1,ans2,ans3,ans4);
}
