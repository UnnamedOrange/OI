#include<bits/stdc++.h>
#define maxk 50
#define maxn 100010
#define maxm 200010
#define ll long long
#define mod 998244353
using namespace std;
int head[maxn], nxt[maxm], a[maxm], edge, dl[maxn], ru[maxn], n, k;
ll f[maxn][maxk], C[maxk][maxk], g[3000][3000], mi[3000];
void create(int u, int v)
{
	edge++; a[edge] = v; nxt[edge] = head[u]; head[u] = edge;
}
void spc()
{
	g[1][0] = 1;
	dl[1] = 1;
	int lef = 1, righ = 1;
	while (lef <= righ)
	{
		int u = dl[lef];
		for (int i = head[u]; i; i = nxt[i])
		{
			int v = a[i];
			for (int j = 1; j <= n; j++)
				g[v][j] = (g[v][j] + g[u][j - 1]) % mod;
			ru[v]--;
			if (ru[v] == 0) dl[++righ] = v;
		}
		lef++;
	}
	for (int i = 1; i <= n; i++)
	{
		mi[i] = 1;
		for (int j = 1; j <= k; j++)
			mi[i] = mi[i] * i % mod;
	}
	for (int i = 1; i <= n; i++)
	{
		ll ans = 0;
		for (int j = 1; j <= n; j++)
			ans = (ans + g[i][j] * mi[j]) % mod;
		printf("%lld\n", ans);
	}
}
int main()
{
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	int m;
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= m; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		create(u, v);
		ru[v]++;
	}
	if (n <= 2000 && m <= 5000)
	{
		spc();
		return 0;
	}
	C[0][0] = 1;
	for (int i = 1; i <= k; i++)
	{
		C[i][0] = 1;
		for (int j = 1; j <= k; j++)
			C[i][j] = (C[i-1][j-1] + C[i-1][j]) % mod;
	}
	int lef = 1, righ = 1;
	dl[1] = 1;
	f[1][0] = 1;
	while (lef<=righ)
	{
		int u = dl[lef];
		for (int i = head[u]; i; i = nxt[i])
		{
			int v = a[i];
			ru[v]--;
			if (ru[v] == 0) dl[++righ] = v;
			for (int i = 0; i <= k; i++)
				for (int j = 0; j <= i; j++)
				f[v][i] = (f[v][i] + f[u][j] * C[i][j] % mod) % mod;
		}
		lef++;
	}
	for (int i = 1; i <= n; i++)
		printf("%lld\n", f[i][k]);
	return 0;
}
