#include<bits/stdc++.h>
typedef unsigned int uint;
typedef unsigned long long ull;

namespace {

inline char read() {
    static const int IN_LEN = 1 << 18 | 1;
    static char buf[IN_LEN], *s, *t;
    return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
           s == t ? -1 : *s++;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
    (oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
    *oh++ = c;
}

template <typename T>
inline void print(T x) {
    static char buf[21], cnt;
    if (x != 0) {
        (x < 0) && (print('-'), x = -x);
        for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
        while (cnt) print(buf[cnt--]);
    } else {
        print('0');
    }
}

struct InputOutputStream {
    ~InputOutputStream() { fwrite(obuf, 1, oh - obuf, stdout); }

    template <typename T>
    inline InputOutputStream &operator>>(T &x) {
        static char c;
        static bool iosig;
        for (c = read(), iosig = false; !isdigit(c); c = read()) {
            if (c == -1) return *this;
            iosig |= c == '-';
        }
        for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
        iosig && (x = -x);
        return *this;
    }

    template <typename T>
    inline InputOutputStream &operator<<(const T &x) {
        print(x);
        return *this;
    }
} io;
}
using namespace std;
inline int rd(){
	char ch=getchar();int i=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getchar();}
	return i*f;
}
const int N=5e5+50,Mod=1e9+9;
int n,m,tot,a[N],mul_tag[N*4],sum[N*4];
struct Seg{
	int l,r;
	friend inline bool operator <(const Seg &a,const Seg &b){
		return a.l<b.l||(a.l==b.l&&a.r>b.r);
	}
}seg[N];
inline void upt(int k){
	sum[k]=(sum[k<<1]+sum[k<<1|1])%Mod;
}
inline void mul(int k,int v){
	mul_tag[k]=(ull)mul_tag[k]*v%Mod;
	sum[k]=(ull)sum[k]*v%Mod;
}
inline void pd(int k){
	 (mul_tag[k]!=1)&&
	 	(mul(k<<1,mul_tag[k]),mul(k<<1|1,mul_tag[k]),mul_tag[k]=1);
}
inline void add(int k,int l,int r,int pos,int v){
	if(l==r){ (sum[k]+=v)%=Mod ; return;}
	pd(k); int mid=(l+r)>>1;
	(pos<=mid) ? (add(k<<1,l,mid,pos,v)) :(add(k<<1|1,mid+1,r,pos,v));
	upt(k);
}
inline void mul(int k,int l,int r,int L,int R,int v){
	if(L<=l&&r<=R){mul(k,v); return;}
	pd(k); int mid=(l+r)>>1;
	if(R<=mid) mul(k<<1,l,mid,L,R,v);
	else if(L>mid) mul(k<<1|1,mid+1,r,L,R,v);
	else mul(k<<1,l,mid,L,R,v),mul(k<<1|1,mid+1,r,L,R,v);
	upt(k);
}
inline int query(int k,int l,int r,int L,int R){
	if(L<=l&&r<=R)return sum[k];
	pd(k); int mid=(l+r)>>1,rs=0;
	if(R<=mid)rs=query(k<<1,l,mid,L,R);
	else if(L>mid)rs=query(k<<1|1,mid+1,r,L,R);
	else rs=(query(k<<1,l,mid,L,R)+query(k<<1|1,mid+1,r,L,R))%Mod;
	upt(k); return rs;
}
inline int power(int a,int b){
	int rs=1;
	for(;b;b>>=1,a=(ull)a*a%Mod)if(b&1)rs=(ull)rs*a%Mod;
	return rs;
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=rd(); m=rd();
	for(int i=1;i<=n;i++) io>>seg[i].l>>seg[i].r;
	for(int i=1;i<=m;i++) io>>a[i];
	sort(a+1,a+m+1); m=unique(a+1,a+m+1)-a-1;
	for(int i=1;i<=n;i++){
		seg[i].l=lower_bound(a+1,a+m+1,seg[i].l)-a;
		seg[i].r=upper_bound(a+1,a+m+1,seg[i].r)-a-1;
		if(seg[i].l<=seg[i].r) seg[++tot]=seg[i];		
	} 
	if(tot)sort(seg+1,seg+tot+1);
	fill(mul_tag+1,mul_tag+N*4,1);
	add(1,0,m,0,1); 
	for(int i=1;i<=tot;i++){
		mul(1,0,m,seg[i].r,m,2);
		int t=query(1,0,m,seg[i].l-1,seg[i].r-1);
		add(1,0,m,seg[i].r,t);
	}
	printf("%d\n",(ull)query(1,0,m,m,m)*power(2,(n-tot))%Mod);
}
