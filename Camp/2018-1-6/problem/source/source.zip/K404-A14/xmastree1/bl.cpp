#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#include<map>
#define pb push_back
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int BLN=5010,N=100010,M=33000100;
struct node{
	int to,next;
};node edge[N*2];
int graph[N],tot;
void addedge(int i,int x,int y){
	edge[i].to=y;edge[i].next=graph[x];graph[x]=i;
}
int n,Q,ty;int lastans;
int a[N],last[N],pre[N];
int dfn[N],end[N],dfn_cnt,fa[N],stack[N],father[N][20];
int seg[M],lch[M],rch[M];int c[N],rt[N];int cnt1,cnt2,rt1[20][20],rt2[20][20];
vector<int> vec[N];
map<int,int> mp[N];
map<int,int>::iterator it;

struct BL{
	int	cnt[BLN][BLN];
	void dfs(int x){
		int i,y;
		for(i=graph[x];i;i=edge[i].next){
			y=edge[i].to;
			if(y==fa[x])	continue;
			fa[y]=x;dfs(y);
		}
	}
	void solve(){
		int i,x,y,l,r,opt,tmp;
		lastans=0;
		dfs(1);
		rep(i,1,n){x=i;while(x){cnt[x][a[i]]++;x=fa[x];}}
		while(Q--){
			scanf("%d",&opt);
			if(opt==1){
				scanf("%d%d%d",&x,&l,&r);
				x^=(ty*lastans);l^=(ty*lastans);r^=(ty*lastans);
				lastans=0;
				rep(i,l,r)	lastans+=(cnt[x][i]>0);	
				printf("%d\n",lastans);
			}
			else{
				scanf("%d%d",&x,&y);
				x^=(ty*lastans);y^=(ty*lastans);
				tmp=x;while(tmp){cnt[tmp][a[x]]--;tmp=fa[tmp];}
				a[x]=y;
				tmp=x;while(tmp){cnt[tmp][a[x]]++;tmp=fa[tmp];}
			}
		}
	}
};BL baoli;

/*int find(int x,int l,int r){
	int j,y;
	for(j=18;j>=0;j--)	if(father[x][j]){
		y=father[x][j];
		if(l<dfn[y]&&end[y]<r)	x=y;
	}
	return x;
}

void dfs(int x){
	int i,y;dfn[x]=++dfn_cnt;stack[dfn_cnt]=x;
	for(i=graph[x];i;i=edge[i].next){
		y=edge[i].to;
		if(y==fa[x])	continue;
		fa[y]=x;father[y][0]=x;dfs(y);
	}
	end[x]=dfn_cnt;
}

int modify(int pre,int l,int r,int x,int w){
	int now=++tot;
	if(l==r)	seg[now]=seg[pre]+w;
	else{
		int mid=l+r>>1;
		if(mid>=x){
			rch[now]=rch[pre];lch[now]=modify(lch[pre],l,mid,x,w);
		}
		else{
			lch[now]=lch[pre];rch[now]=modify(rch[pre],mid+1,r,x,w);
		}
		seg[now]=seg[lch[now]]+seg[rch[now]];
	}
	return now;
}

inline int lowbit(int x){return x&(-x);}

void modify(int x,int y,int w){
	if(!y)	return;
	for(;x<=n;x+=lowbit(x))	c[x]=modify(c[x],1,n,y,w);
}

void query(int l,int r,int fl,int fr,int dep){
	int i;
	if(fl<=l&&r<=fr){
		rep(i,1,cnt1)	lastans-=seg[rt1[dep][i]];
		rep(i,1,cnt2)	lastans+=seg[rt2[dep][i]];
		return;
	}
	int mid=l+r>>1;
	if(mid>=fr){
		rep(i,1,cnt1)	rt1[dep+1][i]=lch[rt1[dep][i]];
		rep(i,1,cnt2)	rt2[dep+1][i]=lch[rt2[dep][i]];
		query(l,mid,fl,fr,dep+1);
	}
	else if(mid+1<=fl){
		rep(i,1,cnt1)	rt1[dep+1][i]=rch[rt1[dep][i]];
		rep(i,1,cnt2)	rt2[dep+1][i]=rch[rt2[dep][i]];
		query(mid+1,r,fl,fr,dep+1);
	}
	else{
		rep(i,1,cnt1)	rt1[dep+1][i]=lch[rt1[dep][i]];
		rep(i,1,cnt2)	rt2[dep+1][i]=lch[rt2[dep][i]];
		query(l,mid,fl,fr,dep+1);
		rep(i,1,cnt1)	rt1[dep+1][i]=rch[rt1[dep][i]];
		rep(i,1,cnt2)	rt2[dep+1][i]=rch[rt2[dep][i]];
		query(mid+1,r,fl,fr,dep+1);
	}
}*/

int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("bl.out","w",stdout);
	int i,j,x,y,l,r,z,opt;
	scanf("%d%d%d",&n,&Q,&ty);
	rep(i,1,n)	scanf("%d",&a[i]);
	rep(i,1,n-1){
		scanf("%d%d",&x,&y);
		tot++;addedge(tot,x,y);
		tot++;addedge(tot,y,x);
	}
	if(n<=5000&&Q<=5000){baoli.solve();return 0;}
	/*dfs(1);
	rep(j,1,18)	rep(i,1,n)	father[i][j]=father[father[i][j-1]][j-1];
	rep(i,1,n)	mp[i][0]=n+1;
	rep(i,1,n){
		x=stack[i];pre[i]=last[a[x]];last[a[x]]=i;
		mp[a[x]][pre[i]]=i;mp[a[x]][i]=n+1;
		y=find(x,pre[i],n+1);
		vec[a[x]].pb(dfn[x]);
		vec[a[x]].pb(-dfn[fa[y]]);
	}
	rep(i,1,n){
		rt[i]=rt[i-1];
		rep(j,0,(int)vec[i].size()-1) if(vec[i][j]){
			if(vec[i][j]<0)	rt[i]=modify(rt[i],1,n,-vec[i][j],-1);
			else rt[i]=modify(rt[i],1,n,vec[i][j],1);
		}
	}
	while(Q--){
		scanf("%d",&opt);
		if(opt==1){
			scanf("%d%d%d",&x,&l,&r);
			x^=(ty*lastans);l^=(ty*lastans);r^=(ty*lastans);
			cnt1=cnt2=0;
			rt1[0][++cnt1]=rt[l-1];rt2[0][++cnt2]=rt[r];
			y=l-1;for(;y;y-=lowbit(y))	rt1[0][++cnt1]=c[y];
			y=r;for(;y;y-=lowbit(y))	rt2[0][++cnt2]=c[y];
			lastans=0;
			query(1,n,dfn[x],end[x],0);
			printf("%d\n",lastans);
		}
		else{
			scanf("%d%d",&x,&y);
			x^=(ty*lastans);y^=(ty*lastans);
			l=pre[dfn[x]];r=mp[a[x]][dfn[x]];
			if(end[x]<r){
				z=find(x,l,r);
				modify(a[x],dfn[x],-1);
				modify(a[x],dfn[fa[z]],1);
			}
			mp[a[x]][l]=r;pre[r]=l;
			mp[a[x]].erase(mp[a[x]].lower_bound(dfn[x]));
			a[x]=y;
			it=(--mp[a[x]].lower_bound(dfn[x]));
			l=it->first;r=it->second;
			if(end[x]<r){
				z=find(x,l,r);
				modify(a[x],dfn[x],1);
				modify(a[x],dfn[fa[z]],-1);
			}
			pre[r]=dfn[x];
			pre[dfn[x]]=l;
			mp[a[x]][dfn[x]]=r;
			mp[a[x]][l]=dfn[x];
		}
	}*/			
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
