#include<bits/stdc++.h>
#define maxn 100010
#define ll long long
#define mod 998244353
using namespace std;
int p[maxn], ch[maxn], use[maxn], visit[maxn], ans, n, flag = 1;
void sc()
{
	for (int i = 1; i <= n; i++)
		visit[i] = 0;
	int cur = 0;
	for (int i = 1; i <= n; i++)
		if (visit[i] == 0)
		{
			int tot = 0, tmp = i;
			cur++;
			while (visit[tmp] == 0)
			{
				visit[tmp] = cur;
				tot++;
				tmp = ch[tmp]; 
			}
			if (tmp != i || tot % 2) return;
		}
	ans++;
}
void work(int dep)
{
	if (dep > n) sc();
	else
	{
		if (p[dep])
		{
			ch[dep] = p[dep];
			work(dep + 1);
		}
		else
		for (int i = 1; i <= n; i++)
		{
			if (i == dep || use[i]) continue;
			ch[dep] = i; use[i] = 1;
			work(dep + 1);
			use[i] = 0;
		}
	}
}
void subtask()
{
	int tmp = n / 2;
	ll ans = 1;
	for (int i = 1; i <= tmp; i++)
		ans = ans * (2 * i - 1) % mod;
	ans = ans * ans % mod;
	printf("%lld\n", ans);
}
int main()
{
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	scanf("%d", &n);
	if (n % 2)
	{
		puts("0");
		return 0;
	}
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &p[i]);
		if (p[i])
		{
			use[p[i]] = 1;
			flag = 0;
		}
	}
	if (flag)
	{
		subtask();
		return 0;
	}
	work(1);
	printf("%d\n", ans);
	return 0;
}
