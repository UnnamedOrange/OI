#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int N=100010;
char s[N];
int cnt[30],vis[30];
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T,n,i,tmp;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		scanf("%s",s+1);
		tmp=1;
		rep(i,1,n)	if(s[i]!=s[n-i+1])	tmp=0;
		if(!tmp){printf("1\n");continue;}
		memset(vis,0,sizeof(vis));memset(cnt,0,sizeof(cnt));
		rep(i,1,n)	vis[s[i]-'a']=1,cnt[s[i]-'a']++;
		tmp=0;
		rep(i,0,25)	tmp+=vis[i];
		if(tmp==1){printf("-1\n");continue;}
		if(n%2==0||tmp>2){printf("2\n");continue;}
		if(cnt[s[n/2+1]-'a']==1){printf("-1\n");continue;}
		tmp=0;
		rep(i,1,n-1)	if(s[i]==s[i+1])	tmp=1;
		if(!tmp){printf("-1\n");continue;}
		else {printf("2\n");continue;}
	}
	return 0;
}
