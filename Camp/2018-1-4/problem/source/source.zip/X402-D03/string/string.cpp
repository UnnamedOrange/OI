#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXL = 110;
const ll MOD = 998244353;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int m;
namespace SP {
	int t[110];
	inline void getfail(char s[], int fail[], int n) {
		int i;
		fail[1] = 0;
		for(i = 2; i <= n; i++) {
			int f = fail[i-1];
			while(f && s[f+1] != s[i]) f = fail[f];
			if(s[f+1] == s[i]) f++;
			fail[i] = f;
		}
		//for(i = 1; i <= n; i++) printf("%d ", fail[i]);
		//printf("\n");
		for(i = 1; i <= n; i++) {
			t[i] = fail[i];
			int &f = t[i];
			while(f && s[f+1] == s[i+1]) f = fail[f];
			if(s[f+1] != s[i+1]) f++;
		}
		for(i = 1; i <= n; i++) fail[i] = t[i];
		//exit(0);
	}
	inline void getban(char s[], bool ban[], int n) {
		int i, j;
		for(i = (n+1)>>1; i <= n; i++) {
			for(j = i+1; j <= n; j++) 
				if(s[j] == s[2*i-j+1]) break;
			if(j <= n) continue;
			ban[i] = true;
		}
	}
	inline void update(ll &cur, ll val) {
		cur = cur + val;
		if(cur >= MOD) cur -= MOD;
	}
	ll dp[510][110][110], ans;
	int n, f1[110], f2[110];
	char s1[110], s2[110];
	bool b1[110], b2[110];
	inline ll qpow(ll a, ll b) {
		ll res = 1;
		while(b) {
			if(b & 1LL) res = res * a % MOD;
			b >>= 1, a = a * a % MOD;
		}
		return res;
	}
	void solve() {
		int i, j, k;
		scanf("%s", s1+1);
		n = strlen(s1+1);
		memcpy(s2, s1, sizeof(s1));
		reverse(s2+1, s2+n+1);
		for(i = 1; i <= n; i++) s2[i] = ((s2[i]-'0')^1)+'0';
		getfail(s1, f1, n);
		getfail(s2, f2, n);
		getban(s1, b1, n);
		getban(s2, b2, n);

		/*for(i = 1; i <= n; i++) printf("%c", s2[i]);
		printf("\n");
		for(i = 1; i <= n; i++) printf("%d ", f1[i]);
		printf("\n");
		for(i = 1; i <= n; i++) printf("%d ", f2[i]);
		printf("\n");*/
		dp[0][0][0] = 1;
		for(i = 0; i < m; i++) 
			for(j = 0; j < n; j++) 
				for(k = 0; k < n; k++) {
					if(s1[j+1] == '0') {
						if(s2[k+1] == '0') {
							update(dp[i+1][j+1][k+1], dp[i][j][k]);
							update(dp[i+1][f1[j]][f2[k]], dp[i][j][k]);
						}
						else {
							update(dp[i+1][j+1][f2[k]], dp[i][j][k]);
							update(dp[i+1][f1[j]][k+1], dp[i][j][k]);
						}
					}
					else {
						if(s2[k+1] == '0') {
							update(dp[i+1][f1[j]][k+1], dp[i][j][k]);
							update(dp[i+1][j+1][f2[k]], dp[i][j][k]);
						}
						else {
							update(dp[i+1][f1[j]][f2[k]], dp[i][j][k]);
							update(dp[i+1][j+1][k+1], dp[i][j][k]);
						}
					}
				}
		//printf("%lld\n", dp[m-1][3][1]);
		for(j = 0; j < n; j++) 
			for(k = 0; k < n; k++) {
				if(b1[j] || b2[k]) continue;
			//	printf("%d %d: %lld\n", j, k, dp[m][j][k]);
				update(ans, dp[m][j][k]);
			}
		//printf("%lld\n", ans);
		ll ALL = qpow(2, m);
		printf("%lld\n", ((ALL-ans)%MOD+MOD)%MOD);
		return;
	}
}

int n;
int l[7], ans;
char s[7][MAXL];
bool S[50];

void dfs(int cur) {
	if(cur == m+1) {
		int i, j, k;
		for(i = m+1; i <= 2*m; i++) S[i] = S[2*m-i+1]^1;
		for(i = 1; i <= n; i++) {
			for(j = 1; j+l[i]-1 <= 2*m; j++) {
				for(k = 1; k <= l[i]; k++) 
					if(S[j+k-1] != s[i][k]-'0') break;
				if(k > l[i]) break;
			}
			if(j+l[i]-1 > 2*m) return;
		}
		ans++;
		return;
	}
	S[cur] = true;
	dfs(cur+1);
	S[cur] = false;
	dfs(cur+1);
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);

	int i;

	n = read(), m = read();
	if(n == 1) {
		SP::solve();
		return 0;
	}

	for(i = 1; i <= n; i++) {
		scanf("%s", s[i]+1);
		l[i] = strlen(s[i]+1);
	}

	dfs(1);
	printf("%d\n", ans);
	return 0;
}
