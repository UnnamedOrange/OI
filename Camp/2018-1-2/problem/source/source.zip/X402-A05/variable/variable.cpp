#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>

#define REP(i, t) for(int i = 0, i##E = (t); i < i##E; ++i)
typedef long long LL;

template <class T> inline bool minimum(T &a, T b) {return a > b? a = b, 1 : 0;}
template <class T> inline bool maximum(T &a, T b) {return a < b? a = b, 1 : 0;}
template <class T> inline T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = 1;
	for(;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return x = f? -x : x;
}

const int N = 5e2 + 10;
const LL inf = 4e18;

int n; LL W, w[N], ans;

int a[N][6], x[N], y[N], z[N], p;
int l[N], r[N], c[N], q;

int main()
{
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);

	int T; scanf("%d", &T);
	while(T--){
		ans = inf;

		read(n), read(W), read(p), read(q);
		for(int i = 1; i <= p; ++i){
			read(x[i]), read(y[i]), read(z[i]);
			REP(j, 6) read(a[i][j]);
		}
		for(int i = 1; i <= q; ++i)
			read(l[i]), read(r[i]), read(c[i]);

		REP(s, 1<<n){
			for(int i = 1; i <= n; ++i)
				if(s & (1 << (i-1))) w[i] = W;
				else w[i] = -W;
			bool flag = true;
			for(int i = 1; i <= q; ++i){
				if(!c[i] && w[l[i]] > w[r[i]]) { flag = false; break; }
				if(c[i] == 1 && w[l[i]] != w[r[i]]) { flag = false; break; }
				if(c[i] == 2 && w[l[i]] >= w[r[i]]) { flag = false; break; }
			}
			if(!flag) continue;
			LL ret = 0;
			for(int i = 1; i <= n; ++i) ret += w[i];
			for(int i = 1; i <= p; ++i){
				LL h = 1LL*a[i][0]*abs(w[x[i]]+w[y[i]]) + 1LL*a[i][1]*abs(w[y[i]]+w[z[i]])+
					1LL*a[i][2]*abs(w[z[i]]+w[x[i]]) + 1LL*a[i][3]*(w[x[i]]+w[y[i]]) +
					1LL*a[i][4]*(w[y[i]]+w[z[i]]) + 1LL*a[i][5]*(w[z[i]]+w[x[i]]);
				ret += h;
//Hi=ai|w[xi]+w[yi]|+bi|w[yi]+w[zi]|+ci|w[zi]+w[xi]|+di(w[xi]+w[yi])+ei(w[yi]+w[zi])+fi(w[zi]+w[xi])
			}
			minimum(ans, ret);
		}

		printf("%lld\n", ans);
	}
	return 0;
}
