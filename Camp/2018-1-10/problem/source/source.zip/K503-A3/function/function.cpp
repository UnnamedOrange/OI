#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
#define pr pair<int, int>
#define x first
#define y second
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while (!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while (isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n *= sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 1222222;
int T, n;
ll f[N], p[N], fac[N], sum[N];
vector<ll> prime;

ll mut(ll a, ll b){
	ll y = 1, t = a;
	for (; b; b >>= 1, t = t * t)
		if (b & 1) y = y * t;
	return y;
}

int main(){
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	rep(i, 1, N - 1) p[i] = i; f[1] = 1;
	rep(i, 2, N - 1){
		if (p[i] == i) prime.pb(i), f[i] = 3, fac[i] = 1;
		for (int j = 0; j < prime.size()&&prime[j] * i < N; ++j){
			p[prime[j]*i] = prime[j];
			if (i % prime[j] == 0){
				fac[prime[j]*i] = fac[i] + 1;
				break;
			} else fac[prime[j]*i] = 1;
		}
	}
	rep(i, 1, N - 1) if (p[i] != i){
		if (mut(p[i], fac[i]) != i) 
			f[i] = f[mut(p[i], fac[i])] * f[i/mut(p[i], fac[i])];
		else f[i] = f[i/p[i]] + 2;
	}
	rep(i, 1, N - 1) sum[i] = sum[i-1] + f[i];
	read(T);
	while(T--){
		read(n);
		cout << sum[n] << endl;
	}	
	return 0;
}
