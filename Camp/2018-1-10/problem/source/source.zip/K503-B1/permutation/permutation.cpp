#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
const long long mod=998244353;
int n,a[maxn],b[maxn],ha[maxn],vis[maxn],tot,ans;
long long anss;
int i,j,k;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void dfs(int x){
	if (vis[x]==1) return;
	tot++; vis[x]=1;
	dfs(b[x]);
}
void check(){
	int i;
	for (i=1;i<=n;i++) vis[i]=0;
	for (i=1;i<=n;i++){
		if (vis[i]==0){
			tot=0; dfs(i);
			if (tot%2==1) return;
		}
	}
	ans++;
}
void work(int x){
	int i;
	if (x>n){
		check();
		return;
	}
	if (a[x]!=0){
		b[x]=a[x]; work(x+1);
	}
	else{
		for (i=1;i<=n;i++){
			if (ha[i]==0){
				ha[i]=1;
				b[x]=i;
				work(x+1);
				ha[i]=0;
			}
		}
	}
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=read();
	if (n<=8){
		for (i=1;i<=n;i++){
			a[i]=read();
			ha[a[i]]=1;
		}
		work(1);
		printf("%d\n",ans);
	}
	else{
		if (n%2==1){
			printf("0\n");
			return 0;
		}
		anss=1;
		for (i=1;i<=n;i++){
			if (i%2==1){
				anss=(anss*i)%mod;
				anss=(anss*i)%mod;
			}
		}
		printf("%lld\n",anss);
	}
	return 0;
}
// 0 1 0 9 0 225 0 11025 0 893025
// 2:  1*1
// 4:  1*1*3*3
// 6:  1*1*3*3*5*5
// 8:  1*1*3*3*5*5*7*7
// 10: 1*1*3*3*5*5*7*7*9*9
