#include<bits/stdc++.h>
using namespace std;
struct Info{
	int nu,ne;
}a[100010];
int b[100010]={0},n,q,t,num=0,f[100010],c[100010],x,y,opt,z,lan=0;
struct tree{
	int l,r,ta,nu;
}h[1000010];
void jb(int x,int y){
	a[++num].nu=y;a[num].ne=b[x];b[x]=num;
}
void dfs(int x,int fa){
	f[x]=fa;
	for (int y=b[x];y;y=a[y].ne){
		if (a[y].nu!=fa)
			dfs(a[y].nu,x);
	}
}
void build(int nu,int l,int r){
	h[nu].l=l;h[nu].r=r;h[nu].nu=0;h[nu].ta=0;
	if (l!=r){
		build(nu*2,l,(l+r)/2);
		build(nu*2+1,(l+r)/2+1,r);
	}
}
void pu(int x){
	if (h[x].ta==1){h[x].nu=0;h[x].ta=0;if (h[x].l!=h[x].r){h[x*2].ta=1;h[x*2+1].ta=1;}}
}
int que(int nu,int l,int r){
	pu(nu);
	if (h[nu].l==l&&h[nu].r==r) return h[nu].nu;
	int mid=(h[nu].l+h[nu].r)/2,an=0;
	if (l<mid) an+=que(nu*2,l,min(mid,r));
	if (r>=mid) an+=que(nu*2+1,max(mid+1,l),r);
	return an;
}
void fy(int nu,int l,int r){
	pu(nu);
	if (h[nu].l==l&&h[nu].r==r){h[nu].ta=1;return ;}
	int mid=(h[nu].l+h[nu].r)/2;
	if (l<mid) fy(nu*2,l,min(mid,r));
	if (r>=mid) fy(nu*2+1,max(mid+1,l),r);
}
void add(int nu,int l){
	pu(nu);
	if (h[nu].l==h[nu].r){if (h[nu].nu==0) h[nu].nu++;return ;}
	if (l<=(h[nu].l+h[nu].r)/2) add(nu*2,l);else add(nu*2+1,l);
	pu(nu*2);pu(nu*2+1);
	h[nu].nu=h[nu*2].nu+h[nu*2+1].nu;
}
void dfs(int x,int l,int r){
	if (c[x]>=l&&c[x]<=r) add(1,c[x]);
	for (int y=b[x];y;y=a[y].ne)if (a[y].nu!=f[x]) dfs(a[y].nu,l,r);
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d %d %d",&n,&q,&t);
	for (int i=1;i<=n;i++)scanf("%d",&c[i]);
	for (int i=1;i<n;i++){
		scanf("%d %d",&x,&y);
		jb(x,y);jb(y,x);
	}
	build(1,1,n);
	dfs(1,0);
	while (q--){
		scanf("%d",&opt);
		if (opt==2){scanf("%d %d",&x,&y);c[x]=y;}
		if (opt==1){
			scanf("%d %d %d",&x,&y,&z);
			if (t==1){x=x xor lan;y=y xor lan;z=z xor lan;}
			dfs(x,y,z);
			lan=que(1,y,z);
			fy(1,y,z);
			printf("%d\n",lan);
		}
	}
}
