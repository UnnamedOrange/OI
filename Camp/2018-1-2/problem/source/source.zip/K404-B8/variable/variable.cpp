#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
const int maxn = 29;
const ll inf = 1e15;

int a[maxn];
struct rel{int x,y,opt;}b[maxn];
struct task{int x,y,z;ll a,b,c,d,e,f;}c[maxn];
int n,W,p,q,T;
ll ans;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

bool check()
{
	for(int i=1;i<=q;i++)
	{
		if(b[i].opt==0&&!(a[b[i].x]<=a[b[i].y])) return false;
		if(b[i].opt==1&&!(a[b[i].x]==a[b[i].y])) return false;
		if(b[i].opt==2&&!(a[b[i].x]<a[b[i].y])) return false;
	}
	return true;
}
ll calc()
{
	ll res=0;
	for(int i=1;i<=n;i++) res+=a[i];
	for(int i=1;i<=p;i++)
		res+=c[i].a*abs(a[c[i].x]-a[c[i].y])+c[i].b*abs(a[c[i].y]-a[c[i].z])+c[i].c*abs(a[c[i].z]-a[c[i].x])
			+c[i].d*(a[c[i].x]-a[c[i].y])+c[i].e*(a[c[i].y]-a[c[i].z])+c[i].f*(a[c[i].z]-a[c[i].x]);
	return res;
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read();W=read();p=read();q=read();
		for(int i=1;i<=p;i++) c[i]=(task){read(),read(),read(),read(),read(),read(),read(),read(),read()};
		for(int i=1;i<=q;i++) b[i]=(rel){read(),read(),read()};
		int mr=(1<<n)-1;ans=inf;
		for(int i=0;i<=mr;i++)
		{
			for(int j=1;j<=n;j++) if(i&(1<<j>>1)) a[j]=-W;else a[j]=W;
			if(check()) ans=min(ans,calc());
		}
		printf("%d\n",ans);
	}
	return 0;
}
