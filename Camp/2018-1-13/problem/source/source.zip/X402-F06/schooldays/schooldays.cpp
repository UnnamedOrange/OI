#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmax(int &x,int y){return y>x?(x=y,1):0;}
inline bool chkmin(int &x,int y){return y<x?(x=y,1):0;}
const int inf=0x3f3f3f3f,mod=1e9+7;
int n;
inline void add(int &x,int y){
	x+=y;
	if(x>mod) x-=mod;
}
namespace bf{
	const int maxn=2000+10;
	int c[maxn],d[maxn];
	int l[maxn][maxn],r[maxn][maxn];
	int dp[maxn],f[maxn];
	void input(){
		REP(i,1,n) c[i]=read(),d[i]=read();
	}
	void init(){
		memset(dp,-1,sizeof(dp));
		memset(f,0,sizeof(f));
		f[0]=1;dp[0]=0;
	}
	void work(){
		input();
		init();
		REP(i,1,n){
			l[i][i]=c[i],r[i][i]=d[i];
			REP(j,i+1,n)
				l[i][j]=max(l[i][j-1],c[j]),r[i][j]=min(r[i][j-1],d[j]);
		}
		REP(i,1,n)
			REP(j,0,i-1){
				if(i-j<l[j+1][i] || i-j>r[j+1][i]) continue;
				if(chkmax(dp[i],dp[j]+1)) f[i]=f[j];
				else if(dp[i]==dp[j]+1) add(f[i],f[j]);
			}
		if(dp[n]==-1) printf("-1\n");
		else printf("%d %d\n",dp[n],f[n]);
	}
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
#endif
	n=read();
	if(n<=2000){
		bf::work();
		return 0;
	}
	printf("-1\n");
	return 0;
}
