#include<bits/stdc++.h>
using namespace std;
const int maxn=100100;
char str[maxn];
int main(){
	return 0;
}
