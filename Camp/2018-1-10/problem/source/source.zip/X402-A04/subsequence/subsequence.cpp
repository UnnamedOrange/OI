#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=350;
const int inf=0x3f3f3f3f;
int f[N][N],nex1[N][N],nex2[N][N];
int n,m,K,a[N],b[N],c[N];

void wj()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
}
int main()
{
	wj();
	int i,j,k,opt,T;
	n=read(); m=read(); K=read();
	for(i=1;i<=n;++i) a[i]=read();
	for(i=1;i<=m;++i) b[i]=read();
	for(i=0;i<=n;++i) for(k=1;k<=K;++k)
	{
		nex1[i][k]=i+1;
		while(nex1[i][k]<=n&&a[nex1[i][k]]!=k) nex1[i][k]++;
	}	
	for(i=0;i<=m;++i) for(k=1;k<=K;++k)
	{
		nex2[i][k]=i+1;
		while(nex2[i][k]<=m&&b[nex2[i][k]]!=k) nex2[i][k]++;
	}
	/*if(K==2&&n<=18&&m<=18)
	{
		int ans=0;
		for(int len=1;len<=max(n,m)+1;++len)
		{
			int tot=1<<len;
			for(int s=0;s<tot;++s)
			{
				for(i=1;i<=len;++i) c[i]=((s>>i-1)&1)+1;
				bool can=1;
				i=1; j=1;
				while(j<=len)
				{
					while(i<=n&&a[i]!=c[j]) i++;
					if(i==n+1) break;
					j++;
				}
				if(j==len+1) can=0;
				i=1; j=1;
				while(j<=len)
				{
					while(i<=m&&b[i]!=c[j]) i++;
					if(i==m+1) break;
					j++;
				}
				if(j==len+1) can=0;
				if(can) {ans=len;break;}
			}
			if(ans) break;
		}
		printf("%d\n",ans);
		return 0;
	}*/

	memset(f,inf,sizeof(f));
	f[n+1][m+1]=0;

	for(i=1;i<=K;++i) nex1[n+1][i]=n+1,nex2[m+1][i]=m+1;
	for(i=n+1;i>=0;--i) for(j=m+1;j>=0;--j) 
	{
		if(i==n+1&&j==m+1) continue;
		if(i!=n+1&&j!=m+1&&a[i]!=b[j]) continue;
		for(k=1;k<=K;++k)
		{
			f[i][j]=min(f[i][j],f[nex1[i][k]][nex2[j][k]]+1);
			//if(nex1[i][k]==n+1&&nex2[j][k]==m+1) cerr<<i<<' '<<j<<' '<<k<<endl;
		}
	}
	printf("%d\n",f[0][0]);
	return 0;
}
