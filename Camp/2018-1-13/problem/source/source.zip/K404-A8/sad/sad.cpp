#include <cstdio>

const int MAXN = 100000 + 10;
int N;
char S[MAXN];
int ans;

int main() {
	freopen( "sad.in", "r", stdin );
	freopen( "sad.out", "w", stdout );
	register int i;
	scanf( "%d", &N ); getchar();
	gets( S + 1 );
	for( i = 1; i <= N; ++i )
		ans += S[i] == '1';
	printf( "%d\n", ans );
	return 0;
}
