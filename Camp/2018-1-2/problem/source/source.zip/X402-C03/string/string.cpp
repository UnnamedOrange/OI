#include<bits/stdc++.h>
using namespace std;

const int maxn=1e5+10;
int t,n,ans;
char s[maxn];

inline bool hw(){
	for(int i=0,j=n-1;i<j;++i,--j)
		if(s[i]!=s[j])
			return false;
	return true;
}
inline bool judge(){
	for(int i=0,j=n-1;i<j;++i,--j)
		if(s[i]!=s[0]||s[j]!=s[0])
			goto flag1;
	return true;
	flag1:
	if(!hw())
		goto flag2;
	for(int i=0;i<n;i+=2)
		if(s[i]!=s[0])
			goto flag2;
	for(int i=1;i<n;i+=2)
		if(s[i]!=s[1])
			goto flag2;
	return true;
	flag2:
	return false;
}

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d%s",&n,s);
		if(judge()){
			puts("-1");
			continue;
		}
		if(hw())
			puts("2");
		else
			puts("1");
	}
	return 0;
}
