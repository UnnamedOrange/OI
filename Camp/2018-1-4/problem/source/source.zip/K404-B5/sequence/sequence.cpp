#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 27;

int n;
int a[MAXN];

map < AR(int), int > mp;
map < AR(int), int > ::iterator it;
set < AR(int) > vis;



void init ();
void input ();
void work ();

int dfs ( AR(int) &now );

void swap ( AR(int) &now, int p )
{
	int p2 = p >> 1;
	lp ( i, 0, p2 ){
		swap ( now[i], now[p-i] );
//		now[i] ^= now[p-i], now[p-i] ^= now[i], now[i] ^= now[p-i];
	}
}



int main ()
{
	init ();
	
	int T;
	scanf ( "%d", &T );
	while ( T-- ){
		input ();
		work ();
	}
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "sequence" );
}

void input ()
{
	scanf ( "%d", &n );
	lpi ( i, 1, n ) scanf ( "%d", &a[i] );
}

void work ()
{
	AR(int) tar;
	lpi ( i, 1, n ) tar.PB ( i );
	mp[tar] = 0;
	
	AR(int) ar;
	lpi ( i, 1, n ) ar.PB ( a[i] );
	
	cout << dfs ( ar ) << endl;
}



int dfs ( AR(int) &now )
{
//	lp ( i, 0, n ) cerr << now[i] << " ";
//	cerr << endl;
	
	if ( ( it = mp.find ( now ) ) != mp.end () ) return it->second;
	if ( vis.find ( now ) != vis.end () ) return INF;
	vis.insert ( now );
	
	AR(int) v;
	int ans = INF;
	lp ( i, 1, n ){
		v = now;
//		cerr << "--- " << i << endl;
//		lp ( j, 0, n ) cerr << v[j] << " ";
//		cerr << endl;
		swap ( v, i );
//		lp ( j, 0, n ) cerr << v[j] << " ";
//		cerr << endl;
//		cerr << "***" << endl;
		ans = min ( ans, dfs ( v ) + 1 );
	}
	
	mp[now] = ans;
	
	return ans;
}
