#include <bits/stdc++.h>
#define N 10000010
#define ll long long
using namespace std;
int t,n,d[N],p[N],isp[N],mu[N],q[N],num[N],cnt(0);
ll ans,s[N];

void pre(){
	mu[1]=d[1]=1;
	for (int i=2;i<N;i++){
		if (!isp[i]){
			p[++cnt]=i;
			mu[i]=-1; d[i]=2; q[i]=i; num[i]=1;
		}
		for (int j=1;j<=cnt && p[j]*i<N;j++){
			isp[p[j]*i]=1;
			if (i%p[j])
				mu[i*p[j]]=-mu[i],q[i*p[j]]=p[j],num[i*p[j]]=1,d[i*p[j]]=d[i]*2;
			else
				mu[i*p[j]]=0,q[i*p[j]]=q[i]*p[j],num[i*p[j]]=num[i]+1,d[i*p[j]]=d[i/q[i]]*(num[i]+2);
		//	printf("%d %d\n",i*p[j],p[j]);
			if (i%p[j]==0) break;
		}
	}
	s[1]=1;
	for (int i=2;i<N;i++)
		s[i]=s[i-1]+(ll)d[i]*d[i];
	/*puts("");
	for (int i=2;i<N;i++){
	//	mu[i]+=mu[i-1];
		d[i]=0;
		for (int j=1;j*j<=i;j++)
			if (i%j==0)
				d[i]+=(j*j==i)?1:2;
	//	d[i]+=d[i-1];
	}*/
//	for (int i=2;i<N;i++)
//		printf("%d ",mu[i]);
//	puts("");
}

int main(){
//	cout << sizeof(mu)*8/1024/1024;
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	pre();
	scanf("%d",&t);
	while (t--){
		scanf("%d",&n);
		ans=0;
		for (int i=1;i<=n;i++)
			ans+=(ll)mu[i]*s[n/i];
		printf("%lld\n",ans);
	}
	return 0;
}
