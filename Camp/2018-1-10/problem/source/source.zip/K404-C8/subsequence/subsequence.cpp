#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
const int N=4005;

int n,m,k,a[N],b[N],ans,inf;
int pa[N][N],pb[N][N],dp[N][N];


int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);

	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++) scanf("%d",&a[i]);
	for (int i=1;i<=m;i++) scanf("%d",&b[i]);

	for (int i=1;i<=k;i++) pa[n+1][i]=pa[n][i]=n+1;
	for (int i=n-1;i>=0;i--) 
	{
		for (int j=1;j<=k;j++) pa[i][j]=pa[i+1][j];
		pa[i][a[i+1]]=i+1;
	}
	
	for (int i=1;i<=k;i++) pb[m+1][i]=pb[m][i]=m+1;
	for (int i=m-1;i>=0;i--) 
	{
		for (int j=1;j<=k;j++) pb[i][j]=pb[i+1][j];
		pb[i][b[i+1]]=i+1;
	}
	
	memset(dp,0x3f3f3f3f,sizeof(dp));
	ans=dp[0][0],dp[0][0]=0;
	
	for (int x=0;x<=n+1;x++)
		for (int y=0;y<=m+1;y++)
			for (int i=1;i<=k;i++) 
			dp[pa[x][i]][pb[y][i]]=min(dp[pa[x][i]][pb[y][i]],dp[x][y]+1);
	
	printf("%d\n",dp[n+1][m+1]);
	return 0;
}

/*
3 2 2
1 2 1
2 2

8 10 2
1 2 1 2 1 2 1 2
1 2 1 2 1 2 1 2 1 2
*/

