#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;
const long long Mod=1000000007;
long long n,cnt,map[1001000][2],dp[1001000],dep[1001000],Max;
struct node
{
	long long v;
	node *next;
}pool[50000010],*h[1001000];
void addedge(long long u,long long v)
{
	node *p=&pool[++cnt];
	p->v=v;p->next=h[u];h[u]=p;
}
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%lld",&n);
	for(long long i=1;i<=n;i++) scanf("%lld%lld",&map[i][0],&map[i][1]);
	for(long long i=1;i<=n;i++)
	{
		long long Min=map[i][0],Max=map[i][1];
		for(long long j=i+Min-1;j<i+Max;j++)
		{
			long long len=j-i+1;
			Min=max(Min,map[j][0]);
			Max=min(Max,map[j][1]);
			if(len<Min||len>Max) continue;
			addedge(i,j);
		}
	}
	dp[0]=1;
	dep[0]=0;
	for(long long i=0;i<=n;i++)
	{
		if(!dp[i]) continue;
		for(node *p=h[i+1];p;p=p->next)
		{
			long long v=p->v;
			if(dep[v]>dep[i]+1) continue;
			if(dep[v]==dep[i]+1) dp[v]+=dp[i];
			else dep[v]=dep[i]+1,dp[v]=dp[i];
			dp[v]%=Mod;
		}
	}
	if(dp[n]==0) printf("-1");
	else printf("%lld %lld",dep[n],dp[n]%Mod);
	return 0;
}
