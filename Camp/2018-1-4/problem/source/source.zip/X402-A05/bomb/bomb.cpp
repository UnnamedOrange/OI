#include <bits/stdc++.h>

#define REP(i, t) for(int i = 0, i##E = (t); i < i##E; ++i)

template <class T> inline T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = 1;
	for(;  isdigit(c); c = getchar()) x = x*10 + c-'0';
	return x = f? -x : x;
}
template <class T> inline bool maximum(T &a, T b) {return a < b? a = b, 1 : 0;}
template <class T> inline bool minimum(T &a, T b) {return a > b? a = b, 1 : 0;}

const int N = 1e6 + 10;

int n, m;
struct Graph
{
	int e, Begin[N], to[N], Next[N];

	void add_edge(int u, int v)
	{
		to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
	}
}G, A;

int dfn[N], low[N], dfs_clock, S[N], top;
int sccid[N], tot, size[N], degree[N];

void Tarjan(int u, int fa)
{
	dfn[u] = low[u] = ++dfs_clock;
	S[++top] = u;

	for(int i = G.Begin[u]; i; i = G.Next[i]){
		int v = G.to[i];
		if(v == fa) continue;
		if(!low[v]) Tarjan(v, u), minimum(low[u], low[v]);
		else if(!sccid[v]) minimum(low[u], low[v]);
	}

	if(low[u] == dfn[u]){
		for(++tot;;){
			int x = S[top--];
			sccid[x] = tot; ++ size[tot];
			if(x == u) break;
		}
	}

	return ;
}

int q[N], l, r, dp[N];
void Topsort()
{
	l = 1, r = 0;
	for(int i = 1; i <= tot; ++i)
		if(!degree[i]) q[++r] = i, dp[i] = size[i];

	while(l <= r){
		int u = q[l++];
		for(int i = A.Begin[u]; i; i = A.Next[i]){
			int v = A.to[i];
			maximum(dp[v], dp[u] + size[v]);
			if(!(--degree[v])) q[++r] = v;
		}
	}

	int ans = 0;
	for(int i = 1; i <= tot; ++i) maximum(ans, dp[i]);
	printf("%d\n", ans);

	return ;
}

int main()
{
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);

	read(n), read(m);
	for(int i = 1; i <= m; ++i){
		int u, v; 
		read(u), read(v); G.add_edge(u, v);
	}

	for(int i = 1; i <= n; ++i) if(!dfn[i]) Tarjan(i, i);
	for(int u = 1; u <= n; ++u){
		for(int i = G.Begin[u]; i; i = G.Next[i]){
			int v = G.to[i];
			if(sccid[u] != sccid[v]){
				A.add_edge(sccid[u], sccid[v]);
				++degree[sccid[v]];
			}
		}
	}

	Topsort();

	return 0;
}
