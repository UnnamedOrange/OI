#include <stdio.h>
#define maxn 100010
#define modn 998244353LL
int f[maxn]={0},num[maxn]={0},a[maxn]={0},n,m,k,i,j,ans=0;
int max(int x,int y)
{
	return x>y ? x : y;
}
int power(int x,int y)
{
	int i=x,s=1;
	for (;y;y=(y>>1))
	{
		if (y&1) s=(long long)s*(long long)i%modn;
		i=(long long)i*(long long)i%modn;
	}
	return s;
}
int count()
{
	int ans=0,i;
	for (i=1;i<=m;i++)
		ans=(ans+power(a[i],k))%modn;
	return ans;
}
void work(int l,int r,int x)
{
	int i,j,k;
	if (x==n) ans=(ans+count())%modn;
	for (i=l+1;i<=m;i++)
		for (j=max(i,r+1);j<=m;j++)
		{
			for (k=i;k<j;k++)
				a[k]++;
			work(i,j,x+1);
			for (k=i;k<j;k++)
				a[k]--;
		}
}
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (i=1;i<=m;i++)
		num[i]=i;
	for (i=1;i<=m;i++)
		num[i]=(num[i]+num[i-1])%modn;
	for (i=1;i<=m;i++)
		num[i]=(num[i]+num[i-1])%modn;
	if (n==1) printf("%d",num[m-1]);
		else
		{
			work(0,0,0);
			printf("%d",ans);
		}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
