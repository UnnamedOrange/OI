#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
int n,q,t,ans=0,cnt,time; 
struct node{
	int next,to;
}a[10010];
int head[10010],v[10010];
int c[10010],sz[10010];
int dfn[10010],p[10010];
void init(int u,int v){
	a[++cnt].to=v;
	a[cnt].next=head[u];
	head[u]=cnt;	
}
void dfs(int x,int father){
	sz[x]=1;
	dfn[++time]=x;
	p[x]=time;
	for (int i=head[x];i;i=a[i].next){
		int y=a[i].to;
		if (y!=father){
			dfs(y,x);
			sz[x]+=sz[y];
		}
	}
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read();q=read();t=read();
	for (int i=1;i<=n;++i)
		c[i]=read();
	for (int i=1;i<n;++i){
		int u=read(),v=read();
		init(u,v);init(v,u);	
	}
	dfs(1,0);
	while (q--){
		int flag=read();
		if (flag==1){
			int u=read(),l=read(),r=read();
			if (t==1){
				u^=ans;
				l^=ans;
				r^=ans;	
			}
			memset(v,0,sizeof(v));
			ans=0;
			for (int i=p[u];i<=p[u]+sz[u]-1;++i)
				v[c[dfn[i]]]=1;
			for (int i=l;i<=r;++i)
				ans+=v[i];
			printf("%d\n",ans);
		}else{
			int u=read(),x=read();
			c[u]=x;	
		}
	}
	return 0;
}

