#include <cstdio>

int a[30][2],b[30],n,m,ans=0;
bool mark[30][30]={0};
int result[30];

void dfs(int x){
	if (x>n){
		int t=1;
		for (int i=1;i<=m;i++)
			if (!mark[n][i]){
				t=0; break;
			}
		ans+=t; return;
	}
	for (int i=1;i<=m;i++)
		mark[x][i]=mark[x-1][i];
	result[x]=0;
	dfs(x+1);
	for (int i=1;i<=m;i++)
		if (a[x][0]<=b[i]&&b[i]<=a[x][1])
			mark[x][i]=true;
	result[x]=1;
	dfs(x+1);
}

int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
		scanf("%d%d",&a[i][0],&a[i][1]);
	for (int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	dfs(1); printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

