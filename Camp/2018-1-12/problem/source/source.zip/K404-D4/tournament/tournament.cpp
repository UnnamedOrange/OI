#include <iostream>
#include <cstdio>
using namespace std;
int n, k;
const int MOD = 998244353;
/*int head[10], to[300], nxt[300], cnt;
inline void addedge (int u, int v) { cnt++, to[cnt] = v, nxt[cnt] = head[u], head[u] = cnt; }
int ans;
bool ok;
int vis[10];
inline void dfs (int step, int u, int from) {
	if (step == k && u == from) { ok = true; return; }
	if (step >= k) return;
	for (int e = head[u]; e; e = nxt[e]) {
		int v = to[e];
		if (!vis[v]) {
			vis[v] = true;
			dfs (step + 1, v, from);
			vis[v] = false;
		}
	}
}
inline void dfs (int u, int v) {
	if (v > n) {
		ok = false;
		for (int i = 1; i <= n; i++) {
			dfs (0, i, i);
		}
		if (ok) ans++;
		return;
	}
	addedge (u, v);
	dfs (v == n ? u + 1 : u, v == n ? u + 2 : v + 1);
	head[u] = nxt[head[u]];
	cnt--;
	addedge (v, u);
	dfs (v == n ? u + 1 : u, v == n ? u + 2 : v + 1);
	head[v] = nxt[head[v]];
	cnt--;
}*/
inline int ksm (int a, int p) {
	if (p == 0) return 1;
	if (p == 1) return a;
	int l = ksm (a, p >> 1);
	l = 1ll * l * l % MOD;
	if (p & 1) l = 1ll * l * a % MOD;
	return l;
}
inline int fac (int x) {
	int res = 1;
	for (int i = 1; i <= x; i++) res = 1ll * res * i % MOD;
	return res;
}
int a[5010], ny[5010], s[5010];
int main () {
	freopen ("tournament.in", "r", stdin);
	freopen ("tournament.out", "w", stdout);
	scanf ("%d%d", &n, &k);
	//dfs(1, 2);
	for (int i = 1; i <= n; i++) s[i] = ksm (2, i * (i - 1) / 2);
	if (k == 3) printf ("%d\n", (s[n] - fac (n) + MOD) % MOD);
	else if (k == n) {
		a[1] = 1;
		ny[1] = 1; for (int i = 2; i <= n; i++) ny[i] = 1ll * (MOD - MOD / i) * ny[MOD % i] % MOD;
		for (int i = 2; i <= n; i++) {
			int c = 1;
			for (int j = 1; j < i; j++) {
				c = 1ll * c * (i - j + 1) % MOD * ny[j] % MOD;
				a[i] = (a[i] + 1ll * c * a[j] % MOD * s[i - j] % MOD) % MOD;
			}
			a[i] = (s[i] - a[i] + MOD) % MOD;
		}
		printf ("%d\n", a[n]);
	}
	return 0;
}
