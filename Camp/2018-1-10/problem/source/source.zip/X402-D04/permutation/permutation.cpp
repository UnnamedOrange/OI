#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=100010;
const int mod=998244353;
int n;
int a[maxn], p[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int ans, fa[maxn], cnt[maxn], Next[maxn];
int find(int x){ return x==fa[x] ? x : fa[x]=find(fa[x]); }
bool check(){
	for(int i=1;i<=n;i++) fa[i]=i,cnt[i]=0;
	for(int i=1;i<=n;i++) fa[find(i)]=find(a[i]);
	for(int i=1;i<=n;i++) cnt[find(i)]++;
	for(int i=1;i<=n;i++) if(cnt[i]&1) return false;
	return true;
}
void dfs(int x){
	if(x>n){
		// for(int i=1;i<=n;i++) printf("%d ", a[i]); puts("");
		// for(int i=1;i<=n;i++) cerr<<a[i]<<' '; cerr<<endl;
		// cerr<<ans<<endl;
		if(check()) ans++;
		return;
	}
	for(int i=1;i<=n;i++)if(!p[i] && i!=x){
		a[x]=i; p[i]=1;
		dfs(Next[x]);
		p[i]=0;
	}
}

void solve(){
	n/=2; ll t=1;
	for(ll i=1;i<=n;i++) t=t*(i*2-1)%mod;
	printf("%lld\n", t*t%mod);
}

int main(){
	freopen("permutation.in","r",stdin),freopen("permutation.out","w",stdout);

	read(n);
	if(n & 1){ puts("0"); return 0; }
	for(int i=1;i<=n;i++) read(a[i]), p[a[i]]=1;
	int t=0;
	for(int i=1;i<=n;i++) t+=p[i];
	if(!t){ solve(); return 0; }
	int lst=0;
	for(int i=1;i<=n;i++) if(!a[i]) Next[lst]=i, lst=i;
	Next[lst]=n+1;
	// for(int i=1;i<=n;i++) printf("%d ", Next[i]); puts("");
	dfs(Next[0]);
	printf("%d\n", ans);
	return 0;
}
