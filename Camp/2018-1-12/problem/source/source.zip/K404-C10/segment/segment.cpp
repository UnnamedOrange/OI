#include <cstdio>
using namespace std;
#define N 330
#define Mod 998244353
long long f[2][N][N],g[2][N][N],pw[N];
int n,m,k,i,j,l;
inline int qmi(int di,int zhi)
{
	int ret=1,x=di;
	while (zhi){
		if (zhi&1) ret=1LL*ret*x%Mod;x=1LL*x*x%Mod;zhi>>=1;
	}return ret;
}
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (i=0;i<=n;i++) pw[i]=qmi(i,k);
	if (n>m){
		puts("0");
		return 0;
	}
	f[0][0][0]=1;
	for (i=1;i<=m;i++)
	for (j=0;j<=n;j++)
	for (l=0;l<=j;l++){
		f[i&1][j][l]=(f[(i&1)^1][j][l]+(j>0?f[(i&1)^1][j-1][l]:0)+(l>0?f[(i&1)^1][j][l-1]:0)+(j>0&&l>0?f[(i&1)^1][j-1][l-1]:0))%Mod;
		g[i&1][j][l]=(f[i&1][j][l]*pw[j-l]+g[(i&1)^1][j][l]+(j>0?g[(i&1)^1][j-1][l]:0)+(l>0?g[(i&1)^1][j][l-1]:0)+(j>0&&l>0?g[(i&1)^1][j-1][l-1]:0))%Mod;
	}
	printf("%lld\n",(g[m&1][n][n]+Mod)%Mod);
	return 0;
}
