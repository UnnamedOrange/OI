#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

typedef long long LL;

const LL mod=998244353;
LL k,tot=0;
int n,m,l[500010]={0},r[500010]={0},a[500010]={0};

LL fpow(LL a,LL b){
	LL ret=1,t=a;
	while(b){
		if(b%2)ret=(ret*t)%mod;
		t=(t*t)%mod;b/=2;
	}
	return ret;
}

long long getans(){
	long long ans=0;
	for(int i=1;i<=m;i++)
	  if(a[i])
	    ans=(ans+fpow(a[i],k))%mod;
	return ans;
}

void dfs(int d){
	if(d==n+1){
		tot=(tot+getans())%mod;
		return;
	}
	for(int i=l[d-1]+1;i+n-d<m;i++)
	  for(int j=max(i,r[d-1]);j+n-d<=m;j++){
	  	l[d]=i;r[d]=j;
	  	for(int t=i;t<j;t++)a[t]++;
	  	dfs(d+1);
	  	l[d]=r[d]=0;
	  	for(int t=i;t<j;t++)a[t]--;
	  }
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%lld",&n,&m,&k);
	if(n>m*m){
		printf("0");
		return 0;
	}
	if(n==1){
		m--;
		for(long long i=1;i<=m;i++)
		  tot=(tot+i*(m-i+1))%mod;
	}
	else dfs(1);
	printf("%lld",tot);
	return 0;
}
