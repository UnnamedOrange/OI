#include <bits/stdc++.h>
using namespace std;

const int MOD = 998244353;

int Rev(int x) {
	int f = MOD - 2;
	int r = 1;
	while (f) {
		if (f & 1) {
			r = (long long)r * x % MOD;
		}
		x = (long long)x * x % MOD;
		f >>= 1;
	}
	return r;
}

int Convert(double f) {
	double x = 0;
	for (int i = 1; ; ++i) {
		x += f;
		if (fabs(x - round(x)) <= 1e-8) {
			//cerr << f << '*' << i << '=' << x << endl;
			return (long long)(round(x) + 0.5) * Rev(i) % MOD;
		}
	}
	return -1;
}

int n;
vector<int> Edge[100010];
int Color[100010];

int main() {
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);
	cin >> n;
	for (int i = 0; i < n; ++i) {
		char c;
		cin >> c;
		Color[i] = (c == '1');
	}
	for (int i = 1; i < n; ++i) {
		int x, y;
		cin >> x >> y;
		--x;
		--y;
		Edge[x].push_back(y);
		Edge[y].push_back(x);
	}
	if (n <= 6) {
		int mask = 1 << n;
		map<int, double> DP[2][6][65];
		DP[0][0][1][1] = 1;
		double ans = 0;
		for (int i = 1; i < 100; ++i) {
			int t = i & 1;
			int f = t ^ 1;
			for (int j = 0; j < n; ++j) {
				for (int k = 0; k < mask; ++k) {
					DP[t][j][k] = map<int, double>();
				}
			}
			for (int j = 0; j < n; ++j) {
				for (int k = 0; k < mask; ++k) {
					for (map<int, double>::iterator it = DP[f][j][k].begin(); it != DP[f][j][k].end(); ++it) {
						double p = it->second / Edge[j].size();
						for (vector<int>::iterator itt = Edge[j].begin(); itt != Edge[j].end(); ++itt) {
							 if (!Color[*itt] && (k & (1 << *itt))) {
								DP[t][*itt][k][it->first] += p;
							} else {
								DP[t][*itt][k | (1 << *itt)][it->first + 1] += p;
							}
						}
					}
				}
			}
			for (int j = 0; j < n; ++j) {
				if (Edge[j].size() == 1) {
					for (int k = 0; k < mask; ++k) {
						for (map<int, double>::iterator it = DP[t][j][k].begin(); it != DP[t][j][k].end(); ++it) {
							ans += it->first * it->second;
						}
						DP[t][j][k] = map<int, double>();
					}
				}
			}
			//clog << setw(6) << ans << '\n';
		}
		cout << Convert(ans) << endl;
	}
}
