#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define MAXN 4000
#define f(t) f[t.first][t.second]
#define g(t) g[t.first][t.second]
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int N, M, K, f[MAXN+5][MAXN+5]; bool g[MAXN+5][MAXN+5];
struct SeqAM
{
	int c[MAXN+5][MAXN+5], pre[MAXN+5], last[MAXN+5], head, n; void Init(){n = 1; for(rint i = 1; i <= K; last[i] = 1, i++);}
	void Append(int x){int p = ++n; for(rint i = 1, v; i <= K; i++) for(v = last[i]; v && !c[v][x]; c[v][x] = p, v = pre[v]); pre[p] = last[x], last[x] = p;}
	/*void Print()
	{
		for(rint i = 1, j; i <= n; putchar('\n'), i++)
			for(printf("%d:",i), j = 1; j <= K; printf("%d ",c[i][j]), j++);
	}*/
}A,B;	typedef pair<int,int> pii; pii End = pii(0,0);
void BFS()
{
	static pii q[MAXN*MAXN+505], p, t; static int head, tail; head = 0, tail = 1, q[1] = pii(1,1), f(q[1]) = 0, g(q[1]) = true;
	for(rint i; head<tail; )
		for(p = q[++head], i = 1; i <= K; i++)
			if(t = pii(A.c[p.first][i],B.c[p.second][i]), !g(t))
				{f(t) = f(p)+1, g(t) = true, q[++tail] = t; if(t==End) return;}
}
int main()
{
	freopen("subsequence.in","r",stdin), freopen("subsequence.out","w",stdout);
	N = read(), M = read(), K = read(), A.Init(), B.Init();
	for(rint i = 1; i <= N; A.Append(read()), i++); for(rint i = 1; i <= M; B.Append(read()), i++); BFS(); printf("%d\n",f(End)); return 0;
}
