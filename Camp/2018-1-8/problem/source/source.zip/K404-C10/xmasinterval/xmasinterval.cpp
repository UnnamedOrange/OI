#include <cstdio>
#include <algorithm>
using namespace std;
#define pr pair<int,int>
#define R first
#define L second
#define Mod 1000000009
#define N 500050
#define mid ((l+r)>>1)
#define ls l,mid,t<<1
#define rs mid+1,r,t<<1|1
#define upd tr[t]=(tr[t<<1]+tr[t<<1|1])%Mod;
#define pud if(tag[t]!=1){tr[t<<1]=1LL*tr[t<<1]*tag[t]%Mod;tag[t<<1]=1LL*tag[t<<1]*tag[t]%Mod;tr[t<<1|1]=1LL*tr[t<<1|1]*tag[t]%Mod;tag[t<<1|1]=1LL*tag[t<<1|1]*tag[t]%Mod;tag[t]=1;}
pr b[N];
int tr[N<<2],tag[N<<2],a[N],n,m,i;
void bd(int l,int r,int t)
{
	tag[t]=1;if (l==r) return;bd(ls);bd(rs);
}
void cg(int l,int r,int t,int ll,int rr)
{
	if (ll<=l&&rr>=r){
		tr[t]=(tr[t]<<1)%Mod;tag[t]=(tag[t]<<1)%Mod;return;
	}pud if (ll<=mid) cg(ls,ll,rr);if (rr>mid) cg(rs,ll,rr);upd;
}
void build(int l,int r,int t,int x,int y)
{
	if (l==r){
		tr[t]=y;return;
	}if (x<=mid) build(ls,x,y);else build(rs,x,y);upd;
}
int query(int l,int r,int t,int ll,int rr)
{
	if (ll<=l&&rr>=r) return tr[t];
	pud int jb=0;if (ll<=mid) jb=(jb+query(ls,ll,rr))%Mod;
	if (rr>mid) jb=(jb+query(rs,ll,rr))%Mod;return jb;
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (i=1;i<=n;i++) scanf("%d%d",&b[i].L,&b[i].R);
	for (i=1;i<=m;i++) scanf("%d",&a[i]);m++;
	sort(a+1,a+m+1);for (i=1;i<=n;i++) b[i].L=lower_bound(a+1,a+m+1,b[i].L)-a-1,b[i].R=upper_bound(a+1,a+m+1,b[i].R)-a-1;
	sort(b+1,b+n+1);bd(1,m,1);int j=1;
	for (i=1;i<=m;i++){
		int psz;
		if (i==1) psz=1;else psz=-query(1,m,1,1,i-1);
		build(1,m,1,i,psz);
		while (b[j].R==i){
			cg(1,m,1,1,b[j].L);
			j++;
		}
	}printf("%d\n",(query(1,m,1,1,m)+Mod)%Mod);
	return 0;
}
