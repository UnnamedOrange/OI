//2018-1-13
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1000000+5)
const int P = 1e9 + 7;

inline int Mod(int a){
	return a >= P? a-P: a;
}

int n, ml[N], mr[N], f[N], g[N];

bool ID(int st, int ed, int &l, int &r){
	int len = ed-st+1;
	if(len > mr[ed]) return false;

	l = max(ed + (ml[ed]-len), ed);
	r = min(ed + (mr[ed]-len), n);
	
	if(l > r) return false;
	return true;
}

void Get(int me, int ot){
	if(f[me] > f[ot]+1) return;
	if(f[me] == f[ot]+1) g[me] = Mod(g[me]+g[ot]);
	else f[me] = f[ot]+1, g[me] = g[ot];
}

int main(){
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
	
	scanf("%d", &n);
	For(i, 1, n) scanf("%d%d", &ml[i], &mr[i]);

	int l, r, nl, nr;
	Set(f, -1); f[0] = 0; g[0] = 1;
	
	For(i, 0, n-1) if(f[i] >= 0){
		if(!ID(i+1, i+1, l, r)) continue;

		if(i+1 >= l && i+1 <= r) Get(i+1, i);

		For(j, i+2, n){
			if(!ID(i+1, j, nl, nr)) break;
			l = max(l, nl); r = min(r, nr);
			if(j >= l && j <= r) Get(j, i);
		}
	}
	
	printf("%d", f[n]);
	if(f[n] >= 0) printf(" %d", g[n]);
	puts("");

	return 0;
}
