#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#define mod 1000000007
using namespace std;

long long s,m,n,t,ans;
long long dp[50000005],top[50000005];

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
	for(int i=m;i>n;i--)
		top[i]=s-m+1;
	for(int i=n;i>=1;i--)
		top[i]=min(s-m+1,t);
	dp[0]=1;
	for(long long i=1;i<=m;i++)
	{
		for(long long k=s;k>=1;k--)
		{
			dp[k]=0;
			for(long long j=min(k,top[i]);j>=1;j--)
			{
				dp[k]+=dp[k-j];
				dp[k]%=mod;
			}
		}
		dp[0]=0;
	}
	for(int i=1;i<=s;i++)
		ans+=dp[i],ans%=mod;
	printf("%lld",ans);
	return 0;
}
