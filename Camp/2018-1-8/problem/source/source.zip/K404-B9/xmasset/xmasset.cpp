#include<bits/stdc++.h>
using namespace std;

int t,n,T;

int main()
{
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	scanf("%d",&t);
	scanf("%d%d",&n,&T);
	if (t==1)
	  {
	  	for (int i=1;i<=T;i++)
	  	  {
	  	  	int x,y;
	  	  	scanf("%d%d",&x,&y);
	  	  	printf("%d\n",x);
		  }
	  }
	if (t==2)
	  {
	  	for (int i=1;i<=T;i++)
	  	  {
	  	  	int x,y;
	  	  	scanf("%d%d",&x,&y);
	  	  	if (x==y) printf("yes\n");
	  	  	else printf("no\n");
		  }
	  }  
	return 0;  
}
