#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 100005
typedef unsigned int ui;
const int base1=41,base2=43;

int n;
ui p1[maxn],p2[maxn];
char s[maxn];
bool can1[maxn],can2[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

int main(){
	p1[0]=1; for (int i=1;i<=100000;i++) p1[i]=p1[i-1]*base1;
	p2[0]=1; for (int i=1;i<=100000;i++) p2[i]=p2[i-1]*base2;
	for (int T=read();T;T--){
		n=read(); scanf("%s",s+1);
		if (n==1){puts("-1"); continue;}
		int l,r; for (l=1,r=n;s[l]==s[r]&&l<r;++l,--r);
		if (l<r){puts("1"); continue;}
		memset(can1,0,sizeof(can1)),memset(can2,0,sizeof(can2));
		ui pp=s[1]-'a'+1,x1=pp*p1[0],y1=x1,x2=pp*p2[0],y2=x2;
		for (int i=2;i<n-1;i++){
			pp=s[i]-'a'+1;
			x1=x1+pp*p1[i-1],y1=y1*base1+pp;
			x2=x2+pp*p2[i-1],y2=y2*base2+pp;
			if (x1==y1&&x2==y2) can1[i]=1;
		}
		pp=s[n]-'a'+1,x1=pp*p1[0],y1=x1,x2=pp*p2[0],y2=x2;
		for (int i=n-1;i>2;i--){
			pp=s[i]-'a'+1;
			x1=x1+pp*p1[n-i],y1=y1*base1+pp;
			x2=x2+pp*p2[n-i],y2=y2*base2+pp;
			if (x1==y1&&x2==y2) can2[i]=1;
		}
		bool can=0;
		for (int i=2;i<n-1;i++)
			if (!can1[i]&&!can2[i+1]){can=1; break;}
		puts(can?"2":"-1");
	}
	return 0;
}
