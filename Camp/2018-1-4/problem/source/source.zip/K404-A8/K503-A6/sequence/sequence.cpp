#include<cstdio>
#include<algorithm> 
using namespace std;
#define N 30
#define rep(i,j,k) for(i=j;i<=k;++i)
int n,i,j,k,m,L,R,tes,cnt,s,t,timing;
int pw[N],q[16777220],f[16777220],lst[16777220],x[N],hsh[N],di[N];
void read(int &p){
	p=0; char x=getchar(); bool fu=false;
	if(x=='-') fu=true;
	while(x<'0' || x>'9'){x=getchar(); if(x=='-') fu=true;}
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
	if(fu) p=-p;
}
bool cmp(int a,int b){
	return x[a]<x[b];
}
void init(){
	read(n); s=t=cnt=0; timing++;
	rep(i,1,n) {
		read(x[i]);
		hsh[i]=i;
	}
	sort(hsh+1,hsh+1+n,cmp);
	rep(i,1,n){
		if((i==1)||(x[hsh[i]]!=x[hsh[i-1]])) cnt++;
		di[hsh[i]]=cnt-1;
	}
	pw[0]=1;
	rep(i,1,n) pw[i]=pw[i-1]*cnt;
	rep(i,1,n){
		s+=pw[i-1]*di[i];
		t+=pw[i-1]*di[hsh[i]];
	}
}
int getpos(int s,int k){
	return (s/pw[k-1])%cnt;
}
void work(){
	L=R=0;
	q[0]=s; f[s]=0; lst[s]=timing;
	while(L<=R){
		int x=q[L]; L++;
		if(x==t) return ;
		rep(i,2,n){
			int news=x;
			rep(j,1,i){
				news+=(getpos(x,i-j+1)-getpos(x,j))*pw[j-1];
			}
			if(lst[news]!=timing){
				lst[news]=timing;
				f[news]=f[x]+1;
				if(news==t) return ;
				R++; q[R]=news;
			}
		}
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	read(tes);
	while(tes--){ 
		init();
		work();
		printf("%d\n",f[t]);
	}
	return 0;
}
