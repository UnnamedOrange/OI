#include<bits/stdc++.h>
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
using namespace std;
int s, t, n, m, s1;
const int mod = 1000000007;
int dp[1000005];
int main() {
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	R(s), R(t), R(n), R(m);
	if(s < m) {
		puts("0");
		return 0;
	}
	if(s == m) {
		puts("1");
		return 0;
	}
	s1 = s - m;
	dp[0] = 1;
	int sum = 0;
	int mi;
	int he = 0;
	for(int i = 1; i <= n; ++i) {
		mi = max(s1 - t + 1, 0);
		for(int j = s1 - 1; j >= s1 - t + 1; --j) sum = (sum + dp[j]) % mod;
		he = 0;
		for(int j = s1; j > 0; --j) {
			dp[j] = (dp[j] + sum) % mod;
			sum = ((sum - dp[j - 1]) + mod) % mod;
			(j - t >= 0) ? (sum += dp[j - t]) : (0);
			sum %= mod;
		//	printf("dp[%d] = %d\n", j, dp[j]);
			he = (he + dp[j]) % mod;
		}
//		printf("he = %d\n", he);
//		puts("");
	}
	sum = 0;
	for(int i = n + 1; i <= m; ++i) {
		for(int j = s1 - 1; j >= 0; --j) sum = (sum + dp[j]) % mod;
		for(int j = s1; j > 0; --j) {
			dp[j] = (dp[j] + sum) % mod;
			sum = ((sum - dp[j - 1]) + mod) % mod;

		}
	}
	int ans = 0;
	for(int i = 0; i <= s1; ++i) {
		ans = (ans + dp[i]) % mod;
	}
	printf("%d\n", ans);
}
