// 30pt
#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 1e6+5, modd = 1e9+7 ;
int n, m, f[maxn], F[maxn] ;
int c[maxn], d[maxn] ;
int main() {
	freopen ( "schooldays.in", "r", stdin ) ;
	freopen ( "schooldays.out", "w", stdout ) ;

	int i, j ;
	Read(n) ;
	memset ( f, -1, sizeof f ) ;
	f[0] = 0 ;
	F[0] = 1 ;
	int maxc, mind ;
	for ( i = 1 ; i <= n ; i ++ ) {
		Read(c[i]), maxc = c[i] ;
		Read(d[i]), mind = d[i] ;
		for ( j = 1 ; j <= i ; j ++ ) {
			if (maxc <= j && j <= mind) {
				if (f[i] < f[i - j] + 1) {
					f[i] = f[i - j] + 1 ;
					F[i] = F[i - j] ;
				} else if (f[i] == f[i - j] + 1)
					(F[i] += F[i - j]) %= modd ;
			}
			maxc = max(maxc, c[i - j]) ;
			mind = min(mind, d[i - j]) ;
		}
	}
	if (F[n]) printf ( "%d %d\n", f[n], F[n] ) ;
	else puts("-1") ;
	return 0 ;
} 
