#include<bits/stdc++.h>
#define mo 1000000009
using namespace std;
struct Info{int l,r,be,en;}a[500010];
struct tree{int l,r,nu;}t[2000010];
int b[500010],jb[500010],m,n,nb=0,x,f[500010],g[500010];
bool comp(const Info &a,const Info &b){
	return a.l<b.l;
}
int er2(int x){
	int l=0,r=nb,mid;
	while (l+1<r){
		mid=(l+r)/2;
		if (b[mid]>=x)r=mid;else l=mid;
	}
	if (b[r]<=x) return r;else return l;
}
int er1(int x){
	int l=1,r=nb+1,mid;
	while (l+1<r){
		mid=(l+r)/2;
		if (b[mid]<x)l=mid;else r=mid;
	}
	if (b[l]>=x) return l;else return r;
}
void build(int nu,int l,int r){
	t[nu].l=l;t[nu].r=r;
	if (l==r){
		if (l==0) t[nu].nu=1;else t[nu].nu=0;
	}else{
		build(nu*2,l,(l+r)/2);
		build(nu*2+1,(l+r)/2+1,r);
		t[nu].nu=t[nu*2].nu+t[nu*2+1].nu;
	}
}
void add(int nu,int x,int pp){
	t[nu].nu+=pp;
	t[nu].nu%=mo;
	if (t[nu].l!=t[nu].r){
		if (x<=(t[nu].l+t[nu].r)/2) add(nu*2,x,pp);else add(nu*2+1,x,pp);
	}
}
int que(int nu,int l,int r){
	if (t[nu].l==l&&t[nu].r==r) return t[nu].nu;
	int mid=(t[nu].l+t[nu].r)/2,su=0;
	if (l<=mid) su+=que(nu*2,l,min(r,mid));
	if (r>mid) su+=que(nu*2+1,max(mid+1,l),r);
	return su%mo;
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d %d",&n,&m);
	for (int i=1;i<=n;i++)scanf("%d %d",&a[i].l,&a[i].r);
	for (int i=1;i<=m;i++)scanf("%d",&jb[i]);
	sort(jb+1,jb+m+1);
	for (int i=1;i<=m;i++)if (jb[i]!=jb[i-1]) b[++nb]=jb[i];
	b[nb+1]=2147483647;
	sort(a+1,a+n+1,comp);
	for (int i=1;i<=n;i++){a[i].be=er1(a[i].l);a[i].en=er2(a[i].r);}
	build(1,0,nb);
	for (int i=1;i<=n;i++){
		if (a[i].be==1)x=que(1,0,a[i].en);
		else x=que(1,a[i].be-1,a[i].en);
		add(1,a[i].en,x);
	}
	cout<<que(1,nb,nb)<<endl;
	return 0;
}
