#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

int type, n, T, x, y;

int encode(int x, int y){
	int z = x ^ y, i = 0;
	while(1){
		if(z & 1) return i * 2 + (x >> i & 1) + 1;
		z >>= 1;
		i++;
	}
}
int decode(int x, int y){
	y--;
	int i = y >> 1, z = y & 1;
	if((x >> i & 1) == z) puts("yes");
	else puts("no");
}

int main(){
	
	read(type), read(n), read(T);
	while(T--){
		read(x), read(y);
		if(type == 1) write(encode(x, y)), enter;
		else decode(x, y);
	}
	
	return 0;
}
/*
2
5 6
1 2
4 1
2 2
3 4
5 1
2 2
*/
