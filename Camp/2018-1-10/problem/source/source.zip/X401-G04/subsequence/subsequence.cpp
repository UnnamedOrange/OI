/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
#define MAXN 4000
int a[MAXN+10],b[MAXN+10],c[MAXN+10];
int n,m,k;
namespace bl
{
bool check(int s[],int n,int t[],int m)
{
    int p=1;
    for(int i=1; i<=n; ++i)
    {
        if (s[i]==t[p])
        {
            ++p;
            if (p>m) return false;
        }
    }
    return true;
}
bool dfs(int now,int maxdeep)
{
    if (now>maxdeep)
    {
        bool t=check(a,n,c,maxdeep) && check(b,m,c,maxdeep);
#ifdef MDEBUG
        if (t)
        {
            for(int i=1; i<=maxdeep; ++i)
            {
                cerr<<c[i]<<' ';
            }
            cerr<<endl;
        }
#endif
        return t;
    }
    for(int i=1; i<=k; ++i)
    {
        c[now]=i;
        if (dfs(now+1,maxdeep)) return true;
        c[now]=0;
    }
    return false;
}
int main()
{
    int ans=1;
    while(!dfs(1,ans)) ++ans;
    return ans;
}
}
int main()
{
#ifndef MDEBUG
    freopen("subsequence.in","r",stdin);
    freopen("subsequence.out","w",stdout);
#endif
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1; i<=n; ++i)
    {
        scanf("%d",&a[i]);
    }
    for(int i=1; i<=m; ++i)
    {
        scanf("%d",&b[i]);
    }
    int ans=0;
    ans=bl::main();
    printf("%d\n",ans);
    return 0;
}
