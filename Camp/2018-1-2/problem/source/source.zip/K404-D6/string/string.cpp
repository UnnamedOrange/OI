#include<cstdio>
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
int pos[100001];
char S[200001],A[200001];
int T,n,len,l,r,top;
inline int min(int a,int b){
	return a<b?a:b;
}
inline bool check(char *S,int l,int r){
	while(l<r){
		if(S[l]!=S[r])
			return 1;
		++l;--r;
	}
	return 0;
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	die:;
	while(T--){
		scanf("%d%s",&n,S+1);
		if(check(S,1,n)){
			puts("1");
			continue;
		}
		for(register int i=n/2;i;--i){
			if(check(S,1,i)&&check(S,i+1,n)){
				puts("2");
				goto die;
			}
			if(n>10000&&n/2-i>=100)
				break;
		}
		puts("-1");
	}
	return 0;
}
