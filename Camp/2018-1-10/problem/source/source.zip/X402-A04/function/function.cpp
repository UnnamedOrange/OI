#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1000050;
ll sig[N],sigs[N];
int mu[N],prime[N],cnt=0,mn[N];
bool isnotprime[N];

void init()
{
	isnotprime[1]=1; mu[1]=1; sig[1]=1; mn[1]=0;
	int n=N-50;
	for(int i=2;i<=n;++i)
	{
		if(!isnotprime[i]) prime[++cnt]=i,sig[i]=2,mu[i]=-1,mn[i]=1;
		for(int j=1;j<=cnt&&i*prime[j]<=n;++j)
		{
			isnotprime[i*prime[j]]=1;
			if(!(i%prime[j]))
			{
				mn[i*prime[j]]=mn[i]+1;
				sig[i*prime[j]]=sig[i]/(mn[i]+1)*(mn[i]+2);
				break;
			}
			mu[i*prime[j]]=-mu[i];
			mn[i*prime[j]]=1; sig[i*prime[j]]=sig[i]*2;
		}
	}
	for(int i=1;i<=n;++i) sigs[i]=sigs[i-1]+sig[i]*sig[i];
}

void wj()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	init();
	T=read();
	for(int cas=1;cas<=T;++cas)
	{
		int n=read();
		ll ans=0;
		for(i=1;i<=n;++i) ans=ans+mu[i]*sigs[n/i];
		printf("%lld\n",ans);
	}
	return 0;
}
