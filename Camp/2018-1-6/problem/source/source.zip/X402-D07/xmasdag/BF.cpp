#include<bits/stdc++.h>
using namespace std;
#define pb push_back
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=100010,maxm=200010,mo=998244353;
int n,m,k,ind[maxn];
int head[maxn],nxt[maxm],to[maxm],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}
void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}
int fpm(int x,int p){
    int ret=1;
    for(;p;p>>=1,x=1ll*x*x%mo)
        if(p&1) ret=1ll*ret*x%mo;
    return ret;
}
int sum[2010][2010];
int ans[maxn];
namespace SP{
    int sum[maxn];
    void solve(){
        queue<int> q; q.push(1); sum[1]=1;
        while(!q.empty()){
            int u=q.front(); q.pop();
            for(int i=head[u];i;i=nxt[i]){
                int v=to[i];
                Add(ans[v],(ans[u]+sum[u])%mo);
                Add(sum[v],sum[u]);
                if(!--ind[v]) q.push(v);
            }
        }
        for(int i=1;i<=n;i++) printf("%d\n",ans[i]);
    }
}
int main(){
    freopen("xmasdag.in","r",stdin);
    freopen("BF.out","w",stdout);
    read(n); read(m); read(k);
    for(int i=1;i<=m;i++){
        int u,v;
        read(u); read(v);
        ae(u,v); ++ind[v];
    }
    if(k==1) SP::solve(),exit(0);
    queue<int> q;
    q.push(1); sum[1][0]=1;
    while(!q.empty()){
        int u=q.front(); q.pop();
        for(int i=1;i<=n;i++) Add(ans[u],1ll*sum[u][i]*fpm(i,k)%mo);
        for(int i=head[u];i;i=nxt[i]){
            int v=to[i];
            for(int j=0;j<n;j++) Add(sum[v][j+1],sum[u][j]);
            if(!--ind[v]) q.push(v);
        }
    }
    for(int i=1;i<=n;i++) printf("%d\n",ans[i]);
    return 0;
}
