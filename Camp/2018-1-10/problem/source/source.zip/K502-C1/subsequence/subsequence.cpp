#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
using namespace std;

const int MAXN = 4100;
int n, m, k, ans;
int a[MAXN], b[MAXN], f[MAXN][MAXN], g[MAXN][MAXN], h[MAXN][MAXN];

namespace Force
{
	int c[30];
	bool check(int sz)
	{
		int j = 1;
		for (int i = 1; i < n + 1; ++i)
		{
			if (a[i] == c[j])
				++j;
		}
		if (j >= sz + 1)
			return false;
		j = 1;
		for (int i = 1; i < m + 1; ++i)
		{
			if (b[i] == c[j])
				++j;
		}
		if (j >= sz + 1)
			return false;
		return true;
	}
	void dfs(int p, int d)
	{
		if (ans <= d)
			return;
		if (p == d + 1)
		{
			if (check(d))
				ans = d;
		}
		else if (p < d + 1)
		{
			for (int i = 1; i < k + 1; ++i)
			{
				c[p] = i;
				dfs(p + 1, d);
			}
		}
	}
	void main()
	{
		memset(c, 0, sizeof c);
		ans = max(n, m) + 1;
		for (int i = 1; i < max(n, m) + 1; ++i)
		{
			dfs(1, i);
			if (ans < max(n, m) + 1)
				break;
		}
		printf("%d\n", ans);
	}
}

namespace Dp
{
	int pre[320];
	void init()
	{
		for (int i = 1; i < k + 1; ++i)
			h[n + 1][i] = n + 1;
		for (int i = n; i > -1; --i)
		{
			for (int j = 1; j < k + 1; ++j)
			{
				if (a[i + 1] != j)
					h[i][j] = h[i + 1][j];
				else
					h[i][j] = i + 1;
			}
		}
		for (int i = 1; i < k + 1; ++i)
			g[m + 1][i] = m + 1;
		for (int i = m; i > -1; --i)
		{
			for (int j = 1; j < k + 1; ++j)
			{
				if (b[i + 1] != j)
					g[i][j] = g[i + 1][j];
				else
					g[i][j] = i + 1;
			}
		}
	}	
	void main()
	{
		init();
		memset(f, 0x3f, sizeof f);
		f[0][0] = 0;
		for (int i = 0; i < n + 2; ++i)
		{
			for (int j = 0; j < m + 2; ++j)
			{
				for (int l = 1; l < k + 1; ++l)
				{
					f[h[i][l]][g[j][l]] = min(f[i][j] + 1, f[h[i][l]][g[j][l]]);
				}
			}
		}
		ans = max(n, m) + 1;
		ans = min(f[n + 1][m + 1], ans);
		printf("%d\n", ans);
	}	
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	n = read();
	m = read();
	k = read();
	for (int i = 1; i < n + 1; ++i)
		a[i] = read();
	for (int i = 1; i < m + 1; ++i)
		b[i] = read();
	if (n <= 18)
		Force::main();
	else if (n <= 300)
		Dp::main();
	return 0;
}
