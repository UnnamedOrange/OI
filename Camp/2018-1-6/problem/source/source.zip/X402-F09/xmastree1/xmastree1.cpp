#include<bits/stdc++.h>
#include<ext/pb_ds/hash_policy.hpp>
#include<ext/pb_ds/assoc_container.hpp>
#define mid ((l+r)>>1)
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
__gnu_pbds::gp_hash_table<int,bool> mp;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=100005;
int e,head[N],nex[N<<1],to[N<<1],ans,fa[N],c[N],l,r;
void add(int x,int y){
	to[++e]=y; nex[e]=head[x]; head[x]=e;
}
void dfs(int x,int f){
	fa[x]=f;
	for(int i=head[x];i;i=nex[i])
		if (to[i]!=f) dfs(to[i],x);
}
void dfs2(int x){
	if (!mp[c[x]]&&c[x]>=l&&c[x]<=r) mp[c[x]]=1,++ans;
	for(int i=head[x];i;i=nex[i])
		if (to[i]!=fa[x]) dfs2(to[i]);
}
int main(){
	freopen("xmastree1.in","r",stdin); freopen("xmastree1.out","w",stdout);
	int n=read(),q=read(),t=read(),fl,x,y,z,a;
	For(i,1,n) c[i]=read();
	For(i,1,n-1) x=read(),y=read(),add(x,y),add(y,x);
	dfs(1,0);
	while(q--){
		fl=read(),x=read(),y=read();
		if (fl==1){
			z=read(); if (t) x=x^ans,y=y^ans,z=z^ans; if (y>z) a=y,y=z,z=x;
			mp.clear(); ans=0,l=y,r=z; dfs2(x); printf("%d\n",ans);
		}
		else c[x]=y;
	}
	return 0;
}
