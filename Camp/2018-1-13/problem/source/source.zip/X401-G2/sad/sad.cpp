#include<bits/stdc++.h>
#define MO 998244353
#define N 100050
using namespace std;
inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}

int u,v,tot,d[N],a[N],c[N*2][2],du[N],v_[56],n,f_[N],s_[N],f[N],sh[N],er;
inline int ksm(int p, int k)
{
	v_[0]=p; 
	for(int i=1; i<=29; ++i)v_[i]=(long long )v_[i-1]*v_[i-1]%MO;
	int ss=1;
	for(int i=29; i>=0; --i)if(1<<i<=k)
	{
		ss=(long long)ss*v_[i]%MO;
		k-=1<<i;
	}
	return ss;
}

inline int ni(int p)
{
	if(p<0)p=p%MO+MO;  //% -3   ll -4 //()
	return ksm(p,MO-2);
}

void dfs(int p, int faa)
{
	if(du[p]==1)
	{
		sh[p]=0;
	    f[p]=1;
	    return;
	}
	
	if(p==1)
	{
		int tt=0;
		for(int o=a[p]; o; o=c[o][1])
		{
		    dfs(c[o][0],p);
		    f_[++tt]=f[c[o][0]];
		    s_[tt]=sh[c[o][0]];
	    }
	    
	    int ff=(f_[1]+f_[2])%MO,ss=((s_[1]+s_[2])%MO+ff)%MO;
//	    cerr<< ff <<' ' <<ss<<endl;
	    
	    if(d[p])
	    f[p]=((long long)er*ss%MO*ni(1-(long long)er%MO*s_[1]%MO-(long long)er%MO*s_[2]%MO)%MO+1)%MO;
	    else 
	    f[p]=((long long)er*(f_[1]+f_[2])%MO*ni(1-(long long)er*s_[1]%MO-(long long)er*s_[2]%MO)%MO+1)%MO;
	    return;
    }
	for(int o=a[p]; o; o=c[o][1])
	{
		if(c[o][0]==faa)continue;
		dfs(c[o][0],p);
		if(d[p])
		f[p]=(long long)er*(f[c[o][0]]+sh[c[o][0]])%MO*ni(1-(long long)er*sh[c[o][0]]%MO)%MO+1; //%MO //no%= ()%= //
		else
		//()
		f[p]=(long long)er*f[c[o][0]]%MO*ni(1-(long long)er*sh[c[o][0]]%MO)%MO+1;
		sh[p]=(long long)er*ni(1-(long long)er*sh[c[o][0]]%MO)%MO;
//		sh[p]=er+er*(sh[c[o][0]]*sh[p])
//		f[p]=er*(f[c[o][0]]+sh[c[o][0]]*(f[p]+1))              //+1;
	}
}

int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	n=read(); 
	for(int i=1; i<=n; ++i)
	{
		d[i]=getchar();
		while(d[i]>49 || d[i]<48)d[i]=getchar();
	}
	for(int i=1; i<=n; ++i)d[i]-=48;
	for(int i=1; i<n; ++i)
	{
		u=read(); v=read();
		c[++tot][0]=v; c[tot][1]=a[u]; a[u]=tot;
		c[++tot][0]=u; c[tot][1]=a[v]; a[v]=tot;
		++du[u]; ++du[v];
	}
	er=ni(2);
	dfs(1,0);
//	cerr<<sh[2]<<endl;
	printf("%d\n",f[1]);
}
