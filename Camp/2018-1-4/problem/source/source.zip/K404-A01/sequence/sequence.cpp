//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const lovelive mod=1004535809;
void read(int &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
int a[25],n,ans;
int val()
{
  int r=0;
  for(int i=2;i<n;i++)
    if((a[i-1]<a[i]&&a[i]>a[i+1])||(a[i-1]>a[i])&&(a[i+1]>a[i]))
      ++r;
  return r;
}
bool dfs(int dep,int pre)
{
  int k;
  bool p=false;
  if(dep+val()>ans)
    return false;
  for(k=n;k>=1;k--)
  {
    if(a[k]!=k)
      break;
    if(k==1)
      return true;
  }
  for(int i=2;i<=k;i++)
    if(i!=pre)
    {
  	  for(int j=1;j<=i-j;j++)
  	    swap(a[j],a[i-j+1]);
  	  p=dfs(dep+1,i);
  	  for(int j=1;j<=i-j;j++)
  	    swap(a[j],a[i-j+1]);
  	  if(p)
  	    return true;
    }
  return false;
}
int main()
{
  freopen("sequence.in","r",stdin);
  freopen("sequence.out","w",stdout);
  int T;
  read(T);
  while(T--)
  {
  	read(n);
    for(int i=1;i<=n;i++)
      read(a[i]);
    for(ans=0;ans<n*2;ans++)
  	  if(dfs(0,0))
  	    break;
    cout<<ans<<"\n";
  }
  return 0;
}
/*
1
8
8 6 1 3 2 4 5 7 
*/
