#include<cstdio>
#include<algorithm>
using namespace std;
#define N 2005
#define mod 1000000007
#define rep(i,j,k) for(i=j;i<=k;++i)
#define down(i,j,k) for(i=j;i>=k;--i)
int n,m,i,j,k,Max_c,Min_d,ans;
int f[N],dp[N],c[N],d[N];
void read(int &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
} 
void init(){
	read(n);
	if(n>=N) {puts("-1"); return ;}
	rep(i,1,n){ read(c[i]); read(d[i]); }
	f[0]=1; dp[0]=0; 
	rep(i,1,n){
		Max_c=-mod; Min_d=mod;
		down(j,i-1,0){
			Max_c=max(Max_c,c[j+1]);
			Min_d=min(Min_d,d[j+1]);
			if(f[j]==0) continue ;
			if((i-j<Max_c)||(i-j>Min_d)) continue ;
			if(dp[i]<dp[j]+1){
				dp[i]=dp[j]+1; f[i]=f[j];
			}else
			if(dp[i]==dp[j]+1){
				f[i]=(f[i]+f[j])%mod;
			}
		}
	}
	if(dp[n]==0) puts("-1");
	else printf("%d %d\n",dp[n],f[n]);
}
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	init();
	return 0;
}
