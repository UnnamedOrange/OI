#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<set>
//#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

const int N=1000050;
const int bas=35;
int n,val[N];
pii w[N];
inline bool cmp(pii a,pii b) {return a.fi>b.fi;}
int head[N],tail[N],sum[N<<2];
int ret=0;
bool found=0;
void gorig(int o,int l,int r)
{
	if(l==r) {found=1;ret=l;return ;}
	int mid=l+r>>1;
	if(sum[o<<1|1]) gorig(o<<1|1,mid+1,r);
	else gorig(o<<1,l,mid);
}
void pre(int o,int l,int r,int x,int y)
{
	if(found) return ;
	if(x<=l&&r<=y)
	{
		if(sum[o]) gorig(o,l,r);
		return ;
	}
	int mid=l+r>>1;
	if(y>mid) pre(o<<1|1,mid+1,r,x,y);
	if(x<=mid) pre(o<<1,l,mid,x,y);
}
void golef(int o,int l,int r)
{
	if(l==r) {found=1;ret=l;return ;}
	int mid=l+r>>1;
	if(sum[o<<1]) golef(o<<1,l,mid);
	else golef(o<<1|1,mid+1,r);
}
void nex(int o,int l,int r,int x,int y)
{
	if(found) return ;
	if(x<=l&&r<=y)
	{
		if(sum[o]) golef(o,l,r);
		return ;
	}
	int mid=l+r>>1;
	if(x<=mid) nex(o<<1,l,mid,x,y);
	if(y>mid) nex(o<<1|1,mid+1,r,x,y);
}
void update(int o,int l,int r,int x)
{
	sum[o]++;
	if(l==r) return ;
	int mid=l+r>>1;
	if(x<=mid) update(o<<1,l,mid,x);
	else update(o<<1|1,mid+1,r,x);
}

void wj()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	//clock_t sta=clock();
	n=read();
	for(i=1;i<=n;++i) val[i]=read(),w[i]=pii(val[i],i);
	sort(w+1,w+1+n,cmp);
	db ans=0;
	//ans=(db)w[1].fi/2.0*w[1].se/n*(n-w[1].se+1)/n;
	//update(1,1,n,w[1].se); tail[w[1].se]=n+1;
	for(i=1;i<=n;++i)
	{
		int pos=w[i].se;
		tail[pos]=n+1;
		found=0; ret=0;
		nex(1,1,n,pos,n);
		db lef=0,rig=0,mul=2;
		if(!found) rig=(tail[pos]-pos)/2.0;
		else
		{
			tail[pos]=ret; head[ret]=pos;
			for(j=1;j<=bas;++j) 
			{
				rig+=(tail[pos]-pos)/mul;
				mul*=2;
				pos=tail[pos];
				if(pos==n+1) break;
			}
		}
		pos=w[i].se; mul=1;
		found=0; ret=0;
		pre(1,1,n,1,pos);
		if(!found) lef=pos-head[pos];
		else
		{
			head[pos]=ret; tail[ret]=pos;
			for(j=1;j<=bas;++j)
			{
				lef+=(pos-head[pos])/mul;
				mul*=2;
				pos=head[pos];
				if(!pos) break;
			}
		}
		update(1,1,n,w[i].se);
		ans+=rig/n*lef*w[i].fi/n;
	}
	printf("%.12lf",ans);
	//clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
