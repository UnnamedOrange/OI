#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
const int mod=(1e9)+7;
int n,m,s,t,dp[110][110],ans;
int i,j,k;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	s=read(); t=read(); n=read(); m=read();
	memset(dp,0,sizeof(dp)); dp[0][s]=1;
	for (i=0;i<=m-1;i++){
		for (j=0;j<=s;j++){
			if (i+1<=n){
				for (k=1;k<=t;k++){
					if (j-k>=0) dp[i+1][j-k]=(dp[i+1][j-k]+dp[i][j])%mod;
				}
			}
			else{
				for (k=1;k<=s;k++){
					dp[i+1][j-k]=(dp[i+1][j-k]+dp[i][j])%mod;
				}
			}
		}
	}
	ans=0;
	for (i=0;i<=s;i++){
		ans=(ans+dp[m][i])%mod;
	}
	printf("%d\n",ans);
	return 0;
}
