#include<bits/stdc++.h>
using namespace std;

const int maxn=1010;
int n;
int w[maxn], r[maxn];
vector<int> g[maxn];

int fa[maxn][12];
void dfs(int x,int id){
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa[x][id]) continue;
		fa[v][id]=x; dfs(v, id);
	}
}

int p[maxn], ans, q[maxn];
int main(){
	freopen("xmastree2.in","r",stdin),freopen("xmastree2.out","w",stdout);

	scanf("%d", &n);
	int u, v;
	for(int i=1;i<n;i++) scanf("%d%d", &u, &v), g[u].push_back(v), g[v].push_back(u);
	for(int i=1;i<=n;i++) scanf("%d%d", &w[i], &r[i]);
	int cnt=0;
	for(int i=1;i<=n;i++)if(r[i]){
		dfs(i,++cnt);
	}
	int tot=1;
	for(int i=1;i<=n;i++) p[i]=i, tot*=i;
	while(tot--){
		int flag=0;
		for(int i=1;i<=n;i++) q[ p[i] ]=i;
		for(int i=1;i<=cnt;i++){
			int c=1;
			for(int j=1;j<=n;j++) if(q[j]<q[fa[j][i]]){ c=0; break; }
			if(c){ flag=1; break; }
		}
		int t=0;
		if(flag){
			for(int i=1;i<=n;i++){ t+=i*w[ p[i] ]; }
			ans=max(ans, t);
			// for(int i=1;i<=n;i++) printf("%d ", p[i]); puts("");
			// printf("t = %d\n", t);
		}
		next_permutation(p+1,p+1+n);
	}
	printf("%d\n", ans);
	return 0;
}
