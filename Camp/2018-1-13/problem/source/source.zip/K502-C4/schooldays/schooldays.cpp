#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#define mod 1000000007
using namespace std;

int n,c[125005],d[125005];
long long ans,sum;

void solve(int head,int cnt)
{
	int maxc=0,mind=1e9;
	if(head==n+1)
	{
		cnt--;
		if(cnt>ans)
		{
			ans=cnt;
			sum=1;
		}
		else if(cnt==ans) sum++, sum%=mod;
		return;
	}
	for(int i=head;i-head+1<=mind&&i<=n;i++)
	{
		maxc=max(maxc,c[i]);
		mind=min(mind,d[i]);
		if(i-head+1>=maxc)
			solve(i+1,cnt+1);
	}
}

int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&c[i],&d[i]);
	solve(1,1);
	if(ans==0) printf("-1");
	else printf("%lld %lld",ans,sum);
	return 0;
}
