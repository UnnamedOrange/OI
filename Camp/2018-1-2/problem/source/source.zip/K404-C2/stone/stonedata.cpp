#include<algorithm>
#include<unistd.h>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<ctime>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;

int main()
{
	freopen("stone.in","w",stdout);
	srand(time(0)+getpid());
	int n=6,a=rand()%5+1,b=rand()%5+1;
	printf("%d %d %d\n",n,a,b);
	rep(i,1,n) printf("%d\n",rand()%15);
	return 0;
}
