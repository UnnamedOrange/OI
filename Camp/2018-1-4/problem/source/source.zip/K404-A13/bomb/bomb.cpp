#include<cstdio>
#include<stack>
#include<cctype>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn = 1e5 + 5;
struct edge {
	int v, next;
}e[maxn];
int cnt, head[maxn], n, m, u, v, dfn[maxn], low[maxn], dfsc, mx;
bool vis[maxn];
void adde(const int &u, const int &v) {
	e[++cnt] = (edge) {v, head[u]};
	head[u] = cnt;
} 
void read(int & x) {
	static char c = getchar();
	x = 0;
	while(!isdigit(c)) c = getchar();
	while(isdigit(c)) x = x * 10 + c - '0', c = getchar();
}
stack<int > stk;
int tarjan(int u) {
	dfn[u] = low[u] = ++dfsc;
	stk.push(u), vis[u] = 1;
	for(register int i = head[u]; i; i = e[i].next) {
		int v = e[i].v;
		if(!dfn[v]) low[u] = min(low[u], tarjan(v));
		else low[u] = min(low[v], low[u]);
	}
	if(low[u] == dfn[u]) {
		int sz = 0;
		while(stk.top() != u) {
			++sz;
			stk.pop();
		}
		stk.pop();
		mx = max(mx, sz + 1);
	}
	return low[u];
}
int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(register int i = 1; i <= m; ++i) {
		read(u), read(v);
		adde(u, v);
	}
	for(register int i = 1; i <= n; ++i)
		if(!dfn[i]) tarjan(i);
	printf("%d", mx);
	return 0;
}
