#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=505;
int n,W,p,q,w[maxn];
struct data{
	int x,y,type;
	void input(){
		x=read(),y=read(),type=read();
	}
}d[maxn*2];
struct data2{
	int x,y,z;
	ll a,b,c,d,e,f;
	void input(){
		x=read(),y=read(),z=read();
		a=read(),b=read(),c=read();
		d=read(),e=read(),f=read();
	}
	ll calc(){
		return a*abs(w[x]-w[y])+b*abs(w[y]-w[z])+c*abs(w[z]-w[x])+d*(w[x]-w[y])+e*(w[y]-w[z])+f*(w[z]-w[x]);
	}
}t[maxn*2];
ll ans=1e18;
ll calc(){
	ll res=0;
	REP(i,1,n)res+=w[i];
	REP(i,1,p)res+=t[i].calc();
	return res;
}
bool check(){
	bool res=1;
	REP(i,1,q){
		if(d[i].type==0)res&=w[d[i].x]<=w[d[i].y];
		else if(d[i].type==1)res&=w[d[i].x]==w[d[i].y];
		else res&=w[d[i].x]<w[d[i].y];
	}return res;
}
void dfs(int step){
	if(step>n){
		if(check())chkmin(ans,calc());
		return;
	}
	w[step]=W,dfs(step+1);
	w[step]=-W,dfs(step+1);
}
void work(){
	n=read(),W=read(),p=read(),q=read();
	REP(i,1,p)t[i].input();
	REP(i,1,q)d[i].input();
	ans=1e18;
	dfs(1);
	write(ans,'\n');
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
#endif
	int T=read();
	while(T--)work();
	return 0;
}
