#include<bits/stdc++.h>
#define ll long long
#define For(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
int read(){
	int x=0,fh=1; char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') fh=-1;
	for(;isdigit(ch);ch=getchar()) x=x*10+(ch^48);
	return x*fh;
}
const int mo=1e9+7;
int ksm(int x,int y){
	int f=1; ll an=1,k=x;
	while(y){
		if (f&y) y^=f,an=an*k%mo;
		k=k*k%mo,f<<=1;
	}
	return (int)an;
}
int n,m,s,t,k,ny[1000005]; int a[105][105];
int dfs(int x,int y){
	if ((n-x+1)*t<y) return 0;
	if (!y) return 1; int &ha=a[x][y];
	if (ha) return ha;
	int z=min(t,y);
	For(i,0,z){
		ha+=dfs(x+1,y-i);
		if (ha>=mo) ha-=mo;
	}
	return ha;
}
int main(){
	freopen("success.in","r",stdin); freopen("success.out","w",stdout);
	ll r,an=1; s=read(),t=read(),n=read(),m=read();
	s-=m,--t; if (s<0) puts("0"),exit(0);
	For(i,1,s+1) ny[i]=ksm(i,mo-2);
	For(i,1,s){
		r=1;
		For(j,0,i){
			For(ii,1,n) memset(a[ii],0,(i-j+1)<<2);
			an+=r*dfs(1,i-j)%mo; if (an>=mo) an-=mo;
			r=r*(m-n+j)%mo*ny[j+1]%mo;
		}
	}
	printf("%lld\n",an);
	return 0;
}
//205812539
