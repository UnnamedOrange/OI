#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std ;
template<class T>void read(T &x){
	x=0;int f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=f?-x:x;
	return ;
}
const int maxn=1000010;

int n,ans,m,bns,orz,tot,ecnt,cnt,tur,sro;

int ff[maxn][2],head[maxn],dis[maxn],out[maxn],head1[maxn],inst[maxn],belong[maxn],dfn[maxn],size[maxn],f[maxn],low[maxn],vis[maxn],stra[maxn];

struct edge{
	int u,v,next;
}E[maxn],e[maxn];

void addedge(int u,int v){
	E[++ecnt].u=u;
	E[ecnt].v=v;
	E[ecnt].next=head[u];
	head[u]=ecnt;
}

int gef(int x){return f[x]==x?x:f[x]=gef(f[x]);}

void tarjan(int x){
	dfn[x]=low[x]=++orz;
	stra[++tur]=x;
	vis[x]=1;
	for(int i=head[x];i;i=E[i].next){
		int v=E[i].v;
		if(!dfn[v]) {tarjan(v);low[x]=min(low[x],low[v]);}
		else if(vis[v]) low[x]=min(low[x],dfn[v]);
	}
	if(dfn[x]==low[x]){
		++tot;int v;
		do{
			vis[v=stra[tur--]]=0;
			belong[v]=tot;size[tot]++;
			ans=max(size[tot],ans);
		}while(v!=x);
	}
}

void Tarjan(){
	for(int i=1;i<=n;i++)if(!dfn[i]) tarjan(i);
}

void add(int u,int v){
	e[++cnt].u=u;
	e[cnt].v=v;
	e[cnt].next=head1[u];
	head1[u]=cnt;
	out[v]++;
}

void work(){
	for(int i=1;i<=m;i++){
		int u=belong[ff[i][0]];int v=belong[ff[i][1]];
		if(u!=v) add(u,v);
	}
	int l=0,r=0;
	for(int i=1;i<=tot;i++) if(!out[i]) inst[++r]=i;
	while(l<r){
		int x=inst[++l];
		ans=max(ans,dis[x]+size[x]);
		for(int i=head1[x];i;i=e[i].next){
			int v=e[i].v;
			dis[v]=max(dis[v],dis[x]+size[x]);
			out[v]--;
			if(!out[v]) inst[++r]=v;	
		}
	}
	printf("%d",ans);
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=n;i++) f[i]=i;
	for(int i=1;i<=m;i++){
		int u,v;read(u),read(v);
		addedge(u,v);
		ff[i][0]=u,ff[i][1]=v;
	}
	Tarjan();
	work();
	return 0;
}

