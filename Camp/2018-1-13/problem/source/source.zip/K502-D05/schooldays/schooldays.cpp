#include<bits/stdc++.h>
using namespace std;

const int maxn = 1e+6 + 10;

int n,mlg2[maxn];
int fmx[21][maxn],fmi[21][maxn];
int f[maxn],g[maxn];

void input()
{
	int i;
	
	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%d%d",fmx[0]+i,fmi[0]+i);
}

void st_pre()
{
	int i,j=1;
	
	for(i=1;i<=22;i++)
	 for(;j<maxn && j<(1<<i);j++) mlg2[j]=i-1;
	
	for(i=1;(1<<i)<=n;i++)
	{
		for(j=0;j+(1<<i)<=n;j++) 
		{
			fmi[i][j]=min(fmi[i-1][j],fmi[i-1][j+(1<<i-1)]);
			fmx[i][j]=max(fmx[i-1][j],fmx[i-1][j+(1<<i-1)]);
		}
	}
}

inline int fmax(int l,int r){int d=mlg2[r-l];return max(fmx[d][l],fmx[d][r-(1<<d)+1]);}
inline int fmin(int l,int r){int d=mlg2[r-l];return min(fmi[d][l],fmi[d][r-(1<<d)+1]);}
inline int igl(int l,int r)
{
	if(r-l+1>fmin(l,r)) return -1;
	return fmax(l,r)>r-l+1;
}

void solve()
{
	int i,j,t;
	
	f[0]=0;g[0]=1;
	for(i=1;i<=n;i++)
	{
		for(j=i-1;j>=0;j--) 
		{
			if((t=igl(j,i-1))==-1) break;
			if(t) continue;
			if(f[j]+1>f[i])
			{
				f[i]=f[j]+1;g[i]=g[j];
			}
			else if(f[j]+1==f[i]) g[i]+=g[j];
		}
	}
	if(f[n]==0) cout<<-1<<endl;
	else        cout<<f[n]<<' '<<g[n]<<endl;
}

int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	
	input();
	st_pre();
	solve();
	
	return 0;
}
