/*******************************************
	File:subsequence.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-10 08:59:53
*******************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 4010
#define inf (1<<30)
int n,m,k,posa[N],posb[N],a[N],b[N],f[N][N];
int main()
{
	freopen("subsequence.out","w",stdout);
	freopen("subsequence.in","r",stdin);
	n=read();
	m=read();
	k=read();
	fr(i,1,n)
		a[i]=read();
	fr(i,1,m)
		b[i]=read();
	fr(i,0,n+1)
		fr(j,0,m+1)
			f[i][j]=inf;
	f[0][0]=0;
	fr(i,0,n+1)
		fr(j,0,m+1)
			if(f[i][j]!=inf)
			{
				fr(o,1,k)
					posa[o]=posb[o]=0;
				fr(o,i+1,n+1)
					if(!posa[a[o]])
						posa[a[o]]=o;
				fr(o,j+1,m+1)
					if(!posb[b[o]])
						posb[b[o]]=o;
				fr(o,1,k)
				{
					if(!posa[o])
						posa[o]=n+1;
					if(!posb[o])
						posb[o]=m+1;
					f[posa[o]][posb[o]]=min(f[posa[o]][posb[o]],f[i][j]+1);
				}
			}
	printf("%d\n",f[n+1][m+1]);
	return 0;
}