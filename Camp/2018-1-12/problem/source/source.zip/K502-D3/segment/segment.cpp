#include <cstdio>
#include <cstring>
#include <algorithm>
#define ele int
#define ll long long
using namespace std;
#define maxn 100010
#define MOD 998244353
ele n,m,k;
inline ele pw(ele a,ele x){
	ele ans=1,tmp=a%MOD;
	for (; x; x>>=1,tmp=(ll)tmp*tmp%MOD)
		if (x&1) ans=(ll)ans*tmp%MOD;
	return ans;
}
namespace t1{
	ele ans,f[maxn];
	void dfs(ele i,ele l,ele r){
		if (i==n){
			ele tmp=0,s=0;
			for (int i=0; i<m; ++i)
				s+=f[i],(tmp+=pw(s,k))%=MOD;
			(ans+=tmp)%=MOD;
			return;
		}
		if (l==m || r==m) return;
		for (int j=l; j<m; ++j)
			for (int k=max(j,r); k<m; ++k){
				++f[j]; --f[k];
				dfs(i+1,j+1,k+1);
				--f[j]; ++f[k];
			}
	}
	inline void solve(){
		ans=0;
		dfs(0,0,0);
		printf("%d\n",ans);
	}
};
namespace t2{
	inline void solve(){
		ele ans=0;
		for (int i=0; i<m; ++i) (ans+=(ll)(i+1)*(m-i-1)%MOD)%=MOD;
		printf("%d\n",ans);
	}
};
namespace t3{
	inline ele func(ele x){
		return (ll)x*(x-1)/2%MOD;
	}
	inline ele p1(ele x){
		return (ll)x*(x+1)/2%MOD;
	}
	inline ele p2(ele x){
		return (ll)x*(x+1)*(x*2+1)/6%MOD;
	}
	inline void solve(){
		ele a1=0,a2=0,a3=0;
		for (int i=0; i<m; ++i){
			(a1+=(ll)func(i+1)*func(m-i-1)%MOD)%=MOD;
			ele t=(ll)func(m-i)*(m-i-1)%MOD;
			ele t1=(p2(m-1)-p2(i))%MOD;
			ele t2=(ll)(2*i-1)*(p1(m-1)-p1(i))%MOD;
			ele t3=(ll)i*(i-1)*(m-i-1)%MOD;
			t1=((ll)t1-t2+t3)%MOD;
			t1=(ll)t1*pw(2,MOD-2)%MOD;
			(t-=t1)%=MOD;
			(a2+=(ll)t*(i+1)%MOD)%=MOD;
			t=(ll)func(i+2)*(i+1)%MOD;
			t1=p2(i);
			t2=(ll)(2*i+3)*p1(i)%MOD;
			t3=(ll)(i+2)*(i+1)*(i+1)%MOD;
			t1=((ll)t1-t2+t3)%MOD;
			t1=(ll)t1*pw(2,MOD-2)%MOD;
			(t-=t1)%=MOD;
			(a3+=(ll)t*(m-i-1)%MOD)%=MOD;
		}
		a1=(ll)a1*pw(2,k)%MOD;
		a1=(ll)(a1+a2+a3)%MOD;
		a1+=MOD; a1%=MOD;
		printf("%d\n",a1);
	}
};
int main(){
	freopen("segment.in","r",stdin); freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if (n==1) t2::solve();
	if (n==2) t3::solve();
	else t1::solve();
	return 0;
}