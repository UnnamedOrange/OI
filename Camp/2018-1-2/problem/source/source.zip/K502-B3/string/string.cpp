#include <stdio.h>

char a[100001];
long long int t,n;
 
inline long long int read()
{
    char ch;
    bool flag = false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout); 
	t=read();
	while(t--)
	{
		n=read(); 
		scanf("%s",a);
		long long int i,flag=0;
		for(i=1;i<=n-1;i++)
		{
			if(a[i]!=a[i-1])
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
			printf("-1\n");
		else
		{
			int temp=0;
			for(i=0;i<=n/2-1;i++)
			{
				if(a[i]!=a[n-i-1])
				{
					temp=1;
					break;
				}
			} 
			if(temp==0)
			{
				if(n%2==1)
				{
					int cur=0; 
					for(i=1;i<=n/2-1;i++)
					{
						if(a[i]!=a[i-1])
						{
							cur=1;
							break;
						}
					}
					if(cur==0)
						printf("-1\n");
					else
						printf("2\n");
				}
				else
					printf("2\n");
			}
			else
				printf("1\n");
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
