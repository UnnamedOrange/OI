#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

typedef long long LL;
const int N = 1e5 + 10;
const int P = 998244353;
struct edge{int ed, ne;} e[N<<1]; int he[N], en;
int n, ans;
char s[N];
int f[N], g[N], h[N], son[N];

int lp(int a, int b) {
	int c = 1;
	for(; b; b >>= 1, a = (LL)a * a % P)
		if(b & 1) c = (LL)c * a % P;
	return c;
}

void ins(int a, int b) {
	e[++en].ed = b; e[en].ne = he[a]; he[a] = en; ++son[b];
}

void dfs(int u, int fa) {
	f[u] = 1;
	int t = 0, i;
	for(i = he[u]; i; i = e[i].ne)
	if(e[i].ed != fa) {
		dfs(e[i].ed, u);
		if(son[e[i].ed]) f[u] = (f[u] + f[e[i].ed]) % P, ++t;
	}
	if(s[u] == '1') f[u] = (f[u] + t) % P;
	f[u] = (LL)f[u] * lp(son[u]+1-t, P-2) % P;
}

void dfs2(int u, int fa) {
	int sum = 0, i, t = 0;
	for(i = he[u]; i; i = e[i].ne)
	if(e[i].ed != fa && son[e[i].ed]) sum = (sum + f[e[i].ed]) % P, ++t;
	for(i = he[u]; i; i = e[i].ne)
	if(e[i].ed != fa) {
		if(!son[e[i].ed]) sum = (sum + f[e[i].ed]) % P, ++t;
		if(s[u] == '1') {
			if(u == 1) g[e[i].ed] = (t + sum - f[e[i].ed]) % P;
			else g[e[i].ed] = (sum - f[e[i].ed] + t + 1 + g[u]) % P;
		} else {
			if(u == 1) g[e[i].ed] = (1 + sum - f[e[i].ed]) % P;
			else g[e[i].ed] = (sum - f[e[i].ed] + 1 + g[u]) % P;
		}
		g[u] = (LL)g[u] * lp(son[u]+1-t, P-2) % P;
		if(!son[e[i].ed]) sum = (sum - f[e[i].ed] + P) % P, --t;
		h[e[i].ed] = (h[u] + g[e[i].ed]) % P;
		dfs2(e[i].ed, u);
	}
	if(!son[u]) ans = (ans + h[u]) % P;
}

int main() {
	freopen("sad.in", "r", stdin); freopen("sad.out", "w", stdout);
	int i, x, y;
	scanf("%d", &n);
	scanf("%s", s+1);
	rep(i, 1, n-1) {
		scanf("%d %d", &x, &y);
		ins(x, y); ins(y, x);
	}
	rep(i, 2, n) --son[i];
	dfs(1, 0); f[1] = 0;
	h[1] = 1; dfs2(1, 0);
	//printf("%d %d %d %d\n", f[1], f[2], f[3], f[4]);
	//printf("%d %d %d\n", g[1], g[2], g[3]);
	//printf("%d %d %d\n", g[1], g[2], g[3]);
	printf("%d\n", ans);
	return 0;
}
