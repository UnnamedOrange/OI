#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=505,N=1005;
const int inff=(int)1e7;
const long long inf=(long long)1e12+7,INF=(long long)1e18+7;
int n,w,p,q;
int X[N],Y[N],Z[N],A[N],B[N],C[N],D[N],E[N],F[N];
int x[N],y[N],r[N];
struct SHUI{
	int bin[20];
	SHUI(){
		for(int i=0;i<20;i++)bin[i]=(1<<i);
	}
	int v[20];
	long long ab(long long x){
		if(x<0)return -x;
		return x;
	}
	void solve(){
		for(int i=1;i<=p;i++)X[i]--,Y[i]--,Z[i]--;
		for(int i=1;i<=q;i++)x[i]--,y[i]--;
		long long tmpans=INF;
		for(int S=0,up=(1<<n);S<up;S++){
			for(int i=0;i<n;i++)
				if(S&bin[i])v[i]=w;
				else v[i]=-w;
			static bool f;
			f=false;
			for(int i=1;i<=q;i++)
				if(r[i]==0&&v[x[i]]>v[y[i]]){f=true;break;}
				else if(r[i]==1&&v[x[i]]!=v[y[i]]){f=true;break;}
				else if(r[i]==2&&v[x[i]]>=v[y[i]]){f=true;break;}
			if(f)continue;
			long long ans=0;
			for(int i=0;i<n;i++)ans+=v[i];
			for(int i=1;i<=p;i++)ans+=A[i]*ab(v[X[i]]-v[Y[i]])+B[i]*ab(v[Y[i]]-v[Z[i]])+C[i]*ab(v[Z[i]]-v[X[i]])+D[i]*(v[X[i]]-v[Y[i]])+E[i]*(v[Y[i]]-v[Z[i]])+F[i]*(v[Z[i]]-v[X[i]]);
			if(ans<tmpans)tmpans=ans;
		}
		printf("%lld\n",tmpans);
	}
}P30;
struct IHSU{
	struct W{
		int to,nx;
		long long cap;
	}Lis[6*M+16*N];
	int Head[M*2],tot;
	void Add(int x,int y,long long cap){
		Lis[++tot]=(W){y,Head[x],cap};
		Head[x]=tot;
		Lis[++tot]=(W){x,Head[y],0};
		Head[y]=tot;
	}
	int S,T;
	long long mxf;
	bool bixuda[M],bixuxiao[M];
	int qian[M*2],hou[M*2];
	int itea[M*2],level[M*2],mark[M*2],TIM;
	bool BFS(){
		static int q[M*2],L,R,x;
		L=R=0;
		TIM++;
		mark[S]=TIM;
		q[R++]=S;
		level[S]=0;
		while(L<R){
			x=q[L++];
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
				if(Lis[i].cap>0&&mark[to]!=TIM){
					mark[to]=TIM;
					level[to]=level[x]+1;
					q[R++]=to;
				}
		}return mark[T]==TIM;
	}
	long long dfs(int x,long long f){
		if(x==T)return f;
		long long re=0,tmp;
		for(int &i=itea[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(Lis[i].cap>0&&(level[to]==level[x]+1)&&((tmp=dfs(to,min(f,Lis[i].cap))))){
				Lis[i].cap-=tmp;
				Lis[i^1].cap+=tmp;
				re+=tmp;
				f-=tmp;
				if(f==0)break;
			}
		return re;
	}
	void MXF(){
		long long x;
		while(BFS()){
			for(int i=S;i<=T;i++)itea[i]=Head[i];
			while((x=dfs(S,inf)))mxf+=x;
		}
	}
	void CLR(){
		tot=1;
		S=0,T=2*n+1;
		for(int i=S;i<=T;i++)Head[i]=0,qian[i]=hou[i]=0;
		mxf=0;
		for(int i=1;i<=n;i++)bixuda[i]=bixuxiao[i]=0;
	}
	void solve(){
		CLR();
		for(int i=1;i<=p;i++){
			Add(X[i]+n,Y[i]+n,2*(A[i]+D[i]));
			if(A[i]-D[i]>=0)Add(Y[i]+n,X[i]+n,2*(A[i]-D[i]));
			else qian[Y[i]+n]+=2*(D[i]-A[i]),hou[X[i]+n]+=2*(D[i]-A[i]);
			Add(Y[i]+n,Z[i]+n,2*(B[i]+E[i]));
			if(B[i]-E[i]>=0)Add(Z[i]+n,Y[i]+n,2*(B[i]-E[i]));
			else qian[Z[i]+n]+=2*(E[i]-B[i]),hou[Y[i]+n]+=2*(E[i]-B[i]);
			Add(Z[i]+n,X[i]+n,2*(C[i]+F[i]));
			if(C[i]-F[i]>=0)Add(X[i]+n,Z[i]+n,2*(C[i]-F[i]));
			else qian[X[i]+n]+=2*(F[i]-C[i]),hou[Z[i]+n]+=2*(F[i]-C[i]);
		}
		mxf-=(long long)n*inff;
		for(int i=1;i<=q;i++)
			if(r[i]==0){
				Add(x[i]+n,y[i]+n,inf);
			}else if(r[i]==1){
				Add(x[i]+n,y[i]+n,inf);
				Add(y[i]+n,x[i]+n,inf);
			}else if(r[i]==2){
				bixuxiao[x[i]]=1;
				bixuda[y[i]]=1;
			}
		for(int i=1;i<=n;i++){
			Add(S,i,inf+qian[i+n]);
			if(bixuda[i])Add(i,i+n,inf+qian[i+n]);
			else Add(i,i+n,1+inff+qian[i+n]);
			if(bixuxiao[i])Add(i+n,T,inf+hou[i+n]);
			else Add(i+n,T,-1+inff+hou[i+n]);
		}
		MXF();
		mxf*=w;
		printf("%lld\n",mxf);
	}
}PPP;
void solve(){
	scanf("%d %d %d %d",&n,&w,&p,&q);
	for(int i=1;i<=p;i++)scanf("%d %d %d %d %d %d %d %d %d",&X[i],&Y[i],&Z[i],&A[i],&B[i],&C[i],&D[i],&E[i],&F[i]);
	for(int i=1;i<=q;i++)scanf("%d %d %d",&x[i],&y[i],&r[i]);
//	if(0);
	if(n<=15)P30.solve();
	else PPP.solve();
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int cas;scanf("%d",&cas);
	while(cas--)solve();
	return 0;
}
