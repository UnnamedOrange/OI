#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 2007;
const int MOD = 1e9 + 7;

int add ( int x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
	return x;
}

struct dT
{
	dT () : maxi ( -1 ), cc ( 0 ) {}
	dT ( int _m, int _c ) : maxi ( _m ), cc ( _c ) {}
	
	dT operator + ( const dT &a ) const
	{
		if ( a.maxi > maxi ) return a;
		else if ( a.maxi == maxi ) return dT ( maxi, add ( cc, a.cc ) );
		else return ( *this );
	}
	
	void operator += ( const dT &a )
	{
		( *this ) = ( *this ) + a;
	}
	
	dT trans ()
	{
		return dT ( maxi+1, cc );
	}
	
	int maxi, cc;
}dp[MAXN];

int n;
int cl[MAXN], cr[MAXN];



void init ();
void input ();
void work ();



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "schooldays" );
}

void input ()
{
	scanf ( "%d", &n );
	lpi ( i, 1, n ) scanf ( "%d%d", &cl[i], &cr[i] );
}

void work ()
{
	int ml, mr;
	dp[0] = dT ( 0, 1 );
	lpi ( i, 1, n ){
		ml = 0, mr = INF;
		lpd ( j, i, 0 ){
			ml = qmax ( ml, cl[j] );
			mr = qmin ( mr, cr[j] );
			if ( i - j + 1 >= ml && i - j + 1 <= mr ){
				dp[i] += dp[j-1].trans ();
			}
		}
	}
	
	if ( ~dp[n].maxi ) cout << dp[n].maxi << " " << dp[n].cc << endl;
	else cout << -1 << endl;
}
