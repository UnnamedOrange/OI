//by yjz
#include<bits/stdc++.h>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
//My i/o stream
struct fastio
{
	char s[100000];
	int it,len;
	fastio(){it=len=0;}
	inline char get()
	{
		if(it<len)return s[it++];it=0;
		len=fread(s,1,100000,stdin);
		if(len==0)return EOF;else return s[it++];
	}
	bool notend()
	{
		char c=get();
		while(c==' '||c=='\n')c=get();
		if(it>0)it--;
		return c!=EOF;
	}
}_buff;
#define geti(x) x=getnum()
#define getii(x,y) geti(x),geti(y)
#define getiii(x,y,z) getii(x,y),geti(z)
#define puti(x) putnum(x),putchar(' ')
#define putii(x,y) puti(x),puti(y)
#define putiii(x,y,z) putii(x,y),puti(z)
#define putsi(x) putnum(x),putchar('\n')
#define putsii(x,y) puti(x),putsi(y)
#define putsiii(x,y,z) putii(x,y),putsi(z)
inline ll getnum()
{
	ll r=0;bool ng=0;char c;c=_buff.get();
	while(c!='-'&&(c<'0'||c>'9'))c=_buff.get();
	if(c=='-')ng=1,c=_buff.get();
	while(c>='0'&&c<='9')r=r*10+c-'0',c=_buff.get();
	return ng?-r:r;
}
template<class T> inline void putnum(T x)
{
	if(x<0)putchar('-'),x=-x;
	register short a[20]={},sz=0;
	while(x)a[sz++]=x%10,x/=10;
	if(sz==0)putchar('0');
	for(int i=sz-1;i>=0;i--)putchar('0'+a[i]);
}
inline char getreal(){char c=_buff.get();while(c<=32)c=_buff.get();return c;}
const int B=1<<20;
struct SGT
{
	int val[B+5];
	int a[B*2+5];
	SGT()
	{
		memset(val,0,sizeof(val));
		memset(a,0,sizeof(a));
		for(int i=0;i<B;i++)a[B+i]=i;
		for(int i=B-1;i>=1;i--)a[i]=a[i<<1];
	}
	void changeval(int x,int v)
	{
		val[x]=v;
		for(int i=(B+x)>>1;i;i>>=1)
		{
			a[i]=val[a[i<<1]]>val[a[i<<1|1]]?a[i<<1]:a[i<<1|1];
		}
	}
	void checkval(int x,int v)
	{
		if(v>val[x])changeval(x,v);
	}
	int query(int x,int y)
	{
//		cerr<<"query:"<<x<<","<<y<<endl;
		int ans=x;
		x+=B-1;
		y+=B+1;
		while(x^y^1)
		{
			if(~x&1)ans=val[ans]>val[a[x^1]]?ans:a[x^1];
			if( y&1)ans=val[ans]>val[a[y^1]]?ans:a[y^1];
			x>>=1;y>>=1;
		}
		return ans;
	}
}sgta,sgtb;
int tol[1000111];

void upd(int &x,int v){x=x+v>=mod?x+v-mod:x+v;}
int n;
pair<int,int> combine(pair<int,int> x,pair<int,int> y)
{
	if(x.FF>y.FF)return x;
	else if(x.FF<y.FF)return y;
	else return MP(x.FF,x.SS+y.SS>=mod?x.SS+y.SS-mod:x.SS+y.SS);
}
pair<int,int> a[1000111];
pair<int,int> dp[1000111];
bool f[1000111];
int cnt[1000111];
int sum[1000111];
set<int> st;
int cur_i;
void add(int x)
{
	if(f[x]||x<tol[cur_i])return;
	f[x]=1;
	if(dp[x-1].FF>=0)
	{
		if((cnt[dp[x-1].FF]++)==0)st.insert(dp[x-1].FF);
		upd(sum[dp[x-1].FF],dp[x-1].SS);
	}
	sgta.changeval(x,1);
}
void del(int x)
{
	if(!f[x])return;
	f[x]=0;
	if(dp[x-1].FF>=0)
	{
		if((--cnt[dp[x-1].FF])==0)st.erase(dp[x-1].FF);
		upd(sum[dp[x-1].FF],mod-dp[x-1].SS);
	}
	sgta.changeval(x,0);
}
vector<int> cmd[1000111];
void chkmx(int x,int v)
{
	if(v==1)return;
//	cerr<<"chkmx:"<<x<<" "<<v<<endl;
	sgtb.checkval(x,v);
	if(max(1,x-v+2)>x)return;
	while(true)
	{
		int t=sgta.query(max(1,x-v+2),x);
		if(sgta.val[t]==0)return;
		del(t);
		int np=t+v-1;
		assert(np>cur_i);
		if(np<=n)cmd[np].PB(t);
	}
}
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	geti(n);
	for(int i=1;i<=n;i++)getii(a[i].FF,a[i].SS);
	set<pair<int,int> > tst;
	int it=1;
	for(int i=1;i<=n;i++)
	{
		tst.insert(MP(a[i].SS,i));
		while(tst.size()>0&&i-it+1>tst.begin()->FF)
		{
			tst.erase(MP(a[it].SS,it));
			it++;
		}
		tol[i]=it;
	}
//	for(int i=1;i<=n;i++)cerr<<tol[i]<<" ";cerr<<endl;
	for(int i=1;i<=n;i++)dp[i]=MP(-mod,0);
	if(n<=2000)
	{
		dp[0]=MP(0,1);
		for(int i=1;i<=n;i++)
		{
			int mx=0,mn=n+1;
			for(int j=i;j>=1;j--)
			{
				mx=max(mx,a[j].FF);
				mn=min(mn,a[j].SS);
				if(mx<=(i-j+1)&&(i-j+1)<=mn)
				{
					dp[i]=combine(dp[i],dp[j-1]);
				}
			}
			dp[i].FF++;
	//		cerr<<dp[i].FF<<","<<dp[i].SS<<endl;
		}
	}
	else
	{
		dp[0]=MP(0,1);
		for(int i=1;i<=n;i++)
		{
			cur_i=i;
	//		cerr<<"i="<<i<<endl;
			add(i);
			chkmx(i,a[i].FF);
	//		cerr<<"phase I end"<<endl;
	//		for(int j=1;j<=i;j++)cerr<<f[j];cerr<<endl;
			for(int j=0;j<cmd[i].size();j++)
			{
				int x=cmd[i][j];
				int c=sgtb.val[sgtb.query(x,n)]+x-1;
				if(c>i)
				{
					if(c<=n)cmd[c].PB(x);
				}
				else add(x);
			}
			while(true)
			{
				if(tol[i]-1<1)break;
				int t=sgta.query(1,tol[i]-1);
				if(sgta.val[t]==0)break;
				del(t);
			}
	//		cerr<<"phase II end"<<endl;
	//		for(int j=1;j<=i;j++)cerr<<f[j];cerr<<endl;
			if(st.size()>0)
			{
				int t=*(--st.end());
				dp[i]=MP(t+1,sum[t]);
			}
	//		cerr<<dp[i].FF<<","<<dp[i].SS<<endl;
		}
	}
	if(dp[n].FF<0)puts("-1");
	else cout<<dp[n].FF<<" "<<dp[n].SS<<endl;
	return 0;
}
