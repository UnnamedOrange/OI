/*
	created by scarlyw
*/
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <cctype>
#include <vector>
#include <set>
#include <queue>
#include <ctime>
#include <bitset>

inline char read() {
	static const int IN_LEN = 1024 * 1024;
	static char buf[IN_LEN], *s, *t;
	if (s == t) {
		t = (s = buf) + fread(buf, 1, IN_LEN, stdin);
		if (s == t) return -1;
	}
	return *s++;
}

///*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return ;
		if (c == '-') iosig = true;	
	}
	for (x = 0; isdigit(c); c = read()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int OUT_LEN = 1024 * 1024;
char obuf[OUT_LEN], *oh = obuf;
inline void write_char(char c) {
	if (oh == obuf + OUT_LEN) fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf;
	*oh++ = c;
}

template<class T>
inline void W(T x) {
	static int buf[30], cnt;
	if (x == 0) write_char('0');
	else {
		if (x < 0) write_char('-'), x = -x;
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 + 48;
		while (cnt) write_char(buf[cnt--]);
	}
}

inline void flush() {
	fwrite(obuf, 1, oh - obuf, stdout);
}

/*
template<class T>
inline void R(T &x) {
	static char c;
	static bool iosig;
	for (c = getchar(), iosig = false; !isdigit(c); c = getchar())
		if (c == '-') iosig = true;	
	for (x = 0; isdigit(c); c = getchar()) 
		x = ((x << 2) + x << 1) + (c ^ '0');
	if (iosig) x = -x;
}
//*/

const int MAXN = 100000 + 10;

int n, t, ans;
char s[MAXN], s1[MAXN];

inline void dfs(char *s, int len, int cnt) {
	if (cnt >= ans) return ;
	if (len == 0) {
		ans = std::min(ans, cnt);
		return ;
	}
	for (int i = 1; i <= len; ++i)
		for (int j = i; j <= len; ++j) {
			int l = j - i + 1;
			bool flag = false;
			for (int k = 0; k < l / 2; ++k)
				if (s[i + k] != s[j - k]) {
					flag = true ;
					break ;
				}
			if (flag) {
				int c_len = 0;
				for (int k = 1; k < i; ++k) s1[++c_len] = s[k];
				for (int k = j + 1; k <= len; ++k) s1[++c_len] = s[k];
				dfs(s1, c_len, cnt + 1);
			}
		}
}

inline void solve() {
	ans = MAXN;
	scanf("%d%s", &n, s + 1);
	if (n <= 10) dfs(s, n, 0), W(((ans == MAXN) ? -1 : ans)), write_char('\n');
	else {
		bool flag = false ;
		for (int i = 1; i <= n; ++i)
			if (s[i] != s[n + 1 - i]) {
				flag = true;
				break ;
			}
		if (flag) {
			W(1), write_char('\n');
			return ;
		} else {
			for (int i = 1; i <= n; ++i)
				for (int j = i; j <= n; ++j) {
					int l = j - i + 1;
					bool flag = false;
					for (int k = 0; k < l / 2; ++k)
						if (s[i + k] != s[j - k]) {
							flag = true ;
							break ;
						}
					if (flag) {
						int c_len = 0;
						for (int k = 1; k < i; ++k) s1[++c_len] = s[k];
						for (int k = j + 1; k <= n; ++k) s1[++c_len] = s[k];
						bool able = false ;
						for (int k = 0; k < c_len / 2; ++k) {
							if (s1[1 + k] != s1[c_len - k]) {
								able = true ;
								break ;
							}
						}
						if (able) {
							W(2), write_char('\n');
							return ;
						}
					}
				}
			W(-1), write_char('\n');
		}
	}
}

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	scanf("%d", &t);
	while (t--) solve();
	flush();
	return 0;
}
