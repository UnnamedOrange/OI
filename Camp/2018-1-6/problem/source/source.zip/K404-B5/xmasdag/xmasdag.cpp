#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 100007;
const int MAXM = 200007;
const int MAXK = 507;
const int MOD = 998244353;

struct eT
{
	void setd ( int _u, int _v, int _l )
	{
		u = _u, v = _v, last = _l;
	}
	
	int u, v, last;
}edge[MAXM];

int n, m, k;
int ke, la[MAXN];
int deg[MAXN];



void init ();
void input ();
void work ();

int add ( int x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
	return x;
}

void addv ( int &x, int y )
{
	x += y;
	if ( x >= MOD ) x -= MOD;
}

int dec ( int x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
	return x;
}

void decv ( int &x, int y )
{
	x -= y;
	if ( x < 0 ) x += MOD;
}



namespace task1
{
	const int MAXN = 3007;
	
	int q[MAXN];
	int dp[MAXN][MAXN];
	
	int qpow ( int a, int b )
	{
		LL base = a, ans = 1;
		while ( b ){
			if ( b & 1 ) ( ans *= base ) %= MOD;
			( base *= base ) %= MOD;
			b >>= 1;
		}
		return SC ( int, ans );
	}
	
	void work ()
	{
		int l = 0, r = 0, now, v;
		q[r++] = 1;
		dp[1][0] = 1;
		while ( l < r ){
			now = q[l++];
			for ( int i = la[now]; ~i; i = edge[i].last ){
				v = edge[i].v;
				lpi ( j, 1, n ){
					addv ( dp[v][j], dp[now][j-1] );
				}
				--deg[v];
				if ( !deg[v] ) q[r++] = v;
			}
		}
		
		lpi ( i, 1, n ){
			int ans = 0;
			lpi ( j, 0, n ){
				addv ( ans, SC ( LL, dp[i][j]  ) * ( ( j || k ) ? qpow ( j, k ) : 1 ) % MOD );
			}
			printf ( "%d\n", ans );
		}
	}
}

namespace task2
{
	int q[MAXN];
	int dp[MAXN][MAXK];
	int C[MAXK][MAXK];
	int tmp[MAXK];
	
	void trans ( int u, int v );
	void calc ( int now );

	void work ()
	{
		lp ( i, 0, MAXK ){
			C[i][0] = C[i][i] = 1;
			lp ( j, 1, i ) C[i][j] = add ( C[i-1][j], C[i-1][j-1] );
		}
		
		int l = 0, r = 0, now, v;
		lpi ( i, 1, n ){
			if ( !deg[i] ){
				q[r++] = i;
			}
		}
		dp[1][0] = 1;
		while ( l < r ){
			now = q[l++];
			if ( now ^ 1 ) calc ( now );
			for ( int i = la[now]; ~i; i = edge[i].last ){
				v = edge[i].v;
				trans ( now, v );
				--deg[v];
				if ( !deg[v] ) q[r++] = v;
			}
		}
		
		lpi ( i, 1, n ){
			printf ( "%d\n", dp[i][k] );
		}
	}
	
	void trans ( int u, int v )
	{
		lpi ( i, 0, k ) addv ( dp[v][i], dp[u][i] );
	}
	
	void calc ( int now )
	{
		lpi ( i, 0, k ) tmp[i] = dp[now][i], dp[now][i] = 0;
		lpi ( i, 0, k ){
			lpi ( j, 0, i ){
				addv ( dp[now][i], SC ( int, SC ( LL, C[i][j] ) * tmp[j] % MOD ) );
			}
		}
	}
}




int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "xmasdag" );
}

void input ()
{
	scanf ( "%d%d%d", &n, &m, &k );
	int u, v;
	ke = 0;
	INIT ( la, -1 );
	lp ( i, 0, m ){
		scanf ( "%d%d", &u, &v );
		edge[ke].setd ( u, v, la[u] );
		la[u] = ke++;
		++deg[v];
	}
}

void work ()
{
	if ( n <= 2000 && m <= 5000 ) task1::work ();
	else task2::work ();
}
