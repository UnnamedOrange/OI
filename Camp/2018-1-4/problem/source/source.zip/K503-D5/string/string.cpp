#include <cstdio>
#include <cstring>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=1e3+5,mod=998244353;
char st[10][200];
int n,m,i,j,k,ans,l,a[N];
void judge()
{
	int i,j,k,flag;
	rep(i,1,n)
	{
		l=strlen(st[i]+1);
		rep(j,1,m*2-l+1)
		{
			flag=1;
			rep(k,1,l)
			  if (st[i][k]-'0'!=a[j+k-1]) flag=0;
			if (flag) break;
		}
		if (!flag) return;
	}
	ans++;
}
void dfs(int x)
{
	if (x>2*m) {judge();return;}
	if (x>m) {
		a[x]=a[2*m-x+1]^1;
		dfs(x+1);
	}
	else {
	  a[x]=1; dfs(x+1);
	  a[x]=0; dfs(x+1);
	}
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n) scanf("%s",st[i]+1);
	if (m<=15) dfs(1);
    printf("%d\n",ans);
	return 0;
}
