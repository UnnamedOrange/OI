#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
int n,q,t,a[100010],tot,b[100010],c[100010],ans,id[100010];
int cnt,head[100010],to[200010],nxt[200010];
bool vis[100010];
void add(int x,int y)
{
	cnt++;
	to[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
void dfs(int x,int fa)
{
	tot++;
	a[x]=tot;
	id[tot]=x;
	for (int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if (y==fa)
		{
			continue;
		}
		dfs(y,x);
	}
	b[x]=tot;
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=read();
	q=read();
	t=read();
	//scanf("%d%d%d",&n,&q,&t);
	for (int i=1;i<=n;i++)
	{
		c[i]=read();
	}
	for (int i=1;i<n;i++)
	{
		int x,y;
		x=read();
		y=read();
		//scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	dfs(1,0);
	while (q--)
	{
		int op,x,y,l,r;
		op=read();
		if (op==1)
		{
			x=read();
			l=read();
			r=read();
			if (t==1)
			{
				x^=ans;
				l^=ans;
				r^=ans;
			}
			ans=0;
			memset(vis,false,sizeof(vis));
			for (int i=a[x];i<=b[x];i++)
			{
				int col=c[id[i]];
				if (col>=l && col<=r)
				{
					if (!vis[col])
					{
						vis[col]=true;
						ans++;
					}
				}
			}
			printf("%d\n",ans);
		}
		else
		{
			x=read();
			y=read();
			if (t==1)
			{
				x^=ans;
				y^=ans;
			}
			c[x]=y;
		}
	}
	return 0;
}
