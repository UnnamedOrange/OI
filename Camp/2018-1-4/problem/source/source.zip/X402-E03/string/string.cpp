#include <bits/stdc++.h>
using namespace std ;
const int maxn = 505, maxt = 10 ;
int n, m, sz[maxt], ans, len ;
char ch[maxn] ;
bool p[maxn], s[maxt][maxn] ;
bool judge ( int x ) {
	int i, j, k ;
	for ( i = 1 ; i <= m ; i ++, x >>= 1 )
		p[i] = x&1, p[len-i+1] = p[i]^1 ;
	bool fg ;
	for ( i = 1 ; i <= n ; i ++ ) {
		fg = 0 ;
		for ( k = 1 ; k <= len ; k ++ ) {
			fg = 1 ;
			for ( j = 1 ; j <= sz[i] ; j ++ )
				if (s[i][j] ^ p[k+j-1]) {
					fg = 0 ;
					break ;
				}
			if (fg) break ;
		}
		if (!fg) return 0 ;
	}
	return 1 ;
}
int main() {
	freopen ( "string.in", "r", stdin ) ;
	freopen ( "string.out", "w", stdout ) ;
	
	scanf ( "%d%d", &n, &m ) ;
	len = m<<1 ;
	int i, j, S ;
	for ( i = 1 ; i <= n ; i ++ ) {
		scanf ( "%s", ch+1 ) ;
		sz[i] = strlen(ch+1) ;
		for ( j = 1 ; j <= sz[i] ; j ++ )
			s[i][j] = ch[j]-'0' ;
	}
	S = (1<<m)-1 ;
	for ( i = 0 ; i <= S ; i ++ )
		if (judge(i)) ++ ans ;
	cout << ans << endl ;
	return 0 ;
}
