#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define ll long long
#define N 100010
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	puts("orz ltx"); 
	return 0;
}