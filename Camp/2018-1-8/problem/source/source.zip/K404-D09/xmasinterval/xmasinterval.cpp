#include <cstdio>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

const int NON = 500005;
int N, M, L[NON], R[NON], P[NON];

inline void init() {
	N = get_int();
	M = get_int();
	for(int i = 1; i <= N; ++i)
		in >>L[i] >>R[i];
	for(int i = 1; i <= N; ++i)
		P[i] = get_int();
}

inline int Check(int x) {
	int Index[21] = {0}, bit = 1;
	while(x) {
		if(x & 1) Index[++Index[0]] = bit;
		++bit;
		x >>= 1;
	}
	for(int i = 1; i <= M; ++i) {
		bool b = false;
		for(int j = 1; !b && j <= Index[0]; ++j)
			if(L[Index[j]] <= P[i] && P[i] <= R[Index[j]])
				b = true;
		if(!b) return 0;
	}
	return 1;
}

inline void solve() {
	if(N <= 20) {
		int u = 1 << N, count = 0;
		for(int x = 1; x < u; ++x)
			count += Check(x);
		printf("%d\n", count);
	} else {
		printf("0\n");
	}
}

#define PROBLEM_NAME	"xmasinterval"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	init();
	solve();
	return 0;
}
