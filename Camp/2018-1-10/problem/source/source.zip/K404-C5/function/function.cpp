#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
const int R_LEN=(1<<18)|1;
struct Fast_io{
    char ibuf[R_LEN],obuf[R_LEN],*s,*t,*wt;
    int buf[50];
    Fast_io(){
        s=ibuf,t=ibuf,wt=obuf;
        memset(buf,0,sizeof(buf));
    }
    ~Fast_io(){fwrite(obuf,1,wt-obuf,stdout);}
    inline char getc(){
        (s==t)&&(t=(s=ibuf)+fread(ibuf,1,R_LEN,stdin));
        return (s==t)?-1:*s++;
    }
    inline int rd(){
        char ch=getc(); int i=0,f=1;
        while(!isdigit(ch)){if(ch=='-')f=-1;ch=getc();}
        while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getc();}
        return i*f;
    }
    inline void print(char c){
        (wt==obuf+R_LEN) && (fwrite(obuf,1,R_LEN,stdout),wt=obuf);
        *wt++=c;
    }
    template<typename T>
    inline void W(T x){
        if(!x){print('0');return;}
        if(x<0){print('-');x=-x;}
        while(x){buf[++buf[0]]=x%10;x/=10;}
        while(buf[0])print(buf[buf[0]--]+'0');
    }
}io;
const int N=3e6+50;
int T,pr[N],pt,npr[N],mnpr[N],mncnt[N];
ll g[N];
inline void seive(){
	g[1]=1; 
	for(int i=2;i<N;++i){
		if(!npr[i]){
			pr[++pt]=i; 
			g[i]=3;
			mnpr[i]=i;
			mncnt[i]=1;
		}
		for(int j=1;j<=pt;++j){
			if((ll)pr[j]*i>=N)break;
			int k=pr[j]*i;
			npr[k]=1;
			if(!(i%pr[j])){
				mnpr[k]=mnpr[i]*pr[j];
				mncnt[k]=mncnt[i]+1;
				g[k]=(mnpr[k]==k?(2*mncnt[k]+1):g[k/mnpr[k]]*g[mnpr[k]]);
				break;
			}else{
				g[k]=g[i]*g[pr[j]];
				mnpr[k]=pr[j];
				mncnt[k]=1;
			}
		}
	}
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	seive();
	for(int i=1;i<N;i++)g[i]+=g[i-1];
	for(T=io.rd();T;T--){
		io.W(g[io.rd()]); io.print('\n');
	}
}
