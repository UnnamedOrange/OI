#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
//const int MOD = 998244353;
//int n, m, len[10];
//char ch[110];
//int s[10][110], fs[10][110];
//int ok[10][110];
//bool used[10];
//pair <int, int> tt[10];
//int ans, nxt[110];
//inline int ksm (int a, int p) {
//	if (p == 0) return 1;
//	if (p == 1) return a;
//	int l = ksm (a, p >> 1);
//	l = 1ll * l * l % MOD;
//	if (p & 1) l = 1ll * l * a % MOD;
//	return l;
//}
//inline void dfs (int step, int l, int lt, int c) {
//	if (step > n) {
//		printf ("xxx!!\n");
//		for (int i = 1; i <= n; i++) printf ("%d %d\n", tt[i].first, tt[i].second);
//		return;
//	}
//	for (int i = 1; i <= n; i++) if (!used[i]) {
//		used[i] = true;
//		if (tt[step - 1].second <= 0) {
//			tt[step] = make_pair (i, -1);
//			dfs (step + 1);
//			tt[step] = make_pair (i, 0);
//			dfs (step + 1);
//		}
//		for (int p = 1; p <= ok[i][0]; p++) {
//			tt[step] = make_pair (i, p);
//			bool b = true;
//			for (int j = 1; j < step && b; j++) if (tt[j].second > 0) {
//				for (int x = ok[i][0], y = ok[tt[j].first][tt[j].second]; x && y; x--, y--) if (s[i][x] != s[tt[j].first][y]) { b = false; break; }
//				for (int x = ok[i][0] + 1, y = ok[tt[j].first][tt[j].second]; x <= len[i] && y <= len[tt[j].first]; x++, y++) if (s[i][x] != s[tt[j].first][y]) { b = false; break; }
//			}
//			if (tt[step - 1].second > 0) for (int j = 1; j < step; j++) if (tt[j].second > 0) if (max (ok[i][0], len[i] - ok[i][0]) > max (ok[tt[j].first][tt[j].second], len[tt[j].first] - ok[tt[j].first][tt[j].second]));
//			if (tt[step + 1])
//			if (b) dfs (step + 1);
//		}
//		used[i] = false;
//	}
//}
int n, m, len[10];
char ch[10][110], s[1010];
inline bool check () {
	bool r = true;
	for (int i = 1; i <= n; i++) {
		bool b = false;
		for (int p = 1; p <= 2 * m - len[i] + 1; p++) {
			bool ok = true;
			for (int j = 1; j <= len[i]; j++) if (s[p + j - 1] != ch[i][j]) ok = false;
			if (ok) b = true;
		}
		if (!b) r = false;
	}
	return r;
}
int ans;
inline void dfs (int step) {
	if (step > m) {
		if (check ()) ans++;
		return;
	}
	s[step] = '1', s[2 * m - step + 1] = '0';
	dfs (step + 1);
	s[step] = '0', s[2 * m - step + 1] = '1';
	dfs (step + 1);
}
int main () {
	freopen ("string.in", "r", stdin);
	freopen ("string.out", "w", stdout);
//	scanf ("%d%d", &n, &m);
//	for (int i = 1; i <= n; i++) {
//		scanf ("%s", ch + 1);
//		len[i] = strlen (ch + 1);
//		for (int p = 1; p <= len[i]; p++) s[i][p] = ch[p] - '0', fs[i][len[i] - p + 1] = !s[i][p];
//		/*for (int p = 1; p <= len[i]; p++) printf ("%d", s[i][p]);
//		printf ("\n");
//		for (int p = 1; p <= len[i]; p++) printf ("%d", fs[i][p]);
//		printf ("\n");*/
//		for (int p = 1; p < len[i]; p++) {
//			bool b = true;
//			for (int x = p, y = p + 1; x && y <= len[i]; x--, y++) if (s[i][x] == s[i][y]) { b = false; break; }
//			if (b) ok[i][++ok[i][0]] = p;
//		}
//	}
//	for (int i = 1; i <= n; i++) for (int j = 1; j <= ok[i][0]; j++) printf ("%d%c", ok[i][j], " \n"[j == ok[i][0]]);
//	dfs (1, 0, 0, 1);
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) scanf ("%s", ch[i] + 1), len[i] = strlen (ch[i] + 1);
	dfs (1);
	printf ("%d\n", ans);
	return 0;
}
