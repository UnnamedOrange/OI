#include <bits/stdc++.h>

int type, n;
const int N = 20;

struct symbol
{
	int x, p;
}p[N];
int Pow[N];

void init()
{
	p[0] = (symbol) {1, 6};
	for(int i = 0; i <= 5; ++i)
		for(int x = 0; x <= 2; ++x) p[i*3+x+1] = (symbol) {x, i};
	Pow[0] = 1;
	for(int i = 1; i <= 6; ++i) Pow[i] = Pow[i-1] * 3;
}

int encode(int x, int y)
{
	int X[10], Y[10];
	for(int i = 6; i >= 0; --i){
		X[i] = x / Pow[i];
		x %= Pow[i];
	}
	for(int i = 6; i >= 0; --i){
		Y[i] = y / Pow[i];
		y %= Pow[i];
	}
	for(int i = 6; i >= 0; --i)
		if(Y[i] != X[i]){
			if(i != 6) return i*3 + X[i]+1;
			else return 0;
		}
	return 0;
}

bool decode(int q, int h)
{
	q %= Pow[p[h].p+1];
	return q / Pow[p[h].p] == (p[h].x+1)%3;
}

int main()
{
    int T;
    init();
    scanf("%d%d%d", &type, &n, &T);
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
	return 0;
}
