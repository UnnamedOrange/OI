#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define LL long long
using namespace std;
const LL Maxn = 100000 + 100, Mod = 1000000000 + 7;
LL A[Maxn], Fac[Maxn];
LL N, a, b;
inline LL Mult(LL a, LL b)
{
	LL Ans = 0;
	while (b)
	{
		if (b & 1) (Ans += a) %= Mod;
		a = (a + a) % Mod;
		b >>= 1;
	}
	return Ans;
}
inline LL Pow(LL a, LL b)
{
	LL Ans = 1;
	while (b)
	{
		if (b & 1) Ans = Mult(Ans, a) % Mod;
		a = Mult(a, a) % Mod;
		b >>= 1;
	}
	return Ans;
}
inline LL C(LL n, LL m)
{
	return Mult(Mult(Fac[n], Pow(Fac[m], Mod - 2)), Pow(Fac[n - m], Mod - 2));
}
LL B[Maxn];
inline void BF1()
{
	LL Ans1 = Pow(2, N - 1);
	cout<<0<<" "<<0<<" ";
	int fl = 0;
	for (int i = 1; i <= N; ++i)
		if (A[i] % (a + b))fl = 1;
	if (fl)
	cout<<Ans1<<" "<<Ans1<<endl;
	else cout<<0<<" "<<Pow(2, N)<<endl;
}
LL Q[1001], P[1001];
LL Ans1, Ans2, Ans3, Ans4;
inline void Check()
{
	LL flag = 0;
	for (LL i = 1; i <= N; ++i) P[i] = Q[i] * A[i];
	LL win1, win2;
	while (1)
	{
		LL fl = 0, Max = 0, k;
		for (LL i = 1; i <= N; ++i)
			if (P[i] >= a)
			{
				fl = 1;
				if (P[i] > Max)Max = P[i], k = i;
			}
		if (!fl)
		{
			win1 = 2;
			break;
		}
		P[k] -= a;
		fl = 0;
		Max = 0;
		for (LL i = 1; i <= N; ++i)
			if (P[i] >= b)
			{
				fl = 1;
				if (P[i] > Max)Max = P[i], k = i;
			}
		if (!fl)
		{
			win1 = 1;
			break;
		}
		P[k] -= b;
	}
	for (LL i = 1; i <= N; ++i) P[i] = Q[i] * A[i];
	while (1)
	{
		LL fl = 0, Max = 0, k;
		for (LL i = 1; i <= N; ++i)
			if (P[i] >= b)
			{
				fl = 1;
				if (P[i] > Max) Max = P[i], k = i;
			}
		if (!fl)
		{
			win2 = 1;
			break;
		}
		P[k] -= b;
		fl = 0;
		Max = 0;
		for (LL i = 1; i <= N; ++i)
			if (P[i] >= a)
			{
				fl = 1;
				if (P[i] > Max) Max = P[i], k = i;
			}
		if (!fl)
		{
			win2 = 2;
			break;
		}
		P[k] -= a;
	}
	if (win1 == win2)
	{
		if (win1 == 1)
			Ans1 ++;
		else 
			Ans2 ++;
	}
	else 
	{
		if (win1 == 1) Ans3 ++;
		else Ans4 ++;
	}
}
inline void dfs(LL x)
{
	if (x == N)
	{
		Check();
		return ;
	}
	Q[++x] = 1;
	dfs(x);
	Q[x] = 0;
	dfs(x);
}
inline void BF2()
{
	Ans1 = Ans2 = Ans3 = Ans4 = 0;
	dfs(0);
	cout<<Ans1<<" "<<Ans2<<" "<<Ans3<<" "<<Ans4<<endl;
}
int main()
{
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	Fac[0] = 1;
	for (LL i = 1; i <= 100000; ++i)
		Fac[i] = Mult(Fac[i - 1], i);
	scanf("%lld%lld%lld", &N, &a, &b);
	for (LL i = 1; i <= N; ++i)
		scanf("%lld", &A[i]);
	if (a == b)
	{
		BF1();
		return 0;
	}
	else
	{
		BF2();
		return 0;
	}
	return 0;
}
