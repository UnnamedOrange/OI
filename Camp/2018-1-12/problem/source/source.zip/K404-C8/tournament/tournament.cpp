#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
const int N=100005;
typedef long long ll;
const ll mod=998244353;

int power_mod(int a,ll b) 
{
	int ans=1;
	while (b) 
	{
		if (b&1) ans=(ll)ans*a%mod;
		a=(ll)a*a%mod;
		b>>=1;
	}
	return ans;
}

int n,k;


int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);

	scanf("%d%d",&n,&k);	
	if (k==3) 
	{
		int ans=power_mod(2,(ll)n*(n-1)/2),tmp=1;
		tmp=1;for (int i=1;i<=n;i++) tmp=(ll)tmp*i%mod;
		printf("%lld\n",(ans-tmp+mod)%mod);
		return 0;
	}	
	return 0;
}
