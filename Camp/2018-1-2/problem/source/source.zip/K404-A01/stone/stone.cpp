//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
lovelive mod=1e9+7;
void read(lovelive &x)
{
  x=0;
  char c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c>='0'&&c<='9')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
lovelive pow1(lovelive x,lovelive k)
{
  lovelive r=1;
  while(k)
  {
    if(k&1)
      r*=x;
    x*=x;
    r%=mod;
    x%=mod;
    k>>=1;
  }
  return r;
}
lovelive x[100010],ct[5];
lovelive ans1,ans2,ans3,ans4;
int main()
{
  freopen("stone.in","r",stdin);
  freopen("stone.out","w",stdout);
  lovelive n,a,b,p=0;
  read(n);read(a);read(b);
  if(a>b)
    swap(a,b),p=1;
  for(int i=1;i<=n;i++)
  {
  	read(x[i]);
  	x[i]%=(a+b);
  	if(x[i]<a)
  	  ct[0]++;
  	if(x[i]>=a&&x[i]<b)
  	  ct[1]++;
  	if(x[i]>=b&&x[i]>=2*a)
  	  ct[2]++;
  	if(x[i]>=b)
  	  ct[3]++;
  	if(x[i]>=2*a)
  	  ct[4]++;
  }
  if(a*2>=b)
  {
  	ans1+=(pow1(2,ct[1])-1)*pow1(2,n-ct[1])%mod;
  	n-=ct[1];
  	ct[3]-=ct[4];
    if(ct[2]>=2)
      ans1+=(pow1(2,ct[2])-ct[2]-1)*pow1(2,n-ct[2])%mod;
    if(ct[3])
      {
      	ans3=(ct[2]*pow1(2,n-ct[2]-1)%mod);
      	ans4=(ct[2]*pow1(2,n-ct[2]-1)%mod);
	  }
	else
	  ans3+=ct[2]*pow1(2,n-ct[2])%mod;
	n-=ct[2];
    if(ct[3])
    {
	  ans4+=pow1(2,n-1);
	  ans3+=pow1(2,n-1);
    }
    else
      ans4+=pow1(2,n);
  }
  else
  {
  	ans1+=(pow1(2,ct[1])-1)*pow1(2,n-ct[1])%mod;
  	n-=ct[1];
  	ct[4]-=ct[3];
  	if(ct[2]>=2)
  	  ans1+=(pow1(2,ct[2])-ct[2]-1)*pow1(2,n-ct[2])%mod;
  	if(ct[2])
  	  ans3+=ct[2]*pow1(2,n-ct[2])%mod;
  	ans4+=pow1(2,ct[0]);
  }
  if(p)
    swap(ans1,ans2);
  printf("%lld %lld %lld %lld\n",ans1%mod,ans2%mod,ans3%mod,ans4%mod);
  return 0;
}
