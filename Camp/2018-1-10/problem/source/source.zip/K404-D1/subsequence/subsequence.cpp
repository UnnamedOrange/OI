#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#define N 4010
#define inf 1000000000
using namespace std;
int n,m,k;
int a[N],b[N],f[4010][4010],nxa[4010][4010],nxb[4010][4010];
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("subsequence.in","r",stdin);
    freopen("subsequence.out","w",stdout);
    n=read(),m=read(),k=read();
    for(int i=1; i<=n; i++)
        a[i]=read();
    for(int i=1; i<=m; i++)
        b[i]=read();
    for(int id=1; id<=k; id++)
    {
        int lst=n+1;
        for(int i=n; i>=0; i--)
        {
            nxa[i][id]=lst;
            if(a[i]==id)
                lst=i;
        }
    }
    for(int id=1; id<=k; id++)
    {
        int lst=m+1;
        for(int i=m; i>=0; i--)
        {
            nxb[i][id]=lst;
            if(b[i]==id)
                lst=i;
        }
    }
    memset(f,63,sizeof(f));
    f[0][0]=0;
    for(int i=0; i<=n+1; i++)
        for(int j=0; j<=m+1; j++)
            if(f[i][j]<f[n+1][m+1])
                for(int id=1; id<=k; id++)
                {
                    int ni=nxa[i][id],nj=nxb[j][id];
                    f[ni][nj]=min(f[ni][nj],f[i][j]+1);
                }
    printf("%d",f[n+1][m+1]);
    return 0;
}
