#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
const int N=100005;
typedef long long ll;
const ll mod=998244353;


int n,p[N],ans;bool b[N],o[N];
void work()
{
	for (int i=1;i<=n;i++) o[i]=false;//printf("%d ",p[i]);puts("");
	for (int i=1;i<=n;i++) if (!o[i]) 
	{
		int t=i,cnt=0;
		do
		{
			cnt++;
			o[t]=true;
			t=p[t];
		}while (t!=i);
		if (cnt&1) return ;
	}
	ans++;
}

void dfs(int t) 
{
	if (t==n+1) {work();return ;}
	if (p[t]) {dfs(t+1);return ;}
	for (int i=1;i<=n;i++) if (!b[i]) 
	{
		p[t]=i;
		b[i]=true;
		dfs(t+1);
		b[i]=false;
	}
	p[t]=0;
}


int main()
{
	freopen("permutation.in","r",stdin);	
	freopen("permutation.out","w",stdout);
	
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d",&p[i]);
	
	if (n<=8) 
	{
		for (int i=1;i<=n;i++) if (p[i]) b[p[i]]=true;
		dfs(1);
		printf("%d\n",ans);
	}
	else 
	{
		if (n&1) 
		{
			puts("0");
			return 0;
		}
		ans=1;
		for (int i=3;i<=n;i+=2) ans=(ll)ans*i%mod;
		ans=(ll)ans*ans%mod;
		printf("%d\n",ans);
	}
	return 0;
}

