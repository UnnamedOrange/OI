#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

FILE* seed,in;

typedef std::pair<int,int> pii;
pii s[1000000];

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("xmasdag.in","w",stdout);//look at here

	int n=100000,m=0,k=80;

	for(int i=n-1;i;i--)
	{
		s[++m]=pii(i,i+1);
		int lim=rand()%(std::min(n-i,100));
		if(m>=190000-i)lim=0;
		while(lim--)
			s[++m]=pii(i,rand()%(n-i)+i+1);
	}

	printf("%d %d %d\n",n,m,k);
	for(int i=m;i;i--)
		printf("%d %d\n",s[i].first,s[i].second);

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
