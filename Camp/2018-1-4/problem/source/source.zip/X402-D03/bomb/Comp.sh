while true; do
echo ">>> gen"
python3 gen.py
echo ">>> bf"
./bf
echo ">>> bomb"
./bomb
if diff ./bf.out ./bomb.out;
then continue;
else break;
fi
done
