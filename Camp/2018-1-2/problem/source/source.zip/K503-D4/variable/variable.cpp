#include<bits/stdc++.h>
#define maxn 100
#define INF 1000000000000000
#define ll long long
using namespace std;
int n,p,q,x[maxn],y[maxn],z[maxn],t1[maxn],t2[maxn],r[maxn];
ll ans,a[maxn],b[maxn],c[maxn],d[maxn],e[maxn],f[maxn],ch[maxn],w;
void sc()
{
	for (int i=1;i<=q;i++)
	{
		if (r[i]==0 && ch[t1[i]]>ch[t2[i]]) return;
		if (r[i]==1 && ch[t1[i]]!=ch[t2[i]]) return;
		if (r[i]==2 && ch[t1[i]]>=ch[t2[i]]) return;
	}
	ll sum=0;
	for (int i=1;i<=p;i++)
	{
		int tmp;
		tmp=a[i]*abs(ch[x[i]]-ch[y[i]])+b[i]*abs(ch[y[i]]-ch[z[i]])+c[i]*abs(ch[z[i]]-ch[x[i]]);
		tmp+=d[i]*(ch[x[i]]-ch[y[i]])+e[i]*(ch[y[i]]-ch[z[i]])+f[i]*(ch[z[i]]-ch[x[i]]);
		sum+=tmp;
	}
	for (int i=1;i<=n;i++) sum+=ch[i];
	if (sum<ans) ans=sum;
}
void work(int dep)
{
	if (dep>n) sc();
	else
	for (int i=0;i<=1;i++)
	{
		if (i==0) ch[dep]=-w; else ch[dep]=w;
		work(dep+1);
	}
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--)
	{
		ans=INF;
		scanf("%d%lld%d%d",&n,&w,&p,&q);
		for (int i=1;i<=p;i++)
			scanf("%d%d%d%lld%lld%lld%lld%lld%lld",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for (int i=1;i<=q;i++)
			scanf("%d%d%d",&t1[i],&t2[i],&r[i]);
		work(1);
		printf("%lld\n",ans);
	}
	return 0;
}
