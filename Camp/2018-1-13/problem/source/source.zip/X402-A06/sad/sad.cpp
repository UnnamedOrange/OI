#include<bits/stdc++.h>

using namespace std;

const int maxn = 100010;

char s[maxn];

int n;

int main(){
	
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);

	scanf("%d", &n);
	scanf("%s", s);

	for(int i = 2, x, y;i <= n; ++i) scanf("%d%d", &x, &y);
	int len = strlen(s), Ans = 0;
	for(int i = 0;i < len; ++i) if(s[i] == '1') ++Ans;

	printf("%d\n", Ans);

	return 0;
}
