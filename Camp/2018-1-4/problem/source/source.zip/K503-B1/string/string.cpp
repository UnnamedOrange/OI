#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
int T,opt,n,m,a[maxn],b[maxn],ans=0;
int i,j,k,mp[510][510],f[510];
char s[510][510];
void check(){
	int i,j,k,t1,t2=0;
	for (i=1;i<=m;i++) a[i]=b[i];
	for (i=m+1;i<=2*m;i++){
		a[i]=a[2*m-i+1];
		if (a[i]==0) a[i]=1;
		else a[i]=0;
	}
	for (i=1;i<=n;i++){
		for (j=1;j<=2*m-f[i]+1;j++){
			t1=1;
			for (k=1;k<=f[i];k++){
				if (a[j+k-1]!=mp[i][k]){
					t1=0; break;
				}
			}
			if (t1==1) break;
		}
		t2=t2+t1;
	}
	if (t2==n) ans++;
}
void work(int x){
	if (x==m+1){
		check();
		return;
	}
	b[x]=0; work(x+1);
	b[x]=1; work(x+1);
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (i=1;i<=n;i++){
		scanf("%s",s[i]);
		j=strlen(s[i]);
		for (k=0;k<=j;k++){
			if ((s[i][k]=='0')||(s[i][k]=='1')){
				f[i]++; mp[i][f[i]]=s[i][k]-'0';
			}
		}
	}
	work(1);
	printf("%d\n",ans);
	return 0;
}
