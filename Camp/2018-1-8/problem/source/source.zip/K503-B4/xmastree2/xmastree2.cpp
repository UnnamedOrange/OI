#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
const int maxn=35;
int n,head[maxn],f[maxn],E[maxn],V[maxn],cnt,wi[maxn],ri[maxn];
int root,ans=0;
short ai[maxn];
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
void dfs(int now,int fa)
{
	f[now]=fa;
	for(int i=head[now];i!=0;i=E[i])
		if(V[i]!=fa)
			dfs(V[i],now);
}
int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	read(n);
	for(int i=1,u,v;i<n;i++)
	{
		read(u);
		read(v);
		E[++cnt]=head[u];
		V[cnt]=v;
		head[u]=cnt;
		E[++cnt]=head[v];
		V[cnt]=u;
		head[v]=cnt;
	}
	for(int i=1;i<=n;i++)
	{
		read(wi[i]);
		read(ri[i]);
	}
	for(int i=1;i<=n;i++)
		if(ri[i])
		{
			root=i;
			dfs(i,0);
			for(int i=1;i<=n;i++)
				ai[i]=i;
			int res;
			do
			{
				res=0;
				for(short v=1;v<=n;v++)
				{
					if(ai[v]==1&&v!=root)
					{
						res=0;
						break;
					}
					if(ai[f[v]]<ai[v])
						res+=wi[v]*ai[v];
					else
					{
						res=0;
						break;
					}
				}
				if(res>ans)
					ans=res;
			}
			while(std::next_permutation(ai+1,ai+n+1));
		}
	std::cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
