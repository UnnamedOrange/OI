//2018-1-2
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M (200+5)
#define N (100000+5)

int n;
char s[N];
bool ins[N];

bool Check(){
	For(i, 1, n>>1) if(s[i] != s[n-i+1]) return false;
	return true;
}

bool Checkaba(){
	bool flag = true;
	For(i, 2, n) if(s[i] == s[i-1]){
		flag = false; break;
	}

	if(flag) return true;
	if(!(n&1)) return false;
	
	char me = s[1];
	For(i, 1, n>>1) if(s[i] != me) return false;
	For(i, (n>>1)+2, n) if(s[i] != me) return false;
	return true;
}

int main(){
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	
	int T;
	scanf("%d", &T);

	while(T--){
		scanf("%d", &n);
		scanf("%s", s+1);
		if(!Check()){puts("1"); continue;}

		Set(ins, 0);
		For(i, 1, n) ins[s[i]] = true;

		int cnt = 0;
		For(i, 'a', 'z') cnt += ins[i];

		if(cnt >= 3) puts("2");
		else if(cnt == 1) puts("-1");
		else if(Checkaba()) puts("-1"); else puts("2");
	}

	return 0;
}
