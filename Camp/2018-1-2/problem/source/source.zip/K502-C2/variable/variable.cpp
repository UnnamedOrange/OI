#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while(c = getchar(), c >= '0');
}

const int M = 505;
const int INF = (int)1e9;

int T, n, W, p, q, mat[M][M], val[M];

namespace NW {
	
	const int V = M;
	const int E = 20000;
	
	int n, Head[V], tot, level[M], que[M];
	struct Node {int to,cap,nxt;} Edge[E << 1];
	
	void Init_graph(int _n) {
		n = _n; tot = 0;
		for (int i = 1; i <= n; i++) Head[i] = -1;
	}
	
	void Addedge(int a, int b, int c) {
		Edge[tot] = (Node) {b, c, Head[a]}; Head[a] = tot++;
		Edge[tot] = (Node) {a, 0, Head[b]}; Head[b] = tot++;
	}
	
	bool BFS(int s, int t) {
		for (int i = 1; i <= n; i++) level[i] = -1;
		int l = 0, r = -1;
		level[s] = 0; que[++r] = s;
		while (l <= r) {
			int now = que[l++];
			for (int i = Head[now]; ~i; i = Edge[i].nxt) {
				int to = Edge[i].to;
				if (~level[to] || !Edge[i].cap) continue;
				level[to] = level[now] + 1;
				que[++r] = to;
			}
		}
		return ~level[t];
	}
	
	int dfs(int s, int t, int f) {
		if (s == t) return f;
		for (int i = Head[s]; ~i; i = Edge[i].nxt) {
			int to = Edge[i].to;
			if (level[to] != level[s] + 1 || !Edge[i].cap) continue;
			int d = dfs(to, t, min(Edge[i].cap,f));
			if (d) {
				Edge[i].cap -= d;
				Edge[i ^ 1].cap += d;
				return d;
			}
		}
		return 0;
	}
	
	int maxflow(int s, int t) {
		int rs = 0;
		while (BFS(s, t)) {
			int f;
			while ((f = dfs(s, t, INF)) > 0) rs += f;
		}
		return rs;
	}
	
}

void solve() {
	memset(mat, 0, sizeof(mat));
	for (int i = 1; i <= n; i++) val[i] = 1;
	for (int i = 1; i <= p; i++) {
		int x, y, z, a, b, c, d, e, f;
		Rd(x), Rd(y), Rd(z), Rd(a), Rd(b), Rd(c), Rd(d), Rd(e), Rd(f);
		mat[x][y] += a, mat[y][z] += b, mat[z][x] += c;
		val[x] += (d - f);
		val[y] += (e - d);
		val[z] += (f - e);
	}
	int ans = 0;
	NW::Init_graph(n + 2);
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			if (i == j || !mat[i][j]) continue;
			NW::Addedge(i, j, 2 * mat[i][j]);
			NW::Addedge(j, i, 2 * mat[i][j]);
		}
	}
	for (int i = 1; i <= n; i++) {
		if (val[i] > 0) {
			ans -= val[i];
			NW::Addedge(i, n + 2, 2 * val[i]);
		}
		if (val[i] < 0) {
			ans += val[i];
			NW::Addedge(n + 1, i, 2 * -val[i]);
		}
	}
	for (int i = 1; i <= q; i++) {
		int x, y, r;
		Rd(x), Rd(y), Rd(r);
		if (r == 0) NW::Addedge(x, y, INF);
		else if (r == 1) NW::Addedge(x, y, INF), NW::Addedge(y, x, INF);
		else NW::Addedge(x, n + 2, INF), NW::Addedge(n + 1, y, INF);
	}
	ans += NW::maxflow(n + 1, n + 2);
	cout << (ll) W * ans << endl;
}

int main() {
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	Rd(T);
	while (T--) {
		Rd(n), Rd(W), Rd(p), Rd(q);
		solve();
	}
	return 0;
}
