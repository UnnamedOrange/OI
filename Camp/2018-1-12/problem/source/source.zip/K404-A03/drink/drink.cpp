//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<set>
using namespace std;
#define db double
const int maxn=1e6+7,base=50;
int n,sa[maxn];
db a[maxn],ans,now,now2,t;
set<int> G;
set<int>::iterator it,it2;

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

bool cmp(int x,int y) {
	return a[x]==a[y]? x<y:a[x]>a[y];
}

void get_ans1(int x,int y) {
	db p=(db)x/db(y);
	now+=now2*(1.0-p); now2*=0.5*p;
}

void get_ans2(int x,int y) {
	get_ans1(n+1-x,n+1-y);
}

int main() {
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();int x;
	for(int i=1;i<=n;++i) a[i]=read()/2.0,sa[i]=i;
	sort(sa+1,sa+n+1,cmp);
	for(int i=1;i<=n;++i) {
		x=sa[i]; now=0;
		G.insert(x);
		it=G.find(x);it2=it;
		now2=1000;now=0;
		for(int j=1;j<=base&&it2!=G.begin();++j) {
			x=*it2;--it2;
			get_ans1(*it2,x);
		}
		t=now+now2;
		it2=it;x=sa[i];++it2;
		now2=1000;now=0;
		for(int j=1;j<=base&&it2!=G.end();++j) {
			get_ans2(*it2,x);
			x=*it2;++it2;
		}
		now+=now2;
		x=sa[i];
		ans+=a[x]*(n-x+1)*x*t*now;
	}
	ans/=(db)(n*n);ans/=1000000;
	printf("%.3f",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
/*
5
1 2 3 4 1
*/
