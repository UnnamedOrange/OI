#include<bits/stdc++.h>
using namespace std;
const int p=998244353;
typedef long long ll;
int n,m,k,size,fir[120000],a[505][505];
struct edge{int u,v,nex;}e[220000];
struct node{
	int degree,f[40];
	void plus(){
		for (int i=n;i;i--)
		for (int j=i-1;j>=0;j--)
		f[i]=(f[i]+(ll)f[j]*a[i][j])%p;
	}
}f[100005];
void add(int u,int v){e[++size].u=u;e[size].v=v;e[size].nex=fir[u];fir[u]=size;f[v].degree++;}
void work(int x){
	if (x>1) f[x].plus();
	for (int i=fir[x];i;i=e[i].nex){
		int y=e[i].v;
		f[y].degree--;
		for (int j=0;j<=k;j++)
		f[y].f[j]=(f[y].f[j]+f[x].f[j])%p;
		if (f[y].degree==0) work(y);
	}
}
int cnt[2005][5005],ans[2005],b[5005];
void bf(int x){
	for (int i=fir[x];i;i=e[i].nex){
		int y=e[i].v;
		f[y].degree--;
		for (int j=0;j<=m;j++)
		cnt[y][j+1]=(cnt[y][j+1]+cnt[x][j])%p;
		if (f[y].degree==0) bf(y);
	}
}
int pow(int x,int k){
	int t=1;
	for (;k;k>>=1){
		if (k&1) t=(ll)t*x%p;
		x=(ll)x*x%p;
	}
	return t;
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for (int i=1;i<=m;i++){
		int x,y;
		scanf("%d %d",&x,&y);
		add(x,y);
	}
	for (int i=0;i<=k;i++) a[i][0]=1;
	for (int i=1;i<=k;i++)
	for (int j=1;j<=i;j++) 
	a[i][j]=(a[i-1][j]+a[i-1][j-1])%p;
	f[1].f[0]=1;cnt[1][0]=1;
	if ((n<=2000)&&(m<=5000)){
		bf(1);
		for (int i=0;i<=m;i++)
		b[i]=pow(i,k);
		for (int i=1;i<=n;i++)
		for (int j=0;j<=m;j++)
		ans[i]=(ans[i]+(ll)cnt[i][j]*b[j])%p;
		for (int i=1;i<=n;i++)
		printf("%d\n",ans[i]);
	}
	else {
		work(1);
		for (int i=1;i<=n;i++)
		printf("%d\n",f[i].f[k]);
	}
	return 0;
}
