#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
#define rep(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_; ++i) 
int bword(char s[]) {
	int l = strlen(s);
	if(l == 1) return 1;
	rep(i, 0, (l >> 1) - 1) 
		if(s[i] != s[l - i - 1]) return 0;
	return 1;
}
#define Maxn 10009
char s[Maxn], t[Maxn], z[Maxn];
int n;
void _copy(char t[], char s[], int a, int b) {
	char tmp[2];
	strcpy(t, "\0");
	rep(i, a, b){
		tmp[0] = s[i];
		tmp[1] = '\0';
		strcat(t, tmp);
	}
}
void _del(char t[], char s[], int a, int b) {
	char tmp[2];
	strcpy(t, "\0");
	rep(i, 0, a - 1){
		tmp[0] = s[i]; tmp[1] = '\0';
		strcat(t, tmp);
	}
	rep(i, b + 1, n - 1){
		tmp[0] = s[i]; tmp[1] = '\0';
		strcat(t, tmp);
	}
}
int main(){
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--) {
		int ans = 2333333;
		scanf("%d", &n);
		scanf("%s", s);
		if(!bword(s)) printf("1\n");
		else{
			rep(i, 0, n - 3) 
				rep(j, i + 2, n - 1)
					if(i + 1 < j){
						_copy(t, s, i, j);
						if(bword(t)) continue;
						_del(z, s, i, j);
						if(bword(z)) continue;
						ans = 2;
					}
		}
		printf("%d\n", ans == 2333333 ? -1 : ans);
	}
	return 0;
}
