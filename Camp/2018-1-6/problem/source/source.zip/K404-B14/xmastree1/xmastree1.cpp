#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int MAXN = 100010;
const int MAXS = 320;
int n, q, t;
int lastans;
int c[MAXN];
vector<int> G[MAXN];
int in[MAXN], out[MAXN], tim;
int newc[MAXN];
void dfs(int x, int f){
	in[x] = ++tim;
	for(register unsigned int i = 0; i < G[x].size(); i++){
		int y = G[x][i];
		if(y == f) continue;
		dfs(y, x);
	}
	out[x] = tim;
}
bool tag[MAXN];
int main(){
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &t);
	for(int i = 1; i <= n; i++){
		scanf("%d", &c[i]);
	}
	for(int i = 1; i < n; i++){
		int u, v;
		scanf("%d%d", &u, &v);
		G[u].PB(v);
		G[v].PB(u);
	}
	dfs(1, 0);
	for(int i = 1; i <= n; i++) newc[in[i]] = c[i];
	while(q--){
		int opt;
		scanf("%d", &opt);
		if(opt == 1){
			int x, l, r, ans = 0;
			scanf("%d%d%d", &x, &l, &r);
			x ^= lastans * t;
			l ^= lastans * t;
			r ^= lastans * t;
			register int *p;
			for(p = newc + in[x]; p + 3 <= newc + out[x]; p += 4){
				register int *p1 = p + 1, *p2 = p + 2, *p3 = p + 3;
				if(l <= *p && *p <= r){ans += !tag[*p];tag[*p] = true;}
				if(l <= *p1 && *p1 <= r){ans += !tag[*p1];tag[*p1] = true;}
				if(l <= *p2 && *p2 <= r){ans += !tag[*p2];tag[*p2] = true;}
				if(l <= *p3 && *p3 <= r){ans += !tag[*p3];tag[*p3] = true;}
			}
			for(; p <= newc + out[x]; p++){
				if(l <= *p && *p <= r){ans += !tag[*p];tag[*p] = true;}
			}
			printf("%d\n", lastans = ans);
			for(p = newc + in[x]; p + 3 <= newc + out[x]; p += 4){
				register int *p1 = p + 1, *p2 = p + 2, *p3 = p + 3;
				tag[*p] = false;
				tag[*p1] = false;
				tag[*p2] = false;
				tag[*p3] = false;
			}
			for(; p <= newc + out[x]; p++){
				tag[*p] = false;
			}
		}
		else{
			int x, v;
			scanf("%d%d", &x, &v);
			x ^= lastans * t;
			v ^= lastans * t;
			newc[in[x]] = v;
		}
	}
	return 0;
}
