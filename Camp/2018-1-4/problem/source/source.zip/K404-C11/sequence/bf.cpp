#include <bits/stdc++.h>

namespace {

const int MAXN = 23;

int a[MAXN];

int n, ans;

struct Node {
    char a[MAXN];
    int step, val;
    inline bool operator<(const Node &p) const {
        return val > p.val;
    }
    
    inline void maintain() {
        val = 0;
        for (register int i = 1; i < n; i++)
            val += std::abs(a[i] - a[i - 1]) > 1;
    }
} now;

class PriorityQueue : public std::priority_queue<Node> {
    typedef std::priority_queue<Node> super;

  public:
    inline void clear() {
        super::c.clear();
    }
};

PriorityQueue q;

struct Data {
    char a[MAXN];

    inline bool operator<(const Data &p) const {
        return memcmp(a, p.a, n);
    }

    Data(const int *a) {
        for (register int i = 0; i < n; i++) this->a[i] = a[i];
    }

    Data(const char *a) {
        memcpy(this->a, a, n);
    }
};

typedef std::map<Data, int> Map;
Map map;

inline int check() {
    register int val = 0;
    for (register int i = 1; i < n; i++)
        val += std::abs(a[i] - a[i - 1]) > 1;
    return val;
}

void dfs(int step) {
    if (step >= ans) return;
    register int &cur = map[Data(a)];
    if (!cur) {
        cur = step;
    } else if (step >= cur) {
        return;
    }
    if (check() == 0) {
        if (a[0] > 1) step++;
        ans = std::min(ans, step);
        return;
    }
    for (register int i = 0; i < n; i++) {
        std::reverse(a, a + i + 1);
        dfs(step + 1);
        std::reverse(a, a + i + 1);
    }
}

void optDfs(int step) {
    register int cVal = check();
    if (cVal == 0) {
        if (a[0] > 1) step++;
        ans = std::min(ans, step);
        return;
    }
    if (step + cVal * 0.7 >= ans) return;
    register int &cur = map[Data(a)];
    if (!cur) {
        cur = step;
    } else if (step >= cur) {
        return;
    }
    for (register int i = 0; i < n; i++) {
        std::reverse(a, a + i + 1);
        optDfs(step + 1);
        std::reverse(a, a + i + 1);
    }
}

inline void solveCase() {
    std::cin >> n;
    map.clear();
    map.~map();
    for (register int i = 0; i < n; i++) 
        std::cin >> a[i];
    q.clear();
    for (register int i = 0; i < n; i++)
        now.a[i] = a[i];
    now.step = 0;
    now.maintain();
    q.push(now);
    ans = INT_MAX;
    while (!q.empty()) {
        now = q.top();
        q.pop();
        register int &step = map[Data(now.a)];
        step = std::min(step, now.step);
        if (now.val == 0) {
            if (now.a[0] > 1) now.step++;
            ans = now.step;
            break;
        }
        if (now.step >= ans) continue;
        now.step++;
        for (register int i = 0; i < n; i++) {
            std::reverse(now.a, now.a + i + 1);
            now.maintain();
            q.push(now);
            std::reverse(now.a, now.a + i + 1);
        }
    }
    if (n <= 7 || ans <= 7) {
        dfs(0);
    } else {
        optDfs(0);
    }
    std::cout << ans << '\n';
}

inline void solve() {
    register int T;
    std::cin >> T;
    while (T--) solveCase();
}
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);
    freopen("sequence.in", "r", stdin);
    // freopen("sequence.out", "w", stdout);
    solve();
    return 0;
}