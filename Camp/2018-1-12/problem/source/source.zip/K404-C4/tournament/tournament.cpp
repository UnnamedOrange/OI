#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
const long long Mod=998244353;
int n,k;
long long ans,m;
int cnt,head[10],to[30],nxt[30],dfn[10];
bool flag,vis[10];
void add(int x,int y)
{
	cnt++;
	to[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
long long pw(long long x,long long y)
{
	long long res=1;
	while (y)
	{
		if (y&1)
		{
			res=res*x%Mod;
		}
		y>>=1;
		x=x*x%Mod;
	}
	return res;
}
void solve()
{
	ans=1;
	for (int i=2;i<n;i++)
	{
		ans=ans*i%Mod;
	}
	ans=ans*pw(2,m-k)%Mod;
	printf("%lld\n",ans);
}
void dfs(int x,int now)
{
	if (flag)
	{
		return;
	}
	if (dfn[x])
	{
		int s=now-dfn[x];
		if (s==k)
		{
			flag=true;
		}
		return;
	}
	dfn[x]=now;
	for (int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if (vis[y])
		{
			continue;
		}
		dfs(y,now+1);
	}
	//vis[x]=true;
	dfn[x]=0;
}
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	m=n*(n-1)/2;
	if (k<3 || k>n)
	{
		puts("0");
		return 0;
	}
	/*
	if (k==n)
	{
		solve();
		return 0;
	}
	*/
	for (int mask=0;mask<(1<<m);mask++)
	{
		//mask=59;
		//cout<<mask<<endl;
		cnt=0;
		memset(head,0,sizeof(head));
		int i=1,j=2;
		for (int h=0;h<m;h++)
		{
			if (mask&(1<<h))
			{
				add(i,j);
				//cout<<i<<"-->"<<j<<endl;
			}
			else
			{
				add(j,i);
				//cout<<j<<"-->"<<i<<endl;
			}
			j++;
			if (j>n)
			{
				i++;
				j=i+1;
			}
		}
		flag=false;
		//memset(vis,false,sizeof(vis));
		for (int i=1;i<=n;i++)
		{
			if (!vis[i])
			{
				dfs(i,1);
			}
			if (flag)
			{
				break;
			}
		}
		if (flag)
		{
			ans++;
		}
	}
	printf("%lld\n",ans);
	return 0;
}
