#include<algorithm>
#include<unistd.h>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<ctime>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;

int main()
{
	freopen("xmastree1.in","w",stdout);
	srand(time(0)+getpid());
	int n=5000,m=5000,T=0;
	printf("%d %d %d\n",n,m,T);
	rep(i,1,n) printf("%d ",rand()%n+1);
	puts("");
	rep(i,2,n) printf("%d %d\n",i,rand()%(i-1)+1);
	rep(i,1,m)
	{
		int tp=rand()%2+1;
		if(tp==1)
		{
			int x=rand()%n+1,l=rand()%n+1,r=rand()%n+1;
			if(l>r) swap(l,r);
			printf("%d %d %d %d\n",tp,x,l,r);
		}
		else
		{
			int x=rand()%n+1,y=rand()%n+1;
			printf("%d %d %d\n",tp,x,y);
		}
	}
	return 0;
}
