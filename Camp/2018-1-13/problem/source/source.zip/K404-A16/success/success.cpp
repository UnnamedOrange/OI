#include <cstdio>
#define FOR(i, l, r) for(ll i = l; i <= r; ++i)

using namespace std;

typedef long long ll;
const int mod = 1e9 + 7;
const int N = 1000010;

ll s, t, n, m, ans;
ll f[2][N], jie[N], inv[N];

ll pow(ll x, int y)
{
	ll ans = 1;
	for(; y; y >>= 1)
	{
		if (y & 1) ans = ans * x % mod;
		x = x * x % mod;
	}
	return ans;
}
ll iv(ll x) {return pow(x, mod - 2);}
ll c(ll m, ll n) {return n > m ? 0 : jie[m] * inv[n] % mod * inv[m - n] % mod;}

int main()
{
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	scanf("%lld%lld%lld%lld", &s, &t, &n, &m);
	f[0][0] = 1;
	FOR(i, 1, n)
	{
		FOR(j, 1, i * t) f[0][j] = (f[0][j] + f[0][j - 1]) % mod, f[1][j] = 0;
		FOR(j, i, i * t)
		{
			f[1][j] = f[0][j - 1];
			if (j - t - 1 >= 0) f[1][j] = (f[1][j] + mod - f[0][j - t - 1]) % mod;
		}
		FOR(j, 0, i * t) f[0][j] = f[1][j];
	}
	jie[0] = 1; FOR(i, 1, s) jie[i] = jie[i - 1] * i % mod;
	inv[s] = iv(jie[s]); for(int i = s; i; --i) inv[i - 1] = inv[i] * i % mod;
	FOR(i, n, n * t) (ans += f[0][i] * c(s - i, m - n)) %= mod;
	printf("%lld\n", ans);
	return 0;
}
