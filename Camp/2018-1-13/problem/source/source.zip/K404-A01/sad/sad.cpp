//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const lovelive N=1e5+100,mod=998244353;
void read(lovelive &x)
{
  x=0;
  char c;
  c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c<='9'&&c>='0')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
int fir[N],to[N*2],nxt[N*2],fa[N],siz[N],cnt[N],tot;
void add_edge(int x,int y)
{
  nxt[++tot]=fir[x];
  to[tot]=y;
  fir[x]=tot;
}
void dfs1(int i,int f)
{
  fa[i]=f;
  for(int j=fir[i];j;j=nxt[j])
    if(to[j]!=f)
      dfs1(to[j],i);
}
char s[N];
lovelive f[N],g[N];
lovelive pow1(lovelive x,lovelive k)
{
  lovelive r=1;
  while(k)
  {
  	if(k&1)
  	  r*=x;
  	x*=x;
  	r%=mod;
  	x%=mod;
  	k>>=1;
  }
  return r;
}
queue<int> sp;
int main()
{
  freopen("sad.in","r",stdin);
  freopen("sad.out","w",stdout);
  lovelive n,x,y,p,tmp,sum;
  read(n);
  scanf("%s",s+1);
  for(int i=1;i<n;i++)
    read(x),read(y),add_edge(x,y),add_edge(y,x),++siz[x],++siz[y],++cnt[x],++cnt[y];
  dfs1(1,0);
  for(int i=1;i<=n;i++)
    if(siz[i]==1)
      sp.push(i);
  while(!sp.empty())
  {
  	p=sp.front();
  	sp.pop();
  	--siz[fa[p]];
  	if(siz[fa[p]]==1&&fa[p]!=1)
  	  sp.push(fa[p]);
  	else
  	  if(fa[p]==1&&!siz[fa[p]])
  	    sp.push(fa[p]);
  	f[p]=1;tmp=pow1(cnt[p],mod-2);sum=0;
  	if(cnt[p]!=1)
	  g[p]=tmp;
  	for(int j=fir[p];j;j=nxt[j])
  	  if(to[j]!=fa[p])
  	    f[p]=(f[p]+f[to[j]]*tmp)%mod,sum=(sum+g[to[j]]*tmp)%mod;
  	if(sum)
  	{
  	  sum=mod+1-sum;
  	  tmp=pow1(sum,mod-2);
  	  g[p]=g[p]*tmp%mod;
  	  f[p]=f[p]*tmp%mod;
	}
  }
  cout<<f[1];
  return 0;
}
/*
3
111
1 2
1 3

4
1111
1 2
1 3
3 4
*/
