#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=4010,INF=0x3f3f3f3f;
int n,m,k,a[maxn],b[maxn];
int to[2][maxn][maxn],f[maxn][maxn];
int dfs(int x,int y){
    if(x==n+1&&y==m+1) return 0;
    if(f[x][y]!=INF) return f[x][y];
    for(int i=1;i<=k;i++){
        int nx=to[0][x][i];
        int ny=to[1][y][i];
        chkmin(f[x][y],dfs(nx,ny)+1);
    }
    return f[x][y];
}
int main(){
    freopen("subsequence.in","r",stdin);
    freopen("subsequence.out","w",stdout);
    read(n); read(m); read(k);
    for(int i=1;i<=n;i++) read(a[i]);
    for(int i=1;i<=m;i++) read(b[i]);
    for(int i=1;i<=k;i++){
        to[0][n+1][i]=n+1;
        to[1][m+1][i]=m+1;
    }
    for(int i=n;~i;i--){
        for(int j=1;j<=k;j++) to[0][i][j]=to[0][i+1][j];
        to[0][i][a[i+1]]=i+1;
    }
    for(int i=m;~i;i--){
        for(int j=1;j<=k;j++) to[1][i][j]=to[1][i+1][j];
        to[1][i][b[i+1]]=i+1;
    }
    memset(f,INF,sizeof f);
    printf("%d\n",dfs(0,0));
    return 0;
}
