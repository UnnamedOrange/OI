#include<iostream>
#include<cstdio>
#include<cstring>
#include<bitset>
using namespace std;
struct lxy{
	int to,next;
}b[100005];
int n,q,t;
int head[50005];
int cnt;
int fa[50005],vis[50005],col[50005];
int ans=0;
bitset <50005> m[50005];

int readit()
{
	int a=0;
	char x;
	x=getchar();
	while(x<'0'||x>'9')
	  x=getchar();
	while(x>='0'&&x<='9')
	{
		a=a*10+x-'0';
		x=getchar();
	}
	return a;
}

void update(int u)
{
	m[u].reset();
	m[u][col[u]]=1;
	for(int i=head[u];i!=-1;i=b[i].next)
	  if(b[i].to!=fa[u])
	    m[u]=(m[u]|m[b[i].to]);
}

void add(int op,int ed)
{
	cnt++;
	b[cnt].next=head[op];
	b[cnt].to=ed;
	head[op]=cnt;
}

void dfs(int u)
{
	for(int i=head[u];i!=-1;i=b[i].next)
	  if(vis[b[i].to]==0)
	  {
		vis[b[i].to]=1;
		fa[b[i].to]=u;
		dfs(b[i].to);
	  }
	update(u);
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++)head[i]=-1,scanf("%d",&col[i]);
	for(int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	vis[1]=1;
	dfs(1);
	for(int i=1;i<=q;i++)
	{
		int x,y,z,r;
		scanf("%d",&x);
		if(x==2)
		{
			scanf("%d%d",&y,&z);
			col[y]=z;
			update(y);
			for(int i=fa[y];i!=0;i=fa[i])
			  update(i);
		}
		if(x==1)
		{
			scanf("%d%d%d",&y,&z,&r);
			if(t==1)
			  y=ans^y,z=ans^z,r=ans^r;
			ans=0;
			for(int i=z;i<=r;i++)
			  if(m[y][i]==1)
			    ans++;
			printf("%d\n",ans);
		}
	}
}
