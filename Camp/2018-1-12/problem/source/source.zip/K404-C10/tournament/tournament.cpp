#include <cstdio>
#include <cmath>
using namespace std;
#define Mod 998244353
#define N 400050
int w[N],u[N],t[N],f[N],g[N],h[N],n,k,i,m,hh[N],pw[N],ni[N];
inline int qmi(int di,int zhi)
{
	int ret=1,x=di;
	while (zhi){
		if (zhi&1) ret=1LL*ret*x%Mod;x=1LL*x*x%Mod;zhi>>=1;
	}return ret;
}
inline void dft(int* a,int n,int pd)
{
	int yg;
	if (pd==1) yg=qmi(3,(Mod-1)/n);else yg=qmi(3,Mod-1-(Mod-1)/n);
	for (i=1;i<n;i++) w[i]=1LL*w[i-1]*yg%Mod;
	for (i=0;i<n;i++) u[i]=a[i];
	for (int m=1,psz=1;m<n;m<<=1,psz++){
		int p=0;
		for (i=0;i<n;i++) if ((i&(m<<1)-1)<m){
			int gh=1LL*w[(n>>psz)*(i&m-1)]*u[p+(n>>1)]%Mod;
			t[i]=(gh+u[p])%Mod;
			t[i+m]=(u[p]-gh)%Mod;
			p++;
		}
		for (i=0;i<n;i++) u[i]=t[i];
	}
	if (pd==1) for (i=0;i<n;i++) a[i]=u[i];
	else{
		int psz=qmi(n,Mod-2);
		for (i=0;i<n;i++) a[i]=1LL*u[i]*psz%Mod;
	}
}
void qiuni(int m,int* g)
{
	if (m==2){
		g[0]=1;return;
	}
	qiuni(m>>1,g);
	for (i=0;i<(m>>1);i++) h[i]=hh[i];
	dft(g,m,1);dft(h,m,1);
	for (i=0;i<m;i++) g[i]=(2LL*g[i]-1LL*g[i]*g[i]%Mod*h[i]%Mod)%Mod;
	dft(g,m,-1);
	for (i=(m>>1);i<m;i++) g[i]=0;
}
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);m=ceil(log2(k));m=1<<m;
	int nn=ceil(log2(n+1));nn=1<<nn;w[0]=1;
	pw[0]=1;for (i=1;i<=nn;i++) pw[i]=1LL*pw[i-1]*i%Mod;
	ni[nn]=qmi(pw[nn],Mod-2);for (i=nn;i>=1;i--) ni[i-1]=1LL*ni[i]*i%Mod;
	for (i=0;i<m;i++) hh[i]=1LL*qmi(2,1LL*i*(i-1)/2%(Mod-1))*ni[i]%Mod;
	qiuni(m<<1,g);
	for (i=k;i<m;i++) g[i]=0;
	for (i=0;i<m;i++) hh[i]=g[i];
	for (i=0;i<(nn<<1);i++) h[i]=0;
	qiuni(nn<<1,f);
	int ans=(-1LL*pw[n]*f[n]+qmi(2,1LL*n*(n-1)/2%(Mod-1)))%Mod;
	printf("%d\n",(ans+Mod)%Mod);
	return 0;
}
