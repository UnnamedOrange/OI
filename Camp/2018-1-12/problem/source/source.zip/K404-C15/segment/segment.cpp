#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 100005, P = 998244353;
int m, n, k, d[N];
int L[N], R[N];
ll ans;

ll qpow(ll a, ll x){
	ll ret = 1;
	while(x){
		if(x & 1) (ret *= a) %= P;
		(a *= a) %= P;
		x >>= 1;
	}
	return ret;
}
void check(){
	for(int i = 1; i <= m; i++) d[i] = 0;
	for(int i = 1; i <= n; i++)
		d[L[i]]++, d[R[i]]--;
	ll res = 0;
	for(int i = 1; i <= m; i++){
		d[i] += d[i - 1];
		(res += qpow(d[i], k)) %= P;
	}
	(ans += res) %= P;
}
void dfs(int cur, int l, int r){
	if(cur == n + 1) return check();
	if(min(m - l + 1, m - r + 1) < n - cur + 1) return;
	for(int i = l; i <= m - n + cur; i++)
		for(int j = max(i, r); j <= m - n + cur; j++)
			L[cur] = i, R[cur] = j, dfs(cur + 1, i + 1, j + 1);
}

int main(){
	
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "w", stdout);
	
	read(n), read(m), read(k);

	if(n > m){
		puts("0");
		return 0;
	}
	if(m <= 7){
		dfs(1, 1, 1);
		write(ans), enter;
		return 0;
	}
	if(n == 1){
		for(int i = 1; i < m; i++)
			ans = (ans + i * (m - i)) % P;
		write(ans), enter;
		return 0;
	}
	if(n == 2 && k == 1){
		static ll a[N] = {0}, b[N] = {0};
		for(int i = 2; i <= m; i++)
			a[i] = (a[i - 1] + i * (i - 1) / 2 % P) % P;
		for(int i = 3; i <= m; i++)
			b[i] = (b[i - 1] + (a[i] - a[i - 1]) * (a[i - 1] - a[i - 2]) % P + a[i - 1]) % P;
		write(b[m]), enter;
		return 0;
	}
	
	return 0;
}

