#include<cstdio>
using namespace std;
const int mod=998244353;
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int n,m,k;
	long long ans=0;
	scanf("%d%d%d",&n,&m,&k);
	if(n==1){ 
		for(int i=1;i<m;i++) ans+=(m-i)*i,ans%=mod;
		printf("%lld",ans);
		return 0;
	}
	ans=n*m%mod;
	if(n>m*m) printf("0\n");
	else printf("%lld",ans);
	return 0;
}
