#include <bits/stdc++.h>
using namespace std;

int n, m, k;
int A[4010], B[4010], P[4010];
int JA[4010][4010], JB[4010][4010];
int Dp[4010][4010];

struct View {
	int a, b;
	int& d;
	View(int aa, int bb, int& dpt) : a(aa), b(bb), d(dpt) {
		++d;
		for (int i = 0; i < d; ++i) {
			putchar(' ');
		}
		printf("Calc Dp[%d][%d]\n", a, b);

	}
	~View() {
		for (int i = 0; i < d; ++i) {
			putchar(' ');
		}
		printf("Dp[%d][%d] = %d\n", a, b, Dp[a][b]);
		--d;
	}
};

int Get(int a, int b) {
	// static int dpt;
	// View v(a, b, dpt);
	if (Dp[a][b] != -1) {
		return Dp[a][b];
	} else {
		int& x = Dp[a][b];
		x = 0x3FFFFFFF;
		for (int i = 1; i <= k && x; ++i) {
			x = min(x, Get(JA[a][k], JB[b][k]));
		}
		++x;
		return x;
	}
}

int main() {
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	cin >> n >> m >> k;
	for (int i = 1; i <= n; ++i) {
		cin >> A[i];
	}
	for (int i = 1; i <= m; ++i) {
		cin >> B[i];
	}
	for (int i = 1; i <= k; ++i) {
		P[i] = n + 1;
		JA[n + 1][i] = n + 1;
	}
	for (int i = n; ~i; --i) {
		memcpy(JA + i, P, sizeof(P));
		P[A[i]] = i;
	}
	for (int i = 1; i <= k; ++i) {
		P[i] = m + 1;
		JB[m + 1][i] = m + 1;
	}
	for (int i = m; ~i; --i) {
		memcpy(JB + i, P, sizeof(P));
		P[B[i]] = i;
	}
	memset(Dp, 0xFF, sizeof(Dp));
	Dp[n + 1][m + 1] = 0;
	cout << Get(0, 0);
}
