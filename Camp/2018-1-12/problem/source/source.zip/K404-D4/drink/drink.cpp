#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n, rk[1000010];
double xs[1000010];
pair <int, int> a[1000010];
struct T {
	int num;
	double sum, tag;
} t[2100000];
inline void clear (int p, int l, int r) {
	t[p].num = 0;
	t[p].sum = 0;
	t[p].tag = 1;
	if (l == r) return;
	int mid = (l + r) >> 1;
	clear (p << 1, l, mid);
	clear (p << 1 | 1, mid + 1, r);
}
inline void push_down (int p) {
	t[p << 1].sum *= t[p].tag;
	t[p << 1].tag *= t[p].tag;
	t[p << 1 | 1].sum *= t[p].tag;
	t[p << 1 | 1].tag *= t[p].tag;
	t[p].tag = 1;
}
inline int find (int p, int l, int r, int pos) {
	if (l == r) return 1;
	push_down (p);
	int mid = (l + r) >> 1;
	if (pos <= mid) return find (p << 1, l, mid, pos);
	else return t[p << 1].num + find (p << 1 | 1, mid + 1, r, pos);
}
inline void add (int p, int l, int r, int pos, double x) {
	if (l == r) { t[p].num = 1, t[p].sum = x; return; }
	push_down (p);
	int mid = (l + r) >> 1;
	if (pos <= mid) add (p << 1, l, mid, pos, x);
	else add (p << 1 | 1, mid + 1, r, pos, x);
	t[p].num = t[p << 1].num + t[p << 1 | 1].num;
	t[p].sum = t[p << 1].sum + t[p << 1 | 1].sum;
}
inline void div (int p, int l, int r, int ll, int rr) {
	if (l >= ll && r <= rr) { t[p].sum /= 2, t[p].tag /= 2; return; }
	push_down (p);
	int mid = (l + r) >> 1;
	if (ll <= mid) div (p << 1, l, mid, ll, rr);
	if (rr > mid) div (p << 1 | 1, mid + 1, r, ll, rr);
	t[p].sum = t[p << 1].sum + t[p << 1 | 1].sum;
}
double ans;
int main () {
	freopen ("drink.in", "r", stdin);
	freopen ("drink.out", "w", stdout);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++) scanf ("%d", &a[i].first), a[i].second = i;
	sort (a + 1, a + n + 1);
	for (int i = 1; i <= n; i++) rk[a[i].second] = i;
	for (int i = 1; i <= n; i++) swap (a[i].first, a[i].second);
	sort (a + 1, a + n + 1);
	xs[1] = 0.5;
	for (int i = 2; i <= n; i++) xs[i] = xs[i - 1] / 2;
	for (int l = 1; l <= n; l++) {
		clear (1, 1, n);
		for (int r = l; r <= n; r++) {
			int x = r - l - find (1, 1, n, rk[r]) + 2;
			div (1, 1, n, 1, rk[r]);
			add (1, 1, n, rk[r], a[r].second * xs[x]);
			ans += t[1].sum;
		}
	}
	printf ("%.15lf\n", ans / n / n);
	return 0;
}
