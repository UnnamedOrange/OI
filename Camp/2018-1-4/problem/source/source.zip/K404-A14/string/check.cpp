#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
int main(){
	int T=10;int x,y;
	while(T--){
		system("data.exe");
		system("string.exe");
		system("bl.exe");
		freopen("string.out","r",stdin);
		scanf("%d",&x);
		freopen("bl.out","r",stdin);
		scanf("%d",&y);
		if(x!=y){printf("WA!\n");return 0;}
		else printf("AC!\n");
	}
	printf("ALL CORRECT!\n");
	return 0;
}
