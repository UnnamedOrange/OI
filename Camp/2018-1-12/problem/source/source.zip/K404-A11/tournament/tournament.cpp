#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int b[30][30];
bool pan;
int n,k;
int ans;
int aim;

void p(int bu,int u)
{
	//cout<<u<<" ";
	if(bu==k+1)
	{
		if(u==aim)ans++,pan=1;
		return;
	}
	for(int i=1;i<=n;i++)
	{
	  if(b[u][i]==1&&pan==0)
	    p(bu+1,i);
    }
	    
}

void dfs(int x,int y)
{
//	for(int i=1;i<=n;i++)
//	{
//	  for(int j=1;j<=n;j++)
//	    cout<<b[i][j]<<" ";
//	  cout<<endl;
//	}
    pan=0;
	for(int i=1;i<=n;i++)
	  if(pan==0)
	    aim=i,p(1,i);
	//cout<<endl<<endl;
	for(int i=1;i<=n;i++)
	  for(int j=i+1;j<=n;j++)
	    if(i>x||(i==x&&y<=j))
	    {
	    	b[i][j]=0;b[j][i]=1;
	    	dfs(i,j+1);
	    	b[i][j]=1;b[j][i]=0;
		}
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	  for(int j=i+1;j<=n;j++)
	    b[i][j]=1;
//	for(int i=1;i<=n;i++)
//	  for(int j=1;j<=n;j++)
//	    cout<<b[i][j]<<endl;
    dfs(1,2);
    cout<<ans;
}
