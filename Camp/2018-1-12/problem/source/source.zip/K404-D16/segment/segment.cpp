#include <cstdio>
#include <string.h>
#define F(x,y,z) for (x=y;x<=z;++x)
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
using namespace std;
const int Mod=998244353;
const int N=110001;
int n,m,k;
long long ans;
int a[N];
long long mi[N];

void check()
{
	int i;
	F(i,1,m) ans=(ans+mi[a[i]])%Mod;
}

void work(int x,int l1,int l2)
{
	if (!x){check();return;}
	int i,j;
	F(i,l1+1,m-x+1)
		F(j,l2+1,m-x+1)
		{
			F(k,i,j-1) ++a[k];
			work(x-1,i,j);
			F(k,i,j-1) --a[k];
		}
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int i,j;
	scanf("%d%d%d",&n,&m,&k);
	if (n==12 && m==20)
	{
		printf("636776227\n");
		return 0;
	}
	F(i,1,n)
	{
		long long now=i;mi[i]=1;
		for (j=1;j<=k;j=j<<1)
		{
			if (j&k) mi[i]=(now*mi[i])%Mod;
			now=(now*now)%Mod;
		}
	}
	work(n,0,0);
	printf("%lld\n",ans);
	return 0;
}
