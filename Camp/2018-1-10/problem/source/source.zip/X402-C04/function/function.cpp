#include<iostream>
#include<map>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

typedef long long ll;
const int N=1e7+9;
const ll md=998244353;

int minp[N],pri[N>>1],ptop;
ll d[N],mu[N],sd[N];
bool npri[N];
map<int,ll> fmu,fsumsig,fsumsqr;

inline void init()
{
	mu[1]=1;sd[1]=d[1]=1;
	for(int i=2;i<N;i++)
	{
		if(!npri[i])
		{
			pri[++ptop]=i;
			mu[i]=-1;
			minp[i]=1;
			d[i]=2;
		}

		for(int j=1;j<=ptop && i*pri[j]<N;j++)
		{
			npri[i*pri[j]]=1;
			if(i%pri[j])
			{
				mu[i*pri[j]]=-mu[i];
				minp[i*pri[j]]=1;
				d[i*pri[j]]=d[i]*2;
			}
			else
			{
				mu[i*pri[j]]=0;
				minp[i*pri[j]]=minp[i]+1;
				d[i*pri[j]]=d[i]/(minp[i]+1)*(minp[i]+2);
			}
		}

		mu[i]=(mu[i-1]+mu[i]+md)%md;
		sd[i]=(sd[i-1]+d[i])%md;
		d[i]=(d[i-1]+d[i]*d[i]%md)%md;
	}
}

inline ll sum(ll x)
{
	return ((x+1)*x/2)%md;
}

inline ll sumsig(ll n)
{
	if(n<N)return sd[n];
	if(fsumsig.find(n)!=fsumsig.end())
		return fsumsig[n];
	ll ret=0;

	for(ll i=1,j;i<=n;i=j+1)
	{
		j=n/(n/i);
		(ret+=(j-i+1)*(n/i)%md)%=md;
	}

	return fsumsig[n]=ret;
}

inline ll sumsqr(ll n)
{
	if(n<N)return d[n];
	if(fsumsqr.find(n)!=fsumsqr.end())
		return fsumsqr[n];
	ll ret=0;
	for(int i=1,j;i<=n;i++)
	{
		j=n/(n/i);
		ret+=(sumsig(j)-sumsig(i-1)+md)%md*(n/i-1)%md;
	}
	return fsumsqr[n]=ret;
}

inline ll cmu(ll n)
{
	if(n<N)return mu[n];
	if(fmu.find(n)!=fmu.end())
		return fmu[n];

	ll ret=1;
	for(int i=2,j;i<=n;i=j+1)
	{
		j=n/(n/i);
		ret=(ret+md-(j-i+1)*cmu(n/i)%md)%md;
	}
	fmu[n]=ret;

	return ret;
}

ll n;

int mian()
{
	scanf("%lld",&n);

	ll ans=0;
	for(int i=1,j;i<=n;i=j+1)
	{
		j=n/(n/i);
		(ans+=sumsqr(n/i)%md*((cmu(j)-cmu(i-1)+md)%md)%md)%=md;
	}

	printf("%lld\n",ans);
	return 0;
}

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);

	init();

	int T;
	scanf("%d",&T);
	while(T--)
		mian();

	return 0;
}
