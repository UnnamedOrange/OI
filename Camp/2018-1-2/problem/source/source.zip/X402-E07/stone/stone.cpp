#include <bits/stdc++.h>
using namespace std;
const int maxn = 100000 +10;
const long long mod = 1e9 + 7;
int read(){
	int x=0,flag=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')flag=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*flag;
}
long long Pow(long long x,long long t){
	long long ans=1;
	while(t){
		if(t&1)ans=ans*x%mod;
		x=x*x%mod;t>>=1;
	}
	return ans;
}
int flag=0,point=0;
long long bas=0,fac[maxn],rfac[maxn];
int a1 = 0,a2 = 0;
int ai[maxn];

void init(){
	fac[0]=rfac[0]=1;
	for(long long i=1;i<maxn;i++){
		fac[i]=fac[i-1]*i%mod;
		rfac[i]=Pow(fac[i],mod-2);
	}
}
long long C(long long m,long long n){
	return fac[m] * rfac[n] % mod * rfac[m-n] % mod;
}
int n,a,b;
int main(){
	freopen("stone.in","r",stdin),freopen("stone.out","w",stdout);
	init();
	n=read();a=read();b=read();if(a>b){swap(a,b);flag=1;}
	for(int i=1;i<=n;i++)ai[i]=read()%(a+b);
	for(int i=1;i<=n;i++)if(ai[i]<a)++bas;
	else if(ai[i]>=a&&ai[i]<=b-1)++point;
	else if(ai[i]>=b&&ai[i]<=b+a-1)++a1;
	else ++a2;
	bas=Pow(2LL,1LL*bas);
	long long ans2 = ((Pow(2,point)-1)%mod*bas%mod+mod)%mod;
	ans2 = ans2 * Pow(2LL,a1+a2) % mod;
	if(!flag)printf("%lld %lld ",(ans2%mod+mod)%mod,0);
	else printf("%lld %lld ",0,(ans2%mod+mod)%mod);
	long long all = Pow(2LL,1LL*n);
	all -=  ans2;
	all = ( all % mod + mod ) % mod;
	long long ans = 0;
	for(int i=1;i<=a1;i+=2){
		ans = ans + C(a1,i);
	}
	ans = ans * bas * Pow(2,a2);
	printf("%lld %lld\n",ans,((all-ans)%mod+mod)%mod);
	return 0;
}
