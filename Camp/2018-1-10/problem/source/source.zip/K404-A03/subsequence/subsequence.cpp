//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const int maxn=4000+7,INF=0x3f3f3f3f;
int n,m,k,a[maxn],b[maxn],tot,nn,mm,ans;

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

int next[2][maxn][maxn],last[maxn],mindis[2][maxn],ok[maxn][maxn];
bool s(int pos1,int pos2,int now) {
	if(pos1==INF&&pos2==INF) return 1;
	if((pos1!=INF&&mindis[0][pos1]>now)||(pos2!=INF&&mindis[1][pos2]>now)) return 0;
	int x,y;
	for(int i=1;i<=k;++i) {
		x=pos1; y=pos2;
		if(x!=INF) x=next[0][x][i];
		if(y!=INF) y=next[1][y][i];
		if(x<INF&&y<INF&&ok[x][y]<=now) return 1;
		if(s(x,y,now-1)) {
			if(x!=INF&&y!=INF) ok[x][y]=now; return 1;
		}
	}
	return 0;
}

int main() {
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	n=read(); m=read(); k=read();
	for(int i=1;i<=n;++i) a[i]=read();
	for(int i=1;i<=m;++i) b[i]=read();
	memset(last,0x3f3f3f3f,sizeof(last));tot=0;
	memset(mindis,0x3f3f3f3f,sizeof(mindis));
	memset(ok,0x3f3f3f3f,sizeof(ok));
	for(int i=n;i;--i) {
		for(int j=1;j<=k;++j) {
			next[0][i][j]=last[j];
			if(last[j]==INF) mindis[0][i]=1;
			else mindis[0][i]=min(mindis[0][i],mindis[0][last[j]]+1);
		}
		last[a[i]]=i;
	}
	for(int j=1;j<=k;++j) {
		next[0][0][j]=last[j];
		if(last[j]==INF) mindis[0][0]=1;
		else mindis[0][0]=min(mindis[0][0],mindis[0][last[j]]+1);
	}
	memset(last,0x3f3f3f3f,sizeof(last));tot=0;
	for(int i=m;i;--i) {
		for(int j=1;j<=k;++j) {
			next[1][i][j]=last[j];
			if(last[j]==INF) mindis[1][i]=1;
			else mindis[1][i]=min(mindis[1][i],mindis[1][last[j]]+1);
		}
		last[b[i]]=i;
	}
	for(int j=1;j<=k;++j) {
		next[1][0][j]=last[j];
		if(last[j]==INF) mindis[1][0]=1;
		else mindis[1][0]=min(mindis[1][0],mindis[1][last[j]]+1);
	}
	int x,y;
	if((ll)n*m*k<=1e7) {
		ok[n+1][m+1]=0;
		for(int i=1;i<=n;++i) ok[i][m+1]=mindis[0][i];
		for(int i=1;i<=m;++i) ok[n+1][i]=mindis[1][i];
		for(int i=n;i;--i) for(int j=m;j;--j) if(a[i]==b[j]){
			for(int t=1;t<=k;++t) {
				x= next[0][i][t]==INF? n+1:next[0][i][t];
				y= next[1][j][t]==INF? m+1:next[1][j][t];
				ok[i][j]=min(ok[i][j],ok[x][y]+1);
				ok[i][m+1]=min(ok[i][m+1],ok[i][j]);
				ok[n+1][j]=min(ok[n+1][j],ok[i][j]);
			}
		}
		for(int t=1;t<=k;++t) {
			x= next[0][0][t]==INF? n+1:next[0][0][t];
			y= next[1][0][t]==INF? m+1:next[1][0][t];
			ok[0][0]=min(ok[0][0],ok[x][y]+1);
		}
		printf("%d",ok[0][0]);
	}
	else for(ans=1;ans<=max(n,m)+1;++ans) if(s(0,0,ans)) {
		printf("%d",ans); break;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
4 4 2
1 1 2 1 
2 2 2 2 
*/
