#include <cstdio>
#include <vector>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

const int N = 1000010;

int fa1[N], fa2[N], a[N], L[N], R[N], wh[N], right[N], left[N], n, t, maxn;
double Lans[N], Rans[N], ans, c;
vector <int> w[100010];

char B[1 << 26], *S = B;
#define getchar() (*S++)
int read()
{
	int x = 0; char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9') {x = x * 10 + c - '0'; c = getchar();}
	return x;
}

int find1(int x) {return fa1[x] == x ? x : fa1[x] = find1(fa1[x]);}
int find2(int x) {return fa2[x] == x ? x : fa2[x] = find2(fa2[x]);}

int main()
{
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	
	fread(B, 1, 1 << 26, stdin);
	n = read(); maxn = max(30, 10000000 / n);
	FOR(i, 1, n) a[i] = read();
	FOR(i, 1, n) w[a[i]].push_back(i);
	for(int i = 100000; i; --i) for(int j = 0; j < w[i].size(); ++j) wh[++t] = w[i][j];
	
	FOR(i, 0, n + 1) fa1[i] = fa2[i] = i;
	for(int i = n; i; --i)
	{
		int W = wh[i];
		R[W] = find1(W + 1); fa1[W] = find1(R[W]);
		L[W] = find2(W - 1); fa2[W] = find2(L[W]);
	}
	
	FOR(i, 1, n)
	{
		register int W = wh[i];
		if (L[W] == 0) Lans[W] = W;
			else Lans[W] = Lans[L[W]] / 2.0 + (W - L[W]);
		if (R[W] == n + 1) Rans[W] = n + 1 - W;
			else Rans[W] = Rans[R[W]] / 2.0 + (R[W] - W);
		ans += Lans[W] * Rans[W] * a[W];
		
		right[L[W]] = W; right[W] = R[W];
		left[R[W]] = W; left[W] = L[W];
		t = W; c = (Lans[R[W]] - (R[W] - W)) / 2.0;
		FOR(j, 1, maxn) {t = right[t]; if (t == n + 1) break; Lans[t] -= c; c /= 2.0;}
		t = W; c = (Rans[L[W]] - (W - L[W])) / 2.0;
		FOR(j, 1, maxn) {t = left[t]; if (t == 0) break; Rans[t] -= c; c /= 2.0;}
	}
	
	printf("%.10lf\n", ans / (n * 1.0) / (n * 1.0) / 2.0);
	return 0;
}
