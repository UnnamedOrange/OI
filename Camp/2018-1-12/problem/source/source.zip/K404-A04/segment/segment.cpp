#include<iostream>
#include<cstdio>
#include<cstring>
#define up(x,y) x=(x+(y)+mod)%mod
#define ll long long
using namespace std;
const int mod=998244353;
const int maxm=100010;
int n,m,k,a[maxm];
ll ans,f[2][355][355],g[2][355][355];
ll ksm(ll a,int b){ll r=1;for(;b;b>>=1){if(b&1)r=r*a%mod;a=a*a%mod;}return r;}
void find(int v,int cl,int cr)
{
	if(v>n)
	{
		for(int i=1;i<=m;i++)
			ans=(ans+ksm(a[i],k))%mod;
//		for(int i=1;i<=m;i++)
//			cout<<a[i]<<' ';
//		cout<<endl;		
		return;	
	}
	for(int l=cl+1;l<=m;l++)
		for(int r=max(l,cr+1);r<=m;r++)
		{
			for(int i=l;i<r;i++)
				a[i]++;
			find(v+1,l,r);
			for(int i=l;i<r;i++)
				a[i]--;
		}
}
void spc_n_1()
{
	for(int i=1;i<m;i++)
		ans=(ans+i*(m-i))%mod;
}
void spc_k_1()
{
	for(int l=0;l<=m;l++)
		for(int r=0;r<=m;r++)
			g[0][l][r]=1;
	for(int i=1,v=1;i<=n;i++,v^=1)
	{
		memset(f[v],0,sizeof(f[v]));
		memset(g[v],0,sizeof(g[v]));
		for(int l=1;l<=m;l++)
			for(int r=l;r<=m;r++)
			{
				up(f[v][l][r],f[v^1][l-1][r-1]+g[v^1][l-1][r-1]*(r-l)%mod);
				up(g[v][l][r],g[v^1][l-1][r-1]);
			}
//		cout<<"DP:"<<i<<endl;
//		for(int l=1;l<=m;l++)
//			for(int r=l;r<=m;r++)
//				cout<<l<<' '<<r<<' '<<f[v][l][r]<<' '<<g[v][l][r]<<endl;	
		for(int l=1;l<=m;l++)
			for(int r=1;r<=m;r++)
			{
				up(f[v][l][r],+f[v][l-1][r]+f[v][l][r-1]-f[v][l-1][r-1]);		
				up(g[v][l][r],+g[v][l-1][r]+g[v][l][r-1]-g[v][l-1][r-1]);
			}
//		cout<<"DP:"<<i<<endl;
//		for(int l=1;l<=m;l++)
//			for(int r=l;r<=m;r++)
//				cout<<l<<' '<<r<<' '<<f[v][l][r]<<' '<<g[v][l][r]<<endl;
				
	}
	ans=f[n&1][m][m];
}
void spc_k_mod()
{
//	cout<<"!!!"<<endl;
	g[0][0][0]=1;
	for(int i=1,v=1;i<=n;v^=1,i++)
	{
		memset(f[v],0,sizeof(f[v]));
		memset(g[v],0,sizeof(g[v]));
		for(int cl=0;cl<=m;cl++)
			for(int cr=cl;cr<=m;cr++)
				if(g[v^1][cl][cr])
				for(int l=cl+1;l<=m;l++)
					for(int r=cr+1;r<=m;r++)	
					{
						up(f[v][l][r],f[v^1][cl][cr]+g[v^1][cl][cr]*(r-max(l,cr)));
						up(g[v][l][r],g[v^1][cl][cr]);
					}
	}
	ans=0;
	for(int l=1;l<=m;l++)
		for(int r=l;r<=m;r++)
			up(ans,f[n&1][l][r]);
}
//void spc_n_2()
//{
//	for(int l=1;l<=m;l++)
//		for(int r=l;r<=m;r++)
//		{
//			cout<<l<<' '<<r<<endl;
//			if(l!=r) up(ans,((ll)(r-l-1)*(r-l-2)/2)*(m-r)%mod);
//			cout<<ans<<endl;
//			up(ans,ksm(2,k)*((ll)(r-l-1)*(r-l)/2)%mod*(m-r)%mod);
//			cout<<ans<<endl;
//			for(int i=1;i<m-r;i++)
//				up(ans,(i+r-l)*(m-i));
//			cout<<ans<<endl;	
//		}
//}
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(n>m) ans=0;
	else if(m<=6) find(1,0,0);
	else if(n==1) spc_n_1();
	//else if(n==2) spc_n_2();
	else if(k==1) spc_k_1();
	else if(k==mod-1) spc_k_mod();
	
	printf("%lld",ans);
	return 0;
}
