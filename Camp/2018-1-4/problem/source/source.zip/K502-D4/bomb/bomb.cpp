#include<bits/stdc++.h>
#define rep(a,b,c) for(int a=b;a<=c;a++)
#define go(a) for(int i=head[a];i;i=edge[i].next)
#define N 1000005
using namespace std;
struct E {
	int to,next; } edge[2*N];
int head[N],tot,n,m;
int ans;
int cur;
int dis[N];
int indu[N];
int q[N];
void addedge(int t1,int t2) {
	tot++;
	edge[tot].to=t2;
	edge[tot].next=head[t1];
	head[t1]=tot; }
void bfs(int loc) {
	dis[loc]=1;
	int h,t;
	q[h=t=1]=loc;
	while(h<=t) {
		int u=q[h++];
		go(u) {
			int v=edge[i].to;
			if(dis[v]==dis[u]||!dis[v]) {
				dis[v]=dis[u]+1;
				q[++t]=v; } } } }
int main() {
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,m) {
		int t1,t2;
		scanf("%d%d",&t1,&t2);
		addedge(t1,t2);
		++indu[t2]; }
	rep(i,1,n)
	if(!indu[i])
		bfs(i);
	rep(i,1,n)
	if(!dis[i])
		bfs(i);
	rep(i,1,n)
	ans=max(ans,dis[i]);
	printf("%d\n",ans);
	return 0; }
