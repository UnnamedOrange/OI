#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)
#define Forr(i, j, k) for(int i = j; i >= k; i--)

using namespace std;

const int N = 2010;
const int Mod = 1e9 + 7;

int n;
int l[N], r[N];
int way[N], dp[N];

int main(){

	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) scanf("%d%d", &l[i], &r[i]);

	memset(dp, -1, sizeof dp);
	dp[0] = 0, way[0] = 1;
	For(i, 1, n){
		int maxl = l[i], minr = r[i];
		Forr(j, i - 1, 0){
			if(i - j >= maxl && i - j <= minr){
				if(dp[j] + 1 > dp[i]) dp[i] = dp[j] + 1, way[i] = way[j];
				else if(dp[j] + 1 == dp[i]) way[i] = (way[i] + way[j]) % Mod;
			}
			maxl = max(maxl, l[j]), minr = min(minr, r[j]);
		}
	}

	if(dp[n] < 0) puts("-1");
	else printf("%d %d\n", dp[n], way[n]);

	return 0;
}
