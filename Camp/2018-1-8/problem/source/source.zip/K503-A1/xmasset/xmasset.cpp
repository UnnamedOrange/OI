#include<bits/stdc++.h>
using namespace std;
int t,T,n,x,h,y,q;
int read(){
	int f=0,g=1;
	char ch=getchar();
	for (;!isdigit(ch);ch=getchar());
	for (;isdigit(ch);ch=getchar()) f=f*10+ch-'0';
	return f;
}
int main(){
	t=read();
	if (t==1){
		n=read();T=read();
		while (T--){
			x=read();y=read();
			for (int i=0;i<=9;i++)
			if ((x^y)&(1<<i)){
				int t=i+1;
				if (x&(1<<i)) t+=10;
				if (t/10) putchar(t/10+'0');
				putchar(t%10+'0');
				putchar('\n');
				break;
			}
		}
	}
	else{
		n=read();T=read();
		while (T--){
			q=read();h=read();
			if (h>10){
				h-=11;
				if (q&(1<<h)) puts("yes");
				else puts("no");
			}
			else {
				h--;
				if (q&(1<<h)) puts("no");
				else puts("yes");
			}
		}
	}
	return 0;
}
