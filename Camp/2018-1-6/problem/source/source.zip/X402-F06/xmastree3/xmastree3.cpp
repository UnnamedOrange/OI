#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
typedef unsigned long long ull;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
#define pii pair<ull,ull>
const int maxn=20,mod=998244353;
map<pii,bool> mp;
vector<int> g[maxn];
int n,k;
int fa[maxn],la[maxn];
ull pw[maxn];
int ans=0;
void work(){
	ull f=0,l=0;
	REP(i,1,n) f+=pw[i-1]*fa[i],l+=pw[i-1]*la[i];
	pii u=make_pair(f,l);
	if(!mp[u]) mp[u]=1,++ans;
}
void dfs(int x,int ff,int num){
	vector<int> vc;
	int l=0;
	vc.push_back(x);
	while(l<vc.size()){
		int u=vc[l];
		++l;
	}
	REP(i,0,vc.size()-1){
		int u=vc[i];
		la[u]=num;
		fa[u]=ff;
		REP(j,0,g[u].size()-1){
			int v=g[u][j];
			REP(l,num+1,k) dfs(v,u,l);
			g[u].push_back(v),g[v].push_back(u);
		}
	}
	work();
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
#endif
	n=read(),k=read();
	pw[0]=1;
	REP(i,1,n) pw[i]=pw[i-1]*k;
	REP(i,1,n-1){
		int x=read(),y=read();
		g[x].push_back(y);
		g[y].push_back(x);
	}
	REP(i,1,n)
		REP(j,1,k)
			dfs(i,0,j);
	printf("%d\n",ans);
	return 0;
}
