#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;
long long mod = 1e9 + 9;
const int MAXN = 1e5 + 10;
int n, m;
struct seg {
	int l;
	int r;
	int num;
	int a[40];
} s[MAXN];

int cnt = 0;
int key[MAXN];
int temp[MAXN];
int flag[MAXN];
long long f[MAXN];
long long ans;
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

bool cmp(seg a, seg b)
{
	if(a.l == b.l) {
		return a.r < b.r;
	}
	return a.l < b.l;
}
void open()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
}

int status[30];

bool judge()
{
	for(int i = 1; i <= cnt; i++) {
		if(flag[i] == 0) {
			return false;
		}
	}
	return true;
}
void DFS(int k)
{
	if(k == n + 1) {
		if(judge()) {
			ans++;
		}
		return;
	}
	status[k] = 0;
	DFS(k + 1);
	status[k] = 1;
	for(int i = 1; i <= s[k].num; i++) {
		flag[s[k].a[i]]++;
	}
	DFS(k + 1);
	for(int i = 1; i <= s[k].num; i++) {
		flag[s[k].a[i]]--;
	}
}
void close()
{
	fclose(stdin);
	fclose(stdout);
}
int main()
{
	open();
	n = read(), m = read();
	for(int i = 1; i <= n; i++) {
		s[i].l = read(), s[i].r = read();
		s[i].num = 0;
	}
	for(int i  = 1; i <= m; i++) {
		key[i] = read();
	}
	sort(key + 1, key + 1 + m);
	sort(s + 1, s + 1 + n, cmp);
	for(int i = 1; i <= m;i++) {
		if(key[i] != key[i - 1]) {
			temp[++cnt] = key[i];
		}
	}
	/*for(int i = 1; i <= n; i++) {
		cout<<s[i].num<<endl;
		for(int j  = 1; j  <= s[i].num; j++) {
			cout<<s[i].a[j]<<" ";
		}
		cout<<endl<<endl;
	}*/
	if(n <= 20) {
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= cnt; j++) {
			if(temp[j] <= s[i].r && temp[j] >= s[i].l) {
				s[i].a[++s[i].num] = j;
			}
		}
		}
		DFS(1);
	} else {
		for(int i = 1; i <= n; i++) {
			
		}
		for(int i = 1; i <= n; i++) {
			long long temp = 0;
			int l = s[i].l, r = s[i].r;
			for(int j = r + 1; j <= cnt; j++) {
				f[j] = f[j] * 2 % mod;
			}
			for(int j = l - 1; j < r; j++) {
				temp = (temp + f[j]) % mod;
			}
			f[r] = (f[r] + temp) % mod;
		}
	}
	printf("%lld\n", ans);
	close();
	return 0;
}
