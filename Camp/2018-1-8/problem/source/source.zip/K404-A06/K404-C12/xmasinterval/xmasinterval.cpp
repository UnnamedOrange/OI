#include <algorithm>
#include <iostream>
#include <cstdio>
#define MOD 1000000009
using namespace std; 
typedef long long ll; 
struct interval
{
	int l, r; 
	inline bool operator <(const interval &a) const
	{
		if (l == a.l)
			return r < a.r; 
		return l < a.l; 
	}
} arr[500005]; 
char buf[200000005]; 
int pos = -1; 
inline int getint()
{
	register int res = 0, ch = buf[++pos]; 
	for (; ch < 48; ch = buf[++pos]); 
	for (; ch >= 48; ch = buf[++pos])
		res = res * 10 + ch - 48; 
	return res; 
}
int sum[2000005], lazy[2000005]; 
int x[500005], app[500005]; 
inline void upd(int &x, int y)
{
	x += y; 
	if (x >= MOD)
		x -= MOD; 
}
inline void push_up(int u)
{
	sum[u] = sum[u << 1]; 
	upd(sum[u], sum[u << 1 | 1]); 
}
inline void push_down(int u)
{
	if (lazy[u] == 1)
		return; 
	lazy[u << 1] = (ll)lazy[u << 1] * lazy[u] % MOD; 
	lazy[u << 1 | 1] = (ll)lazy[u << 1 | 1] * lazy[u] % MOD; 
	sum[u << 1] = (ll)sum[u << 1] * lazy[u] % MOD; 
	sum[u << 1 | 1] = (ll)sum[u << 1 | 1] * lazy[u] % MOD; 
	lazy[u] = 1;
}
void modify(int u, int l, int r, int pos, int x)
{
	if (l == r)
	{
		upd(sum[u], x); 
		return;
	}
	push_down(u); 
	int m = l + r >> 1; 
	if (pos <= m)
		modify(u << 1, l, m, pos, x); 
	else
		modify(u << 1 | 1, m + 1, r, pos, x); 
	push_up(u); 
}
void modify(int u, int l, int r, int L, int R, int x)
{
	if (L <= l && r <= R)
	{
		sum[u] = (ll)sum[u] * x % MOD; 
		lazy[u] = (ll)lazy[u] * x % MOD; 
		return; 
	}
	push_down(u); 
	int m = l + r >> 1; 
	if (L <= m)
		modify(u << 1, l, m, L, R, x); 
	if (m < R)
		modify(u << 1 | 1, m + 1, r, L, R, x); 
	push_up(u); 
}
int query(int u, int l, int r, int L, int R)
{
	if (L <= l && r <= R)
		return sum[u]; 
	push_down(u); 
	int m = l + r >> 1, res = 0; 
	if (L <= m)
		upd(res, query(u << 1, l, m, L, R)); 
	if (m < R)
		upd(res, query(u << 1 | 1, m + 1, r, L, R)); 
	return res; 
}
int main()
{
	freopen("xmasinterval.in", "r", stdin); 
	freopen("xmasinterval.out", "wt", stdout); 
	fread(buf, 1, 200000005, stdin); 
	int n = getint(), m = getint(); 
	for (int i = 0; i < n; i++)
	{
		arr[i].l = getint(); 
		arr[i].r = getint(); 
	}
	for (int i = 0; i < m; i++)
	{
		x[i] = getint(); 
		app[i] = x[i]; 
	}
	sort(app, app + m); 
	int cnt = unique(app, app + m) - app; 
	for (int i = 0; i < n; i++)
	{
		arr[i].l = lower_bound(app, app + cnt, arr[i].l) - app; 
		arr[i].r = upper_bound(app, app + cnt, arr[i].r) - app - 1; 
	}
	sort(arr, arr + n); 
	for (int i = 0; i < 2000005; i++)
		lazy[i] = 1; 
	modify(1, 0, cnt, 0, 1); 
	for (int i = 0; i < n; i++)
	{
		int l = arr[i].l, r = arr[i].r; 
		if (l > r)
		{
			modify(1, 0, cnt, 0, cnt, 2); 
			continue;
		}
		modify(1, 0, cnt, r + 1, cnt, 2); 
		modify(1, 0, cnt, r + 1
		, query(1, 0, cnt, l, r)); 
	}
	printf("%d\n", query(1, 0, cnt, cnt, cnt)); 
	return 0; 
}

