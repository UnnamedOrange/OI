#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=510;
const LL inf=1e16;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
}
int T,n,p,q,G[N][N][2];
int w[N],fa[N];
LL ans,W;
vector<pii>R;
inline void add(int u,int v,int x,int y)
{
	G[u][v][0]+=2*(x+y);
	G[u][v][1]+=2*(x-y);
}
inline int find(int x){return fa[x]==x?x:fa[x]=find(fa[x]);}
inline void Combine(int x,int y){if((x=find(x))!=(y=find(y)))fa[x]=y;}
inline LL Solve()
{
	For(i,1,n)assert(w[i]!=0);
	For(i,0,SZ(R)-1)if(w[R[i].first]>w[R[i].second])return inf;
	LL ret=0;
	For(i,1,n)
	{
		ret+=w[i];
		For(j,i+1,n)
			if(w[i]!=w[j])
			{
				ret+=G[i][j][w[i]==1];
				ret+=G[j][i][w[j]==1];
			}
	}
	return W*ret;
}
inline void dfs(int now)
{
	if(now==n+1){chkmin(ans,Solve());return;}
	if(w[now]!=0){dfs(now+1);return;}
	if(w[find(now)]!=0)
	{
		w[now]=w[find(now)];
		dfs(now+1);
		w[now]=0;
		return;
	}
	w[now]=1;w[find(now)]=1;
	dfs(now+1);
	w[now]=-1;w[find(now)]=-1;
	dfs(now+1);
	w[now]=0;w[find(now)]=0;
	return;
}
int main()
{
	int x,y,z,a,b,c,d,e,f;
	file();
	read(T);
	while(T--)
	{
		mem(G,0),mem(w,0),R.clear();
		read(n),read(W),read(p),read(q);
		For(i,1,n)fa[i]=i;
		For(i,1,p)
		{
			read(x),read(y),read(z);
			read(a),read(b),read(c),read(d),read(e),read(f);
			add(x,y,a,d);
			add(y,z,b,e);
			add(z,x,c,f);
		}
		For(i,1,q)
		{
			read(x),read(y),read(z);
			if(z==2)w[x]=-1,w[y]=1;
			if(z==1)Combine(x,y);
			if(z==0)R.pb(pii(x,y));
		}
		ans=inf;
		dfs(1);
		printf("%lld\n",ans);
	}
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
