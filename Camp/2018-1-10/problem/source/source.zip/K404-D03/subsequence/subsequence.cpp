#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=4010;

int a[N],b[N];

int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	
	int n=read(),m=read(),K=read();
	register int i,j,k,now;
	for(i=1;i<=n;++i) a[i]=read();
	for(i=1;i<=m;++i) b[i]=read();
	if(K==2)
	{
		for(i=1;i<=n;++i) a[i]--;
		for(i=1;i<=m;++i) b[i]--;
		bool flag=0;
		for(i=1;i<=n;++i)
			if(!a[i])flag=1;
		for(i=1;i<=m;++i)
			if(!b[i])flag=1;
		if(!flag){cout<<1<<endl;return 0;}
		for(i=1;i<1<<(max(n,m));++i)
		{
			j=n;now=i;
			while(now && j)
			{
				if(a[j]==(now&1)) now>>=1;
				j--;
			}
			if(!now) continue;
			j=m;now=i;
			while(now && j)
			{
				if(b[j]==(now&1)) now>>=1;
				j--;
			}
			if(!now) continue;
			int res=0;
			while(i) res++,i>>=1;
			cout<<res<<endl;
			return 0;
		}
	}
	return 0;
}

