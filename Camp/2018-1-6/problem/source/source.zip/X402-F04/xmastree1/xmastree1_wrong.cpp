//2018-1-6
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000+5)
#define M (30000000+5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x<<1) + (x<<3) + (chr^'0');
		chr = getchar();
	}
}

struct node{
	int ls, rs, v;
};

int n, ql, qr;

#define lc h[o].ls
#define rc h[o].rs
#define mid ((L+R)>>1)

namespace Seg_tree{
	int hn, root[N];
	node h[M];

	void Modify(int &o, int L, int R, int p, int pv){
		if(!o) o = ++hn;
		if(L == R){h[o].v += pv; return;}
		
		if(p <= mid) Modify(lc, L, mid, p, pv);
		else Modify(rc, mid+1, R, p, pv);
		h[o].v = h[lc].v + h[rc].v;
	}

	int Query(int o, int L, int R){
		if(!o) return 0;
		if(ql <= L && qr >= R) return h[o].v;

		int ret = 0;
		if(ql <= mid) ret += Query(lc, L, mid);
		if(qr > mid) ret += Query(rc, mid+1, R);
		return ret;
	}
};

#undef lc
#undef rc
#undef mid

using namespace Seg_tree;

int c[N];

int lowbit(int x){return x & (-x);}
void Add(int x, int y, int v){
	while(x <= n){
		Modify(root[x], 1, n, y, v);
		x += lowbit(x);
	}
}
int Sum(int x){
	int ret = 0;
	while(x > 0){
		ret += Query(root[x], 1, n); x -= lowbit(x);
	}
	return ret;
}
int Qry(int L, int R){return L <= R? Sum(R) - Sum(L-1): 0;}

int dfn, col[N], id[N], in[N], out[N];
vector<int> G[N];

void Dfs(int now, int F){
	id[now] = in[now] = ++dfn;
	Add(col[now], id[now], 1);

	For(i, 0, G[now].size()-1)
		if(G[now][i] != F) Dfs(G[now][i], now);
	out[now] = dfn;
}

int main(){
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	
	int q, t, u, v;

	Read(n); Read(q); Read(t);
	For(i, 1, n) Read(col[i]);
	
	For(i, 1, n-1){
		Read(u); Read(v);
		G[u].pb(v); G[v].pb(u);
	}
	Dfs(1, 0);
//	For(i, 1, n) printf("id[%d] = %d\n", i, id[i]);
	
	int ans = 0, op, l, r, uc;

	while(q--){
		Read(op);

		if(op == 1){
			Read(u), Read(l), Read(r);
			if(t) u^=ans, l^=ans, r^=ans;
			
			ql = in[u]; qr = out[u];
			printf("%d\n", ans=Qry(l, r));
		
		}else{
			Read(u); Read(uc);
			Add(col[u], id[u], -1); Add(col[u]=uc, id[u], 1);
		}
	}

	return 0;
}
