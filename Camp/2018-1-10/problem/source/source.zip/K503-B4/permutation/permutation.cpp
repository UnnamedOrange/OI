#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const int maxn=1e5+5;
const int mod=998244353;
int n,m,ai[maxn],size[maxn],num,cnt[2];
bool vis[maxn],vis2[maxn];
ll fac[maxn],finv[maxn],inv[maxn],f[100][100],g[maxn],dp[maxn];
inline void read(int &now)
{
	char Cget;
	now=0;
	while((Cget=getchar())>'9'||Cget<'0');
	while(Cget>='0'&&Cget<='9')
	{
		now=now*10+Cget-'0';
		Cget=getchar();
	}
}
inline ll C(int a,int b)
{
	return (fac[a]*finv[b])%mod*finv[a-b]%mod;
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	read(n);
	inv[1]=1;
	fac[1]=1;
	finv[1]=1;
	finv[0]=1;
    for(int i=2;i<=n+1;i++)
    {
		inv[i]=-mod/i*inv[mod%i]%mod;
		(inv[i]+=mod)%=mod;
		fac[i]=fac[i-1]*i%mod;
		finv[i]=finv[i-1]*inv[i]%mod;
	}
	for(int i=1;i<=n;i++)
	{
		read(ai[i]);
		vis[ai[i]]=true;
	}
	for(int i=1;i<=n;i++)
		if(!vis[i])
		{
			vis[i]=true;
			int t=i;
			++num;
			while(t)
			{
				vis2[t]=true;
				++size[num];
				t=ai[t];
			}
			cnt[size[num]%2]++;
		}
	for(int i=1;i<=n;i++)
		if(!vis2[i])
		{
			int t=i,tmp=0;
			while(t)
			{
				vis2[t]=true;
				++tmp;
				t=ai[t];
			}
			if(tmp%2)
			{
				puts("0");
				fclose(stdin);
				fclose(stdout);
				return 0;
			}
		}
	if(cnt[1]%2)
	{
		puts("0");
		
				fclose(stdin);
				fclose(stdout);
		return 0;
	}
	g[0]=1;
	g[1]=1;
	for(int i=2;i<=n;i++)
		g[i]=g[i-1]*(i-1)%mod;
	if(cnt[0]+cnt[1]<=10)
	{
		f[0][0]=1;
		for(short i=0;i<=cnt[1];++i)
			for(short v=0;v<=cnt[0];++v)
				if(i||v)
				{
					for(short e=0;e<=i;e+=2)
						for(short k=0;k<=v;++k)
							if(e+k)
							{
								if(!e)
									(f[i][v]+=f[i][v-k]*g[k]%mod*C(cnt[0]-v+k-1,k-1))%=mod;
								else if(!k)
									(f[i][v]+=f[i-e][v]*g[e]%mod*C(cnt[1]-i+e-1,e-1))%=mod;
								else
									(f[i][v]+=f[i-e][v-k]*g[e+k]%mod*(C(cnt[1]-i+e-1,e-1)*C(cnt[0]-v+k-1,k-1)%mod))%=mod;
							}
				}
		std::cout<<f[cnt[1]][cnt[0]];
	}
	else
	{
		dp[0]=1;
		for(int i=2;i<=cnt[1];i+=2)
			for(int v=2;v<=i;v+=2)
				(dp[i]+=(dp[i-v]*g[v])%mod*C(cnt[1]-i+v-1,v-1))%=mod;
		std::cout<<dp[cnt[1]];
	}
	
				fclose(stdin);
				fclose(stdout);
	return 0;
}
