#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int N = 100005;
int T, n;
char s[N];

bool huiwen(){
	for(int i = 1, j = n; i < j; i++, j--)
		if(s[i] != s[j]) return 0;
	return 1;
}
bool same(){
	char c = s[1];
	for(int i = 2; i <= n; i++)
		if(s[i] != c) return 0;
	return 1;	
}

int main(){

	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);

	read(T);
	while(T--){
		read(n);
		scanf("%s", s + 1);
		if(huiwen()){
			if(same()) puts("-1");
			else puts("2");
		}
		else puts("1");
	}
	
	return 0;
}
/*
2 7 
abcdcba
3
xxx
*/
