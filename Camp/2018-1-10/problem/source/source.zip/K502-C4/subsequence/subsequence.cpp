#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<queue>
using namespace std;

int n,m,K,a[303],b[303],top;

struct node
{
	int v,son[303];
} s[1000005];

struct trie
{
	int v,depth;
} t;
queue<trie> q;

void buildtrie_n(int now,int k)
{
	if(k==n+1) return;
	if(s[now].son[a[k]]==0)
	{
		top++;
		s[top].v=a[k];
		s[now].son[a[k]]=top;
	}
	for(int i=k+1;i<=n;i++)
		buildtrie_n(s[now].son[a[k]],i);
}

void buildtrie_m(int now,int k)
{
	if(k==m+1) return;
	if(s[now].son[b[k]]==0)
	{
		top++;
		s[top].v=b[k];
		s[now].son[b[k]]=top;
	}
	for(int i=k+1;i<=m;i++)
		buildtrie_m(s[now].son[b[k]],i);
}

void bfs()
{
	t.v=0; t.depth=0;
	q.push(t);
	while(!q.empty())
	{
		t=q.front(); q.pop();
		int root=t.v, depth=t.depth;
		for(int i=1;i<=K;i++)
		{
			if(s[root].son[i]==0)
			{
				printf("%d",depth+1);
				exit(0);
				//return;
			}
			else
			{
				t.v=s[root].son[i];
				t.depth=depth+1;
				q.push(t);
			}
		}
	}
}

int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
		buildtrie_n(0,i);
	for(int i=1;i<=m;i++)
		buildtrie_m(0,i);
	bfs();
	printf("%d",max(n,m)+1);
	return 0;
}
