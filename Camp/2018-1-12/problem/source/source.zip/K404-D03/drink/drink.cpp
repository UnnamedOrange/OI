#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

typedef double db;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=1510;

struct node
{
	int val,pos;
	friend bool operator <(const node &x,const node &y)
	{return x.val<y.val;}
}p[N];

struct seg_tree{db sum;int num;}tr[N<<2];
int V[N],rk[N];
db pw[N];

db modify(int k,int l,int r,int x)
{
	if(l==r)
	{
		tr[k].num++;
		tr[k].sum+=V[l]*pw[tr[k].num];
		return tr[k].sum;
	}
	int mid=(l+r)>>1;
	x<=mid ? modify(k<<1,l,mid,x) : modify(k<<1|1,mid+1,r,x);
	tr[k].num=tr[k<<1].num+tr[k<<1|1].num;
	tr[k].sum=tr[k<<1|1].sum+tr[k<<1].sum*pw[tr[k<<1|1].num];
	return tr[k].sum;
}

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	
	int n=read();
	register int i,j;
	for(i=1;i<=n;++i)
		p[i].val=read(),p[i].pos=i;
	sort(p+1,p+1+n);
	for(i=1;i<=n;++i)
		rk[p[i].pos]=i,V[i]=p[i].val;
	pw[0]=1;
	for(i=1;i<=n;++i) pw[i]=pw[i-1]*0.5;
	db ans(0);
	for(i=1;i<=n;++i)
	{
		if(i>1) memset(tr,0,sizeof(tr));
		for(j=i;j<=n;++j)
			ans+=modify(1,1,n,rk[j]);
	}
	ans/=db(1ll*n*n);
	printf("%.8lf\n",ans);
}
/*
5
1 2 3 4 1

1.238750000000000
*/


