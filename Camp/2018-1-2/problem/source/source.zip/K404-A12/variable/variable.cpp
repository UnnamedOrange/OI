#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct H{
	int id[4],a[10];
}h[1005];
struct query{
	int x,y,r;
}q[1005];
int n,P,Q;
ll now[1005],w;
ll zh(ll a){
	return (a<0)?-a:a;
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%d%lld%d%d",&n,&w,&P,&Q);
		for(int i=1;i<=P;i++){
			for(int p=1;p<=3;p++) scanf("%d",&h[i].id[p]);
			for(int p=1;p<=6;p++) scanf("%d",&h[i].a[p]);
		}
		for(int i=1;i<=Q;i++){
			scanf("%d%d%d",&q[i].x,&q[i].y,&q[i].r);
		}
		ll ans=1e15;
		for(int i=0;i<(1<<n);i++){
			ll sum=0;
			for(int p=1;p<=n;p++){
				now[p]=-w;
				if(i&(1<<p-1)) now[p]=w;
				sum+=now[p];
			}
			bool t=1;
			for(int p=1;p<=Q;p++){
				if(q[p].r==0&&now[q[p].x]>now[q[p].y]){
					t=0;break;
				}
				if(q[p].r==1&&now[q[p].x]!=now[q[p].y]){
					t=0;break;
				}
				if(q[p].r==2&&now[q[p].x]>=now[q[p].y]){
					t=0;break;
				}
			}
			if(!t) continue;
			for(int p=1;p<=P;p++){
				int x,nxt;
				for(int j=1;j<=3;j++){
					x=h[p].id[j];nxt=(j==3)?h[p].id[1]:h[p].id[j+1];
					sum+=zh(now[x]-now[nxt])*h[p].a[j];
					sum+=(now[x]-now[nxt])*h[p].a[j+3];
				}
			}
			ans=min(ans,sum);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
