#include<cstdio> 
using namespace std;
int main(){ 
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	int t,n,T,x,y;
	scanf("%d",&t);
	scanf("%d%d",&n,&T);
	while(T--){
		scanf("%d%d",&x,&y);
		if(t==1) printf("%d\n",x);
		else{
			if(x==y) printf("yes\n");
			else printf("no\n");
 		}
	}
	return 0;
} 
