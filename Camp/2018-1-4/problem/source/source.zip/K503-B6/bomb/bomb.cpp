#include<algorithm>
#include<iostream>
#include<cstring>
#include<cctype>
#include<cstdio>
#include<string>
#define rep(i,x,y) for(register int i = x;i <= y; ++ i)
using namespace std;
typedef long long ll;
template<typename T>inline void read(T&x)
{
	x = 0; char c;int sign = 1;
	do { c = getchar(); if(c == '-') sign = -1; }while(!isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar() ; }while(isdigit(c));
	x *= sign;
}

inline void init(string name)
{
	string in = name + ".in",out = name + ".out";
	freopen(in.c_str(),"r",stdin);
	freopen(out.c_str(),"w",stdout);
}

const int N = 1e6 + 500;
int n,m,ans,cnt[N],belong[N],f[N];
int tot,head[N],to[N],nxt[N];
int Tot,Head[N],To[N],Nxt[N];
int s[N],dfn[N],low[N],sz,top,scc;
bool vis[N];

inline void add(int x,int y) { nxt[tot] = head[x]; to[tot] = y; head[x] = tot++; }
inline void Add(int x,int y) { Nxt[Tot] = Head[x]; To[Tot] = y; Head[x] = Tot++; }

void tarjan(int x)
{
	s[++top] = x; vis[x] = 1;
	dfn[x] = low[x] = ++sz;
	for(register int i = head[x] ;~i ; i = nxt[i])
		if(!vis[to[i]])
		{
			tarjan(to[i]);
			low[x] = min(low[x],low[to[i]]);
		}else low[x] = min(low[x],dfn[to[i]]);
	
	if(dfn[x] == low[x])
	{
		belong[x] = ++scc; vis[x] = 0;cnt[scc] = 1;
		while(s[top] != x)
		{
			++cnt[scc];
			vis[s[top]] = 0;
			belong[s[top--]] = scc;
		}
		top --;
	}
}

void dfs(int x)
{
	for(register int i = Head[x];~i; i = Nxt[i])
		if(!f[To[i]])
		{
			dfs(To[i]);
			f[x] = max(f[x],f[To[i]]);
		}
		else f[x] = max(f[x],f[To[i]]);
	
	f[x] += cnt[x]; 
	ans = max(f[x],ans);
}

int main()
{
	init("bomb");
	memset(head,-1,sizeof head);
	memset(Head,-1,sizeof Head);
	read(n);read(m);
	rep(i,1,m)
	{
		int u ,v;
		read(u);read(v);
		add(u,v);
	}
	
	rep(i,1,n)
		if(!belong[i])
			tarjan(i);
	
	rep(j,1,n) for(register int i = head[j];~i; i = nxt[i])
		if(belong[j] != belong[to[i]])Add(belong[j],belong[to[i]]);
	
	rep(i,1,scc) if(!f[i]) dfs(i);
	
	cout<<ans<<endl;
	
	return 0;
}
