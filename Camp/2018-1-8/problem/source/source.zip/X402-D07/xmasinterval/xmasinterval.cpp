#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=500010,mo=1e9+9;
int n,m,a[maxn],ans,cnt;
struct data{
    int l,r;
    bool operator < (const data& rhs) const{
        return l<rhs.l||l==rhs.l&&r>rhs.r;
    }
} t[maxn];
int fpm(int x,int k){
    int ret=1;
    for(;k;k>>=1,x=1ll*x*x%mo)
        if(k&1) ret=1ll*ret*x%mo;
    return ret;
}
void Inc(int& x,int y){
    x+=y;
    if(x>=mo) x-=mo;
    if(x<0) x+=mo;
}
namespace SGT{
#define ls h<<1
#define rs h<<1|1
#define mid ((l+r)>>1)
#define lc l,mid
#define rc mid+1,r
    int T[maxn*3],mul[maxn*3];
    void creat(){ for(int i=1;i<maxn*3;i++) mul[i]=1; }
    void pushdown(int h){
        if(mul[h]!=1){
            T[ls]=1ll*T[ls]*mul[h]%mo;
            T[rs]=1ll*T[rs]*mul[h]%mo;
            mul[ls]=1ll*mul[ls]*mul[h]%mo;
            mul[rs]=1ll*mul[rs]*mul[h]%mo;
            mul[h]=1;
        }
    }
    void pushup(int h){ T[h]=(T[ls]+T[rs])%mo; }
    void update(int h,int l,int r,int L,int R){
        if(L>R) return;
        if(L<=l&&r<=R){
            T[h]=T[h]*2%mo;
            mul[h]=mul[h]*2%mo;
            return;
        }
        pushdown(h);
        if(L<=mid) update(ls,lc,L,R);
        if(R>mid) update(rs,rc,L,R);
        pushup(h);
    }
    void modify(int h,int l,int r,int p,int w){
        if(l==r) return void(Inc(T[h],w));
        pushdown(h);
        if(p<=mid) modify(ls,lc,p,w);
        else modify(rs,rc,p,w);
        pushup(h);
    }
    int query(int h,int l,int r,int L,int R){
        if(L>R) return 0;
        if(L<=l&&r<=R) return T[h];
        pushdown(h);
        int ret=0;
        if(L<=mid) Inc(ret,query(ls,lc,L,R));
        if(R>mid) Inc(ret,query(rs,rc,L,R));
        return ret;
    }
}
using namespace SGT;
int main(){
    freopen("xmasinterval.in","r",stdin);
    freopen("xmasinterval.out","w",stdout);
    read(n); read(m);
    for(int i=1;i<=n;i++) read(t[i].l),read(t[i].r);
    for(int i=1;i<=m;i++) read(a[i]);
    sort(a+1,a+m+1);
    for(int i=1;i<=n;i++){
        t[i].l=lower_bound(a+1,a+m+1,t[i].l)-a;
        t[i].r=upper_bound(a+1,a+m+1,t[i].r)-a-1;
    }
    sort(t+1,t+n+1);
    creat();
    for(int i=1;i<=n;i++){
        if(t[i].l>t[i].r) ++cnt;
        else{
            int F=(t[i].l==1)+query(1,1,m,max(t[i].l-1,1),t[i].r);
            update(1,1,m,t[i].r+1,m);
            modify(1,1,m,t[i].r,F);
        }
    }
    printf("%d\n",1ll*query(1,1,m,m,m)*fpm(2,cnt)%mo);
    return 0;
}
