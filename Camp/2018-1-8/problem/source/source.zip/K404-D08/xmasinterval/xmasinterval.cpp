#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>
#include<ctime>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=1500010,P=1000000009;
int n,m,x0,k0,x[N],l[N],r[N],xt[N],f[N],pw[N],all;
map <int,int> mp;
map <int,int> :: iterator it;
int ft[N],tot;
struct edge{int t,n;}E[N];
void add_edge(int x,int y){
	E[++tot]=(edge){y,ft[x]},ft[x]=tot;
}
void upd(int &x,int y){x=(x+y)%P;}
int n0;
#define ___ int t=1,int l=1,int r=n0
#define mid ((l+r)>>1)
#define ls t<<1,l,mid
#define rs t<<1|1,mid+1,r
struct dat{int t,s;}a[N<<2];
void addup(int t,int k){
	a[t].t+=k;
	a[t].s=(LL)a[t].s*pw[k]%P;
}
void push(int t){
	addup(t<<1,a[t].t);
	addup(t<<1|1,a[t].t);
	a[t].t=0;
}
void rev(___){
	if (l==r){
		a[t]=(dat){0,k0};
		return;
	}
	if (a[t].t) push(t);
	if (x0<=mid) rev(ls); else rev(rs);
	a[t].s=(a[t<<1].s+a[t<<1|1].s)%P;
}
void mul(___){
	if (x0>=r){
		upd(all,a[t].s);
		++a[t].t;
		a[t].s=a[t].s*2%P;
		return;
	}
	if (a[t].t) push(t);
	mul(ls);
	if (x0>mid) mul(rs);
	a[t].s=(a[t<<1].s+a[t<<1|1].s)%P;
}
inline void rd(int &x){
	static char ch;
	x=0;
	while ((ch=getchar())>'9'||ch<'0');
	while (ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
//	printf("%d\n",time(0));
	scanf("%d%d",&n,&m);
	rep(i,1,n) /*rd(l[i]),rd(r[i]),*/scanf("%d%d",l+i,r+i),mp[l[i]],mp[r[i]];
	rep(i,1,m) /*rd(x[i]),*/scanf("%d",x+i),mp[x[i]];
//	printf("%d\n",time(0));
	mp[0];
	int ii=0;
	for (it=mp.begin();it!=mp.end();it++) it->se=++ii;
	rep(i,1,n) l[i]=mp[l[i]],r[i]=mp[r[i]];
	rep(i,1,m) x[i]=mp[x[i]];
	rep(i,1,n) add_edge(r[i],l[i]);
	rep(i,1,m) xt[x[i]]=1;
	xt[1]=xt[++ii]=1;
	n0=ii;
	f[1]=-1;
	x0=1,k0=-1,rev();
	all=-1;
	pw[0]=1;
	rep(i,1,ii) pw[i]=pw[i-1]*2%P;
	rep(i,2,ii){
		if (xt[i]){
//			rep(j,1,i-1) if (xt[j]) upd(f[i],f[j]);
//			f[i]=-f[i];
			f[i]=-all;
			x0=i,k0=-all,all=0,rev();
		}
		go(i){
//			rep(j,1,v-1) f[j]=f[j]*2%P;
			x0=v-1,mul();
		}
	}
	f[ii]=(f[ii]+P)%P;
	printf("%d\n",f[ii]);
//	printf("%d\n",time(0));
	return 0;
}
