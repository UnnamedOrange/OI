#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=1000010;
struct edge{int t,n;}E[N];
int ft[N],dfn[N],low[N],bel[N],sta[N],ins[N],q[N],deg[N],sum[N];
int n,m,ex[N],ey[N],top,tim,tot,ans;
void upd(int &x,int y){x=min(x,y);}
void dfs(int u){
	dfn[u]=low[u]=++tim;
	sta[++top]=u;
	ins[u]=1;
	go(u) if (!dfn[v]){
		dfs(v);
		upd(low[u],low[v]);
	} else if (ins[v]) upd(low[u],dfn[v]);
	if (low[u]!=dfn[u]) return;
	while (1){
		int v=sta[top--];
		bel[v]=u;
		ins[v]=0;
		++sum[u];
		if (v==u) break;
	}
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,m){
		int x,y;
		scanf("%d%d",&x,&y);
		ex[i]=x,ey[i]=y;
		E[++tot]=(edge){y,ft[x]},ft[x]=tot;
	}
	rep(i,1,n) if (!dfn[i]) dfs(i);
	memset(ft,0,sizeof(ft)),tot=0;
	rep(i,1,m){
		int x=bel[ex[i]],y=bel[ey[i]];
		if (x==y) continue;
		E[++tot]=(edge){y,ft[x]},ft[x]=tot;
		++deg[y];
	}
	int h=1,t=0;
	rep(i,1,n) if (bel[i]==i&&deg[i]==0) q[++t]=i;
	while (h<=t){
		++ans;
		int t0=t;
		rep(i,h,t0){
			int u=q[i];
			--sum[u];
			if (sum[u]) q[++t]=u;
			else go(u) if (!--deg[v]) q[++t]=v;
		}
		h=t0+1;
	}
	printf("%d\n",ans);
	return 0;
}

