#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int P=1000000007;
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
void Del(int &x,int y){
	x-=y;
	if(x<0)x+=P;
}
int fast(int x,int p){
	int re=1;
	while(p){
		if(p&1)re=(long long)re*x%P;
		x=(long long)x*x%P,p>>=1;
	}return re;
}
long long s;
int t,n,m;
struct SHUI{
	int dp[105];
	void solve(){
		dp[0]=1;
		for(int i=1;i<=n;i++){
			for(int j=s;j>=0;j--)
				if(dp[j]){
					for(int k=1;k<=t;k++)
						if(j+k<=s)Add(dp[j+k],dp[j]);
						else break;
					dp[j]=0;
				}
		}
		for(int i=n+1;i<=m;i++){
			for(int j=s;j>=0;j--)
				if(dp[j]){
					for(int k=j+1;k<=s;k++)Add(dp[k],dp[j]);
					dp[j]=0;
				}
		}
		int ans=0;
		for(int i=1;i<=s;i++)Add(ans,dp[i]);
		printf("%d\n",ans);
	}
}P20;
struct IHSU{
	int ansl[1000005];
	int fac[1000005],rfac[1000005];
	int C(int a,int b){
		return (long long)fac[a]*rfac[b]%P*rfac[a-b]%P;
	}
	void solve(){
		fac[0]=1;
		for(int i=1;i<1000005;i++)fac[i]=(long long)fac[i-1]*i%P;
		rfac[1000004]=fast(fac[1000004],P-2);
		for(int i=1000003;i>=0;i--)rfac[i]=(long long)rfac[i+1]*(i+1)%P;
		int ans=C(s,m);
		for(int i=1,c=1;i<=n&&s-i*t>=m;i++,c^=1)
			if(c){
				Del(ans,(long long)C(n,i)*C(s-i*t,m)%P);
			}else {
				Add(ans,(long long)C(n,i)*C(s-i*t,m)%P);
			}
		printf("%d\n",ans);
	}
}P30;

int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	cin>>s>>t>>n>>m;
	if(s<m)puts("0");
	else if(s<=100&&t<=100&&n<=100&&m<=100)P20.solve();
	else if(s<=1000000&&m<=1000000)P30.solve();
	
	return 0;
}
