#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int p=998244353;
struct edge{int u,v,nex;}e[2200];
int n,k,fir[200],size,cho[11],fa[11],h[11],ans;
void add(int u,int v){e[++size].u=u;e[size].v=v;e[size].nex=fir[u];fir[u]=size;}
int find(int x,int t){
	if (cho[x]||h[x]) return 0;
	h[x]=1;
	if (fa[x]==t) {h[x]=0;return x;}
	for (int i=fir[x];i;i=e[i].nex){
		int y=find(e[i].v,t);
		if (y) {h[x]=0;return y;}
	}
	h[x]=0;return 0;
}
bool dfs(int x){
	cho[x]=1;
	for (int i=fir[x];i;i=e[i].nex){
		int y=e[i].v,z=find(y,x);
		if (cho[y]) continue;
		if (!z) return false;
		if (!dfs(z)) return false;
	}
	return true;
}
int f[11][11],c[11][11];
int dp(int x,int y){
	if (y>k) return 0;
	if (c[x][y]) return f[x][y];
	c[x][y]=1;
	int t=1;
	for (int i=1;i<=n;i++)
	if (fa[i]==x) t=(ll)t*dp(i,y+1)%p;
	f[x][y]=(dp(x,y+1)+t)%p;
	return f[x][y];
}
void check(int root){
	memset(cho,0,sizeof(cho));
	memset(c,0,sizeof(c));
	if (!dfs(root)) return;
	memset(f,0,sizeof(f));
	ans=(ans+dp(root,1))%p;
}
void work(int dep,int fl){
	if (dep>n) {check(fl);return;}
	if (fl==0) {fa[dep]=0;work(dep+1,dep);}
	if (dep<=n-1+(fl>0)){
		for (int i=1;i<=n;i++)
		if (i!=dep) {fa[dep]=i;work(dep+1,fl);}
	}
}
int main(){
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	size=0;ans=0;
	scanf("%d%d",&n,&k);
	for (int i=1;i<n;i++){
		int x,y;
		scanf("%d %d",&x,&y);
		add(x,y);
		add(y,x);
	}
	work(1,0);
	printf("%d\n",ans);
	return 0;
}
