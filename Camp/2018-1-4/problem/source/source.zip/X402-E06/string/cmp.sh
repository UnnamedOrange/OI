cas=1
while true; do
    python3 ./gen.py || break
    ./bf || break
    ./string || break

    diff ./bf.out ./string.out || break

    echo $cas
    cas=`expr $cas + 1`
done
