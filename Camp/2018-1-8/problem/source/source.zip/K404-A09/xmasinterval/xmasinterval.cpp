#include<bits/stdc++.h>
using namespace std;
#define N 500010
const int mod=1000000009;
struct Query {
	int l,r;
}q[N];
int x[N],n,m,ans;
void dfs(int po) {
	if(po==n+1) {
		for(int i=1;i<=m;i++) if(x[i]!=-1) return;
		ans++;
		return;
	}
	dfs(po+1);
	int tmp[20];
	memcpy(tmp,x,sizeof(tmp));
	for(int i=1;i<=m;i++) {
		if(x[i]>=q[po].l&&x[i]<=q[po].r) x[i]=-1;
	}
	dfs(po+1);
	memcpy(x,tmp,sizeof(tmp));
}
int main() {
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) {
		scanf("%d%d",&q[i].l,&q[i].r);
	}
	for(int i=1;i<=m;i++) scanf("%d",&x[i]);
	dfs(1);
	printf("%d",ans);
}
