#include<bits/stdc++.h>
#define FE "drink"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c))(c=='-'?p=-1:0),c=getchar();
	while(isdigit(c))x=(x<<3)+(x<<1)+(c^'0'),c=getchar();
	return x*p;
}
inline void putint(int x){
	static int buf[20];
	int tot=0;
	x<0?putchar('-'),x=-x:0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
int n,a[1000005],temp[1000005];
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	n=getint();
	for(int i=1;i<=n;++i){
		a[i]=getint();
	}
	double ans=0;
	for(int i=1;i<=n;++i){
		for(int j=i;j<=n;++j){
			for(int k=i;k<=j;++k){
				temp[k]=a[k];
			}
			sort(temp+i,temp+j+1);
			double x=0.5;
			for(int k=j;k>=i;--k){
				ans+=x*temp[k];
				x/=2.0;
			}
		}
	}
	printf("%.8f",ans/n/n);
	return 0;
}
