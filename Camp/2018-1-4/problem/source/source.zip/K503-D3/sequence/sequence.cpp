#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;

int n,a[30];

void reverse(int r){
	for (int i=0;i<=r>>1;i++)
		swap(a[i],a[r-i]);
}

bool dfs(int x, int p, int k){
	if (x>k) return false;
	while (p>=0&&a[p]==p+1) p--;
	if (p<0) return true;
	int c=0;
	for (int i=0;i<p+1;i++)
		if (abs(a[i]-a[i-1])!=1) c++;
	if (x+c>k) return false;
	for (int i=1;i<=p;i++){
		reverse(i);
		if (dfs(x+1,p,k)) return true;
		reverse(i);
	}
	return false;
}

int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int t; scanf("%d",&t);
	while (t--){
		scanf("%d",&n);
		for (int i=0;i<n;i++)
			scanf("%d",&a[i]);
		int ans=0;
		while (!dfs(0,n-1,ans)) ans++;
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

