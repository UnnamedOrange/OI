#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,m,k;
int a[4005],b[4005];
int f[4005][4005];
bool vis[4005][4005];

int dp(int ai,int bi)
{
	if(ai==n+1&&bi==m+1)
	  return 0;
	if(vis[ai][bi]==1)
	  return f[ai][bi];
	vis[ai][bi]=1;
	int cola[4005]={0};
	int colb[4005]={0};
	for(int i=n;i>ai;i--)
	  cola[a[i]]=i;
	for(int i=m;i>bi;i--)
	  colb[b[i]]=i;
	for(int i=1;i<=k;i++)
	{
		if(cola[i]==0)cola[i]=n+1;
		if(colb[i]==0)colb[i]=m+1;
	    f[ai][bi]=min(f[ai][bi],dp(cola[i],colb[i])+1);
    }
	return f[ai][bi];
}

int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	memset(f,0x7f7f7f7f,sizeof(f));
	for(int i=1;i<=n;i++)
	  scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
	  scanf("%d",&b[i]);
	printf("%d",dp(0,0));
}
