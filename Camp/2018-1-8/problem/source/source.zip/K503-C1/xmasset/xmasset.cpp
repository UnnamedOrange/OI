#include <bits/stdc++.h>

int type, N;

void init()
{
    
}
int read(){
	int tmp=0, fh=1; char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') fh=-1; ch=getchar();}
	while (ch>='0'&&ch<='9'){tmp=tmp*10+ch-'0'; ch=getchar();}
	return tmp*fh;
}
int encode(int x, int y)
{
    return x;
}

bool decode(int q, int h)
{
    return q == h;
}

int main()
{
    int T;
    type=read(), N=read(), T=read();
    init();
    while (T--) {
        int x, y;
        x=read(), y=read();
        if (type == 1){
        	if (x==y){
        		for (int j=1, k=0; ; j<<=1, k++)
        			if ((x&j)!=0){
	        			printf("%d\n",k*2+(x>>k)%2+1);
    	    			break;
					}
			}
			else
        	for (int j=1, k=0; ; j<<=1, k++){
        		if ((x&j)!=(y&j)){
	        		printf("%d\n",k*2+(x>>k)%2+1);
    	    		break;
    	    	}
			}
    	}
        else{
        	int q=x, h=y-1;
        	if ((q&(1<<(h/2)))==((h%2)<<(h/2)))
        		printf("yes\n");
        		else printf("no\n");
		}
    }
}

