#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <sstream>
#include <cctype>
#include <cmath>
#include <algorithm>
#define THE_BRST_PONY "Rainbow Dash"

using namespace std;
const int N=1100000;

inline int RD() {
	char ch=getchar();
	int x=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) {
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x;
}

int n,m,ans,clk,b;
int dc[N][2],blk[N],bsiz[N];
int dp[N],deg[N];

struct Graph {
	int cnt,h[N],nxt[N],to[N];
	
	void AddEdge(int x,int y) {
		cnt++; nxt[cnt]=h[x]; h[x]=cnt; to[cnt]=y;
		return;
	}
}G1,G2;

void DFS(int x) {
	dc[x][0]=++clk;
	blk[x]=x;
	for(int e=G1.h[x];e;e=G1.nxt[e]) {
		if(dc[G1.to[e]][1]) continue;
		if(!dc[G1.to[e]][0]) DFS(G1.to[e]);
		if(dc[blk[x]][0]>dc[blk[G1.to[e]]][0])
			blk[x]=blk[G1.to[e]];
	}
	dc[x][1]=clk;
	return;
}

int GetAns(int x) {
	if(dp[x]) return dp[x];
	dp[x]=bsiz[x];
	for(int e=G2.h[x];e;e=G2.nxt[e])
		dp[x]=max(dp[x],GetAns(G2.to[e])+bsiz[x]);
	return dp[x];
}

int main() {
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=RD(); m=RD();
	for(int i=0;i<m;i++) {
		int a,b;
		a=RD(); b=RD();
		G1.AddEdge(a,b);
	}
	for(int i=1;i<=n;i++) {
		if(!dc[i][0]) DFS(i);
		bsiz[blk[i]]++;
	}
	for(int i=1;i<=n;i++) {
		for(int e=G1.h[i];e;e=G1.nxt[e]) {
			if(blk[G1.to[e]]!=blk[i]) {
				G2.AddEdge(blk[i],blk[G1.to[e]]);
				deg[blk[G1.to[e]]]++;
			}
		}
	}
	for(int i=1;i<=n;i++)
		if(bsiz[i]&&!deg[i])
			ans=max(ans,GetAns(i));
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
9 10
1 3
4 1
4 2
3 4
3 6
4 7
7 6
5 6
5 8
6 9
*/
