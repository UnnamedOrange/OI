#include <algorithm>
#include <iostream>
#include <cstdio>
#define MOD 1000000007
using namespace std; 
inline int getint()
{
	int res = 0, ch = getchar(); 
	for (; ch < 48; ch = getchar());
	for (; ch >= 48; ch = getchar())
		res = res * 10 + (ch ^ 48); 
	return res; 
}
template <typename T>
inline void upd(T &a, T b)
{
	a += b; 
	if (a >= MOD)
		a -= MOD;
}
template <typename T>
inline T sum(T a, T b)
{
	a += b; 
	if (a >= MOD)
		a -= MOD;
	return a; 
}
namespace brute
{
	int dp[2005], ans[2005], c[2005], d[2005]; 
	bool vis[2005]; 
	inline void solve(int n)
	{
		vis[0] = true; 
		ans[0] = 1; 
		for (int i = 1; i <= n; i++)
		{
			scanf("%d%d", c + i, d + i); 
			int mn = -1e9, mx = 1e9; 
			for (int j = i; j >= 0; j--)
			{
				if (mn <= i - j && i - j <= mx && vis[j])
				{
					if (dp[j] + 1 > dp[i])
					{
						vis[i] = true; 
						dp[i] = dp[j] + 1; 
						ans[i] = ans[j]; 
					}
					else if (dp[j] + 1 == dp[i])
						upd(ans[i], ans[j]); 
				}
				mn = max(mn, c[j]); 
				mx = min(mx, d[j]); 
			}
		}
		if (!vis[n])
			puts("-1"); 
		else
			printf("%d %d\n", dp[n], ans[n]);
	}
}
int n, bit[1000005], st[1000005][25]; 
int c[1000005], d[1000005], pre[1000005]; 
inline int query_st(int l, int r)
{
	int len = bit[r - l + 1]; 
	return min(st[l][len], st[r - (1 << len) + 1][len]); 
}
struct data
{
	int mx, ans;
	data(int _mx = 0, int _ans = 0)
	{
		mx = _mx; 
		ans = _ans; 
	}
	inline data operator +(const data &a) const
	{
		if (mx == a.mx)
			return data(mx, sum(ans, a.ans)); 
		return mx < a.mx ? a : *this; 
	}
	inline data operator +=(const data &a)
	{
		return *this = *this + a; 
	}
} seg[4000005], lazy[4000005], dp[4000005]; 
inline void mark(int u, data x)
{
	seg[u] += x; 
	lazy[u] += x; 
}
inline void push_down(int u)
{
	if (-1 == lazy[u].mx)
		return;
	mark(u << 1, lazy[u]); 
	mark(u << 1 | 1, lazy[u]); 
	lazy[u] = data(-1, 0);
}
void modify(int u, int l, int r, int L, int R, data x)
{
	if (L <= l && r <= R)
	{
		mark(u, x); 
		return; 
	}
	push_down(u); 
	int m = l + r >> 1; 
	if (L <= m)
		modify(u << 1, l, m, L, R, x); 
	if (m < R)
		modify(u << 1 | 1, m + 1, r, L, R, x); 
	seg[u] = seg[u << 1] + seg[u << 1 | 1]; 
}
data query(int u, int l, int r, int L, int R)
{
	if (L > R)
		return data(-1, 0);
	if (L <= l && r <= R)
		return seg[u]; 
	push_down(u); 
	int m = l + r >> 1; 
	data res(-1, 0);
	if (L <= m)
		res += query(u << 1, l, m, L, R); 
	if (m < R)
		res += query(u << 1 | 1, m + 1, r, L, R); 
	return res; 
}
inline void solve(int l, int r, int k, int t)
{
	int L = max(k, l + t), R = min(r, k + t - 1), i = L; 
	data res; 
	while (i <= R)
	{
		if (pre[i] >= k)
			return; 
		if (pre[i] >= l)
			break;
		if (i == L)
			res = query(1, 0, n, l, i - t); 
		else
			res += dp[i - t]; 
		if (~res.mx)
			dp[i] += data(res.mx + 1, res.ans);
		i++; 
	}
	if (i > r)
		return;
	if (pre[i] < l)
	{
		int x = lower_bound(pre + i, pre + r, l) - pre; 
		res = query(1, 0, n, l, k - 1); 
		if (~res.mx)
			modify(1, 0, n, i, x, data(res.mx + 1, res.ans)); 
		i = x + 1; 
	}
	while (i <= r)
	{
		if (pre[i] >= k)	
			return; 
		res = query(1, 0, n, pre[i], min(k - 1, i - t)); 
		if (~res.mx)
			dp[i] += data(res.mx + 1, res.ans); 
		i++;
	}
}
void work(int l, int r)
{
	if (l > r)
		return;
	if (l == r)
	{
		modify(1, 0, n, l, l, dp[l]); 
		dp[l] = query(1, 0, n, l, l); 
		return; 
	}
	int k = max_element(c + l + 1, c + r + 1) - c, t = c[k]; 
	work(l, k - 1); 
	solve(l, r, k, t); 
	work(k, r); 
}
int main()
{
	freopen("schooldays.in", "r", stdin); 
	freopen("schooldays.out", "wt", stdout); 
	n = getint(); 
	if (n <= 2000)
	{
		brute::solve(n); 
		return 0;
	}
	for (int i = 1; i <= n; i++)
	{
		c[i] = getint(); 
		d[i] = getint(); 
		st[i][0] = d[i]; 
	}
	for (int i = 1; i < 22; i++)
	{
		for (int j = 1; j + (1 << i) <= n + 1; j++)
			st[j][i] = min(st[j][i - 1], st[j + (1 << i - 1)][i - 1]); 
	}
	for (int i = 2; i < 1000005; i++)
		bit[i] = bit[i >> 1] + 1;
	for (int i = 1; i <= n; i++)
	{
		pre[i] = pre[i - 1]; 
		while (i - pre[i] > query_st(pre[i] + 1, i))
			pre[i]++; 
	}
	for (int i = 0; i < 4000005; i++)
		dp[i] = seg[i] = lazy[i] = data(-1, 0); 
	dp[0] = data(0, 1); 
	work(0, n); 
	if (dp[n].mx == -1)
		puts("-1");
	else
		printf("%d %d\n", dp[n].mx, dp[n].ans); 
	return 0; 
}

