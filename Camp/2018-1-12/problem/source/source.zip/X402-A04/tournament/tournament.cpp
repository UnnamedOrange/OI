#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=998244353;
const int N=100050;
ll qpow(ll a,ll n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int n,k;
int fac[N],m=0;
pii e[N<<1];
vector<int>G[N];
bool add=0,vis[N];
void dfs(int u,int d)
{
	if(add) return ;
	vis[u]=1;
	for(int i=0,siz=G[u].size();i<siz;++i)
	{
		int v=G[u][i];
		if(v==1&&d==n) {add=1;break;}
		if(vis[v]) continue;
		dfs(v,d+1);
	}
	vis[u]=0;
}

void wj()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read();k=read();
	fac[0]=1;
	for(i=1;i<=n;++i) fac[i]=1ll*fac[i-1]*i%mod;
	for(i=1;i<=n;++i) for(j=i+1;j<=n;++j) e[m]=pii(i,j),m++;
	int tot=1<<m,ans=0;
	for(int s=0;s<tot;++s)
	{
		for(i=1;i<=n;++i) G[i].clear();
		for(i=0;i<m;++i) 
		{
			if(s&(1<<i)) G[e[i].fi].pb(e[i].se);
			else G[e[i].se].pb(e[i].fi);
		}
		if(k==3)
		{
			bool can=0;
			for(i=1;i<=n;++i)
			{
				for(int i1=0,siz1=G[i].size();i1<siz1;++i1)
				{
					int v2=G[i][i1];
					for(int i2=0,siz2=G[v2].size();i2<siz2;++i2)
					{
						int v3=G[v2][i2];
						for(int i3=0,siz3=G[v3].size();i3<siz3;++i3)
							if(G[v3][i3]==i) {can=1;break;}
						if(can) break;
					}
					if(can) break;
				}
				if(can) break;
			}
			if(can) ans++;
		}
		else if(k==n)
		{
			for(i=1;i<=n;++i) vis[i]=0;
			add=0;
			dfs(1,1);
			if(add) ans++;
		}
	}
	printf("%d\n",ans);
	return 0;
}
