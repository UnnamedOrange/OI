#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int mod=998244353;
#define x first
#define y second
int n,k;
namespace bf{
	const int maxn=7;
	int a[maxn][maxn],vis[maxn],p[maxn];
	bool check(){
		REP(i,1,k-1)
			if(!a[p[i+1]][p[i]])
				return 0;
		if(!a[p[1]][p[k]]) return 0;
		return 1;
	}
	bool dfs(int step){
		if(!step){
			if(check()) return 1;
			return 0;
		}
		REP(i,1,n)
			if(!vis[i]){
				vis[i]=1;
				p[step]=i;
				if(dfs(step-1)) return 1;
				vis[i]=0;
			}
		return 0;
	}
	void work(){
		vector<pair<int,int> > vc;
		int tmp=0;
		REP(i,1,n)REP(j,i+1,n) vc.push_back(make_pair(i,j)),tmp++;
			int ans=0;
		REP(i,0,(1<<tmp)-1){
			memset(vis,0,sizeof(vis));
			pair<int,int> u;
			REP(j,0,tmp-1){
				u=vc[j];
				if((1<<j)&i) a[u.x][u.y]=1,a[u.y][u.x]=0;
				else a[u.x][u.y]=0,a[u.y][u.x]=1;
			}
			if(dfs(k)) ++ans;
			if(ans>mod) ans-=mod;
		}
		printf("%d\n",ans);
	}
};
int main(){
#ifndef ONLINE_JUDGE
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
#endif
	n=read(),k=read();
	if(k>n){
		printf("0\n");
		return 0;
	}
	if(n<=6) bf::work();
	return 0;
}
