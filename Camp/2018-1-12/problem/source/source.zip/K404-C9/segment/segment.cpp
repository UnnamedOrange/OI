#include<bits/stdc++.h>
#include<vector>
using namespace std;
int num[12003];
int l[15000],r[15000];
int cnto[15000];
int cntt[15000]; 
long long ans=0;
int n,m,k;
int cnt=1;
const int Mod=998244353;
long long dp[1700][41][41];
long long act[1700][41][41];
long long fpow(long long di,int top) { 
	long long ret=1;
	while(top!=0) { 
		if(top%2) ret*=di,ret%=Mod;
		top/=2;di*=di,di%=Mod;
	} 
	return ret;
} 

void getans() { 
	long long jcq=0;
	for(int i=1;i<=n;++i) { 
		cnto[i]+=(num[i]==1);
		cntt[i]+=(num[i]==2);
		jcq+=fpow(num[i],k);
		jcq%=Mod;
	} 
//	if(jcq!=0) { 
//		printf("%d : \n",cnt),++cnt;
//		for(int i=1;i<=m;++i) printf("%d %d  ",l[i],r[i]);
//		printf("\n\n");
//	} 
	ans+=jcq;
	ans%=Mod;
} 

void dfs(int nw,int lma,int rma) { 
	for(int i=lma+1;i<=(n-m+nw);++i) { 
		for(int j=max(rma+1,i);j<=(n-m+nw);++j) { 
			for(int kk=i;kk<j;++kk) num[kk]++;
			l[nw]=i,r[nw]=j;
			if(nw==m) getans();
			else dfs(nw+1,i,j);
			for(int kk=i;kk<j;++kk) num[kk]--;
		} 
	} 
} 
void spe1() { 	
	dp[0][0][0]=1;
	for(int T=0;T<=m;++T) { 
		for(int i=0;i<=n;++i) {  //now left
			for(int j=i;j<=n;++j) { //now right
				if(dp[T][i][j]==0) continue;
				for(int l=i+1;l<=n;++l) { //next left
					for(int r=max(j+1,l);r<=n;++r) { 
						dp[T+1][l][r]+=dp[T][i][j],dp[T+1][l][r]%=Mod;
						act[T+1][l][r]+=act[T][i][j];
						act[T+1][l][r]+=dp[T][i][j]*(r-l),act[T+1][l][r]%=Mod;
					} 
				} 
			} 
		} 
	} 
//	for(int T=1;T<=m;++T) { 
//		printf("%d : \n",T);
//		for(int i=1;i<=n;++i) {	
//			for(int j=i;j<=n;++j) { 
//				printf("%d %d %d\n",i,j,dp[T][i][j]);
//			} 
//		} 
//		printf("\n");
//	} 
	for(int i=1;i<=n;++i) { 
		for(int j=i;j<=n;++j) { 
			ans+=act[m][i][j];
		} 
	} 
	ans%=Mod;
} 

void spe3() { 
	ans+=fpow(n,3);
	ans-=fpow(n,1);
	if(ans<0) ans+=Mod;
	ans*=fpow(6,Mod-2);
	ans%=Mod;
} 

int main() { 
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&m,&n,&k);
	if(m>=n) { 
		printf("0");
		return 0;
	} 
	if(m==1) { 
		spe3();
		printf("%lld",ans);
		return 0;
	} 
	if(k==1000) {  
		spe1(),printf("%lld",ans);
		return 0;
	} 
	dfs(1,0,0);
	ans%=Mod;
	printf("%lld",ans);
	return 0;
} 
