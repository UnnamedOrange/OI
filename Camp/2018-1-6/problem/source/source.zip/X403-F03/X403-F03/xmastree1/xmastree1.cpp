#include<cstdio>
#include<iostream>
using namespace std;
int n,m,T,doe,num,ans;
int ch[5050],dfn[5050],b[5050],a[5050];
int pre[101010],son[101010],now[5050];
int br[5050];
void add(int x,int y)
{
	++doe;
	pre[doe]=now[x];
	now[x]=doe;
	son[doe]=y;
}
void dfs(int x,int fa)
{
	++num;
	dfn[x]=num;
	a[num]=b[x];
	ch[x]=1;
	int p=now[x];
	while (p)
	{
		int y=son[p];
		if (y!=fa)
		{
			dfs(y,x);
			ch[x]+=ch[y];
		}
		p=pre[p];
	}
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);

	scanf("%d%d%d",&n,&m,&T);
	for (int i=1;i<=n;++i)
		scanf("%d",&b[i]);
	int x,y;
	for (int i=1;i<n;++i)
	{
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	dfs(1,0);
	int l,r,t;
	for (int i=1;i<=m;++i)
	{
		scanf("%d",&t);
		if (t==1)
		{
			scanf("%d%d%d",&x,&l,&r);
			if (T==1)
				x^=ans,l^=ans,r^=ans;
			ans=0;
			y=dfn[x]+ch[x]-1;
			x=dfn[x];
			for (int j=x;j<=y;++j)
				if (a[j]>=l && a[j]<=r && br[a[j]]!=i)
				{
					++ans;
					br[a[j]]=i;
				}
			printf("%d\n",ans);
		}
		else
		{
			scanf("%d%d",&x,&y);
			if (T==1)
				x^=ans,y^=ans;
			a[dfn[x]]=y;
		}
	}
	return 0;
}
