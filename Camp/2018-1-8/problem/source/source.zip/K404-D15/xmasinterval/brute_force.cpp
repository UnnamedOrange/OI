#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 10005
const int mod=1000000009;

int n,m;
int a[maxn],l[maxn],r[maxn];
int f[maxn][maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

struct interval{
	int l,r;
	bool operator <(const interval &a)const{return l<a.l||(l==a.l&&r<a.r);}
}p[maxn];

int main(){
	n=read(),m=read();
	for (int i=1;i<=n;i++) p[i].l=read(),p[i].r=read();
	for (int i=1;i<=m;i++) a[i]=read();
	sort(a+1,a+m+1),sort(p+1,p+n+1);
	for (int i=1;i<=n;i++){
		l[i]=lower_bound(a+1,a+m+1,p[i].l)-a-1;
		r[i]=upper_bound(a+1,a+m+1,p[i].r)-a-1;
	}
	for (int i=0;i<=m;i++) f[0][i]=1;/*
									   for (int i=1;i<=n;i++) printf("%d %d %d %d\n",l[i],r[i],p[i].l,p[i].r);*/
	for (int i=1;i<=n;i++){
		f[i][0]=f[i-1][0];
		for (int j=1;j<=m;j++){
			f[i][j]=f[i-1][j]-f[i-1][j-1];
			f[i][j]<0?f[i][j]+=mod:0;
		}
		int x=l[i],y=r[i];
		int v=f[i-1][y]-(x?f[i-1][x-1]:0); v<0?v+=mod:0;
		f[i][y]+=v; f[i][y]>mod?f[i][y]-=mod:0;
		for (int j=y+1;j<=m;j++){
			f[i][j]<<=1;
			f[i][j]>mod?f[i][j]-=mod:0;
		}
		for (int j=1;j<=m;j++){
			f[i][j]+=f[i][j-1];
			f[i][j]>mod?f[i][j]-=mod:0;
		}
	}/*
	for (int i=1;i<=n;i++){
		printf("%d",f[i][0]);
		for (int j=1;j<=m;j++)
			printf(" %d",f[i][j]-f[i][j-1]);
		puts("");
		}*/
	printf("%d\n",(f[n][m]-f[n][m-1]+mod)%mod);
	return 0;
}
