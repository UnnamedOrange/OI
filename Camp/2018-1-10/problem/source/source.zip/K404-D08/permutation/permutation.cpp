#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
int a[20],n,ans,vis[20];
bool jud(int x){
	int t=0,y=a[x];
	while (y!=x) t^=1,y=a[y];
	return t;
}
bool judge(){
	rep(i,1,n) if (!jud(a[i])) return 0;
	return 1;
}
void dfs(int d){
	if (d==n+1){
		if (judge()) ++ans;
		return;
	}
	if (a[d]) return dfs(d+1);
	rep(i,1,n) if (!vis[i]){
		vis[i]=1;
		a[d]=i;
		dfs(d+1);
		vis[i]=0;
		a[d]=0;
	}
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	rep(i,1,n) scanf("%d",a+i),vis[a[i]]=1;
	dfs(1);
	printf("%d\n",ans);
	return 0;
}

