#include<bits/stdc++.h>
using namespace std;
#define N 1010
int t[N][N],n,num[N],y[N];
void dfs(int po,int type) {
	if(po==n+1) {
		num[type]++;
		return;
	}
	dfs(po+1,type);
	dfs(po+1,t[type][y[po]]);
}
int main() {
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int a,b;
	scanf("%d%d%d",&n,&a,&b);
	for(int i=1;i<=n;i++) {
		int x;
		scanf("%d",&x);
		int tmp=x%(a+b);
		if(tmp<a&&tmp<b) y[i]=4;
		if(tmp>=a&&tmp>=b) y[i]=3;
		if(tmp<a&&tmp>=b) y[i]=2;
		if(tmp>=a&&tmp<b) y[i]=1;
	}
	t[1][1]=t[1][3]=t[3][1]=t[1][4]=t[4][1]=1;
	t[2][2]=t[2][3]=t[3][2]=t[2][4]=t[4][2]=2;
	t[3][4]=t[4][3]=3;
	t[4][4]=t[3][3]=4;
	dfs(1,4);
	printf("%d %d %d %d",num[1],num[2],num[3],num[4]);
}
