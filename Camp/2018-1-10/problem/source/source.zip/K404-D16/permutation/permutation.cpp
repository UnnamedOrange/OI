#include <cstdio>
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
#define F(x,y,z) for (x=y;x<=z;++x)
using namespace std;
const int N=100001;
const int Mod=998244353;
int n,m,ans,now;
int d[N],a[N];
int h[N],fl,s[N],nows;
int q[N];

void Find(int x)
{
	if (h[x]) return;
	h[x]=++now;s[x]=nows;
	if (s[d[x]]==nows)
	{
		if ((h[x]-h[d[x]])%2==0) 
			fl=1;
	}
	Find(d[x]);
}

void check()
{
	fl=0;now=0;
	int i;
	F(i,1,n) h[i]=0;
	F(i,1,n) s[i]=0;
	F(i,1,n) nows=i,Find(i);
	if (!fl) 
	{
		++ans;
		//F(i,1,n) printf("%3d",d[i]);printf("\n");
	}
	
}

void work(int x)
{
	if (x==n+1)
	{
		check();
		return;
	}
	if (a[x])
	{
		d[x]=a[x];
		work(x+1);
		return;
	}
	int i;
	F(i,1,n)
		if (!q[i])
		{
			d[x]=i;q[i]=1;
			work(x+1);
			d[x]=0;q[i]=0;
		}
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int i,j,k;
	scanf("%d",&n);
	F(i,1,n) scanf("%d",&a[i]),q[a[i]]=1;
	if (n==8)
	{
		work(1);
		printf("%d\n",ans);
	}
	else
	{
		long long an=1;
		for (i=1;i<n;i+=2)
			an=(an*i)%Mod;
		printf("%lld\n",(an*an)%Mod);
	}
	return 0;
}

