#include<cstdio>
#include<vector>
#include<cstring>
#define LL long long
using namespace std;

struct lpl
{
	int left, right;
	vector<int> v;
}b[25];

const int mod = 1e9 + 7;
int n, m, x, ans;
int a[25];
bool flag[25];
LL inf;

inline void workk(LL t)
{
	for(int i = 1; i <= n; ++i)
	{
		a[i] = t & 1;
		t = t >> 1;
		if(a[i] == 1)
		{
			for(int j = b[i].v.size() - 1; j >= 0; --j)
			{
				flag[b[i].v[j]] = true;
			}
		}
	}
	int y;
	for(y = 1; y <= m; ++y)
	{
		if(flag[y] == false)	break;
	}
	if(y == m + 1)	ans++;
}

int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	scanf("%d%d", &n, &m); ans = 0;
	for(int i = 1; i <= n; ++i)
	{
		scanf("%d%d", &b[i].left, &b[i].right);
	}
	for(int i = 1; i <= m; ++i)
	{
		scanf("%d", &x);
		for(int j = 1; j <= n; ++j)
		{
			if(b[j].left <= x && x <= b[j].right)
			{
				b[j].v.push_back(i);
			}
		}
	}
	inf = 1 << n;
	for(LL i = 1; i <= inf; ++i)
	{
		memset(flag, false, sizeof(flag));
		workk(i);
	}
	printf("%d", ans);
	return 0;
}
