#include <cmath> 
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

#define LL long long

const int mod = 1000000007;
const int N1 = 1000000 + 1000;

LL s, t, n, m, ans = 0;
LL f[2][N1], pr[2][N1], f1[120][120];
int A[110];

namespace file{
	inline void open()
	{
		freopen("success.in", "r", stdin);
		freopen("success.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}
using namespace file;

namespace input{
	inline LL read()
	{
		LL a = 0;
		char ch;
		LL f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}
	
	inline void Get()
	{
		s = read(), t = read(), n = read(), m = read();
	}
}

namespace math{
	inline int ksm(LL a, LL b)
	{
		LL base = a, ret = 1;
		while(b > 0)
		{
			if(b & 1)
				ret = ret * base % mod;
			base = base * base % mod;
			b >>= 1;
		}
		return ret;
	}
}

namespace brute{
	inline void dfs(int x, LL rest)
	{
		if(rest == 0 && x != m + 1)
			return;
		if(x + rest < m + 1)
			return;
		if(x == m + 1)
		{
			/*for(int i = 1;i <= m;++i)
				printf("%d ", A[i] - 1);
			printf("\n");*/
			++ans;
			return;
		}
		
		LL up = rest;
		if(x <= n)
			up = min(up, t);
		for(int i = 1;i <= up;++i)
			A[x] = i, dfs(x + 1, rest -  i), A[x] = 0;
	}
	
	inline void solve()
	{
		dfs(1, s);
		printf("%lld\n", ans % mod);
	}
}

namespace method{
	inline void solve()
	{
		ans = 0, s -= m, --t;
		LL i = 1;
		f[0][0] = 1;
		for(LL u = 0;u <= s;++u)
			pr[0][u] = 1;
		for(LL u = 1;u <= m;++u)
		{
			for(LL j = 0;j <= s;++j)
			{
				f[i][j] = 0;
				pr[i][j] = 0;
				LL J = j;
				if(u <= n)
					J = min(J, t);
				f[i][j] = (f[i][j] + pr[i ^ 1][j]) % mod;
				if(j != J)
					f[i][j] = (f[i][j] - pr[i ^ 1][j - J - 1] + mod) % mod;
				pr[i][j] = (pr[i][j - 1] + f[i][j]) % mod;
				//printf("f[%lld][%lld]=%lld pr[%lld][%lld]=%lld\n", i, j, f[i][j], i, j, pr[i][j]);
			}
			i ^= 1;
		}
		printf("%lld\n", pr[i ^ 1][s]);
	}
}

namespace check{
	inline void deter()
	{
		if(s <= 10 && t <= 10 && n <= 10 && m <= 10)
			brute::solve();
		else if(s <= N1 && m <= N1)
			method::solve();
		else
			printf("%d\n", 19260817);
	}
}

int main()
{
	open();
	input::Get();
	check::deter();
	close();
	return 0;
} 
