#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <ctime>
#include <cstdlib>

using namespace std;
int main()
{
	freopen("bomb.in", "w", stdout);
	int n = 10000, m = 10000;
	cout<<n<<" "<<m<<endl; 
	srand(time(NULL));
	for(int i = 1; i <= m; i++) {
		int a = 0, b = 0;
		while(a == b) {
			a = rand() % n + 1;
			b = rand() % n + 1;
		}
		cout<<a<<" "<<b<<endl;
	}
}
