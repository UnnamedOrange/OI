#include <stdio.h>

#define CONTESTANT 

long long getMiniumDistance(int R, int C);
long long getDistance(int x, int y);
