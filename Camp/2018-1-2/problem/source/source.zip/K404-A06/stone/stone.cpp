#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <algorithm>
using namespace std;

const int mod = 1e9+7;

int n, a, b, x[100010], base = 1;

int main() {
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	scanf("%d%d%d", &n, &a, &b);
	for(int i = 1; i <= n; ++i)
		scanf("%d", x+i);
	sort(x+1, x+n+1);
	reverse(x+1, x+n+1);
	while(/*x[n] < min(a, b) && */n > 0) n--, base <<= 1, base %= mod;
	printf("%d %d %d %d\n", 0, 0, 0, base);
}
