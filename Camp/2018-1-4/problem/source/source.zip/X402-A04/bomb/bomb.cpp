#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
//#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1000050;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y) 
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
}
int n,m,scc=0,val[N],dfn[N],low[N],dfs_clk=0,stk[N],top=0,bel[N],f[N];
bool instk[N];
vector<int>G[N];

void tarjan(int u)
{
	dfn[u]=++dfs_clk; low[u]=dfn[u];
	instk[u]=1; stk[++top]=u;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(!dfn[v])
		{
			tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(instk[v]) low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		scc++;
		while(stk[top]!=u)
		{
			bel[stk[top]]=scc; instk[stk[top]]=0;
			val[scc]++; top--;
		}
		bel[stk[top]]=scc; instk[stk[top]]=0;
		val[scc]++; top--;
	}
}
int deg[N];
void rebuild()
{
	for(int u=1;u<=n;++u) for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(bel[u]!=bel[v]) G[bel[u]].pb(bel[v]),deg[bel[v]]++;
	}
}
int ans=0;
void topsort()
{
	top=0;
	for(int i=1;i<=scc;++i) if(!deg[i]) stk[++top]=i,f[i]=val[i];
	while(top)
	{
		int u=stk[top]; top--;
		ans=max(ans,f[u]);
		for(int i=0,siz=G[u].size();i<siz;++i)
		{
			int v=G[u][i];
			deg[v]--;
			f[v]=max(f[v],f[u]+val[v]);
			if(!deg[v]) stk[++top]=v;
		}
	}
}

void wj()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	//clock_t sta=clock();
	n=read(); m=read();
	for(i=1;i<=m;++i)
	{
		int x=read(),y=read();
		add(x,y);
		//e[++cnt]=(node){y,head[x]};head[x]=cnt;
	}
	for(i=1;i<=n;++i) if(!dfn[i]) tarjan(i);
	rebuild();
	topsort();
	printf("%d\n",ans);
	//clock_t fin=clock();
	//cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
	return 0;
}
