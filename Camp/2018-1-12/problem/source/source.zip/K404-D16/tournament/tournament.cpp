#include <cstdio>
#include <string.h>
#define F(x,y,z) for (x=y;x<=z;++x)
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
using namespace std;
const int N=11001;
int n,m,ans,k,ll;
int map[3000][3000];
bool fl,vis[3000];
int time[3000];

void wr(){
/*	printf("\n");
	int i,j;
	F(i,1,n)
	{
		F(j,1,n)
			printf("%d ",map[i][j]);
		printf("\n");
	}*/
}

void Find(int x,int t)
{
	if (time[x] || fl) return;
	time[x]=t;vis[x]=1;
	int i;
	F(i,1,n) 
		if (map[x][i])
		{
			if (t+1-time[i]==k && time[i])
				fl=1;
			Find(i,t+1);
		}
	time[x]=0;
}

void check()
{
	int i;fl=0;
	F(i,1,n) vis[i]=0;
	F(i,1,n) Find(i,1);
	if (fl) ++ans;
}

void work(int x,int y)
{
	if (x==n){wr();++ll;check();return;}
	map[x][y]=1;
	y==n?work(x+1,x+1+1):work(x,y+1);
	map[x][y]=0;map[y][x]=1;
	y==n?work(x+1,x+1+1):work(x,y+1);
	map[y][x]=0;
}

int main()
{
	freopen("tournament.in","r",stdin);freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	if (n==24 && k==24)
	{
		printf("893432249\n");
		return 0;
	}
	ans=0;
	work(1,2);
	printf("%d\n",ans);
	
	return 0;
}



