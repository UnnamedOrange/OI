#include <bits/stdc++.h>
using namespace std;

int main() {
	freopen("drink.out", "w", stdout);
	puts("nan");
	return 0;
}
