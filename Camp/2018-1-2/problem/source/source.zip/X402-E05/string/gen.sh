cas=1
while true; do
	./test || break
	./string ||break
	echo $cas
	cas=`expr $cas + 1`
done
