#include<bits/stdc++.h>
using namespace std;
#define N 1000010
const int mod=1000000007;
map<int,int> f[N];
int f1[N],t;
int dfsf(int n,int s) {
	if(n>s||n*t<s) return 0;
	if(n==1) return 1;
	int &tmp=f[n][s];
	if(tmp!=0) return tmp;
	for(int i=1;i<=t;i++) {
		tmp=(tmp+dfsf(n-1,s-i))%mod;
	}
	return tmp;
}
map<int,int> g[N];
int g1[N];
int dfsg(int n,int s) {
	if(n>s) return 0;
	if(n==1) return 1;
	int &tmp=g[n][s];
	if(tmp!=0) return tmp;
	for(int i=1;i<s;i++) {
		tmp=(tmp+dfsg(n-1,i))%mod;
	}
	return tmp;
}
int main() {
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	int s,n,m;
	scanf("%d%d%d%d",&s,&t,&n,&m);
	for(int i=1;i<=n*t;i++) f1[i]=dfsf(n,i);
	for(int i=1;i<=s;i++) g1[i]=(g1[i-1]+dfsg(m-n,i))%mod;
	int ans=0;
	for(int i=1;i<=n*t;i++) {
		ans=(unsigned long long)(ans+f1[i]*g1[s-i])%mod;
	}
	printf("%d",ans);
}
