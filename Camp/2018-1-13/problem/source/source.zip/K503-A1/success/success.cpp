#include<bits/stdc++.h>
using namespace std;
const int p=1000000007;
typedef long long ll;
ll s,t,n,m;
int f[500][500],f2[500][500],ans;
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	cin>>s>>t>>n>>m;
	f[0][0]=1;f2[0][0]=1;
	for (int i=0;i<=n;i++)
	for (int j=0;j<=s;j++)
	if (f[i][j])for (int k=1;k<=t;k++)
	f[i+1][j+k]=(f[i+1][j+k]+f[i][j])%p;
	for (int i=0;i<=m-n;i++)
	for (int j=0;j<=s;j++)
	if (f2[i][j])for (int k=1;k<=s;k++)
	f2[i+1][j+k]=(f2[i+1][j+k]+f2[i][j])%p;
	ans=0;
	for (int i=n;i<=s;i++)
	for (int j=m-n;i+j<=s;j++)
	ans=(ans+(ll)f[n][i]*f2[m-n][j]%p)%p;
	cout<<ans<<endl;
	return 0;
}
