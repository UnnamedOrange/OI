#include<bits/stdc++.h>
#define M 1000005
#define MO 1000000007
using namespace std;
inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar();
	return ret;
}

int ans,n,m,s,t,dp[M],su[M];

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	s=read(); t=read(); n=read(); m=read();
	if(s<m)
	{
		puts("0");
		return 0;
	}
	s-=m; for(int j=0; j<=s; ++j)su[j]=1;
	for(int i=1; i<=n; ++i)
	{ 
	    for(int j=1; j<=s; ++j)dp[j]=(su[j]+MO-(j>=t?su[j-t]:0))%MO;
	 	for(int j=1; j<=s; ++j)su[j]=(dp[j]+su[j-1])%MO;
	}
	if(n==m)
	{
		dp[0]=1;
		for(int i=0; i<=s; ++i) ans=(ans+dp[i])%MO;
	    printf("%d\n",ans);
		exit(0);  
	}
	for(int i=n+2; i<=m; ++i)
	for(int j=1; j<=s; ++j)su[j]=(su[j]+su[j-1])%MO; 
	for(int i=0; i<=s; ++i) ans=(ans+su[i])%MO;
	printf("%d\n",ans);  
}
