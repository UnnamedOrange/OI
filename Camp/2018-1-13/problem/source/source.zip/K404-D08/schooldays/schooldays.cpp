#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define per(a,b,c) for (int a=b;a>=c;a--)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=2010;
int n,low[N],up[N],siz[N];
struct dat{int mx,s;}f[N];
void upd(dat &x,dat y){
	if (x.mx<y.mx) x=y;
	else x.s+=y.s;
}
struct _st{
	int *a;
	int mn[15][N];
	void build(int *nw){
		a=nw;
		rep(i,1,n) mn[0][i]=a[i];
		for (int l=1;;l++){
			int mx=n-(1<<l)+1;
			if (mx<1) break;
			rep(i,1,mx) mn[l][i]=min(mn[l-1][i],mn[l-1][i+(1<<(l-1))]);
		}
	}
	int ask(int l,int r){
		int len=r-l+1;
		return min(mn[siz[len]][l],mn[siz[len]][r-(1<<siz[len])+1]);
	}
}stlow,stup;
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	rep(i,1,n) scanf("%d%d",low+i,up+i),low[i]=-low[i];
	rep(i,2,n) siz[i]=siz[i>>1]+1;
	stlow.build(low);
	stup.build(up);
	f[1].s=1;
	rep(i,1,n){
		dat tp=(dat){f[i].mx+1,f[i].s};
		rep(j,i,n){
			int len=j-i+1;
			if (len<-stlow.ask(i,j)) continue;
			if (len> stup .ask(i,j)) continue;
			upd(f[j+1],tp);
		}
	}
	if (f[n+1].mx==0) puts("-1"); else
	printf("%d %d\n",f[n+1].mx,f[n+1].s);
	return 0;
}

