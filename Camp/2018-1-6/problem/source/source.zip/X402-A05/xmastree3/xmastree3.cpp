#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>

#define calc_clock() std::cerr << 1.0*clock()/CLOCKS_PER_SEC << std::endl
typedef long long LL;
typedef std::pair<int, int> Pii;

const int N = 10;

int n, k, tot, fa[N], label[N];
int e = 1, Begin[N], Next[N << 1], to[N << 1];

void add_edge(int u, int v)
{
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

struct good_TREE
{
	int fa[N], label[N];
	bool operator == (const good_TREE& rhs)const
	{
		for(int i = 1; i <= n; ++i)
			if(fa[i] != rhs.fa[i] || label[i] != rhs.label[i])
				return false;
		return true;
	}
}P[int(5e6)], tmp;

bool vis[N << 1];
int finished, top, stk[N][N], len[N];

void dfs_pretreat(int Top, int u, int from)
{
	stk[Top][++len[Top]] = u;
	for(int i = Begin[u]; i; i = Next[i])
		if(!vis[i] && to[i] != from) 
			dfs_pretreat(Top, to[i], u);
}

void dfs(int u, int f, int dep)
{
	len[u] = 0; dfs_pretreat(u, u, 0);
	for(int i = 1; i <= len[u]; ++i){
		int v = stk[u][i];

		fa[v] = f; label[v] = dep;
		finished |= 1 << v;

		if(finished == (1<<(n+1))-2){
			finished ^= 1 << v;
			for(int j = 1; j <= n; ++j) 
				tmp.fa[j] = fa[j], tmp.label[j] = label[j];
			bool flag = 0;
			for(int j = 1; j <= tot; ++j) if(tmp == P[j]){
				flag = 1; break;
			}
		//	for(int j = 1; j <= n; ++j)
		//		printf("%d %d\n", tmp.fa[j], tmp.label[j]);
			if(!flag) P[++tot] = tmp;
			continue ;
		}

		for(int j = Begin[v]; j; j = Next[j]){
			if(vis[j]) continue; else vis[j] = vis[j^1] = 1;

			for(int d = 1; d <= k-dep; ++d) 
				dfs(to[j], v, dep + d);

			vis[j] = vis[j^1] = 0;
		}

		finished ^= 1 << v;
	}
}

void dfs()
{
	for(int dep = 1; dep <= k; ++dep) dfs(1, 0, dep);
	printf("%d\n", tot);
}

int main()
{
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);

	scanf("%d%d", &n, &k);
	for(int i = 1; i < n; ++i){
		int u, v; scanf("%d%d", &u, &v);
		add_edge(u, v); add_edge(v, u);
	}
	
	dfs();

	return 0;
}
