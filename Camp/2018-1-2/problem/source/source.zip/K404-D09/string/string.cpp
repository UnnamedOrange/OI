#include <cctype>
#include <cstdio>
#include <algorithm>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}


inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); isalpha(ch); ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

int len, f[105][105];
char str[105];

inline void init() {
	len = get_int();
	/*len = */get_str(str + 1);
}

inline bool check(int l, int r) {
	for(; r > l; ++l, --r) if(str[l] != str[r]) return true;
	return false;
}

inline bool checkRest(int l, int r, int il, int ir) {
	do {
		if(l == il) l = ir + 1;
		if(r == ir) r = il - 1;
		if(r <= l) return false;
		if(str[l] != str[r]) return true;
		++l, --r;
	} while(true);
}

inline void tense(int &a, int b) {
	a > b ? a = b : 0;
}

inline void solve() {
	for(int i = len - 1; i; --i)
		for(int j = i + 1; j <= len; ++j) {
			if(check(i, j)) {
				f[i][j] = 1;
				continue;
			}
			else f[i][j] = 0x3FFFFFFF;
			for(int k = i; k <= j; ++k)
				for(int l = k + 1; l <= j; ++l)
					if(checkRest(i, j, k, l))
						tense(f[i][j], f[k][l] + 1);
		}
	printf("%d\n", f[1][len] == 0x3FFFFFFF ? -1 : f[1][len]);
}

#define PROBLEM_NAME	"string"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	int T = get_int();
	while(T--) {
		init();
		solve();
	}
	return 0;
}
