#include <cstdio>
#include <queue>
#define Max(x,y) x>y?x:y
#define Min(x,y) x<y?x:y
#define la (x-1)&1
#define v d[j].b
#define F(x,y,z) for (x=y;x<=z;++x)
#define LL long long
using namespace std;
const int N=100100,M=200100,Mod=998244353;
int n,m,K,p[M],ans[N],st[N],ld,lll;
struct gsqq{
	int node,s;
	bool friend operator <(gsqq a,gsqq b)
	{return a.node>b.node;}
};
struct rode{
	int b,ne;
}d[M];
add(int x,int y){d[++ld].b=y;d[ld].ne=st[x];st[x]=ld;}
int f[2][N];
queue<int> que[2];
void yu(){
	int i,j;
	long long x,y;
	scanf("%d%d%d",&n,&m,&K);
	F(i,1,m){
		x=i;y=1;
		for (j=1;j<=K;j=j<<1)
		{
			if (j&K) y=(y*x)%Mod;
			x=(x*x)%Mod;
		}
		p[i]=y;
	}
}
void move(int x)
{
	int i,j;
	F(i,1,n) f[x&1][i]=0;
	while (!que[la].empty())
	{
		i=que[la].front();
		que[la].pop();
			for (j=st[i];j;j=d[j].ne)
			{
				if (!f[x&1][v]) que[x&1].push(v);
				f[x&1][v]=(f[x&1][v]+f[la][i])%Mod;
				ans[v]=(ans[v]+(LL)p[x]*f[la][i])%Mod;
			}
	}
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	yu();int i,j,x,y;gsqq e;
	F(i,1,m) scanf("%d%d",&x,&y),add(x,y);
	f[0][1]=1;que[0].push(1);
	F(i,1,m+2) move(i);
	F(i,1,n) printf("%d\n",ans[i]);
	return 0;
}
