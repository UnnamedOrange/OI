#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0*clock()/CLOCKS_PER_SEC << std::endl
#define fst first
#define snd second

typedef long long LL;
typedef std::pair<int, int> Pii;

#ifdef __linux__
#define getchar getchar_unlocked
#endif
template <typename T>
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int mod = 998244353;

int fpm(int x, int e)
{
	int res = 1;
	for(; e; e >>= 1){
		if(e & 1) res = (LL)res * x % mod;
		x = (LL)x * x % mod;
	}
	return res;
}

void add(int &a, int b)
{
	a += b;
	if(a >= mod) a -= mod;
}

const int N = 1e5 + 10;

int e, Begin[N], to[N << 1], Next[N << 1];

void add_edge(int u, int v)
{
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
	to[++e] = u, Next[e] = Begin[v], Begin[v] = e;
}

int dp[N];
int black, white;
int n; char s[N];

int size[N];

void dfs_DP(int u, int fa)
{
	for(int i = Begin[u]; i; i = Next[i]){
		int v = to[i];
		if(v == fa) continue;
		dfs_DP(v, u);
		++size[u];
	}

	if(!size[u]) dp[u] = 1;
	for(int i = Begin[u]; i; i = Next[i]){
		int v = to[i];
		if(v == fa) continue;
		add(dp[u], (LL)(dp[v]+1) * fpm(size[u], mod-2) % mod);
	}
}

bool Init()
{
	scanf("%d%s", &n, s + 1);

	int len = strlen(s + 1);
	for(int i = 1; i <= len; ++i){
		if(s[i] == '0') ++white;
		else ++black;
	}

	for(int i = 1; i < n; ++i){
		int u, v; read(u), read(v);
		add_edge(u, v);
	}

	return black == 0;
}

void pfer()
{
	dfs_DP(1, 0);
	printf("%d\n", dp[1]);
	return ;
}

int main()
{
	freopen("sad.in", "r", stdin);
	freopen("sad.out", "w", stdout);

	if(!Init()) printf("%d\n", black);
	else pfer();

	return 0;
}
