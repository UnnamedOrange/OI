#include <cstdio>
#include <algorithm>
#define F(x,y,z) for (x=y;x<=z;++x)
using namespace std;
const int N=1000100;
int Max(int x,int y){return x>y?x:y;}
int n,m,tot,now,ans;
int g[N],st[N],r[N],num[N],vis[N],h[N],w[N],f[N];
struct gsqq{
	int ne,b;
}d[N*8];
int R(){
	char c=getchar();
	while (!(c>='0' && c<='9')) c=getchar();
	int an=0;
	while (c>='0' && c<='9') an=an*10+c-'0',c=getchar();
	return an;
}
void add(int x,int y)
{
	++tot;
	d[tot].b=y;
	d[tot].ne=st[x];st[x]=tot;
}
void find(int x,int y)
{
	vis[x]=y;ans=Max(ans,y);h[x]=1;
	w[x]=1;
	int i;
	for (i=st[x];i;i=d[i].ne)
		if (vis[d[i].b]<y+1 && !w[d[i].b])
			find(d[i].b,y+1);
	w[x]=0;
}
int find2(int x,int fa)
{
	int i;
	if (f[x]) return f[x];
	f[x]=1;
	for (i=st[x];i;i=d[i].ne)
	 	if (d[i].b!=fa)
		f[x]=Max(f[x],find2(d[i].b,x)+1);
	ans=Max(ans,f[x]);
	return f[x];
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int i,j,k,x,y,z;
	scanf("%d%d",&n,&m);
	F(i,1,n)g[i]=i;
	F(i,1,m)
	{
		x=R();y=R();
		add(x,y);++r[y];
	}
	if (n>1000)
	{
		F(i,1,n) if (!r[i])find2(i,0);
		printf("%d\n",ans);
		return 0;
	}
	F(i,1,n) 
		if (!r[i]) 
		{
			F(j,1,n) vis[i]=0;
			now=i,find(i,1);
		}
	F(i,1,n) 
		if (!h[i]) 
		{
			F(j,1,n) vis[i]=0;
			now=i,find(i,1);
		}
	printf("%d\n",ans);
	return 0;
}
