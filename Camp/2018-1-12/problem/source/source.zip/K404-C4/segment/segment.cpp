#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	do
	{
		ch=getchar();
		if (ch=='-')
		{
			f=-f;
		}
	}while (ch<'0' || ch>'9');
	do
	{
		x=x*10+ch-'0';
		ch=getchar();
	}while (ch>='0' && ch<='9');
	return x*f;
}
const long long Mod=998244353;
int n,m,k;
long long ans;
long long pw(long long x,long long y)
{
	long long res=1;
	while (y)
	{
		if (y&1)
		{
			res=res*x%Mod;
		}
		y>>=1;
		x=x*x%Mod;
	}
	return res;
}
void solve1()
{
	for (int i=1;i<m;i++)
	{
		ans=(ans+i*(m-i)%Mod)%Mod;
	}
	printf("%lld\n",ans);
}
int l[100010],r[100010],cnt[100010];
void cal()
{
	/*
	for (int i=1;i<=n;i++)
	{
		cout<<l[i]<<" "<<r[i]<<endl;
	}
	puts("");
	*/
	long long s=0;
	for (int i=1;i<=m;i++)
	{
		s+=cnt[i];
		ans=(ans+pw(s,k))%Mod;
	}
}
void dfsr(int x,int now)
{
	if (now==n)
	{
		cal();
		return;
	}
	for (int i=max(x+1,l[now+1]);i<=m-n+now+1;i++)
	{
		r[now+1]=i;
		cnt[i]--;
		dfsr(i,now+1);
		cnt[i]++;
	}
}
void dfsl(int x,int now)
{
	if (now==n)
	{
		dfsr(0,0);
		return;
	}
	for (int i=x+1;i<=m-n+now+1;i++)
	{
		l[now+1]=i;
		cnt[i]++;
		dfsl(i,now+1);
		cnt[i]--;
	}
}
void solve2()
{
	ans=0;
	dfsl(0,0);
	printf("%lld\n",ans);
}
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if (n>=m)
	{
		puts("0");
		return 0;
	}
	if (n==1)
	{
		solve1();
		return 0;
	}
	if (n<=6)
	{
		solve2();
		return 0;
	}
	long long f1=0,f2=0;
	for (int l1=1;l1<m;l1++)
	{
		for (int r1=l1;r1<m;r1++)
		{
			for (int l2=l1+1;l2<=m;l2++)
			{
				if (l2>r1)
				{
					f1=(f1+(r1-l1)*(m-l2+1)%Mod)%Mod;
					f1=(f1+(m-l2)*(m-l2+1)/2%Mod)%Mod;
				}
				else
				{
					f2=(f2+(r1-l2)*(m-r1)%(Mod-1))%(Mod-1);
					f1=(f1+(l2-l1)*(m-r1)%Mod)%Mod;
					f1=(f1+(m-r1+1)*(m-r1)/2%Mod)%Mod;
				}
				//cout<<l1<<" "<<r1<<" "<<l2<<" "<<f1<<endl;
			}
		}
	}
	long long f=(f1+f2*pw(2,k)%Mod)%Mod;
	printf("%lld\n",f);
	return 0;
}
