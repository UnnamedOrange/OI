#include<cstdio>
using namespace std;
int main()
{
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	int t;
	scanf("%d", &t);
	return 0;
}
