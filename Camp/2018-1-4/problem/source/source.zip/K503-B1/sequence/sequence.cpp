#include<bits/stdc++.h>
using namespace std;
const int maxn=40;
int T,opt,n,l,r,a[maxn],ha[4000000],ans,anss,haa[maxn],getn[maxn];
int tot,b[maxn],t1;
int i,j,k;
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
int changed(int x,int y){
	int i,t1,t2;
	memset(haa,0,sizeof(haa));
	for (i=1;i<=n;i++){
		t1=(x%getn[n-i+1])/getn[n-i];
		t2=0;
		for (j=1;j<=n;j++){
			if (haa[j]==0) t2++;
			if (t2==t1+1){ b[i]=j; break; }
		}
		haa[b[i]]=1;
	}
	for (i=1;i<=y/2;i++) swap(b[i],b[y-i+1]);
	t2=0;
	memset(haa,0,sizeof(haa));
	for (i=1;i<=n;i++){
		t1=0;
		for (j=1;j<=b[i]-1;j++) if(haa[j]==0) t1=t1+1;
		t2=t2+t1*getn[n-i];
		haa[b[i]]=1;
	}
	return t2;
}
void work(int thi,int dep){
	if ((ha[thi]!=-1)&&(ha[thi]<=dep)) return;
	ha[thi]=dep;
	if ((dep>=2*n)||((ha[0]!=-1)&&(dep>ha[0]))) return;
	int i,nex;
	for (i=2;i<=n;i++){
		nex=changed(thi,i);
		work(nex,dep+1);
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	T=read();
	getn[0]=1; for (i=1;i<=10;i++) getn[i]=getn[i-1]*i;
	for (opt=1;opt<=T;opt++){
		n=read();
		tot=0;
		memset(haa,0,sizeof(haa));
		for (i=1;i<=n;i++){
			a[i]=read();
			t1=0;
			for (j=1;j<=a[i]-1;j++) if(haa[j]==0) t1=t1+1;
			tot=tot+t1*getn[n-i];
			haa[a[i]]=1;
		}
		anss=0;
		memset(ha,-1,sizeof(ha));
		work(tot,0);
		printf("%d\n",ha[anss]);
	}
	return 0;
}
