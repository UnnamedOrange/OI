#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

const int N=100005;
const int mod=1000000007;

int n;
int f1[N][18],f2[N][18],c[N],d[N],dp[N],lg[N],f[N],g[N];

void init(){
	int i,j;
	for (i=1;i<=n;i++) f1[i][0]=c[i];
	for (i=1;i<=n;i++) f2[i][0]=d[i];
	for (i=1;i<=17;i++){
		for (j=1;j+(1<<i)-1<=n;j++) f1[j][i]=max(f1[j][i-1],f1[j+(1<<i-1)][i-1]);
		for (j=1;j+(1<<i)-1<=n;j++) f2[j][i]=min(f2[j][i-1],f2[j+(1<<i-1)][i-1]);
	}
}

int rmqc(int l,int r){
	int d=lg[r-l+1];
	return max(f1[l][d],f1[r-(1<<d)+1][d]);
}

int rmqd(int l,int r){
	int d=lg[r-l+1];
	return min(f2[l][d],f2[r-(1<<d)+1][d]);
}

int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	int i,j;
	scanf("%d",&n);
	for (i=1;i<=n;i++) scanf("%d%d",&c[i],&d[i]);
	for (i=1;i<=n;i++) lg[i]=log2(i);
	init();
	memset(f,-1,sizeof(f));
	f[0]=0; g[0]=1;
	for (i=1;i<=n;i++){
		for (j=0;j<i;j++){
			if (f[j]==-1) continue;
			if (i-j>=rmqc(j+1,i)&&i-j<=rmqd(j+1,i)){
				if (f[i]<f[j]+1){
					f[i]=f[j]+1; g[i]=g[j];
				}
				else g[i]=(g[i]+g[j])%mod;
			}
		}
	}
	if (f[n]==-1) printf("%d\n",f[n]);
	else printf("%d %d\n",f[n],g[n]);
	return 0;
}
