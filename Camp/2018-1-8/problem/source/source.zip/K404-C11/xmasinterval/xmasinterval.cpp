#include <bits/stdc++.h>

namespace {

inline char read() {
    static const int IN_LEN = 1 << 18 | 1;
    static char buf[IN_LEN], *s, *t;
    return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
            s == t ? -1 : *s++;
}

template <typename T>
inline void read(T &x) {
    static char c;
    static bool iosig;
    for (c = read(), iosig = false; !isdigit(c); c = read()) {
        if (c == -1) return;
        iosig |= c == '-';
    }
    for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
    iosig && (x = -x);
}

inline int read(char *buf) {
    register int s = 0;
    register char c;
    while (c = read(), isspace(c) && c != -1)
        ;
    if (c == -1) {
        *buf = 0;
        return -1;
    }
    do
        buf[s++] = c;
    while (c = read(), !isspace(c) && c != -1);
    buf[s] = 0;
    return s;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
    (oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
    *oh++ = c;
}

template <typename T>
inline void print(T x) {
    static int buf[21], cnt;
    if (x != 0) {
        (x < 0) && (print('-'), x = -x);
        for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
        while (cnt) print((char)buf[cnt--]);
    } else {
        print('0');
    }
}

inline void print(const char *s) {
    for (; *s; s++) print(*s);
}

struct InputOutputStream {
    ~InputOutputStream() {
        fwrite(obuf, 1, oh - obuf, stdout);
    }

    template <typename T>
    inline InputOutputStream &operator>>(T &x) {
        read(x);
        return *this;
    }

    template <typename T>
    inline InputOutputStream &operator<<(const T &x) {
        print(x);
        return *this;
    }
} io;

const int MAXN = 500000 + 9;
const int MOD = 1000000009;

int n, m, a[MAXN], buc[MAXN];

struct Interval {
    int l, r;

    inline bool operator<(const Interval &p) const {
        return l < p.l || (l == p.l && r < p.r);
    }
} in[MAXN];

inline int add(const register int x) {
    return x >= MOD ? x - MOD : x;
} 

typedef unsigned long long ulong;

char *cur;

struct Node *null;

struct Node {
    static const int NODE_SIZE;
    Node *lc, *rc;
    int mul, sum;

    Node() : lc(null), rc(null), mul(1), sum() {}

    inline void cover(int mul) {
        if (this != null) {
            this->mul = (ulong)this->mul * mul % MOD;
            sum = (ulong)sum * mul % MOD;
        }
    }

    inline void pushDown() {
        if (mul != 1) {
            lc->cover(mul);
            rc->cover(mul);
            mul = 1;
        }
    }

    inline void *operator new(size_t) {
        return cur += NODE_SIZE;
    }

    inline void maintain() {
        sum = add(lc->sum + rc->sum);
    }
};

const int Node::NODE_SIZE = sizeof(Node);

char pool[4 * MAXN * Node::NODE_SIZE];

Node *root;

int cnt;

inline void build(Node *&p, int l, int r) {
    p = new Node();
    if (l == r) return;
    register int mid = (l + r) >> 1;
    build(p->lc, l, mid);
    build(p->rc, mid + 1, r);
}

inline void add(Node *p, int l, int r, int pos, int v) {
    if (l == r) {
        p->sum = add(p->sum + v);
        return;
    }
    p->pushDown();
    register int mid = (l + r) >> 1;
    pos <= mid ? add(p->lc, l, mid, pos, v) : add(p->rc, mid + 1, r, pos, v);
    p->maintain();
}

inline void modify(Node *p, int l, int r, int s, int t, int mul) {
    if (s <= l && t >= r) {
        p->cover(mul);
        return;
    }
    p->pushDown();
    register int mid = (l + r) >> 1;
    if (s <= mid) modify(p->lc, l, mid, s, t, mul);
    if (t > mid) modify(p->rc, mid + 1, r, s, t, mul);
    p->maintain();
}

inline int query(Node *p, int l, int r, int s, int t) {
    if (s <= l && t >= r) return p->sum;
    p->pushDown();
    register int mid = (l + r) >> 1;
    register int ret = 0;
    if (s <= mid) ret = add(ret + query(p->lc, l, mid, s, t));
    if (t > mid) ret = add(ret + query(p->rc, mid + 1, r, s, t));
    return ret;
}

inline void solve() {
    cur = pool;
    null = (Node *)pool;
    null->lc = null->rc = null;
    null->mul = 1;
    null->sum = 0;
    io >> n >> m;
    for (register int i = 0; i < n; i++)
        io >> in[i].l >> in[i].r;
    for (register int i = 0; i < m; i++)
        io >> a[i];
    memcpy(buc, a, sizeof(int) * (m));
    std::sort(buc, buc + m);
    cnt = std::unique(buc, buc + m) - buc;
    for (register int i = 0; i < n; i++) {
        in[i].l = std::lower_bound(buc, buc + cnt, in[i].l) - buc;
        in[i].r = std::upper_bound(buc, buc + cnt, in[i].r) - buc - 1;
    }
    std::sort(in, in + n);
    build(root, 0, cnt);
    add(root, 0, cnt, 0, 1);
    for (register int i = 0; i < n; i++) {
        if (in[i].l > in[i].r) {
            modify(root, 0, cnt, in[i].r + 1, cnt, 2);
            continue;
        }
        modify(root, 0, cnt, in[i].r + 1, cnt, 2);
        add(root, 0, cnt, in[i].r + 1, query(root, 0, cnt, in[i].l, in[i].r));
    }
    io << query(root, 0, cnt, cnt, cnt);
}

}

int main() {
    freopen("xmasinterval.in", "r", stdin);
    freopen("xmasinterval.out", "w", stdout);
    solve();
    return 0;
}