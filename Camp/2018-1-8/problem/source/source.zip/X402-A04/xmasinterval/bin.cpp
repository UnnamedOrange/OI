#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=1e9+9;
const int N=500050;
int f[N*3],b[N*3],tot=0,n,m,p[N],lef[N];
pii q[N];

inline int lower(int *a,int mxn,int x) //a:[1,mxn] lower_bound x
{
	int l=1,r=mxn;
	while(l<r)
	{
		int mid=l+r>>1;
		if(x<=a[mid]) r=mid;
		else l=mid+1;
	}
	return l;
}

int s[N*3];
inline void add(int x,int k)
{
	x++;
	for(int i=x;i<=tot+1;i+=(i&-i)) s[i]=(s[i]+k)%mod;
}
inline int ask(int l,int r)
{
	int ans=0; l++; r++;
	for(int i=r;i;i-=(i&-i)) ans=(ans+s[i])%mod;
	for(int i=l-1;i;i-=(i&-i)) ans=(ans-s[i]+mod)%mod;
	return ans;
}
bool cmp(pii c,pii d) {return c.se<d.se||(c.se==d.se&&c.fi<d.fi);}

void wj()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read(); m=read();
	for(i=1;i<=n;++i) 
	{
		q[i].fi=read(),q[i].se=read();
		b[++tot]=q[i].fi;b[++tot]=q[i].se;
	}
	for(i=1;i<=m;++i) p[i]=read(),b[++tot]=p[i];
	sort(b+1,b+1+tot);
	tot=unique(b+1,b+1+tot)-(b+1);
	for(i=1;i<=n;++i) q[i].fi=lower(b,tot,q[i].fi),q[i].se=lower(b,tot,q[i].se);
	for(i=1;i<=m;++i) p[i]=lower(b,tot,p[i]);

	sort(q+1,q+1+n); sort(p+1,p+1+m);
	f[0]=1; add(0,1);
	//for(i=1;i<=n;++i) lef[i]=p[lower(p,m,q[i].fi)-1];
	//for(i=1;i<=n;++i) cerr<<lef[i]<<' '<<q[i].fi<<' '<<q[i].se<<endl;
	//for(i=1;i<=m;++i) cerr<<p[i]<<endl;
	int now=0;
	for(i=1;i<=n;++i)
	{
		f[q[i].se]=ask(lef[i],tot);//q[i].se);
		add(q[i].se,f[q[i].se]);
		int las=now;
		while(q[now+1])
	}
	printf("%d\n",ask(p[m],tot));
	return 0;
}
