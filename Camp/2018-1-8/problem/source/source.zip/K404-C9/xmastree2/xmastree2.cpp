#include<bits/stdc++.h> 
#include<vector>
using namespace std; 
int n;
vector<int>ed[40];
int value[40];
int root[40];
int fa[1230];
int vis[1230];
int nowtim=1;
int ans=0;
int finans=0;
void gf(int k) { 
	for(int i=0;i<ed[k].size();++i) { 
		int tar=ed[k][i];
		if(fa[tar]!=0) continue;
		fa[tar]=k;
		gf(tar);
	} 
} 
void dfs(int k) { 
	if(k==n+1) { 
		finans=max(finans,ans);
		return;
	} 
	for(int i=1;i<=n;++i) { 
		if(vis[i]!=1&&(fa[i]==-1||vis[fa[i]]==1)) { 
			vis[i]=1;
			ans+=nowtim*value[i];
			nowtim++;
			dfs(k+1);
			vis[i]=0;
			nowtim--;
			ans-=nowtim*value[i];
		} 
	} 
} 

int main() { 
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	fa[0]=1;
	cin>>n;
	int a,b;
	for(int i=1;i<n;++i) { 
		scanf("%d%d",&a,&b);
		ed[a].push_back(b);
		ed[b].push_back(a);
	} 
	for(int i=1;i<=n;++i) { 
		scanf("%d%d",&value[i],&root[i]);
	} 
	for(int i=1;i<=n;++i) {
		if(root[i]==1) { 
			memset(fa,0,sizeof(fa));
			fa[i]=-1;
			gf(i);
			dfs(1);
		} 
	}
	printf("%d",finans);
} 
