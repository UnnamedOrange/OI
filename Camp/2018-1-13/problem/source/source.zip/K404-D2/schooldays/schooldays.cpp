#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
#define lid node<<1
#define rid node<<1|1
#define lch lid,l,mid
#define rch rid,mid+1,r
using namespace std;
const int mod=1e9+7;
const int N=1000010;
const int M=2100000;
//const int N=100;
const int INF=1e9;

int q[N],h,t;int g[N];
int c[N],d[N];
int n;


struct SEG{
	int mx[M];
	void update(int node){
		if(c[mx[lid]]>=c[mx[rid]])	mx[node]=mx[lid];
		else mx[node]=mx[rid];
	}
	void build(int node,int l,int r){
		int mid=l+r>>1;
		if(l==r)	{mx[node]=l;return;}
		build(lch);build(rch);
		update(node);
	}
	int query(int node,int l,int r,int fl,int fr){
		int mid=l+r>>1;
		if(fl<=l&&r<=fr)	return mx[node];
		if(mid>=fr)	return query(lch,fl,fr);
		else if(mid+1<=fl)	return query(rch,fl,fr);
		else{
			int t1,t2;
			t1=query(lch,fl,fr);t2=query(rch,fl,fr);
			if(c[t1]>=c[t2])	return t1;
			else return t2;
		}
	}
};SEG s;

struct data{
	int w,num;
	data(){}
	data(int w,int num):w(w),num(num){}
	data operator + (int x){return data(w+x,num);}
};
data f[N];data seg[M];data lazy[M];
data cur;

void update(data &x,data &y,data &z){
	if(y.w==z.w)	x=data(y.w,(y.num+z.num)%mod);
	else if(y.w>z.w)	x=y;
	else x=z;
}

void update(data &x,data &y){
	if(x.w==y.w)	x.num=(x.num+y.num)%mod;
	else if(x.w<y.w)	x=y;
}

void build(int node,int l,int r){
	int mid=l+r>>1;
	lazy[node]=data(-INF,0);
	if(l==r){seg[node]=f[l];return;}
	build(lch);build(rch);
}

void insert(int node,int l,int r,int x){
	int mid=l+r>>1;
	if(l>x||r<x)	return;
	update(cur,lazy[node]);
	if(l==r){update(f[x],cur);update(seg[node],f[x]);return;}
	insert(lch,x);insert(rch,x);
	update(seg[node],seg[lid],seg[rid]);
}

void query(int node,int l,int r,int fl,int fr){
	int mid=l+r>>1;
	if(l>fr||r<fl)	return;
	if(fl<=l&&r<=fr){update(cur,seg[node]);return;}
	query(lch,fl,fr);query(rch,fl,fr);
}

void cg(int node,int l,int r,int fl,int fr){
	int mid=l+r>>1;
	if(l>fr||r<fl)	return;
	if(fl<=l&&r<=fr)	{update(lazy[node],cur);return;}
	cg(lch,fl,fr);cg(rch,fl,fr);
}	

void solve(int l,int r){//l has been done
	int mid=l+1;data now;
	int i,L,R;int sp=mid-1;
	int start,end;
	if(l==r){cur=data(-INF,0);insert(1,0,n,l);return;}
	mid=s.query(1,1,n,l+1,r);
	//rep(i,l+1,r)	if(c[i]>c[mid])	mid=i;
	solve(l,mid-1);
	sp=upper_bound(g+mid,g+r+1,l+1)-g;
	start=max(mid,l+c[mid]);end=min(mid+c[mid]-1,r);
	now=data(-INF,0);
	if(start-c[mid]>l){
		cur=data(-INF,0);
		query(1,0,n,l,start-c[mid]-1);
		now=cur;
	}
	rep(i,start,min(end,sp-1)){
		update(now,f[i-c[mid]]);cur=now+1;
		update(f[i],cur);
	}
	if(end+1<=sp-1){
		cg(1,0,n,end+1,sp-1);
	}
	rep(i,sp,r){
		L=max(g[i]-1,l);R=min(i-c[mid],mid-1);
		if(L>mid-1)	break;
		if(R<L)	continue;
		cur=data(-INF,0);query(1,0,n,L,R);cur=cur+1;update(f[i],cur);
	}
	solve(mid,r);	
}

int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	int i;
	scanf("%d",&n);
	rep(i,1,n)	scanf("%d%d",&c[i],&d[i]);		
	g[1]=1;q[++t]=1;
	rep(i,2,n){
		g[i]=g[i-1];
		while(h<t&&d[q[t]]>=d[i])	t--;
		q[++t]=i;
		while(h<t&&d[q[h+1]]<(i-g[i]+1)){
			if(q[h+1]==g[i])	h++;
			g[i]++;
		}
	}
	f[0]=data(0,1);c[0]=-INF;
	rep(i,1,n)	f[i]=data(-INF,0);
	build(1,0,n);
	s.build(1,1,n);
	solve(0,n);
	//rep(i,1,n)	printf("f[%d]=(%d,%d)\n",i,f[i].w,f[i].num);
	//rep(i,1,n)	rep(j,1,n
	if(f[n].w>0)	printf("%d %d\n",f[n].w,f[n].num);
	else printf("-1\n");
}































