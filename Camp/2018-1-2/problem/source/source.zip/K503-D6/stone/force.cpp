#include <cctype>
#include <cstdio>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

int n,s,k[10],step[2],ans[4];

bool dfs(bool f)
{
    rep(i,0,n-1)
        if (((s>>i)&1) && k[i]>=step[f])
        {
            k[i]-=step[f];
            bool t=dfs(!f);
            k[i]+=step[f];
            if (!t)
                return 1;
        }
    return 0;
}

int main()
{
    freopen("stone.in","r",stdin);
    freopen("force.out","w",stdout);
    scanf("%d%d%d",&n,step,step+1);
    rep(i,0,n-1)
        scanf("%d",k+i);
    for (s=0; s<1<<n; ++s)
    {
        int t=dfs(0)<<1|dfs(1);
        ++ans[t];
//        printf("%d %d\n",s,t);
    }
    printf("%d %d %d %d",ans[2],ans[1],ans[3],ans[0]);
    return 0;
}
