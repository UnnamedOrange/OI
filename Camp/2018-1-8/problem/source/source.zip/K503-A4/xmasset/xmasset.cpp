#include <bits/stdc++.h>

int type, N;

void init() {
	//%%%__debug
}

int encode(int x, int y) {
	return x;
}

bool decode(int q, int h) {
	return q == h;
}

int main() {
	int T;
	scanf("%d%d%d", &type, &N, &T);
	init();
	while (T--) {
		int x, y;
		scanf("%d%d", &x, &y);
		if (type == 1)
			printf("%d\n", encode(x, y));
		else
			puts(decode(x, y) ? "yes" : "no");
	}
}
