#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 10010;
const int MAXM = 500010;
const ll MOD = 1000000009;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, x[MAXM];
int lf[MAXN], rf[MAXN];
struct Segment {
	int l, r;
	bool operator < (const Segment &rhs) const {
		return l < rhs.l || (l == rhs.l && r < rhs.r);
	}
}s[MAXN];
ll dp[2][MAXN], ans;

inline void update(ll &cur, ll val) {
	cur += val;
	if(cur >= MOD) cur -= MOD;
}

int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i, j;

	n = read(), m = read();

	for(i = 1; i <= n; i++) 
		s[i].l = read(), s[i].r = read();
	for(i = 1; i <= m; i++) x[i] = read();
	sort(x+1, x+m+1);
	sort(s+1, s+n+1);

	for(i = 1; i <= n; i++) {
		lf[i] = lower_bound(x+1, x+m+1, s[i].l)-x;
		rf[i] = upper_bound(x+1, x+m+1, s[i].r)-x-1;
		//printf("%d %d\n", lf[i], rf[i]);
	}
	dp[1][0] = dp[1][1] = 1;
	for(i = 1; i < n; i++) {
		bool cur = i & 1;
		for(j = 0; j <= i; j++) {
			if(rf[j] + 1 < lf[i+1]) continue;
			if(s[j].r > s[i+1].r) 
				update(dp[cur^1][j], dp[cur][j]);
			else 
				update(dp[cur^1][i+1], dp[cur][j]);
			update(dp[cur^1][j], dp[cur][j]);
		}
		for(j = 0; j <= i; j++) dp[cur][j] = 0;
	}
	for(j = 0; j <= n; j++) 
		if(s[j].r >= x[m]) update(ans, dp[n&1][j]);
	printf("%lld\n", ans);
	return 0;
}
