#include <cstdio>
#include <vector>
#include <cstring>
using namespace std;
#define U 1000000000LL
#define INF 1000000000000000000LL
#define N 550
struct lwn{
	int u,v;
	long long flow,cap;
} e[20050];
vector<int> g[N];
int d[N],num[N],cur[N],tot,n,p[N],W,m,q,i,a[N],w[N];
inline void link(int x,int y,long long z)
{
	e[tot].u=x;e[tot].v=y;e[tot].cap=z;e[tot].flow=0;
	g[x].push_back(tot++);
	e[tot].u=y;e[tot].v=x;e[tot].cap=0;e[tot].flow=0;
	g[y].push_back(tot++);
}
inline long long maxflow(int s,int t)
{
	memset(d,0,sizeof(d));
	memset(num,0,sizeof(num));
	memset(cur,0,sizeof(cur));
	int x=s;long long fl=0;num[0]=n+2;
	while (d[s]<n+2){
		if (x==t){
			long long jb=INF;
			while (x!=s){
				jb=min(jb,e[p[x]].cap-e[p[x]].flow);
				x=e[p[x]].u;
			}fl+=jb;x=t;
			while (x!=s){
				e[p[x]].flow+=jb;
				e[p[x]^1].flow-=jb;
				x=e[p[x]].u;
			}
		}bool zw=true;
		for (int ii=0;ii<g[x].size();ii++) if (e[g[x][ii]].cap>e[g[x][ii]].flow&&d[x]==d[e[g[x][ii]].v]+1){
			cur[x]=ii;p[e[g[x][ii]].v]=g[x][ii];x=e[g[x][ii]].v;zw=false;break;
		}if (zw){
			cur[x]=0;if (--num[d[x]]==0) return fl;d[x]=n+2;
			for (int ii=0;ii<g[x].size();ii++) if (e[g[x][ii]].cap>e[g[x][ii]].flow) d[x]=min(d[x],d[e[g[x][ii]].v]+1);
			num[d[x]]++;if (x!=s) x=e[p[x]].u;
		}
	}return fl;
}
int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int t;scanf("%d",&t);
	while (t--){
		scanf("%d%d%d%d",&n,&W,&m,&q);long long ans=-U*n-n;tot=0;
		for (i=1;i<=n+2;i++) g[i].clear();
		for (i=1;i<=n;i++) a[i]=1;
		while (m--){
			int x,y,z,A,B,C,D,E,F;
			scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&A,&B,&C,&D,&E,&F);
			a[x]+=D-F;a[y]+=E-D;a[z]+=F-E;
			link(x,y,A<<1);link(y,x,A<<1);
			link(y,z,B<<1);link(z,y,B<<1);
			link(z,x,C<<1);link(x,z,C<<1);
		}for (i=1;i<=n;i++) a[i]<<=1;
		while (q--){
			int x,y,z;scanf("%d%d%d",&x,&y,&z);
			if (z==0) link(y,x,INF);
			else if (z==1) link(x,y,INF),link(y,x,INF);
			else w[x]=-1,w[y]=1;
		}
		for (i=1;i<=n;i++){
			if (w[i]!=1) link(n+1,i,U+a[i]);
			if (w[i]!=-1) link(i,n+2,U);
			if (w[i]==1) ans+=U+a[i];
			else if (w[i]==-1) ans+=U;
		}printf("%lld\n",(ans+maxflow(n+1,n+2))*W);
	}
	return 0;
}
