#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define space putchar(' ')
#define enter putchar('\n')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

const int P = 1000000007;
ll n, m, s, t;

void solve1(){
	static ll f[105][105], g[105][105];
	f[0][0] = 1;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= s; j++)
			for(int k = 1; k <= min((int)t, j); k++)
				(f[i][j] += f[i - 1][j - k]) %= P;
	g[0][0] = 1;
	for(int i = 1; i <= m - n; i++)
		for(int j = 1; j <= s; j++)
			for(int k = 1; k <= j; k++)
				(g[i][j] += g[i - 1][j - k]) %= P;
	ll ans = 0, sum = 0;
	for(int i = n; i <= n * t; i++){
		(sum += f[n][i]) %= P;
		(ans += sum * g[m - n][s - i]) %= P;
	}
	write(ans), enter;
}

int main(){
	
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
	
	read(s), read(t), read(n), read(m);
	if(max(s, m) <= 100) solve1();
	
	return 0;
}
