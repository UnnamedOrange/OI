#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e5+10;
char str[maxn];
int dp[maxn];
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,j,k,m,n,T;
#ifndef ONLINE_JUDGE
	freopen("string.in","r",stdin);
	freopen("60pts.out","w",stdout);
#endif
	T=read();
	while(T--){
		n=read();
		scanf("%s",str+1);
		memset(dp,63,sizeof(dp));
		dp[0]=0;
		for(i=1;i<=n;i++)
			for(j=0;j<i;j++){
				int flag=0;
				for(k=j+1;k<=i;k++)
					if(str[k]!=str[i-k+j+1]){
						flag=1;
						break;
					}
				if(!flag)continue;
				dp[i]=min(dp[i],dp[j]+1);
			}
		printf("%d\n",dp[n]<=INF?dp[n]:-1);
	}
	return 0;
}
