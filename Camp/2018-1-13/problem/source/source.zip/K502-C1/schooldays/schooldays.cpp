#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>
using namespace std;

const int MAXN = 1e6 + 100, MOD = 1e9 + 7;
int n;
int l[MAXN], r[MAXN], g[MAXN];
long long f[MAXN];
bool legal[2100][2100];

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("schooldays.in", "r", stdin);
	freopen("schooldays.out", "w", stdout);
	n = read();
	for (int i = 1; i < n + 1; ++i)
	{
		l[i] = read();
		r[i] = read();
	}
	for (int i = 1; i < n + 1; ++i)
	{
		int small = r[i], big = l[i];
		for (int j = i; j < n + 1; ++j)
		{
			int len = j - i + 1;
			small = min(small, r[j]);
			big = max(big, l[j]);
			if (len <= small && len >= big)
				legal[i][j] = true;
		}
	}
	g[0] = 0;
	for (int i = 1; i < n + 1; ++i)
	{
		for (int j = i; j < n + 1; ++j)
		{
			if (legal[i][j])
				g[j] = max(g[j], g[i - 1] + 1);
		}
	}
	if (g[n] == 0)
	{
		printf("-1\n");
		return 0;
	}
	int sz = g[n];
	f[0] = 1;
	for (int i = 1; i < n + 1; ++i)
	{
		for (int j = 1; j < n + 1; ++j)
		{
			if (legal[i][j])
			{
				if (g[j] == g[i - 1] + 1)
					f[j] = (f[j] + f[i - 1]) % MOD;
			}
		}
	}
	printf("%d %lld\n", sz, f[n]);
	fclose(stdin);
	fclose(stdout);
}
