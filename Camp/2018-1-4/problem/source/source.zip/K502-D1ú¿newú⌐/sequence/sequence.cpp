#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;

const int MAXN = 4e5 + 10;
int n;
int t;
int fra[11];
int flag[MAXN];
int flag1[MAXN], flag2[MAXN];
struct status {
	int cnt[10];
	int step;
} s, front, temp;
void open()
{
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
}

queue<status> q;
queue<status> q1, q2;
void close()
{
	fclose(stdin);
	fclose(stdout);
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

int contor(int *a, int m)
{
	int num = 0;
	int b[10] = {0};
	for(int i = 1; i <= m; i++) {
		int k = 0;
		for(int j = 1; j < a[i]; j++) {
			if(b[j] == 0) {
				k++;
			}
		}
		num += k * fra[m - i];
		//cout<<num<<endl;
		b[a[i]] = 1;
	}
	return num;
}
                                                     
/*int DFS(int *cnt, int m)
{
	int num = contor(cnt, m);
	if(flag[num] != -1) {
		return flag[num];
	}
	int temp[11];
	for(int i = 1; i <= m; i++) {
		temp[i] = cnt[i];
	}
	for(int i = 2; i <= m; i++) {
		for()
	}
} */

void BFS()
{
	while(!q.empty()) {
		q.pop();
	}
	q.push(s);
	while(!q.empty()) {
		front = q.front();
		q.pop();
		int num = contor(front.cnt, n); 
		//cout<<num<<endl;
		/*for(int i = 1; i <= n; i++) {
			cout<<front.cnt[i];
		}
		cout<<endl;*/ 
		if(num == 0) {
			printf("%d\n", front.step);
			return;
		}
		temp = front;
		temp.step = front.step + 1;
		for(int i = 2; i <= n; i++) {
			for(int j = 1; j <= i; j++) {
				temp.cnt[j] = front.cnt[i - j + 1];
			}
			int com = contor(temp.cnt, n);
		//	cout<<com<<endl;
			if(!flag[com]) {
				q.push(temp);
				flag[com] = 1;
			}
		}
	}
}

void two ()
{
	while(!q1.empty()) {
		q1.pop();
	}
	while(!q2.empty()) {
		q2.pop();
	}
	q1.push(s);
	while(!q1.empty() && !q2.empty()) {
		front = q.front();
		q.pop();
		int num = contor(front.cnt, n); 
		//cout<<num<<endl;
		/*for(int i = 1; i <= n; i++) {
			cout<<front.cnt[i];
		}
		cout<<endl;*/ 
		if(num == 0) {
			printf("%d\n", front.step);
			return;
		}
		temp = front;
		temp.step = front.step + 1;
		for(int i = 2; i <= n; i++) {
			for(int j = 1; j <= i; j++) {
				temp.cnt[j] = front.cnt[i - j + 1];
			}
			int com = contor(temp.cnt, n);
		//	cout<<com<<endl;
			if(!flag[com]) {
				q.push(temp);
				flag[com] = 1;
			}
		}
	}
}
int main()
{
	open();
	fra[0] = 1;
	for(int i = 1; i <= 10; i++) {
		fra[i] = fra[i - 1] * i;
	}
	t = read();
	while(t--) {
		n = read();
		for(int i = 0; i <= fra[n]; i++) {
			flag[i] = 0;
		}
		s.step = 0;
		for(int i = 1; i <= n; i++) {
			s.cnt[i] = read();
		}
		flag[contor(s.cnt, n)] = 1;
		BFS();
	}
	close();
	return 0;
}
