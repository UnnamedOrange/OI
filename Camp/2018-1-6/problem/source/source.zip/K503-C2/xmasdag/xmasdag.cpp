#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define maxn 100010
#define modn 998244353
int head[maxn]={0},e[maxn*2][2],d[maxn]={0},q[maxn],f[5010][5010]={0},g[maxn],ans[maxn]={0},num[maxn],n,m,i,j,k,x,y,t=0;
bool mark[maxn]={0};
void addedge(int x,int y)
{
	e[++t][1]=y;
	e[t][0]=head[x];
	head[x]=t;
}
int power(int x,int y)
{
	long long i=x,s=1;
	for (;y>0;y=(y>>1))
	{
		if (y&1) s=(s*i)%modn;
		i=(i*i)%modn;
	}
	return s;
}
void sort()
{
	int l=0,r=0,i;
	q[0]=1;
	for (;l<=r;l++)
	{
		mark[q[l]]=false;
		for (i=head[q[l]];i>0;i=e[i][0])
			if (mark[e[i][1]])
			{
				d[e[i][1]]--;
				if (!d[e[i][1]]) q[++r]=e[i][1];
			}
	}
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (i=0;i<m;i++)
	{
		scanf("%d%d",&x,&y);
		addedge(x,y);
		d[y]++;
	}
	memset(mark,true,sizeof(mark));
	sort();
	if (k==1)
	{
		g[1]=1;
		for (i=0;i<n;i++)
			for (j=head[q[i]];j>0;j=e[j][0])
			{
				ans[e[j][1]]=((ans[e[j][1]]+ans[q[i]])%modn+g[q[i]])%modn;
				g[e[j][1]]=(g[e[j][1]]+g[q[i]])%modn;
			}
		for (i=1;i<=n;i++)
			printf("%d\n",ans[i]);
	}
	else
	{
		for (i=1;i<=n;i++)
			num[i]=power(i,k);
		f[1][0]=1;
		for (i=0;i<n;i++)
		{
			for (j=1;j<=n;j++)
				ans[q[i]]=(ans[q[i]]+(long long)f[q[i]][j]*(long long)num[j]%modn)%modn;
			for (j=head[q[i]];j>0;j=e[j][0])
				for (k=1;k<=n;k++)
					f[e[j][1]][k]=(f[e[j][1]][k]+f[q[i]][k-1])%modn;
		}
		for (i=1;i<=n;i++)
			printf("%d\n",ans[i]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
