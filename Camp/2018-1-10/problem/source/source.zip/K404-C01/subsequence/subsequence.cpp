//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=305;
typedef long long LL;
using namespace std;
int n,m,k,a[N],b[N],dp[N][N],nx1[N][N],nx2[N][N],ls[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
#endif
	read(n); read(m); read(k);
	for(int i=1;i<=n;i++) read(a[i]);
	for(int i=1;i<=m;i++) read(b[i]);
	for(int i=1;i<=k;i++) ls[i]=n+1;
	for(int i=n;i>=0;i--) {
		for(int j=1;j<=k;j++) 
			nx1[i][j]=ls[j];
		ls[a[i]]=i;
	}
	for(int i=1;i<=k;i++) ls[i]=m+1;
	for(int i=m;i>=0;i--) {
		for(int j=1;j<=k;j++) 
			nx2[i][j]=ls[j];
		ls[b[i]]=i;
	}
	memset(dp,-1,sizeof(dp));
	dp[0][0]=0;
	for(int l=1;;l++) {
		for(int i=0;i<=n+1;i++) if(dp[l-1][i]!=-1) {
			for(int j=1;j<=k;j++) {
				int x=i,y=dp[l-1][i];
				if(x!=n+1) x=nx1[x][j]; 
				if(y!=m+1) y=nx2[y][j];
				dp[l][x]=max(dp[l][x],y);
			}	
		}
		if(dp[l][n+1]==m+1) {
			printf("%d\n",l);
			break;
		}
	}
	return 0;
}
/*
11 11 3
1 2 3 2 1 3 1 2 2 1 3
1 3 2 1 2 3 1 2 1 2 3
*/
