#include <stdio.h>
#define maxn 1000010
#define modn 1000000007
int f[2][maxn]={0},s,t,n,m,i,j;
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	for (i=0;i<=s;i++)
		f[0][i]=1;
	for (i=1;i<=m;i++)
	{
		for (j=0;j<=s;j++)
			f[i&1][j]=0;
		for (j=1;j<=s;j++)
		{
			if (i<=n) f[i&1][j]=(f[(i&1)^1][j-1]-(j-t-1>=0 ? f[(i&1)^1][j-t-1] : 0)+modn)%modn;
				else f[i&1][j]=f[(i&1)^1][j-1];
			f[i&1][j]=(f[i&1][j]+f[i&1][j-1])%modn;
		}
	}
	printf("%d",f[m&1][s]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
