#include<bits/stdc++.h>
using namespace std;
int n,a[26],vis[1000000],viss[1000000],tot=0,ans;

int hash(int x[])
{
	long long o=1;
	for (int i=1;i<=n;i++) o=(o+x[i])*2333%999997;  
	return o;
}

int hashh(int x[])
{
	long long o=1;
	for (int i=1;i<=n;i++) o=(o+x[i])*321%728747;  
	return o;
}

void dfs(int x[])
{
	int p=hash(x),o=hashh(x);
	tot++;
	if (tot>=ans) 
	  {
	  	tot--;
	  	return;
	  }	
	if (vis[p]==2&&viss[o]==2)
	  {
	  	ans=tot,tot--;
	  	return;
	  }
	if (vis[p]==1&&viss[o]==1) 
	  {
	  	tot--;
		return;
	  }
    vis[p]=1,viss[o]=1;
	for (int i=1;i<=n-1;i++)
	  for (int j=n;j>i;j--)
	    {
	    	int m[26];
	    	for (int k=1;k<i;k++) m[k]=x[k];
	    	for (int k=j+1;k<=n;k++) m[k]=x[k];
	    	for (int k=i;k<=j;k++) m[k]=x[j-k+i];
	    	dfs(m);
		}
	vis[p]=0,viss[o]=0,tot--;
	return;	
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int t;
	scanf("%d",&t);
	for (int i=1;i<=t;i++)
	  {
	  	tot=0;
	  	int b[26];
	  	memset(b,0,sizeof(b)),memset(a,0,sizeof(a));
	  	scanf("%d",&n);
	  	ans=n;
	  	for (int j=1;j<=n;j++) scanf("%d",&a[j]),b[j]=a[j];
	  	sort(b+1,b+n+1);
	  	for (int j=1;j<=n;j++)
	  	  for (int k=1;k<=n;k++)
	  	    if (a[j]==b[k]) a[j]=k;  
		for (int j=1;j<=n;j++) b[j]=j;    
	  	vis[hash(b)]=2,viss[hashh(b)]=2;    
	  	dfs(a);    
	  	printf("%d\n",ans-1);
	  }
}
