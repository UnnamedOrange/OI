#include <bits/stdc++.h>
using namespace std ;
int main() {
	srand(time(0)) ;
	freopen ( "stone.in", "w", stdout ) ;
	int i, n, a, b, maxx = 1e9 ;
	for ( i = 1e8 ; i ; i -- ) ;
	n = 20 ;
	a = rand()%maxx+11 ;
	b = rand()%maxx+11 ;
	printf ( "%d %d %d\n", n, a, b ) ;
	maxx = 1e9 ;
	for ( i = 1 ; i <= n ; i ++ )
		printf ( "%d ", rand()%maxx ) ;
	return 0 ;
}
