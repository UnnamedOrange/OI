#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const ll md=998244353;
const int N=100009;
const int M=200009;
const int K=509;

int n,m,k,ind[N],q[N];
int to[M],nxt[M],beg[N],tot;
ll f[N][K],s[K][K],fac[K];

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
}

inline void chk(ll &a)
{
	if(a>=md)a-=md;
}

inline ll add(ll a,ll b)
{
	a+=b;if(a>=md)a-=md;
	return a;
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);

	n=read();m=read();k=read();
	for(int i=1,u,v;i<=m;i++)
	{
		u=read();v=read();
		add(u,v);ind[v]++;
	}

	s[0][0]=1;
	for(int i=1;i<=k;i++)
	{
		s[i][0]=0;
		s[i][i]=1;
		for(int j=1;j<i;j++)
			chk(s[i][j]+=add(s[i-1][j-1],j*s[i-1][j]%md));
	}
	fac[0]=1;
	for(ll i=1;i<=k;i++)
		fac[i]=fac[i-1]*i%md;

	memset(f,0,sizeof(f));
	int l=0,r=0;
	for(int i=1;i<=n;i++)
		if(!ind[i])
		{
			q[++r]=i;
			f[i][0]=1ll;
		}

	while(l<r)
	{
		int u=q[++l];
		ll *ff=f[u],*fff;
		for(int i=beg[u],v;i;i=nxt[i])
		{
			if(!(--ind[v=to[i]]))
				q[++r]=v;
			fff=f[v];
			chk(fff[0]+=ff[0]);
			for(int j=1;j<=k;j++)
				chk(fff[j]+=add(ff[j],ff[j-1]));
		}
	}

	ll *ss=s[k],*fff;
	for(int i=1;i<=n;i++)
	{
		ll ans=0;
		fff=f[i];
		for(int j=1;j<=k;j++)
			chk(ans+=fff[j]*ss[j]%md*fac[j]%md);
		printf("%lld\n",ans);
	}

	return 0;
}
