#include<bits/stdc++.h>
using namespace std;

const int maxn = 2e+5 + 10;

int n,m;
char a[maxn],b[maxn];
int len[maxn];

void read()
{
	int i;
	
	scanf("%d%s",&n,b);m=0;memset(len,0,sizeof(len));
	for(i=0;i<n;i++)
	{
		a[m++]='*';
		a[m++]=b[i];
	}
	a[m++]='*';
	//cout<<a<<endl;
}

void manacher()
{
	int i,r,p;
	
	len[0]=1;p=r=0;
	for(i=1;i<m;i++)
	{
		if(i<=r) len[i]=min(r-i+1,len[p*2-i]);
		//cout<<p<<' '<<r-i+1<<' '<<len[p*2-i]<<' ';
		while(i+len[i]<m && i-len[i]>=0 && a[i+len[i]]==a[i-len[i]]) len[i]++;
		if(i+len[i]-1>r) p=i,r=i+len[i]-1;
		//cout<<len[i];
	}//cout<<endl;
}

bool hw(int l,int r)
{
	return len[l+r+1]>r-l;
}
void solve()
{
	int i;
	
	for(i=0;i<n-1;i++) if(!hw(0,i)&&!hw(i+1,n-1)) {cout<<2<<endl;return;}
	cout<<-1<<endl;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	
	int qq;
	cin>>qq;
	while(qq--)
	{
		read();
		manacher();
		//cerr<<hw(0,n-1);
		if(!hw(0,n-1)) cout<<1<<endl;
		else solve();
	}
	
	
	return 0;
}
