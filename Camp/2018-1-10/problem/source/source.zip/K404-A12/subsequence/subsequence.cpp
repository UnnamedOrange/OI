#include <iostream>
#include <cstdio>
#include <cstring>
#define N 4005
using namespace std;
int nxta[N][N],nxtb[N][N],f[N][N],a[N],b[N],n,m,K;
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d",&b[i]);
	for(int i=1;i<=K;i++) nxta[n+1][i]=n+1,nxtb[m+1][i]=m+1;
	for(int i=n;i>=0;i--){
		for(int p=1;p<=K;p++) nxta[i][p]=nxta[i+1][p];
		nxta[i][a[i+1]]=i+1;
	}
	for(int i=m;i>=0;i--){
		for(int p=1;p<=K;p++) nxtb[i][p]=nxtb[i+1][p];
		nxtb[i][b[i+1]]=i+1;
	}
	memset(f,0x3f,sizeof(f));
	f[0][0]=0;
	int mn=max(n,m)+1;
	for(int i=0;i<=n+1;i++){
		for(int p=0;p<=m+1;p++){
			if(f[i][p]>=mn) continue;
			for(int j=1;j<=K;j++){
				f[nxta[i][j]][nxtb[p][j]]=min(f[nxta[i][j]][nxtb[p][j]],f[i][p]+1);
				if(nxta[i][j]==n+1&&nxtb[p][j]==m+1) mn=min(mn,f[i][p]+1);
			}
		}
	}
	printf("%d",f[n+1][m+1]);
	return 0;
}
