#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<string>
#include<cassert>
#include<ctime>
#include<map>
#include<set>
#include<cmath>
using namespace std;
namespace whatever{
	int readu(){
		char ch=getchar();
		while(ch<'0'||ch>'9')
			ch=getchar();
		int value=ch-'0';
		ch=getchar();
		while(ch>='0'&&ch<='9'){
			value=value*10+ch-'0';
			ch=getchar();
		}
		return value;
	}
	char readc(){
		char ch=getchar();
		while(ch==' '||ch=='\n')
			ch=getchar();
		return ch;
	}
	int optimal;
	bool any_ok;
	int n;
	int x[30];
	bool dfs(int sorted_until, int level){
		if(level>optimal)
			return false;
	//	for(int i=n-1;i!=sorted_until;--i)
	//		assert(x[i]==i+1);
		for(int i=sorted_until;i!=-1;--i)
			if(x[i]!=i+1)
				break;
			else{
	//			assert(sorted_until==i);
				--sorted_until;
			}
		if(sorted_until==-1){
			if(optimal>=level){
				optimal=level;
				if(!any_ok){
		//			for(int i=0;i<n;++i)
		//				cout<<x[i]<<' ';
		//			cout<<endl;
					any_ok=true;
					return true;
				}
			}
			assert(0);
			return false;
		}
	//	for(int first=sorted_until;first<=n;++first)
		for(int last=sorted_until;last!=-1;--last){
			reverse(x,x+last+1);
			bool ok=dfs(sorted_until,level+1);
			reverse(x,x+last+1);
			if(ok){
		//		for(int i=0;i<n;++i)
		//			cout<<x[i]<<' ';
		//		cout<<endl;
				return true;
			}
		}
		return false;
	}
	void solve(){
		n=readu();
		for(int i=0;i<n;++i)
			x[i]=readu();
		optimal=-1;
		any_ok=false;
		do{
			++optimal;
			dfs(n-1, 0);
	//		cout<<__LINE__<<endl;
		}while(!any_ok);
		printf("%d\n",optimal);
	}
	void run(){
		freopen("sequence.in","r",stdin);
		freopen("sequence.out","w",stdout);
		int t=readu();
		while(--t!=-1)
			solve();
	}
}

int main(){
	whatever::run();
}
