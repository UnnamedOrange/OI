#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10,mod=998244353;
int fac[maxn],ifac[maxn];
int p[maxn],a[maxn],b[maxn];
int ksm(int x,int y){
	int num=1;
	while(y){
		if(y&1) num=1ll*num*x%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return num;
}
int n;
bool vis[maxn];
int check(){
	REP(i,1,n) vis[i]=0;
	REP(i,1,n){
		if(vis[i]) continue;
		int j=i,num=0;
		while(!vis[j]) vis[j]=1,++num,j=b[j];
		if(num&1) return 0;
	}
	return 1;
}
vector<int> pos;
int main(){
#ifndef ONLINE_JUDGE
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
#endif
	n=read();
	REP(i,1,n) a[i]=read();
	if(n&1){
		printf("0\n");
		return 0;
	}
	int tmp=0,ans=0;
	REP(i,1,n) 
		if(a[i]) vis[a[i]]=1;
		else pos.push_back(i);
	REP(i,1,n) if(!vis[i]) p[++tmp]=i;
	if(tmp<=8){
		int Pw=1;
		REP(i,1,tmp) Pw*=i;
		REP(i,1,n) b[i]=a[i]; 
		while(Pw--){
			int num=0;
			REP(i,0,pos.size()-1) b[pos[i]]=p[++num];
			ans+=check();
			if(ans>mod) ans-=mod;
			next_permutation(p+1,p+tmp+1);
		}
		printf("%d\n",ans);
		return 0;
	}
	p[1]=fac[0]=1;
	REP(i,2,n)
		p[i]=(mod-1ll*(mod/i)*p[mod%i]%mod)%mod;
	REP(i,1,n) fac[i]=1ll*fac[i-1]*i%mod;
	ifac[n]=ksm(fac[n],mod-2);
	DREP(i,n-1,0) ifac[i]=1ll*ifac[i+1]*(i+1)%mod;
	printf("%lld\n",1ll*fac[tmp]*ifac[2]%mod*p[tmp-2]%mod);
	return 0;
}
