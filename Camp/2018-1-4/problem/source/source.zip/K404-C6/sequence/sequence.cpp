//#include <bits/stdc++.h>
#include <cstdio>
#include <iostream>
#include <cstring>
#include <map>

#define MP make_pair
#define PB push_back
#define FO(x) freopen(#x".in", "r", stdin), freopen(#x".out", "w", stdout)

using namespace std;
typedef long long LL;
typedef unsigned long long u64;

template <typename T> inline bool cmin(T & a, const T & b) { return a > b ? a = b, 1 : 0;}
template <typename T> inline bool cmax(T & a, const T & b) { return a < b ? a = b, 1 : 0;}
int read() {
	int x = 0, f = 1;char ch;
	for(ch = getchar(); !isdigit(ch); ch = getchar())
		if(ch == '-') f = -1;
	for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
	return x * f;
}

const int MaxN = 26, inf = 100;
int T, n, ans = inf, x[MaxN], y[MaxN], z[MaxN];

int CNT = 0;

inline int abs(int x) {
	return x > 0 ? x : -x;
}

#define eval(x) (x <= n ? (abs(y[x] - y[x - 1]) != 1) : 0)

int H_, p;
void dfs(int ls = 0) {
	if(p + H_ >= ans) return;
	if(!H_ && y[1] == 1) {
		cmin(ans, p);
		return;
	}
	for(int i = 2; i <= n; i++) {
		if(i != ls) {
			int t = H_;
			H_ -= eval(i + 1);
			int tt;
			for(int j = 1; j < i - j + 1; j++)
				tt = y[j], y[j] = y[i - j + 1], y[i - j + 1] = tt;
			H_ += eval(i + 1);
			++p; dfs(i); --p;
			for(int j = 1; j < i - j + 1; j++)
				tt = y[j], y[j] = y[i - j + 1], y[i - j + 1] = tt;
			H_ = t;
		}
	}
} 
int main() {
	int i;
	FO(sequence);
	T = read(); 
	while(T--) {
		n = read();
		ans = 2 * (n - 1);
		for(i = 1; i <= n; i++) x[i] = y[i] = read();
		H_ = p = 0;
		for(i = 2; i <= n; i++) H_ += (abs(y[i] - y[i - 1]) != 1);
		dfs();	
		cout << ans << endl;
	}
	return 0;
}
