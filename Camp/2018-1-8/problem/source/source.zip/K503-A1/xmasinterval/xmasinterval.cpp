#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int p=1000000009;
int n,m,a[500005],f[500005],two[500005],cnt[500005],las[500005];
struct node{int l,r;} b[500005];
bool cmp(node x,node y){return ((x.r<y.r)||((x.r==y.r)&&(x.l<y.l)));}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	two[0]=1;
	for (int i=1;i<=n;i++) two[i]=two[i-1]*2%p;
	for(int i=1;i<=n;i++) scanf("%d %d",&b[i].l,&b[i].r);
	for(int i=1;i<=m;i++) scanf("%d",a+i);
	sort(a+1,a+m+1);a[0]=0;
	for (int i=1;i<=m;i++)
	if (a[i]!=a[i-1]) a[++a[0]]=a[i];
	m=a[0];
	a[0]=-1;a[m+1]=1000000005;
	for (int i=1;i<=n;i++){
		int left=0,right=m+1,mid;
		while (left<right){
			mid=(left+right)>>1;
			if (a[mid]<b[i].l) left=mid+1;
			else right=mid;
		}
		b[i].l=left;
		left=0;right=m+1;
		while (left<right){
			mid=(left+right>>1);
			if (a[mid]<=b[i].r) left=mid+1;
			else right=mid;
		}
		b[i].r=left-1;
	}
	sort(b+1,b+n+1,cmp);
	for (int i=1;i<=n;i++) {cnt[b[i].r]++;las[i]=(b[i].r==b[i-1].r) ? las[i-1] : i-1;}
	for (int i=1;i<=m;i++) cnt[i]+=cnt[i-1];
	f[0]=1;
	for (int j=1;j<=n;j++){
		int t=1;
		for (int i=b[j].l-1;i<b[j].r;i++)
		{	
			while ((b[j+1].r==b[j].r)&&(b[j+1].l-1<=i)){j++;t++;}
			int l=b[j].l,r=b[j].r;
			f[r]=(f[r]+(ll)f[i]*two[cnt[r-1]-cnt[i]]%p*two[t-1]%p)%p;
		}
	}
	printf("%d\n",f[m]);
	return 0;
}
