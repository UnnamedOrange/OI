#include<iostream>
#include<cstdio>
#include<cstring>

FILE *ans,*out;

int main()
{
	ans=fopen("set.ans","r");
	out=fopen("set.out","r");

	int T;
	fscanf(ans,"%d",&T);

	int x;char y[4];

	for(int i=1;i<=T;i++)
	{
		fscanf(ans,"%d",&x);
		fscanf(out,"%s",y);
		if(x && y[0]=='n')
		{
			printf("fuck you @ %d\n",i);
			return 1;
		}
		else if(!x && y[0]=='y')
		{
			printf("fuck @ %d\n",i);
			return 1;
		}
	}
	printf("ok , good job\n");

	fclose(out);
	fclose(ans);

	return 0;
}
