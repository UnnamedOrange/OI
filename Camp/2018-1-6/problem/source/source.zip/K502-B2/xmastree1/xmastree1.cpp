#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<set>
using namespace std;
const int M=(int)1e5+5,MM=28000000;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
void Ps(int x){
	if(x==0)return;
	Ps(x/10);putchar(x%10^48);
}
void Pt(int x){
	if(x==0)putchar('0');
	else Ps(x);putchar('\n');
}
struct W{
	int to,nx;
}Lis[M*2];
int Head[M],tot;
void Add(int x,int y){
	Lis[++tot]=(W){y,Head[x]};
	Head[x]=tot;
}
int n,q,tp;
int c[M];
int L[M],R[M],dfs_cnt,dui[M];
void dfs(int x,int f){
	dui[L[x]=++dfs_cnt]=x;
	for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
		if(to!=f)
			dfs(to,x);
	R[x]=dfs_cnt;
}
struct SHUI{
	int v[5005];
	void solve(){
		int lasans=0;
		for(int i=1,op,l,r,x;i<=q;i++){
			Rd(op);
			if(op==1){
				Rd(x),Rd(l),Rd(r);
				if(tp)x^=lasans,l^=lasans,r^=lasans;
				lasans=0;
				for(int j=L[x],w;j<=R[x];j++){
					w=dui[j];
					if(c[w]>=l&&c[w]<=r&&v[c[w]]!=i)lasans++,v[c[w]]=i;
				}
				printf("%d\n",lasans);
			}else {
				Rd(x),Rd(l);
				c[x]=l;
			}
		}
	}
}P20;
int OP[M],XX[M],LL[M],RR[M];
int Rt[M],Lson[MM],Rson[MM],val[MM],TTT;
int ls[M];
struct UHIS{
	void update_in(int L,int R,int &p,int x,int v){
		if(p==0)p=++TTT;
		val[p]+=v;
		if(L==R)return;
		int mid=(L+R)>>1;
		if(mid>=x)update_in(L,mid,Lson[p],x,v);
		else update_in(mid+1,R,Rson[p],x,v);
	}
	void update_out(int L,int R,int &p,int x,int y,int v){
		if(p==0)p=++TTT;
		update_in(1,n,val[p],y,v);
		if(L==R)return;
		int mid=(L+R)>>1;
		if(mid>=x)update_out(L,mid,Lson[p],x,y,v);
		else update_out(mid+1,R,Rson[p],x,y,v);
	}
	int query_in(int L,int R,int p,int l,int r){
		if(L==l&&R==r)return val[p];
		int mid=(L+R)>>1;
		if(mid>=r)return query_in(L,mid,Lson[p],l,r);
		else if(mid<l)return query_in(mid+1,R,Rson[p],l,r);
		else return query_in(L,mid,Lson[p],l,mid)+query_in(mid+1,R,Rson[p],mid+1,r);
	}
	int query_out(int L,int R,int p,int l,int r,int ll,int rr){
		if(L==l&&R==r)return query_in(1,n,val[p],ll,rr);
		int mid=(L+R)>>1;
		if(mid>=r)return query_out(L,mid,Lson[p],l,r,ll,rr);
		else if(mid<l)return query_out(mid+1,R,Rson[p],l,r,ll,rr);
		else return query_out(L,mid,Lson[p],l,mid,ll,rr)+query_out(mid+1,R,Rson[p],mid+1,r,ll,rr);
	}
	void solve(){
		for(int i=1,w;i<=n;i++){
			Rt[i]=Rt[i-1];
			w=dui[i];
			if(ls[c[w]]!=0){
				update_out(1,n,Rt[i],c[w],ls[c[w]],-1);
			}
			update_out(1,n,Rt[i],c[w],i,1);
			ls[c[w]]=i;
		}
		int lasans=0;
		for(int i=1,w;i<=q;i++){
			if(tp)XX[i]^=lasans,LL[i]^=lasans,RR[i]^=lasans;
			w=XX[i];
			Pt(lasans=query_out(1,n,Rt[R[w]],LL[i],RR[i],L[w],R[w]));
		}
	}
}P20_1;
struct IHSU{
	int cntson[M],Mxson[M],de[M];
	int tp[M],fa[M];
	void dfs(int x,int f,int d){
		de[x]=d;
		fa[x]=f;
		cntson[x]=1;
		int p=0;
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(to!=f){
				dfs(to,x,d+1);
				cntson[x]+=cntson[to];
				if(cntson[to]>p)p=cntson[to],Mxson[x]=to;
			}
	}
	void rdfs(int x,int f,int gf){
		tp[x]=gf;
		dui[L[x]=++dfs_cnt]=x;
		if(Mxson[x])rdfs(Mxson[x],x,gf);
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(to!=f&&to!=Mxson[x])
				rdfs(to,x,to);
		R[x]=dfs_cnt;
	}
	set<int>st[M];
	int Rt[M*4];
	void update_in(int L,int R,int &p,int x,int v){
		if(p==0)p=++TTT;
		val[p]+=v;
		if(L==R)return;
		int mid=(L+R)>>1;
		if(mid>=x)update_in(L,mid,Lson[p],x,v);
		else update_in(mid+1,R,Rson[p],x,v);
	}
	void update_out(int L,int R,int p,int l,int r,int x,int v){
		if(L==l&&R==r){
			update_in(1,n,Rt[p],x,v);
			return;
		}int mid=(L+R)>>1;
		if(mid>=r)update_out(L,mid,p<<1,l,r,x,v);
		else if(mid<l)update_out(mid+1,R,p<<1|1,l,r,x,v);
		else update_out(L,mid,p<<1,l,mid,x,v),update_out(mid+1,R,p<<1|1,mid+1,r,x,v);
	}
	void UP(int x,int c,int v){
		while(tp[x]!=1){
			update_out(1,n,1,L[tp[x]],L[x],c,v);
			x=fa[tp[x]];
		}
		update_out(1,n,1,L[tp[x]],L[x],c,v);
	}
	int LCA(int x,int y){
		while(tp[x]!=tp[y]){
			if(de[tp[x]]<de[tp[y]])swap(x,y);
			x=fa[tp[x]];
		}
		if(de[x]>de[y])return y;
		return x;
	}
	set<int>::iterator it,it1,it2;
	int query_in(int L,int R,int p,int l,int r){
		if(L==l&&R==r)return val[p];
		int mid=(L+R)>>1;
		if(mid>=r)return query_in(L,mid,Lson[p],l,r);
		else if(mid<l)return query_in(mid+1,R,Rson[p],l,r);
		else return query_in(L,mid,Lson[p],l,mid)+query_in(mid+1,R,Rson[p],mid+1,r);
	}
	int query(int L,int R,int p,int x,int l,int r){
		int re=query_in(1,n,Rt[p],l,r);
		if(L==R)return re;
		int mid=(L+R)>>1;
		if(mid>=x)return re+query(L,mid,p<<1,x,l,r);
		else return re+query(mid+1,R,p<<1|1,x,l,r);
	}
	void solve(){
		dfs(1,1,0);
		dfs_cnt=0;
		rdfs(1,1,1);
		for(int i=1,w,fr,lca;i<=n;i++){
			w=dui[i];
			if((int)st[c[w]].size()){
				fr=(*--st[c[w]].end());
				lca=LCA(fr,w);
				UP(lca,c[w],-1);
			}
			st[c[w]].insert(i);
			UP(w,c[w],1);
		}
		int lasans=0;
		for(int i=1,w,fr,nx,lca;i<=q;i++){
			if(OP[i]==1){
				if(tp)XX[i]^=lasans,LL[i]^=lasans,RR[i]^=lasans;
				printf("%d\n",lasans=query(1,n,1,L[XX[i]],LL[i],RR[i]));
			}else {
				w=L[XX[i]];
				it1=it2=it=st[c[XX[i]]].find(w);
				fr=nx=-1;
				UP(XX[i],c[XX[i]],-1);
				if(it1!=st[c[XX[i]]].begin()){
					it1--;
					fr=(*it1);
					lca=LCA(XX[i],dui[fr]);
					UP(lca,c[XX[i]],1);
				}
				it2++;
				if(it2!=st[c[XX[i]]].end()){
					nx=(*it2);
					lca=LCA(XX[i],dui[nx]);
					UP(lca,c[XX[i]],1);
				}
				if(fr!=-1&&nx!=-1){
					lca=LCA(dui[fr],dui[nx]);
					UP(lca,c[XX[i]],-1);
				}
				st[c[XX[i]]].erase(it);
				st[LL[i]].insert(w);
				it1=it2=it=st[LL[i]].find(w);
				fr=nx=-1;
				c[XX[i]]=LL[i];
				UP(XX[i],LL[i],1);
				if(it1!=st[LL[i]].begin()){
					it1--;
					fr=(*it1);
					lca=LCA(dui[fr],XX[i]);
					UP(lca,LL[i],-1);
				}
				it2++;
				if(it2!=st[LL[i]].end()){
					nx=(*it2);
					lca=LCA(dui[nx],XX[i]);
					UP(lca,LL[i],-1);
				}
				if(fr!=-1&&nx!=-1){
					lca=LCA(dui[fr],dui[nx]);
					UP(lca,LL[i],1);
				}
			}
		}
	}
}PPP;
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	Rd(n),Rd(q),Rd(tp);
	for(int i=1;i<=n;i++)Rd(c[i]);
	for(int i=1,x,y;i<n;i++)Rd(x),Rd(y),Add(x,y),Add(y,x);
	dfs(1,1);
//	if(0);
	if(n<=5000&&q<=5000)P20.solve();
	else {
		bool is_nc=true;
		for(int i=1;i<=q;i++){
			Rd(OP[i]);
			if(OP[i]==1){
				Rd(XX[i]),Rd(LL[i]),Rd(RR[i]);
			}else {
				Rd(XX[i]),Rd(LL[i]);
				is_nc=false;
			}
		}
		if(is_nc)P20_1.solve();
		else PPP.solve();
	}
	return 0;
}
