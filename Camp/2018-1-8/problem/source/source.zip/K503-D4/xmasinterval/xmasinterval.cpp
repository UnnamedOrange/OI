#include<bits/stdc++.h>
#define maxn 30
using namespace std;
int l[maxn], r[maxn], x[maxn], zt[maxn], ch[maxn], ans, n, m;
void work(int dep, int cur)
{
	if (dep > n)
	{
		if (cur == (1 << m) - 1) ans++;
	}
	else
	for (int i = 0; i <= 1; i++)
	{
		ch[dep] = i;
		if (i == 0) work(dep + 1, cur);
		else work(dep + 1, cur | zt[dep]);
	}
}
int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		scanf("%d%d", &l[i], &r[i]);
	for (int i = 1; i <= m; i++)
		scanf("%d", &x[i]);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			if (x[j] >= l[i] && x[j] <= r[i])
				zt[i] |= 1 << j - 1;
	work(1, 0);
	printf("%d\n", ans);
	return 0;
}
