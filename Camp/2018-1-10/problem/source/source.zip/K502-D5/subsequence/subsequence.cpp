#include<bits/stdc++.h>
using namespace std;

const int maxn = 4000 + 10;
const int INF = 0x3fffffff;

int n,m,k,mx,a[maxn],b[maxn];
int ax[maxn][maxn],bx[maxn][maxn];//,mda[maxn],mdb[maxn];
bool vis[maxn][maxn];

void read()
{
	int i;
	
	scanf("%d%d%d",&n,&m,&k);mx=max(n,m)+1;
	
	for(i=1;i<=n;i++) scanf("%d",a+i);
	for(i=1;i<=m;i++) scanf("%d",b+i);
}

void pre()
{
	int i,j;
	
	for(i=1;i<=k;i++) ax[n][i]=bx[m][i]=ax[mx][i]=bx[mx][i]=mx;
	//mda[mx]=mdb[mx]=0;mda[n]=mdb[m]=1;
	
	for(i=n-1;i>=0;i--)
	{
		//mda[i]=INF;
		for(j=1;j<=k;j++) ax[i][j]=(a[i+1]==j?i+1:ax[i+1][j]);//,mda[i]=min(mda[i],mda[ax[i][j]]+1);
	}
	for(i=m-1;i>=0;i--)
	{
		//mdb[i]=INF;
		for(j=1;j<=k;j++) bx[i][j]=(b[i+1]==j?i+1:bx[i+1][j]);//,mdb[i]=min(mdb[i],mdb[bx[i][j]]+1);
	}
}

struct dp{
	int x,y,f;
};

void bfs()
{
	dp u;int i;
	queue<dp> q;
	q.push((dp){0,0,0});vis[0][0]=true;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(i=1;i<=k;i++)
		{
			int tx=ax[u.x][i],ty=bx[u.y][i];
			if(tx==mx && ty==mx) {cout<<u.f+1;exit(0);}
			if(!vis[tx][ty]) q.push((dp){tx,ty,u.f+1});
		}
	}
}

int main()
{
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	
	read();
	pre();
	bfs();
	
	return 0;
}
