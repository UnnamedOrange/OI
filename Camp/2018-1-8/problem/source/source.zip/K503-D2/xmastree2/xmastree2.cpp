#include<bits/stdc++.h>
using namespace std;
struct Info {
	int nu,ne;
}a[101];
int b[230],x,y,n,nu=0,f[50],faa[50],q[50],g[50],w[50],ansn=0;
void jb(int x,int y){
	a[++nu].nu=y;a[nu].ne=b[x];b[x]=nu;
}
void dfs(int x,int fa){
	faa[x]=fa;
	for (int y=b[x];y;y=a[y].ne) if (a[y].nu!=fa) dfs(a[y].nu,x);
}
void woek(int dep){
	if (dep>n){
		int sum=0;
		for (int i=1;i<=n;i++){
			if (f[i]==1)if (g[i]==0) return ;else dfs(i,0);
		}
		for (int i=1;i<=n;i++)
			if (f[i]!=1) if (f[i]<f[faa[i]]) return ;
		for (int i=1;i<=n;i++) sum+=f[i]*w[i];
		ansn=max(ansn,sum);
	}else{
		for (int i=1;i<=n;i++){
			if (f[i]==0){
				f[i]=dep;
				woek(dep+1);
				f[i]=0;
			}
		}
	}
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	cin>>n;
	for (int i=1;i<n;i++){
		scanf("%d %d",&x,&y);
		jb(x,y);jb(y,x);
	}
	for(int i=1;i<=n;i++)scanf("%d %d",&w[i],&g[i]);
	woek(1);
	cout<<ansn<<endl;
	return 0;
}

