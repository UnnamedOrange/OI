#include <bits/stdc++.h>

namespace {

const int MAXM = 6;
const int MOD = 998244353;
int m, n, k;

typedef unsigned long long ulong;

std::vector<int> end;
int a[MAXM], ans;

inline int add(const int x) { return x >= MOD ? x - MOD : x; }

inline int modPow(register int a, register int b) {
    register int ret = 1;
    for (; b; b >>= 1, a = (ulong)a * a % MOD)
        if (b & 1) ret = (ulong)ret * a % MOD;
    return ret;
}

void dfs(int i) {
    if (i > n) {
        for (register int t = 1; t <= m; t++) ans = add(ans + modPow(a[t], k));
        return;
    }
    for (register int l = end.back() + 1; i <= m; i++) {
        for (register int r = l; r <= m; r++) {
            for (register int t = l; t < r; t++) a[t]++;
            end.push_back(r);
            dfs(i + 1);
            end.pop_back();
            for (register int t = l; t < r; t++) a[t]--;
        }
    }
}

int f[2][41][41], g[2][41][41];

inline void solve() {
    std::cin >> n >> m >> k;
    if (n > m) {
        std::cout << "0";
        return;
    }
    if (n == 1) {
        for (register int l = 1; l <= m; l++) {
            for (register int r = l; r <= m; r++) {
                ans = add(ans + r - l);
            }
        }
        std::cout << ans;
        return;
    } else if (n == 2) {
        for (register int l = 1; l <= m; l++) {
            for (register int r = l; r <= m; r++) {
                for (register int l1 = l + 1; l1 <= m; l1++) {
                    for (register int r1 = std::max(l1, r + 1); r1 <= m; r1++) {
                        if (l1 < r) {
                            ans = add(ans + l1 - l + 1);
                            ans = add(ans + modPow(2, r - l1));
                            ans = add(ans + r1 - r);
                        } else {
                            ans = add(ans + r - l);
                            ans = add(ans + r1 - l1);
                        }
                    }
                }
            }
        }
        std::cout << ans;
        return;
    }
    f[0][0][0] = 1;
    for (register int i = 1; i <= m; i++) {
        for (register int j = 0; j <= n; j++) {
            for (register int o = 0; o <= n; o++) {
                f[i & 1][j][o] =
                    ((long long)f[~i & 1][j][o] +
                     (j > 0 ? f[~i & 1][j - 1][o] : 0) +
                     (o > 0 ? f[~i & 1][j][o - 1] : 0) +
                     ((j > 0 && o > 0) ? f[~i & 1][j - 1][o - 1] : 0)) %
                    MOD;
                g[i & 1][j][o] =
                    ((long long)modPow(o - j, k) * f[i & 1][j][o] +
                     (long long)g[~i & 1][j][o] +
                     (j > 0 ? g[~i & 1][j - 1][o] : 0) +
                     (o > 0 ? g[~i & 1][j][o - 1] : 0) +
                     ((j > 0 && o > 0) ? g[~i & 1][j - 1][o - 1] : 0)) %
                    MOD;
            }
        }
    }
    std::cout << g[m & 1][n][n];
    exit(0);
    end.push_back(0);
    dfs(1);
    std::cout << ans;
}
}  // namespace

int main() {
    freopen("segment.in", "r", stdin);
    freopen("segment.out", "w", stdout);
    solve();
    return 0;
}