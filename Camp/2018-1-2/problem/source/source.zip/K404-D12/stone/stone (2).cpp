#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>

using namespace std;
#define pb push_back
#define MAXN 100000
#define MOD  1000000007
#define a turn[0]
#define b turn[1]
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int n, turn[2], cnt[2], x[25], res[4], B[MAXN+5], Free, Ans; vector<int> st; map<pair<vector<int>,bool>,int> Memo;
inline int fastpow(int s, int n){int _a=1; for(; n; n&1 ? _a = 1ll*_a*s%MOD : 0, s = 1ll*s*s%MOD, n >>= 1); return _a;}
pair<vector<int>,bool> tmp;
bool Robot(int c)
{
	tmp.first = st, tmp.second = c; sort(tmp.first.begin(),tmp.first.end(),greater<int>());
	for(; tmp.first.size() && !*--tmp.first.end(); tmp.first.pop_back());
	if(Memo.count(tmp)) return Memo[tmp]; int &ans = Memo[tmp]; vector<int>().swap(tmp.first);
	for(int i = 0, j; i < st.size(); i++)
		if(st[i] >= turn[c])
		{
			st[i] -= turn[c], j = Robot(c^1), st[i] += turn[c];
			if(!j) return ans = true;
		}	return ans = false;
}
void Check()
{
	int Alice_first = Robot(0), Bob_first = Robot(1);
	if(Alice_first && !Bob_first) ++res[0];
	if(Bob_first && !Alice_first) ++res[1];
	if(Alice_first && Bob_first) ++res[2];
	if(!Alice_first && !Bob_first) ++res[3];
}
void DFS(int i){if(i == n+1){Check(); return;} DFS(i+1), st.pb(x[i]), DFS(i+1);}
int main()
{
	freopen("stone.in","r",stdin), freopen("stone.out","w",stdout);
	n = read(), a = read(), b = read();
	if(a==b)
	{
		for(rint i = 1; i <= n; ++cnt[(read()/a)&1], i++);
		Ans = fastpow(2,n-(!!cnt[1])), printf("0 0 %d %d\n",(fastpow(2,n)-Ans+MOD)%MOD,Ans); return 0;
	}
	else if(n <= 20)
	{
		for(rint i = 1; i <= n; x[i++] = read());
		st.clear(), DFS(1); printf("%d %d %d %d\n",res[0],res[1],res[2],res[3]);
	}
	else Ans = (fastpow(2,n)+MOD-1)%MOD, printf("%d 0 0 1\n",Ans); return 0;
}
