#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int MAXB = 3e7;
const int MAXN = 1000010;
const int INF = 0x3f3f3f3f;
char buf[MAXB], *cp = buf;
void rd(int &x){
	x = 0;
	while(*cp < '0' || '9' < *cp) cp++;
	while('0' <= *cp && *cp <= '9') x = x * 10 + *cp++ - 48;
}
int n, m;
int e[MAXN][2];
vector<int> G[MAXN], H[MAXN];
int dfn[MAXN], tim, low[MAXN];
int col[MAXN], color;
int sta[MAXN], top;

int ans;
int d[MAXN];
int q[MAXN], f, r;
int dp[MAXN], cnt[MAXN];
void dfs(int x){
	low[x] = dfn[x] = ++tim;
	sta[top++] = x;
	for(register unsigned int i = 0; i < G[x].size(); i++){
		int y = G[x][i];
		if(!dfn[y]){
			dfs(y);
			low[x] = min(low[x], low[y]);
		}
		else if(!col[y]){
			low[x] = min(low[x], dfn[y]);
		}
	}
	if(dfn[x] == low[x]){
		color++;
		for(;;){
			cnt[color]++;
			int y = sta[--top];
			col[y] = color;
			if(x == y) break;
		}
	}
}
inline void gmax(int &x, int y){
	x = x > y ? x : y;
}
int main(){
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	fread(buf, 1, MAXB, stdin);
	rd(n); rd(m);
	for(int i = 0; i < m; i++){
		int x, y;
		rd(x); rd(y);
		G[x].PB(y);
		e[i][0] = x; e[i][1] = y;
	}
	memset(low, INF, sizeof(low));
	for(int i = 1; i <= n; i++) if(!col[i]) dfs(i);
	for(int i = 0; i < m; i++){
		int x = e[i][0], y = e[i][1];
		x = col[x]; y = col[y];
		if(x == y) continue;
		H[y].PB(x);
		d[x]++;
	}
	for(int i = 1; i <= color; i++) if(!d[i]){
		q[r++] = i;
	}
	while(f < r){
		int x = q[f++];
		dp[x] += cnt[x];
		gmax(ans, dp[x]);
		for(unsigned int i = 0; i < H[x].size(); i++){
			int y = H[x][i];
			gmax(dp[y], dp[x]);
			d[y]--;
			if(!d[y]){
				q[r++] = y;
			}
		}
	}
	printf("%d\n", ans);
	return 0;
}
