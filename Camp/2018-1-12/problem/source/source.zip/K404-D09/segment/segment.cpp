#include <cstdio>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

inline int get_str(char *str) {
	register int len = 0;
	for(register int ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		*str++ = ch, ++len;
	*str = '\0';
	return len;
}

struct IN {
	const IN& operator >> (char *st) const { return get_str(st), *this; }
	const IN& operator >> (char &ch) const { return ch = getch(), *this; }
	const IN& operator >> (int  &x) const { return x = get_int(), *this; }
} in;

namespace OUTBUFFER {
	char buf[1048576];
	int pt;
	inline void putch(register char ch) { buf[pt++] = ch; }
	inline void flush() { if(pt) fwrite(buf,sizeof(char),pt,stdout), pt = 0; }
	inline void check() { if(pt > 1000000) flush(); }
}

template <class T>
inline void put_int(register T x) {
	char temp[23];
	register int top;
	if(x == 0) return OUTBUFFER::putch('0');
	if(x < 0) OUTBUFFER::putch('-'), x = -x;
	for(top = 0; x; temp[++top] = x % 10, x /= 10);
	do OUTBUFFER::putch(temp[top] ^ '0'); while(--top);
	OUTBUFFER::check();
}

struct OUT {
	OUT() { OUTBUFFER::pt = 0; }
	~OUT() { OUTBUFFER::flush(); }
	const OUT &operator << (const char *str) const {
		while(*str) OUTBUFFER::putch(*str++);
		OUTBUFFER::check();
		return *this;
	}
	const OUT &operator << (register char ch) const {
		return OUTBUFFER::putch(ch), *this;
	}
	const OUT &operator << (register int x) const {
		return put_int<int>(x), *this;
	}
	const OUT &operator << (register long long x) const {
		return put_int<long long>(x), *this;
	}
} out;

const int NON = 100005, MOD = 998244353;
int N, M, K, Ans, Inv[NON], D[NON];

inline void init() {
	in >>N >>M >>K;
	if(K == 998244352) {
		Inv[1] = 1;
		for(int i = 2; i <= N; ++i)
			Inv[i] = (MOD + i - 1) / (long long)i * Inv[i - MOD % i];
	}
}

inline int fastPow(int a, int b) {
	int ret = 1;
	while(b) {
		(b & 1) ? (ret = (ret * a) % MOD) : 0;
		a = a * a % MOD;
		b >>= 1;
	}
	return ret;
}

inline int Calc() {
	int sum = 0, a = 0;
	switch(K) {
		case 998244352:
		for(int i = 1; i <= M; ++i) {
			a += D[i];
			a >= MOD ? a -= MOD : 0;
			sum += Inv[a];
			sum >= MOD ? sum -= MOD : 0;
		}; return sum;
		case 1:
		for(int i = 1; i <= M; ++i) {
			a += D[i];
			a >= MOD ? a -= MOD : 0;
			sum += a;
			sum >= MOD ? sum -= MOD : 0;
		}; return sum;
		default:
		for(int i = 1; i <= M; ++i) {
			a += D[i];
			a >= MOD ? a -= MOD : 0;
			sum += fastPow(a, K);
			sum >= MOD ? sum -= MOD : 0;
		}; return sum;
	}
}

inline void search(int depth, int lastL = 0, int lastR = 0) {
	int mr = M - N + depth;
	if(depth > N) {
		Ans += Calc();
		Ans >= MOD ? Ans -= MOD : 0;
		return;
	}
	for(int l = lastL + 1; l <= mr; ++l)
		for(int r = (l > lastR ? l : (lastR + 1)); r <= mr; ++r) {
			++D[l], --D[r];
			search(depth + 1, l, r);
			--D[l], ++D[r];
		}
}

inline void solve() {
	if (N > (long long)M * M) out <<"0\n";
	else {
		Ans = 0;
		search(1);
		out <<Ans <<'\n';
	}
}

#define PROBLEM_NAME	"segment"
int main() {
	freopen(PROBLEM_NAME".in", "r", stdin);
	freopen(PROBLEM_NAME".out", "w", stdout);
	init();
	solve();
	return 0;
}
