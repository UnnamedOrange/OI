#include<bits/stdc++.h>
using namespace std;
const int R_LEN=(1<<18)|1;
struct Fast_in{
    char ibuf[R_LEN],*s,*t;
    Fast_io(){s=ibuf,t=ibuf;}
    inline char getc(){
        (s==t)&&(t=(s=ibuf)+fread(ibuf,1,R_LEN,stdin));
        return (s==t)?-1:*s++;
    }
    inline int rd(){
        char ch=getc(); int i=0,f=1;
        while(!isdigit(ch)){if(ch=='-')f=-1;ch=getc();}
        while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getc();}
        return i*f;
    }
    inline Fast_in &operator >>(int &x){x=rd();return *this;}
}in;
const int Mod=998244353;
typedef long long ll;
int n,m,k;
namespace SP1{
	int ans=0; 
	inline int power(int a,int b){
		int rs=1;
		for(;b;b>>=1,a=(ll)a*a%Mod)if(b&1)rs=(ll)rs*a%Mod;
		return rs;
	}
	vector< pair<int,int> >q;
	inline int calc(){
		static int a[10];
		memset(a,0,sizeof(a));
		for(int i=0;i<n;i++)
			for(int l=q[i].first;l<q[i].second;++l)
				++a[l];
//		for(int i=0;i<n;i++)
//			cerr<<q[i].first<<" "<<q[i].second<<endl;
//		cerr<<endl;
		int rs=0;
		for(int i=1;i<=m;i++) (rs+=power(a[i],k))%=Mod;
		return rs;
	}
	inline void dfs(int l,int r,int cnt){
		if(cnt==n){
			(ans+=calc())%=Mod;
			return;
		}
		for(int L=l+1;L<=m;++L)
			for(int R=r+1;R<=m;++R){
				if(L>R)continue;
				q.push_back(make_pair(L,R));
				dfs(L,R,cnt+1);
				q.pop_back();
			}
	}
	inline void solve(){
		dfs(0,0,0); printf("%d\n",ans);
	}
}
namespace SP2{
	const int N=43;
	int dp[N][N][N],cnt[N][N][N];
	inline int getans1(){
		for(int l=1;l<=m;l++)
			for(int r=l;r<=m;r++)
				dp[l][r][1]=r-l,cnt[l][r][1]=1;
		for(int i=2;i<=n;i++)
			for(int l=1;l<=m;l++)
				for(int r=l;r<=m;r++)
					for(int pre_l=1;pre_l<l;++pre_l)
						for(int pre_r=pre_l;pre_r<r;++pre_r){
							if(!cnt[pre_l][pre_r][i-1]) continue;
							cnt[l][r][i]+=cnt[pre_l][pre_r][i-1];
							if(cnt[l][r][i]>Mod)cnt[l][r][i]-=Mod;
						//	dp[l][r][i]= dp[l][r][i] + ( (l>=pre_r)? dp[pre_l][pre_r][i-1]+(r-l) : dp[pre_l][pre_r][i-1]+(r-pre_r));
							dp[l][r][i]=(dp[l][r][i]+dp[pre_l][pre_r][i-1])%Mod;
							dp[l][r][i]=(dp[l][r][i]+(ll)cnt[pre_l][pre_r][i-1]*(r-l)%Mod)%Mod;
						}
		int ans=0;
		for(int l=1;l<=m;l++)
			for(int r=l;r<=m;r++)
				ans=(ans+dp[l][r][n])%Mod;
		printf("%d\n",ans);			
	}
	inline void getans2(){
		for(int l=1;l<=m;l++)
			for(int r=l;r<=m;r++)
				dp[l][r][1]=r-l,cnt[l][r][1]=1;
		for(int i=2;i<=n;i++)
			for(int l=1;l<=m;l++)
				for(int r=l;r<=m;r++)
					for(int pre_l=1;pre_l<l;++pre_l)
						for(int pre_r=pre_l;pre_r<r;++pre_r){
							if(!cnt[pre_l][pre_r][i-1]) continue;
							cnt[l][r][i]+=cnt[pre_l][pre_r][i-1];
							if(cnt[l][r][i]>Mod)cnt[l][r][i]-=Mod;
							int len=( (l>=pre_r)? (r-l) : (r-pre_r));
							dp[l][r][i]=(dp[l][r][i]+dp[pre_l][pre_r][i-1])%Mod;
							dp[l][r][i]=(dp[l][r][i]+(ll)cnt[pre_l][pre_r][i-1]*len%Mod)%Mod;
						}
		int ans=0;
		for(int l=1;l<=m;l++)
			for(int r=l;r<=m;r++)
				ans=(ans+dp[l][r][n])%Mod;
		printf("%d\n",ans);
	}
	inline void solve(){
		if(k==1)getans1();
		else getans2();
	}
}
namespace SP_n1{
	inline void solve(){
		int ans=0;
		for(int r=1;r<=m;++r){
			ans=(ans+(ll)(r)*(r-1)/2)%Mod;
		}
		printf("%d\n",ans);
	}
}
namespace SP_n2{
	inline void solve(){
		int ans=0;
		for(int l=1;l<=m;++l)
			for(int r=l;r<=m;++r){
				ans=(ans+(ll)(l)*(l-1)/2%Mod*(r-l))%Mod;
				for(int pre_r=l-1;pre_r>=1;--pre_r){
					ans=(ans+(ll)(pre_r)*(pre_r-1)/2)%Mod;
				}
			}
		printf("%d\n",ans);
	}
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	in>>n>>m>>k; 
	if(m<n){puts("0");return 0;}
	if(m<=6)SP1::solve();
	else if(m<=40)SP2::solve();
	else if(n==1)SP_n1::solve();
	else SP_n2::solve();
}
