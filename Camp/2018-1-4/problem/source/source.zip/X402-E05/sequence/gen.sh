cas=1
while true; do
	./test || break
	./sequence ||break
	./sequence1 || break
	diff ./sequence.out ./sequence1.out || break
	echo $cas
	cas=`expr $cas + 1`
done
