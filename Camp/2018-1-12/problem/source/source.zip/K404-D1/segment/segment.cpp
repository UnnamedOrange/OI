#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#define M 100010
#define ll long long
#define mod 998244353
using namespace std;
int n,m,k,ans;
int num[M];
int power(int x,int y)
{
    int ret=1;
    while(y)
    {
        if(y&1)
            ret=(ll)ret*x%mod;
        x=(ll)x*x%mod;
        y>>=1;
    }
    return ret;
}
void dfs(int step,int l,int r)
{
    if(step==n+1)
    {
        for(int i=1; i<=m; i++)
        {
            ans+=power(num[i],k);
            if(ans>=mod)
                ans-=mod;
        }
    }
    else for(int i=l+1; i<=m-(n-step); i++)
            for(int j=max(i,r+1); j<=m-(n-step); j++)
            {
                for(int k=i; k<j; k++)
                    num[k]++;
                dfs(step+1,i,j);
                for(int k=i; k<j; k++)
                    num[k]--;
            }
}
int main()
{
    freopen("segment.in","r",stdin);
    freopen("segment.out","w",stdout);
    cin>>n>>m>>k;
    if(n==1)
    {
        cout<<(((ll)(m-1)*m*(m+1))/6)%mod;
        return 0;
    }
    ans=0;
    dfs(1,0,0);
    cout<<ans;
    return 0;
}
