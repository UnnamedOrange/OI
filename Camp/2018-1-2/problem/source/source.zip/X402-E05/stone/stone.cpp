#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
const LL mod=1e9+7;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
}
int n,A,B,flag;
int x[N],c[N];
LL ans1,ans2,ans3,ans4;
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
int main()
{
	file();
	read(n),read(A),read(B);
	if(A>B)swap(A,B),flag=1;
	For(i,1,n)
	{
		read(x[i]);
		x[i]%=A+B;
		x[i]=((B<=x[i])*2)+(A<=x[i]);
		c[x[i]]++;
	}
	ans1=(c[3]==0?0:qpow(2,c[3]-1))%mod*qpow(2,c[0])%mod*(c[1]==0?1:qpow(2,c[1]-1))%mod;
	ans2=(c[3]==0?1:qpow(2,c[3]-1))%mod*qpow(2,c[0])%mod*(c[1]==0?0:qpow(2,c[1]-1))%mod;
	ans3=(c[3]==0?0:qpow(2,c[3]-1))%mod*qpow(2,c[0])%mod*(c[1]==0?0:qpow(2,c[1]-1))%mod;
	ans4=(c[3]==0?1:qpow(2,c[3]-1))%mod*qpow(2,c[0])%mod*(c[1]==0?1:qpow(2,c[1]-1))%mod;
	if(flag)swap(ans2,ans3);
	printf("%lld %lld %lld %lld\n",ans1,ans2,ans3,ans4);
	return 0;
}
