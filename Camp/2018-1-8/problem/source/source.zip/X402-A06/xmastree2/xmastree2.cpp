#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1; c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, fa[maxn], Begin[maxn], to[maxn], e, Next[maxn], w[maxn], r[maxn];

void add(int x,int y){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get(){
	n = read();
	For(i, 2, n){
		int x = read(), y = read();
		add(x, y), add(y, x);
	}
	
	For(i, 1, n) w[i] = read(), r[i] = read();
}

void dfs(int h,int father){
	for(int i = Begin[h]; i; i = Next[i]){
		int v = to[i];
		if(v == father) continue;

		fa[v] = h;
		dfs(v, h);
	}
}

int dp[(1 << 10) + 10], Ans;

void _dp(int h){
	mm(dp, 0);
	dp[(1<<h-1)] = w[h];
	int tmp = (1 << n) - 1;
	For(i, 0, tmp){
		if(!dp[i]) continue;
		int cnt1 = __builtin_popcount(i);
		For(j, 1, n){
			if(i&(1<<j-1)){
				for(int k = Begin[j];k ;k = Next[k]){
					int v = to[k];
					if(v == fa[j] || (i & (1 << v-1))) continue;

					dp[i | (1 << v-1)] = max(dp[i | (1 << v-1)], dp[i] + w[v] * (cnt1 + 1) );
				}
			}
		}
	}

	Ans = max(Ans, dp[tmp]);
}

void solve_10_bf(){
	For(i, 1, n){
		if(r[i]){
			fa[i] = 0;
			dfs(i, -1);
			_dp(i);
		}
	}
	
	printf("%d\n", Ans);
}

struct node{
	int id, val;
};

priority_queue<node> q;

bool operator < (node c, node d){
	return c.val > d.val;
}

void __dp(int h){
	node T;
	T.id = h, T.val = w[h];
	q.push(T);
	int ans = 0;
	For(i, 1, n){
		T = q.top();
		q.pop();
		ans += T.val * i;
		for(int j = Begin[T.id];j ;j = Next[j]){
			int v = to[j];
			if(v == fa[T.id]) continue;

			node now;
			now.id = v, now.val = w[v];
			q.push(now);
		}
	}

	Ans = max(Ans, ans);
}

void solve_bf(){
	For(i, 1, n){
		if(r[i]){
			fa[i] = 0;
			dfs(i, -1);
			__dp(i);
		}
	}

	printf("%d\n", Ans);
}

int main(){

	freopen("xmastree2.in", "r", stdin);
	freopen("xmastree2.out", "w", stdout);
	
	Get();
	if(n <= 10) solve_10_bf();
	else solve_bf();

	return 0;
}
