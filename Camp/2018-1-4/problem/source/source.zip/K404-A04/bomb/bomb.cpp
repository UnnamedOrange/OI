#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int maxn=1000010;
int n,m,nc,tim,top,ans,dfn[maxn],low[maxn],st[maxn],vis[maxn],col[maxn],num[maxn],rd[maxn],ord[maxn],f[maxn];
struct edge
{
	int t;
	edge *next;
}*con[maxn],*sd[maxn];
void ins(edge **a,int x,int y)
{
	edge *p=new edge;
	p->t=y;
	p->next=a[x];
	a[x]=p;
}
void tarjan(int v)
{
	dfn[v]=low[v]=++tim;
	st[++top]=v;vis[v]=1;
	for(edge *p=con[v];p;p=p->next)
		if(!dfn[p->t]) tarjan(p->t),low[v]=min(low[v],low[p->t]);
		else if(vis[p->t]) low[v]=min(low[v],dfn[p->t]);
	if(dfn[v]==low[v])
		for(nc++;top&&st[top+1]!=v;top--)
		{
			col[st[top]]=nc;
			num[nc]++;
			vis[st[top]]=0;
		}
}
void suodian()
{
	for(int i=1;i<=n;i++)
		for(edge *p=con[i];p;p=p->next)
			if(col[i]!=col[p->t]) ins(sd,col[i],col[p->t]),rd[col[p->t]]++;
}
void tuopu()
{
	top=0;
	for(int i=1;i<=nc;i++)
		if(!rd[i]) st[++top]=i;
	for(int i=1;i<=nc;i++)
	{
		int v=st[top--];ord[i]=v;
		for(edge *p=sd[v];p;p=p->next)
		{
			rd[p->t]--;
			if(!rd[p->t]) st[++top]=p->t;
		}
	}
}
void dp()
{
	ans=0;
	for(int i=nc;i;i--)
	{
		int v=ord[i];
		for(edge *p=sd[v];p;p=p->next)
			f[v]=max(f[v],f[p->t]);
		f[v]+=num[v];
		ans=max(ans,f[v]);	
	}
}
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(con,x,y);
	}
	for(int i=1;i<=n;i++)
		if(!dfn[i]) tarjan(i);
//	for(int i=1;i<=n;i++)
//		cout<<col[i]<<' ';
//	cout<<endl;		
	suodian();
	tuopu();
//	for(int i=1;i<=nc;i++)
//		cout<<num[i]<<' ';
//	cout<<endl;	
	dp();
//	for(int i=1;i<=nc;i++)
//		cout<<f[i]<<' ';
//	cout<<endl;	
	printf("%d",ans);
	return 0;
}
/*8 8
3 2
2 1
2 5
4 2
3 6
6 8
8 6
6 7*/
