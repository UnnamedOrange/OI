#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int ret=0; char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>=48&&c<=57)ret=ret*10+c-48,c=getchar(); 
	return ret;
}int u,v,cu,cv,a[100];;

int main()
{
	freopen("1.out","w",stdout);
	for(int i=1; i<=9; ++i)a[i]=a[i-1]<<1;
	for(int i=1; i<=919; ++i)
	for(int j=i+1; j<=920; ++j)
	{
		u=i;
		v=j;
		if(u%81 || v%81)
		{
			if(u%)
		}
		if()
	}
}

