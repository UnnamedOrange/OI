//2017-11-5
//miaomiao
//
#include <bits/stdc++.h>	
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (1000000+5)

char chr;
inline void Read(int &x){
	chr = getchar();
	while(chr < '0' || chr > '9') chr = getchar();
	x = 0;
	while(chr >= '0' && chr <= '9'){
		x = (x<<1) + (x<<3) + (chr^'0');
		chr = getchar();
	}
}

struct node{
	int id, v;
	bool operator <(const node &rhs)const{
		return v > rhs.v;
	}
};

vector<int> G[N], g[N];
int sn, clk, tp, dfn[N], low[N], sid[N], st[N];
int siz[N], dig[N];

#define v G[now][i]

void Targan(int now){
	dfn[now] = low[now] = ++clk;
	st[++tp] = now;

	For(i, 0, G[now].size()-1)
		if(!dfn[v]){
			Targan(v); low[now] = min(low[now], low[v]);
		}else if(!sid[v]) low[now] = min(low[now], dfn[v]);
	
	if(low[now] == dfn[now]){
		sid[now] = ++sn; ++siz[sn];
		while(st[tp] ^ now) sid[st[tp--]] = sn, ++siz[sn];
		--tp;
	}
}

#undef v

priority_queue<node> q;

void Solve(){
	For(i, 1, sn) if(!dig[i]){
		q.push((node){i, siz[i]});
	//	printf("In %d (sz = %d)\n", i, siz[i]);
	}
	node now;
	int ans = 0, tot = 0, v, id, nxt;

	while(!q.empty()){
		now = q.top(); q.pop();
		v = now.v - tot; id = now.id;

		ans += v; tot += v;
		For(i, 0, g[id].size()-1){
			--dig[nxt = g[id][i]];
			if(!dig[nxt]) q.push((node){nxt, siz[nxt] + tot});
		}
	}

	printf("%d\n", ans);
}

int main(){
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);

	int n, m, u, v;

	Read(n); Read(m);
	For(i, 1, m){
		Read(u); Read(v);
		G[u].pb(v);
	}

	For(i, 1, n) if(!dfn[i]) Targan(i);

	For(i, 1, n) For(j, 0, G[i].size()-1){
		u = sid[i], v = sid[G[i][j]];
		if(u ^ v) g[v].pb(u), ++dig[u];
	}

	Solve();

	return 0;
}
