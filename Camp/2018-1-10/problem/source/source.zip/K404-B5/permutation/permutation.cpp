#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

#include <algorithm>
#include <numeric>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <deque>
#include <list>
#include <bitset>
#include <utility>

#include <string>
#include <cstring>

using namespace std;

#define LL long long
#define LD long double
#define SC(tp,var) static_cast < tp > ( var )
#define AR(tp) vector < tp >
#define PII pair < int, int >
#define PIL pair < int, long long >
#define PLI pair < long long, int >
#define PLL pair < long long, long long >
#define MP make_pair
#define FF first
#define SS second
#define PB push_back
#define PF push_front
#define POB pop_back
#define POF pop_front
#define PQ priority_queue
#define INIT(var,val) memset ( var, val, sizeof ( var ) )
#define fo(fname) { freopen ( fname ".in", "r", stdin ); freopen ( fname ".out", "w", stdout ); }
#define lp(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar < lpen; ++lpvar )
#define lpi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar <= lpen; ++lpvar )
#define lpd(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar > lpen; --lpvar )
#define lpdi(lpvar,lpst,lpen) for ( int lpvar = lpst, _lpen = lpen; lpvar >= lpen; --lpvar )
#define qmax(a,b) (((a)<(b))?(b):(a))
#define qmin(a,b) (((a)<(b))?(a):(b))
#define qabs(a) (((a)<0)?(-(a)):(a))
#define qsqr(a) ((a)*(a))

const int INF = 0x3fffffff;
const int SINF = 0x7fffffff;
const long long LINF = 0x3fffffffffffffffLL;
const long long SLINF = 0x7fffffffffffffffLL;
const int MINF = 0x3f3f3f3f;
const int MAXN = 100007;
const int MOD = 998244353;

int n;
int ip[MAXN];



void init ();
void input ();
void work ();



namespace task1
{
	int p[MAXN];
	bool vis[MAXN];
	
	int dfs ( int now )
	{
		int ans = 0;
		while ( !vis[now] ){
			vis[now] = true;
			now = p[now];
			++ans;
		}
		return ans;
	}
	
	bool check ()
	{
		INIT ( vis, false );
		lpi ( i, 1, n ){
			if ( !vis[i] ){
				if ( dfs ( i ) & 1 ) return false;
			}
		}
		return true;
	}
	
	void work ()
	{
		lpi ( i, 1, n ) p[i] = i;
		bool flag;
		int ans = 0;
		do{
			flag = true;
			lpi ( i, 1, n ){
				if ( ip[i] && ( p[i] ^ ip[i] ) ){
					flag = false;
					break;
				}
			}
			if ( flag && check () ) ++ans;
		}while ( next_permutation ( p+1, p+1+n ) );
		cout << ans << endl;
	}
}

namespace task2
{
	void work ()
	{
		if ( n & 1 ) cout << 0 << endl;
		else{
			LL ans = 1;
			for ( int i = 1; i <= n; i += 2 ) ( ans *= i ) %= MOD;
			cout << ( ans * ans ) % MOD << endl;
		}
	}
}

namespace task3
{
	void work ()
	{
		cout << 0 << endl;
	}
}



int main ()
{
	init ();
	input ();
	work ();
}



void init ()
{
	ios::sync_with_stdio ( false );
	cin.tie ( 0 );
	
	fo ( "permutation" );
}

void input ()
{
	scanf ( "%d", &n );
	lpi ( i, 1, n ) scanf ( "%d", &ip[i] );
}

void work ()
{
	bool all0 = true;
	lpi ( i, 1, n ){
		if ( ip[i] ){
			all0 = false;
			break;
		}
	}
	
	if ( n <= 10 ) task1::work ();
	else if ( all0 ) task2::work ();
	else task3::work ();
}
