#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int T,n,ans,len;
char s[110];
void cut_(int x,int y)
{
	int tmp=1,l=0;
	while(tmp<=len)
	{
		if(tmp<x || tmp>y) s[++l]=s[tmp];
		tmp++;
	}
	return ;
}
bool pd(int x,int y)
{
	for(int i=x;i<=y;i++) if(s[i]!=s[x+y-i]) return true;
	return false;
}
void work(int dep)
{
	if(dep>ans) return ;
	if(len==0)
	{
		ans=min(ans,dep);
		return ;
	}
	char cnt[110];
	memcpy(cnt,s,sizeof(cnt));
	for(int i=1;i<=len;i++)
	{
		for(int j=len;j>=i+1;j--)
		{
			if(pd(i,j))
			{
				cut_(i,j);
				len-=(j-i+1);
				work(dep+1);
				len+=(j-i+1);
				memcpy(s,cnt,sizeof(s));
			}
		}
	}
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		getchar();
		scanf("%s",s+1);
		ans=1e8;len=strlen(s+1);
		work(0);
		if(ans==1e8) ans=-1;
		printf("%d\n",ans);
	}
	return 0;
}
