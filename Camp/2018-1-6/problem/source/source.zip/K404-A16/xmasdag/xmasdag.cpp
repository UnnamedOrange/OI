#include <cstdio>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

typedef long long ll;
const int mod = 998244353;
const int N = 100010;
const int K = 510;

struct edge{int to, next;} e[N << 1];
int cnt, n, m, k, x, y, h[N], head[N], du[N];
ll s[K][K], f[N][K], jie[N];

void ins(int x, int y)
{
	e[++cnt].to = y; e[cnt].next = head[x]; head[x] = cnt; ++du[y];
}

int main()
{
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	FOR(i, 1, m)
	{
		scanf("%d%d", &x, &y);
		ins(x, y);
	}
	int l = 0, r = 1; h[1] = 1; f[1][0] = 1;
	while (l < r)
	{
		x = h[++l];
		for(int i = head[x]; i; i = e[i].next)
		{
			f[e[i].to][0] += f[x][0];
			FOR(j, 1, k)
				(f[e[i].to][j] += f[x][j] + f[x][j - 1]) %= mod;
			--du[e[i].to];
			if (!du[e[i].to]) h[++r] = e[i].to;
		}
	}
	s[0][0] = 1;
	FOR(i, 1, k) FOR(j, 1, i) s[i][j] = (s[i - 1][j - 1] + (ll) j * s[i - 1][j]) % mod;
	jie[0] = 1; FOR(i, 1, k) jie[i] = jie[i - 1] * i % mod;
	FOR(i, 1, n)
	{
		ll ans = 0;
		FOR(j, 0, k) (ans += f[i][j] * jie[j] % mod * s[k][j]) % mod;
		printf("%lld\n", ans);
	}
	return 0;
}
