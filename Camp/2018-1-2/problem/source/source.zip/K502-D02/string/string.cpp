#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int N = 100000 + 1000;
const int N1 = 110;

int T, n;
char str[N];
bool ch[N1][N1];
int f[N1][N1];

inline void open()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
}

inline void close()
{
	fclose(stdin);
	fclose(stdout);
}

inline void init()
{
	for(double i = 1;i <= n;i += 0.5)
	{
		int l, r;
		if(i - (int)i != 0)
		{
			l = i, r = i + 0.5;
			while(l >= 1 && r <= n)
			{
				if(str[l] == str[r])
				{
					ch[l][r] = 1;
					--l, ++r;
				}
				else
					break;
			}
		}
		else
		{
			ch[(int)i][(int)i] = 1;
			l = i - 1, r = i + 1;
			while(l >= 1 && r <= n)
			{
				if(str[l] == str[r])
				{
					ch[l][r] = 1;
					--l, ++r;
				}
				else
					break;
			}
		}
	}
}

inline void wr1()
{
	memset(ch, 0, sizeof ch);
	init();
	memset(f, 0x3f, sizeof f);
	for(int i = 1;i <= n;++i)
		f[i][i] = -1;
	for(int j = 1;j <= n - 1;++j)
		for(int i = 1;i + j <= n;++i)
		{
			if(j == 1)
			{
				if(ch[i][i + j] == 1)
					f[i][i + j] = -1;
				else
					f[i][i + j] = 1;
			}
			else
			{
				for(int k = i;k < i + j;++k)
				{
					if(f[i][k] != -1 && f[k + 1][i + j] != -1)
						f[i][i + j] = min(f[i][i + j], f[i][k] + f[k + 1][i + j]);
					if(ch[i][i + j] != 1)
						f[i][i + j] = 1;
				}
				if(f[i][i + j] > N)
					f[i][i + j] = -1;
			}
		}
	printf("%d\n", f[1][n]);
}

inline int FF(int l, int r)
{
	if(l == r)
		return 1;
	if(r == l + 1)
	{
		if(str[r] == str[l])
			return 1;
		else
			return 0;
	}
	if(!(l == 1 && r == n) && l < r)
	{
		int u = (l + r) >> 1;
		bool flag = true;
		for(int i = 0;l + i <= r - i;++i)
			if(str[l + i] != str[r - i])
			{
				flag = false;
				break;
			}
		if(!flag)
			return 0;
	}
	if(r - l + 1 % 2 == 0)
	{
		int ml = (l + r) >> 1, mr = ml + 1;
		if(FF(l, ml) || FF(mr, r))
			return 1;
		else
			return 0;
	}
	else
	{
		int m = (l + r) >> 1;
		if(FF(l, m) || FF(m, r) || FF(l, m - 1) || FF(m + 1, r))
			return 1;
		else
			return 0;
	}
}

inline void wr2()
{
	int mid = n / 2;
	bool flag = true;
	for(int i = 1;i <= mid;++i)
	{
		int r = n + 1 - i;
		if(str[i] != str[r])
		{
			flag = false;
			break;
		}
	}
	if(!flag)
		printf("1\n");
	else
	{
		bool f1 = true;
		for(int i = 3;i <= n;++i)
			if(str[i] != str[i - 2])
			{
				f1 = false;
				break;
			}
		if(f1)
			printf("-1\n");
		else if(FF(1, n))
			printf("-1\n");
		else
			printf("2\n");
	}
}

inline void solve()
{
	scanf("%d", &T);
	while(T--)
	{
		scanf("%d", &n);
		scanf("%s", str + 1);
		if(n <= 100)
			wr1();
		else
			wr2();
	}
}

int main()
{
	open();
	solve();
	close();
	return 0;
}
