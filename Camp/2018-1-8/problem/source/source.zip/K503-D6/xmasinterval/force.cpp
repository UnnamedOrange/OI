#include <cctype>
#include <cstdio>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define mid ((l+r)>>1)
#define lson l,mid,t<<1
#define rson mid+1,r,t<<1|1
#define lc tr[t<<1]
#define rc tr[t<<1|1]

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;    
}

using namespace std;
const int N=5e5+10,p=1e9+9;
int n,m,ans,l[N],r[N],b[N];

int main()
{
    freopen("xmasinterval.in","r",stdin);
    freopen("force.out","w",stdout);
    m=get(),n=get();
    rep(i,0,m-1)
        l[i]=get(),r[i]=get();
    rep(i,0,n-1)
        b[i]=get();
    for (int i=0; i<1<<m; ++i)
    {
        int flag=0;
        rep(j,0,m-1)
            if ((i>>j)&1)
                rep(k,0,n-1)
                    if (l[j]<=b[k] && b[k]<=r[j])
                        flag|=1<<k;
        ans+=flag+1==1<<n;
    }
    printf("%d",ans);
    return 0;
}
