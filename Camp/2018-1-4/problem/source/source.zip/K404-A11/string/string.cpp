#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m;
long long ans=2;
long long const mod=98244353;
char s[1005];
char c[1005];

long long quick(int k)
{
	long long a=1;
	int x=k%20;
	k=k/20;
	for(int i=1;i<=k;i++)
	  a=(a<<20)%mod;
	a=(a<<x)%mod;
	return a;
}

bool pan(int l,int r)
{
	while(l<r)
	{
		if(s[l]==s[r])
		  return false;
		l++;r--;
	}
	return true;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	scanf("%s",s+1);
	for(int i=1;i<m;i++)
	{
		int l=max(1,i*2+1-m),r=min(m,i*2);
		if(pan(l,r))
		  ans=(ans+quick(min(i-l+1,r-i)))%mod;
	}
	printf("%lld",ans);
}
