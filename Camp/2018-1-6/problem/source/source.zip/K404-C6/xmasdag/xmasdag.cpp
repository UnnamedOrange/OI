#include <bits/stdc++.h>
 
#define fir first
#define sec second
#define MP make_pair
#define PB push_back
 
using namespace std;
typedef long long LL;
typedef unsigned long long u64;
 
template <typename T> inline bool cmin(T & a, const T & b) { return a > b ? a = b, 1 : 0;}
template <typename T> inline bool cmax(T & a, const T & b) { return a < b ? a = b, 1 : 0;}
int read() {
    int x = 0, f = 1;char ch;
    for(ch = getchar(); !isdigit(ch); ch = getchar())
        if(ch == '-') f = -1;
    for(; isdigit(ch); x = x * 10 + ch - '0', ch = getchar());
    return x * f;
}


const int MaxN = 101234, MaxM = MaxN << 1, MaxK = 1024;
int n, m, K;
struct edge {int to, nxt;} e[MaxM]; int cnt, lst[MaxN];
void addEdge(int a, int b) {
	e[++cnt] = (edge) {b, lst[a]}; lst[a] = cnt;
}

const int P = 998244353, G = 3, N = 600;
inline int add(int a, int b) {
    return a + b >= P ? a + b - P : a + b;
}
 
inline int sub(int a, int b) {
    return a - b < 0 ? a - b + P : a - b;
}
 
inline int mul(int a, int b) {
    return (LL) a * b % P;
}
 
inline int exp(int a, int b) {
    int ans = 1;
    for(; b; b >>= 1) {
        if(b & 1) ans = mul(ans, a);
        a = mul(a, a);
    }
    return ans;
}
 
int f[MaxN][MaxK], deg[MaxN], s[MaxK][MaxK], fac[MaxK], rfac[MaxK], ans[MaxN]; queue<int> q;

int main() {
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	int i, j, k, l;
	n = read(); m = read(); K = read();
	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		addEdge(u, v); ++deg[v];
	}	
	
	fac[0] = 1;
	for(i = 1; i <= K; i++) fac[i] = mul(fac[i - 1], i);
	--i; rfac[i] = exp(fac[i], P - 2);	
	for(; i; i--) rfac[i - 1] = mul(rfac[i], i);
	 
	q.push(1); 
	
	f[1][0] = 1; 
	while(!q.empty()) {
		int c = q.front(); q.pop(); 
		int *f = ::f[c];
		for(int i = lst[c], b; b = e[i].to, i; i = e[i].nxt) {
			int *g = ::f[b];
			g[0] = add(g[0], f[0]);
			for(int i = 1; i <= K; i++) 
				g[i] = add(g[i], add(f[i], f[i - 1]));
			if(!--deg[b]) q.push(b);
		}
	}
	s[0][0] = 1;
	for(i = 1; i <= K; i++) 
		for(j = 1; j <= K; j++)	
			s[i][j] = add(s[i - 1][j - 1], mul(j, s[i - 1][j]));
	for(i = 1; i <= n; i++) {
		int ans = 0;
		for(k = 0; k <= K; k++) 
			ans = add(ans, mul(mul(f[i][k], s[K][k]), fac[k]));
		printf("%d\n", ans);
	}
	return 0;
}
