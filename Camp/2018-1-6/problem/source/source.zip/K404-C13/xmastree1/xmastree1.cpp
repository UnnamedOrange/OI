#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
#include<set>
#include<vector>
using namespace std;

const int N=100005;
const int M=N*400;

struct E{
	int to,next;
}mem[N<<1];
struct node{
	int id,x;
	node(){}
	node(int id,int x):id(id),x(x){}
	friend bool operator<(node a,node b){
		return a.id<b.id;
	}
};
int n,num,x,y,ans,opt,T,b,L,R,tot,z,col;
int head[N],c[N],f[N][18],in[N],ot[N],dep[N];
int rt[N],cnt[M],ls[M],rs[M],t[N],used[N];
set<node> st[N];
set<node>::iterator it,pre,nxt;
vector<int> lev[N];

void add(int x,int y){
	num++;
	mem[num].to=y; mem[num].next=head[x];
	head[x]=num;
}

void dfs1(int k,int pre){
	int j,u;
	in[k]=++num;
	for (j=head[k];j;j=mem[j].next){
		u=mem[j].to;
		if (u==pre) continue;
		f[u][0]=k; dep[u]=dep[k]+1;
		dfs1(u,k);
	}
	ot[k]=num;
}

void dfs2(int k,int pre){
	int j,u;
	if (!cnt[c[k]]&&c[k]>=L&&c[k]<=R) ans++;
	if (c[k]>=L&&c[k]<=R) cnt[c[k]]++;
	for (j=head[k];j;j=mem[j].next){
		u=mem[j].to;
		if (u==pre) continue;
		dfs2(u,k);
	}
}

void init(){
	int i,j;
	for (i=1;i<=17;i++)
		for (j=1;j<=n;j++) f[j][i]=f[f[j][i-1]][i-1];
}

int lca(int x,int y){
	int i;
	if (dep[x]<dep[y]) swap(x,y);
	for (i=17;i>=0;i--)
		if (dep[x]-dep[y]>=(1<<i)) x=f[x][i];
	if (x==y) return x;
	for (i=17;i>=0;i--)
		if (f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
	return f[x][0];
}

int insert(int last,int l,int r,int p,int w){
	int now=++tot;
	if (l==r){
		cnt[now]=cnt[last]+w;
		return now;
	}
	int mid=(l+r)>>1;
	ls[now]=ls[last];
	rs[now]=rs[last];
	if (p<=mid) ls[now]=insert(ls[last],l,mid,p,w);
	else rs[now]=insert(rs[last],mid+1,r,p,w);
	cnt[now]=cnt[ls[now]]+cnt[rs[now]];
	return now;
}

void ins(int &k,int l,int r,int p,int w){
	if (!k) k=++tot;
	if (l==r){
		cnt[k]=cnt[k]+w;
		return;
	}
	int mid=(l+r)>>1;
	if (p<=mid) ls[k]=insert(ls[k],l,mid,p,w);
	else rs[k]=insert(rs[k],mid+1,r,p,w);
	cnt[k]=cnt[ls[k]]+cnt[rs[k]];
}

void add(int x,int p,int w){
	for (;x<=n;x+=x&-x) ins(t[x],1,n,p,w);
}

void push(int x){
	for (;x;x-=x&-x) used[x]=t[x];
}

int sum(int x){
	int sum=0;
	for (;x;x-=x&-x) sum+=cnt[used[x]];
	return sum;
}

int sumls(int x){
	int sum=0;
	for (;x;x-=x&-x) sum+=cnt[ls[used[x]]];
	return sum;
}

int query(int x,int y,int l,int r,int L,int R,int ql,int qr){
	if (L<=l&&r<=R) return cnt[y]-cnt[x]+sum(qr)-sum(ql-1);
	int mid=(l+r)>>1,sum=0,p;
	if (R>mid){
		sum=cnt[ls[y]]-cnt[ls[x]]+sumls(qr)-sumls(ql-1);
		for (p=ql-1;p;p-=p&-p) used[p]=rs[used[p]];
		for (p=qr;p;p-=p&-p) used[p]=rs[used[p]];
		sum+=query(rs[x],rs[y],mid+1,r,L,R,ql,qr);
		return sum;
	}
	else{
		for (p=ql-1;p;p-=p&-p) used[p]=ls[used[p]];
		for (p=qr;p;p-=p&-p) used[p]=ls[used[p]];
		return query(ls[x],ls[y],l,mid,L,R,ql,qr);
	}
}

int read(){
	int num=0; char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		num=num*10+c-'0';
		c=getchar();
	}
	return num;
}

int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	int i,k,j;
	n=read(); T=read(); opt=read();
	for (i=1;i<=n;i++) c[i]=read();
	for (i=1;i<n;i++){
		x=read(); y=read();
		add(x,y); add(y,x);
	}
	num=0;
	dfs1(1,0);
	init();
	for (i=1;i<=n;i++) lev[c[i]].push_back(i);
	for (i=1;i<=n;i++){
		rt[i]=rt[i-1];
		for (j=0;j<lev[i].size();j++){
			x=lev[i][j];
			it=pre=nxt=st[i].lower_bound(node(in[x],x));
			rt[i]=insert(rt[i],1,n,in[x],1);
			if (pre==st[i].begin()) y=0;
			else y=(*--pre).x;
			if (nxt==st[i].end()) z=0;
			else z=(*nxt).x;
			if (y) rt[i]=insert(rt[i],1,n,in[lca(x,y)],-1);
			if (z) rt[i]=insert(rt[i],1,n,in[lca(x,z)],-1);
			if (y&&z) rt[i]=insert(rt[i],1,n,in[lca(y,z)],1);
			st[i].insert(node(in[x],x));
		}
	}
	ans=0;
	while (T--){
		b=read();
		if (b==1){
			x=read(); L=read(); R=read();
			x^=ans*opt; L^=ans*opt; R^=ans*opt;
			push(L-1);
			push(R);
			ans=query(rt[L-1],rt[R],1,n,1,ot[x],L,R);
			push(L-1);
			push(R);
			if (in[x]-1) ans-=query(rt[L-1],rt[R],1,n,1,in[x]-1,L,R);
			printf("%d\n",ans);
		}
		else{
			x=read(); col=read();
			x^=ans*opt; col^=ans*opt;
			if (c[x]==col) continue;
			st[c[x]].erase(node(in[x],x));
			
			it=pre=nxt=st[c[x]].lower_bound(node(in[x],x));
			if (pre==st[c[x]].begin()) y=0;
			else y=(*--pre).x;
			if (nxt==st[c[x]].end()) z=0;
			else z=(*nxt).x;
			add(c[x],in[x],-1);
			if (y) add(c[x],in[lca(x,y)],1);
			if (z) add(c[x],in[lca(x,z)],1);
			if (y&&z) add(c[x],in[lca(y,z)],-1);
			c[x]=col;
			
			it=pre=nxt=st[c[x]].lower_bound(node(in[x],x));
			if (pre==st[c[x]].begin()) y=0;
			else y=(*--pre).x;
			if (nxt==st[c[x]].end()) z=0;
			else z=(*nxt).x;
			add(c[x],in[x],1);
			if (y) add(c[x],in[lca(x,y)],-1);
			if (z) add(c[x],in[lca(x,z)],-1);
			if (y&&z) add(c[x],in[lca(y,z)],1);
			
			st[c[x]].insert(node(in[x],x));
		}
	}
	return 0;
}
/*
5 5 1
4 1 1 5 4
5 1
3 5
2 3
4 3
2 2 2
1 3 1 5
2 1 2
1 1 2 7
*/
