while true;
do
./gen
./60pts
./string
if diff 60pts.out string.out;then
echo Accepted!
else
echo Wrong Answer!
exit 0
fi
done
