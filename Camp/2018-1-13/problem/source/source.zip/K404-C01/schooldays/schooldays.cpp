//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=1000007;
const int mod=1000000007;
typedef long long LL;
using namespace std;
int n,c[N],d[N];
LL f[N],g[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
#endif
	read(n);
	memset(f,-1,sizeof(f));
	f[0]=0; g[0]=1;
	for(int i=1;i<=n;i++) {read(c[i]); read(d[i]);}
	for(int i=1;i<=n;i++) {
		int mi=d[i],mx=c[i];
		for(int j=i;j>=1;j--) {
			mi=min(mi,d[j]); mx=max(mx,c[j]);
			if(i-j+1>mi) break;
			if(i-j+1<mx) continue;
			if(f[j-1]!=-1) {
				if(f[i]==-1||f[i]<f[j-1]+1) {
					f[i]=f[j-1]+1;
					g[i]=g[j-1];
				}
				else if(f[i]==f[j-1]+1) {
					g[i]=(g[i]+g[j-1])%mod;
				}
			}
		}
	}
	if(f[n]==-1) puts("-1");
	else printf("%lld %lld\n",f[n],g[n]);
	return 0;
}
