#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=100010;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
}
int n,Q,T,lstans;
int bgn[N],nxt[N<<1],to[N<<1],E;
int ls[N],rs[N],q[N],dfs_cnt;
int a[N],vis[N];
inline void add_edge(int u,int v){nxt[++E]=bgn[u],bgn[u]=E,to[E]=v;}
inline void dfs(int u,int f)
{
	q[ls[u]=++dfs_cnt]=u;
	for(int v,i=bgn[u];i;i=nxt[i])
	{
		if((v=to[i])==f)continue;
		dfs(v,u);
	}
	rs[u]=dfs_cnt;
}
int main()
{
	int type,x,y,z;
	file();
	read(n),read(Q),read(T);
	For(i,1,n)read(a[i]);
	For(i,2,n)
	{
		read(x),read(y);
		add_edge(x,y),add_edge(y,x);
	}
	dfs(1,0);
	while(Q--)
	{
		read(type);
		if(type==1)
		{
			read(x),read(y),read(z);
			if(T)x^=lstans,y^=lstans,z^=lstans;
			int ans=0;
			For(i,ls[x],rs[x])if(y<=a[i]&&a[i]<=z&&!vis[a[i]])vis[a[i]]=1,ans++;
			For(i,ls[x],rs[x])if(y<=a[i]&&a[i]<=z&&vis[a[i]])vis[a[i]]=0;
			printf("%d\n",lstans=ans);
		}
		else
		{
			read(x),read(y);
			if(T)x^=lstans,y^=lstans;
			a[x]=y;
		}
	}
	return 0;
}
