#include <bits/stdc++.h>

int main()
{
	freopen("string.in", "w", stdout);

	srand(time(0));
	int T = 20; printf("%d\n", T);
	while(T--){
//		srand(time(0));
		int n = rand() % 6 + 1;
		int opt = rand() % 5;

		if(!opt) printf("%d\n", n);
		else if(opt <= 2) printf("%d\n", (n << 1) + 1);
		else printf("%d\n", n << 1);

		char s[100];
		for(int i = 1; i <= n; ++i){
			s[i] = rand() % 4 + 'a';
			putchar(s[i]);
		}
		if(opt){
			if(opt <= 2) putchar(rand() % 4 + 'a');
			for(int i = n; i >= 1; --i) putchar(s[i]);
		}
		puts("");
	}
	return 0;
}
