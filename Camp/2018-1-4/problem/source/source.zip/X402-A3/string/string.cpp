#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 510
int n,m,l[N],ans;
char a[N],s[N][N];
bool check(char *s,int poss,char *t,int post,int len)
{
	fr(i,0,len-1)
		if(s[poss+i]!=t[post+i])
			return 0;
	return 1;
}
bool find(char *s,int ls,char *t,int lt)
{
	fr(i,1,ls-lt+1)
		if(check(s,i,t,1,lt))
			return 1;
	return 0;
}
#define mod 998244353
void dfs(int x)
{
	if(x==m+1)
	{
		fr(i,m+1,m+m)
			a[i]=a[m+m-i+1]^1;
//		fr(i,1,m+m)
//			putchar(a[i]+'0');
		fr(i,1,n)
			if(!find(a,m+m,s[i],l[i]))
			{
//				printf(" N\n");
				return;
			}
//		printf(" Y\n");
		ans++;
		if(ans>mod)
			ans-=mod;
		return;
	}
	dfs(x+1);
	a[x]^=1;
	dfs(x+1);
}
int main()
{
	freopen("string.out","w",stdout);
	freopen("string.in","r",stdin);
	n=read();
	m=read();
	fr(i,1,n)
	{
		scanf("%s",s[i]+1);
		l[i]=strlen(s[i]+1);
		fr(j,1,l[i])
			s[i][j]-=48;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}