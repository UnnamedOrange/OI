#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=510,maxm=1010,INF=0x3f3f3f3f;
int n,W,p,q,w[maxn],ans;
struct info{
    int x,y,z,a,b,c,d,e,f;
} t[maxm];
struct data{
    int x,y,op;
} lim[maxm];
int main(){
    freopen("variable.in","r",stdin);
    freopen("variable.out","w",stdout);
    int _; read(_);
    while(_--){
        ans=INF;
        read(n); read(W); read(p); read(q);
        for(int i=1;i<=p;i++){
            read(t[i].x); read(t[i].y); read(t[i].z);
            read(t[i].a); read(t[i].b); read(t[i].c);
            read(t[i].d); read(t[i].e); read(t[i].f);
        }
        for(int i=1;i<=q;i++){
            read(lim[i].x); read(lim[i].y); read(lim[i].op);
        }
        for(int s=0;s<(1<<n);s++){
            int sum=0;
            for(int i=1;i<=n;i++) sum+=(w[i]=(s&(1<<(i-1)))?W:-W);
            bool flag=1;
            for(int i=1;i<=q;i++){
                if(lim[i].op==0&&w[lim[i].x]>w[lim[i].y]){ flag=0; break; }
                if(lim[i].op==1&&w[lim[i].x]!=w[lim[i].y]){ flag=0; break; }
                if(lim[i].op==2&&w[lim[i].x]>=w[lim[i].y]){ flag=0; break; }
            }
            if(!flag) continue;
            for(int i=1;i<=p;i++){
                int x=t[i].x,y=t[i].y,z=t[i].z;
                sum+=t[i].a*abs(w[x]-w[y])+t[i].b*abs(w[y]-w[z])+t[i].c*abs(w[z]-w[x]);
                sum+=t[i].d*(w[x]-w[y])+t[i].e*(w[y]-w[z])+t[i].f*(w[z]-w[x]);
            }
            chkmin(ans,sum);
        }
        printf("%d\n",ans);
    }
    return 0;
}
