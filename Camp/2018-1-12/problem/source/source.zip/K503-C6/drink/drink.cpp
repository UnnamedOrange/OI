#include <bits/stdc++.h>

#define lc k << 1
#define rc k << 1 | 1

#define eps 1e-11

using namespace std;

int n;
int a[2000005];
int id[2000005];
int pre[2000005], nxt[2000005];
int cmp(int x, int y){
	return a[x] < a[y];
}
double ans = 0;
const int MAXSIZE=50000020;
int bufpos;
char buf[MAXSIZE];
int re(){
    int val=0;
    for(;buf[bufpos]<'0' || buf[bufpos]>'9';bufpos++);
    for(;buf[bufpos]>='0' && buf[bufpos]<='9' ;bufpos++)
        val=val*10+buf[bufpos]-'0';
    return val;
}
int main(){
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	buf[fread(buf,1,MAXSIZE,stdin)]='\0';
    bufpos=0;
	n = re();
	//printf("%.10lf", log(2));
	for(int i = 1; i <= n; i ++) a[i] = re();
	for(int i = 1; i <= n; i ++) id[i] = i;
	sort(id + 1, id + n + 1, cmp);
	for(int i = 1; i <= n; i ++){
		pre[i] = i - 1;
		nxt[i] = i + 1;
	}
	for(int i = 1; i <= n; i ++){
		double res = 0, res2 = 0;
		double tmp = 1;
		int pos = id[i];
		int t = pos;
		while(tmp * a[i] > eps && t != 0){
			res = res + (t - pre[t]) * tmp;
			t = pre[t];
			tmp = tmp / 2;
		}
		tmp = 1;
		t = pos;
		while(tmp * a[i] > eps && t != n + 1){
			res2 = res2 + (nxt[t] - t) * tmp;
			t = nxt[t];
			tmp = tmp / 2;
		}
		ans = ans + res * res2 * a[pos];
		if(nxt[pos] != n + 1){
			pre[nxt[pos]] = pre[pos];
		}
		if(pre[pos] != 0){
			nxt[pre[pos]] = nxt[pos];
		}
	}
	ans = ans / 2 / n / n;
	printf("%.12lf\n", ans);
	return 0;
}
