#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#define ele int
#define ll long long
using namespace std;
#define MOD 1000000007
ele n,a,b,x[100010];
namespace t1{
	const ele maxn=10;
	struct st{
		ele p,a[6];
		inline bool operator<(st b)const{
			if (p!=b.p) return p<b.p;
			for (int i=0; i<6; ++i)
				if (a[i]!=b.a[i]) return a[i]<b.a[i];
			return false;
		}
	};
	ele cnt[6],fac[maxn],ifac[maxn],ans[4];
	map<st,ele> dp;
	inline ele pw(ele a,ele x){
		ele ans=1,tmp=a%MOD;
		for (; x; x>>=1,tmp=(ll)tmp*tmp%MOD)
			if (x&1) ans=(ll)ans*tmp%MOD;
		return ans;
	}
	inline ele C(ele n,ele m){
		if (m>n) return 0;
		return (ll)fac[n]*ifac[m]%MOD*ifac[n-m]%MOD;
	}
	inline ele calc(ele c1,ele c2){
		if (c1)
			if (c2) return 2;
			else return 0;
		else if (c2) return 1;
			else return 3;
	}
	ele solve(ele p,ele s,ele t,ele u,ele v,ele w){
		if (!s && !t && !u && !v && !w) return 0;
		st s1=(st){p,{0,s,t,u,v,w}};
		if (dp.find(s1)!=dp.end()) return dp[s1];
		ele res=0;
		if (!p){
			for (int i=1; i<=5; ++i)
				if (i>=a){
					st s2=s1;
					if (!s2.a[i]) continue;
					--s2.a[i]; ++s2.a[i-a];
					res=res || !solve(p^1,s2.a[1],s2.a[2],s2.a[3],s2.a[4],s2.a[5]);
				}
		}
		else{
			for (int i=1; i<=5; ++i)
				if (i>=b){
					st s2=s1;
					if (!s2.a[i]) continue;
					--s2.a[i]; ++s2.a[i-b];
					res=res || !solve(p^1,s2.a[1],s2.a[2],s2.a[3],s2.a[4],s2.a[5]);
				}
		}
		return dp[s1]=res;
	}
	void work(){
		fac[0]=ifac[0]=1;
		for (int i=1; i<=n; ++i){
			fac[i]=(ll)fac[i-1]*i%MOD;
			ifac[i]=pw(fac[i],MOD-2);
		}
		memset(cnt,0,sizeof(cnt));
		for (int i=0; i<n; ++i) ++cnt[x[i]];
		dp.clear();
		for (int s=0; s<=cnt[1]; ++s)
			for (int t=0; t<=cnt[2]; ++t)
				for (int u=0; u<=cnt[3]; ++u)
					for (int v=0; v<=cnt[4]; ++v)
						for (int w=0; w<=cnt[5]; ++w){
							ele c1=solve(0,s,t,u,v,w);
							ele c2=solve(1,s,t,u,v,w);
							ele c=calc(c1,c2);
							ans[c]+=(ll)C(cnt[1],s)*C(cnt[2],t)%MOD*C(cnt[3],u)%MOD*C(cnt[4],v)%MOD*C(cnt[5],w)%MOD;
							ans[c]%=MOD;
						}
		printf("%d %d %d %d\n",ans[0],ans[1],ans[2],ans[3]);
	}
}
namespace t2{
	const ele maxn=100010;
	ele bin[maxn];
	void work(){
		bin[0]=1;
		for (int i=1; i<=n; ++i) bin[i]=(bin[i-1]+bin[i-1])%MOD;
		ele c1=0,c2=0;
		for (int i=0; i<n; ++i)
			if ((x[i]/a)&1) ++c1; else ++c2;
		if (c1){
			ele t=(ll)bin[c1-1]*bin[c2]%MOD;
			printf("0 0 %d %d\n",t,t);
		}
		else printf("0 0 0 %d\n",bin[n]);
	}
}
namespace t3{
	const ele maxn=100010;
	ele bin[maxn],f[maxn],g[maxn],ans[4],fac[maxn],ifac[maxn];
	inline ele pw(ele a,ele x){
		ele ans=1,tmp=a%MOD;
		for (; x; x>>=1,tmp=(ll)tmp*tmp%MOD)
			if (x&1) ans=(ll)ans*tmp%MOD;
		return ans;
	}
	inline ele C(ele n,ele m){
		if (m>n) return 0;
		return (ll)fac[n]*ifac[m]%MOD*ifac[n-m]%MOD;
	}
	void work(){
		for (int i=0; i<n; ++i) x[i]%=(a+b);
		fac[0]=ifac[0]=1; bin[0]=1;
		for (int i=1; i<=n; ++i){
			fac[i]=(ll)fac[i-1]*i%MOD;
			ifac[i]=pw(fac[i],MOD-2);
			bin[i]=(bin[i-1]+bin[i-1])%MOD;
		}
		for (int i=0; i<n; ++i)
			f[i]=(x[i]>=a),g[i]=(x[i]>=b);
		ele u=0,v=0,w=0,x=0;
		for (int i=0; i<n; ++i)
			if (f[i])
				if (g[i]) ++w;
				else ++u;
			else if (g[i]) ++v;
				else ++x;
		ele s=bin[v];
		ele s1=0;
		for (int i=0; i<=u; ++i){
			(ans[0]+=(ll)s1*C(u,i)%MOD)%=MOD;
			if (i<=v){
				(ans[1]+=(ll)C(u,i)*((s-C(v,i)+MOD)%MOD)%MOD)%=MOD;
				(s1+=C(v,i))%=MOD;
				(s+=MOD-C(v,i))%=MOD;
			}
		}
		ans[0]=(ll)ans[0]*bin[w]%MOD*bin[x]%MOD;
		ans[1]=(ll)ans[1]*bin[w]%MOD*bin[x]%MOD;
		if (w) ans[2]=ans[3]=bin[w-1]; else ans[2]=0,ans[3]=1;
		s=0;
		for (int i=0; i<=min(u,v); ++i) (s+=(ll)C(u,i)*C(v,i)%MOD)%=MOD;
		ans[2]=(ll)ans[2]*s%MOD*bin[x]%MOD;
		ans[3]=(ll)ans[3]*s%MOD*bin[x]%MOD;
		printf("%d %d %d %d\n",ans[0],ans[1],ans[2],ans[3]);
	}
}
int main(){
	freopen("stone.in","r",stdin); freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	bool f1=(n<=5),f2=(a==b),f3=(a==1);
	for (int i=0; i<n; ++i){
		scanf("%d",x+i);
		if (x[i]>5) f1=false;
	}
	if (f1) t1::work();
	else if (f2) t2::work();
	else t3::work();
	return 0;
}