#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
long long a[1000010],b[1000010],v[2010][2010],d[1000010],f[1000010];
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	long long i,j,k,m,n;
	scanf("%lld",&n);
	for(i=1;i<=n;i++)
	    scanf("%lld%lld",&a[i],&b[i]);
	for(i=1;i<=n;i++){
		long long maxx=0,minn=100000000;
	    for(j=i;j<=n;j++){
	        maxx=max(maxx,a[j]);
	        minn=min(minn,b[j]);
	        if(j-i+1<=minn && j-i+1>=maxx)
	            v[i][j]=1;
	        else v[i][j]=0;
	    }
	}
	d[0]=1;
	for(i=1;i<=n;i++)
	    for(j=0;j<i;j++)
	        if(v[j+1][i]){
	        	if(f[j]+1==f[i])d[i]=(d[i]+d[j])%1000000007;
	        	if(f[j]+1>f[i]){
	        		f[i]=f[j]+1;
	        		d[i]=d[j];
	        	}
	        }
	if(d[n]!=0)
	printf("%lld %lld\n",f[n],d[n]);
	else printf("-1\n");
	return 0;
}

