#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=550;
const int Q=1050;

int n,p,q;
int W,w[N];

struct SHIZI
{
	int x,y,z,a,b,c,d,e,f;
}h[Q];
struct REQ
{
	int x,y,opt;
}req[Q];


void wj()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	T=read();
	for(int cas=1;cas<=T;++cas)
	{
		n=read(); W=read(); p=read(); q=read();
		for(i=1;i<=p;++i)
			h[i].x=read(),h[i].y=read(),h[i].z=read(),h[i].a=read(),
			h[i].b=read(),h[i].c=read(),h[i].d=read(),h[i].e=read(),h[i].f=read();
		for(i=1;i<=q;++i) req[i].x=read(),req[i].y=read(),req[i].opt=read();
		int tot=1<<n;
		ll minn=1e18;
		for(int s=0;s<tot;++s)
		{
			for(i=1;i<=n;++i) 
			{
				if(s&(1<<i-1)) w[i]=W;
				else w[i]=-W;
			}
			bool can=1;
			for(i=1;i<=q;++i)
			{
				if(!req[i].opt)
				{
					if(w[req[i].x]>w[req[i].y]) {can=0;break;}
				}
				else if(req[i].opt==1)
				{
					if(w[req[i].x]!=w[req[i].y]) {can=0;break;}
				}
				else 
				{
					if(w[req[i].x]>=w[req[i].y]) {can=0;break;}
				}
			}
			if(!can) continue;
			ll ans=0;
			for(i=1;i<=n;++i) ans+=w[i];
			for(i=1;i<=p;++i)
			{
				ans+=(ll)h[i].a*abs(w[h[i].x]-w[h[i].y])+h[i].b*abs(w[h[i].y]-w[h[i].z])
				+(ll)h[i].c*abs(w[h[i].z]-w[h[i].x])+(ll)h[i].d*(w[h[i].x]-w[h[i].y])
				+(ll)h[i].e*(w[h[i].y]-w[h[i].z])+(ll)h[i].f*(w[h[i].z]-w[h[i].x]);
			}
			minn=min(minn,ans);
		}
		printf("%lld\n",minn);
	}
	return 0;
}
