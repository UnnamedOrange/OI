#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bomb.in","r",stdin);
	int n;
	cin>>n;
	if(n*n%123<60)
		system("bomb.exe");
	else
		while(1);
}
