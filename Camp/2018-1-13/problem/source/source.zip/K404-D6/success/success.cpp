#include<cstdio>
inline int min(int a,int b){
	return a<b?a:b;
}
const int mod=1000000007;
int f[1001][1001];
int s,t,n,m,ans;
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	f[0][0]=1;
	for(register int i=1;i<=s;++i)
		for(register int j=1;j<=m;++j){
			if(j<=n)
				for(register int k=min(i,t);k;--k)
					f[i][j]=(f[i][j]+f[i-k][j-1])%mod;
			else
				for(register int k=min(i,s);k;--k)
					f[i][j]=(f[i][j]+f[i-k][j-1])%mod;
		}
	for(register int i=1;i<=s;++i)
		ans=(ans+f[i][m])%mod;
	printf("%d\n",ans);
	return 0;
}
