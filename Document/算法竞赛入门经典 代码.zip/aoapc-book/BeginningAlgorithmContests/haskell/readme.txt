﻿《算法竞赛入门经典》Haskell代码

刘汝佳

Haskell是一门很特别的语言，也是笔者最喜欢的语言之一。

虽然笔者在工作中完全没有使用Haskell，但平时偶尔会拿它写点小东西

笔者对Haskell只是略懂一二，也缺乏实践经验，所以这里的代码难免包含一些土鳖的东西，欢迎拍砖 :)

顺便说一句，如果你对学习Haskell有兴趣，推荐阅读《Learn You a Haskell for Great Good！》

http://learnyouahaskell.com/

这本书很适合初学者阅读，但篇幅比较长，而且有些内容仍然颇有难度。如果你希望快速入门的话，《Haskell Fast & Hard》可能更好：

https://www.fpcomplete.com/school/haskell-fast-hard

关于如何学习Haskell，网上的资料非常多，这里就不赘述了 :)
