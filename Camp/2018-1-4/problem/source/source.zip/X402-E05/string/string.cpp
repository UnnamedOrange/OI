#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define fst first
#define snd second
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int M=510;
const int N=1210;
const int inf=0x3f3f3f3f;
const int mod=998244353;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
}
int m,n,a[N],ans;
char s[N];
int c[N][2],to[N][2],rt,tot,w[N][2],f[N];
int G[N][N],dp[2][M][M][1<<6],fa[N];
inline void init(){c[0][0]=c[0][1]=1;rt=tot=f[0]=1;}
inline void insert(char *s,int val)
{
	int p1=rt,p2=rt,len=strlen(s)-1;
	For(i,0,len)
	{
		int x=s[i]-'0';
		if(!c[p1][x])
		{
			c[p1][x]=++tot,to[p1][x]=tot;
			fa[tot]=p1;
		}
		p1=c[p1][x];
		x=s[len-i]-'0';
		if(!c[p2][x])
		{
			c[p2][x]=++tot,to[p2][x]=tot;
			fa[tot]=p2;
		}
		p2=c[p2][x];
	}
	w[p1][0]|=val;
	w[p2][1]|=val;
}
inline void Get_f(int x)
{
	For(i,0,1)
	{
		int ret=c[f[x]][i];
		if(c[x][i])
		{
			f[c[x][i]]=ret;
			w[c[x][i]][0]|=w[ret][0];
			w[c[x][i]][1]|=w[ret][1];
		}
		else c[x][i]=ret;
	}
}
inline void Get_fail()
{
	queue<int>q;int x;
	for(q.push(rt);!q.empty();Get_f(x))
	{
		x=q.front();q.pop();
		For(i,0,1)if(c[x][i])q.push(c[x][i]);
	}
}
inline void Get_ans()
{
	For(st,1,tot)
	{
		queue<pii>q;
		q.push(pii(st,1));
		G[st][1]=w[st][0];
		while(!q.empty())
		{
			pii now=q.front();q.pop();
			For(i,0,1)
			{
				int v=to[now.snd][i],v1=c[now.fst][i];
				if(v)
				{
					G[st][v]=G[st][now.snd]|w[v1][0];
					q.push(pii(v1,v));
				}
			}
		}
	}
}
struct node
{
	int x,y,st;
	node(){}
	node(int x,int y,int st):x(x),y(y),st(st){}
};
inline void Add(int &x,int y){x=x+y<mod?x+y:x+y-mod;}
inline int check(int x,int y)
{
	int ret=w[x][0];
	while(y!=1)
	{
		int nxt=c[fa[y]][1]==y;
		y=fa[y];
		x=c[x][nxt];
		ret|=w[x][0];
	}
	return ret;
}
inline void Solve()
{
	queue<node>q[2];
	q[0].push(node(1,1,0));
	dp[0][1][1][0]=1;
	For(i,0,m-1)
	{
		int now=i&1,nxt=!(i&1);
		while(!q[now].empty())
		{
			node u=q[now].front();q[now].pop();
			int &ret=dp[now][u.x][u.y][u.st];
			if(!ret)continue;
			For(i,0,1)
			{
				int tox=c[u.x][i];
				int toy=c[u.y][!i];
				Add(dp[nxt][tox][toy][u.st|w[tox][0]|w[toy][1]],ret);
				q[nxt].push(node(tox,toy,u.st|w[tox][0]|w[toy][1]));
			}
			ret=0;
		}
	}
	int now=m&1;
	while(!q[now].empty())
	{
		node u=q[now].front();q[now].pop();
		int &ret=dp[now][u.x][u.y][u.st];
		if((check(u.x,u.y)|u.st)==(1<<n)-1)Add(ans,ret);
		ret=0;
	}
	printf("%d\n",ans);
}
int main()
{
	file();
	init();
	read(n),read(m);
	For(i,1,n)
	{
		scanf("%s",s);
		insert(s,1<<(i-1));
	}
	Get_fail();
	Solve();
	//cerr<<(double)clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
