#include<iostream>
#include<cstdio>
#define in(x) freopen(x,"r",stdin)
#define out(x) freopen(x,"w",stdout)
#define LL long long
#define mod 1000000007
#define NN 1010000+10
using namespace std;
LL sum=0;
int lim=0,st=0,num=0;
LL fact[NN]={0},rev[NN]={0};
LL ksm(LL a,LL b){
	LL op=1;
	while(b){
		if(b&1){
			(op*=a)%=mod;
		}
		b>>=1;
		(a*=a)%=mod;
	}
	return op;
}
initi_fact(int n){
	fact[0]=rev[0]=rev[1]=1;
	for(int i=1;i<=n;++i){
		fact[i]=fact[i-1]*i%mod;
	}
	rev[n]=ksm(fact[n],mod-2);
	for(int i=n-1;i>=1;--i){
		rev[i]=rev[i+1]*(i+1)%mod;
	}
}
LL brute_(){
	initi_fact(sum);
	LL ans=0,fl=1,tp=0;
	for(int i=0;i<=st&&sum-num-i*lim>=0;++i){
		tp=fl;
		tp*=fact[st];
		(tp*=fact[sum-i*lim])%=mod;
		(tp*=rev[i])%=mod;
		(tp*=rev[st-i])%=mod;
		(tp*=rev[num])%=mod;
		(tp*=rev[sum-num-i*lim])%=mod;
		(ans+=tp)%=mod;
		fl=-fl;
	}
	return ans;
}
		
int main(){
	in("success.in");
	out("success.out");
	scanf("%lld%d%d%d",&sum,&lim,&st,&num);
	if(sum<num){
		printf("0");
		return 0;
	}
	if(sum<=1010000){
		printf("%lld",brute_());
		return 0;
	}
}
