#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
typedef long long LL;
const int N=405,mod=998244353;
int n,m,tp,k;
LL f[2][N][N],g[2][N][N],flv[N];

LL getmi(LL a,LL x)
{
	LL rt=1;
	while(x)
	{
		if(x&1) rt=rt*a%mod;
		a=a*a%mod,x>>=1;
	}
	return rt;
}

int inc(int x,int y)
{
	return x+y>=mod?x+y-mod:x+y;
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&m,&n,&k);
	if(m>n) {puts("0"); return 0;}
	rep(i,1,m) flv[i]=getmi(i,k);
	f[0][0][0]=1;
	rep(i,0,n-1)
	{
		tp^=1,memset(f[tp],0,sizeof(f[tp]));
		memset(g[tp],0,sizeof(g[tp]));
		rep(nw,0,min(i,m))
			rep(j,0,nw)
			{
				LL tmp=f[tp^1][j][nw],incg=g[tp^1][j][nw];
				f[tp][j][nw]=inc(f[tp][j][nw],tmp);
				g[tp][j][nw]=(g[tp][j][nw]+incg+(LL)tmp*flv[j])%mod;
				if(j)
				{
					f[tp][j-1][nw]=inc(f[tp][j-1][nw],tmp);
					g[tp][j-1][nw]=(g[tp][j-1][nw]+incg+(LL)tmp*flv[j-1])%mod;
				}
				if(nw<m)
				{
					f[tp][j+1][nw+1]=inc(f[tp][j+1][nw+1],tmp);
					g[tp][j+1][nw+1]=(g[tp][j+1][nw+1]+incg+(LL)tmp*flv[j+1])%mod;
				
					f[tp][j][nw+1]=inc(f[tp][j][nw+1],tmp);
					g[tp][j][nw+1]=(g[tp][j][nw+1]+incg+(LL)tmp*flv[j])%mod;
				}
			}
	}
	printf("%lld\n",g[tp][0][m]);
	return 0;
}
