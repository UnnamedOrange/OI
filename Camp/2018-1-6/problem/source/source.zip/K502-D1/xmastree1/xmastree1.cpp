#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <bitset>

using namespace std;

const int MAXN = 5010;
bitset<MAXN> temp, init, ans;
int n, q, t;
int cnt = 0;
int lastans = 0;
int in[MAXN], out[MAXN];
int head[MAXN], vis[MAXN];
int c[MAXN], m[MAXN];
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

struct edge {
	int v;
	int next;
} g[2 * MAXN];

struct segmentree {
	bitset<MAXN> f;
} seg[MAXN * 8];
void open()
{
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}

void addedge(int u, int v)
{
	g[++cnt].v = v;
	g[cnt].next = head[u];
	head[u] = cnt;
}

void DFS(int x)
{
	vis[x] = 1;
	in[x] = ++cnt;
	m[in[x]] = x;
	for(int j = head[x]; j; j = g[j].next) {
		int to =  g[j].v;
		if(!vis[to]) {
			DFS(to);
		}
	}
	out[x] = cnt;
}

void build(int l, int r, int root)
{
	if(l == r) {
		seg[root].f[c[m[l]]] = 1;
		return;
	}
	int mid = (l + r) >> 1;
	build(l, mid, root * 2);
	build(mid + 1, r, root * 2 + 1);
	seg[root].f = seg[root * 2].f | seg[root * 2 + 1].f;
}

void update(int u, int l, int r, int k, int root)
{
	if(l == r) {
		seg[root].f = seg[root].f & init;
		seg[root].f[k] = 1;
		return;
	}
	int mid = (l + r) >> 1;
	if(u <= mid) {
		update(u, l, mid, k, root * 2);
	} else {
		update(u, mid + 1, r, k, root * 2 + 1);
	}
	seg[root].f = seg[root * 2].f | seg[root * 2 + 1].f;
}

void query(int ql, int qr, int l, int r, int root)
{
	if(l >= ql && r <= qr) {
		ans = ans | seg[root].f;
		return;
	}
	int mid = (l + r) >> 1;
	if(ql <= mid) {
		query(ql, qr, l, mid, root * 2);
	}
	if(qr > mid) {
		query(ql, qr, mid + 1, r, root * 2 + 1);
	}
}
int main()
{
	open();
//	cout<<sizeof(seg) / 1024 / 1024<<endl;
	n = read(), q = read(), t = read();
	for(int i = 1; i <= n; i++) {
		c[i] = read();
	}
	for(int i = 1; i < n; i++) {
		int u, v;
		u = read(), v = read();
		addedge(u, v);
		addedge(v, u); 
	}
	cnt = 0;
	DFS(1);
	/*for(int i = 1; i <= n; i++) {
		cout<<in[i]<<" "<<out[i]<<endl;
	}*/
	build(1, n, 1);
	while(q--) {
		int opr, u;
		opr = read();
		u = read();
		if(t) {
			u = u ^ lastans;	
		}
		if(opr == 1) {
			int l, r;
			ans = ans & init;
			l = read(), r = read();
			if(t) {
				l = l ^ lastans, r = r ^ lastans;
			}
			query(in[u], out[u], 1, n, 1);
			long long sum = 0;
			for(int i = l; i <= r; i++) {
				sum += ans[i];
			}
			printf("%lld\n", sum);
			lastans = sum;
		} else {
			int color;
			color = read();
			if(t)
				color = color ^ lastans;
			update(in[u], 1, n, color, 1);
		}
	}
	close();
	return 0;
}
