#include<cstdio>
#include<algorithm>
#include<map>
using namespace std;
typedef long long ll;
const int mod=1e9+9,X=19260817;
map<ll,int>mp;
map<ll,int>vis;
int a[1500001],b[1500001],d[15000001],c[1500001];
int n,m,ans;
struct line{
	int l,r;
}p[101];
inline void disc_init(){
	sort(b+1,b+b[0]+1);
	b[0]=unique(b+1,b+b[0]+1)-b-1;
	for(register int i=1;i<=n;++i)
		p[i].l=lower_bound(b+1,b+b[0]+1,p[i].l)-b,p[i].r=lower_bound(b+1,b+b[0]+1,p[i].r)-b;
	for(register int i=1;i<=m;++i)
		a[i]=lower_bound(b+1,b+b[0]+1,a[i])-b;
}
inline void dfs(int now){
	if(now==n+1){
		c[0]=0;
		for(register int i=1;i<=b[0];++i)
			c[i]=c[i-1]+d[i];
		for(register int i=1;i<=m;++i)
			if(!c[a[i]])
				return ;
		++ans;
		if(ans>=mod)
			ans-=mod;
		return ;
	}
	dfs(now+1);
	++d[p[now].l];--d[p[now].r+1];
	dfs(now+1);
	--d[p[now].l];++d[p[now].r+1];
	return;
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(register int i=1;i<=n;++i){
		scanf("%d%d",&p[i].l,&p[i].r);
		b[++b[0]]=p[i].l;
		b[++b[0]]=p[i].r;
	}
	for(register int i=1;i<=m;++i){
		scanf("%d",a+i);
		b[++b[0]]=a[i];
	}
	disc_init();
	dfs(1);
	printf("%d",ans);
	return 0;
}
/*
20 4
3 8
1 6
3 8
2 7
1 4
5 6
5 7 
9 10
7 7
5 9
9 11
12 13 
16 17
15 19
20 44
22 33
33 44
55 66
77 78
55 55
8 
4
6
3
*/
