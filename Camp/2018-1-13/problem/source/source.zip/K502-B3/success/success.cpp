#include <stdio.h>
using namespace std;

#define ll long long int

const int mod=1000000007;
ll s,t,n,m,ans=0;

inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void dfs(ll x,ll sum)
{
	if(sum>s)
		return;
	if(x==m+1)
	{
		if(sum<=s)
			ans=(ans+1)%mod; 
		return;
	}
	ll i;
	if(x<=n)
	{
		for(i=1;i<=t;i++)
			dfs(x+1,sum+i);
	}
	else
	{
		for(i=1;i<=s-(m-1);i++)
			dfs(x+1,sum+i);
	}
}

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	s=read(),t=read(),n=read(),m=read();
	dfs(1,0);
	printf("%lld",ans%mod);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
