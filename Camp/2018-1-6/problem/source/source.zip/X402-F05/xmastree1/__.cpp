#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for(int i = j; i <= k; i++)
#define Forr(i, j, k) for(int i = j; i >= k; i--)

int Read(){
	char c = getchar();
	while(c > '9' || c < '0') c = getchar();
	int x = c - '0'; c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

using namespace std;

const int N = 1e5 + 10;

int Begin[N], Next[N << 1], to[N << 1], e;

void add(int u, int v){
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int fa[N][18], dep[N], sz[N], son[N];
int idl[N], idr[N], top[N];

void DFS_init(int o){
	sz[o] = 1;
	for(int i = Begin[o]; i; i = Next[i]){
		int u = to[i];
		if(u == fa[o][0]) continue;
		
		fa[u][0] = o;
		For(j, 1, 17) fa[u][j] = fa[fa[u][j - 1]][j - 1];
		dep[u] = dep[o] + 1;

		DFS_init(u);

		sz[o] += sz[u];
		if(sz[u] > sz[son[o]]) son[o] = u;
	}
}

void DFS_decompose(int o){
	static int dfs_clock = 0;
	idl[o] = ++dfs_clock;
	top[o] = son[fa[o][0]] == o ? top[fa[o][0]] : o;

	if(son[o]) DFS_decompose(son[o]);
	for(int i = Begin[o]; i; i = Next[i]){
		int u = to[i];
		if(u == fa[o][0] || u == son[o]) continue;
		DFS_decompose(u);
	}

	idr[o] = dfs_clock;
}

struct Segment_Tree{
	
	const static int Node = 3e7;

	int sum[Node], lc[Node], rc[Node], node;

	#define M ((L + R) >> 1)

	void add(int &o, int L, int R, int x, int v){
		if(!o) o = ++node;
		sum[o] += v;
		if(L ^ R) x <= M ? add(lc[o], L, M, x, v) : add(rc[o], M + 1, R, x, v);
	}

	int query(int o, int L, int R, int l, int r){
		if(!o || (l <= L && R <= r)) return sum[o];
		int ret = 0;
		if(l <= M) ret += query(lc[o], L, M, l, r);
		if(r > M) ret += query(rc[o], M + 1, R, l, r);
		return ret;
	}

	#undef M
}T;

int n, q, type;
int col[N], croot[N];

struct Binary_Indexed_Tree{
	
	int root[N];

	int lowbit(int x){
		return x & (-x);
	}

	void add(int x, int v){
		while(x <= n){
			T.add(root[x], 1, n, x, v);
			x += lowbit(x);
		}
	}

	int sum(int r, int x, int y){
		int ret = 0;
		while(r){
			ret += T.query(root[r], 1, n, x, y);
			r -= lowbit(r);
		}
		return ret;
	}
}BIT;


void modify(int o, int c, int v){
	int down = o;

	T.add(croot[c], 1, n, idl[o], v);
	int s = v == -1 ? 0 : 1;

	if(T.query(croot[c], 1, n, idl[o], idr[o]) != s) return;	
	Forr(i, 17, 0){
		int f = fa[o][i],
			val = T.query(croot[c], 1, n, idl[f], idr[f]);
		if(val == s) o = f;
	}

	BIT.add(idl[down], v);
	if(o != 1) BIT.add(idl[fa[o][0]], -v);
}

int main(){

	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);

	n = Read(), q = Read(), type = Read();
	For(i, 1, n) col[i] = Read();
	For(i, 2, n){
		int u = Read(), v = Read();
		add(u, v), add(v, u);
	}

	DFS_init(1);
	DFS_decompose(1);
	For(i, 1, n) modify(i, col[i], 1);

	int lstans = 0;

	while(q--){
		int ty = Read(), u = Read();

		if(ty == 1){
			int l = Read(), r = Read();
			if(type) u ^= lstans, l ^= lstans, r ^= lstans;
			lstans = BIT.sum(r, idl[u], idr[u]) - BIT.sum(l - 1, idl[u], idr[u]);
			printf("%d\n", lstans);
		}
		else{
			int c = Read();
			if(type) u ^= lstans, c ^= lstans;
			modify(u, col[u], -1);
			col[u] = c;
			modify(u, col[u], 1);
		}
	}

	return 0;
}
