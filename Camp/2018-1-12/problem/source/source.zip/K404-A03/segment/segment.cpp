//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const int maxn=1e5+10;
const ll mod=998244353;
ll n,m,k,t,ans,g[maxn],pp;

ll aa;char cc;
ll read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

ll qp(ll x,ll k) {
	ll rs=1;
	while(k) {
		if(k&1) rs=rs*x%mod;
		k>>=1; x=x*x%mod;
	}
	return rs;
}

int main() {
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=read(); m=read(); k=read();
	if(n>m-1) printf("0");
	else if(n==1){
		swap(n,m);
		for(ll i=1;i<=n;++i) {
			t=i*(n-i+1)%mod;
			ans+=t;
			if(ans>=mod) ans-=mod;
		}
		printf("%lld",ans);
	}
	else if(n==2) {
		swap(n,m);
		pp=qp(2,mod-2);
		for(ll i=n-1;i;--i) g[i]=(g[i+1]+i*i%mod)%mod;
		t=(n*n%mod*(n-1)%mod-g[1]+mod-n*(n-1)/2%mod+mod)%mod*qp(2,k)%mod;
		ans+=t;if(ans>=mod) ans-=mod;
		for(ll i=2;i<=n;++i) {
			ans+=i*(i-1)/2%mod*(n-i+1)%mod*(n-i)%mod;if(ans>=mod) ans-=mod;
			t=(n-i)*n%mod*n%mod-g[i]+mod;
			if(t>=mod) t-=mod; t=t*i%mod;
			ans+=t;if(ans>=mod) ans-=mod;
			t=(2*i*i%mod-5*i%mod+mod+4)%mod*(n-i+1)%mod*(n-i)/2%mod;
			ans-=t;if(ans<0) ans+=mod;
		}
		printf("%lld",ans*pp%mod);
	}
	else printf("orz");
	fclose(stdin);fclose(stdout);
	return 0;
}

