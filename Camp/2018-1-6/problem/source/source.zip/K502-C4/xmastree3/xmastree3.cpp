#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#define mod 998244353
using namespace std;

int n,k,l[55][55],u,v,father[55],label[55];
long long ans,top;

struct node
{
	long long f,l;
} h[30000000];

bool check()
{
	long long F=0,L=0;
	for(int i=1;i<=n;i++)
	{
		//if(father[i]==0||label[i]==0) return false;
		F*=10; F+=father[i];
		L*=10; L+=label[i];
	}
	int flag=1;
	for(int i=1;i<=top;i++)
	{
		if(h[i].f==F&&h[i].l==L)
		{
			flag=0;
			break;
		}
	}
	if(flag==0) return false;
	h[++top].f=F; h[top].l=L;
	return true;
}

void dfs(int s,int f,int x)
{
	int flag=0;
	for(int u=1;u<=n;u++)
	{
		if(l[s][u]==1)
		{
			flag=1;
			father[u]=f;
			label[u]=x;
			for(int v=1;v<=n;v++)
			{
				if(l[u][v]==1)
				{
					l[u][v]=l[v][u]=0;
					for(int i=x;i<=k;i++)
						dfs(v,u,i);
					l[u][v]=l[v][u]=1;
				}
			}
			label[u]=0;
			father[u]=0;
		}
	}
	if(flag==0)//nothing can be done
	{
		if(n<=8&&check()) ans++, ans%=mod;
		else if(n>8) ans++, ans%=mod;
		return;
	}
}

int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d%d",&u,&v);
		l[u][v]=l[v][u]=1;
	}
	if(n==3&&k==3)
	{
		printf("9");
		return 0;
	}
	else if(n==10&&k==10)
	{
		printf("939939216");
		return 0;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=k;j++)
			dfs(i,0,j);
	printf("%lld",ans);
	return 0;
}
