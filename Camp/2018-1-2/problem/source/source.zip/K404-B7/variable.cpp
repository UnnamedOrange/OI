 #include<bits/stdc++.h>
 #define ll long long
using namespace std;
 
int getint()
{
    int i=0,f=1;char c;
    for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
    if(c=='-')c=getchar(),f=-1;
    for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
    return i*f;
}

const int N=1005;
int T,n,W,p,q,w[N];
ll ans;

struct node
{
	int x,y,z,a,b,c,d,e,f;
	ll h()
	{
		return 1ll*a*abs(w[x]-w[y])+1ll*b*abs(w[y]-w[z])+1ll*c*abs(w[z]-w[x])+1ll*d*(w[x]-w[y])+1ll*e*(w[y]-w[z])+1ll*f*(w[z]-w[x]);
	}
}f[N];
struct node1
{
	int op,x,y;
	bool ok()
	{
		if(op==0)return w[x]<=w[y];
		if(op==1)return w[x]==w[y];
		if(op==2)return w[x]<w[y];
	}
}d[N];

bool check()
{
	for(int i=1;i<=q;i++)
		if(!d[i].ok())return false;
	return true;
}

void dfs(int x)
{
	if(x==n+1)
	{
		if(check())
		{
			ll tmp=0;
			for(int i=1;i<=n;i++)tmp+=w[i];
			for(int i=1;i<=p;i++)tmp+=f[i].h();
			ans=min(ans,tmp);
		}
		return;
	}
	w[x]=W;dfs(x+1);
	w[x]=-W;dfs(x+1);
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	T=getint();
	while(T--)
	{
		n=getint(),W=getint(),p=getint(),q=getint();
		for(int i=1;i<=p;i++)
		{
			f[i].x=getint(),f[i].y=getint(),f[i].z=getint();
			f[i].a=getint(),f[i].b=getint(),f[i].c=getint();
			f[i].d=getint(),f[i].e=getint(),f[i].f=getint();
		}
		for(int i=1;i<=q;i++)
			d[i].x=getint(),d[i].y=getint(),d[i].op=getint();
		ans=1e18;
		dfs(1);
		printf("%lld\n",ans);
	}
	return 0;
}
