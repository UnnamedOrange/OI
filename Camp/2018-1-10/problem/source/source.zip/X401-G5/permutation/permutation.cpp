#include<bits/stdc++.h>
using namespace std;
bool boo[1000000],bo[1000000];
int a[1000000],n,ans;
const long long kcz=998244353;
bool ddfs(int i){
	bo[i]=1;
	if (bo[a[i]]) return 1;
	else return !ddfs(a[i]);
}
void dfs(int i){
	if (i>n)
	{
		for (int i=1;i<=n;i++)
		  bo[i]=0;
		for (int i=1;i<=n;i++)
		if (!bo[i])
			if (ddfs(i)) return;
		ans++;
		return;
	}
			
	if (a[i]!=0)
	  dfs(i+1);
	  else 
	  	for (int j=1;j<=n;j++)
	  	if (j!=i)
	  	if (!boo[j])
	  	{
	  		a[i]=j;
	  		boo[j]=1;
	  		dfs(i+1);
	  		boo[j]=0;
	  		a[i]=0;
	  	}
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		boo[a[i]]=1;
	}
	if (n<=8) 
	{
		dfs(1);
		cout<<ans;
		return 0; 
	}
	for (int i=1;i<=n;i++)
	if (a[i]!=0) {cout<<0<<endl;return 0;}
		if (n&1) {cout<<0;return 0;}
		long long ans=1;
		for (long long i=1;i<n;i+=2)
		  ans=ans*i*i%kcz;
		cout<<ans;
}
