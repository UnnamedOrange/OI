#include <iostream>
#include <cstdio>
using namespace std;
char buf[200000005], out_buf[200000005]; 
int pos = -1, tp = -1, st[15], out_pos = -1; 
inline int getint()
{
	register int res = 0, ch = buf[++pos]; 
	for (; ch < 48; ch = buf[++pos]); 
	for (; ch >= 48; ch = buf[++pos])
		res = res * 10 + ch - 48; 
	return res; 
}
inline void print(int x)
{
	while (x)
	{
		st[++tp] = x % 10; 
		x /= 10; 
	}
	while (~tp)
		out_buf[++out_pos] = st[tp--] + '0'; 
	out_buf[++out_pos] = '\n'; 
}
namespace encode
{
	inline void solve()
	{
		int n = getint(), t = getint();
		while (t--)
		{
			int x = getint(), y = getint(), cntx = 0, cnty = 0; 
			bool f = false; 
			for (int i = 0; i < 10; i++)
			{
				if ((x & (1 << i)) && !(y & (1 << i)))
				{
					f = true; 
					print(i + 5); 
					break; 
				}
				if (x & (1 << i))
					cntx++; 
				if (y & (1 << i))
					cnty++; 
			}
			if (f)
				continue;
			for (int i = 0; i < 4; i++)
			{
				if (!(cntx & (1 << i)) && (cnty & (1 << i)))
				{
					print(i + 1); 
					break; 
				}
			}
		}
		fwrite(out_buf, 1, out_pos + 1, stdout); 
	}
}
namespace decode
{
	inline void solve()
	{
		int n = getint(), t = getint(); 
		while (t--)
		{
			int q = getint(), h = getint(); 
			if (h >= 5)
				puts(q & (1 << h - 5) ? "yes" : "no"); 
			else
			{
				int x = 0; 
				for (int i = 0; i < 10; i++)
				{
					if (q & (1 << i))
						x++; 
				}
				puts(x & (1 << h - 1) ? "no" : "yes"); 
			}
		}
	}
}
int main()
{
	fread(buf, 1, 200000005, stdin); 
	int t = getint(); 
	if (t == 1)
		encode::solve(); 
	else
		decode::solve();
	return 0; 
}

