#include<bits/stdc++.h>
using namespace std;

int n;
long long w[1100000],b[1100000];
double ans;
double baoli(int l,int r)
{
	double anss=0;
	for (int i=l;i<=r;i++) b[i]=w[i];
	sort(b+l,b+r+1);
	for (int i=l;i<=r;i++) anss=(anss+(double)b[i])/2;
	anss=(anss/n)/n;
	return anss;  
}

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d",&w[i]);
	for (int l=1;l<=n;l++)
	  for (int r=l;r<=n;r++)
	    {
	      ans=ans+baoli(l,r);
		}
	printf("%.10f",ans);
	return 0;	
}
