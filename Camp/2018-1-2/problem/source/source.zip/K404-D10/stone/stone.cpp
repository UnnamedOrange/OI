#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int p=1000000007;

In void upd(int&x, int y)
{x=x+y<p? x+y: x+y-p;}

int main()
{
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
    St int n, a, b;
    scanf("%d%d%d", &n, &a, &b);
    Rg bool flag=0;
    if(a>b) swap(a, b), flag=1;
    Rg int u=0, v=0, w=1;
    inc(0, i, n)
    {
        St int x;
        scanf("%d", &x);
        if(x%(a+b)<a)
        {
            upd(u, u);
            upd(v, v);
            upd(w, w);
        }
        else
            if(x%(a+b)<b)
                upd(u, ((ll)u+v+w)%p);
            else
                upd(u, u), v=w=(v+w)%p;
    }
    printf((flag? "0 %d ": "%d 0 "), u);
    printf("%d %d\n", v, w);
    Re 0;
}
