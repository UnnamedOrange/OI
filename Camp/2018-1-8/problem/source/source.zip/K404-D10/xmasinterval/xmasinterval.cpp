//© 2018 Jazengm/ZengXiangru, AllRightsReserved

#include<bits/stdc++.h>
using namespace std;

//#define debugMod
#ifdef debugMod
#define debug(x) x
#endif
#ifndef debugMod
#define debug(x)
#endif

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int mxn=1<<19, p=1000000009;

In void upd(int& a, ll b) {a=((ll)a+b)%p;}

struct interval
{
    int l, r;
    In interval(int a=0, int b=0):
    l(a), r(b) {}
    In bool Op<(interval b) const
    {Re r^b.r? r<b.r: l>b.l;}
} itv[mxn];

const int add=19260817, times=20180118;

int m, type, value;

interval modItv;

#define top int u=1, int l=0, int r=m
#define mid ((l+r)>>1)
#define ls u<<1, l, mid
#define rs u<<1|1, mid+1, r

int timesTag[mxn<<2], addTag[mxn<<2];

In void init()
{
    inc(0, i, m<<2)
        timesTag[i]=1;
}

In void pD(int u)
{
    addTag[u<<1]=((ll)timesTag[u]*addTag[u<<1]+addTag[u])%p;
    timesTag[u<<1]=(ll)timesTag[u<<1]*timesTag[u]%p;
    addTag[u<<1|1]=((ll)timesTag[u]*addTag[u<<1|1]+addTag[u])%p;
    timesTag[u<<1|1]=(ll)timesTag[u<<1|1]*timesTag[u]%p;
    addTag[u]=0, timesTag[u]=1;
}

void mod(top)
{
    if(l^r) pD(u);
    if(modItv.r<l || r<modItv.l) Re;
//    debug(printf("%d %d %d\n", u, l, r);)
    if(modItv.l<=l && r<=modItv.r)
    {
        if(type==add)
            upd(u[addTag], value);
        else
            upd(u[timesTag], u[timesTag]),
            upd(u[addTag], u[addTag]);
        Re;
    }
    mod(ls), mod(rs);
}

int val(int x, top)
{
    if(l==r) Re addTag[u];
    pD(u);
    if(x>mid) Re val(x, rs);
    Re val(x, ls);
}

int main()
{
    freopen("xmasinterval.in", "r", stdin);
    freopen("xmasinterval.out", "w", stdout);
    St int n;
    scanf("%d%d", &n, &m);
    {
        St int x[1<<19];
        inc(1, i, n+1)
            scanf("%d%d", &itv[i].l, &itv[i].r);
        inc(1, i, m+1)
            scanf("%d", x+i);
        sort(x+1, x+m+1);
        unique(x+1, x+m+1);
        #define get(w, a) a##_bound(x+1, x+m+1, w)-x
        inc(1, i, n+1)
            itv[i].l=get(itv[i].l, lower), itv[i].r=get(itv[i].r, upper)-1;
    }
    sort(itv+1, itv+n+1);
    init();
    type=add, value=1, modItv=interval(0, 0), mod();
    inc(1, i, n+1)
    {
    //取模
        debug(inc(0, i, m<<2) printf("tags: %d %d\n", addTag[i], timesTag[i]);
        inc(0, i, m+1) printf("%d ", val(i)); puts("");)
        type=add, value=val(itv[i].l-1), modItv=interval(itv[i].l, itv[i].r), mod();
        type=times, modItv=interval(0, itv[i].l-1), mod();
    }
    printf("%d\n", val(m));
    Re 0;
}
