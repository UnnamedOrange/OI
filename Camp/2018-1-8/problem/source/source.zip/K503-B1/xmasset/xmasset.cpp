#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
int T,opt,n,thi,x,y;
int i,j,k;
void work1(int x,int y){
	int i=0,t1,t2;
	while (1){
		i++;
		t1=x%2;
		t2=y%2;
		if (t1!=t2){
			printf("%d\n",(i-1)*2+t1+1);
			return;
		}
		x=x/2;
		y=y/2;
	}
}
void work2(int x,int y){
	int i,t1,t2;
	y=y-1; t1=y/2; t1=t1+1; y=y%2;
	for (i=1;i<=t1-1;i++){
		x=x/2;
	}
	t2=x%2;
	if (t2==y) printf("yes\n");
	else printf("no\n");
}
int main(){
	scanf("%d%d%d",&thi,&n,&T);
	for (opt=1;opt<=T;opt++){
		scanf("%d%d",&x,&y);
		if (thi==1){
			work1(x,y);
		}
		else{
			work2(x,y);
		}
	}
	return 0;
}
