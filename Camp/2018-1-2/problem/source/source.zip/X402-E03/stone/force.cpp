#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const int maxn = 25, modd = 1e9+7 ;
int n, d[maxn] ;
int a, b ;
LL ans[5] ;
bool dfs ( int *t, int m, bool now ) {
	int i, v = now? b:a ;
	bool fg = 1 ;
	for ( i = 1 ; i <= m ; i ++ )
		if (t[i] >= v) {
			t[i] -= v ;
			fg &= dfs(t, m, now^1) ;
			t[i] += v ;
			if (fg == 0) return 1 ;
		}
	return 0 ;
}
int t[maxn] ;
int calc ( int x ) {
	int fg0, fg1 ;
	int i, m = 0 ;
	for ( i = 1 ; i <= n ; i ++, x >>= 1 )
		if (x&1) t[++m] = d[i] ;
	fg0 = dfs(t, m, 0) ;
	fg1 = dfs(t, m, 1) ;
	if (fg0 == 0 && fg1 == 0) return 0 ;
	if (fg0 == 1 && fg1 == 1) return 1 ;
	if (fg0 == 1) return 2 ;
	return 3 ;
}
int main() {
	freopen ( "stone.in", "r", stdin ) ;
	freopen ( "force.out", "w", stdout ) ;

	int i, x ;
	cin >> n >> a >> b ;
	for ( i = 1 ; i <= n ; i ++ )
		cin >> d[i] ;
	x = 1<<n ;
	for ( i = 0 ; i < x ; i ++ )
		(++ ans[calc(i)]) %= modd ;
	printf ( "%lld %lld %lld %lld\n", ans[2]%modd, ans[3]%modd, ans[0]%modd, ans[1]%modd ) ;
	cerr << (double)clock()/CLOCKS_PER_SEC << endl << endl ;
	return 0 ;
}
