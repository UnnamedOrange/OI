#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;


int n,T,x,y,t,q,h;

int main()
{
	scanf("%d",&t);
	scanf("%d%d",&n,&T);
	
	
	for (int i=1;i<=T;i++)
	if (t==1) 
	{
		scanf("%d%d",&x,&y);
		printf("%d\n",x);
	}
	else 
	{
		scanf("%d%d",&q,&h);
		if (q==h) puts("yes");else puts("no");
	}
	return 0;
}

