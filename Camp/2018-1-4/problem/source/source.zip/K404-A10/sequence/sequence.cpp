#include <bits/stdc++.h>

std::map<std::vector<int>,int> all;
std::queue<std::vector<int> > q; 
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--) {
		int n;
		scanf("%d",&n);
		std::vector<int> base(n);
		for(int i = 0;i < n;++i) scanf("%d",&base[i]);
		std::vector<int> beg(n);
		for(int i = 0;i < n;++i) beg[i] = i + 1;
		all[base] = 1;all[beg] = -1;q.push(base);q.push(beg);
		int ans = 999;
		while(!q.empty()) {
			std::vector<int> cur = q.front();q.pop();
			int dist = all[cur];
			//for(int i = 0;i < n;++i) printf("%d ",cur[i]);
			//printf("%d\n",dist);
			for(int i = 1;i < n;++i) {
				for(int j = 0;j < i - j;++j) std::swap(cur[j],cur[i-j]);
				int v = all[cur];
				if(v == 0) {
					all[cur] = (dist > 0 ? dist + 1 : dist - 1);
					q.push(cur);
				} else if((v > 0 && dist < 0) || (v < 0 && dist > 0)) {
					int x = abs(v - dist) - 1;
					if(x < ans) ans = x;
				}
				for(int j = 0;j < i - j;++j) std::swap(cur[j],cur[i-j]);
			}
			if(dist * 2 > ans) break;
		}
		printf("%d\n",ans);
	}
}
