#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define maxn 100010
#define modn 998244353
int a[maxn],b[maxn]={0},c[maxn]={0},dis[maxn]={0},n,k,t=0,i;
long long ans=1;
bool mark[maxn];
void dfs(int x,int y)
{
	mark[x]=false;
	if (mark[a[x]])
	{
		b[a[x]]=b[x]+1;
		dfs(a[x],y);
	}
	else if (a[x]==y)
	{
		k-=b[x]+1;
		if (!(b[x]&1)) ans=0;
	}
}
void sort()
{
	int i,j,l=0,r=-1;
	for (i=1;i<=n;i++)
		if (!c[i])
			for (j=i;j;j=a[j])
				if (a[j]) dis[a[j]]=dis[j]+1;
					else
					{
						k-=dis[j]/2*2;
						if (dis[j]&1) t++;
					}
}
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	if (n&1) printf("0");
	else
	{
		for (i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			c[a[i]]=i;
		}
		k=n;
		memset(mark,true,sizeof(mark));
		mark[0]=false;
		for (i=1;i<=n;i++)
			if (mark[i]) dfs(i,i);
		if (!ans) printf("0");
		else
		{
			sort();
			for (i=4;i<=k-t*2;i+=2)
				ans=ans*(long long)(i-1)%modn*(long long)(i-1)%modn;
			for (i=k-t*2+1;i<=k-t;i++)
				ans=ans*(long long)i%modn;
			printf("%lld",ans);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
