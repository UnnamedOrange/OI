#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i<=i##end;++i)
#define DREP(i,st,ed) for(int i=(int)(st),i##end=(int)(ed);i>=i##end;--i)
template<typename T>bool chkmin(T &x,const T &y){return x>y?x=y,1:0;}
template<typename T>bool chkmax(T &x,const T &y){return x<y?x=y,1:0;}
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif
template<typename T>T read(){
	T x=0,f=1;
	char c=getchar();
	while((c<'0')||(c>'9')){if(c=='-')f=-1;c=getchar();}
	while((c>='0')&&(c<='9'))x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
#define read() read<int>()
template<typename T>void write(T x,char c){
	static char t[25];
	static int tlen;
	t[tlen=1]=c;
	if(x<0)putchar('-'),x=-x;
	do t[++tlen]=(x%10)^48;
	while(x/=10);
	while(tlen)putchar(t[tlen--]);
}
#define pb push_back
typedef long long ll;
typedef double lf;
const int maxn=100400,mod=998244353;
int n,m,p;
int f[maxn][355];
#define dp(i,j,k) f[(i)*(n+1)+(j)][(k)]
void add(int &x,const int &y){
	x+=y;
	if(x>=mod)x-=mod;
}
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1)res=1ll*res*x%mod;
		x=1ll*x*x%mod,y>>=1;
	}return res;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
#endif
	n=read(),m=read(),p=read();
	if(n>m)return puts("0"),0;
	dp(0,0,0)=1;
	REP(i,0,m-1)
		REP(j,0,n)
			REP(k,0,j){
				if(!dp(i,j,k))continue;
				int tmp=dp(i,j,k);
				if(k<n){
					add(dp(i+1,j,k+1),tmp);
					if(j<n){
						add(dp(i+1,j+1,k),tmp);
						add(dp(i+1,j+1,k+1),tmp);
					}
				}add(dp(i+1,j,k),tmp);
			}
/*
	REP(i,0,m)
		REP(j,0,n)
			REP(k,0,j)
				if(dp(i,j,k))
					cout<<i<<' '<<j<<' '<<k<<' '<<dp(i,j,k)<<endl;
*/
	int ans=0;
	REP(i,1,m)
		REP(j,0,n){
			int cnt=0;
			REP(k,0,n-j)
				add(cnt,1ll*dp(i,j+k,k)*dp(m-i,n-k,n-j-k)%mod);
			add(ans,1ll*cnt*ksm(j,p)%mod);
		}
	write(ans,'\n');
	return 0;
}
