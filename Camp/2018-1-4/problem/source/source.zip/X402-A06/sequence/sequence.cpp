#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int a[maxn], Ans, n;

void Get(){
	n = read();
	For(i, 1, n) a[i] = read();

	if(n <= 18) Ans = n + 2;
	else Ans = n + 1;
}

void dfs(int cont,int Last,int step){

	if(cont + step >= Ans) return;
	if(a[1] == 1 && cont == 0){
		Ans = step;
		return;
	}

	For(i, 2, n){
		if(i != Last){

			int nowcont = cont;
			if(i != n) nowcont += (abs(a[i] - a[i + 1]) == 1);
			if(i != n) nowcont -= (abs(a[i + 1] - a[1]) == 1);

			if(nowcont > cont) continue;

			For(j, 1, i / 2){
				int tmp = a[j];
				a[j] = a[i - j + 1];
				a[i - j + 1] = tmp;
			}

			dfs(nowcont, i, step + 1);

			For(j, 1, i / 2){
				int tmp = a[j];
				a[j] = a[i - j + 1];
				a[i - j + 1] = tmp;
			}
		}
	}
}

void solve(){
	int cont = 0;
	For(i, 2, n) cont += (abs(a[i] - a[i-1]) != 1);
	dfs(cont, -1, 0);
	printf("%d\n", Ans);
}

int main(){
	
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);

	int _ = read();
	while(_ --){
		Get();
		solve();
	}

	return 0;
}
