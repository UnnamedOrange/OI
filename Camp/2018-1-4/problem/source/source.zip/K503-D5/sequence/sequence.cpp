#include <cstdio>
#include <algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int Hn=1e6+5,N=5e5+5,
  h1[11]={0,2777,133333,55555,200001,500001,150777,4566666,1004999,123412,474738},
  h2[11]={0,441412,891234,171239,3123448,77123429,15234100,32333,226112,347383,271282};
int hn,ver[Hn],fst[Hn],nxt[N],key[N];
int t,n,i,j,k,ans;
struct arr{
	int step,per[11];
}q[N]; int l,r;
int hash1(int *a)
{
	int i;
	long long ret=0;
	rep(i,1,n) ret=(ret+(long long)a[i]*h1[i])%Hn;
	return ret;
}
int hash2(int *a)
{
	int i;
	long long ret=0;
	rep(i,1,n) ret=(ret+(long long)a[i]*h2[i])%Hn;
	return ret;	
}
bool push(int *a)
{
	int p=hash1(a),j,keya=hash2(a);
	if (ver[p]!=t) {
		ver[p]=t; fst[p]=0;
	}
	j=fst[p];
	while (j)
    {
    	if (key[j]==keya) return 0;
    	j=nxt[j];
	}
	hn++; nxt[hn]=fst[p]; fst[p]=hn; key[hn]=keya;
	return 1;
}
void Init()
{
	hn=0;
	scanf("%d",&n);
	l=r=1;
	rep(i,1,n) scanf("%d",&q[1].per[i]);
	push(q[1].per);
}
void BFS()
{
	int i,j,flag,newp[10];
	flag=1;
	rep(j,2,n)
	  if (q[1].per[j]<q[1].per[j-1]) flag=0;
	if (flag) {ans=0;return;}
	while (l<=r)
	{
		rep(i,2,n)
	    {
	    	rep(j,1,n) newp[j]=q[l].per[j];
	    	rep(j,1,i/2) swap(newp[j],newp[i-j+1]);
	    	flag=1;
			rep(j,2,n)
	    	  if (newp[j]<newp[j-1]) flag=0;
	    	if (flag) {
	    		ans=q[l].step+1;
	    		return;
			}
			if (push(newp))
	    	{
	    		r++;
	    		q[r].step=q[l].step+1;
	    		rep(j,1,n) q[r].per[j]=newp[j];
			}
	    }
	    l++;
	}
}
void Reg()
{
    ans=0;
	rep(i,1,n)
	{
	  if (q[1].per[i]==i) continue;
	  if (q[1].per[1]!=i) {
	  	 rep(j,1,n)
	  	   if (q[1].per[j]==i) break;
	  	 rep(k,1,j/2) swap(q[1].per[k],q[1].per[j-k+1]);
	  	 ans++;
	  }
	  rep(k,1,i/2) swap(q[1].per[k],q[1].per[i-k+1]);
	  ans++;
    }
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		Init();
		if (n<=9) BFS();
		else Reg();
		printf("%d\n",ans);
	}
	return 0;
}
