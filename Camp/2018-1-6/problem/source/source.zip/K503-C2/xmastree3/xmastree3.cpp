#include <stdio.h>
#define modn 998244353
int n,k,i,ans=1;
int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	scanf("%d%d",&n,&k);
	for (i=1;i<k;i++)
		ans=(long long)ans*(long long)n%modn;
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
