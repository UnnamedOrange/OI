#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int mod=998244353;
#define N 100010
#define vi vector<int>::iterator
vector<int> e[N];
int n,k,vis[N];
int dfs2(int po,int len) {
	if(len==k) return 0;
	int flag=0;
	for(vi i=e[po].begin();i!=e[po].end();i++) {
		int v=*i;
		if(len==k-1&&v==1) return 1;
		if(vis[v]) continue;
		vis[v]=1;
		flag=max(flag,dfs2(v,len+1));
		vis[v]=0;
	}
	return flag;
}
int check() {
	for(int i=1;i<=n;i++) {
		memset(vis,0,sizeof(vis));
		if(dfs2(i,0)) return 1;
	}
	return 0;
}
int ans=0;
void dfs(int x,int y) {
	if(x==n+1) {
		ans+=check();
		return;
	}
	if(x>=y) {
		dfs(x,x+1);
		return;
	}
	if(y==n+1) {
		dfs(x+1,x+2);
		return;
	}
	e[x].push_back(y);
	dfs(x,y+1);
	e[x].pop_back();
	e[y].push_back(x);
	dfs(x,y+1);
	e[y].pop_back();
}
int main() {
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
//	n=k=6;
	dfs(1,1);
	printf("%d",ans);
}
//2,44,904,31264
