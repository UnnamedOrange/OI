while true; do
./gen > input
./bf < input > bfout
./xmasdag < input > stdout

if diff bfout stdout; then
 printf "脑普文真是好样的\n"
 continue
else
 printf "脑普文是真的普\n"
 break
fi

sleep 0.2
done
