#include<bits/stdc++.h>
using namespace std;

const int maxn=30;
const int mod=1e3;
int n,m;

int main(){
	freopen("xmasinterval.in","w",stdout);

	srand(time(0));
	printf("%d %d\n", n=5, m=5);
	for(int i=1;i<=n;i++){
		int l=rand()%mod+1, r=rand()%mod+1;
		if(l>r) swap(l, r);
		printf("%d %d\n", l, r);
	}
	for(int i=1;i<=m;i++) printf("%d ", rand()%mod+1); puts("");
	return 0;
}
