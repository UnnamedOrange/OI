#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int T,p,q,n,W;
int xi[1005],yi[1005],zi[1005],ai[1005],bi[1005],ci[1005],di[1005],ei[1005],fi[1005];
int x[1005],y[1005],r[1005];
int m[20];
int ans=0x7f7f7f7f;

void dfs(int w[],int t)//-1����ȡ����1����ȡ�� 
{
	int ret=0;
	int vis=0;
	for(int i=1;i<=q;i++)
	{
		if(r[i]==0)
		  if(w[x[i]]>w[y[i]])
		    vis=1;
		if(r[i]==1)
		  if(w[x[i]]!=w[y[i]])
		    vis=1;
		if(r[i]==2)
		  if(w[x[i]]>=w[y[i]])
		    vis=1;
	}
	if(vis==0)
	{
		for(int i=1;i<=p;i++)
		{
		  ret+=ai[i]*abs(w[xi[i]]-w[yi[i]]);
		  ret+=bi[i]*abs(w[yi[i]]-w[zi[i]]);
		  ret+=ci[i]*abs(w[zi[i]]-w[xi[i]]);
		  ret+=di[i]*(w[xi[i]]-w[yi[i]]);
		  ret+=ei[i]*(w[yi[i]]-w[zi[i]]);
		  ret+=fi[i]*(w[zi[i]]-w[xi[i]]);
	    }
	    for(int i=1;i<=n;i++)ret+=w[i];
	    ans=min(ans,ret);
	}
	for(int i=t;i<=n;i++)
	  if(w[i]==-W)
	  {
	  	w[i]=W;
	  	dfs(w,i+1);
	  	w[i]=-W;
	  }
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&T);
	while(T!=0)
	{
		T--;
	    ans=0x7f7f7f7f;
		scanf("%d%d%d%d",&n,&W,&p,&q);
		W=abs(W);
		for(int i=1;i<=n;i++)m[i]=-W;
		for(int i=1;i<=p;i++)
		  scanf("%d%d%d%d%d%d%d%d%d",&xi[i],&yi[i],&zi[i],&ai[i],&bi[i],&ci[i],&di[i],&ei[i],&fi[i]);
		for(int i=1;i<=q;i++)
		{
		  scanf("%d%d%d",&x[i],&y[i],&r[i]);
		  if(r[i]==2)
		    m[y[i]]=1;
	    }
		dfs(m,1);
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
}
