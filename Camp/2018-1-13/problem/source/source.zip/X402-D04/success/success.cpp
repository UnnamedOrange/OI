#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn=2010;
const int mod=1e9+7;
ll s;
int t, n, m;
int dp[maxn][maxn];

int main(){
	freopen("success.in","r",stdin),freopen("success.out","w",stdout);

	scanf("%lld%d%d%d", &s, &t, &n, &m);
	dp[0][0]=1;
	for(int i=0;i<m;i++)for(int j=0;j<=s;j++)if(dp[i][j]){
		if(i+1<=n) for(int k=1;k<=t && k+j<=s;k++) (dp[i+1][j+k]+=dp[i][j])%=mod;
		else for(int k=1;k+j<=s;k++) (dp[i+1][j+k]+=dp[i][j])%=mod;
	}
	int ans=0;
	/*
	for(int i=m;i<=s;i++){
		printf("%d : %d\n", i, dp[m][i]);
	}
	*/
	for(int i=m;i<=s;i++) (ans+=dp[m][i])%=mod;
	printf("%d\n", ans);
	return 0;
}
