#include<bits/stdc++.h>
using namespace std;

int main(){
	srand(time(0));
	freopen("xmasinterval.in","w",stdout);
	int n=20,m=20,k=50;
	n=m=5e5;k=1e6;
	printf("%d %d\n",n,m);
	for(int i=1;i<=n;++i){
		int x=rand()%k+1,y=rand()%k+1;
		if(x>y)swap(x,y);
		printf("%d %d\n",x,y);
	}
	for(int i=1;i<=m;++i)
		printf("%d\n",rand()%k+1);
}
