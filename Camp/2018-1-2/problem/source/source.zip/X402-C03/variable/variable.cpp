#include<bits/stdc++.h>
using namespace std;

const int maxn=1e3+10;
int t,n,w,p,q,wx[maxn],wy[maxn],wz[maxn],a[maxn],b[maxn],c[maxn],d[maxn],e[maxn],f[maxn],x[maxn],y[maxn],r[maxn],v[maxn];
int ans;

void dfs(int pos){
	if(pos>n){
		for(int i=1;i<=q;++i)
			switch(r[i]){
				case 0:
					if(v[x[i]]>v[y[i]])
						return;
				case 1:
					if(v[x[i]]!=v[y[i]])
						return;
				case 2:
					if(v[x[i]]>=v[y[i]])
						return;
			}
		int tot=0;
		for(int i=1;i<=p;++i)
			tot+=a[i]*abs(v[wx[i]]-v[wy[i]])+b[i]*abs(v[wy[i]]-v[wz[i]])+c[i]*abs(v[wz[i]]-v[wx[i]])+d[i]*(v[wx[i]]-v[wy[i]])+e[i]*(v[wy[i]]-v[wz[i]])+f[i]*(v[wz[i]]-v[wx[i]]);
		for(int i=1;i<=n;++i)
			tot+=v[i];
		if(tot<ans)
			ans=tot;
		return;
	}
	v[pos]=1;
	dfs(pos+1);
	v[pos]=-1;
	dfs(pos+1);
}

int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d%d%d%d",&n,&w,&p,&q);
		for(int i=1;i<=p;++i)
			scanf("%d%d%d%d%d%d%d%d%d",&wx[i],&wy[i],&wz[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for(int i=1;i<=q;++i)
			scanf("%d%d%d",&x[i],&y[i],&r[i]);
		ans=1e9;
		dfs(1);
		printf("%lld\n",(long long)ans*w);
	}
	return 0;
}
