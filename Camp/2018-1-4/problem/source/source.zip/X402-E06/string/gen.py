import sys
from random import *

sys.stdout = open("string.in", "w")

n = 6
m = 500

print (n, m)

for i in range(n):
    l = randint(50, 100)
    for j in range(l):
        print (randint(0, 1), end = '')
    print ()
