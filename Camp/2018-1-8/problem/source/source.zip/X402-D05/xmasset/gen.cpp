#include<bits/stdc++.h>
using namespace std;
int getx(){
	freopen("gen.in","r",stdin);
	int x;
	scanf("%d",&x);
	fclose(stdin);
	return x;
}
void printx(){
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	fclose(stdout);
}
void solve(){
	int t=1;
	printf("%d\n",t);
	int n=910,m=2000000;
	printf("%d %d\n",n,m);
	int s;
	while(m--){
		s=rand()%n+1,t=rand()%n+1;
		while(s==t)
			s=rand()%n+1,t=rand()%n+1;
		printf("%d %d\n",s,t);
	}
}
int main(){
	srand(time(0)+getx());
	freopen("xmasset.in","w",stdout);
	solve();
	fclose(stdout);
	printx();
	return 0;
}
