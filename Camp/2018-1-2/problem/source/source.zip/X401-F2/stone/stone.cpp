#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std;

template<class T>void read(T &x){
	x=0;int ff=0;char ch=getchar();
	while(ch<'0'||ch>'9'){ff|=(ch=='-');ch=getchar();}
	while(ch<='9'&&ch>='0'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x=ff?-x:x;
	return ;
}

int n,a,b,X[100010],aw,bw,sw[3];

void dfs1(int x,int ret,int tt,int ss){//0��ʾ����,1��ʾ���ں��� 
	if((X[x]-a==0)&&ss==1) {sw[tt^1]++;return;}
	if(!X[x]&&ss!=1) {tt?aw++:bw++;return;}
	if(ret-a<0) {bw++;return;}
	if(!tt) dfs1(x,ret-a,tt^1,ss+1);
	if(ret-b<0){aw++;return;}
	if(tt) dfs1(x,ret-b,tt^1,ss+1);
}

void dfs2(int x,int ret,int tt,int ss){//0��ʾ����,1��ʾ���ں��� 
	if((X[x]-b==0)&&ss==1) {sw[tt]++;return;}
	if(!X[x]&&ss!=1) {tt?aw++:bw++;return;}
	if(ret-b<0) {aw++;return;}
	if(!tt) dfs2(x,ret-b,tt^1,ss+1);
	if(ret-a<0){bw++;return;}
	if(tt) dfs2(x,ret-a,tt^1,ss+1);
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	read(n),read(a),read(b);
	for(int i=1;i<=n;i++) read(X[i]);
	for(int i=0;i<=n;i++) 
		dfs1(i,X[i],0,1),dfs2(i,X[i],0,1);
	printf("%d %d %d %d\n",aw,bw-2,sw[0],sw[1]);
	return 0;
}

