#include<bits/stdc++.h>
using namespace std;
#define N 1000100
int main() {
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
}
