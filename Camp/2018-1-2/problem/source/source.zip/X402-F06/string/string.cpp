#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
inline bool chkmin(int &x,int y){return y<x?(x=y,1):0;}
const int maxn=1e5+10,inf=0x3f3f3f3f;
int dp[maxn];
char s[maxn];
bool pd(int l,int r){
	REP(i,0,(r-l)>>1)
		if(s[i+l]!=s[r-i]) return 1;
	return 0;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	int T=read();
	while(T--){
		int n=read();
		scanf("%s",s+1);
		if(n<=100){
			memset(dp,0x3f,sizeof(dp));
			dp[0]=0;
			REP(i,1,n)
				REP(j,0,i-2)
					if(dp[j]!=inf && pd(j+1,i))
						chkmin(dp[i],dp[j]+1);
			printf("%d\n",dp[n]==inf?-1:dp[n]);
			continue;
		}
		bool flag=1,b=1,b1=1;
		int num=0;
		REP(i,1,n/2)
		flag&=(s[i]==s[n-i+1]);
		REP(i,2,n)
			b&=(s[i]==s[i-1]),num+=(s[i]!=s[1]);
		REP(i,3,n) b1&=(s[i]==s[i-2]);
		if(b || (flag && (num==1 || b1))) printf("-1\n");
		else if(!flag) printf("1\n");
		else printf("2\n");
	}
	return 0;
}
