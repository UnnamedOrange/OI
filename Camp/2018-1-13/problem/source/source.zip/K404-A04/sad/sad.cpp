#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#define ll long long
using namespace std;
const int maxn=100010;
const int mod=998244353;
int n,deg[maxn],fa[maxn];
bool vis[maxn],col[maxn],cc[2];
char s[maxn];
double ans=0;
ll c[maxn],d[maxn];
struct edge{int t;edge *next;}*con[maxn];
void ins(int x,int y){edge *p=new edge;p->t=y;p->next=con[x];con[x]=p;}
ll ksm(ll a,int b){ll r=1;for(a%=mod;b;b>>=1){if(b&1)r=r*a%mod;a=a*a%mod;}return r;}
void find(int x,int cnt,double P)
{
	
	if(s[x]=='1'||!vis[x]) cnt++;
	//cout<<x<<' '<<cnt<<' '<<P<<' '<<vis[x]<<endl;
	bool tmp=vis[x];
	vis[x]=1;
	if(deg[x]==1) 
	{
		ans+=cnt*P;
		vis[x]=tmp;
		//cout<<"cal:"<<cnt*P<<endl;
		return ;
	}
	if(P<1e-10) return ;
	for(edge *p=con[x];p;p=p->next)
		find(p->t,cnt,P/deg[x]);	
	vis[x]=tmp;	
}
void dfsb(int v)
{
	c[v]=1;
	if(deg[v]==1){d[v]=0;return ;}
	ll P=ksm(deg[v],mod-2);	
	ll fm=0;
	for(edge *p=con[v];p;p=p->next)
		if(p->t!=fa[v])
		{
			fa[p->t]=v;
			dfsb(p->t);
			(c[v]+=c[p->t]*P)%=mod;
			(fm+=P*d[p->t])%=mod;			
		}
	fm=ksm(1-fm+mod,mod-2);
	//cout<<fm<<endl;
	d[v]=P*fm%mod;
	(c[v]*=fm)%=mod;
	//cout<<v<<' '<<c[v]<<' '<<d[v]<<endl;
}
void spc_black()
{
	dfsb(1);
	printf("%lld",c[1]);
}
void dfsw(int v)
{
	c[v]=1;
	if(deg[v]==1) {d[v]=0;return;}
	ll tote=0,P=ksm(deg[v],mod-2);
	for(edge *p=con[v];p;p=p->next)
		if(p->t!=fa[v])
		{
			fa[p->t]=v;
			dfsw(p->t);
			(tote+=d[p->t])%=mod;
		}
	d[v]=(tote+1)*P%mod;
	for(edge *p=con[v];p;p=p->next)
		if(p->t!=fa[v]) (c[v]+=(tote+c[p->t]-d[p->t]+mod)%mod*P)%=mod;	
//	cout<<P<<endl;	
//	cout<<v<<' '<<d[v]<<' '<<c[v]<<endl;	
}
void spc_white()
{
	dfsw(1);
	printf("%lld",c[1]);
}
int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s+1);
	for(int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y);
		ins(y,x);
		deg[x]++;deg[y]++;
	}	
	for(int i=1;i<=n;i++)
		col[i]=s[i]-'0',cc[col[i]]=1;
	if(n<=6)
	{
		memset(vis,0,sizeof(vis));
		find(1,0,1.0);
		for(int i=2;i<=n;i++) ans=ans*i;
		ll tans=(ll)round(ans);
		for(int i=2;i<=n;i++) tans=tans*ksm(i,mod-2)%mod;
		printf("%lld",tans);
	}
	else if(!cc[1])spc_white();
	else spc_black();
	return 0;
}
/*4
1111
1 2
1 3
3 4

5 
11111
1 2
1 3
1 4
4 5

4
0000
1 2
1 3
3 4

5
00000
1 2
2 3
1 4
4 5*/
