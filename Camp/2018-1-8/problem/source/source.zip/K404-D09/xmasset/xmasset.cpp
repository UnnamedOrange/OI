#include <bits/stdc++.h>

inline int getch() {
	static int size = 0, pt = 0;
	static char buf[1048576];
	if(size == pt) {
		pt = buf[size = fread(buf, sizeof(char), 1048575, stdin)] = '\0';
		if(size == 0)
			return EOF;
	}
	return buf[pt++];
}

inline int get_int() {
	register int ch, flag = 1, x;
	for(ch = getch(); ch != EOF && (unsigned)(ch ^'0') > 9; ch = getch())
		if(ch == '-') flag = -1;
	if(ch == EOF) return EOF;
	for(x = ch ^ '0', ch = getch(); (unsigned)(ch ^ '0') < 10; ch = getch())
		x = (x << 3) + (x << 1) + (ch ^ '0');
	return x * flag;
}

namespace OUTBUFFER {
	char buf[1048576];
	int pt;
	inline void putch(register char ch) {
		buf[pt++] = ch;
	}
	inline void flush() {
		if(pt) fwrite(buf,sizeof(char),pt,stdout), pt = 0;
	}
	inline void check() {
		if(pt > 1000000) flush();
	}
}

template <class T>
inline void put_int(register T x) {
	char temp[23];
	register int top;
	if(x == 0) return OUTBUFFER::putch('0');
	if(x < 0) OUTBUFFER::putch('-'), x = -x;
	for(top = 0; x; temp[++top] = x % 10, x /= 10);
	do OUTBUFFER::putch(temp[top] ^ '0');
	while(--top);
	OUTBUFFER::check();
}

struct OUT {
	OUT() {
		OUTBUFFER::pt = 0;
	}
	~OUT() {
		OUTBUFFER::flush();
	}
	const OUT &operator << (const char *str) const {
		while(*str) OUTBUFFER::putch(*str++);
		OUTBUFFER::check();
		return *this;
	}
	const OUT &operator << (register char ch) const {
		return OUTBUFFER::putch(ch), *this;
	}
	const OUT &operator << (register int x) const {
		return put_int<int>(x), *this;
	}
	const OUT &operator << (register long long x) const {
		return put_int<long long>(x), *this;
	}
} out;

int encode18(int x, int y) {
	int ptr = 0;
	while(x && y) {	//18
		if((x & 1) != (y & 1)) return (ptr << 1) | (x & 1);
		++ptr, x >>= 1, y >>= 1;
	}
	return 0;
}

bool decode18(int q, int h) {
	bool bit = h & 1;
	h >>= 1;
	return (q & (1 << h)) == bit;
}

int encode(int x, int y) {
	return encode18(x, y);
}

bool decode(int q, int h) {
	return decode18(q, h);
}

int main() {
	int type = get_int(), N = get_int(), T = get_int(), x, y;
	while (T--) {
		x = get_int();
		y = get_int();
		if (type == 1)
			out <<encode(x, y) <<'\n';
		else
			out <<(decode(x, y) ? "yes" : "no");
	}
}
