#include <stdio.h>

#define ll long long int

const int maxn=500001,mod=1000000009;
bool vis[maxn];
ll r[maxn],l[maxn],x[maxn];
ll n,m,ans=0;

inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void dfs(ll t)
{
	ll i;
	if(t==n+1)
	{
		for(i=1;i<=m;i++)
		{
			if(!vis[i])
				return;
		}
		ans=(ans+1)%mod;
		return;
	}
	bool temp[21];
	for(i=1;i<=m;i++)
		temp[i]=vis[i];	
	for(i=1;i<=m;i++)
	{
		if(l[t]<=x[i]&&r[t]>=x[i])
		{ 
			vis[i]=1;
		}
	}
	dfs(t+1);
	for(i=1;i<=m;i++)
		vis[i]=temp[i]; 
	dfs(t+1);
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read(),m=read();
	ll i;
	for(i=1;i<=n;i++)
		l[i]=read(),r[i]=read();
	for(i=1;i<=m;i++)
		x[i]=read();
	dfs(1);
	printf("%lld",ans%mod);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

