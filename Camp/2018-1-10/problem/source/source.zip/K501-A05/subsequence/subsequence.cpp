#include <bits/stdc++.h>

using namespace std;

#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int MAXN = int(4e3);

int n, m, k;

int A[MAXN + 5], B[MAXN + 5];

inline void input()
{
	n = read<int>(), m = read<int>(), k = read<int>();
	for(int i = 1; i <= n; ++i) A[i] = read<int>();
	for(int i = 1; i <= m; ++i) B[i] = read<int>();
}

int transA[MAXN + 5][MAXN + 5], transB[MAXN + 5][MAXN + 5];

inline void build_trans()
{
	for(int i = 1; i <= k; ++i) transA[n][i] = n + 1;
	for(int i = 1; i <= k; ++i) transA[n + 1][i] = n + 1;
	for(int i = n - 1; ~i; --i)
	{
		for(int j = 1; j <= k; ++j) transA[i][j] = transA[i + 1][j];
		transA[i][A[i + 1]] = i + 1;
	}

	for(int i = 1; i <= k; ++i) transB[m][i] = m + 1;
	for(int i = 1; i <= k; ++i) transB[m + 1][i] = m + 1;
	for(int i = m - 1; ~i; --i)
	{
		for(int j = 1; j <= k; ++j) transB[i][j] = transB[i + 1][j];
		transB[i][B[i + 1]] = i + 1;
	}
}

int f[MAXN + 5][MAXN + 5];

inline void DP()
{
	const int oo = 0x3f3f3f3f;
	memset(f, 0x3f, sizeof f), f[0][0] = 0;
	for(int i = 0; i <= n + 1; ++i)
		for(int j = 0; j <= m + 1; ++j)
			if(f[i][j] < oo)
				for(int p = 1; p <= k ; ++p)
					chkmin(f[transA[i][p]][transB[j][p]], f[i][j] + 1);
}

inline void solve()
{
	build_trans();
	DP();

	printf("%d\n", f[n + 1][m + 1]);
}

int main()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);

	input();
	solve();

	return 0;
}

