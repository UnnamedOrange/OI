#include <bits/stdc++.h>
#define LL long long
#define MOD 1000000007
#define getchar() *(pp++)
using namespace std;
char buf[20000100],*pp=buf;
inline LL read() {
	LL x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int n,a[1010][1010],s[1010][1010];
LL d[1010],w[1010];
int main() {
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	fread(buf,sizeof(char),sizeof(buf),stdin);
	cin>>n;
	for(int i=1; i<=n; i++) {
		a[i][read()]=1;
		a[i][read()+1]=-1;
	}
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=n; j++) {
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
		}
	}
	w[0]=1;
	for(int i=1; i<=n; i++) {
		for(int j=0; j<i; j++) {
			if(s[i][i-j]-s[j][i-j]==i-j) {
				if(d[i]<d[j]) {
					d[i]=d[j];
					w[i]=w[j];
				} else {
					if(d[i]==d[j]) {
						d[i]=d[j];
						w[i]+=w[j];
						w[i]%=MOD;
					}
				}
			}
		}
		d[i]++;
	}
	if(w[n])
	{
		cout<<d[n]<<' '<<w[n]<<endl;
	}
	else
	{
		cout<<-1<<endl;
	}
	return 0;
}
