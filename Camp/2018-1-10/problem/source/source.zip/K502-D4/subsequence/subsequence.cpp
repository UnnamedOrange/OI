#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int a[20];
int b[20];
int w[20];
map <int,bool> vis;
void dfsa(int u,int num,int ws){
	if(u>n){
		if(!vis[num*32+ws]){
			vis[num*32+ws]=1;
			w[ws]++;
		}
		return;
	}
	dfsa(u+1,num*2+a[u],ws+1);
	dfsa(u+1,num,ws);
}
void dfsb(int u,int num,int ws){
	if(u>m){
		if(!vis[num]){
			vis[num]++;
			w[ws]++;
		}
		return;
	}
	dfsb(u+1,num*2+b[u],ws+1);
	dfsb(u+1,num,ws);
}
int bun=1;
void cFile(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
}
int solve(){
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]),a[i]--;
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]),b[i]--;
	dfsa(1,0,0);
	dfsb(1,0,0);
	for(int i=1;i<=max(n,m);i++){
		bun*=2;
		if(w[i]!=bun){
			return i;
		}
	}
	return max(n,m)+1;
}
int main(){
	cFile();
	scanf("%d%d%d",&n,&m,&k);
	printf("%d\n",solve());
	return 0;
}
