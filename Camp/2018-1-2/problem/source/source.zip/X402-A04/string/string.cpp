#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;
typedef unsigned long long ul;

const ul bas=233333;
const int N=100050;
const int inf=0x3f3f3f3f;
int f[N],n;
char s[N];
ul hash1[N],hash2[N],pw[N];

void wj()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	T=read();

	f[0]=0; pw[0]=1;
	for(i=1;i<=100000;++i) pw[i]=pw[i-1]*bas;

	for(int cas=1;cas<=T;++cas)
	{
		n=read(); scanf("%s",s+1);
		hash1[0]=0;
		for(i=1;i<=n;++i) hash1[i]=hash1[i-1]*bas+s[i];
		hash2[n+1]=0;
		for(i=n;i;--i) hash2[i]=hash2[i+1]*bas+s[i];
		for(i=1;i<=n;++i) f[i]=inf;
		for(i=1;i<=n;++i) for(j=0;j<i;++j)
			if(hash1[i]-hash1[j]*pw[i-j]!=hash2[j+1]-hash2[i+1]*pw[i-j]) 
				f[i]=min(f[i],f[j]+1);
		printf("%d\n",f[n]==inf?-1:f[n]);
	}
	return 0;
}
