#include <bits/stdc++.h>
#define LL long long
using namespace std ;
const int maxn = 1e5+5, modd = 998244353 ;
int ans, n, m, p[maxn], dep, fa[maxn], sz[maxn] ;
bool vis[maxn] ;
int a[maxn] ;
inline void check ( int x ) {
	dep ++ ;
	if (fa[x]) {
		register int t = fa[x] ;
		fa[x] = 0 ;
		check(t) ;
	}
}
int find ( int x ) { return fa[x] = x==fa[x]? x:find(fa[x]) ; }

inline void dfs ( int stp ) {
	register int i, u, v ;
	if (a[stp-1] && (a[stp-1] ^ p[stp-1])) return ;
	if (stp > n) {
		for ( i = 1 ; i <= n ; i ++ ) {
			fa[i] = i ;
			sz[i] = 1 ;
		}
		for ( i = 1 ; i <= n ; i ++ ) {
			u = find(i), v = find(p[i]) ;
			if (u == v) continue ;
			fa[u] = v ;
			sz[v] += sz[u] ;
		}
		for ( i = 1 ; i <= n ; i ++ )
			if (find(i) == i && (sz[find(i)]&1)) return ;
		++ ans ;
	}
	for ( i = 1 ; i <= n ; i ++ ) {
		if (!vis[i]) {
			vis[i] = 1 ;
			p[stp] = i ;
			dfs(stp+1) ;
			vis[i] = 0 ;
		}
	}
}
LL f[maxn] ;
void init() {
																																									f[0] = f[1] = 1 ;
																																						for ( LL i = 2 ; i < maxn ; i ++ ) {
																																	if (i&1) f[i] = (f[i - 2]*i%modd)*(i-2)%modd ;
																																				else f[i] = ((f[i - 2]*(i-1)%modd)*(i-1)%modd) ;
																																												}
}
int main() {
	freopen ( "permutation.in", "r", stdin ) ;
	freopen ( "permutation.out", "w", stdout ) ;
	int i ;
	init() ;
	while (cin >> n) {
		ans = 0 ;
		for ( i = 1 ; i <= n ; i ++ )
			scanf ( "%d", a+i ) ;
		ans = 0 ;
		if (n <= 8) {
			dfs(1) ;
			printf ( "%d\n", ans ) ;
		} else {
			if (n&1) puts("0") ;
			else printf ( "%lld\n", f[n] ) ;
		}
	}
	return 0 ;
}
