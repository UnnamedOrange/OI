#include<bits/stdc++.h>
#define ll long long
using namespace std;

int getint()
{
	int i=0,f=1;char c;
	for(c=getchar();(c!='-')&&(c<'0'||c>'9');c=getchar());
	if(c=='-')f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

const int N=100005,p=998244353;
int n,ans;
int a[N],du[N];
bool vis[N],exist[N];

bool check()
{
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;i++)
		if(!vis[i])
		{
			int x=i,num=1;
			vis[x]=1;
			while(a[x]!=i)x=a[x],vis[x]=1,num++;
			if(num&1)return false;
		}
	return true;
}

void dfs(int x)
{
	if(x==n+1)
	{
		if(check())ans=(ans+1)%p;
		return;
	}
	if(a[x])dfs(x+1);
	else
	{
		for(int i=1;i<=n;i++)
			if(!exist[i])
			{
				a[x]=i,exist[i]=1;
				dfs(x+1);
				a[x]=0,exist[i]=0;
			}
	}
}

void work1()
{
	ans=1;
	for(int i=1;i<n;i+=2)ans=1ll*ans*i%p;
	ans=1ll*ans*ans%p;
} 

void work2()
{
	int cnt1=0,cnt2=0;
	for(int i=1;i<=n;i++)
		if(a[i])du[a[i]]++;
	for(int i=1;i<=n;i++)
		if(!du[i])
		{
			int x=i,num=1;vis[i]=1;
			while(a[x]&&a[x]!=i)x=a[x],vis[x]=1,num++;
			if(a[x]!=i)
				if(num&1)cnt1++;
				else cnt2++;
		}
	for(int i=1;i<=n;i++)
		if(!vis[i])
		{
			int x=i,num=1;
			vis[x]=1;
			while(a[x]!=i)
				x=a[x],vis[x]=1,num++;
			if(num&1)
			{
				ans=0;
				return;
			}
		}
	ans=1;
	for(int i=1;i<=cnt1;i+=2)ans=1ll*ans*i%p;
	ans=1ll*ans*ans%p;
	for(int i=1;i<=cnt2;i++)ans=1ll*ans*(cnt1+i)%p;
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=getint();
	if(n&1)
	{
		puts("0");
		return 0;
	}
	if(n<=10)
	{
		for(int i=1;i<=n;i++)
		{
			a[i]=getint();
			if(a[i])exist[a[i]]=1;
		}
		dfs(1);
		cout<<ans;
		return 0;
	}
	int bz=1;
	for(int i=1;i<=n;i++)
	{
		a[i]=getint();
		if(a[i])bz=0;
	}
	if(bz)work1();
	else work2();
	cout<<ans<<'\n';
	return 0;
}
