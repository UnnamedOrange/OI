#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
const int Maxn = 5555, Mod = 998244353;

int n, k, f[Maxn], a[Maxn], C[Maxn][Maxn];

int power(int base, int x) {
	int ret = 1;
	for (; x; x >>= 1, base = LL(base)*base%Mod) {
		if (x&1) {
			ret = LL(ret)*base%Mod;
		}
	}
	return ret;
}

int main() {
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	cin >> n >> k;
	for (int i = 1; i <= n; ++i) {
		f[i] = power(2, i*(i-1)/2);
	}
	if (n == k) {
		for (int i = 0; i <= n; ++i) {
			C[i][0] = 1;
			for (int j = 1; j <= i; ++j) {
				C[i][j] = (C[i-1][j-1]+C[i-1][j])%Mod;
			}
		}
		a[1] = 1;
		for (int i = 2; i <= n; ++i) {
			a[i] = f[i];
			for (int j = 1; j < i; ++j) {
				a[i] = (a[i]-LL(C[i][j])*a[j]%Mod*f[i-j]%Mod)%Mod;
			}
		}
		cout << (a[n]+Mod)%Mod << endl;
	} else {
		int fac = 1;
		for (int i = 2; i <= n; ++i) {
			fac = LL(fac)*i%Mod;
		}
		cout << ((f[n]-fac)%Mod+Mod)%Mod << endl;
	}
	return 0;
}
