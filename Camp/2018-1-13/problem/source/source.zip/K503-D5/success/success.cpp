#include <cstdio>
#include <algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=105,mod=1e9+7;
int n,m,s,t,i,j,k,ans,Lim,f[N][N];
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	f[0][0]=1;
	rep(i,1,m)
	  rep(j,i,s)
	  {
	  	if (i<=n) Lim=min(j,t);
	  	else Lim=j;
	    rep(k,1,Lim)
	      f[i][j]=(f[i][j]+f[i-1][j-k])%mod;
        if (i==m) ans=(ans+f[i][j])%mod;
	  }
	printf("%d\n",ans);
	return 0;
}
