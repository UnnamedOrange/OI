#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while(!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while(isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n = n * sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 1222222;
int n;
int a[N], seq[N];

namespace sp{
	int mx[N], sz = 40;
	int main(){
		double ans = 0, ret;
		rep(i, 1, n){
			memset(mx, 0, sizeof(mx)); mx[sz+1] = INF;
			per(j, i, 1){
				int p = lower_bound(mx + 1, mx + sz + 2, a[j]) - mx - 1;
				if (p > 0){
					rep(k, 1, p - 1) mx[k] = mx[k+1];
					mx[p] = a[j];
				}
				ret = 0;
				rep(k, 1, sz)
					ret = (ret + mx[k]) / 2.;
				ans += ret / n / n;
			}
		}
		printf("%.10lf\n", ans);
		return 0;
	}
};

int main(){
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	read(n);
	rep(i, 1, n) read(a[i]);
	if (n > 100) {sp::main(); return 0;}
	double ans = 0;
	rep(i, 1, n) per(j, i, 1){
		int tt = 0;
		rep(k, j, i) seq[++tt] = a[k];
		sort(seq + 1, seq + tt + 1);
		double ret = 0;
		rep(k, 1, tt)
			ret = (ret + seq[k]) / 2.;
		ans += ret / n / n;
	}
	printf("%.10lf\n", ans);
	return 0;
}

