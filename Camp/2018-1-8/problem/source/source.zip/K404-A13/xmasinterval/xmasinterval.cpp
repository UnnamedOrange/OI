#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
#define For(i, a, b) for(int i = a; i <= b; ++i)
using namespace std;
const int maxn = 1e4 + 5, mod = 1e9 + 9;
int dp[2][maxn], n, m, pos[maxn], cnt, pcnt;
int ptot[maxn << 2], ans;
typedef pair<int, int > pii;
pii itv[maxn];
struct point {
	int x, type, id, rank;
	bool operator < (const point &a) const {
		return x < a.x;
	}
}p[maxn << 2];
int now;
int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	scanf("%d%d", &n, &m);
	For(i, 1, n) {
		scanf("%d", &p[++cnt].x), p[cnt].type = 0, p[cnt].id = i;
		scanf("%d", &p[++cnt].x), p[cnt].type = 1, p[cnt].id = i;
	}
	For(i, 1, m) scanf("%d", &p[++cnt].x), p[cnt].type = 2, p[cnt].id = i;
	sort(p + 1, p + cnt + 1);
	For(i, 1, cnt)  
		if(p[i].x == p[i - 1].x) p[i].rank = p[i - 1].rank;
		else p[i].rank = p[i - 1].rank + 1;
	For(i, 1, cnt) {
		if(p[i].type == 0) itv[p[i].id].first = p[i].rank;
		if(p[i].type == 1) itv[p[i].id].second = p[i].rank;
		if(p[i].type == 2) pos[++pcnt] = p[i].rank, ++ptot[pos[pcnt]];
	}
	sort(itv + 1, itv + n + 1);
	For(i, 1, cnt) ptot[i] += ptot[i - 1];
	dp[0][0] = 1;
	For(i, 0, n - 1) {
		now = i % 2;
		memset(dp[now ^ 1], 0, sizeof(dp[now ^ 1]));
		For(j, 0, m) {
			if(itv[i].second >= itv[i + 1].first - 1) 
				(dp[now ^ 1][ptot[itv[i + 1].second]] += dp[now][j]) %= mod;
			(dp[now ^ 1][j] += dp[now][j]) %= mod;
		}
	}
	printf("%d", dp[now ^ 1][m]);
	return 0;
}
