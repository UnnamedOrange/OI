#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int mod=998244353;
const int N=100010;
struct node{
	int to,next;
};node edge[N*2];
int graph[N],tot;
int deg[N],fa[N],c[N];char s[N];
int f[N],sum[N],g[N],up[N],out[N],p[N];
int ans;int n;

void addedge(int i,int x,int y){
	edge[i].to=y;edge[i].next=graph[x];graph[x]=i;
}

int power(int x,int y){
	int ret=1;
	for(;y;y>>=1,x=1ll*x*x%mod){
		if(y&1)	ret=1ll*ret*x%mod;
	}
	return ret;
}

void DP(int x){
	int i,y;
	for(i=graph[x];i;i=edge[i].next){
		y=edge[i].to;
		if(y==fa[x])	continue;
		fa[y]=x;
		//p[y]=(p[x]+1ll*(1-p[x])*(1-out[x]))%mod;
		DP(y);
		sum[x]=(sum[x]+1ll*f[y]*out[x])%mod;
	}
	if(deg[x]==1) f[x]=0;
	else f[x]=1ll*out[x]*power(1-sum[x],mod-2)%mod;//(1./(1.-sum[x]));
}

void work(int x){
	int i,y;
	g[x]=(sum[x]+1ll*out[x]*up[x])%mod;
	//h[x]=1ll*out[x]*power(1-g[x])%mod;
	if(deg[x]==1){ans=(ans+p[x])%mod;}
	else{
		if(c[x]==0){ans=(ans+p[x])%mod;}
		else{ans=(ans+1ll*p[x]*power(1-g[x],mod-2))%mod;}//(1./(1.-g[x])));
	}
	for(i=graph[x];i;i=edge[i].next){
		y=edge[i].to;
		if(y==fa[x])	continue;		
		up[y]=(g[x]-1ll*out[x]*f[y])%mod;
		up[y]=1ll*out[x]*power(1-up[y],mod-2)%mod;
		p[y]=1ll*p[x]*up[y]%mod;
		work(y);
	}
}	
	
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	int i,x,y;
	scanf("%d",&n);
	scanf("%s",s+1);
	rep(i,1,n)	c[i]=s[i]-'0';
	rep(i,1,n-1){
		scanf("%d%d",&x,&y);
		tot++;addedge(tot,x,y);
		tot++;addedge(tot,y,x);
		deg[x]++;deg[y]++;
	}
	rep(i,1,n)	out[i]=power(deg[i],mod-2);//1./(ld)deg[i];
	p[1]=1;DP(1);work(1);
	ans=(ans+mod)%mod;
	printf("%d\n",ans);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
