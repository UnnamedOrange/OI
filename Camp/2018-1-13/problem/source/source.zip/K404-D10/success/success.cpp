//© 2018 Jazengm/ZengXiangru, AllRightsReserved

#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int p=1000000007;

In void upd(int& a, int b){a=((ll)a+b)%p;}

int main()
{
    freopen("success.in", "r", stdin);
    freopen("success.out", "w", stdout);
    St int s, t, n, m;
    scanf("%d%d%d%d", &s, &t, &n, &m);
    St int f[1<<7], g[1<<7];
    f[0]=1;
    inc(0, i_, n)
    {
        memset(g, 0, sizeof g);
        inc(0, i, i_*t+1)
            inc(1, j, t+1)
                upd(g[i+j], f[i]);
        swap(f, g);
//        inc(0, i, s+1)
//            printf("%d ", f[i]);
//        puts("");
    }
    if(n==m)
    {
        Rg int ans=0;
        inc(n, i, s+1)
            upd(ans, f[i]);
        printf("%d\n", ans);
        Re 0;
    }
    St int c[1<<8][1<<8];
    inc(0, i, 1<<8) c[i][0]=1;
    inc(1, i, 1<<8)
        inc(1, j, i+1)
            c[i][j]=(c[i-1][j]+c[i-1][j-1])%p;
    Rg int ans=0;
    inc(n, i, s)
        inc(m-n, j, s-i+1)
        {
//            printf("i, j: %d %d\n", i, j);
//            printf("f, c: %d %d\n", f[i], c[j-1][m-n-1]);
            upd(ans, (ll)f[i]*c[j-1][m-n-1]%p);
        }
    printf("%d\n", ans);
    Re 0;
}
