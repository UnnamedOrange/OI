from sys import stdin
x, = map(float, stdin.readline().strip().split())
print abs(x)
