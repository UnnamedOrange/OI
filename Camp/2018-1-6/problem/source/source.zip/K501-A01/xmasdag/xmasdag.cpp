#include <stdio.h>
#include <set>
#include <bitset>
#include <string.h>
#include <algorithm>
#include <queue>
#include <cctype>
using namespace std;
#define rep(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_ ; ++i)
#define drep(i, a, b) for(register int i = (a), i##_end_ = (b); i >= i##_end_ ; --i)
typedef long long LL;
#define inf (0x3f3f3f3f)
int read() {
	int x = 0, flag = 1;
	char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') flag = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		x = (x << 3) + (x << 1) + (ch - 0x30);
		ch = getchar();
	}
	return flag * x;
}

#define Maxn 2009
#define Maxm 5009
#define Mod (998244353)
int dp[Maxn][Maxm];
int nxt[Maxm], to[Maxm], head[Maxm], e;
void add(int a, int b){
	to[++e] = b;
	nxt[e] = head[a];
	head[a] = e;
}
int n, m, k, vis[Maxn];
void dfs(int a){
	vis[a] = 1;
	for(int i = head[a];i; i = nxt[i]) {
		int v = to[i];
		if(!vis[v]) dfs(v);
		rep(j, 1, m)
			dp[a][j] += dp[v][j - 1];
	}
}
int power(int a, int b){
	int base = a, r = 1;
	while(b) {
		if(b & 1) r = (1ll * base * r) % Mod;
		base = (1ll * base * base) % Mod;
		b >>= 1;
	}
	return r;
}
int main() {
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n = read(), m = read(), k = read();
	dp[1][0] = 1;
	rep(i, 1, m)  {
		int a = read(), b = read();
		add(b, a);
	}
	rep(i, 1, n)
		if(!vis[i]) dfs(i);
	rep(i, 1, n){
		int ans = 0;
		rep(j, 1, m) 
			if(dp[i][j]){
				ans = (ans * 1ll + dp[i][j] * power(j, k) % Mod) % Mod;
			}
		printf("%d\n", ans);
	}
	return 0;
}
