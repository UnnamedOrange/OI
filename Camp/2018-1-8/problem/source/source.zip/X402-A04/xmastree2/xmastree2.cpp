#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=1000;
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}

int n,maxn=0,val[N],canrt[N],id[N],fa[N],vis[N];
void dfs(int u,int f)
{
	fa[u]=f;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==f) continue;
		dfs(v,u);
	}
}

void wj()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read();
	for(i=1;i<n;++i)
	{
		int x=read(),y=read();
		add(x,y);
	}
	for(i=1;i<=n;++i) val[i]=read(),canrt[i]=read();
	for(i=1;i<=n;++i) id[i]=i;
	do
	{
		if(canrt[id[1]])
		{
			dfs(id[1],0);
			int ans=val[id[1]]; bool can=1;
			for(i=1;i<=n;++i) vis[i]=0;
			vis[id[1]]=1;
			for(i=2;i<=n;++i) 
			{
				if(!vis[fa[id[i]]]) {can=0;break;}
				vis[id[i]]=1;
				ans+=val[id[i]]*i;
			}
			if(can) maxn=max(maxn,ans);
		}
	}while(next_permutation(id+1,id+1+n));
	printf("%d\n",maxn);
	return 0;
}
