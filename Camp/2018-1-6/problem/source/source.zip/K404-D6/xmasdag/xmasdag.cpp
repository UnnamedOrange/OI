#include<cstdio>
#include<queue>
#include<vector>
#define gc getchar()
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
using namespace std;
queue<int>q;
inline int read(){
	char c;while(c=gc,c==' '||c=='\n');int data=c-48;
	while(c=gc,c>='0'&&c<='9')data=(data<<1)+(data<<3)+c-48;return data;
}
const int mod=998244353;
const int maxn=100011;
int d[2002][2002];
vector<int>v[maxn];
int n,m,k,x,y;
int ans[maxn],K_mi[maxn],f[maxn],deg[maxn];
struct edge{
	int to;
	edge *nxt;
}e[maxn<<1],*las[maxn<<1],*et=e;
inline void add(int x,int y){
	*++et=(edge){y,las[x]};las[x]=et;++deg[y];
}
inline int fp(int a,int b){
	int ret=1;
	while(b){
		if(b&1)ret=1ll*ret*a%mod;
		a=1ll*a*a%mod;
		b>>=1;
	}
	return ret;
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read();m=read();k=read();
	FOR(i,1,n)K_mi[i]=fp(i,k);
	FOR(i,1,m){
		x=read();y=read();
		add(x,y);	
	}
	if(k==1){
		FOR(i,2,n)
			if(!deg[i])
				q.push(i);
		q.push(1);
		int now;
		f[1]=1;
		while(!q.empty()){
			now=q.front();q.pop();
			for(register edge *it=las[now];it;it=it->nxt){
				--deg[it->to];
				if(!deg[it->to])
					q.push(it->to);
				f[it->to]=(f[now]+f[it->to])%mod;
				ans[it->to]=(ans[it->to]+(f[now]+ans[now])%mod)%mod;
			}
		}
		FOR(i,1,n)
			printf("%d\n",ans[i]);
		return 0;
	}
	if(n<=2000){
		FOR(i,2,n)
			if(!deg[i])
				q.push(i);
		q.push(1);
		int now,ans;
		d[1][0]=1;
		while(!q.empty()){
			now=q.front();q.pop();
			for(register edge *it=las[now];it;it=it->nxt){
				for(register int i=0;i<=n-1;++i)
					d[it->to][i+1]=(d[it->to][i+1]+d[now][i])%mod;
				--deg[it->to];
				if(!deg[it->to])
					q.push(it->to);
			}
		}
		FOR(i,1,n){
			ans=0;
			FOR(j,1,n)
				ans=(1ll*ans+1ll*d[i][j]*K_mi[j]%mod)%mod;
			printf("%d\n",ans);
		}
		return 0;
	}
	FOR(i,2,n)
		if(!deg[i])
			q.push(i);
	v[1].push_back(0);
	q.push(1);
	int now;
	while(!q.empty()){
		now=q.front();q.pop();
		for(register edge *it=las[now];it;it=it->nxt){
			for(register int i=0;i<(int)v[now].size();++i)
				v[it->to].push_back(v[now][i]+1);
			--deg[it->to];
			if(!deg[it->to])
				q.push(it->to);
		}
		for(register int j=0;j<(int)v[now].size();++j)
			ans[now]=(ans[now]+K_mi[v[now][j]])%mod;
		while((int)v[now].size())
			v[now].pop_back();
	}
	FOR(i,1,n)
		printf("%d\n",ans[i]);
	return 0;
}
