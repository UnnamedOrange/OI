# include <bits/stdc++.h>
# define 	N 		100010
using namespace std;
struct node{
	int data,next;
}e[N*2];
int c[N],f[N],dad[N],head[N],place,n,q,t,u,v,opt,x,l,r;
void build(int u, int v){
	e[++place].data=u; e[place].next=head[v]; head[v]=place;
	e[++place].data=v; e[place].next=head[u]; head[u]=place;
}
void dfs(int x, int fa){
	dad[x]=fa;
	for (int ed=head[x]; ed!=0; ed=e[ed].next)
		if (e[ed].data!=fa)
			dfs(e[ed].data,x);
}
void query(int x, int fa){
	f[c[x]]=true;
	for (int ed=head[x]; ed!=0; ed=e[ed].next)
		if (e[ed].data!=fa)
			query(e[ed].data,x);
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for (int i=1; i<=n; i++)
		scanf("%d",&c[i]);
	for (int i=1; i<n; i++){
		scanf("%d%d",&u,&v);
		build(u,v);
	}
	dfs(1,0);
	int lans=0;
	for (int i=1; i<=q; i++){
		scanf("%d",&opt);
		if (opt==1){
			scanf("%d%d%d",&x,&l,&r);
			if (t==1) l=l^lans, r=r^lans, x=x^lans;
			if (l>r) swap(l,r);
			memset(f,0,sizeof(f));
			query(x,dad[x]); lans=0;
			for (int i=l; i<=r; i++) 
				lans=lans+f[i];
			printf("%d\n",lans);
			
		}
		else {
			scanf("%d%d",&x,&l);
			if (t==1) l=l^lans, x=x^lans;
			c[x]=l;
		}
	}
	return 0;
}

