#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
const int N=1000005;
int n,w[N],rk[N],bin[100005];
long double l,r,ans,nw;

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=getint();
	rep(i,1,n) ++bin[w[i]=getint()];
	rep(i,1,100000) bin[i]+=bin[i-1];
	rep(i,1,n) rk[i]=bin[w[i]],--bin[w[i]];
	rep(i,1,n)
	{
		l=r=1,nw=1;
		rep(j,i+1,n)
		{
			if(rk[j]>rk[i]) nw/=2;
			r+=nw;
		}
		nw=1;
		repd(j,i-1,1)
		{
			if(rk[j]>rk[i]) nw/=2;
			l+=nw;
		}
		ans+=l*r*w[i];
	}
	printf("%.10Lf\n",ans/2/n/n);
	return 0;
}
