#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)1e5+5,P=(int)1e9+7;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
int fast(int x,int p){
	int re=1;
	while(p){
		if(p&1)re=(long long)re*x%P;
		x=(long long)x*x%P,p>>=1;
	}return re;
}
int n,a,b;
int x[M];
struct SHUI{
	void solve(){
		int c1=0,c2=0;
		for(int i=1;i<=n;i++)
			if((x[i]/a)&1)c1++;
			else c2++;
		int C=1,ans1=0,ans2=0;
		for(int i=0;i<=c1;i++){
			if(i&1)Add(ans1,C);
			else Add(ans2,C);
			C=(long long)C*fast(i+1,P-2)%P*(c1-i)%P;
		}
		ans1=(long long)ans1*fast(2,c2)%P;
		ans2=(long long)ans2*fast(2,c2)%P;
		printf("0 0 %d %d\n",ans1,ans2);
	}
}P10;
struct IHSU{
	struct W{
		int dp[7776][2],a,b;
		int bin[10];
		W(){
			for(int i=0;i<10;i++)bin[i]=(1<<i);
			memset(dp,-1,sizeof(dp));
		}
		void init(int A,int B){
			a=A,b=B;
		}
		int dfs(int S,int f){
			int &re=dp[S][f];
			if(re!=-1)return re;
			int stk[15],sz=0,nx[15];
			while(S){
				stk[sz++]=S%6;
				S/=6;
			}
			re=0;
			if(f==0){
				for(int i=0,tmp;i<sz;i++)
					if(stk[i]>=a){
						for(int l=0;l<sz;l++)nx[l]=stk[l];
						nx[i]-=a;
						sort(nx,nx+sz);
						tmp=0;
						for(int l=0;l<sz;l++)tmp=tmp*6+nx[l];
						if(dfs(tmp,1)==0){
							re=1;
							break;
						}
					}
			}else {
				for(int i=0,tmp;i<sz;i++)
					if(stk[i]>=b){
						for(int l=0;l<sz;l++)nx[l]=stk[l];
						nx[i]-=b;
						sort(nx,nx+sz);
						tmp=0;
						for(int l=0;l<sz;l++)tmp=tmp*6+nx[l];
						if(dfs(tmp,0)==0){
							re=1;
							break;
						}
					}
			}
			return re;
		}
		int ask(int S){
			static int stk[15],sz;
			sz=0;
			for(int i=0;i<n;i++)if(S&bin[i])stk[sz++]=x[i+1];
			sort(stk,stk+sz);
			int tmp=0;
			for(int i=0;i<sz;i++)tmp=tmp*6+stk[i];
			return dfs(tmp,0);
		}
	}alice,bob;
	void solve(){
		alice.init(a,b),bob.init(b,a);
		int ans1=0,ans2=0,ans3=0,ans4=0;
		for(int i=0,up=(1<<n),f1,f2;i<up;i++){
			f1=alice.ask(i);
			f2=bob.ask(i);
			if(f1&&!f2)ans1++;
			else if(!f1&&f2)ans2++;
			else if(f1&&f2)ans3++;
			else ans4++;
		}
		printf("%d %d %d %d\n",ans1,ans2,ans3,ans4);
	}
}P10_1;
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	Rd(n),Rd(a),Rd(b);
	for(int i=1;i<=n;i++)Rd(x[i]);
	if(a==b)P10.solve();
	else if(n<=5)P10_1.solve();
	
	return 0;
}
