while true;
do
	python gen.py
	time ./xmastree1
	./bf
	diff xmastree1.ans xmastree1.out || break
	echo "???"
done
echo "!!!"
