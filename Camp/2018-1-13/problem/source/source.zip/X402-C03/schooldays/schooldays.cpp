#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}
template<typename t>inline void chkmax(t&a,t b){if(a<b)a=b;}
template<typename t>inline void chkmin(t&a,t b){if(a>b)a=b;}
template<typename t>inline t max_(t a,t b){return a>=b?a:b;}
template<typename t>inline t min_(t a,t b){return a<=b?a:b;}

typedef long long ll;
const int maxn=1e6+10,mod=1e9+7;
int n,c[maxn],d[maxn],dp[maxn],l[maxn],r[maxn],f[maxn];
//int a[maxn<<2],b[maxn<<2],u[maxn<<2],v[maxn<<2];

inline int chk(int a){
	return a>=mod?a-mod:a;
}
/*
void build(int rt,int l,int r){
	if(l==r){
		a[rt]=c[l];
		b[rt]=d[l];
		return;
	}
	int mid=l+r>>1;
	build(rt<<1,l,mid);
	build(rt<<1|1,mid+1,r);
	a[rt]=min_(a[rt<<1],a[rt<<1|1]);
	b[rt]=max_(b[rt<<1],b[rt<<1|1]);
}
int querya(int rt,int l,int r,int x,int y){
	if(l==x&&r==y)
		return a[rt];
	int mid=l+r>>1;
	if(y<=mid)return querya(rt<<1,l,mid,x,y);
	else if(x>mid)return querya(rt<<1|1,mid+1,r,x,y);
	return min_(querya(rt<<1,l,mid,x,mid),querya(rt<<1|1,mid+1,r,mid+1,y));
}
int queryb(int rt,int l,int r,int x,int y){
	if(l==x&&r==y)
		return b[rt];
	int mid=l+r>>1;
	if(y<=mid)return queryb(rt<<1,l,mid,x,y);
	else if(x>mid)return queryb(rt<<1|1,mid+1,r,x,y);
	return min_(queryb(rt<<1,l,mid,x,mid),queryb(rt<<1|1,mid+1,r,mid+1,y));
}
int best,bestcnt;
void modify(int rt,int l,int r,int pos){
	if(l==r){
		u[rt]=dp[l];
		v[rt]=f[l];
		return;
	}
	int mid=l+r>>1;
	if(pos<=mid)
		modify(rt<<1,l,mid,pos);
	else
		modify(rt<<1|1,mid+1,r,pos);
	if(u[rt<<1]>u[rt<<1|1])
		u[rt]=u[rt<<1],v[rt]=v[rt<<1];
	else if(u[rt<<1]<u[rt<<1|1])
		u[rt]=u[rt<<1|1],v[rt]=v[rt<<1|1];
	else
		u[rt]=u[rt<<1],v[rt]=chk(v[rt<<1]+v[rt<<1|1]);
}
void query(int rt,int l,int r,int x,int y){
	if(l==x&&r==y){
		if(u[rt]>best)
			best=u[rt],bestcnt=v[rt];
		else if(u[rt]==best)
			bestcnt=chk(bestcnt+v[rt]);
		return;
	}
	int mid=l+r>>1;
	if(y<=mid)
		query(rt<<1,l,mid,x,y);
	else if(x>mid)
		query(rt<<1|1,mid+1,r,x,y);
	else{
		query(rt<<1,l,mid,x,mid);
		query(rt<<1|1,mid+1,r,mid+1,y);
	}
}
*/

int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
		c[i]=read(),d[i]=read();
	dp[0]=0;f[0]=1;
	l[0]=-1e9;r[0]=1e9;
	for(int i=1,fir=0;i<=n;++i){
		dp[i]=-1;
		for(int j=fir;j<i;++j){
			chkmax(l[j],j+c[i]),chkmin(r[j],j+d[i]);
			if(l[j]>r[j]){
				++fir;
				continue;
			}
			if(~dp[j]&&l[j]<=i&&i<=r[j])
				if(dp[j]+1>dp[i])
					dp[i]=dp[j]+1,f[i]=f[j];
				else if(dp[j]+1==dp[i])
					f[i]=chk(f[i]+f[j]);
		}
		l[i]=-1e9,r[i]=1e9;
	}
	if(dp[n]==-1)
		puts("-1");
	else
		printf("%d %d\n",dp[n],f[n]);
	return 0;
}
