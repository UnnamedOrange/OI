#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;
const long long Mod=1000000007;
long long s,t,n,m,ans;
void dfs(long long lefted,long long dep)
{
	if(dep>m || lefted==0)
	{
		ans++;
		return ;
	}
	if(dep>n)
		for(long long i=0;i<=lefted;i++) dfs(lefted-i,dep+1);
	else
		for(long long i=0;i<=min(lefted,t);i++) dfs(lefted-i,dep+1);
}
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
	s-=m;t--;
	dfs(s,1);
	printf("%lld ",ans%Mod);
	return 0;
}

