#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
double a[101];
double t[101][101];
int n;
double ans=0;
int main()
{
   freopen("drink.in","r",stdin);
   freopen("drink.out","w",stdout);
   scanf("%d",&n);
   for(int i=1;i<=n;i++)
     cin>>a[i];
   for(int i=1;i<=n;i++)
     for(int j=i;j<=n;j++)
	 	for(int k=i;k<=j;k++)
	 	{
	 	  int p=0;
	 	  for(int q=i;q<=j;q++)
	 	    if(a[q]>a[k]||(a[q]==a[k]&&q<=k))
	 	      p++;
	 	  t[k][p]+=1;
	 	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		  cout<<t[i][j]<<" ";
		cout<<endl;
	}
	//return 0;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=n;j++)
	  {
	    ans=ans+((a[i]*t[i][j])/double (1<<j))/double(n*n);
	    printf("%.6f\n",ans);
	  }
    printf("%.6f",ans);
}
