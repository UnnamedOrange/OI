#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int inf=0x3f3f3f3f;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
#ifdef ztzshiwo
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);
#endif
}
int type,n,T;
inline void Solve1()
{
	int x,y;
	read(n),read(T);
	For(i,1,T)
	{
		read(x),read(y);
		For(j,0,9)
		if(((x>>j)&1)!=((y>>j)&1))
		{
			printf("%d\n",(((x>>j)&1)?1:11)+j);
			break;
		}
	}
}
inline void Solve2()
{
	int x,h;
	read(n),read(T);
	For(i,1,T)
	{
		read(x),read(h);
		int flag=h>10,pos=(h-1)%10;
		if((x>>pos)&1)printf("%s\n",flag?"no":"yes");
		else printf("%s\n",flag?"yes":"no");
	}
}
int main()
{
	file();
	read(type);
	if(type==1)Solve1();
	else Solve2();
	return 0;
}
