#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int pi[100005];
int n;long long ans;
int vis[11];
int bu=0;
int gree[11];

void pan(int u)
{
	if(u==0)
	{
		bu=1;
	    return;
	}
	bu++;
	vis[u]=1;
	if(vis[pi[u]]==0)
	  pan(pi[u]);
}

int dfs(int k)
{
	memset(vis,0,sizeof(vis));
	bool y=0;
	for(int i=1;i<=n;i++)
	  if(vis[i]==0)
	  {
	    bu=0;
		pan(i);
		if(bu%2==1)
		  y=1;
	  }
	if(y==0)ans++;
	for(int i=k;i<=n;i++)
	  if(pi[i]==0)
	  	for(int j=1;j<=n;j++)
	  		if(gree[j]==0)
	  		{
	  			pi[i]=j;
	  			gree[j]++;
	  			dfs(i+1);
	  			pi[i]=0;
	  			gree[j]--;
			}
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
	  scanf("%d",&pi[i]);
	  gree[pi[i]]++;
	  if(pi[i]!=0)bu=1;
    }
    if(n%2==1)
    {
    	printf("0");
    	return 0;
	}
    if(bu==0)
    {
    	ans=1;
    	for(long long i=1;i<=n-1;i=i+2)
    	  ans=(ans*i)%998244353;
    	ans=(ans*ans)%998244353;
    	printf("%lld",ans);
    	return 0;
	}
	dfs(1);
	printf("%lld",ans);
}
