#include <cstdio>
#include <algorithm>
#include <cmath>
#include <vector>
using namespace std;
#define N 100050
#define M 70
int st[N],ed[N],euler[N],a[N],id,lf[M][N],l[M],r[M],cnt[M][N],n,q,t,p,i,j,k,f[M][M][M],ans,b[N];
vector<int> g[N];
void dfs(int now,int lst)
{
	st[now]=++id;euler[id]=now;
	for (int ii=0;ii<g[now].size();ii++) if (g[now][ii]!=lst) dfs(g[now][ii],now);
	ed[now]=id;
}
int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);p=floor(pow(n,0.666));
	for (i=1;i<=n;i++) scanf("%d",&a[i]);
	for (i=1;i<n;i++){
		int x,y;scanf("%d%d",&x,&y);
		g[x].push_back(y);g[y].push_back(x);
	}dfs(1,0);
	for (i=1;i<=n/p+1;i++) l[i]=n+1;
	for (i=1;i<=n;i++) l[i/p+1]=min(l[i/p+1],i),r[i/p+1]=max(r[i/p+1],i),cnt[i/p+1][a[euler[i]]]++;
	for (j=1;j<=n/p+1;j++)
	for (i=1;i<=n;i++) lf[j][i]=cnt[j][i]?j:lf[j-1][i];
	for (i=1;i<=n/p+1;i++)
	for (j=1;j<=n;j++) f[i][lf[i][j]][j/p+1]++;
	for (i=1;i<=n/p+1;i++)
	for (j=1;j<=i;j++)
	for (k=1;k<=n/p+1;k++) f[i][j][k]+=f[i][j][k-1];
	while (q--){
		int opt;scanf("%d",&opt);
		if (opt==1){
			int x,y,z;scanf("%d%d%d",&x,&y,&z);if (t) x^=ans,y^=ans,z^=ans;
			int l1=st[x],r1=ed[x],l2=y,r2=z,l3=l1/p+2,r3=r1/p,l4=l2/p+1,r4=r2/p;
			if (l1/p==r1/p){
				ans=0;
				for (i=l1;i<=r1;i++){
					if (!b[a[euler[i]]]&&a[euler[i]]>=l2&&a[euler[i]]<=r2) ans++;
					b[a[euler[i]]]++;
				}
				for (i=l1;i<=r1;i++) b[a[euler[i]]]--;
				printf("%d\n",ans);continue;
			}
			if (l2/p==r2/p){
				ans=0;
				for (i=l1;i<=r[l1/p+1];i++) b[a[euler[i]]]++;
				for (i=l[r1/p+1];i<=r1;i++) b[a[euler[i]]]++;
				for (i=l2;i<=r2;i++) if (lf[r3][i]>=l3||b[i]) ans++;
				for (i=l1;i<=r[l1/p+1];i++) b[a[euler[i]]]--;
				for (i=l[r1/p+1];i<=r1;i++) b[a[euler[i]]]--;
				printf("%d\n",ans);continue;
			}ans=0;
			for (j=l3;j<=r3;j++) ans+=f[r3][j][r4]-f[r3][j][l4];
			for (i=l2;i<=r[l2/p+1];i++) if (lf[r3][i]>=l3) ans++;
			for (i=l[r2/p+1];i<=r2;i++) if (lf[r3][i]>=l3) ans++;
			for (i=l1;i<=r[l1/p+1];i++){
				if (!b[a[euler[i]]]&&a[euler[i]]>=l2&&a[euler[i]]<=r2&&lf[r3][a[euler[i]]]<l3) ans++;
				b[a[euler[i]]]++;
			}
			for (i=l[r1/p+1];i<=r1;i++){
				if (!b[a[euler[i]]]&&a[euler[i]]>=l2&&a[euler[i]]<=r2&&lf[r3][a[euler[i]]]<l3) ans++;
				b[a[euler[i]]]++;
			}
			for (i=l1;i<=r[l1/p+1];i++) b[a[euler[i]]]--;
			for (i=l[r1/p+1];i<=r1;i++) b[a[euler[i]]]--;
			printf("%d\n",ans);
		}else{
			int x,y;scanf("%d%d",&x,&y);if (t) x^=ans,y^=ans;x=st[x];
			int gh=a[euler[x]];a[euler[x]]=y;
			cnt[x/p+1][gh]--;cnt[x/p+1][y]++;
			for (i=1;i<=n/p+1;i++) 
			for (k=gh/p+1;k<=n/p+1;k++) f[i][lf[i][gh]][k]--;
			for (i=1;i<=n/p+1;i++) 
			for (k=y/p+1;k<=n/p+1;k++) f[i][lf[i][y]][k]--;
			for (i=1;i<=n/p+1;i++) lf[i][gh]=cnt[i][gh]?i:lf[i-1][gh],lf[i][y]=cnt[i][y]?i:lf[i-1][y];
			for (i=1;i<=n/p+1;i++) 
			for (k=gh/p+1;k<=n/p+1;k++) f[i][lf[i][gh]][k]++;
			for (i=1;i<=n/p+1;i++) 
			for (k=y/p+1;k<=n/p+1;k++) f[i][lf[i][y]][k]++;
		}
	}
	return 0;
}
