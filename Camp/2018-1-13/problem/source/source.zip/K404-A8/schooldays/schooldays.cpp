#include <cstdio>

int main() {
	freopen( "schooldays.in", "r", stdin );
	freopen( "schooldays.out", "w", stdout );
	puts( "-1" );
	return 0;
}
