#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=1e6;
int q[11],l[11],len,s[N+5],mu[N+5],ans,fl[N+5],an[N+5];
void dfs(int x,int w){
	if (x==len+1){
		an[ans]+=mu[w]*s[ans/w]; return;
	}
	dfs(x+1,w);
	For(i,1,l[x]) w=w*q[x],dfs(x+1,w);
}
int main(){
	freopen("function.in","r",stdin); freopen("function.out","w",stdout);
	int x,y,_=read();
	For(i,2,N>>1) fl[i<<1]=2;
	for(int i=3;i<=N;i+=2)
		if (!fl[i]&&i<1000)
				for(int j=i*i;j<=N;j+=(i<<1)) fl[j]=i;
	mu[1]=1; s[1]=1;
	For(i,2,N)
		if (!fl[i]) mu[i]=-1,s[i]=2;
		else{
			x=i; ans=0; while(x%fl[i]==0) x=x/fl[i],++ans;
			if (ans==1) mu[i]=mu[x]*mu[i/x]; s[i]=(ans+1)*s[x];
		}
	For(i,2,N) s[i]=s[i]*s[i];
	For(i,1,N){
		x=i; len=0; ans=i;
		while(fl[x]){
			y=fl[x]; q[++len]=y; l[len]=0;
			while(x%y==0) x=x/y,++l[len];
 		}
		if (x>1) q[++len]=x,l[len]=1; dfs(1,1);
	}
	For(i,2,N) an[i]+=an[i-1];
	while(_--) x=read(),printf("%d\n",an[x]);
	return 0;
}
