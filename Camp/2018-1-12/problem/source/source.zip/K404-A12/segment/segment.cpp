#include <iostream>
#include <cstdio>
#include <cstring>
#define mod 998244353
using namespace std;
typedef long long ll;
int n,m,K;
ll quick_pow(ll a,ll b){
	ll ans=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1) ans=ans*a%mod;
	return ans;
}
int sum[100005],tot[100005];
ll ans=0;
void dfs(int k,int l,int r){
	if(k>n){
		for(int i=1;i<=m;i++) tot[i]=sum[i]+tot[i-1],ans=(ans+quick_pow(tot[i],K))%mod;
		return;
	}
	for(int i=l+1;i<=m;i++){
		for(int p=max(r+1,i);p<=m;p++){
			sum[i]++;sum[p]--;
			dfs(k+1,i,p);
			sum[i]--;sum[p]++;
		}
	}
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	dfs(1,0,0);
	printf("%lld",ans);
	return 0;
}
