#include<bits/stdc++.h>

#define ll long long
#define inf 999999999
#define mm(a, b) memset(a, b, sizeof(a))

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 110;

const int mod = 1e9 + 7;

int s, t, n, m, dp[maxn][maxn];

void Get(){
	s = read(), t = read(), n = read(), m = read();
}

void solve_bf(){
	dp[0][0] = 1;
	int Ans = 0;

	For(i, 0, m-1){
		For(j, 0, s){
			if(!dp[i][j]) continue;
			int tmp = s-j;
			if(i+1 <= n) tmp = min(tmp, t);
			For(k, 1, tmp){
				(dp[i+1][k+j] += dp[i][j]) %= mod;
			}
		}
	}

	For(i, 1, s) (Ans += dp[m][i]) %= mod;
	printf("%d\n", Ans);
}

int main(){
	
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);

	Get();
	solve_bf();

	return 0;
}
