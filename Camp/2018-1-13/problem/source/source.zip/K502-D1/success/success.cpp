#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>

using namespace std;

int n, m, s, t;
long long mod = 1000000007;
long long ans = 0;
long long f[200][200];

void open()
{
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}
int main()
{
	open();
	s = read(), t = read(), n = read(), m = read();
	if(n <= 100) {
		f[0][0] = 1;
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= s; j++) {
				for(int k = t;  k >= 1; k--) {
					if(j - k >= 0) {
						f[i][j] = (f[i][j] + f[i - 1][j - k]) % mod;
					}
				}
			}
		}
		for(int i = n + 1; i <= m; i++) {
			for(int j = 1; j <= s; j++) {
				for(int k = j;  k >= 1; k--) {
					if(j - k >= 0) {
						f[i][j] = (f[i][j] + f[i - 1][j - k]) % mod;
					}
				}
			}
		}
		/*for(int i = 1; i <= m; i++) {
			for(int j = 1; j <= s; j++) {
				cout<<f[i][j]<<" ";
			}
			cout<<endl;
		}
		cout<<endl;*/
		for(int i = 1; i <= s; i++) {
			ans = (ans + f[m][i]) % mod;
		}
		printf("%lld\n", ans);
	}
	close();
	return 0;
}
