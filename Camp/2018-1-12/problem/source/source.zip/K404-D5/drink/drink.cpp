#include<cstdio>
#include<queue>
using namespace std;

const int maxn = 1e6 + 5;
long long ini[maxn];
long long n;
long long n2;
double ans, lin;

inline void workk(int l, int r)
{
	double ret = 0;
	priority_queue<int> q;
	for(int i = l; i <= r; ++i)
	{
		q.push(-ini[i]);
	}
	while(!q.empty())
	{
		lin = q.top(); q.pop(); lin = -lin;
		ret = (ret + lin) / 2;
	}
	ans += (ret / n2);
}

int main()
{
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	scanf("%lld", &n); n2 = n * n;
	if(n <= 100)
	{
		for(int i = 1; i <= n; ++i)
		scanf("%lld", &ini[i]);
		for(int i = 1; i <= n; ++i)
		{
			for(int j = i; j <= n; ++j)
			{
				workk(i, j);
			}
			}
		printf("%lf", ans);
	}

	return 0;
}
