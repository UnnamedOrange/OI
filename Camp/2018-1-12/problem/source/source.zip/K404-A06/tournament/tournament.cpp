#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
using namespace std;
const int mod=998244353;
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	int n,k;scanf("%d%d",&n,&k);k=1;
	for(int i=1;i<n;++i)k=1ll*k*i%mod;
	printf("%d\n",k);
}
