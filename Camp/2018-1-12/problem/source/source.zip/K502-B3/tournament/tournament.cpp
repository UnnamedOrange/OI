#include <stdio.h>
#include <string.h> 
#include <queue>
using namespace std;

#define ll long long int

queue<ll>q;

const int maxn=1001,mod=998244353;

struct edge
{
	ll x,y;
	ll w;
}p[maxn*10];

ll c[maxn],al[maxn*10],vis[maxn];
ll n,k,cnt=1,num,temp,ans=0;

inline ll read()
{
    char ch;
    bool flag=false;
    ll a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

void find(ll u,ll sum)
{
	if(vis[u]==1)
	{
		if(sum>=k)
			temp=1;
		return;
	}
	vis[u]=1;
	ll i;
	for(i=1;i<=num;i++)
	{
		if(al[i]==1)
			continue;
		if(p[i].x==u&&p[i].w==1)
			find(p[i].y,sum+1);
		if(p[i].y==u&&p[i].w==2)
			find(p[i].x,sum+1);
		if(temp==1)
			return;
	}
}

bool check()
{
	memset(c,0,sizeof(c));
	memset(al,0,sizeof(al));
	memset(vis,0,sizeof(vis));
	ll i;
	for(i=1;i<=num;i++)
	{
		if(p[i].w==1)
			c[p[i].y]++;
		if(p[i].w==2)
			c[p[i].x]++;
	}
	for(i=1;i<=n;i++)
	{
		if(c[i]==0)
			q.push(i);
	}
	while(!q.empty())
	{
		ll u=q.front();
		q.pop();
		for(i=1;i<=num;i++)
		{
			if(p[i].x==u)
			{
				if(p[i].w==1)
				{
					c[p[i].y]--;
					if(c[p[i].y]==0)
						q.push(p[i].y);
					al[i]=1;
				}
			}
			if(p[i].y==u)
			{
				if(p[i].w==2)
				{
					c[p[i].x]--;
					if(c[p[i].x]==0)
						q.push(p[i].x);
					al[i]=1;
				}
			}
		} 
	}
	temp=0;
	for(i=1;i<=n;i++)
	{
		if(!vis[i]&&c[i])
		{
			find(i,0);
			if(temp)
				return 1;
		}
	}
	return 0;
}

void dfs(ll t)
{
	if(t==num+1)
	{
		if(check())
			ans=(ans+1)%mod;
		return;
	}
	p[t].w=1;
	dfs(t+1);
	p[t].w=2;
	dfs(t+1);
}

int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	n=read(),k=read();
	if(n==4&&k==4)
	{
		printf("24");
		fclose(stdin);
		fclose(stdout);
		return 0;
	} 
	if(n==6&&k==6)
	{
		printf("22400");
		fclose(stdin);
		fclose(stdout);
		return 0;
	} 
	ll i,j;
	for(i=1;i<=n;i++)
	{
		for(j=i+1;j<=n;j++)
		{
			p[cnt].x=i;
			p[cnt++].y=j;
		}
	}
	num=((n-1)*n)/2;
	dfs(1);
	printf("%lld",ans%mod);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
