#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=0;
	while (ch<'0' || ch>'9'){
		  if (ch=='-') w=-1;
		  ch=getchar();
	}
	while (ch<='9' && ch>='0'){
		  x=(x<<1)+(x<<3)+ch-'0';
		  ch=getchar();
	}
	return x*w;
}
const int Mod=1e9+7;
int n,x,y;
int tot1,tot2; 
int mult(int x,int y){
	return (int)((long long)x*(long long)y%(long long)Mod);
}
int add(int x,int y){
	x%=Mod;y%=Mod;
	return ((x+y)%Mod+Mod)%Mod;
}
int Pow(int x,int y){
	int res=1;
	while (y){
		if (y%2==1) res=mult(res,x);
		x=mult(x,x);
		y/=2;
	}
	return res;
}
int c[100010],r[100010];
int C(int x,int y){
	if (x>y) return 0;
	return mult(c[y],mult(r[x],r[y-x]));	
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n=read();
	x=read();y=read();
	c[0]=r[0]=1;
	for (int i=1;i<=n;++i){
		c[i]=mult(c[i-1],i);
		r[i]=Pow(c[i],Mod-2);
	}
	if (x==y){
		printf("0 0 ");
		for (int i=1;i<=n;++i){
			int k=read();
			if ((k/x)%2==0) tot2++;
			else tot1++; 
		}
		int ans1=0,ans2;
		for (int i=1;i<=tot1;i+=2)
			ans1=add(ans1,C(i,tot1));	
		ans1=mult(ans1,Pow(2,tot2));
		ans2=add(Pow(2,n),-ans1);
		printf("%d %d\n",ans1,ans2);
		return 0;
	}	
	
	return 0;
}

