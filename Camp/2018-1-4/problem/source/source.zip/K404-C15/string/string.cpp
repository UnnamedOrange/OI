#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#define enter putchar('\n')
#define space putchar(' ')
using namespace std;
typedef long long ll;
template <class T>
void read(T &x){
	char c;
	bool op = 0;
	while(c = getchar(), c < '0' || c > '9')
		if(c == '-') op = 1;
	x = c - '0';
	while(c = getchar(), c >= '0' && c <= '9')
		x = x * 10 + c - '0';
	if(op) x = -x;	
}
template <class T>
void write(T x){
	if(x < 0) putchar('-'), x = -x;
	if(x >= 10) write(x / 10);
	putchar('0' + x % 10);
}

int n, m, nxt[10][105], len[10];
char s[10][105], a[605];

bool getnxt(char *b, int *nxt, int len){
	nxt[1] = 0;
	for(int i = 2, j = 0; i <= len; i++){
		while(j && b[j + 1] != b[i]) j = nxt[j];
		if(b[j + 1] == b[i]) j++;
		nxt[i] = j;
	}
}
bool kmp(char *b, int *nxt, int len){
	for(int i = 1, j = 0; i <= 2 * m; i++){
		while(j && b[j + 1] != a[i]) j = nxt[j];
		if(b[j + 1] == a[i]) j++;
		if(j == len) return 1;
	}
	return 0;
}
void solve1(){
	int ans = 0;
	for(int i = 1; i <= n; i++){
		len[i] = strlen(s[i] + 1);
		getnxt(s[i], nxt[i], len[i]);
	}
	for(int i = 0; i < (1 << m); i++){
		for(int j = 1; j <= m; j++){
			a[j] = ((i >> (j - 1)) & 1) + '0';
			a[2 * m - j + 1] = (((i >> (j - 1)) & 1) ^ 1) + '0';
		}
		bool ok = 1;
		for(int i = 1; i <= n; i++)
			if(!kmp(s[i], nxt[i], len[i])) ok = 0;
		if(ok) ans++;
	}
	write(ans), enter;
}

int main(){
	
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	
	read(n), read(m);
	for(int i = 1; i <= n; i++)
		scanf("%s", s[i] + 1);
	if(m <= 15) solve1();
	
	return 0;
}
/*
2 3
011
001
*/
