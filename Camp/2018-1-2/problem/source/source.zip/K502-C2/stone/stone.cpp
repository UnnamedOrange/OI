#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<map>
#include<vector>

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while (c = getchar(), c >= '0');
}

const int M = (int)1e5 + 5;
const int P = (int)1e9 + 7;

int n, a, b, A[M];

namespace Subtask1 {
	
	map < pair< int, vector<int> >, bool > Mp;
	
	bool dfs(int f, vector <int> T) {
		if (Mp.find(make_pair(f, T)) != Mp.end()) return Mp[make_pair(f, T)];
		if (!f) {
			for (int i = 0; i < (int)T.size(); i++) {
				if (T[i] >= a) {
					vector <int> nxt = T;
					nxt[i] -= a;
					sort(nxt.begin(), nxt.end());
					if (!dfs(!f, nxt)) return Mp[make_pair(f, T)] = true;
				}
			}
		} else {
			for (int i = 0; i < (int)T.size(); i++) {
				if (T[i] >= b) {
					vector <int> nxt = T;
					nxt[i] -= b;
					sort(nxt.begin(), nxt.end());
					if (!dfs(!f, nxt)) return Mp[make_pair(f, T)] = true;
				}
			}
		}
		return Mp[make_pair(f,T)] = false;
	}
	
	void solve() {
		int ans1 = 0, ans2 = 0, ans3 = 0, ans4 = 0;
		for (int i = 0; i < (1 << n); i++) {
			vector <int> vec;
			for (int j = 0; j < n; j++)
				if (i >> j & 1) vec.push_back(A[j + 1]);
			sort(vec.begin(), vec.end());
			bool f1 = dfs(0, vec), f2 = dfs(1, vec);
			if (f1 && !f2) ans1++;
			if (!f1 && f2) ans2++;
			if (f1 && f2) ans3++;
			if (!f1 && !f2) ans4++;
		}
		printf("%d %d %d %d\n", ans1, ans2, ans3, ans4);
	}
	
}

namespace Subtask2 {
	
	int f[M], dp[M][2];
	
	void solve() {
		for (int i = 1; i <= n; i++)
			f[i] = (A[i] / a) & 1;
		for (int i = 1; i <= n; i++)
			for (int j = 0; j < 2; j++)
				dp[i][j] = (dp[i - 1][j] + dp[i - 1][j ^ f[i]] + (f[i] == j)) % P;
		dp[n][0] = (dp[n][0] + 1) % P;
		printf("0 0 %d %d\n", dp[n][1], dp[n][0]);
	}
	
}

int main() {
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	int mx = 0;
	Rd(n), Rd(a), Rd(b);
	for (int i = 1; i <= n; i++) Rd(A[i]), mx = max(mx, A[i]);
	if (n <= 5 && mx <= 5) Subtask1::solve();
	else if (a == b) Subtask2::solve();
	return 0;
}
