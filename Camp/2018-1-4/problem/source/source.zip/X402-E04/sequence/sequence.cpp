#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
#define Forr(i,j,k) for(int i=j;i>=k;--i)
#define ll long long 
using namespace std;
const int N=50,INF=0x3f3f3f3f;
template<class T>void read(T &x){
	x=0;char c=getchar();
	while(!isdigit(c))c=getchar();
	while( isdigit(c))x=x*10+c-48,c=getchar();
}
template<class T>inline bool chmi(T &a,T b){return a>b?a=b,1:0;}
template<class T>inline bool chmx(T &a,T b){return a<b?a=b,1:0;}
inline void file(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
}
int n,a[N],lim;
void init(){
	read(n);
	For(i,1,n)read(a[i]);
}
int ok;
bool dfs(int now,int g,int last){
	if(ok)return 1;
	if(now+g>lim)return 0;
	if(now==lim){
		For(i,1,n)if(a[i]!=i)return 0;ok=1;
		return 1;
	}
	int t=n,G;
	while(a[t]==t&&t)t--;
	For(j,2,t){
		if(j==last)continue;
		G=g+(abs(a[j]-a[j+1])==1)-(abs(a[1]-a[j+1])==1);
		reverse(a+1,a+j+1);
		if(dfs(now+1,G,j))return 1;
		reverse(a+1,a+j+1);
	}	
	return 0;
}
int Get(){
	int ret=0;
	a[n+1]=n+1;
	For(i,1,n)ret+=(abs(a[i]-a[i+1])!=1);
	return ret;
}
void solve(){
	int G=Get();ok=0;
	for(lim=0;;lim++){
		if(dfs(0,G,1))return void(printf("%d\n",lim));
	}
}
int main(){
	file();
	int T;
	read(T);
	while(T--)init(),solve();
	return 0;
}
