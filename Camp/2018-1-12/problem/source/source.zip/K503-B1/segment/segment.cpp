#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
const long long mod=998244353;
int n,m;
long long ans;
int i,j,k,a[maxn],b[maxn],c[20];
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
long long getax(long long a,long long x){
	long long t1=1,t2=1,t3=a;
	while (x!=0){
		if (x%(t1*2)/t1==1){
			x=x-t1;
			t2=(t2*t3)%mod;
		}
		t1=t1*2; t3=(t3*t3)%mod;
	}
	return t2;
}
void check(){
	int i,j;
	memset(c,0,sizeof(c));
	for (i=1;i<=n;i++){
		for (j=a[i];j<=b[i]-1;j++){
			c[j]++;
		}
	}
	for (i=1;i<=m;i++){
		ans=(ans+getax(c[i],k))%mod;
	}
}
void work(int x,int l,int r){
	int i,j;
	if (x==n+1){
		check();
		return;
	}
	for (i=l+1;i<=m;i++){
		for (j=r+1;j<=m;j++){
			a[x]=i; b[x]=j;
			if (i<=j) work(x+1,i,j);
		}
	}
}
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	n=read(); m=read(); k=read();
	ans=0;
	if (n==1){
		for (i=1;i<=m;i++){
			ans=(ans+(m-i)*i)%mod;
		}
		printf("%lld\n",ans);
		return 0;
	}
	if (m<=6){
		work(1,0,0);
		printf("%lld\n",ans);
	}
	return 0;
}
