#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,K,tot;
int a[4011],b[4011],sum1[4011],sum2[4011],f1[4011][4011],f2[4011][4011],SUM1[4011][4011],SUM2[4011][4011],fns1[4011][4011],fns2[4011][4011];

int main()
{
  freopen("subsequence.in","r",stdin);
  freopen("subsequence.out","w",stdout);
  int i,j,k,t,pd=0,t1,t2,tt1,tt2;
  scanf("%d%d%d",&n,&m,&K);
  for(i=1;i<=n;i++) scanf("%d",&a[i]);
  for(i=1;i<=m;i++) scanf("%d",&b[i]);
  for(i=n;i>=1;i--)
    for(j=1;j<=K;j++) 
	  if(a[i]==j) SUM1[i][j]=SUM1[i+1][j]+1;
	  else SUM1[i][j]=SUM1[i+1][j];
  for(i=m;i>=1;i--)
    for(j=1;j<=K;j++) 
	  if(b[i]==j) SUM2[i][j]=SUM2[i+1][j]+1;
	  else SUM2[i][j]=SUM2[i+1][j];
  for(i=1;i<=K;i++) f1[0][i]=f2[0][i]=1;
  sum1[0]=sum2[0]=K;
  for(i=1;i<=n;i++)
    {
	  for(j=i;j>=1;j--)
	   { 
	    if(sum1[j-1]==K) 
		 {
		  if(!f1[j][a[i]]) 
		   {
		    sum1[j]++;
		    fns1[j][a[i]]=1;
		   }
		  f1[j][a[i]]=1;
		 }
	   }
	}
  for(i=1;i<=m;i++)
    {
	  for(j=i;j>=1;j--)
	   { 
	    if(sum2[j-1]==K) 
		 {
		  if(!f2[j][b[i]]) 
		   {
		    sum2[j]++;
	        fns2[j][b[i]]=1;
		   }
		  f2[j][b[i]]=1;
		 }
	   }
	}
  t1=t2=0;
  for(i=1;i<=n;i++) 
   {
   	t1++,t2++,tt1=t1,tt2=t2;
    for(j=1;j<=K;j++)
      {
      	if(f1[i][j]) tt1=max(tt1,fns1[i][j]);
      	else if(f2[i][j]) tt2=max(tt2,fns2[i][j]);
      	else 
      	  {
		   	if(SUM1[t1][j])
		   	  {
			   for(k=t1;a[k]!=j;k++);	 
			   tt1=max(tt1,k);
			  }
			else {pd=1;break;}
			if(SUM2[t2][j])
		   	  {
			   for(k=t2;b[k]!=j;k++);
			   tt2=max(tt2,k);	 
			  }
			else {pd=1;break;}
		  }
	  }
	if(pd) break;
	t1=tt1,t2=tt2;
   }
  printf("%d\n",i);
}
