/*
Author: CNYALI_LK
LANG: C++
PROG: tournament.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
const ll p=998244353;
int a[66][66];
int geth(int n,int m){
	for(int k=1;k<=n;++k){
		for(int i=1;i<=n;++i)for(int j=1;j<=n;++j){
			if(a[i][j]!=0x3f3f3f3f&&a[j][k]!=0x3f3f3f3f&&a[k][j]!=0x3f3f3f3f)if(a[i][j]+a[j][k]+a[k][j]==m)return 1;
		}
		for(int i=1;i<=n;++i)for(int j=1;j<=n;++j){
			chkmin(a[i][j],a[i][k]+a[k][j]);
		}
	}
	return 0;
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	ll n,m;
	n=read();
	m=read();
	int s=1<<(n*(n-1)>>1);
	int cnt=0;
	for(int i=0;i<s;++i){
		int T=1;
		for(int j=1;j<=n;++j)for(int k=j+1;k<=n;++k){
			a[j][k]=i&T?1:0x3f3f3f3f;
			a[k][j]=i&T?0x3f3f3f3f:1;
			T<<=1;
		}
		if(geth(n,m))++cnt;
	}
	printf("%lld\n",cnt);
	return 0;
}

