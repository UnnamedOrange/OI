#include<bits/stdc++.h>
using namespace std;
int t,m,n,a[10],b[10],x,y;
int main(){
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	
	scanf("%d",&t);
	if (t==1)
	{
		scanf("%d%d",&n,&m);
		for (int i=1;i<=m;i++)
		{
			scanf("%d%d",&x,&y);
			for (int j=1;j<=5;j++)
			{
			  a[j]=x%4;
			  x/=4;
			}
			for (int j=1;j<=5;j++)
			{
			  b[j]=y%4;
			  y/=4;
			}
			for (int i=1;i<=5;i++)
			  if (a[i]!=b[i])
			  {
			    printf("%d\n",i*4+a[i]-3);;
				break;
			  }
		}
	}
	if (t==2)
	{
		scanf("%d%d",&n,&m);
		for (int i=1;i<=m;i++)
		{
		scanf("%d%d",&x,&y);	
		for (int j=1;j<=5;j++)
		{
		  a[j]=x%4;
		  x/=4;
		}
		if (a[(y+3)/4]==(y+3)%4) printf("yes\n");
		else printf("no\n");
		}
	}
	return 0;
}

