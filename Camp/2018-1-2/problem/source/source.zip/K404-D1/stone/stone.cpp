#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#define mod 1000000007
using namespace std;
int n,m,a,b;
int ans1,ans2,ans3,ans4;
int f[100010][2],siz[100010],now[10];
bool dfs0(bool step)
{
    if(!step)
    {
        bool flag=false;
        for(int i=1; i<=m; i++)
            if(now[i]>=a)
            {
                now[i]-=a;
                flag|=dfs0(step^1);
                now[i]+=a;
            }
        return flag;
    }
    else
    {
        bool flag=true;
        for(int i=1; i<=m; i++)
            if(now[i]>=b)
            {
                now[i]-=b;
                flag&=dfs0(step^1);
                now[i]+=b;
            }
        return flag;
    }
}
bool dfs1(bool step)
{
    if(step)
    {
        bool flag=false;
        for(int i=1; i<=m; i++)
            if(now[i]>=b)
            {
                now[i]-=b;
                flag|=dfs1(step^1);
                now[i]+=b;
            }
        return flag;
    }
    else
    {
        bool flag=true;
        for(int i=1; i<=m; i++)
            if(now[i]>=a)
            {
                now[i]-=a;
                flag&=dfs1(step^1);
                now[i]+=a;
            }
        return flag;
    }
}
void sp1()
{
    for(int i=1; i<=n; i++)
    {
        f[i][0]=f[i-1][0],f[i][1]=f[i-1][1];
        if((siz[i]/a)&1)
        {
            f[i][1]+=f[i-1][0]+1;
            f[i][0]+=f[i-1][1];
            if(f[i][1]>=mod)
                f[i][1]-=mod;
        }
        else
        {
            f[i][0]+=f[i-1][0]+1;
            f[i][1]+=f[i-1][1];
            if(f[i][0]>=mod)
                f[i][0]-=mod;
        }
    }
    printf("0 0 %d %d",f[n][1],f[n][0]+1);
    exit(0);
}
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
    n=read(),a=read(),b=read();
    for(int i=1; i<=n; i++)
        siz[i]=read();
    if(a==b)
        sp1();
    for(int i=0; i<(1<<n); i++)
    {
        m=0;
        for(int j=1; j<=n; j++)
            if(i&(1<<(j-1)))
                now[++m]=siz[j];
        bool afirst=dfs0(0),bfirst=dfs1(1);
        bool everya=1,everyb=1;
        for(int j=1; j<=m; j++)
            if(now[j]>=b)
            {
                now[j]-=b;
                everya&=dfs0(0);
                now[j]+=b;
            }
        for(int j=1; j<=m; j++)
            if(now[j]>=a)
            {
                now[j]-=a;
                everyb&=dfs1(1);
                now[j]+=a;
            }
        if(afirst&&everya)
            ans1++;
        if(bfirst&&everyb)
            ans2++;
        if(afirst&&bfirst)
            ans3++;
        if(everya&&everyb)
            ans4++;
    }
    printf("%d %d %d %d",ans1,ans2,ans3,ans4);
    return 0;
}
