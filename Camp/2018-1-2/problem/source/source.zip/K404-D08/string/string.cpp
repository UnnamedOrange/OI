#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
const int N=100010;
int n;
char s[N];
bool judge(int l,int r){
	rep(i,l,r) if (s[i]!=s[r+l-i]) return 1;
	return 0;
}
bool type1(){
	if (n%2==0) return 0;
	rep(i,2,n/2) if (s[i]!=s[i-1]) return 0;
	return 1;
}
void work(){
	scanf("%d",&n);
	scanf("%s",s+1);
	if (judge(1,n)){
		puts("1");
		return;
	}
	if (type1()){
		puts("-1");
		return;
	}
	char c1=s[1],c2=s[2];
	bool f1=1,f2=1;
	for (int i=1;i<=n;i+=2) if (s[i]!=c1) f1=0;
	for (int i=2;i<=n;i+=2) if (s[i]!=c2) f2=0;
	if (f1&&f2){
		puts("-1");
		return;
	}
	puts("2");
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int tc;
	scanf("%d",&tc);
	while (tc--) work();
	return 0;
}
