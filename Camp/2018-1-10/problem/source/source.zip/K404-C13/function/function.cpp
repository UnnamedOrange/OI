#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#define ll long long
using namespace std;

const int N=1000005;

int n,T,cnt;
int mu[N],pri[N],id[N],f[N];
bool vis[N];
ll s[N];

void getpri(int n){
	int i,j;
	mu[1]=1;
	for (i=2;i<=n;i++){
		if (!vis[i]){
			pri[++cnt]=i;
			mu[i]=-1;
		}
		for (j=1;j<=cnt&&pri[j]*i<=n;j++){
			vis[i*pri[j]]=1;
			if (i%pri[j]) mu[i*pri[j]]=-mu[i];
			else{
				mu[i*pri[j]]=0;
				break;
			}
		}
	}
	for (i=1;i<=n;i++)
		for (j=i;j<=n;j+=i) f[j]++;
	for (i=1;i<=n;i++)
		for (j=i;j<=n;j+=i) s[j]+=1ll*mu[i]*f[j/i]*f[j/i];
	for (i=1;i<=n;i++) s[i]+=s[i-1];
}

int read(){
	int num=0; char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		num=num*10+c-'0';
		c=getchar();
	}
	return num;
}

int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	getpri(1000000);
	scanf("%d",&T);
	while (T--){
		n=read();
		printf("%lld\n",s[n]);
	}
	return 0;
}
