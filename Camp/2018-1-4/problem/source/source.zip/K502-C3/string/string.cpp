#include<iostream>
#include<cstdio>
#include<algorithm>
#define mod 998244353
using namespace std;
int n,m;
void open(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
}
int pre[40]={0};
struct stri{
	char a[100];
	int len;
	int hash;
}s[10];
int s[10000]={0};
int rev(int i){
	int n=0;
	while(i){
		s[n++]=i&1;
		i>>=1;
	}
	int res=0;
	for(int i=0;i<n;++i){
		res=res*2+s[i];
	}
	return res;
}
bool check(){
	return true;
}
int main(){
	open();
	scanf("%d%d",&n,&m);
//	printf("%d",(((n<<4)*(m<<2)^1232414)&2147483587)%mod);
	for(int i=1;i<=n;++i){
		scanf("%s",s[i].a)
		fro(int i=0;i<strlen(s[i].a);++i){
			s[i].hash=s[i].hash*2+(s[i].a[i]-'0');
		}
		s[i].len=strlen(s[i].a);
	}
	int all=(1<<m)-1;
	int ans=0;
	for(int i=0;i<=all;++i){
		int whole=i<<(m)+rev(i);
		for(int i=1,tp=whole;i<=2*m;++i){
			pre[i]=tp;
			tp>>=1;
		}
		if(check())++ans;
	}
	return ans;
}
