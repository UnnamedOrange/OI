#include<iostream>
#include<cstdio>
#include<cstring>

inline void check_min(int a,int &b){if(a<b)b=a;}
const int N=550,M=N*N*4,INF=1000000007;

int n;

namespace netflow
{
	int begin[N],next[M],to[M],w[M];
	int e,S,T;
	void init()
	{
		memset(begin,0,sizeof(begin));
		e=1,S=n+1,T=S+1;
	}
	void add(int x,int y,int z)
	{
//		if(z)printf("%d -- > %d : %d\n",x,y,z);
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		w[e]=z;
	}

	int cur[N],lv[N],gap[N],pre[N];

	bool calc(int p)
	{
		int k=T+1;
		for(int i=cur[p]=begin[p];i;i=next[i])
			if(w[i])
			{
				check_min(lv[to[i]],k);
			}

		if(!(--gap[lv[p]]))return 0;
		return ++gap[lv[p]=k+1];
	}
	int MF()
	{
		memset(lv,0,sizeof(lv));
		memset(gap,0,sizeof(gap));
		memcpy(cur,begin,sizeof(cur));
		gap[0]=T;
		to[(pre[S]=1)^1]=S;
		int ret=0;
		for(int u=S,v;v=0,lv[S]<=T;)
		{
			for(v=cur[u];v;v=next[v])
				if(w[v] && lv[to[v]]+1==lv[u])break;
			if(v)
			{
				cur[u]=v;
				pre[u=to[v]]=v;
				if(u==T)
				{
					int k=INF;
					for(int p=T;p!=S;p=to[pre[p]^1])
						check_min(w[pre[p]],k);
					for(int p=T;p!=S;p=to[pre[p]^1])
						w[pre[p]]-=k,w[pre[p]^1]+=k;
					ret+=k;
					u=S;
				}
			}
			else if(calc(u))u=to[pre[u]^1];
			else break;
		}

//		printf("ret = %d\n",ret);

		return ret;
	}
}

namespace maoak
{
	int G[N][N],k[N];
	int w,m0,m1;
	int ans;
	void initialize()
	{
		memset(G,0,sizeof(G));
		scanf("%d%d%d%d",&n,&w,&m0,&m1);
		int x,y,z,a,b,c,d,e,f;
		for(int i=1;i<=n;i++)k[i]=1;
		for(int i=1;i<=m0;i++)
		{
			scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&e,&f);
			G[x][y]+=a;
			G[y][z]+=b;
			G[z][x]+=c;
			k[x]+=d-f;
			k[y]+=e-d;
			k[z]+=f-e;
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=i;j++)
				G[i][j]+=G[j][i],G[j][i]=0;

//		for(int i=1;i<=n;i++,printf("\n"))
//			for(int j=1;j<=i;j++)printf("%d ",G[i][j]);
//		printf("--------------\n");
//		for(int i=1;i<=n;i++)printf("%d ",k[i]);printf("\n");

		using namespace netflow;
		init();
		ans=0;
		for(int i=1;i<=n;i++)
		{
			if(k[i]>0)
			{
				add(S,i,k[i]*2),add(i,S,0);
				ans+=-k[i];
			}
			else 
			{
				add(i,T,-k[i]*2),add(T,i,0);
				ans+=k[i];
			}
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<i;j++)
			{
				if(!G[i][j])continue;
				add(i,j,G[i][j]*2);
				add(j,i,G[i][j]*2);
			}

		while(m1--)
		{
			scanf("%d%d%d",&x,&y,&z);
			if(z<2)z^=1;
			if(z==0)add(x,y,INF),add(y,x,INF);
			else if(z==1)add(y,x,INF),add(x,y,0);
			else add(S,x,INF),add(x,S,0),add(y,T,INF),add(T,y,0);
		}

//		printf("ans = %d\n",ans);
	}
	void solve()
	{
		initialize();
		ans+=netflow::MF();
		printf("%lld\n",1ll*ans*w);
	}
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T;
	for(scanf("%d",&T);T--;maoak::solve());
	return 0;
}
