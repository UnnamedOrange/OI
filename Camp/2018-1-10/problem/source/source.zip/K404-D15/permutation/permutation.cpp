#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 100005
const int mod=998244353;

int n;
int a[maxn],b[maxn];
bool vis[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

void solve(){
	int ans=1;
	for (int i=3;i<n;i+=2) ans=1ll*ans*i%mod;
	ans=1ll*ans*ans%mod;
	printf("%d\n",ans);
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=read(); int ans=0; if (n&1){puts("0"); return 0;}
	for (int i=1;i<=n;i++) b[i]=read();
	bool fuckpps=1;
	for (int i=1;i<=n;i++) if (b[i]) fuckpps=0;
	if (fuckpps){solve(); return 0;}
	for (int i=1;i<=n;i++) a[i]=i;
	do{
		memset(vis,0,sizeof(int)*(n+1));
		bool flag=1;
		for (int i=1;i<=n;i++) if (a[i]!=b[i]&&b[i]){flag=0; break;}
		if (!flag) continue;
		bool can=1;
		for (int i=1;i<=n;i++)
			if (!vis[i]){
				int cnt=0;
				for (int j=i;!vis[j];vis[j]=1,j=a[j]) ++cnt;
				if (cnt&1){can=0; break;}
			}
		ans+=can;
	}while (next_permutation(a+1,a+n+1));
	cout<<ans<<endl;
	return 0;
}
