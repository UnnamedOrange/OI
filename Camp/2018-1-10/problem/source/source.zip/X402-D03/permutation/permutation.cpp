#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MAXN = 100010;
const ll MOD = 998244353;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

inline ll qpow(ll a, ll b) {
	ll res = 1;
	while(b) {
		if(b & 1LL) res = res * a % MOD;
		b >>= 1, a = a * a % MOD;
	}
	return res;
}

int n, n0, n1, p[MAXN], indeg[MAXN];
ll fac[MAXN], ifac[MAXN];
ll g[MAXN], sum, ans;
bool vis[MAXN];

int main() {
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);

	int i;

	n = read();
	for(i = 1; i <= n; i++) p[i] = read(), indeg[p[i]]++;
	for(i = 1; i <= n; i++) {
		if(indeg[i]) continue;
		int u = i, cnt = 1;
		vis[u] = true;
		while(p[u]) u = p[u], vis[u] = true, cnt++;
		if(cnt & 1) n1++;
		else n0++;
	}
	for(i = 1; i <= n; i++) {
		if(vis[i]) continue;
		int u = i, cnt = 1;
		vis[u] = true;
		while(!vis[p[u]]) {
			u = p[u], vis[u] = true;
			cnt++;
		}
		if(cnt & 1) {
			printf("0\n");
			return 0;
		}
	}
	if(n1 & 1) {
		printf("0\n");
		return 0;
	}
	//printf("%d %d\n", n0, n1);
	fac[0] = 1;
	for(i = 1; i <= n; i++) fac[i] = fac[i-1]*i%MOD;
	ifac[n] = qpow(fac[n], MOD-2);
	for(i = n; i >= 1; i--) ifac[i-1] = ifac[i]*i%MOD;
	sum = g[0] = 1;
	for(i = 2; i <= n1; i += 2) {
		g[i] = sum*qpow(i, MOD-2)%MOD;
		sum = (sum+g[i])%MOD;
	}
	//printf("%lld\n", g[n1]*fac[n1]%MOD);
	ans = g[n1]*fac[n1]%MOD*fac[n1+n0]%MOD*ifac[n1]%MOD;
	printf("%lld\n", ans);
	return 0;
}
