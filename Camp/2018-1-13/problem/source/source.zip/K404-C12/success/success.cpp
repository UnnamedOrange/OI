#include <iostream>
#include <cstdio>
#define MOD 998244353
using namespace std;
typedef long long ll;
inline ll quick_pow(ll a, int n)
{
	ll res = 1; 
	while (n)
	{
		if (n & 1)
			res = res * a % MOD; 
		a = a * a % MOD;
		n >>= 1;
	}
	return res;
}
namespace brute
{
	ll fact[1000005], inv[1000005];
	inline void init()
	{
		fact[0] = 1; 
		for (int i = 1; i < 1000005; i++)
			fact[i] = fact[i - 1] * i % MOD; 
		inv[1000004] = quick_pow(fact[1000004], MOD - 2); 
		for (int i = 1000004; i; i--)
			inv[i - 1] = inv[i] * i % MOD;
	}
	inline ll C(int n, int m)
	{
		if (n < m)
			return 0; 
		return fact[n] * inv[m] % MOD * inv[n - m] % MOD;
	}
	inline void solve(int s, int t, int n, int m)
	{
		init(); 
		ll ans = 0; 
		for (int i = 0; i <= n; i++)
			(ans += C(n, i) * C(s - i * t, m)
			 * (i & 1 ? -1 : 1) % MOD + MOD) %= MOD; 
		printf("%lld\n", ans);
	}
}
int main()
{
	freopen("success.in", "r", stdin);
	freopen("success.out", "wt", stdout);
	ll s; 
	int t, n, m; 
	scanf("%lld%d%d%d", &s, &t, &n, &m);
	brute::solve(s, t, n, m); 
	return 0; 
}

