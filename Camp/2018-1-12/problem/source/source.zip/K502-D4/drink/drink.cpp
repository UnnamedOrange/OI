#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;char c; c=getchar();
	while(c<'0'||c>'9') { if(c=='-') f=-1; c=getchar(); }
	while(c>='0'&&c<='9') { x=x*10+c-'0'; c=getchar(); }
	return x*f;
}
int tem[200005],L,R;
int n,w[100005],t[100005];
double njie2[40],ans;
int lc[200005],rc[200005],size[200005],tot=1;
bool cmp(int x,int y) {
	if (w[x]!=w[y]) return w[x]>w[y];
	return x<y;
}
void pushup(int loc){
	size[loc]=size[lc[loc]]+size[rc[loc]];
}
void build(int u,int l,int r) {
	if (l==r){
		if (l==0||l==n+1)
			size[u]=1;
		return ;
	}
	int mid=(l+r)>>1;
	build(lc[u]=++tot,l,mid);
	build(rc[u]=++tot,mid+1,r);
	pushup(u);
}
void add(int u,int l,int r,int p) {
	int mid=(l+r)>>1;
	if (r<p) {
		if (!L||!size[u])
			return ;
		if (l==r) {
			tem[--L]=l;
			return ;
		}
		add(rc[u],mid+1,r,p);
		add(lc[u],l,mid,p);
		return ;
	}
	if (p<l){
		if (R==60||!size[u])
			return;
		if (l==r){
			tem[++R]=l;
			return ;
		}
		add(lc[u],l,mid,p);
		add(rc[u],mid+1,r,p);
		return ;
	}
	size[u]++;
	if (l==r)
		return ;
	if (p<=mid) {
		add(lc[u],l,mid,p);
		add(rc[u],mid+1,r,p);
	}
	else{
		add(rc[u],mid+1,r,p);
		add(lc[u],l,mid,p);
	}
}
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++){
		w[i]=read();
		t[i]=i;		
	}
	sort(t+1,t+n+1,cmp);
	njie2[0]=1;
	for (int i=1;i<=35;i++)
		njie2[i]=njie2[i-1]/2;
	build(1,0,n+1);
	for (int i=1;i<=n;i++){
		for(int j=i;j<n;j++){
			if(j==i)
				w[j]=w[i];
		}
		int a=t[i];
		tem[L=R=30]=a;
		add(1,0,n+1,a);
		for(int tx=L;tx<30;tx++)
			for(int ty=31;(ty-tx-1)<=30&&ty<=R;ty++) 
				ans+=(double)w[a]*(tem[tx+1]-tem[tx])*njie2[ty-tx-1]*(tem[ty]-tem[ty-1]);
	}
	ans/=n*n;
	printf("%.8lf\n",ans);
	return 0;
}
