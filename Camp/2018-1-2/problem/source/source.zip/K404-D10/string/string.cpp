#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int mxn=1<<17;

char s[mxn];

In bool checkP(int n)
{
    inc(0, i, n>>1)
        if(s[i]!=s[n-i-1])
            Re 0;
    Re 1;
}

int main()
{
    freopen("string.in", "r", stdin);
    freopen("string.out", "w", stdout);
    St int t;
    for(scanf("%d", &t); t--;)
    {
        St int n;
        scanf("%d\n%s", &n, s);
        if(!checkP(n))
            {puts("1"); Ct;}
        if(!checkP(n-2))
            {puts("2"); Ct;}
        puts("-1");
    }
}
