#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
using namespace std;
const int MAXN = 16;
const int p = 998244353;
int n, k, ans;
bool vis[MAXN];
int f[1 << MAXN][MAXN];
bool solved[1 << MAXN];
vector<int> G[MAXN];
int dfs(int x, int f){
	register int ret = 1 << x;
	for(register unsigned int i = 0; i < G[x].size(); i++){
		register int y = G[x][i];
		if(y == f || vis[y]) continue;
		ret |= dfs(y, x);
	}
	return ret;
}
void solve(int S){
	if(solved[S]) return;
	int g[MAXN];
	for(register int x = 0; x < n; x++) if(S & (1 << x)){
		for(register int i = 1; i <= k; i++) g[i] = 1;
		vis[x] = true;
		for(register unsigned int i = 0; i < G[x].size(); i++){
			register int y = G[x][i];
			if(vis[y]) continue;
			register int SS = dfs(y, x);
			solve(SS);
			for(register int j = 1, tmp = 0; j <= k; j++){
				(tmp += f[SS][j - 1]) %= p;
				g[j] = (LL)g[j] * tmp % p;
			}
		}
		vis[x] = false;
		for(register int j = 1; j <= k; j++) (f[S][j] += g[j]) %= p;
	}
	solved[S] = true;
}
int main(){
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
	cin >> n >> k;
	memset(f, 0, sizeof(f));
	for(int i = 0; i <= k; i++) f[0][i] = 1;
	for(int i = 1; i < n; i++){
		int x, y;
		scanf("%d%d", &x, &y);
		x--; y--;
		G[x].PB(y); G[y].PB(x);
	}
	solve((1 << n) - 1);
	for(int i = 0; i <= k; i++) (ans += f[(1 << n) - 1][i]) %= p;
	cout << ans << endl;
	return 0;
}
