#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<bitset>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 1001
#define INF 0x3f3f3f3f
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
int n,W,p,q,ans,w[N];
struct node
{
	int x,y,z,a,b,c,d,e,f;
	int calc()
	{
		return a*abs(w[x]-w[y])+b*abs(w[y]-w[z])+c*abs(w[z]-w[x])
		+d*(w[x]-w[y])+e*(w[y]-w[z])+f*(w[z]-w[x]);	
	}
	void read()
	{
		re(x),re(y),re(z),re(a),re(b),re(c),re(d),re(e),re(f);
	}
}s[N];
struct pid
{
	int x,y,r;
	bool check()
	{
		if(r==0)return w[x]<=w[y];
		if(r==1)return w[x]==w[y];
		if(r==2)return w[x]<w[y];
	}
	void read()
	{
		re(x),re(y),re(r);
	}
}d[N];
int main()
{
	open(variable);
	int t;re(t);
	while(t--)
	{
		ans=INF;
		re(n),re(W),re(p),re(q);
		for(int i=1;i<=p;++i)s[i].read();
		for(int i=1;i<=q;++i)d[i].read();
		for(int i=0;i<(1<<n);++i)
		{
			int now=0;
			for(int j=1,c=i;j<=n;++j,c>>=1)
				now+=(w[j]=(c&1)?1:-1);
			bool ok=1;
			for(int j=1;j<=q;++j)
				if(!d[j].check())
					ok=0;
			if(!ok)continue;
			for(int j=1;j<=p;++j)
				now+=s[j].calc();
			ans=min(ans,now);
		}
		printf("%lld\n",1ll*ans*W);
	}
}
