#include <cstdio>
#include <queue>
#include <algorithm>
#define F(x,y,z) for (x=y;x<=z;++x)
using namespace std;
const int N=1010;
int x[N],y[N],z[N],a[N],b[N],c[N],d[N],e[N],f[N],w[N];
int n,m,T,W,p,q;
int dx[N],dy[N],dr[N];
long long ans;
int J(int x){return x<0?-x:x;}
long long Min(long long x,long long y){return x<y?x:y;}

void check()
{
	int i;
	F(i,1,q)
	{
		if (dr[i]==1 && (w[dx[i]]!=w[dy[i]])) return;
		if (dr[i]==0 && (w[dx[i]]> w[dy[i]])) return;
		if (dr[i]==2 && (w[dx[i]]>=w[dy[i]])) return;
	}
	long long an=0;
	F(i,1,n) an+=w[i];
	F(i,1,p) an+=a[i]*J(w[x[i]]-w[y[i]])+b[i]*J(w[y[i]]-w[z[i]])+
				 c[i]*J(w[z[i]]-w[x[i]])+d[i]*(w[x[i]]-w[y[i]])+
				 e[i]*(w[y[i]]-w[z[i]])+f[i]*(w[z[i]]-w[x[i]]);
	ans=Min(ans,an);
}

void work(int x)
{
	if (x==n+1){check();return;}
	w[x]=W;work(x+1);
	w[x]=-W;work(x+1);
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int i,j,k;
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d%d%d%d",&n,&W,&p,&q);
		ans=9223372036854775800;
		F(i,1,p)scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		F(i,1,q)scanf("%d%d%d",&dx[i],&dy[i],&dr[i]);
		work(1);
		printf("%lld\n",ans);
	}
	return 0;
}

