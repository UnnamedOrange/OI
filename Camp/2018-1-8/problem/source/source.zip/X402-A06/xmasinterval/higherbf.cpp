#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 500010;
//rem
const int mod = 1e9+9;

int n, m, x[maxn], dp[maxn];

struct node{
	int l, r;
}a[maxn];

bool cmp(node c, node d){
	return c.l == d.l ? c.r > d.r : c.l < d.l;
}

void Get(){
	n = read(), m = read();
	For(i, 1, n) a[i].l = read(), a[i].r = read();
	For(i, 1, m) x[i] = read();

	sort(a+1, a+n+1, cmp);
	sort(x+1, x+m+1);
}

int lp[maxn], rp[maxn], vis[maxn];

void solve_bf(){
	For(i, 1, n){
		lp[i] = lower_bound(x+1, x+m+1, a[i].l) - x;
		rp[i] = upper_bound(x+1, x+m+1, a[i].r) - x;
	}

	int tmp = (1 << n) - 1, Ans = 0;
	For(i, 0, tmp){
		For(j, 1, m) vis[j] = 0;
		For(j, 1, n){
			if(i & (1 << j-1)){
				++ vis[lp[j]];
				-- vis[rp[j]];
			}
		}

		int sum = 0, flag = 0;
		For(j, 1, m){
			sum += vis[j];
			if(sum < 1) {flag = 1; break;}
		}

		if(!flag) ++ Ans;
	}

	printf("%d\n", Ans);
}

void solve(){
	dp[0] = 1;
	For(i, 1, n){
		int lpos = lower_bound(x+1, x+m+1, a[i].l) - x - 1;
		int rpos = upper_bound(x+1, x+m+1, a[i].r) - x - 1;

		For(j, rpos, m) (dp[j] += dp[j]) %= mod;
		For(j, lpos, rpos-1) (dp[rpos] += dp[j]) %= mod;
	}

	printf("%d\n", dp[m]);
}

int main(){

	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	
	Get();
	solve();

	return 0;
}
