#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
typedef long long LL;
const int maxn=3000000;
int n;
bool vis[maxn+10];
int prime[maxn+10],cnt;
int mu[maxn+10];
LL s[maxn+10],ans;
void init(){
    mu[1]=s[1]=1;
    for(int i=2;i<=maxn;i++){
        if(!vis[i]) prime[++cnt]=i,mu[i]=-1,s[i]=2;
        for(int j=1;j<=cnt&&i*prime[j]<=maxn;j++){
            vis[i*prime[j]]=1;
            mu[i*prime[j]]=-mu[i];
            s[i*prime[j]]=s[i]*2;
            if(i%prime[j]==0){
                mu[i*prime[j]]=0;
                s[i*prime[j]]-=s[i/prime[j]];
            }
        }
    }
    for(int i=1;i<=maxn;i++) mu[i]+=mu[i-1],s[i]=s[i]*s[i]+s[i-1];
}
int main(){
    freopen("function.in","r",stdin);
    freopen("function.out","w",stdout);
    init();
    int _; read(_);
    while(_--){
        read(n); ans=0;
        for(int d=1;d<=n;d++){
            int i=n/(n/d);
            ans+=s[n/d]*(mu[i]-mu[d-1]);
            d=i;
        }
        printf("%lld\n",ans);
    }
    return 0;
}
