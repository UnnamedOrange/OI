#include<cstdio>
const int mod=998244353;
int n,x,sz,cnt,ans;
int to[2333333];
bool vis[2333333];
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	if(n&1){
		puts("0");
		return 0;
	}
	for(register int i=1;i<=n;++i){
		scanf("%d",&x);
		if(x){
			++cnt;
			to[i]=x;
		}
	}
	for(register int i=1;i<=n;++i)
		if(!vis[i]&&to[i]){
			x=i;
			sz=1;
			vis[i]=1;
			while(to[x]!=i&&to[x]){
				x=to[x];
				vis[x]=1;
				++sz;
			}
			if(to[x]==i&&(sz&1)){
				puts("0");
				return 0;
			}
		}
	n-=cnt;ans=1;
	for(register int i=1;i<=n;++i)
		ans=((i&1)?1ll*ans*i%mod:1ll*ans*(i-1)%mod);
	printf("%d\n",ans);
	return 0;
}
