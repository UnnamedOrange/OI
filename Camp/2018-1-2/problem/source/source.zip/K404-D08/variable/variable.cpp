#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(a,b,c) for (int a=b;a<=c;a++)
#define go(u) for (int o=ft[u],v;v=E[o].t;o=E[o].n)
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef double dob;
typedef pair<int,int> par;
const int N=1010;
const LL big=1ll<<30,inf=1ll<<45;
int n,W,P,Q,S,T,tot,ft[N],cur[N],dis[N],q[N];
struct edge{int t,n;LL f;}E[100010];
LL t[N],mp[N][N];
bool bfs(){
	int h,t;
	q[h=t=1]=S;
	memset(dis,0,sizeof(dis));
	memcpy(cur,ft,sizeof(ft));
	dis[S]=1;
	while (h<=t){
		int u=q[h++];
		go(u) if (E[o].f&&!dis[v]){
			dis[v]=dis[u]+1;
			q[++t]=v;
		}
	}
	return dis[T]!=0;
}
LL dfs(int u=S,LL f=inf){
	if (u==T||!f) return f;
	LL g=0,t;
	for (int &o=cur[u];o;o=E[o].n){
		int v=E[o].t;
		LL nf=E[o].f;
		if (dis[v]!=dis[u]+1) continue;
		t=dfs(v,min(f,nf));
		g+=t,f-=t,E[o].f-=t,E[o^1].f+=t;
		if (!f) break;
	}
	return g;
}
void add(int x,int y,LL f){
	E[++tot]=(edge){y,ft[x],f},ft[x]=tot;
	E[++tot]=(edge){x,ft[y],0},ft[y]=tot;
}
#define n1(x) (x*2-1)
#define n2(x) (x*2  )
void work(){
	//clear!
	tot=1;
	memset(ft,0,sizeof(ft));
	memset(mp,0,sizeof(mp));
	scanf("%d%d%d%d",&n,&W,&P,&Q);
	rep(i,1,n) t[i]=1;
	rep(i,1,P){
		int x,y,z,a,b,c,d,e,f;
		scanf("%d%d%d%d%d%d%d%d%d",&x,&y,&z,&a,&b,&c,&d,&e,&f);
		t[x]+=d-f;
		t[y]+=e-d;
		t[z]+=f-e;
		mp[x][y]+=a,mp[y][x]+=a;
		mp[y][z]+=b,mp[z][y]+=b;
		mp[z][x]+=c,mp[x][z]+=c;
	}
	// build graph
	S=n*2+1,T=S+1;
	rep(i,1,Q){
		int x,y,r;
		scanf("%d%d%d",&x,&y,&r);
		if (r==0){
			add(n1(x),n2(y),inf);
		} else if (r==1){
			add(n1(x),n2(y),inf);
			add(n1(y),n2(x),inf);
		} else if (r==2){
			add(S,n1(y),inf);
			add(n2(x),T,inf);
		}
	}
	rep(i,1,n){
		add(n1(i),n2(i),inf);
		add(S,n1(i),big-t[i]);
		add(n2(i),T,big+t[i]);
	}
	rep(i,1,n) rep(j,i+1,n) if (mp[i][j]){
		add(n1(i),n2(j),mp[i][j]*2);
		add(n1(j),n2(i),mp[i][j]*2);
	}
	// max flow
	LL ans=0;
	while (bfs()) ans+=dfs();
	ans-=big*n;
	printf("%lld\n",ans*W);
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int tc;
	scanf("%d",&tc);
	while (tc--) work();
	return 0;
}

