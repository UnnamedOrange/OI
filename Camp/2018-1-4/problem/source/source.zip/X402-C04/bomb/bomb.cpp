#include<iostream>
#include<queue>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0' || '9'<ch)ch=getchar();
	while('0'<=ch && ch<='9')x=x*10+(ch^48),ch=getchar();
	return x;
}

typedef long long ll;
const int N=1000009;

int n,m,ans,ind[N],f[N];
int to[N],nxt[N],beg[N],tot;
int eto[N],enxt[N],efrm[N],ebeg[N],etot;
int low[N],pre[N],scc[N],siz[N],stk[N],scccnt,dfn,top;
queue<int> q;

inline void chkmax(int &a,int b){if(a<b)a=b;}
inline void chkmin(int &a,int b){if(a>b)a=b;}

inline void adde(int u,int v)
{
	eto[++etot]=v;
	efrm[etot]=u;
	enxt[etot]=ebeg[u];
	ebeg[u]=etot;
}

inline void add(int u,int v)
{
	to[++tot]=v;
	nxt[tot]=beg[u];
	beg[u]=tot;
	ind[v]++;
}

inline void dfs(int u)
{
	low[u]=pre[u]=++dfn;
	stk[++top]=u;

	for(int i=ebeg[u],v;i;i=enxt[i])
		if(!low[v=eto[i]])
		{
			dfs(v);
			chkmin(low[u],low[v]);
		}
		else if(!scc[v])
			chkmin(low[u],pre[v]);
	if(low[u]==pre[u])
	{
		scccnt++;
		do
			scc[stk[top]]=scccnt,siz[scccnt]++;
		while(stk[top--]!=u);
	}	
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);

	n=read();m=read();
	for(int i=1,u,v;i<=m;i++)
	{
		u=read(),v=read();
		adde(u,v);
	}

	for(int i=1;i<=n;i++)
		if(!scc[i])
			dfs(i);

	for(int i=1;i<=etot;i++)
		if(scc[efrm[i]]!=scc[eto[i]])
			add(scc[efrm[i]],scc[eto[i]]);

	for(int i=1;i<=scccnt;i++)
		if(!ind[i])
		{
			f[i]=siz[i];
			q.push(i);
		}

	for(int j=1;j<=scccnt;j++)
	{
		int u=q.front();q.pop();
		chkmax(ans,f[u]);
		for(int i=beg[u];i;i=nxt[i])
		{
			chkmax(f[to[i]],f[u]);
			if(!(--ind[to[i]]))
			{
				f[to[i]]+=siz[to[i]];
				q.push(to[i]);
			}
		}
	}

	printf("%d\n",ans);
	return 0;
}
