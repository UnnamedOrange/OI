#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define MOD 998244353
#define at(S,j) (((S)>>~-(j))&1)
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int first[55], f[8193][16], g[8192][16], c[8192], n, k, E, tot; bool book[8192];
struct Edge{int to,nex; Edge(){} Edge(int _to, int _nex){to=_to,nex=_nex;}}e[105];
inline void Add(int a, int b){e[tot] = Edge(b,first[a]), first[a] = tot++, e[tot] = Edge(a,first[b]), first[b] = tot++;}
inline void Inc(int &x, int v){x += v, x<MOD?:x-=MOD;}
void DFS_R(int p, int fa, int S, int &R){R |= 1<<~-p; for(rint u = first[p], v; ~u; u = e[u].nex) if((v=e[u].to)-fa && at(S,v)) DFS_R(v,p,S,R);}
void Robot(int S)
{
	if(book[S]) return; book[S] = true; if(!S){for(rint i = 0; i <= k; f[S][i] = 1, i++); return;}
	if(c[S]==1){for(rint i = 0; i <= k; f[S][i] = i, i++); return;}
	for(int p = 1, u, v, j, R; p <= n; p++) if(at(S,p))
	{
		for(j = 0; j < k; g[p][j] = 1, j++);
		for(u = first[p]; ~u; u = e[u].nex)
			for(DFS_R(v=e[u].to,p,S,R=0), Robot(S&R), j = 0; j < k; g[p][j] = 1ll*g[p][j]*f[S&R][j]%MOD, j++);
		for(j = 1; j <= k; Inc(f[S][j],g[p][j-1]), Inc(g[p][j],g[p][j-1]), j++);
	}
}
int main()
{
	freopen("xmastree3.in","r",stdin), freopen("xmastree3.out","w",stdout);
	n = read(), k = read(), E = ~-(1<<n), memset(first+1,-1,n<<2); for(rint i = 2; i <= n; Add(read(),read()), i++);
	for(rint i = 1; i <= E; c[i] = -~c[i-(i&-i)], i++); Robot(E), printf("%d\n",f[E][k]); return 0;
}
