#include <bits/stdc++.h>
using namespace std;

struct Op {
	int x, y, z;
	int a, b, c, d, e, f;
	int Eval(int w, int m) {
		int wx = (m & (1 << x)) ? w : -w;
		int wy = (m & (1 << y)) ? w : -w;
		int wz = (m & (1 << z)) ? w : -w;
		return a * abs(wx - wy) + b * abs(wy - wz) + c * abs(wz - wx) + d * (wx - wy) + e * (wy - wz) + f * (wz - wx);
	}
};

struct Req {
	int x, y, r;
};

vector<Op> ops;
vector<Req> req;

#define BIT_AT(v, p) (((v) >> (p)) & 1)

int main() {
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	int t;
	cin >> t;
	while (t--) {
		int n, w, p, q;
		cin >> n >> w >> p >> q;
		ops.clear();
		if (w < 0) {
			w = -w;
		}
		for (int i = 0; i < p; ++i) {
			Op o;
			cin >> o.x >> o.y >> o.z >> o.a >> o.b >> o.c >> o.d >> o.e >> o.f;
			ops.push_back(o);
		}
		for (int i = 0; i < q; ++i) {
			Req r;
			cin >> r.x >> r.y >> r.r;
			req.push_back(r);
		}
		if (n > 30) {
			continue;
		}
		int Ans = 0x3FFFFFFF;
		int mask = 1 << n;
		for (int i = 0; i < mask; ++i) {
			bool check = true;
			for (int j = 0; j < req.size() && check; ++j) {
				switch(req[j].r) {
				case 0:
					if (BIT_AT(i, req[j].x) > BIT_AT(i, req[j].y)) {
						check = false;
					}
					break;
				case 1:
					if (BIT_AT(i, req[j].x) != BIT_AT(i, req[j].y)) {
						check = false;
					}
					break;
				case 2:
					if (BIT_AT(i, req[j].x) >= BIT_AT(i, req[j].y)) {
						check = false;
					}
					break;
				}
			}
			if (check) {
				int ans = 0;
				for (int j = 0; j < n; ++j) {
					ans += BIT_AT(i, j) ? w : -w;
				}
				for (int j = 0; j < ops.size(); ++j) {
					ans += ops[j].Eval(w, i);
				}
				if (Ans > ans) {
					Ans = ans;
				}
			}
		}
		cout << Ans << '\n';
	}
}
