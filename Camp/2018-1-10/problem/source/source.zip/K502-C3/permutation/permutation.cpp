#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
int p[10]={0};
bool used[10]={0};
bool fl[10]={0},ok[10]={0};
int n;
bool check(){
	memset(ok,0,sizeof ok);
	for(int i=1;i<=n;++i){
		if(!ok[i]){
			int pos=p[i];
			int cnt=1;
			while(pos!=i){
				cnt++;
				ok[pos]=1;
				pos=p[pos];
			}
			if(cnt&1)return false;
		}
	}
	return true;
}
			
int dfs(int x){
	if(x==n+1){
		if(check())return 1;
	}
	if(fl[x])return dfs(x+1);
	int res=0;
	for(int i=1;i<=n;++i){
		if(!used[i]&&i!=x){
			used[i]=1;
			p[x]=i;
			res+=dfs(x+1);
			used[i]=0;
		}
	}
	return res;
}
int brute_force(){
	dfs(1);
}
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	if(n<=8){
		for(int i=1;i<=n;++i){
			scanf("%d",&p[i]);
			if(p[i])fl[i]=1;
			used[p[i]]=1;
		}
		cout<<brute_force();
		return 0;
	}
	printf("0\n");
	return 0;
}
