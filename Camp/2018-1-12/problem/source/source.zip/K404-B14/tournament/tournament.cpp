#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define PII pair<int, int>
#define F first
#define S second
using namespace std;
const int INF = 0x3f3f3f3f;
const int p = 998244353;
inline void gmin(int &x, int y){x = x < y ? x : y;}
inline void gmax(int &x, int y){x = x > y ? x : y;}
inline int inc(int a, int b){a += b; if(a >= p) a -= p; return a;}
inline int dec(int a, int b){a -= b; if(a < 0) a += p; return a;}
inline int mul(int a, int b){return (LL)a * b % p;}
int fpow(int a, int x){
	int ret = 1;
	while(x){
		if(x & 1) ret = mul(ret, a);
		a = mul(a, a);
		x >>= 1;
	}
	return ret;
}
int n, k, ans;
namespace work3{
	void solve(){
		ans = 1;
		for(int i = 2; i <= n; i++) ans = mul(ans, i);
		ans = dec(fpow(2, (LL)n * (n - 1) / 2), ans);
		return (void)printf("%d\n", ans);
	}
}
namespace workn{
	const int MAXN = 100010;
	int a[MAXN], f[MAXN];
	int fac[MAXN], nfac[MAXN];
	int C(int a, int b){
		return mul(fac[a], mul(nfac[b], nfac[a - b]));
	}
	void solve(){
		for(int i = 1; i <= n; i++) f[i] = fpow(2, (LL)i * (i - 1) / 2);
		nfac[1] = 1;
		for(int i = 2; i <= n; i++) nfac[i] = p - (LL)p / i * nfac[p % i] % p;
		nfac[0] = fac[0] = 1;
		for(int i = 1; i <= n; i++) fac[i] = mul(fac[i - 1], i), nfac[i] = mul(nfac[i - 1], nfac[i]);
		a[1] = 1;
		for(int i = 2; i <= n; i++){
			a[i] = f[i];
			for(int s = 1; s <= i - 1; s++)
				a[i] = dec(a[i], mul(mul(C(i, s), a[s]), f[i - s]));
		}
		ans = a[n];
		printf("%d\n", ans);
	}
}
namespace bruteforce{
	const int MAXN = 10;
	bool f[MAXN][MAXN];
	bool vis[MAXN];
	int cur;
	bool dfs2(int x, int dep){
		if(!dep) return x == cur;
		if(vis[x]) return false;
		vis[x] = true;
		for(int i = 1; i <= n; i++) if(f[x][i] && dfs2(i, dep - 1)) return true;
		vis[x] = false;
		return false;
	}
	void check(){
		for(int i = 1; i <= n; i++) if(memset(vis, 0, sizeof(vis)), cur = i, dfs2(i, k)) return (void)(ans = inc(ans, 1));
	}
	void dfs(int x, int y){
		if(y > n) x++, y = x + 1;
		if(x >= n) return (void)check();
		f[x][y] = 1; f[y][x] = 0;
		dfs(x, y + 1);
		f[x][y] = 0; f[y][x] = 1;
		dfs(x, y + 1);
	}
	void solve(){
		ans = 0;
		dfs(1, 2);
		printf("%d\n", ans);
	}
}
int main(){
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	scanf("%d%d", &n, &k);
	if(k == 3) work3::solve();
	else if(k == n) workn::solve();
	else bruteforce::solve();
	return 0;
}
