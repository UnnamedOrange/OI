#include <cstdio>
#include <cstring>
#include <algorithm>
#define ele int
#define ll long long
using namespace std;
#define maxn 100010
#define MOD 998244353
ele n,m1,m2,p[maxn],ind[maxn],fac[maxn],ifac[maxn],f[maxn],g[maxn];
bool flag[maxn];
inline ele pw(ele a,ele x){
	ele ans=1,tmp=a%MOD;
	for (; x; x>>=1,tmp=(ll)tmp*tmp%MOD)
		if (x&1) ans=(ll)ans*tmp%MOD;
	return ans;
}
int main(){
	freopen("permutation.in","r",stdin); freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for (int i=0; i<n; ++i) scanf("%d",p+i),--p[i],++ind[p[i]];
	memset(flag,0,sizeof(flag));
	m1=m2=0;
	for (int i=0; i<n; ++i)
		if (!flag[i] && ~p[i]){
			flag[i]=true;
			ele cnt=1,j;
			for (j=p[i]; ~j && j!=i; j=p[j]) ++cnt,flag[j]=true;
			if (j==i){
				if (cnt&1){
					puts("0");
					return 0;
				}
			}
		}
	memset(flag,0,sizeof(flag));
	for (int i=0; i<n; ++i)
		if (!flag[i] && !ind[i]){
			flag[i]=true;
			ele cnt=1,j;
			for (j=p[i]; ~j && j!=i; j=p[j]) ++cnt,flag[j]=true;
			if (cnt&1) ++m1; else ++m2;
		}
	fac[0]=ifac[0]=1;
	for (int i=1; i<=n; ++i){
		fac[i]=(ll)fac[i-1]*i%MOD;
		ifac[i]=pw(fac[i],MOD-2);
	}
	f[0]=g[0]=1; f[1]=g[1]=0;
	for (int i=2; i<=m1; ++i){
		f[i]=(ll)g[i-2]*pw(i,MOD-2)%MOD;
		g[i]=(g[i-2]+f[i])%MOD;
	}
	ele ans=(ll)f[m1]*fac[m1]%MOD;
	for (int i=0; i<m2; ++i) ans=(ll)ans*(m1+i+1)%MOD;
	printf("%d\n",ans);
	return 0;
}