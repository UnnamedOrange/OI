#include<cstdio>
#include<map>
#include<algorithm>
#include<queue>
#define gc getchar()
#define FOR(i,s,t) for(register int i=s;i<=t;++i)
using namespace std;
inline int read(){
	char c;while(c=gc,c==' '||c=='\n');int data=c-48;
	while(c=gc,c>='0'&&c<='9')data=(data<<1)+(data<<3)+c-48;return data;
}
typedef long long ll;
const int x=101;
map<ll,int>hash;
ll goal;
int T,n;
int a[x],b[x];
inline void dfs(int now){
	register int tot=0;
	for(register int i=1;i<=(n<<1|1);++i)b[i]=0;
	for(register int i=1;i<=n;++i)if(a[i]!=i)b[a[i]+i-1]=1;
	for(register int i=1;i<=(n<<1|1);++i)if(b[i])++tot;
	if(now+tot>=hash[goal])return;
	ll h=0;
	for(register int i=1;i<=n;++i)h=1ll*h*x+1ll*a[i];
	if(now>=hash[h]&&hash[h])return;
	hash[h]=now;
	register int i,l,r;
	l=2,r=n;
	while(l<=r){
		i=r;
		for(register int j=1,k=i;j<k;++j,--k)
			swap(a[j],a[k]);
		dfs(now+1);
		for(register int j=1,k=i;j<k;++j,--k)
			swap(a[j],a[k]);
		if(l!=r){
			i=l;
			for(register int j=1,k=i;j<k;++j,--k)
				swap(a[j],a[k]);
			dfs(now+1);
			for(register int j=1,k=i;j<k;++j,--k)
				swap(a[j],a[k]);
		}
		++l;--r;
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		goal=0;
		for(register int i=1;i<=n;++i)goal=1ll*goal*x+1ll*i;
		hash.clear();
		for(register int i=1;i<=n;++i)a[i]=read();
		hash[goal]=n;
		dfs(1);
		printf("%d\n",hash[goal]-1);
	}
	return 0;
}
