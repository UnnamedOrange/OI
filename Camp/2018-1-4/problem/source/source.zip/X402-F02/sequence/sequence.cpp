#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=100+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("sequence.in","r",stdin);
		freopen("sequence.out","w",stdout);
	#endif
}
int n,a[N],x[N];
void input()
{
	memset(a,0,sizeof a);
	n=read<int>();
	For(i,1,n)a[i]=read<int>();
	a[n+1]=n+1;
}
int max_d;
int best()
{
	int res=0;
	For(i,1,n)if(abs(x[i]-x[i+1])!=1)res++;
	return res;
}
int y[N];
void rev(int pos)
{
	For(i,1,pos)y[i]=x[i];
	Fordown(i,pos,1)x[i]=y[pos-i+1];
}
bool check()
{
	For(i,1,n)if(x[i]!=x[i+1]-1)return 0;
	return 1;
}
bool dfs(int dep,int pre)
{
	if(check())return 1;
	if(dep+best()>max_d)return 0;
	For(i,2,n)
	{
		if(i==pre)continue;
		rev(i);
		if(dfs(dep+1,i))return 1;
		rev(i);
	}
	return 0;
}
void work()
{
	max_d=0;
	while(1)
	{
		memcpy(x,a,sizeof x);
		if(dfs(0,0)){printf("%d\n",max_d);break;}
		max_d++;
	}
}
int main()
{
	file();
	int T=read<int>();
	while(T--)
	{
		input();
		work();
	}
	return 0;
}
