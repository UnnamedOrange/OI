#include <bits/stdc++.h>

namespace {

const int MAXN = 4000 + 9;

int n, m, k, a[MAXN], b[MAXN];
const int times = 10000;

typedef unsigned int uint;

inline uint nextUint() {
    static uint x = 495;
    return x ^= x << 13, x ^= x >> 17, x ^= x << 5, x;
}

inline bool check(int len) {
    static int tmp[MAXN];
    for (register int i = 0; i < times; i++) {
        for (register int j = 1; j <= len; j++) tmp[j] = nextUint() % k + 1;
        register int t1 = 1, t2 = 1;
        while (t1 <= n && t2 <= n) {
            if (a[t1] != tmp[t2]) {
                t1++;
            } else {
                t1++;
                t2++;
            }
        }
        if (t2 > len) {
            continue;
        } else {
            t1 = 1;
            t2 = 1;
            while (t1 <= m && t2 <= len) {
                if (b[t1] != tmp[t2]) {
                    t1++;
                } else {
                    t1++;
                    t2++;
                }
            }
            if (t2 > len) continue;
            else return true;
        }
    }
    return false;
}

inline void solve() {
    std::cin >> n >> m >> k;
    for (register int i = 1; i <= n; i++) std::cin >> a[i];
    for (register int i = 1; i <= m; i++) std::cin >> b[i];
    register int r = std::max(n, m) + 1, l;
    while (r && check(r >> 1)) {
        r >>= 1;
    }
    l = std::max(1, r >> 1);
    for (register int mid; r - l > 1;) {
        mid = (l + r) >> 1;
        if (check(mid)) r = mid;
        else l = mid;
    }
    std::cout << r;
}
}

int main() {
    freopen("subsequence.in", "r", stdin);
    freopen("subsequence.out", "w", stdout);
    solve();
    return 0;
}