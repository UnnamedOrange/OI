#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x;char c;
	while((c=getchar())<'0'||c>'9');
	x=c-48;
	while((c=getchar())>='0'&&c<='9')x=x*10+c-48;
	return x;
}

typedef long long ll;
const int maxn=5e5+10,mod=1e9+9;
int n,m,pos[maxn];
pair<int,int> seg[maxn];
int st[maxn<<2],tag[maxn<<2];

inline void init(){
	sort(pos+1,pos+m+1);
	for(int i=1;i<=n;++i)
		seg[i].first=lower_bound(pos+1,pos+m+1,seg[i].first)-pos,seg[i].second=upper_bound(pos+1,pos+m+1,seg[i].second)-pos-1;
	sort(seg+1,seg+n+1);
}
inline int chk(int x){
	return x>=mod?x-mod:x;
}
inline void push_up(int rt){
	st[rt]=chk(st[rt<<1]+st[rt<<1|1]);
}
inline void push_down(int rt){
	if(tag[rt]!=1){
		tag[rt<<1]=(ll)tag[rt<<1]*tag[rt]%mod;
		st[rt<<1]=(ll)st[rt<<1]*tag[rt]%mod;
		tag[rt<<1|1]=(ll)tag[rt<<1|1]*tag[rt]%mod;
		st[rt<<1|1]=(ll)st[rt<<1|1]*tag[rt]%mod;
		tag[rt]=1;
	}
}
void build(int rt,int l,int r){
	tag[rt]=1;
	if(l==r)
		return;
	int mid=l+r>>1;
	build(rt<<1,l,mid);
	build(rt<<1|1,mid+1,r);
}
void add(int rt,int l,int r,int pos,int val){
	if(l==r){
		st[rt]=chk(st[rt]+val);
		return;
	}
	push_down(rt);
	int mid=l+r>>1;
	if(pos<=mid)
		add(rt<<1,l,mid,pos,val);
	else
		add(rt<<1|1,mid+1,r,pos,val);
	push_up(rt);
}
void mul(int rt,int l,int r,int x){
	if(l==x){
		st[rt]=chk(st[rt]<<1);
		tag[rt]=chk(tag[rt]<<1);
		return;
	}
	push_down(rt);
	int mid=l+r>>1;
	if(x>mid)
		mul(rt<<1|1,mid+1,r,x);
	else
		mul(rt<<1,l,mid,x),mul(rt<<1|1,mid+1,r,mid+1);
	push_up(rt);
}
int query(int rt,int l,int r,int x,int y){
	if(l==x&&r==y)
		return st[rt];
	push_down(rt);
	int mid=l+r>>1;
	if(y<=mid)
		return query(rt<<1,l,mid,x,y);
	else if(x>mid)
		return query(rt<<1|1,mid+1,r,x,y);
	else
		return chk(query(rt<<1,l,mid,x,mid)+query(rt<<1|1,mid+1,r,mid+1,y));
}

int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;++i)
		seg[i].first=read(),seg[i].second=read();
	for(int i=1;i<=m;++i)
		pos[i]=read();
	init();
	build(1,0,m);
	add(1,0,m,0,1);
	for(int i=1;i<=n;++i){
		add(1,0,m,seg[i].second,query(1,0,m,seg[i].first-1,seg[i].second));
		if(seg[i].second<m)mul(1,0,m,seg[i].second+1);
	}
	printf("%d\n",query(1,0,m,m,m));
	return 0;
}
