#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N=5000;
const int M=30;

int n;
char s[N];

int main()
{
	freopen("seed.in","r",stdin);
	int seed;scanf("%d",&seed);
	srand(time(0)+seed*2345^1234|124);
	freopen("seed.in","w",stdout);
	printf("%d\n",rand());

	freopen("string.in","w",stdout);
	int T=20;
	printf("%d\n",T);
	while(T--)
	{
		int n=20;
		printf("%d\n",n);
		if(rand()%3<100)
		{
		for(int i=1;i<=n/2+1;i++)
			s[i]=s[n-i+1]=rand()%5+'a';
		for(int i=1;i<=n;i++)
			printf("%c",s[i]);
		puts("");
		}
		else
		{
			for(int i=1;i<=n;i++)
				putchar(rand()%5+'a');
			puts("");
		}
	}
	return 0;
}
