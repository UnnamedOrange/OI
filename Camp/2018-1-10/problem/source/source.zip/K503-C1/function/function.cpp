# include <bits/stdc++.h>
# define 	N 		5000100
# define 	ll 		long long
using namespace std;
bool f[N+10];
int mu[N+10],d[N+10],p[N+10],pnum;
ll M[N+10],D2[N+10];
void getmu(){
	f[1]=true; mu[1]=1; d[1]=1;
	for (ll i=2; i<=N; i++){
		if (f[i]==false){
			p[++pnum]=i;
			mu[i]=-1; d[i]=2;
			for (ll j=1; j<pnum&&N/p[j]>=i; j++)
				f[i*p[j]]=true, mu[i*p[j]]=1, d[i*p[j]]=d[i]*d[p[j]];
			if (N/i>=i) f[i*i]=true, mu[i*i]=0, d[i*i]=3;
		}
		else for (ll j=1; j<=pnum&&N/p[j]>=i; j++){
				f[i*p[j]]=true;
				if (i%p[j]!=0) mu[i*p[j]]=mu[i]*mu[p[j]], d[i*p[j]]=d[i]*d[p[j]];
				else {
					mu[i*p[j]]=0;
					ll now=i,num=0;
					while (now%p[j]==0){
						num++;
						now/=p[j];
					}
					d[i*p[j]]=d[now]*(d[p[j]]+num);
					break;
				}
			}	
	}
	for (ll i=1; i<=N; i++) M[i]=(ll)mu[i]+M[i-1];
	for (ll i=1; i<=N; i++) D2[i]=(ll)d[i]*(ll)d[i]+D2[i-1];
}
int main(){
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	ll opt,ca=1,n,ans;
	getmu();
	for (scanf("%lld",&opt); ca<=opt; ca++){
		scanf("%lld",&n); ans=0;
		for (ll i=1, nex=0; i<=n; i=nex+1){
			nex=n/(n/i);
			ans=ans+(M[nex]-M[i-1])*D2[n/i];
		}
		printf("%lld\n",ans);
	}
	return 0;
}

