#include <bits/stdc++.h>
using namespace std ;
void Read ( int &x, char c = getchar() ) {
	for ( x = 0 ; !isdigit(c) ; c = getchar() ) ;
	for ( ; isdigit(c) ; c = getchar() ) x = 10*x + c - '0' ;
}
const int maxn = 1e5+5 ;
int n, m, e, Begin[maxn], Next[maxn<<1], To[maxn<<1] ;
void add ( int x, int y ) {
	To[++e] = y ;
	Next[e] = Begin[x] ;
	Begin[x] = e ;
}
int c[maxn], dep[maxn] ;
bool vis[maxn] ;
void _dfs ( int x ) {
	int i, u ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (!dep[u]) {
			dep[u] = dep[x]+1 ;
			_dfs(u) ;
		}
	}
}
int L, R ;
set <int> st ;
void dfs ( int x ) {
	int i, u ;
	if (L <= c[x] && c[x] <= R) st.insert(c[x]) ;
	for ( i = Begin[x] ; i ; i = Next[i] ) {
		u = To[i] ;
		if (dep[u] == dep[x]+1) dfs(u) ;
	}
}
int main() {
	freopen ( "xmastree1.in", "r", stdin ) ;
	freopen ( "xmastree1.out", "w", stdout ) ;

	int t, i, x, u, _, op ;
	unsigned long ans = 0 ;
	Read(n) ; Read(_) ;  Read(t) ;
	for ( i = 1 ; i <= n ; i ++ )
		Read(c[i]) ;
	for ( i = 1 ; i < n ; i ++ ) {
		Read(x) ; Read(u) ;
		add(x, u) ;
		add(u, x) ;
	}
	dep[1] = 1 ;
	_dfs(1) ;
	while (_--) {
		Read(op) ;
		if (op == 1) {
			Read(x) ; Read(L) ; Read(R) ;
			if (t) x ^= ans, L ^= ans, R ^= ans ;
			st.clear() ;
			dfs(x) ;
			printf ( "%lu\n", ans = st.size() ) ;
		} else {
			Read(x) ; Read(u) ;
			if (t) x ^= ans, u ^= ans ;
			c[x] = u ;
		}
	}
	return 0 ;
}
