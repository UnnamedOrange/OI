#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#define ele int
using namespace std;
#define maxn 12
#define maxm 510
#define maxl 110
#define maxs (1<<6)
#define sigma 2
#define MOD 998244353
struct node{
	ele m1,m2,len,dp[maxm][maxs];
	node *last,*f,*l[sigma];
	inline void init(){
		m1=m2=0; last=f=NULL;
		memset(dp,0,sizeof(dp)); memset(l,0,sizeof(l));
	}
}np[maxn*maxl],*ncnt;
inline ele getv(ele x,ele i){
	return (x>>i)&1;
}
inline ele setv(ele&x,ele i,ele k){
	x=x&~(1<<i);
	x=x|(k<<i);
	return x;
}
inline bool test(ele n,char *s,ele j){
	ele j1=j+1;
	while (~j && j1<n){
		if (s[j]==s[j1]) return false;
		--j; ++j1;
	}
	if (j1==n) return true;
	return false;
}
inline void ins(node *root,ele id,ele n,char *s){
	node *p=root;
	for (int i=0; i<n; ++i){
		if (!p->l[s[i]]){
			node *q=ncnt++; q->init();
			q->len=p->len+1;
			p->l[s[i]]=q;
		}
		p=p->l[s[i]];
		if (test(n,s,i)) setv(p->m2,id,1);
	}
	setv(p->m1,id,1);
}
inline void build(node *root){
	static queue<node*> Q;
	Q.push(root); root->f=root->last=NULL;
	while (!Q.empty()){
		node *k=Q.front(); Q.pop();
		for (int i=0; i<sigma; ++i)
			if (k->l[i]){
				node *p=k->f;
				while (p && !p->l[i]) p=p->f;
				if (!p) k->l[i]->f=root;
				else k->l[i]->f=p->l[i];
				k->l[i]->last=(~k->l[i]->f->m1)?k->l[i]->f:k->l[i]->f->last;
				Q.push(k->l[i]);
			}
	}
}
ele n,m,L[maxn];
char s[maxn][maxl],s1[maxn][maxl];
bool flip[maxn];
node *root;
int main(){
	freopen("string.in","r",stdin); freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=0; i<n; ++i){
		scanf("%s",s[i]); L[i]=strlen(s[i]);
		for (int j=0; j<L[i]; ++j){
			s[i][j]-='0'; s1[i][L[i]-1-j]=s[i][j]^1;
		}
	}
	ncnt=np; root=ncnt++;
	root->init(); root->len=0;
	for (int i=0; i<n; ++i){
		ins(root,i,L[i],s[i]);
		ins(root,i,L[i],s1[i]);
	}
	build(root);
	root->dp[0][0]=1;
	for (int L=0; L<m; ++L){
		for (int kcnt=0; kcnt<ncnt-np; ++kcnt){
			node *k=np+kcnt;
			for (int s=0; s<(1<<n); ++s)
				if (k->dp[L][s])
					for (int i=0; i<sigma; ++i){
						node *p=k;
						while (p && !p->l[i]) p=p->f;
						if (!p) p=root; else p=p->l[i];
						ele s1=s;
						for (node *q=p; q; q=q->last) s1=s1|q->m1;
						(p->dp[L+1][s1]+=k->dp[L][s])%=MOD;
					}
		}
	}
	ele ans=0;
	for (int i=0; i<ncnt-np; ++i)
		for (int s=0; s<(1<<n); ++s){
			ele s1=s;
			for (node *p=np+i; p; p=p->f) s1=s1|p->m2;
			if (s1==(1<<n)-1) (ans+=np[i].dp[m][s])%=MOD;
		}
	printf("%d\n",ans);
	return 0;
}