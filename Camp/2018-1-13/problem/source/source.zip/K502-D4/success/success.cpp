#include<bits/stdc++.h>
using namespace std;
long long n,m,s,t,f[1005][1005],ans,mo=1e9+7;
int main() {
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	scanf("%d%d%d%d",&s,&t,&n,&m);
	f[0][0]=1;
	for(long long i=1; i<=m; i++)
		for(long long j=1; j<=s; j++) {
			if(i<=n)
				for(int k=max(j-t,0ll); k<j; k++)
					f[i][j]=(f[i][j]+f[i-1][k])%mo;
			else
				for(int k=0; k<j; k++)
					f[i][j]=(f[i][j]+f[i-1][k])%mo;
			if(i==m) ans=(ans+f[i][j])%mo;
		}
	printf("%lld\n",ans);
	return 0;
}
