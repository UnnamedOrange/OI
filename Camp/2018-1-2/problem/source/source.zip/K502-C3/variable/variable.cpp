#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#define NN 500+20
#define MM 1000+10
using namespace std;
void open(){
	freopen("variable.in","r",stdin);
//	freopen("variable.out","w",stdout);
}
void close(){
	fclose(stdin);
	fclose(stdout);
}
int Max;
int a[NN]={0};
struct node{
	int a,b,kd;
}e[MM]={0};
struct Coop{
	int x,y;
	int cnt;
}c[MM];
int n,val,p,q;
bool cmp(bool a,bool b,int kd){
	switch(kd){
		case 0: return !(a&&(!b));
		case 1:return a==b;
		case 2:return (!a)&&b;
	}
}
bool check(int sit){
	for(int i=1;i<=q;++i){
		if(!cmp((1<<(e[i].a-1))&sit,(1<<(e[i].b-1))&sit,e[i].kd)){
			return false;
		}
	}
	return true;
}
int get_ans(int sit){
	int res=0;
	for(int i=1;i<=n;++i){
		if((1<<(i-1))&sit){
			res+=a[i];
		}
		else res-=a[i];
	}
	for(int i=1;i<=p;++i){
		if(!cmp((1<<(c[i].x-1))&sit,(1<<(c[i].y-1))&sit,1)){
			res+=2*c[i].cnt;
		}
	}
	return res;
}
			
int solve(){
	scanf("%d",&n);
	scanf("%d%d%d",&val,&p,&q);
	for(int i=1;i<=n;++i){
		a[i]=1;
	}
	int x1,x2,x3,qq,w,ee,r,t,y;
	for(int i=1;i<=p;++i){
		scanf("%d%d%d%d%d%d%d%d%d",&x1,&x2,&x3,&qq,&w,&ee,&r,&t,&y);
		a[x1]+=r-y;
		a[x2]+=t-r;
		a[x3]+=y-t;
		c[i*3-2].cnt=qq;
		c[i*3-2].x=x1;
		c[i*3-2].y=x2;
		c[i*3-1].cnt=w;
		c[i*3-1].x=x2;
		c[i*3-1].y=x3;
		c[i*3].cnt=ee;
		c[i*3].x=x3;
		c[i*3].y=x1;
	}
	int cnt=1;
	for(int i=1;i<=q;++i){
		scanf("%d%d%d",&x1,&x2,&r);
		e[i].a=x1;
		e[i].b=x2;
		e[i].kd=r;
	}
	Max=(1<<n);
	int ans=1000000;
	int tp=0;
	int pos;
	for(int sit=0;sit<Max;++sit){
		if(check(sit)){
			tp=get_ans(sit);
		}
		if(tp<ans){
			ans=tp;
		}
	}
	return ans*w;
}
int main(){
	open();
	int T;
	scanf("%d",&T);
	while(T--){
		printf("%d\n",solve());
	}
	close();
	return 0;
}
