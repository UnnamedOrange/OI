#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define per(i, a, b) for (int i = (a); i >= (b); --i)
#define pb push_back
#define mp make_pair
using namespace std;

template<typename T>
void read(T& n){
	char ch; int sign = 1;
	while(!isdigit(ch = getchar())) if (ch == '-') sign = -1;
	n = ch - '0';
	while(isdigit(ch = getchar())) n = n * 10 + ch - '0';
	n=n*sign;
}
typedef long long ll;
const int INF = 1e9 + 7;
const int N = 122;
int T, n, ans;
int a[N], d[N];

bool check(){
	rep(i, 1, n) if (a[i] != i) return false;
	return true;
}
bool dfs(int x){
	if (x > ans) return check();
	bool ret = false;
	rep(i, 2, n){
		reverse(a + 1, a + i + 1);
		d[x] = i, ret |= dfs(x + 1);
		if (ret) return true;
		reverse(a + 1, a + i + 1);
	}
	return ret;
}

int main(){
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	read(T);
	while(T--){
		read(n);
		rep(i, 1, n) read(a[i]);
		for (ans = 0; ; ans++)
			if (dfs(1)) break;
		printf("%d\n", ans);
	}
	return 0;
}


