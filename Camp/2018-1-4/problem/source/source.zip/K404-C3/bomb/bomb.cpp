#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 1000010
#define ll long long
using namespace std;
char xB[1<<15],*xS=xB,*xT=xB;
#define getchar() (xS==xT&&(xT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xT)?0:*xS++)
inline int read() 
{ 
    int x=0,f=1;char ch=getchar(); 
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();} 
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
    return x*f; 
}
struct zgz
{
    int next,to;
}edge[N],Edge[N];
int head[N],Head[N],cnt=1,Cnt=1;
int f[N],deg_out[N],ans,n,m;
queue<int> q;
void add(int from,int to)
{
    edge[cnt].to=to;
    edge[cnt].next=head[from];
    head[from]=cnt++;
}
void Add(int from,int to)
{
    deg_out[to]++;
    Edge[Cnt].to=to;
    Edge[Cnt].next=Head[from];
    Head[from]=Cnt++;
}
int tot,dfn[N],low[N],scnt,stk[N],top,v,sz[N],belong[N];
bool vis[N];
inline int Mn(int a,int b)
{return a<b?a:b;}
inline int Mx(int a,int b)
{return a>b?a:b;}
void topsort()
{
    for(int i=1;i<=scnt;i++)
        if(!deg_out[i])q.push(i);
    while(!q.empty())
    {
        int x=q.front();q.pop();
        f[x]+=sz[x];
        for(int i=Head[x];i;i=Edge[i].next)
        {
            int to=Edge[i].to;
            deg_out[to]--; f[to]=Mx(f[x],f[to]);
            if(!deg_out[to]) q.push(to);
        }
    }
}
 
void tarjan(int x)
{
    low[x]=dfn[x]=++tot;
    stk[++top]=x;
    vis[x]=1;
    for(int i=head[x];i;i=edge[i].next)
    {
        int to=edge[i].to;
        if(!dfn[to])
        {
            tarjan(to);
            low[x]=Mn(low[x],low[to]);
        }
        else if(vis[to])
            low[x]=Mn(low[x],dfn[to]);
    }
    if(low[x]==dfn[x])
    {
        scnt++;
        do{
            v=stk[top--];
            vis[v]=0;
            belong[v]=scnt;
            sz[scnt]++;
        }while(v!=x);
    }
}
void rebuild()
{
    for(int x=1;x<=n;x++)
    {
        for(int i=head[x];i;i=edge[i].next)
        {
            int to=edge[i].to;
            if(to!=x&&belong[to]!=belong[x])
                Add(belong[to],belong[x]);
        }
    }
}
 
int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
    n=read(),m=read();
    while(m--)
    {
        int x=read(),y=read();
        if(x!=y)add(x,y);
    }
    for(int i=1;i<=n;i++)
    if(!dfn[i])tarjan(i);
    
    rebuild();
    topsort();
    for(int i=1;i<=scnt;i++)
        ans=Mx(ans,f[i]);
    printf("%d\n",ans);
}