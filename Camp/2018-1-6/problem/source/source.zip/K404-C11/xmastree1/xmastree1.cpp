#include <bits/stdc++.h>

namespace {

inline char read() {
    static const int IN_LEN = 1 << 18 | 1;
    static char buf[IN_LEN], *s, *t;
    return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)),
            s == t ? -1 : *s++;
}

template <typename T>
inline void read(T &x) {
    static char c;
    static bool iosig;
    for (c = read(), iosig = false; !isdigit(c); c = read()) {
        if (c == -1) return;
        iosig |= c == '-';
    }
    for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
    iosig && (x = -x);
}

inline int read(char *buf) {
    register int s = 0;
    register char c;
    while (c = read(), isspace(c) && c != -1)
        ;
    if (c == -1) {
        *buf = 0;
        return -1;
    }
    do
        buf[s++] = c;
    while (c = read(), !isspace(c) && c != -1);
    buf[s] = 0;
    return s;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
    (oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
    *oh++ = c;
}

template <typename T>
inline void print(T x) {
    static int buf[21], cnt;
    if (x != 0) {
        (x < 0) && (print('-'), x = -x);
        for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
        while (cnt) print((char)buf[cnt--]);
    } else {
        print('0');
    }
}

inline void print(const char *s) {
    for (; *s; s++) print(*s);
}

struct InputOutputStream {
    ~InputOutputStream() {
        fwrite(obuf, 1, oh - obuf, stdout);
    }

    template <typename T>
    inline InputOutputStream &operator>>(T &x) {
        read(x);
        return *this;
    }

    template <typename T>
    inline InputOutputStream &operator<<(const T &x) {
        print(x);
        return *this;
    }
} io;

const int MAXN = 100000 + 9;

std::vector<int> edge[MAXN];

inline void addEdge(const int u, const int v) {
    edge[u].push_back(v);
    edge[v].push_back(u);
}

int in[MAXN], out[MAXN], id[MAXN], idx, c[MAXN], n, q, t;

void dfs(const int u, const int fa) {
    in[u] = ++idx;
    id[idx] = u;
    for (register int i = 0, v; i < (int)edge[u].size(); i++) 
        if ((v = edge[u][i]) != fa) dfs(v, u);
    out[u] = idx;
}

typedef unsigned int uint;

inline uint nextUint() {
    static uint x = 495;
    return x ^= x << 13, x ^= x >> 17, x ^= x << 5, x;
}

char **cur;

const int MAX_LOG = 17;
const int MAXM = MAX_LOG * 4 * MAXN;

struct Node *null;

struct Node {
    static const int NODE_SIZE;
    Node *lc, *rc;
    int key, cnt, size;
    uint rank;
    Node(int key) : cnt(1), size(1), rank(nextUint()), 
            key(key), lc(null), rc(null) {}

    inline void maintain() {
        size = lc->size + rc->size + 1;
    }

    inline void *operator new(size_t) {
        return *--cur;
    }

    inline void operator delete(void *o) {
        if ((Node *)o != null) *cur++ = (char *)o;
    }
};

const int Node::NODE_SIZE = sizeof(Node);

char *unused[MAXM];
char pool[MAXM * Node::NODE_SIZE];

Node *d[MAXN * 4];

inline Node *select(Node *p, int k) {
    for (; p != null && p->key != k;)
        k <= p->key ? p = p->lc : p = p->rc;
    return p;
}

inline Node *merge(Node *u, Node *v) {
    if (u == null) return v;
    if (v == null) return u;
    if (u->rank < v->rank) {
        u->rc = merge(u->rc, v);
        u->maintain();
        return u;
    } else {
        v->lc = merge(u, v->lc);
        v->maintain();
        return v;
    }
}

void dfs(Node *u) {
    if (u == null) return;
    dfs(u->lc);
    std::cerr << u->key << ' ';
    dfs(u->rc);
}

inline void split(Node *u, int k, Node *&l, Node *&r) {
    if (u == null) return (void)(l = r = null);
    if (k <= u->key) {
        split(u->lc, k, l, r);
        u->lc = r;
        r = u;
    } else {
        split(u->rc, k, l, r);
        u->rc = l;
        l = u;
    }
    u->maintain();
}

std::vector<Node *> recycle;

inline Node *copyMerge(Node *u, Node *v) {
    if (u == null) return v;
    if (v == null) return u;
    if (u->rank < v->rank) {
        Node *p = new Node(*u);
        recycle.push_back(p);
        p->rc = copyMerge(p->rc, v);
        p->maintain();
        return p;
    } else {
        Node *p = new Node(*v);
        recycle.push_back(p);
        p->lc = copyMerge(u, p->lc);
        p->maintain();
        return p;
    }
}

inline void copySplit(Node *u, int k, Node *&l, Node *&r) {
    if (u == null) return (void)(l = r = null);
    Node *p = new Node(*u);
    recycle.push_back(p);
    if (k <= u->key) {
        copySplit(p->lc, k, l, r);
        p->lc = r;
        r = p;
    } else {
        copySplit(p->rc, k, l, r);
        p->rc = l;
        l = p;
    }
    p->maintain();
}

inline Node *fingerSearch(Node *u, Node *v) {
    if (u == null) return v;
    if (v == null) return u;
    if (u->rank > v->rank) std::swap(u, v);
    register Node *l, *r;
    copySplit(v, u->key, l, r);
    register Node *p = new Node(*u);
    recycle.push_back(p);
    if (select(r, u->key) != null) {
        register Node *tL, *tR;
        copySplit(r, u->key + 1, tL, tR);
        p->cnt += tL->cnt;
        r = tR;
    }
    p->lc = fingerSearch(p->lc, l);
    p->rc = fingerSearch(p->rc, r);
    p->maintain();
    return p;
}

inline void insert(Node *&p, int key) {
    register Node *l, *r;
    split(p, key, l, r);
    p = merge(l, merge(new Node(key), r));
}

inline void erase(Node *&p, int key) {
    register Node *l, *r, *tL, *tR;
    split(p, key, l, r);
    split(r, key + 1, tL, tR);
    delete tL;
    p = merge(l, tR);
}

int M;

inline void modify(int k, int col, int newCol) {
    if (col == newCol) return;
    register Node *it;
    for (k += M; k; k >>= 1) {
        it = select(d[k], col);
        if (it != null) {
            if (--it->cnt == 0) erase(d[k], col);
        }
        it = select(d[k], newCol);
        if (it != null) it->cnt++;
        else insert(d[k], newCol);
    }
}

inline void insert(int k, int col) {
    register Node *it;
    for (k += M; k; k >>= 1) {
        it = select(d[k], col);
        if (it != null) it->cnt++;
        else insert(d[k], col);
    }
}

inline int query(register int s, register int t, int l, int r) {
    register Node *ans = null;
    register Node *L, *R, *tL, *tR;
    for (s = s + M - 1, t = t + M + 1; s ^ t ^ 1; s >>= 1, t >>= 1) {
        if (~s & 1) {
            copySplit(d[s ^ 1], l, L, R);
            copySplit(R, r + 1, tL, tR);
            ans = fingerSearch(ans, tL);
        }
        if (t & 1) {
            copySplit(d[t ^ 1], l, L, R);
            copySplit(R, r + 1, tL, tR);
            ans = fingerSearch(ans, tL);
        }
    }
    register int size = ans->size;
    for (register int i = 0; i < (int)recycle.size(); i++) {
        delete recycle[i];
    }
    recycle.clear();
    return size;
} 

namespace Force {

std::bitset<5011> buc;

inline void solve() {
    register int ans = 0;
    for (register int cmd, u, l, r, col; q--;) {
        io >> cmd;
        switch (cmd) {
            case 1: {
                io >> u >> l >> r;
                if (t) {
                    u ^= ans;
                    l ^= ans;
                    r ^= ans;
                }
                buc.reset();
                for (register int i = in[u]; i <= out[u]; i++) {
                    if (c[id[i]] >= l && c[id[i]] <= r) buc.set(c[id[i]]);
                }
                ans = buc.count();
                io << ans << '\n';
                break;
            }
            case 2: {
                io >> u >> col;
                if (t) {
                    u ^= ans;
                    col ^= ans;
                }
                c[u] = col;
            }
        } 
    }
}
}

inline void solve() {
    io >> n >> q >> t;
    cur = unused;
    for (register int i = 0; i < MAXM; i++)
        *cur++ = pool + i * Node::NODE_SIZE;
    null = new Node(0);
    null->lc = null->rc = null;
    null->cnt = null->size = 0;
    null->rank = nextUint();
    for (register int i = 1; i <= n; i++) {
       io >> c[i];
    }
    for (register int i = 1, u, v; i < n; i++) {
       io >> u >> v;
        addEdge(u, v);
    }
    dfs(1, 0);
    if (n <= 5000) {
        Force::solve();
        return;
    }
    for (M = 1; M < n + 2;) M <<= 1;
    for (register int i = 0; i <= M * 2; i++) d[i] = null; 
    for (register int i = 1; i <= n; i++) {
        insert(in[i], c[i]);
    }
    register int ans = 0;
    for (register int cmd, u, l, r, col; q--;) {
        io >> cmd;
        switch (cmd) {
            case 1: {
                io >> u >> l >> r;
                if (t) {
                    u ^= ans;
                    l ^= ans;
                    r ^= ans;
                }
                ans = query(in[u], out[u], l, r);
                io << ans << '\n';
                break;
            }
            case 2: {
                io >> u >> col;
                if (t) {
                    u ^= ans;
                    col ^= ans;
                }
                modify(in[u], c[u], col);
                c[u] = col;
            }
        } 
    }
}
}

int main() {
    freopen("xmastree1.in", "r", stdin);
    freopen("xmastree1.out", "w", stdout);
    solve();
    return 0;
}