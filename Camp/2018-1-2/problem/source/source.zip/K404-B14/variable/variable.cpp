#include<bits/stdc++.h>
#define LL long long
#define MP make_pair
#define PB push_back
#define F first
#define S second
#define PII pair<int, int>
const int INF = 0x3f3f3f3f;
using namespace std;
const int MAXN = 20;
int T, n, W, p, q, ans;
struct Node{
	int x, y, z, a, b, c, d, e, f;
	void get(){cin >> x >> y >> z >> a >> b >> c >> d >> e >> f; x--; y--; z--;}
	int calc(int X, int Y, int Z){return a * abs(X - Y) + b * abs(Y - Z) + c * abs(Z - X) + d * (X - Y) + e * (Y - Z) + f * (Z - X);}
}t[MAXN];
struct Node2{
	int x, y, r;
	void get(){cin >> x >> y >> r; x--; y--;}
	bool check(int X, int Y){return (r == 0 && X <= Y) || (r == 1 && X == Y) || (r == 2 && X < Y);}
}d[MAXN];
int c(int x){return x ? 1 : -1;}
int main(){
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	cin >> T;
	while(T--){
		cin >> n >> W >> p >> q;
		for(int i = 0; i < p; i++){
			t[i].get();
		}
		for(int i = 0; i < q; i++){
			d[i].get();
		}
		ans = INF;
		for(int i = 0; i < 1 << n; i++){
			bool flag = false;
			for(int j = 0; j < q && !flag; j++){
				if(!d[j].check(c(i & (1 << d[j].x)), c(i & (1 << d[j].y)))) flag = true;
			}
			if(flag) continue;
			int tmp = 0;
			for(int k = 0; k < n; k++) tmp += c(i & (1 << k));
			for(int j = 0; j < p; j++){
				tmp += t[j].calc(c(i & (1 << t[j].x)), c(i & (1 << t[j].y)), c(i & (1 << t[j].z)));
			}
			if(tmp < ans) ans = tmp;
		}
		cout << ans * W << endl;
	}
	return 0;
}
