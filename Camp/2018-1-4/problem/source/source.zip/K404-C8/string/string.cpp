#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<bitset>
using namespace std;
const int mod=998244353;
void MOD(int &x) {if (x>=mod) x-=mod;}


int n,m;
char ch[6][105],s[6][105];

int l[6],q[605],hd,tl;
struct aa
{
	int ch[605][2],tot,f[605];bool b[605];bitset<600> bj[605];bool ty;
	void clear()
	{
		for (int i=0;i<=tot;i++) ch[i][0]=ch[i][1]=f[i]=b[i]=0,bj[i].reset();
		tot=0;
	}
	void insert(int id,int l)
	{
		int t=0,c;
		for (int i=0;i<l;i++) 
		{
			if (ty) c=s[id][l-i-1]-'0';else c=s[id][i]-'0';
			if (!ch[t][c]) ch[t][c]=++tot;
			t=ch[t][c];
			
			if (i==l-1) break;
			if (ty) bj[t].set(id*100+l-i-2);
			else bj[t].set(id*100+i);
		}
		b[t]=true;
	}
	void get_fail()
	{
		hd=1,tl=0;
		if (ch[0][0]) q[++tl]=ch[0][0];
		if (ch[0][1]) q[++tl]=ch[0][1];
		while (hd<=tl) 
		{
			int u=q[hd++];
			bj[u]=bj[u]|bj[f[u]];
			if (b[f[u]]) b[u]=true;
			if (ch[u][0]) f[ch[u][0]]=ch[f[u]][0],q[++tl]=ch[u][0];
			else ch[u][0]=ch[f[u]][0];
			if (ch[u][1]) f[ch[u][1]]=ch[f[u]][1],q[++tl]=ch[u][1];
			else ch[u][1]=ch[f[u]][1];
		}
	}
}U,V;

int f[2][605][605],r;
int work(int n)
{	
	for (int i=0;i<n;i++) 
	{
		l[i]=strlen(s[i]);
		U.insert(i,l[i]);
		V.insert(i,l[i]);
	}
	U.get_fail(),V.get_fail();
	
	r=0;
	for (int i=0;i<=U.tot;i++)
		for (int j=0;j<=V.tot;j++) f[0][i][j]=f[1][i][j]=0;
	f[0][0][0]=1;
	for (int i=0;i<m;i++) 
	{
		for (int u=0;u<=U.tot;u++) if (!U.b[u])
			for (int v=0;v<=V.tot;v++) 
			if (!V.b[v])
			{
				MOD(f[r^1][U.ch[u][0]][V.ch[v][1]]+=f[r][u][v]);
				MOD(f[r^1][U.ch[u][1]][V.ch[v][0]]+=f[r][u][v]);
				f[r][u][v]=0;
			}
		r^=1;
	}
	int ans=0;
	for (int u=0;u<=U.tot;u++) if (!U.b[u])
		for (int v=0;v<=V.tot;v++) if (!V.b[v]) 
		if ((U.bj[u]&V.bj[v]).count()==0) MOD(ans+=f[r][u][v]);
	U.clear(),V.clear();
	return ans;
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	U.ty=false;V.ty=true;
	
	scanf("%d%d",&n,&m);
	for (int i=0;i<n;i++) scanf("%s",ch[i]);
	
	
	int ans=1,t;for (int i=1;i<=m;i++) MOD(ans<<=1);
	for (int ss=1;ss<(1<<n);ss++) 
	{
		t=0;
		for (int j=0;j<n;j++) if (ss&(1<<j)) memcpy(s[t++],ch[j],sizeof(ch[j]));
		if (t&1) MOD(ans=ans-work(t)+mod);else MOD(ans+=work(t));
	}
	printf("%d\n",ans);
	return 0;
}
/*
2 3
011
001

6 100
100011001010110010111111101000
100011011110100100001011111001
101000101001011110001000100101
001101110000110001001010110111
010101101010101010101111110100
010101100101100100101110010101
*/

