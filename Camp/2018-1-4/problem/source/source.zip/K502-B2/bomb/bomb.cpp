#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
const int M=(int)1e6+5;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
void Max(int &x,int y){
	if(x<y)x=y;
}
void Min(int &x,int y){
	if(x>y)x=y;
}
struct W{
	int to,nx;
}Lis[M];
int Head[M],tot;
void Add(int x,int y){
	Lis[++tot]=(W){y,Head[x]};
	Head[x]=tot;
}
int n,m;
struct SHUI{
	int dp[(1<<10)];
	int e[10],OK[(1<<10)],dui[(1<<10)];
	void dfs(int x,int y){
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if((e[y]&(1<<(to-1)))==0){
				e[y]|=(1<<(to-1));
				e[to-1]|=(1<<y);
				dfs(to,y);
			}
	}
	void solve(){
		for(int i=0;i<n;i++)dfs(i+1,i),OK[(1<<i)]=1,dui[(1<<i)]=i;
		OK[0]=1;
		for(int i=1,up=(1<<n),S,rS;i<up;i++){
			S=i,rS=S&(-S),S^=rS;
			OK[i]=OK[S]&((e[dui[rS]]&S)==0);
		}
		memset(dp,-1,sizeof(dp));
		dp[(1<<n)-1]=0;
		for(int i=(1<<n)-1,tmp,nx;i>0;i--)
			for(int S=i;S;S=(S-1)&i)
				if(OK[S]){
					nx=i^S;
					tmp=dp[i]+1;
					if(dp[nx]>tmp||dp[nx]==-1)dp[nx]=tmp;
				}
		printf("%d\n",dp[0]);
	}
}P20;

struct IUHS{
	int mark[M],ret;
	void dfs(int x,int c){
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(mark[to]==0)dfs(to,c);
			else if(mark[to]==c)ret=false;
	}
	bool check_cir(){
		ret=true;
		for(int i=1;i<=n;i++)if(mark[i]==0)dfs(i,i);
		return ret;
	}
	void solve(){
		static int q[M],deg[M],level[M],L,R,x;L=R=0;
		int ans=0;
		for(int x=1;x<=n;x++)
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
				deg[to]++;
		for(int i=1;i<=n;i++)if(deg[i]==0)q[R++]=i,level[i]=1;
		while(L<R){
			x=q[L++];
			Max(ans,level[x]);
			for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx){
				Max(level[to],level[x]+1);
				if(deg[to]--==1)q[R++]=to;
			}
		}
		printf("%d\n",ans);
	}
}P30;
struct UHSI{
	int dfn[M],low[M],dfs_cnt;
	int stk[M],sz,instk[M];
	vector<int>ps[M];
	int ID[M],TOT;
	void dfs(int x){
		dfn[x]=low[x]=++dfs_cnt;
		stk[sz++]=x;
		instk[x]=1;
		for(int i=Head[x],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
			if(dfn[to]==0){
				dfs(to);
				Min(low[x],low[to]);
			}else if(instk[to])Min(low[x],dfn[to]);
		if(low[x]==dfn[x]){
			TOT++;
			for(;;){
				sz--;
				ps[TOT].push_back(stk[sz]);
				instk[stk[sz]]=0;
				ID[stk[sz]]=TOT;
				if(stk[sz]==x)break;
			}
		}
	}
	int deg[M],level[M],q[M],L,R;
	void solve(){
		for(int i=1;i<=n;i++)if(dfn[i]==0)dfs(i);
		L=R=0;
		for(int i=1;i<=TOT;i++)
			for(int j=0,up=ps[i].size();j<up;j++)
				for(int x=ps[i][j],p=Head[x],to;p&&(to=Lis[p].to,1);p=Lis[p].nx)
					if(ID[to]!=ID[x])deg[ID[to]]++;
		for(int i=1;i<=TOT;i++)
			if(deg[i]==0)q[R++]=i;
		int ans=0;
		while(L<R){
			int x=q[L++];
			level[x]+=ps[x].size();
			Max(ans,level[x]);
			for(int j=0,up=ps[x].size();j<up;j++)
				for(int xx=ps[x][j],i=Head[xx],to;i&&(to=Lis[i].to,1);i=Lis[i].nx)
					if(ID[to]!=ID[xx]){
						Max(level[ID[to]],level[x]);
						if(deg[ID[to]]--==1)
							q[R++]=ID[to];
					}
		}
		printf("%d\n",ans);
	}
}PPP;
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	Rd(n),Rd(m);
	for(int i=1,x,y;i<=m;i++)Rd(x),Rd(y),Add(x,y);
//	if(0);
	if(n<=10)P20.solve();
	else if(P30.check_cir())P30.solve();
	else PPP.solve();
	return 0;
}
