/*****************************************************
	File:segment.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-12 10:12:54
*****************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
long long read()
{
	long long r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define mod 998244353
#define N 100010
long long power(long long x,long long y,long long m)
{
	long long r=1;
	while(y)
	{
		if(y&1)
			r=r*x%m;
		y>>=1;
		x=x*x%m;
	}
	return r;
}
long long n,m,k,ans,l[N],r[N],s[N],p[N];
void dfsr(int x)
{
	if(x==n+1)
	{
//		fr(i,1,n)
//			printf("%lld %lld\n",l[i],r[i]);
//		fr(i,1,m)
//			printf("%lld%c",s[i],i==m?'\n':' ');
//		printf("%lld\n",ans);
		int k=0;
		fr(i,1,m)
			ans=(ans+p[k+=s[i]])%mod;
//		printf("%lld\n",ans);
//		putchar(10);
		return;
	}
	fr(i,max(l[x],r[x-1]+1),m)
	{
		r[x]=i;
		s[i]--;
		dfsr(x+1);
		s[i]++;
	}
}
void dfsl(int x)
{
	if(x==n+1)
	{
		dfsr(1);
		return;
	}
	fr(i,l[x-1]+1,m)
	{
		l[x]=i;
		s[i]++;
		dfsl(x+1);
		s[i]--;
	}
}
int main()
{
	freopen("segment.out","w",stdout);
	freopen("segment.in","r",stdin);
	n=read();
	m=read();
	k=read();
	if(n>=m)
	{
		printf("0\n");
		return 0;
	}
	if(m>=6)
	{
		if(n==1)
		{
			n=1;
			ans=1;
			fr(i,3,m)
				ans=ans*(i+1)%mod*power(i-2,mod-2,mod)%mod;
			printf("%lld\n",ans);
			return 0;
		}
		if(n==2&&k==1)
		{
			n=2;
			ans=1;
			fr(i,3,m)
				ans=ans*(i+1)%mod*power(i-2,mod-2,mod)%mod;
			ans=ans*power(5,mod-2,mod);
			long long k1=0,k2=5;
			fr(i,3,m)
			{
				k1=(k1+k2)%mod;
				k2=(k2+3)%mod;
			}
			ans=ans*k1%mod;
			printf("%lld\n",ans);
			return 0;
		}
		if(k==998244352)
		{
			n=min(n,m-n);
			int k1=2;
			fr(i,3,m+n)
			{
				s[i]=(s[i-1]+k1)%mod;
				k1++;
			}
			ans=1;
			fd(i,n,2)
				ans=ans*s[m-i+2]%mod*power(s[i+1],mod-2,mod)%mod;
			fr(i,3,m)
				ans=ans*(i+1)%mod*power(i-2,mod-2,mod)%mod;
			printf("%lld\n",ans);
			return 0;
		}
	}
	fr(i,0,n)
		p[i]=power(i,k,mod);
//	fr(i,0,n)
//		printf("%lld%c",p[i],i==n?'\n':' ');
	dfsl(1);
	printf("%lld\n",ans);
	return 0;
}