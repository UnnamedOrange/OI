#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;++i)
using namespace std;
int read(){
	int x=0,l=1; char ch=getchar();
	while(!isdigit(ch)) {if (ch=='-') l=-1; ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*l;
}
const int N=100005,mo=998244353;
int an[N],e,head[N],nex[N<<1],to[N<<1],a[N<<1],in[N],cnt[N],q[N],l,r;
int ksm(int x,int y){
	long long z=x; int an=0,f=1;
	while(y){
		if (f&y) {y=y^f; an+=z; if (an>=mo) an-=mo;}
		z=z*z%mo; f=f<<1;
	}
	return an;
}
void add(int x,int y){
	to[++e]=y; nex[e]=head[x]; head[x]=e; ++in[y];
}
void dfs(int x,int f){
	an[x]+=a[f]; if (an[x]>=mo) an[x]-=mo;
	for(int i=head[x];i;i=nex[i]) dfs(to[i],f+1);
}
int main(){
	freopen("xmasdag.in","r",stdin); freopen("xmasdag.out","w",stdout);
	int n=read(),m=read(),k=read(),x,y;
	For(i,1,m) x=read(),y=read(),add(x,y);
	if (k==1){
		q[1]=1; l=0; r=1; cnt[1]=1;
		while(l<r){
			x=q[++l];
			for(int i=head[x];i;i=nex[i]){
				y=to[i]; an[y]=((cnt[x]+an[x])%mo+an[y])%mo; cnt[y]=(cnt[y]+cnt[x])%mo; in[y]--;
				if (!in[y]) q[++r]=y;
			}
		}
		For(i,1,n) printf("%d\n",an[i]); return 0;
	}
	For(i,1,m) a[i]=ksm(i,k);
	dfs(1,0); For(i,1,n) printf("%d\n",an[i]);
	return 0;
}
