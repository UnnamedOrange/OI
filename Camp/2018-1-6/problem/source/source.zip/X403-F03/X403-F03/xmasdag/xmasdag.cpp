#include<cstdio>
#include<iostream>
#include<cstring>
#define ll long long
using namespace std;
const ll mod=998244353;
ll s[101010][33],a[101010][33];
ll C[555][555];
int du[101010],now[101010],pre[202020],son[202020];
int que[101010];
ll ans[101010],cl[101010];
ll f[2020][2020];
int n,m,k,doe;
ll power(ll x,ll kk)
{
	ll sss=1;
	while (kk)
	{
		if (kk%2) sss=sss*x%mod;
		x=x*x%mod;
		kk/=2;
	}
//	printf("%lld\n",sss);
	return sss;
}
void add(int x,int y)
{
	++doe;
	pre[doe]=now[x];
	now[x]=doe;
	son[doe]=y;
	++du[y];
}
void check(int x)
{
	for (int i=0;i<=k;++i)
	{
		for (int j=0;j<=i;++j)
			s[x][i]=(s[x][i]+C[i][j]*a[x][j]%mod)%mod;
	}
	ans[x]=s[x][k];
}
void sol()
{
	int head=1,tail=1;
	que[1]=1;
	s[1][0]=1;
	while (head<=tail)
	{
		int x=que[head];
		if (x!=1) check(x);
		int p=now[x];
		while (p)
		{
			int y=son[p];
			for (int i=0;i<=k;++i)
				a[y][i]=(a[y][i]+s[x][i])%mod;
			--du[y];
			if (du[y]==0)
			{
				++tail;
				que[tail]=y;
			}
			p=pre[p];
		}
		++head;
	}
}
void bl()
{
	int head=1,tail=1;
	que[1]=1;
	f[1][0]=1;
	while (head<=tail)
	{
		int x=que[head];
		if (x!=1)
			for (int i=1;i<=n;++i)
				ans[x]=(ans[x]+f[x][i]*cl[i]%mod)%mod;
		int p=now[x];
		while (p)
		{
			int y=son[p];
			for (int i=1;i<=n;++i)
					f[y][i]=(f[y][i]+f[x][i-1])%mod;
			--du[y];
			if (du[y]==0)
			{
				++tail;
				que[tail]=y;
			}
			p=pre[p];
		}
		++head;
	}
}
int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);

	C[0][0]=1;
	for (int i=1;i<=505;++i)
	{
		C[i][0]=C[i][i]=1;
		for (int j=1;j<i;++j)
			C[i][j]=(C[i-1][j-1]+C[i-1][j])%mod;
	}

	scanf("%d%d%d",&n,&m,&k);
	int x,y;
	for (int i=1;i<=m;++i)
	{
		scanf("%d%d",&x,&y);
		add(x,y);
	}

	if (n<=2010)
	{
		for (int i=1;i<=n;++i)
			cl[i]=power(i,k);
		bl();
		printf("0\n");
		for (int i=2;i<=n;++i)
			printf("%lld\n",ans[i]);
		return 0;
	}
	sol();

	printf("0\n");
	for (int i=2;i<=n;++i)
		printf("%lld\n",ans[i]);
	
	return 0;
}
