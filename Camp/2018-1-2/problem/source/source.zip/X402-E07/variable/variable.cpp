#include <bits/stdc++.h>
using namespace std;
const int maxn = 1000 +10;
const long long inf = 1e16;
int read(){
	int x=0,flag=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')flag=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*flag;
}
struct nod{
	int x,y,z,a,b,c,d,e,f;
	nod(void){}
};
struct point{
	int x,y,r;
	point(void){}
};
nod ai[maxn];
point bi[maxn];
int n;
long long w,w2;
int p,q;
long long ci[maxn];
long long ans;
bool chk(){
	int x,y;
	for(int i=1;i<=q;i++){
		x=bi[i].x;y=bi[i].y;
		if(bi[i].r==0&&ci[x]>ci[y])return 0;
		if(bi[i].r==1&&ci[x]!=ci[y])return 0;
		if(bi[i].r==2&&ci[x]>=ci[y])return 0;
	}
	return 1;
}
long long calc(){
	long long tmp=0;
	for(int i=1;i<=n;i++)tmp+=ci[i];
	for(int i=1;i<=p;i++){
		tmp += ai[i].a * abs( ci[ai[i].x] - ci[ai[i].y] );
		tmp += ai[i].b * abs( ci[ai[i].z] - ci[ai[i].y] );
		tmp += ai[i].c * abs( ci[ai[i].x] - ci[ai[i].z] );
		tmp += ai[i].d * ( ci[ai[i].x] - ci[ai[i].y] );
		tmp += ai[i].e * ( ci[ai[i].y] - ci[ai[i].z] );
		tmp += ai[i].f * ( ci[ai[i].z] - ci[ai[i].x] );
	}
	return tmp;
}
void dfs(int x){
	if(x==n+1){
		if(chk())ans=min(ans,calc());
		return;
	}
	ci[x]=-w;dfs(x+1);ci[x]=w;dfs(x+1);
}
int main(){
	freopen("variable.in","r",stdin),freopen("variable.out","w",stdout);
	int T;scanf("%d",&T);
	for(int cas=1;cas<=T;cas++){
		ans=inf;
		scanf("%d%lld%d%d",&n,&w,&p,&q);w2 = w;
		for(int i=1;i<=p;i++){
			ai[i].x=read();ai[i].y=read();ai[i].z=read();
			ai[i].a=read();ai[i].b=read();ai[i].c=read();
			ai[i].d=read();ai[i].e=read();ai[i].f=read();
		}
		for(int i=1;i<=q;i++){
			bi[i].x=read();bi[i].y=read();bi[i].r=read();
		}
		if(n>=15)printf("0\n");
		else{
			dfs(1);
			printf("%lld\n",ans);
		}
	}
	return 0;
}
