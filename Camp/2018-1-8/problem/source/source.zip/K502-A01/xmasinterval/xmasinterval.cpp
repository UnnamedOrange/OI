#include <bits/stdc++.h>
using namespace std;
const int Maxn = 30, Mod = 1000000009;
struct node
{
	int x, y;
}A[Maxn];
int B[Maxn], P[Maxn];
int N, M, Ans;
inline void Check()
{
	int j = 1;
	for (int i = 1; i <= N; ++i)
	{
		if (!P[i]) continue;
		while (A[i].x <= B[j] && B[j] <= A[i].y)
			++j;
		if (j == M + 1)
		{
			++Ans;
			Ans %= Mod;
			return ;
		}
	}
	return ;
}
inline void dfs(int x)
{
	if (x == N)
	{
		Check();
		return ;
	}
	P[x + 1] = 1;
	dfs(x + 1);
	P[x + 1] = 0;
	dfs(x + 1);
}
inline int cmp(node a, node b)
{
	if (a.x == b.x) return a.y < b.y;
	return a.x < b.x;
}
int main()
{
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	scanf("%d%d", &N, &M);
	for (int i = 1; i <= N; ++i) scanf("%d%d", &A[i].x, &A[i].y);
	sort(A + 1, A + N + 1, cmp);
	for (int i = 1; i <= M; ++i) scanf("%d", &B[i]);
	sort(B + 1, B + M + 1);
	dfs(0);
	cout<<Ans<<endl;
	return 0;
}
