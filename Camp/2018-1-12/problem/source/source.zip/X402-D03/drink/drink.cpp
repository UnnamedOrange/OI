#include<bits/stdc++.h>
using namespace std;

typedef long double ld;
const int MAXN = 1000010;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, w[MAXN];
ld ans;

int main() {
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);

	int i, j, k;

	n = read();
	for(i = 1; i <= n; i++) w[i] = read();

	for(i = 1; i <= n; i++) {
		ld res = 0.5, val = 2; 
		for(j = i-1; j >= 1; j--) {
			if(w[j] >= w[i]) val *= 2;
			res += 1.0/val;
		}
		res *= w[i];
		for(j = i; j <= n; j++) {
			if(w[j] > w[i]) res *= 0.5;
			ans += res;
		}
	}
	printf("%.10LF\n", ans/n/n);
	return 0;
}
