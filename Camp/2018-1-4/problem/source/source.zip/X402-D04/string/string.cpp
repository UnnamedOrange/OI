#include<bits/stdc++.h>
using namespace std;

const int maxn=510;
const int mod=998244353;
int n,m;
int ans;
char s[10][maxn];
int str[maxn];
int use[maxn];

bool check(char *s){
	int len=strlen(s+1), ret=0;
	// printf("%s\n", s+1);
	for(int i=1;i+len-1<=2*m;i++){
		int flag=1;
		for(int j=1;j<=len;j++) if(use[i+j-1]!=s[j]-'0'){ flag=0; break; }
		if(flag) return true;
	}
	return false;
}

int dp[maxn][110][110];
int fail[maxn];
void solve(){
	dp[0][0][0]=1;
	int len=strlen(s[1]+1);
	for(int i=1;i<=len;i++) str[i]=s[1][i]-'0';
	fail[1]=1; fail[2]=1;
	for(int i=3;i<=len;i++){
		int j=fail[i-1];
		while(j && str[i]!=str[j]) j=fail[j];
	}
	/*
	for(int i=1;i<=m;i++){
		for(int j=0;j<=len;j++){
			if(!j){ dp[i][j][0]=dp[i][j][1]=1; continue; }
			for(int l=0;l<=1;l++){
				if(j && l==s[1][j]) (dp[i][j][0]+=dp[i-1][j-1][0])%=mod;
				if(j && l==(!str[len+1-j])) (dp[i][j][1]+=dp[i-1][j-1][1])%=mod;
			}
		}
	}
	*/
	for(int i=0;i<=m;i++) for(int j=0;j<=len;j++) for(int k=0;k<=len;k++){
		int jj=j, kk=k;
		for(int l=0;l<=1;l++){
			if(l==str[j]) jj++; else jj=(str[1]==l); jj=min(jj, len);
			if(l==(!str[len+1-j])) kk++; else kk=(str[len]==(!l)); kk=min(kk, len);
			(dp[i+1][jj][kk]+=dp[i][j][k])%=mod;
		}
	}
	int ans=0;
	for(int j=0;j<len;j++) (ans+=((dp[m][len][j]+dp[m][j][len])%mod+dp[m][len][len])%mod)%=mod;
	for(int i=(len+1)/2;i<=len;i++){
		int pos=i;
		int flag=1;
		for(int j=1;j<=i && i+j<=len;j++){
			if(str[i+j]!=str[pos]){ flag=0; break; }
			pos--;
		}
		if(flag){
			for(int j=0;j<len;j++) (ans+=dp[m][i][j])%=mod;
		}
		pos=n-i+1; flag=1;
		for(int j=1;j<=i && i+j<=len;j++){
			if(str[n-i-j+1]!=(!str[pos])){ flag=0; break; }
			pos--;
		}
		if(flag){
			for(int j=0;j<len;j++) (ans+=dp[m][j][i])%=mod;
		}
	}
	printf("%d\n", ans);
}

int main(){
	freopen("string.in","r",stdin),freopen("string.out","w",stdout);

	scanf("%d%d", &n, &m);
	for(int i=1;i<=n;i++) scanf("%s", s[i]+1);
	if(m>15){ solve(); return 0; }
	for(int i=0;i<(1<<m);i++){
		for(int j=1;j<=m;j++) if(i & (1<<(j-1))) use[j]=1; else use[j]=0;
		for(int j=m+1;j<=2*m;j++) use[j]=!use[2*m-j+1];
		// for(int j=1;j<=2*m;j++) printf("%d", use[j]); puts("");
		int flag=1;
		for(int j=1;j<=n;j++) if(!check(s[j])){ flag=0; break; }
		if(!flag) continue;
		ans++;
	}
	printf("%d\n", ans);
	return 0;
}
