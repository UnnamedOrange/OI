#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)
#define Forr(i, j, k) for(int i = j; i >= k; i--)

using namespace std;

const int Mod = 998244353;

void add(int &x, int y){
	x += y;
	if(x >= Mod) x -= Mod;
}

const int N = 1e5 + 10, K = 510;

int Begin[N], Next[N << 1], to[N << 1], e;

void addedge(int u, int v){
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int dp[N][K], C[K][K];
bool vis[N];
int n, m, k;

void DFS(int o){
	vis[o] = true;
	if(o == 1){
		dp[o][0] = 1;
		return;
	}
	for(int i = Begin[o]; i; i = Next[i]){
		int u = to[i];
		if(!vis[u]) DFS(u);
		For(j, 0, k) add(dp[o][j], dp[u][j]);
	}
	Forr(i, k, 0) For(j, 0, i - 1)
		dp[o][i] = (dp[o][i] + 1ll * dp[o][j] * C[i][j]) % Mod;
}

int main(){

	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);
	For(i, 1, m){
		int u, v;
		scanf("%d%d", &u, &v);
		addedge(v, u);
	}
	For(i, 0, k){
		C[i][0] = 1;
		For(j, 1, i) C[i][j] = (C[i - 1][j] + C[i - 1][j - 1]) % Mod;
	}
	For(i, 1, n) if(!vis[i]) DFS(i);
	For(i, 1, n) printf("%d\n", dp[i][k]);

	return 0;
}
