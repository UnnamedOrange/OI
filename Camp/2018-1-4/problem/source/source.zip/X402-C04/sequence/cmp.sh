while true
do
	./gen
	./sequence
	./sequencess
	if diff sequence.out sequences.out
	then
		printf "#"
	else
		printf "Wa"
		exit 0
	fi
done
