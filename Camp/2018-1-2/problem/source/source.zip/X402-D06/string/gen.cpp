#include<bits/stdc++.h>
using namespace std;
char str[100010];
int main(){
	int i,j,k,m,n=5,T=10000,tmp;
	freopen("gen.in","r",stdin);
	scanf("%d",&tmp);
	srand(time(0)+tmp);
	freopen("string.in","w",stdout);
	printf("%d\n",T);
	while(T--){
		printf("%d\n",n);
		for(i=1;i<=(n+1)/2;i++)
			str[i]=(rand()%26)+'a';
		for(i=n/2+1;i<=n;i++)
			str[i]=str[n-i+1];
		if(rand()%100>70)str[n]='c';
		puts(str+1);
	}
	freopen("gen.in","w",stdout);
	printf("%d\n",rand());
	return 0;
}
