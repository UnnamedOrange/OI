#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef pair<int,int> pii;
typedef double db;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=100005,mod=998244353;
int Pow(int x,int y){
	int res=1;
	for(;y;y>>=1,x=(ll)x*x%mod)
		if(y&1)res=(ll)res*x%mod;
	return res;
}
int n,a[N];
struct P_0{
	void work(){
		int p[15],flag,ans=0,mark[15]={},tar=0,t;
		rep(i,1,n+1)p[i]=i;
		do {
			flag=true;
			rep(i,1,n+1)if(a[i]&&p[i]!=a[i]){flag=false;break;}
			if(!flag)continue;
			++tar;
			rep(i,1,n+1)if(mark[i]!=tar){
				t=i;
				while(mark[t]!=tar){
					flag^=1;
					mark[t]=tar;
					t=p[t];
				}
				if(!flag)break;
			}
			ans+=flag;
		}while(next_permutation(p+1,p+1+n));
		ptn(ans);
	}
}P0;
struct P_1{
	void work(){
		int ans=1;
		for(int i=1;i<n;i+=2)ans=(ll)ans*i%mod;
		ans=(ll)ans*ans%mod;
		ptn(ans);
	}
}P1;
struct P_2{
	int mark[N],deg[N];
	int KONG(int Mx){
		if(Mx&1)return 0;
		int ans=1;
		for(int i=1;i<Mx;i+=2)ans=(ll)ans*i%mod;
		ans=(ll)ans*ans%mod;
		return ans;
	}
	int fac[N],ifac[N];
	int C(int n,int m){
		if(n<m)return 0;
		return (ll)fac[n]*ifac[m]%mod*ifac[n-m]%mod;
	}
	void work(){
		int sz[2]={};
		fac[0]=1;ifac[0]=1;
		rep(i,1,n+1){//Ҫ��ȥ�����еĻ� 
			fac[i]=(ll)fac[i-1]*i%mod;
			++deg[a[i]];
		}
		deg[0]=0;
		rep(i,1,n+1){
			if(!deg[i]&&!mark[i]){
				int x=i,c=0;
				while(x){
					c^=1;
					mark[x]=1;
					x=a[x];
					--deg[x];
				}
				++sz[c];
			}
		}
		rep(i,1,n+1)if(deg[i]){
			int c=0,x=i;
			while(!mark[x]){
				c^=1;mark[x]=1;
				x=a[x];
			}
			if(c&1){ptn(0);return ;}
		}
		ifac[n]=Pow(fac[n],mod-2);
		per(i,1,n+1)ifac[i-1]=(ll)ifac[i]*i%mod;
		
		int ans=KONG(sz[1]),res=0,now=sz[1],nowmul=1;
		rep(i,0,sz[0]+1){
			res=(res+(ll)nowmul*fac[sz[0]]%mod*ifac[i]%mod)%mod;
			nowmul=(ll)nowmul*now%mod;
			now++;
		}
		ans=(ll)ans*res%mod;
		ptn(ans);
	}
}P2;
bool vis[N];
int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int sum=0;
	rd(n);
	rep(i,1,n+1){
		rd(a[i]),sum|=a[i];
		if(a[i]&&vis[a[i]])n=1;
		vis[a[i]]=1;
	}
	if(n&1)ptn(0);
	else if(n<=8)P0.work();
	else if(!sum)P1.work();
	else P2.work();
	return 0;
}
