#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

typedef long long LL;
int n, m, k; LL ans;
const int P = 998244353;

int main() {
	freopen("segment.in", "r", stdin); freopen("segment.out", "w", stdout);
	scanf("%d %d %d", &m, &n, &k);
	if(m > n) {puts("0"); return 0;}
	if(m == 1) ans = (LL)n * (n-1) / 2 % P;
	printf("%lld\n", ans);
	return 0;
}
