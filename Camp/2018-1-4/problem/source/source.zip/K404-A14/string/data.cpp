#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<ctime>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;

int ran(int x){
	int i,ret=0;
	rep(i,1,3)	ret=(1ll*ret*20010102+rand())%x;
	return ret;
}

int main(){
	freopen("string.in","w",stdout);
	srand(time(0));
	int n,m,i,j,x;
	m=500;n=6;
	printf("%d %d\n",n,m);
	rep(i,1,n){
		x=ran(100)+1;
		rep(j,1,x)	printf("%d",ran(2));
		printf("\n");
	}
}
