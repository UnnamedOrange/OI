#include <bits/stdc++.h>

#define cerr_clock() std::cerr << 1.0 * clock()/CLOCKS_PER_SEC << std::endl;
#define fst first
#define snd second

typedef long long LL;
typedef std::pair<int, int> Pii;

#ifdef __linux__
#define getchar getchar_unlocked
#endif
template <typename T> inline bool maximum(T &a, T b) { return a < b? a = b, 1 : 0; }
template <typename T> inline bool minimum(T &a, T b) { return a > b? a = b, 1 : 0; }
template <typename T>
T read(T &x, T f = 0)
{
	char c = getchar(); x = 0;
	for(; !isdigit(c); c = getchar())
		f |= c == '-';
	for(;  isdigit(c); c = getchar())
		x = x*10 + c-'0';
	return x = f? -x : x;
}

const int mod = 1e9 + 7;

int fpm(int x, int e)
{
	int res = 1;
	for(; e; e >>= 1){
		if(e & 1) res = (LL)res * x % mod;
		x = (LL)x * x % mod;
	}
	return res;
}

void add(int &a, int b)
{
	a += b;
	if(a >= mod) a -= mod;
}

LL n, m, s, t;

namespace On_dp
{
	int dp[10010][10010];

	void main()
	{
		dp[0][0] = 1;
		for(int i = 1; i <= n; ++i){
/*			for(int j = i; j <= t*i; ++j){
				int k = std::min((LL)j, t);
				dp[i][j] = (sum[i-1][j-1]-sum[i-1][j-k] + dp[i-1][j-k]) % mod;
				}
				for(int j = 0; j <= s; ++j)
				sum[i][j] = (sum[i][j-1] + dp[i][j]) % mod;
 */
			for(int j = i; j <= t*i; ++j)
				for(int k = 1; k <= std::min((LL)j, t); ++k)
					add(dp[i][j], dp[i-1][j-k]);
		}
//		for(int i = n; i <= s; ++i){
//			printf("dp[%lld][%d] = %d\n", n, i, dp[n][i]);
//		}

		int Ans = 0;
		if(m > n){
			for(int i = m; i <= s; ++i){
				for(int j = n; j <= n * t; ++j){ 
					if(i-j < m-n) continue;
					add(Ans, (LL)dp[n][j] * fpm(m-n, i-j-(m-n)) % mod);
				}
			}
		}
		else{
			for(int tot = m; tot <= s; ++tot)
				add(Ans, dp[n][tot]);
		}

		printf("%d\n", Ans);
	}
}

int main()
{
	freopen("success.in", "r", stdin);
	freopen("success.out", "w", stdout);

	read(s), read(t), read(n), read(m);
	On_dp::main();

	return 0;
}
