#include<bits/stdc++.h>
using namespace std;
int a[1001];
int stk[1001],top;
int n;
int A,B;
bool Dfs(int p){
	int v=p?B:A;
//	bool bo=(top==2&&stk[1]==3&&stk[2]==4&&p==0);
	for(int i=1;i<=top;i++){
		if(stk[i]>=v){
			stk[i]-=v;
			if(!Dfs(p^1)){
//				if(bo) printf("")
				stk[i]+=v;
				return 1;
			}
			stk[i]+=v;
		}
	}
	return 0;
}
int ansA,ansB,ans0,ans2;
void solve(){
	int AA,BB;
	AA=Dfs(0);
	BB=Dfs(1);
	if(AA&&BB){
		ans2++;
	}
	if(AA&&!BB)ansA++;
	if(!AA&&BB) ansB++;
	if(!AA&&!BB) ans0++;
}
void dfs(int p){
	if(p>n){
		solve();
		return;
	}
	stk[++top]=a[p];
	dfs(p+1);
	top--;
	dfs(p+1);
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("baoli.out","w",stdout);
	scanf("%d%d%d",&n,&A,&B);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	dfs(1);
	printf("%d %d %d %d\n",ansA,ansB,ans2,ans0);
	return 0;
}
