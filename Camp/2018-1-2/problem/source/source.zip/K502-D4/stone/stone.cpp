#include<iostream>
#include<cstdio>

using namespace std;

int a,b,n;
long long mo=1e9+7;
int x[100005];
long long f[100005][4];
bool faned;

long long ksm(long long base,long long loc)
{
	if(loc==1)
		return base;
	else
	{
		long long ks=ksm(base,loc/2);
		if(loc%2==0)
			return (ks*ks)%mo;
		else
			return(((ks*ks)%mo)*base)%mo;
	}
}

int get(long long num)
{
	long long tem=num%(a+b);
	if(tem<a) return 2;
	if(tem>=2*a) return 3;
	if(tem>=b) return 1;
	return 0;
}

int main()
{
//	freopen("stone.in","r",stdin);
//	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	for(int i=1;i<=n;i++)
		scanf("%d",&x[i]);
	if(a>b)
	{
		faned=1;
		int tem=a;
		a=b;
		b=tem;
	}
	if(a==b)
	{
		int nj=0;
		int no=0;
		for(int i=1;i<=n;i++)
		{
			x[i]/=a;
			if(x[i]%2==0)
				no++;
			else
				nj++;
		}
		if(nj==0)
			printf("0 0 0 %lld\n",ksm(2,n));
		else
			printf("0 0 %lld %lld\n",ksm(2,n-1),ksm(2,n-1));
		return 0;
	}
	f[1][0]=0;
	f[1][1]=0;
	f[1][3]=0;
	f[1][2]=1;
	f[1][get(x[1])]++;
	for(int i=2;i<=n;i++)
	{
		f[i][0]=f[i-1][0];
		f[i][1]=f[i-1][1];
		f[i][2]=f[i-1][2];
		f[i][3]=f[i-1][3];
		if(get(x[i])==0)
			f[i][0]=(f[i][0]+f[i-1][0]+f[i-1][1]+f[i-1][2]+f[i-1][3])%mo;
		else if(get(x[i])==1)
		{
			f[i][2]=(f[i][2]+f[i-1][1])%mo;
			f[i][0]=(f[i][0]+f[i-1][0]+f[i-1][3])%mo;
			f[i][1]=(f[i][1]+f[i-1][2])%mo;
		}
		else if(get(x[i])==2)
		{
			f[i][0]=(f[i][0]+f[i-1][0])%mo;
			f[i][1]=(f[i][1]+f[i-1][1])%mo;
			f[i][2]=(f[i][2]+f[i-1][2])%mo;
			f[i][3]=(f[i][3]+f[i-1][3])%mo;
		}
		else
		{
			f[i][0]=(f[i][0]+f[i-1][0]+f[i-1][1]+f[i-1][3])%mo;
			f[i][3]=(f[i][3]+f[i-1][2])%mo;
		}
	}
	if(faned)
		printf("0 %lld %lld %lld\n",f[n][0],f[n][1]+f[n][3],f[n][2]);
	else
		printf("%lld 0 %lld %lld\n",f[n][0],f[n][1]+f[n][3],f[n][2]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
