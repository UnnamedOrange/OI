#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)1e6+5;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
int n,a[M];
int fr[M],nx[M];
int id[M];
bool cmp(int x,int y){
	return a[x]<a[y];
}
long long bin[64];
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	for(int i=0;i<64;i++)bin[i]=(1LL<<i);
	Rd(n);
	for(int i=1;i<=n;i++)Rd(a[i]),id[i]=i,fr[i]=i-1,nx[i]=i+1;
	sort(id+1,id+n+1,cmp);
	double ans=0;
	int UP,UPP;
	if(n<=50000)UP=50;
	else UP=27;
	UPP=UP-1;
	for(int i=1,x,ls,rs,y,v;i<=n;i++){
		static int l[55],r[55];
		x=id[i],v=a[x],ls=0,rs=0;
		for(l[ls++]=y=x;y>=1&&ls<=UP;l[ls++]=(y=fr[y]));
		for(r[rs++]=y=x;y<=n&&rs<=UP;r[rs++]=(y=nx[y]));
		ls--,rs--,rs--;
		for(int j=0;j<ls;j++)
			for(int k=0,up=min(rs,UPP-j);k<=up;k++)
				ans+=(double)v*(l[j]-l[j+1])*(r[k+1]-r[k])/bin[j+k+1];
		nx[fr[nx[x]]=fr[x]]=nx[x];
	}
	printf("%.15f\n",ans/n/n);
	return 0;
}
