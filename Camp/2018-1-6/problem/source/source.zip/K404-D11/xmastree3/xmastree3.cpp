#include<cstdio>
using namespace std;
int main()
{
	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);
	printf("12"); 
	return 0;
}
