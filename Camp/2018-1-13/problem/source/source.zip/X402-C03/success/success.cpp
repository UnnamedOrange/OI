#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int mod=1e9+7;
ll s,t,n,m,ans,dp[1000][10000];

ll dfs(ll pos,ll rest){
	if(~dp[pos][rest])
		return dp[pos][rest];
	if(pos>m)
		return dp[pos][rest]=1;
	ll res=0;
	if(pos<=n)
		for(ll i=1;i<=t&&rest>=i;++i)
			res+=dfs(pos+1,rest-i);
	else
		for(ll i=1;i<=rest;++i)
			res+=dfs(pos+1,rest-i);
	return dp[pos][rest]=res%mod;
}

int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	memset(dp,-1,sizeof(dp));
	scanf("%lld%lld%lld%lld",&s,&t,&n,&m);
	ans=dfs(1,s);
	printf("%lld\n",ans%mod);
	return 0;
}
