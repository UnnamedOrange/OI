#include<cstdio>
using namespace std;
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	printf("1.238750000000000");
	return 0;
}
