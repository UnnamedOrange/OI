#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int const mod=998244353;
int n,m;
long long qian[11],ans,p;
long long t[11];

long long quick(long long x,long long c)
{
	if(c==1) return x;
	if(c%2==0)  return quick((x*x)%mod,c>>1)%mod;
	else if(c%2==1) return quick((x*x)%mod,c>>1)*x%mod;
}

void dfs(int l,int r,int k)
{
	if(k==n)
	{
		memset(t,0,sizeof(t));
		for(int i=1;i<=m;i++)
		  t[i]=t[i-1]+qian[i];
//		for(int i=1;i<=m;i++)
//		  cout<<t[i]<<" ";
//		cout<<endl;
		for(int i=1;i<=m;i++)
		  ans=(ans+quick(t[i],p))%mod;
	}
	for(int i=l;i<=m;i++)
	  for(int j=max(i,r);j<=m;j++)
	  {
	  	qian[i]++;qian[j]--;
	  	dfs(i+1,j+1,k+1);
	  	qian[i]--;qian[j]++;
	  }
}

int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&p);
	if(n>m)
	{
		cout<<0;
		return 0;
	}
	dfs(1,1,0);
	cout<<ans;
}
