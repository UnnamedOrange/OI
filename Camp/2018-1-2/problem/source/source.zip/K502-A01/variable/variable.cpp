#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define LL long long
using namespace std;
const LL Maxn = 30;
struct node
{
	LL x, y, z, a, b, c, d, e, f;
}A[Maxn];
struct node1
{
	LL x, y, r;
}B[Maxn];
LL N, W, P, Q, Ans;
LL Que[Maxn];
inline void Check()
{
	for (LL i = 1; i <= Q; ++i)
	{
		if (B[i].r == 0 && Que[B[i].x] > Que[B[i].y])return ;
		if (B[i].r == 1 && Que[B[i].x] != Que[B[i].y])return ;
		if (B[i].r == 2 && Que[B[i].x] >= Que[B[i].y])return ;
	}
	LL Sum = 0;
	for (LL i = 1; i <= N; ++i)
		Sum += Que[i];
	for (LL i = 1; i <= P; ++i)
	{
		Sum += A[i].a * (abs(Que[A[i].x] - Que[A[i].y])) +  A[i].b * (abs(Que[A[i].z] - Que[A[i].y])) + A[i].c * (abs(Que[A[i].z] - Que[A[i].x]));
		Sum += A[i].d * ((Que[A[i].x] - Que[A[i].y])) +  A[i].e * ((Que[A[i].y] - Que[A[i].z])) + A[i].f * ((Que[A[i].z] - Que[A[i].x]));
	}
	Ans = min(Ans, Sum);
}
inline void dfs(LL x)
{
	if (x == N)
	{
		Check();
		return ;
	}
	Que[++x] = W;
	dfs(x);
	Que[x] = -W;
	dfs(x);
}
int main()
{
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	LL T;
	scanf("%lld", &T);
	while (T--)
	{
		scanf("%lld%lld%lld%lld", &N, &W, &P, &Q);
		Ans = 0x3f3f3f3f;
		for (LL i = 1; i <= P; ++i)
			scanf("%lld%lld%lld%lld%lld%lld%lld%lld%lld", &A[i].x, &A[i].y, &A[i].z, &A[i].a, &A[i].b, &A[i].c, &A[i].d, &A[i].e, &A[i].f);
		for (LL i = 1; i <= Q; ++i)
			scanf("%lld%lld%lld", &B[i].x, &B[i].y, &B[i].r);
		dfs(0);
		cout<<Ans<<endl;
	}
	return 0;
}
