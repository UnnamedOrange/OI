#include <bits/stdc++.h>
using namespace std;
int code[1005][1005];
int n,num;
inline bool check(){
	for(int i=1;i<=n;++i){
		bool x[10];
		memset(x,0,sizeof(x));
		for(int j=1;j<=n;++j){
			if(code[i][j]==0)continue;
			x[code[i][j]]=1;
		}
		for(int j=1;j<=n;++j){
			if(code[i][j]==0)continue;
			if(x[code[j][i]])return false;
		}
	}
	return true;
}
inline void dfs(int x,int y,bool &f){
	if(f)return;
	if(!check())return;
	//cout<<x<<" "<<y<<endl;
	if(y>n){
		if(check()){
			for(int i=1;i<=n;++i){
				for(int j=1;j<=n;++j){
					cout<<code[i][j]<<" ";
				}
				cout<<endl;
			}
			f=1;
		}
		return;
	}
	if(x==y){
		dfs(x,y+1,f);
		return;
	}
	for(int i=1;i<=num;++i){
		code[x][y]=i;
		if(y==n)dfs(x+1,1,f);
		else dfs(x,y+1,f);
		code[x][y]=0;
	}
}
int main(){
	freopen("2.txt","w",stdout);
	cin>>n>>num;
	bool f=0;
	dfs(1,1,f);
	return 0;
}
