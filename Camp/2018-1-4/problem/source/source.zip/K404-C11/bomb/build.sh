#!/bin/bash
'/c/Program Files/Dev-Cpp/MinGW64/bin/g++' -g bomb.cpp -o bomb -DDBG -Wall -Wextra -m32
