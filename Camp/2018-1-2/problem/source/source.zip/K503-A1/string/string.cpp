#include<bits/stdc++.h>
using namespace std;
int T,n,a[2560];
char s[200000],ch[200000];
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	while (T--){
		scanf("%d %s",&n,s+1);
		int fl=1,flag=1;
		for (int i=2;i<=n;i++) if (s[i]!=s[i-1]) {fl=0;break;}
		for (int i=3;i<=n;i++) if (s[i]!=s[i-2]) {flag=0;break;}
		if (fl||flag) {puts("-1");continue;}
		int t=2;
		for (int i=1;i<=n;i++)
		if (s[i]!=s[n-i+1]) {t--;break;}
		if (t==1) printf("1\n");
		else{
			memset(a,0,sizeof(a));
			for (int i=1;i<=n;i++) a[s[i]]++;
			int m=0;
			for (int i=1;i<=n;i++) m=max(m,a[s[i]]);
			if (n-m>1) puts("2");
			else puts("-1");
		}
	}
	return 0;
}
