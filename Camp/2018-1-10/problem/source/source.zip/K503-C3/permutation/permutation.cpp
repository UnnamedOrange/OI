#include <bits/stdc++.h>
#define N 20
#define ll long long
#define P 998244353
using namespace std;
int n,a[N],b[N],used[N];
ll ans(0);

inline bool check(int l,int x){
	int i,len=1;
	for (i=x;i<l;i=a[i],len++);
	if (i==l && len&1)
		return 0;
	return 1;
}

void search(int dep){
	if (dep>n){
		ans++; return;
	}
	if (b[dep]){
		if (!check(dep,b[dep]))
			return;
		a[dep]=b[dep],search(dep+1);
	}
	for (int i=1;i<=n;i++)
		if (!used[i] && i!=dep && check(dep,i)){
			used[i]=1; a[dep]=i;
			search(dep+1);
			used[i]=0;
		}
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
		scanf("%d",&b[i]),used[b[i]]=1;
	if (n&1){
		puts("0");
		return 0;
	}
	if (n<=10)
		search(1);
	else{
		ans=1;
		for (int i=1;i<n/2;i++)
			ans=ans*(ll)(i*2+1)%P;
		ans=ans*ans%P;
	}
	printf("%lld\n",ans);
	return 0;
}
