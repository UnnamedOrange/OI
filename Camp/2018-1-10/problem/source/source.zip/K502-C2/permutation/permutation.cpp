#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long

using namespace std;

inline void Rd(int &res) {
	char c; res = 0;
	while (c = getchar(), c < '0');
	do {
		res = (res << 1) + (res << 3) + (c ^ 48);
	} while (c = getchar(), c >= '0');
}

const int M = (int) 1e5 + 5;
const int P = 998244353;

int n, Per[M];

namespace Subtask1 {
	
	bool mark[M];
	int Pr[M], ans;
	
	void solve() {
		for (int i = 1; i <= n; i++) Pr[i] = i;
		do {
			bool flag = true;
			for (int i = 1; i <= n; i++)
				if (Per[i] && Pr[i] != Per[i]) flag = false;
			if (!flag) continue;
			for (int i = 1; i <= n; i++) mark[i] = false;
			for (int i = 1; i <= n; i++) {
				if (mark[i]) continue;
				int sz = 0, x = i;
				while (!mark[x]) {
					mark[x] = true;
					x = Pr[x]; sz++;
				}
				if (sz & 1) flag = false;
			}
			ans += flag;
		} while (next_permutation(Pr + 1, Pr + n + 1));
		printf("%d\n", ans);
	}
	
}

int main() {
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	Rd(n);
	for (int i = 1; i <= n; i++) Rd(Per[i]);
	if (n <= 8) Subtask1::solve();
	else if (n & 1) puts("0");
	else {
		int ans = 1;
		for (int i = 2; i <= n; i += 2)
			ans = (ll) ans * (i - 1) % P;
		ans = (ll) ans * ans % P;
		printf("%d\n", ans);
	}
	return 0;
}
/*
2 0 0                    |  1
4 0 0 0 0                |  9
6 0 0 0 0 0 0            | 225
8 0 0 0 0 0 0 0 0        |11025
10 0 0 0 0 0 0 0 0 0 0   |893025


6
2 0 4 0 0 0





*/
