#include <bits/stdc++.h>

typedef long long int int64;
static const int64 mod = 998244353LL;
int64 power(int64 a,int64 b) {
	int64 v = 1;
	for(int i = 60;i >= 0;--i) {
		v = (v * v) % mod;
		if((b & (1LL << i)) != 0)
			v = (v * a) % mod;
	}
	return v;
}
int64 f[100003],g[100003];
int64 inv[100003],fac[100003],invfac[100003];
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	int64 n,k;
	scanf("%lld%lld",&n,&k);
	inv[1] = fac[0] = invfac[0] = fac[1] = invfac[1] = 1;
	for(int i = 2;i <= 100000;++i) {
		inv[i] = (mod - inv[mod % i]) * (mod / i) % mod;
		fac[i] = (fac[i - 1] * i) % mod;
		invfac[i] = (invfac[i - 1] * inv[i]) % mod;
	}
	if(k == 3) {
		int64 fac = 1;
		for(int i = 1;i <= n;++i) fac = (fac * i) % mod;
		int64 ans = power(2,n*(n-1)/2) - fac;
		if(ans < 0) ans += mod;
		printf("%lld\n",ans);
	} else {
		f[1] = 1;
		for(int i = 2;i <= n;++i) {
			int64 v = power(2,i*(i-1)/2);
			for(int j = 1;j <= i - 1;++j) {
				int64 x = fac[i] * invfac[j] % mod * invfac[i - j] % mod * f[j] % mod * power(2,(i-j)*(i-j-1)/2) % mod;
				v = (v - x) % mod;
			}
			f[i] = v;
		}
		g[1] = g[2] = 0;
		for(int i = 3;i <= n;++i) {
			int64 v = 0;
			for(int j = 1;j < k;++j) {
				v = (v + g[i-j] * fac[i] % mod * invfac[j] % mod * invfac[i-j] % mod * f[j]) % mod;
			}
			for(int j = k;j <= i;++j) {
				v = (v + power(2,(i-j)*(i-j-1)/2) * fac[i] % mod * invfac[j] % mod * invfac[i-j] % mod * f[j]) % mod;
			}
			g[i] = v;
		}
		int64 ans = g[n];
		if(ans < 0) ans += mod;
		printf("%lld\n",ans);
	}
}
