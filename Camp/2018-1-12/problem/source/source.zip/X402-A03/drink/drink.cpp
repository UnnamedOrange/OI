/*****************************************************
	File:drink.cpp
	Author:huhao
	Email:826538400@qq.com
	Created time:2018-1-12 08:46:18
*****************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define N 1000010
int n,w[N],a[N];
long double ans;
int main()
{
	freopen("drink.out","w",stdout);
	freopen("drink.in","r",stdin);
	n=read();
	fr(i,1,n)
		w[i]=read();
	fr(i,1,n)
		fr(j,i,n)
		{
			a[j]=w[j];
			sort(a+i,a+j+1);
			long double k=1;
			fd(o,j,i)
			{
				k=k*0.5;
				ans=ans+k*a[o];
			}
		}
	printf("%.15Lf\n",ans/n/n);
	return 0;
}