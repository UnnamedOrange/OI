#include<bits/stdc++.h>
using namespace std;
int lim;
int a[55][55];
bool dfs(int dep,int las,int siz){
	while(a[dep][siz]==siz)
		--siz;
	if(dep+siz>lim)
		return false;
	if(!siz)
		return true;
	for(int i=2;i<=siz;i++){
		if(i!=las){
			for(int j=1;j<=i;j++)
				a[dep+1][j]=a[dep][i-j+1];
			for(int j=i+1;j<=siz;j++)
				a[dep+1][j]=a[dep][j];
			if(dfs(dep+1,i,siz))
				return true;
		}
	}
	return false;
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	std::ios::sync_with_stdio(false);
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		for(int i=1;i<=n;i++)
			cin>>a[0][i];
		a[0][0]=233;
		for(lim=1;lim<=2*n;lim++){
			a[lim][0]=233;
			if(dfs(0,0,n))
				break;
		}
		cout<<lim-1<<endl;
	}
	return 0;
}
