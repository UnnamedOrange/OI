//2018-1-6
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000+5)

struct node{
	int ls, rs, v;
	int id, fr;
};

int ql, qr;

#define lc h[o].ls
#define rc h[o].rs
#define mid ((L+R)>>1)

namespace Seg_tree{
	int hn, root[N];
	node h[N*50];
	
	void Modify(int &o, int L, int R, int p, int ID){
		h[++hn] = h[o]; o = hn;

		if(L == R){
			if(h[o].id != ID) h[o].id = ID, h[o].fr += h[o].v;
			h[o].v = 1;
			return;
		}

		if(p <= mid) Modify(lc, L, mid, p, ID);
		else Modify(rc, mid+1, R, p, ID);
		
		if(h[o].id != ID) h[o].id = ID;
		h[o].fr = h[lc].fr + h[rc].fr;
		h[o].v = max(h[lc].v, h[rc].v);
	}

	int Query(int o1, int o2, int L, int R){
		if(!o1 && !o2) return 0;
		if(ql <= L && qr >= R) return h[o2].fr+h[o2].v-h[o1].fr-h[o1].v;
		
		int ret = 0;
		if(ql <= mid) ret += Query(h[o1].ls, h[o2].ls, L, mid);
		if(qr > mid) ret += Query(h[o1].rs, h[o2].rs, mid+1, R);
		return ret;
	}
};

#undef lc
#undef rc
#undef mid

using namespace Seg_tree;

int dfn, col[N], id[N], in[N], out[N], fa[N];
vector<int> G[N], mpo[N];

void Dfs(int now, int F){
	id[now] = in[now] = ++dfn; fa[now] = F;
	mpo[col[now]].pb(id[now]);

	For(i, 0, G[now].size()-1)
		if(G[now][i] != F) Dfs(G[now][i], now);
	out[now] = dfn;
}

int n, ans;
bool vis[N];

void Dfs2(int now){
	vis[col[now]] = true;
	For(i, 0, G[now].size()-1)
		if(G[now][i] != fa[now]) Dfs2(G[now][i]);
}

void Query1(int u, int L, int R){
	For(i, L, R) vis[i] = false;
	Dfs2(u);
	
	ans = 0;
	For(i, L, R) ans += vis[i];
	printf("%d\n", ans);
}

void Querytree(int u, int L, int R){
	ql = in[u], qr = out[u];
//	printf("ql = %d qr = %d\n", ql, qr);
	printf("%d\n", ans = Query(root[L-1], root[R], 1, n));
}

int main(){
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	
	int q, t, u, v;
	
	scanf("%d%d%d", &n, &q, &t);
	For(i, 1, n) scanf("%d", &col[i]);

	For(i, 1, n-1){
		scanf("%d%d", &u, &v);
		G[u].pb(v); G[v].pb(u);
	}

	Dfs(1, 0);

	int lst = 0;
	For(i, 1, n)
		For(j, 0, mpo[i].size()-1){
			Modify(root[i]=lst, 1, n, mpo[i][j], i);
			lst = root[i];
		}

	int op, l, r, uc;
	bool flag = true;

	while(q--){
		scanf("%d", &op);

		if(op == 1){
			scanf("%d%d%d", &u, &l, &r);
			if(t) u^=ans, l^=ans, r^=ans;
			
			if(!flag) Query1(u, l, r);
			else Querytree(u, l, r);
		}else{
			flag = false;
			scanf("%d%d", &u, &uc);
			if(t) u^=ans, uc^=ans;
			col[u] = uc;
		}
	}

	return 0;
}
