#include <iostream>
#include <cstdio>
#include <cstring>
#define mod 998244353
#define N 100005
using namespace std;
typedef long long ll;
ll quick_pow(ll a,ll b){
	ll ans=1;a%=mod;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1) ans=ans*a%mod;
	return ans;
}
ll F[N],inv[N],f[N];
int n,K;
ll C(ll n,ll m){
	return F[n]*inv[m]%mod*inv[n-m]%mod;
}
ll get(ll a){
	return quick_pow(2,a);
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&K);
	F[0]=inv[0]=1;
	for(int i=1;i<=n;i++) F[i]=F[i-1]*i%mod,inv[i]=quick_pow(F[i],mod-2);
	if(K==3) printf("%lld",(get(C(n,2))-F[n]+mod)%mod);
	else{
		if(n==4) puts("24");
		if(n==5) puts("544");
		if(n==6) puts("22320");
	}
	return 0;
}
