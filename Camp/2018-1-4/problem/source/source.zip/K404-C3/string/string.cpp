#include <cmath>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define N 110
#define ll long long
#define mod 998244353
using namespace std;
inline int read() 
{ 
    int x=0,f=1;char ch=getchar(); 
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();} 
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();} 
    return x*f; 
}
int n,m;
char s[7][N];
namespace subtask1
{
	int ans=0;
	char a[16];
	void dfs(int x)
	{
		if(x==m+1)
		{
			for(int i=m+1;i<=2*m;i++)
			if(a[2*m-i+1]=='0')a[i]='1';
			else a[i]='0';
			char *p;
			for(int i=1;i<=n;i++)
			{
				p=strstr(a+1,s[i]+1);
				if(!p)return ;
			}
			ans++;
			return ;
		}
		a[x]='0';
		dfs(x+1);
		a[x]='1';
		dfs(x+1);
	}
	void main()
	{
		dfs(1);
		printf("%d\n",ans);
	}
}
namespace subtask2
{
	ll quickmod(ll a,ll b)
	{
		ll ret=1;
		while(b)
		{
			if(b&1)ret=ret*a%mod;
			a=a*a%mod,b>>=1;
		}
		return ret;
	}
	ll ans;
	int main()
	{/*
		int len=strlen(s[1]+1);
		for(int i=1;i<=m;i++)
		{
			if(i+len-1<=m)ans+=quickmod(2,m-len),ans%=mod;
			else
			{
				bool ok=1;
				for(int j=i+len-1;j>m;j--)
				{
					if(s[1][i+j-1]!=s[1][i+2*m-j-1])
					{
						ok=0;
						break ;
					}
				}
				if(ok)
				{
					ans+=quickmod(2,i-1);
					ans%=mod;
				}
			}
		}*/
		ans=quickmod(2,m);
		printf("%lld\n",ans);
	}
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++)
	scanf("%s",s[i]+1);
	if(m<=15)subtask1::main();
	else if(n==1)subtask2::main();
	
}