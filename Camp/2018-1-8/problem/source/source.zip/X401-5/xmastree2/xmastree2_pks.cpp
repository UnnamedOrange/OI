#include<bits/stdc++.h>
#define int long long
using namespace std;
struct node1{
	int r,next;}side[70000];
struct node{
	long long v,num,zong,fa;}bee[50000];
int sidetot,fa[50000],n,weizhi[50000],dui[50000],tot,now[50000],w[50000],r[50000];
long long ans;
double js(int i){
	return bee[i].v*1.0/bee[i].num;}
void add(int i,int j){
	sidetot++;
	side[sidetot].r=j;
	side[sidetot].next=now[i];
	now[i]=sidetot;
}
void dfs(int i){
	for (int p=now[i];(p);p=side[p].next)
	if (fa[side[p].r]==0)
	{
		fa[side[p].r]=i;
		dfs(side[p].r);
	}
}
int getfa(int i){
	if (bee[i].fa==i) return i;
	bee[i].fa=getfa(bee[i].fa);
	return bee[i].fa;
}
void insert(int i){
	tot++;
	dui[tot]=i;
	int j=tot;
	while ((j>1)&&(js(dui[j])<js(dui[j>>1])))
	{
		swap(weizhi[dui[j]],weizhi[dui[j>>1]]);
		swap(dui[j],dui[j>>1]);
		j=j>>1;
	}
}
void tiao(int i){
	int j=i;
	while ((j>1)&&(js(dui[j])<js(dui[j>>1])))
	{
		swap(weizhi[dui[j]],weizhi[dui[j>>1]]);
		swap(dui[j],dui[j>>1]);
		j=j>>1;
	}
	j=i;
	int k;
	while ((j*2)<=tot)
	{
		if ((j*2==tot)||(js(dui[j<<1])<js(dui[j*2+1])))
			k=0; else k=1;
		if (js(dui[j])>js(dui[j*2+k]))
		{
			swap(weizhi[dui[j]],weizhi[dui[j*2+k]]);
			swap(dui[j],dui[j*2+k]);
			j=j*2+k;
		}
		else break;
	}
}
signed main(){
	scanf("%lld",&n);
	for (int i=1;i<n;i++)
	{
		int x,y;
		scanf("%lld%lld",&x,&y);
		add(x,y);
		add(y,x);
	}
	for (int i=1;i<=n;i++)
		scanf("%lld%lld",&w[i],&r[i]);
	for (int i=1;i<=n;i++)
	if (r[i])
	{
		for(int j=1; j<=n; ++j)
		{
			fa[j]=0;
		}
		fa[i]=i;
		dfs(i);
		for (int j=1;j<=n;j++)
		if (i!=j)
		{
			weizhi[j]=tot+1;
		    bee[j].num=1;
		   	bee[j].v=w[j];
		   	bee[j].zong=w[j];
			bee[j].fa=j;
			insert(j);
		}else
		{
			bee[j].num=1;
		   	bee[j].v=w[j];
		   	bee[j].zong=w[j];
			bee[j].fa=j;
		}
		for (int j=1;j<n;j++)
		{
			int k=dui[1];
			getfa(k);
			getfa(fa[k]);
			bee[bee[fa[k]].fa].zong+=bee[bee[k].fa].zong+bee[bee[k].fa].v*bee[bee[fa[k]].fa].num;
			bee[bee[fa[k]].fa].v+=bee[bee[k].fa].v;
			bee[bee[fa[k]].fa].num+=bee[bee[k].fa].num;
			bee[bee[k].fa].fa=bee[fa[k]].fa;
			if (bee[fa[k]].fa!=i)
			{
				weizhi[dui[tot]]=1;
				dui[1]=dui[tot];
				tot--;
				tiao(1);
				tiao(weizhi[k]);
			}
			else 
			{
				dui[1]=dui[tot];
				tot--;
				tiao(1);
			}
		}
		ans=max(ans,bee[i].zong);
	}
	cout<<ans<<endl;
}

