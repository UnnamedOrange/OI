#include<bits/stdc++.h>
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		c=='-'?p=-1:0;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
const long long BIG = 1000000000000000;
#define LEN 10005
int n,w,p,q;
long long ai[LEN],x[LEN],y[LEN],z[LEN],a[LEN],b[LEN],c[LEN]
		  ,d[LEN],e[LEN],f[LEN],x2[LEN],y2[LEN],r[LEN];
int wi[LEN];
long long ans=0x3f3f3f3f3f;
inline void serch(int cur){
	if(cur==n+1){
		for(int i=1;i<=q;++i){
			int x=x2[i],y=y2[i];
			if(r[i]){
				if(r[i]==1){
					if(wi[x]!=wi[y])return;
				}
				else{
					if(wi[x]>=wi[y])return;
				}
			}
			else{
				if(wi[x]>wi[y])return;
			}
		}
		long long cur=0;
		for(int i=1;i<=n;++i){
			cur+=wi[i];
		}
		for(int i=1;i<=p;++i){
			int x1=wi[x[i]],x2=wi[y[i]],x3=wi[z[i]];
			int a1=x1-x2,b1=x2-x3,c1=x3-x1;
			cur+=a[i]*abs(a1)+b[i]*abs(b1)+c[i]*abs(c1);
			cur+=d[i]*a1+e[i]*b1+f[i]*c1;
		}
		ans=min(cur,ans);
		return;
	}
	wi[cur]=w;
	serch(cur+1);
	wi[cur]=-w;
	serch(cur+1);
}
inline void work(){
	n=getint(),w=getint(),p=getint(),q=getint();
	int s=0,t=2*n+1;
	for(int i=1;i<=p;++i){
		x[i]=getint(),y[i]=getint(),z[i]=getint(),
		a[i]=getint(),b[i]=getint(),c[i]=getint(),
		d[i]=getint(),e[i]=getint(),f[i]=getint();
	}
	for(int i=1;i<=q;++i){
		x2[i]=getint(),y2[i]=getint(),r[i]=getint();
	}
	ans=0x3f3f3f3f3f;
	serch(1);
	cout<<ans<<endl;
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int t=getint();
	while(t--){
		work();
	}
	return 0;
}
