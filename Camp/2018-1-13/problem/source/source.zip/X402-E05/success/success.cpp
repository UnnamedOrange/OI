#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define pb push_back
#define pii pair<int,int>
#define SZ(x) (int)x.size()
#ifdef __linux__
#define getchar getchar_unlocked
#endif
#define mem(a,b) memset(a,b,sizeof(a))
#define  For(i,a,b) for(int i=a,i##E=b;i<=i##E;++i)
#define rFor(i,a,b) for(int i=a,i##E=b;i>=i##E;--i)
typedef long long LL;
using namespace std;
const int N=1000010;
const int inf=0x3f3f3f3f;
const LL mod=1e9+7;
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
template<typename T>inline void read(T &x)
{
	x=0;int _f(0);char ch=getchar();
	while(!isdigit(ch))_f|=(ch=='-'),ch=getchar();
	while( isdigit(ch))x=x*10+ch-'0',ch=getchar();
	x=_f?-x:x;
}
inline void file()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
}
LL s,t,n,m,ans;
LL fac[N],ifac[N];
inline void Add(LL &x,LL y){x=x+y<mod?x+y:x+y-mod;}
inline LL qpow(LL a,LL b)
{
	LL ret=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)ret=ret*a%mod;
	return ret;
}
inline void init(int n)
{
	fac[0]=ifac[0]=1;
	For(i,1,n)fac[i]=fac[i-1]*i%mod;
	ifac[n]=qpow(fac[n],mod-2);
	rFor(i,n,2)ifac[i-1]=ifac[i]*i%mod;
}
inline LL C(LL n,LL k)
{
	if(n<k)return 0;
	return fac[n]*ifac[k]%mod*ifac[n-k]%mod;
}
int main()
{
	file();
	read(s),read(t),read(n),read(m);
	init(s+1);
	s-=m;
	For(i,0,n)
	{
		LL ret=C(m+s-i*t,s-i*t);
		//For(j,0,s-i*t)Add(ret,C(m-1+j,j));
		//printf("%d %lld %lld\n",i,ret,C(m+s-i*t,s-i*t));
		if(i&1)
			Add(ans,mod-C(n,i)*ret%mod);
		else 
			Add(ans,C(n,i)*ret%mod);
	}
	printf("%lld\n%lld\n",ans,C(m+s,s)-C(m+s-t,s-t));
	return 0;
}
