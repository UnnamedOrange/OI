#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=1000005;
const LL inf=1ll<<45;
LL c[N],d[N];
bool v[1005][1005];
LL dd[N],f[N];
LL tma,tmi;
LL mod=1e9+7;
int n;
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%lld%lld",&c[i],&d[i]);
	for(int i=1;i<=n;i++){
		tmi=inf;
		tma=0;
		for(int j=i;j<=n;j++){
			tma=max(tma,c[j]);
			tmi=min(tmi,d[j]);
			v[i][j]=(j-i+1<=tmi&&j-i+1>=tma)?1:0;
		}
	}
	dd[0]=1;
	for(int i=1;i<=n;i++)
	    for(int j=0;j<i;j++)
	        if(v[j+1][i])
	        	if(f[j]+1==f[i])
					dd[i]=(dd[i]+dd[j])%mod;
	        	else if(f[j]+1>f[i]){
	        		f[i]=f[j]+1;
	        		dd[i]=dd[j];
	        	}
	if(dd[n]!=0)
		printf("%lld %lld\n",f[n],dd[n]);
	else
		printf("-1\n");
	return 0;
}
