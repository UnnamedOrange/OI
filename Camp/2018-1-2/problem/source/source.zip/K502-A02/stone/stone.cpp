#include<cstdio>
#include<iostream>
#include<cmath>
#define mod 1000000007
using namespace std;
typedef long long LL;
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int n,a,b;
	cin>>n>>a>>b;
	printf("0 0 %lld %lld\n",(LL)pow(2,n-1)%mod,(LL)pow(2,n-1)%mod);
	return 0;
}
