#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c = getchar();

	return sum * fg;
}

const int maxn = 100010;

int n, m, K, A[maxn], B[maxn], C[maxn], Max;

void Get(){
	n = read(), m = read(), K = read();

	For(i, 1, n) A[i] = read();
	For(i, 1, m) B[i] = read();

	Max = max(n, m);
}

int Ans;

bool check(int h){
	int pos = 1;
	For(i, 1, n){
		if(A[i] == C[pos]) ++pos;
	}
	if(pos > h) return false;

	pos = 1;
	For(i, 1, m){
		if(B[i] == C[pos]) ++pos;
	}
	if(pos > h) return false;

	return true;
}

void dfs(int h){
	if(h - 1 >= Ans) return;
	if(h && check(h - 1)) Ans = h - 1;
	if(h > Max) return;

	C[h] = 1;
	dfs(h+1);

	C[h] = 2;
	dfs(h+1);
}

void solve_bf(){
	Ans = inf;
	dfs(1);
	printf("%d\n", Ans);
}

const int maxm = 4010;

int dp[maxm][maxm], Nexta[maxm][maxm], Nextb[maxm][maxm], Last[maxm], Firsta[maxm], Firstb[maxm];

void pre_work(){
	For(i, 0, n + 2) For(j, 0, m + 2) dp[i][j] = inf;

	For(i, 1, K) Firsta[i] = n+1, Nexta[n+1][i] = n+1;
	For(i, 1, K) Firstb[i] = m+1, Nextb[m+1][i] = m+1;

	For(i, 1, K) Last[i] = n+1;

	rep(i, n, 1){
		int now = A[i];
		Last[now] = i;

		For(j, 1, K){
			Nexta[i][j] = Last[j];
		}

		Firsta[now] = i;
	}

	For(i, 1, K) Last[i] = m+1;

	rep(i, m, 1){
		int now = B[i];
		Last[now] = i;

		For(j, 1, K){
			Nextb[i][j] = Last[j];
		}

		Firstb[now] = i;
	}

	For(i, 1, K){
		dp[Firsta[i]][Firstb[i]] = 1;
	}
}

void solve_higher_bf(){
	pre_work();
	For(i, 1, n + 1){
		For(j, 1, m + 1){
			if(dp[i][j] == inf || dp[i][j] >= dp[n+1][m+1]) continue;
			if(i == n+1 && j == m+1) continue;
			For(k, 1, K){
				int u = Nexta[i+1][k], v = Nextb[j+1][k];

				if(u > n+1 || i == n+1) u = n+1; 
				if(v > m+1 || j == m+1) v = m+1;

				dp[u][v] = min(dp[u][v], dp[i][j] + 1);
			}
		}
	}

	printf("%d\n", dp[n+1][m+1]);
}

int main(){
	
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);

	Get();
	solve_higher_bf();

	return 0;
}
