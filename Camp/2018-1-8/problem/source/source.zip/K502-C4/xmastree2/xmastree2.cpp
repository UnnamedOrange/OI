#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

int n,w[30005],r[30005],head[30005],top,u,v;
int go[30005],topgo;
long long ans,Ans;
bool vis[30005];

struct edge
{
	int v,next;
} s[60005];

void dfs(int now,int cnt)
{
	ans+=w[now]*cnt;
	if(cnt==n)
	{
		Ans=max(Ans,ans);
		ans-=w[now]*cnt;
		return;
	}
	vis[now]=1;
	int amo=0;
	for(int i=head[now];i!=0;i=s[i].next)
	{
		int to=s[i].v;
		if(vis[to]==1) continue;
		go[++topgo]=to;
		amo++;
	}
	for(int i=1;i<=topgo;i++)
	{
		int temp=go[i];
		go[i]=0;
		swap(go[i],go[topgo]);
		topgo--;
		dfs(temp,cnt+1);
		topgo++;
		swap(go[i],go[topgo]);
		go[i]=temp;
	}
	while(amo--) go[topgo--]=0;
	vis[now]=0;
	ans-=w[now]*cnt;
}

bool cmp(int a,int b)
{
	return w[a]<w[b];
}

void dream(int now,int cnt)
{
	Ans+=w[now]*cnt;
	if(cnt==n)
	{
		printf("%lld",Ans);
		exit(0);
	}
	vis[now]=1;
	for(int i=head[now];i!=0;i=s[i].next)
	{
		int to=s[i].v;
		if(vis[to]==1) continue;
		go[++topgo]=to;
	}
	sort(go+1,go+topgo+1,cmp);
	int temp=go[1];
	go[1]=0; swap(go[1],go[topgo]); topgo--;
	dream(temp,cnt+1);
}

void ihaveadream()
{
	int root;
	for(int i=1;i<=n;i++)
		if(r[i]=1)
		{
			root=i;
			break;
		}
	dream(root,1);
}

int main()
{
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d%d",&u,&v);
		s[++top].v=v; s[top].next=head[u]; head[u]=top;
		s[++top].v=u; s[top].next=head[v]; head[v]=top;
	}
	for(int i=1;i<=n;i++)
		scanf("%d%d",&w[i],&r[i]);
	if(n>=1007)
	{
		ihaveadream();
		return 0;
	}
	for(int i=1;i<=n;i++)
		if(r[i]==1) dfs(i,1);
	printf("%lld",Ans);
	return 0;
}
