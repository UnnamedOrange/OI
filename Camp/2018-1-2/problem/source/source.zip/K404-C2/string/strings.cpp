#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
const int N=100005;
char s[N];
int n,len,g[N],f[N<<1],t[N<<1];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void manacher()
{
	int id=0,r=0;
	rep(i,1,len)
	{
		f[i]=r>=i?min(r-i+1,f[2*id-i]):1;
		while(t[i-f[i]]==t[i+f[i]]) ++f[i];
		if(i+f[i]-1>r) id=i,r=i+f[i]-1;
	}
}

bool check(int l,int r)
{
	return f[l+r]-1<r-l+1;
}

void solve()
{
	n=getint(),len=0,scanf("%s",s+1);
	rep(i,1,n) t[++len]=-1,t[++len]=s[i]-'a';
	t[++len]=-1,t[0]=-2,t[len+1]=-3,manacher();
	rep(i,1,n) g[i]=1000000000;
	rep(i,1,n)
		rep(j,0,i-1)
			if(check(j+1,i))
				g[i]=min(g[i],g[j]+1);
	printf("%d\n",g[n]==1000000000?-1:g[n]);
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("strings.out","w",stdout);
	for(int T=getint(); T--; solve());
	return 0;
}
