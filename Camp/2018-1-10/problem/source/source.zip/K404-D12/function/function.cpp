#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define MAXN 1000000
#define ll long long
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int Pr[78500], mu[MAXN+5], d[MAXN+5], tot, T; bool book[MAXN+5]; ll sum[MAXN+5], ans;
void Sieve()
{
	mu[1] = 1;
	for(rint i = 2, j, c; i <= MAXN; i++)
		for(book[i] ?: (Pr[++tot] = i, mu[i] = -1), j = 1; j <= tot && (c=i*Pr[j])<=MAXN; j++)
			if(book[c] = true, i%Pr[j]) mu[c] = -mu[i]; else{mu[c] = 0; break;}
	for(rint i = 1, j; i <= MAXN; sum[i] = sum[i-1]+1ll*d[i]*d[i], mu[i] += mu[i-1], i++) for(j = i; j <= MAXN; ++d[j], j += i);
}
ll Calc_106(int N){ans = 0; for(rint d = 1, p; d <= N; p = N/(N/d), ans += 1ll*(mu[p]-mu[d-1])*sum[N/d], d = p+1); return ans;}
ll Calc_109(int N){return 0;}
int main()
{
	freopen("function.in","r",stdin), freopen("function.out","w",stdout);
	T = read(); if(!T) return 0; Sieve(); for(int n; T--; Out((n=read())<=1000000?Calc_106(n):Calc_109(n)), Outc('\n')); _END; return 0;
}
