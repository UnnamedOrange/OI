#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <queue>
#define inf 0x3f3f3f3f
using namespace std;
typedef long long ll;
struct edge{
	int to, nxt, cap, flow;
}e[500005];
int h[10005], cnt = -1, cur[10005];
int n, m, s, t, op, oq; ll w;
int dis[10005], vis[10005];
int mp[505][505], val[505];

int Abs(int x){
	return x > 0 ? x : -x;
}

inline int addedge(int x, int y, int cp){
	cnt++; e[cnt].to = y; e[cnt].nxt = h[x]; e[cnt].cap = cp; e[cnt].flow = 0; h[x] = cnt;
	cnt++; e[cnt].to = x; e[cnt].nxt = h[y]; e[cnt].cap = 0; e[cnt].flow = 0; h[y] = cnt;
}
int bfs(){
	for(int i = 1; i <= t; i ++) dis[i] = inf, vis[i] = 0;
	queue<int>q; dis[s] = 0; vis[s] = 1; q.push(s);
	while(!q.empty()){
		int x = q.front();
		q.pop();
		for(int i = h[x]; i != inf; i = e[i].nxt){
			if(!vis[e[i].to] && e[i].cap - e[i].flow > 0){
				vis[e[i].to] = 1; dis[e[i].to] = dis[x] + 1; q.push(e[i].to);
			}
		}
	}
	return vis[t];
}
int dfs(int x, int a){
	if(x == t || a == 0) return a;
	int minf,resf=0;
	for(int &i = cur[x]; i != inf; i = e[i].nxt){
		if(dis[x] + 1 == dis[e[i].to]){        
			minf = dfs(e[i].to, min(a, e[i].cap - e[i].flow));
			if(minf > 0){
				e[i].flow += minf;
				e[i ^ 1].flow -= minf;
				resf += minf;
				a -= minf;
				if(a == 0) break;
			}
		}
	}
	return resf;
}
inline int dinic(){
	int maxflow=0;
	while(bfs()){
		for(int i = 1; i <= t; i ++){
			cur[i] = h[i];
		}
		maxflow += dfs(s,inf);
	}
	return maxflow;
}
int main(){
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--){
		scanf("%d%lld%d%d", &n, &w, &op, &oq);
		memset(h, inf, sizeof(h)); cnt = -1;
		memset(mp, 0, sizeof(mp));
		memset(val, 0, sizeof(val));
		for(int i = 1; i <= n; i ++){
			val[i] = 1;	
		}
		for(int i = 1; i <= op; i ++){
			int xi, yi, zi, ai, bi, ci, di, ei, fi;
			scanf("%d%d%d%d%d%d%d%d%d", &xi, &yi, &zi, &ai, &bi, &ci, &di, &ei, &fi);
			val[xi] += di - fi;
			val[yi] += ei - di;
			val[zi] += fi - ei;
			if(xi < yi) mp[xi][yi] += ai; else mp[yi][xi] += ai;
			if(yi < zi) mp[yi][zi] += bi; else mp[zi][yi] += bi;
			if(zi < xi) mp[zi][xi] += ci; else mp[xi][zi] += ci;
		}
		int mx = 0;
		for(int i = 1; i <= n; i ++){
			mx = max(mx, Abs(val[i]));
		}
		mx = mx + 1;
		s = 2 * n + 1, t = 2 * n + 2;
		for(int i = 1; i <= n; i ++){
			addedge(s, i, mx + val[i]);
			addedge(i, i + n, inf);
			addedge(i + n, t, mx - val[i]);
		}
		for(int i = 1; i <= n; i ++){
			for(int j = i + 1; j <= n; j ++){
				if(mp[i][j] == 0) continue;
				addedge(i + n, j, 2 * mp[i][j]);
				addedge(j + n, i, 2 * mp[i][j]);
			}
		}
		for(int i = 1; i <= oq; i ++){
			int xi, yi, zi;
			scanf("%d%d%d", &xi, &yi, &zi);
			if(zi == 0){
				addedge(yi + n, xi, inf);
			}
			if(zi == 1){
				addedge(xi + n, yi, inf);
				addedge(yi + n, xi, inf);
			}
			if(zi == 2){
				addedge(s, xi, inf);
				addedge(yi + n, t, inf);
			}
		}
		printf("%lld\n", ll((dinic() - mx * n)) * w);
	}
	return 0;
}

