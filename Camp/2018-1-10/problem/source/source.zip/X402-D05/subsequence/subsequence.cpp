#include<bits/stdc++.h>
using namespace std;
void chkmin(int &x,int y){
	x=x<y?x:y;
}
const int INF=1e8;
int a[10100],b[10100];
int dp[310][310];
int c[310][310],d[310][310];
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	for(int i=1;i<=k;i++)
		c[n+1][i]=n+1,d[m+1][i]=m+1;
	for(int i=n;i>=0;i--){
		for(int j=1;j<=k;j++){
			if(a[i+1]==j)
				c[i][j]=i+1;
			else
				c[i][j]=c[i+1][j];
		}
	}
	for(int i=m;i>=0;i--){
		for(int j=1;j<=k;j++){
			if(b[i+1]==j)
				d[i][j]=i+1;
			else
				d[i][j]=d[i+1][j];
		}
	}
	for(int i=0;i<=n+1;i++)
		for(int j=0;j<=m+1;j++)
			dp[i][j]=INF;
	dp[0][0]=0;
	for(int i=0;i<=n+1;i++)
		for(int j=0;j<=m+1;j++)
			for(int s=1;s<=k;s++)
				chkmin(dp[c[i][s]][d[j][s]],dp[i][j]+1);
	printf("%d\n",dp[n+1][m+1]);
	return 0;
}
