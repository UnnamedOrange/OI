#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<stack>
#define ll long long
using namespace std;
const int N=1005;
int n,w,p,q;
ll ans=1e17;
int x[N],y[N],z[N],a[N],b[N],c[N],d[N],e[N],f[N],xx[N],yy[N],r[N],k[N];
inline ll h(int i){
	return a[i]*abs(k[x[i]]-k[y[i]])+b[i]*abs(k[y[i]]-k[z[i]])+c[i]*abs(k[z[i]]-k[x[i]])+d[i]*(k[x[i]]-k[y[i]])+e[i]*(k[y[i]]-k[z[i]])+f[i]*(k[z[i]]-k[x[i]]);
}
inline void add(){
	ll s=0;
	for(int i=1;i<=n;i++) s+=k[i]+h(i);
	ans=min(s,ans);
}
inline bool check(){
	for(int i=1;i<=q;i++){
		if(!r[i]&&k[xx[i]]>k[yy[i]]) return 0;
		if(r[i]==1&&k[xx[i]]!=k[yy[i]]) return 0;
		if(r[i]==2&&k[xx[i]]>=k[yy[i]]) return 0;
	}
	return 1;
}
void dfs(int i){
	if(i==n+1){
		if(check()) add();
		return;
	}
	k[i]=w;
	dfs(i+1);
	k[i]=-w;
	dfs(i+1);
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d%d%d",&n,&w,&p,&q);
		for(int i=1;i<=p;i++) scanf("%d%d%d%d%d%d%d%d%d",&x[i],&y[i],&z[i],&a[i],&b[i],&c[i],&d[i],&e[i],&f[i]);
		for(int i=1;i<=q;i++) scanf("%d%d%d",&xx[i],&yy[i],&r[i]);
		dfs(1);
		printf("%lld",ans);
		return 0;
	}
}
