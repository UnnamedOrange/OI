#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,k,a[20],b[20],ans=1e9,c[20],mid;
bool ok;
bool find1(){
	int j=1; 
	for(int i=1;i<=n;i++){
		if(a[i]==c[j]){
			j++;continue;
		}
	}
	if(j>mid)return 1;
	else return 0;
}
bool find2(){
	int j=1; 
	for(int i=1;i<=m;i++){
		if(b[i]==c[j]){
			j++;continue;
		}
	}
	if(j>mid)return 1;
	else return 0;
}
bool judge(){
	if(find1()||find2())return 0;
	return 1;
}
void dfs(int pos){
	if(ok==1)return; 
	if(pos>mid){
		if(judge())ok=1;
		return;
	}
	for(int i=1;i<=2;i++){
		c[pos]=i;
		dfs(pos+1);
		if(ok)return;
	}
}
bool check(){
	ok=0;
	dfs(1);
	if(ok)return 1;
	return 0;
}
int main(){
	freopen("subsequence.in","r",stdin);freopen("subsequence.out","w",stdout);
//	freopen("Cola.txt","r",stdin);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	int l=2,r=max(m,n)+1;
	while(l<=r){
		mid=(l+r)>>1;
		if(check())r=mid-1,ans=min(ans,mid);
		else l=mid+1;
	}
	printf("%d",ans);
	return 0;
}
