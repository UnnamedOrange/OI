#include<bits/stdc++.h>
using namespace std;
vector <int> a[101000],b[101000];
int n,q,t,c[101000],lastans=0,f[101000],vis[101000];

void find(int x,int l,int r)
{
	if (c[x]<=r&&c[x]>=l&&!vis[c[x]]) 
	  {
	  	lastans++;
	  	vis[c[x]]=1;
	  }
	for (int i=a[x].size()-1;i>=0;i--) find(a[x][i],l,r);
}

void dfs(int x)
{
	vis[x]=1;
	for (int i=b[x].size()-1;i>=0;i--)
	  {
	  	if (!vis[b[x][i]])
	  	  {
	  	 	a[x].push_back(b[x][i]);
	  	 	dfs(b[x][i]);
		  }
	  }
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for (int i=1;i<=n;i++) scanf("%d",&c[i]);
	for (int i=1;i<n;i++)
	  {
	  	int u,v;
	  	scanf("%d%d",&u,&v);
	  	b[u].push_back(v);
	  	b[v].push_back(u);
	  	f[v]=u;
	  }  
	dfs(1);  
	for (int i=1;i<=q;i++)
	  {
	  	int o;
	  	scanf("%d",&o);
	  	if (o==1)
	  	  {
	  	  	int u,l,r;
	  	  	scanf("%d%d%d",&u,&l,&r);
	  	  	if (t==1) u=u^lastans,l=l^lastans,r=r^lastans;
	  	  	lastans=0;
	  	  	memset(vis,0,sizeof(vis));
	  	  	find(u,l,r);
	  	  	printf("%d\n",lastans);
		  }
		if (o==2)
		  {
		  	int u,cl;
		  	scanf("%d%d",&u,&cl);
		  	if (t==1) u=u^lastans,cl=cl^lastans;
		  	c[u]=cl;
		  }  
	  }  
}
