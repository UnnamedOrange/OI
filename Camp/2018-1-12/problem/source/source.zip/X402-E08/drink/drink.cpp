/*
Author: CNYALI_LK
LANG: C++
PROG: drink.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %d\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<int,int> pii;
template<class T>int chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>int chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
int read(){
	int s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WriteIntBuffer[1024];
template<class T>void write(T a,char end){
	int cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WriteIntBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WriteIntBuffer[cnt]);--cnt;}
	putchar(end);
}

int w[1024240],s[1024240],a[1024240];
int Wcmp(int a,int b){
	return w[a]<w[b];
}
#ifndef cnyali_lk
#define cnyali_lk
#endif
double fa[1024240],fb[1024240];
double sum[4024240],add[4024240],mul[4024240];
#define mid ((l+r)>>1)
inline void BuildTree(int x,int l,int r){
	sum[x]=add[x]=0;
	mul[x]=1;
	if(l!=r){
		BuildTree(x<<1,l,mid);
		BuildTree(x<<1|1,mid+1,r);
	}
}
inline void push_up(int x){
	sum[x]=sum[x<<1]+sum[x<<1|1];
}
inline void push_down(int x,int l,int r) {
	sum[x<<1]*=mul[x];
	sum[x<<1|1]*=mul[x];
	mul[x<<1]*=mul[x];
	mul[x<<1|1]*=mul[x];
	add[x<<1]*=mul[x];
	add[x<<1|1]*=mul[x];
	mul[x]=1;
	add[x<<1]+=add[x];
	add[x<<1|1]+=add[x];
	sum[x<<1]+=(mid-l+1)*add[x];
	sum[x<<1|1]+=(r-mid)*add[x];
	add[x]=0;
}
inline void c2(int x,int l,int r,int lx,int rx){
	if(lx<=l&&r<=rx){mul[x]/=2;sum[x]/=2;add[x]/=2;return;}
	if(r<lx||rx<l)return;
	push_down(x,l,r);
	c2(x<<1,l,mid,lx,rx);
	c2(x<<1|1,mid+1,r,lx,rx);
	push_up(x);
}
inline void Plus(int x,int l,int r,int lx,int rx,double s){
	if(lx<=l&&r<=rx){add[x]+=s;sum[x]+=(r-l+1)*s;return;}
	if(r<lx||rx<l)return;
	push_down(x,l,r);
	Plus(x<<1,l,mid,lx,rx,s);
	Plus(x<<1|1,mid+1,r,lx,rx,s);
	push_up(x);
}
inline double get(int x,int l,int r,int s){
	while(l!=r){
		push_down(x,l,r);
		if(s<=mid)r=mid,x<<=1;
		else l=mid+1,x=x<<1|1;
	}
	return sum[x];	
}
int main(){
#ifdef cnyali_lk
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
#endif
	int n;
	n=read();
	for(int i=1;i<=n;++i){
		w[i]=read();
		a[i]=i;
	}
	sort(a+1,a+n+1,Wcmp);
	for(int i=1;i<=n;++i)s[a[i]]=i;
	double ans=0,W;
	BuildTree(1,1,n);
	for(int i=1;i<=n;++i){
		fa[i]=i-get(1,1,n,s[i]);
		c2(1,1,n,1,s[i]-1);
		Plus(1,1,n,1,s[i]-1,i*1./2);
	}
	BuildTree(1,1,n);
	for(int i=n;i;--i){
		fb[i]=n-i+1-get(1,1,n,s[i]);
		c2(1,1,n,1,s[i]-1);
		Plus(1,1,n,1,s[i]-1,(n-i+1)*1./2);
	}
	for(int i=1;i<=n;++i)
		ans+=fa[i]*fb[i]/n*w[i]/n/2;
	printf("%.10lf\n",ans);
	return 0;
}

