#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<queue>
//#include<ctime>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=8;
const int M=505;
const int SZ=60051;
const int mod=998244353;
int sz=1,rt=1,fail[SZ],ch[SZ][2],sum[2][SZ];
int n,m;
void insert(char *s,int len,int wh,int id)
{
	int o=rt;
	for(int i=1;i<=len;++i)
	{
		int x=s[i]-48;
		if(!ch[o][x]) ch[o][x]=++sz;
		o=ch[o][x];
	}
	sum[wh][o]|=1<<id;
}
queue<int>q;
void buildfail()
{
	q.push(rt);
	while(!q.empty())
	{
		int o=q.front(); q.pop();
		for(int i=0;i<=1;++i)
		{
			int v=ch[o][i];
			if(!ch[o][i]) {ch[o][i]=ch[fail[o]][i];continue;}
			if(o==rt) fail[ch[o][i]]=rt;
			else
			{
				int p=fail[o];
				while(p)
				{
					if(ch[p][i]) {fail[ch[o][i]]=ch[p][i];break;}
					p=fail[p];
				}
				if(!p) fail[ch[o][i]]=rt;
			}
			sum[0][v]|=sum[0][fail[v]];
			sum[1][v]|=sum[1][fail[v]];
			q.push(v);
		}
	}
}
int f[M][1701][(1<<6)+1];

char in[M],p[M];
void wj()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
//	clock_t sta=clock();
	n=read(); m=read();
	for(i=1;i<=n;++i)
	{
		scanf("%s",in+1);
		int len=strlen(in+1);
		insert(in,len,0,i-1);
		for(j=1;j<=len;++j) p[j]=in[len-j+1];
		for(j=1;j<=len;++j) p[j]=97-p[j];
		insert(p,len,0,i-1);
		//for(int k=1;k<=len;++k) putchar(p[k]); ln;
		int l=0;
		for(j=1;j<len;++j)
		{
			l=0; bool can=1;
			for(int k=1;k<=j;++k) if(2*j+1-k<=len&&in[k]==in[2*j+1-k]) {can=0;break;}
			if(can)
			{
				for(int k=len;k>=2*j+1;--k) p[++l]=97-in[k];
				for(int k=1;k<=j;++k) p[++l]=in[k];
				insert(p,l,1,i-1);
			}
		}
	}
//	cerr<<sz<<endl;
	buildfail();
	for(i=1;i<=sz;++i) f[m+1][i][(1<<n)-1]=1;
	int tot=1<<n;
	for(i=m;i;--i) for(j=1;j<=sz;++j) for(int s=0;s<tot;++s)
	{
		int s1=s,v=0,&ans=f[i][j][s];
		v=ch[j][0]==0?rt:ch[j][0];
		s1|=sum[0][v];
		if(i==m) s1|=sum[1][v];
		ans=(ans+f[i+1][v][s1])%mod;

		s1=s;
		v=ch[j][1]==0?rt:ch[j][1];
		s1|=sum[0][v];
		if(i==m) s1|=sum[1][v];
		ans=(ans+f[i+1][v][s1])%mod;
	}
	printf("%d\n",f[1][rt][0]);
//	clock_t fin=clock();
//	cerr<<(double)(fin-sta)/CLOCKS_PER_SEC<<endl;
//	cout<<fail[8]<<endl;
	return 0;
}
