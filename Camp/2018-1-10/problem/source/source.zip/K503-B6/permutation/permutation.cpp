#include<iostream>
#include<cstdio>
#include<cctype>
#include<algorithm>
#include<cstring>
#define rep(i,x,y) for(register int i = x ;i <= y; ++ i)
using namespace std;
typedef long long ll;
template<typename T>inline void read(T&x)
{
	x = 0;char c;int sign = 1;
	do { c = getchar(); if(c == '-') sign = -1; }while(!isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); }while(isdigit(c));
	x *= sign;
}
inline void init(string name)
{
	string in = name + ".in",out = name + ".out";
	freopen(in.c_str(),"r",stdin);
	freopen(out.c_str(),"w",stdout);
}

const int N = 1e5 + 500,mod = 998244353;
int n ,fuc[N] ,inv[N] , finv[N] ,p[N] ,f[N] ,np ,cnt ,num;
int dp[5002][5002];
bool vis[N];

inline void pre()
{
	inv[1] = fuc[0] = fuc[1] = 1;
	rep(i,2,n)
		fuc[i] = (ll)fuc[i - 1] * i % mod,
		inv[i] = ((ll)-mod) / i * inv[mod%i] % mod;
	
	finv[0] = 1;finv[1] = inv[1];
	rep(i,2,n)
		finv[i] = ((ll)finv[i - 1] * inv[i]) % mod;
	
//	rep(i,1,n) printf("%d ",fuc[i]);
//	printf("%d\n");
}
 
int c(int m,int n)
{
	if(m == n) return 1;
	return ((ll)fuc[n] * finv[m]) % mod * finv[n - m] % mod;
}

ll solve(int n,int x)
{
	if(n&1) return 0;
	
	if(n <= 10000 && x <= 5000 && ~dp[n>>1][x]) return dp[n>>1][x];
	
	int ans = 0;
	
	for(register int i = 2;i <= n; i+= 2)
		rep(j,0,x){
		
//		printf("%d %d %d\n",i,j,fuc[i + j - 1]);
		
		ans = ((ll)ans + (ll)c(i - 1,n - 1)*fuc[i + j - 1]%mod*(n - i > 0 ? solve(n - i,x - j):1 * (x - j > 0 ? (1<<(x - j - 1)) : 1))) % mod;
	}
	if(n <= 10000 && x <= 5000) return dp[n>>1][x] = ans;
	return ans;
}

int main()
{
	init("permutation");
	
	memset(dp,-1,sizeof dp);
	read(n);
	pre();
	
	rep(i,1,n)
	{
		read(f[i]);
		if(f[i] == i)
			return puts("0"),0;
	}
	 
	rep(i,1,n)
		if(!vis[i])
		{
			int x = i;bool e = 1;
			vis[x] = 1;np = 1;++cnt;
			while(f[x])
			{
				if(vis[f[x]])
				{
					if(np & 1) return puts("0"),0;
					e = 0;--cnt;break;
				}
				x = f[x] ; vis[x] = 1; ++np;
			}
			if(e){
				if(np > 1)
					++num;
			}
		}
	
	printf("%lld\n",(solve(cnt - num,num) + mod) % mod);
	
	return 0;
}
