#include<cstdio>
#include<iostream>
#include<cstring>
#define maxn 110
#define inf 0x3f3f3f3f
using namespace std;
char s[maxn];
int dp[maxn];
int pd(int x,int y){
	while (x<=y){
		if (s[x]!=s[y]) return 0;
		x++; y--;
	}
	return 1;
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int T;
	cin>>T;
	while (T--){
		int i,j,k,n;
		scanf("%d\n",&n);
		scanf("%s",s+1);
		memset(dp,0x3f,sizeof(dp));
		dp[0]=0;
		for (int i=1;i<=n;i++){
			for (int j=0;j<i;j++)
				if (!pd(j+1,i)){
					dp[i]=min(dp[i],dp[j]+1);
				}
		}
		if (dp[n]<inf) printf("%d\n",dp[n]);
		else printf("-1\n");
	}
	return 0;
}
