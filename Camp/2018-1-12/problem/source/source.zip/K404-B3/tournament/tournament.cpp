#include<map>
#include<cmath>
#include<queue>
#include<bitset>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define mod 998244353
#define ll long long
#define N 100010
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int n,k;
namespace sub1
{
	int ans=0,m;
	#define M 10
	bitset<M>a1[M],a2[M];
	int lj[M],fro[M*M],to[M*M],cnt;
	void add(int a,int b){fro[++cnt]=lj[a];to[cnt]=b;lj[a]=cnt;}
	struct qaz{int x,y;}p[M*M];
	bool ck(int x)
	{
		memset(lj,0,sizeof(lj));cnt=0;
		for(int i=1;i<=n;i++) a1[i]=a2[i]=0;
		int tx,ty;
		for(int i=0;i<m;i++)
		{
			tx=p[i+1].x;ty=p[i+1].y;
			if(x&(1<<i)) add(tx,ty),a1[tx][ty]=1;
			else add(ty,tx),a1[ty][tx]=1;
		}
		if(k==3)
		{
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++) if(a1[i][j]) a2[i]|=a1[j];
			for(int i=1;i<=n;i++)
			{
				for(int j=1;j<=n;j++)
				{
					if(a2[i][j]&&a1[j][i]) return 1;
					if(a2[j][i]&&a1[i][j]) return 1;
				}
			}
			return 0;
		}
	}
	void Main()
	{
		m=n*(n-1)/2;
		for(int i=1,tt=0;i<=n;i++)
			for(int j=i+1;j<=n;j++) p[++tt]=(qaz){i,j};
		for(int i=0;i<(1<<m);i++)
			if(ck(i)) ans++;
		printf("%d\n",ans);
	}
};
int main()
{
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	n=rd();k=rd();
	if(n<=6) sub1::Main();
	return 0;
}