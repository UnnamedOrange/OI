#include <cstdio>
#include <algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define down(i,j,k) for (i=j;i>=k;i--)
using namespace std;
const int N=2e3+5,mod=1e9+7;
int n,i,j,l,r,c[N],d[N],f[N],dp[N];
inline void updata(int i,int j)
{
	if (f[j]+1<f[i]) return;
	if (f[j]+1>f[i]) {
		f[i]=f[j]+1; dp[i]=dp[j];
	}
	else dp[i]=(dp[i]+dp[j])%mod;
}
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	rep(i,1,n) scanf("%d%d",&c[i],&d[i]);
	dp[0]=1;
	rep(i,1,n)
	{
		l=c[i]; r=d[i];
		down(j,i,1)
		{
			l=max(l,c[j]); r=min(r,d[j]);
			if (i-j+1<l || i-j+1>r) break;
			updata(i,j-1);
		}
	}
	if (f[n]==0) printf("-1\n");
	else printf("%d %d\n",f[n],dp[n]);
	return 0;
}
