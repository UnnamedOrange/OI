#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

int randint(int l, int r){
	return rand() % (r - l + 1) + l;
}

int main(){

	freopen("xmasinterval.in", "w", stdout);

	srand(time(0));

	int mx = 40, n = 20, m = n;
	printf("%d %d\n", n, m);
	For(i, 1, n){
		int l = randint(1, mx), r = randint(1, mx);
		if(l > r) swap(l, r);
		printf("%d %d\n", l, r);
	}
	For(i, 1, m) printf("%d\n", randint(4, mx - 4));

	return 0;
}
