#include<bits/stdc++.h>
using namespace std;
const int maxn=2000010;
int T,opt,n,m,w,anss;
int i,j,k,x,y;
int vis[maxn],low[maxn],dfn[maxn],ha[maxn],rr,a[maxn],f[maxn],col=0,hf[maxn],ans[maxn];
int r,f1[maxn],f2[maxn],f3[maxn];
int rrr,ff1[maxn],ff2[maxn],ff3[maxn];
int read(){
	int tot=0,fh=1;
	char c=getchar();
	while ((c-'0'<0)||(c-'0'>9)){if(c=='-')fh=-1;c=getchar();}
	while ((c-'0'>=0)&&(c-'0'<=9)){tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void tarjan(int x){
	w++; dfn[x]=w; low[x]=w;
	rr++; a[rr]=x;
	ha[x]=1; vis[x]=1;
	int i=f1[x];
	while (i!=0){
		if (vis[f2[i]]==0){
			tarjan(f2[i]);
			low[x]=min(low[x],low[f2[i]]);
		}
		else{
			if (ha[f2[i]]==1){
				low[x]=min(low[x],dfn[f2[i]]);
			}
		}
		i=f3[i];
	}
	if (low[x]==dfn[x]){
		col++;
		while (a[rr]!=x){
			ha[a[rr]]=0;
			f[a[rr]]=col;
			a[rr]=0; rr--;
		}
		ha[a[rr]]=0;
		f[a[rr]]=col;
		a[rr]=0; rr--;
	}
}
void tubo(){
	int i,j,l=1,r=0;
	for (i=1;i<=col;i++){
		if (ha[i]==0){
			r++; a[r]=i;
		}
	}
	while (l<=r){
		i=ff1[a[l]];
		while (i!=0){
			ha[ff2[i]]--;
			ans[ff2[i]]=max(ans[ff2[i]],ans[a[l]]+hf[a[l]]);
			if (ha[ff2[i]]==0){
				r++; a[r]=ff2[i];
			}
			i=f3[i];
		}
		l++;
	}
	
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	n=read(); m=read();
	memset(f1,0,sizeof(f1)); r=0;
	for (i=1;i<=m;i++){
		x=read(); y=read();
		r++; f2[r]=y; f3[r]=f1[x]; f1[x]=r;
	}
	memset(vis,0,sizeof(vis));
	for (i=1;i<=n;i++)
		if (vis[i]==0){ rr=0; w=0; tarjan(i); }
	memset(hf,0,sizeof(hf));
	for (i=1;i<=n;i++){
		hf[f[i]]++;
	}
	rrr=0; memset(ff1,0,sizeof(ff1));
	memset(ha,0,sizeof(ha));
	for (i=1;i<=n;i++){
		j=f1[i];
		while (j!=0){
			if (f[f2[j]]!=f[i]){
				rrr++; ff2[rrr]=f[f2[j]]; ff3[rrr]=ff1[f[i]]; ff1[f[i]]=rrr;
				ha[f[f2[j]]]++;
			}
			j=f3[j];
		}
	}
	memset(ans,0,sizeof(ans));
	tubo();
	anss=0;
	for (i=1;i<=col;i++){
		anss=max(anss,ans[i]+hf[i]);
	}
	printf("%d\n",anss);
	return 0;
}
