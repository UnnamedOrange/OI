#include<map>
#include<cmath>
#include<queue>
#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 1000000007
#define ll long long
#define N 100010
inline int rd()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int T,n;
char s[N];
bool ck(int l,int r)
{
	if(l==r) return 0;
	int sz=r-l+1,mid=l+r>>1;
	if(sz&1)
	{
		for(int i=mid,j=mid;i>=l;i--,j++)
			if(s[i]!=s[j]) return 1;
	}
	else 
	{
		for(int i=mid,j=mid+1;i>=l;i--,j++)
			if(s[i]!=s[j]) return 1;
	}
	return 0;
}
int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	T=rd();
	while(T--)
	{
		n=rd();
		scanf("%s",s+1);
		if(n==1){puts("-1");continue;}
		if(ck(1,n)){puts("1");continue;}
		int i;
		for(i=1;i<n;i++)
			if(ck(1,i)&&ck(i+1,n)) break;
		if(i<n) puts("2");
		else puts("-1");
	}
	return 0;
}
/*
10
7
abcdcba
3
xxx
1
a
2
ab
3
aba
7
abababa
5
ababa
6
abaaba
7
fasdgsf

*/