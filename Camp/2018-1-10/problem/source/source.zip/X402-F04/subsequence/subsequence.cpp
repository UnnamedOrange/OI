//2018-1-10
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define Set(a, v) memset(a, v, sizeof(a))
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)
#define Forr(i, a, b) for(int i = (a); i >= (int)(b); --i)

#define N (4000+5)
const int oo = 0x3f3f3f3f;

inline int chkmin(int a, int b){return a < b? a: b;}

int n, m, rk, a[N], b[N], f[N][N], ap[N][N], bp[N][N];

int main(){
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &rk);
	For(i, 1, n) scanf("%d", &a[i]), ap[a[i]][i-1] = i;
	For(i, 1, m) scanf("%d", &b[i]), bp[b[i]][i-1] = i;
	
	int lst;
	For(i, 1, rk){
		lst = ap[i][n+1]; if(!lst) lst = oo;
		Forr(j, n, 0)
			if(ap[i][j]) lst = ap[i][j]; else ap[i][j] = lst;
		
		lst = bp[i][m+1]; if(!lst) lst = oo;
		Forr(j, m, 0)
			if(bp[i][j]) lst = bp[i][j]; else bp[i][j] = lst;
	}

	Set(f, oo);
	f[0][0] = 0;

	int me, ni, nj, ans = max(n, m) + 1;

	For(i, 0, n+1) For(j, 0, m+1) if((me=f[i][j]) < oo){
		if(me >= ans) continue;

		For(k, 1, rk){
			ni = i == n+1? oo: ap[k][i];
			nj = j == m+1? oo: bp[k][j];
			if(ni == oo && nj == oo){
				ans = chkmin(ans, me+1); continue;
			}

			ni = chkmin(ni, n+1); nj = chkmin(nj, m+1);
			f[ni][nj] = chkmin(f[ni][nj], me+1);
		}
	}

	printf("%d\n", ans);

	return 0;
}
