#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#include<vector>
#define N 2010
#define K 510
vector<int>t[N];
int n,m,k;
long long ans[N],f[N][N],g[N],power[N];
#define mod 998244353
void dfs(int x)
{
	if(ans[x]||x==1)
		return ;
	fr(i,0,t[x].size()-1)
	{
		dfs(t[x][i]);
		fr(j,1,n)
			f[x][j]=(f[x][j]+f[t[x][i]][j-1])%mod;
	}
	fr(i,1,n)
		ans[x]=(ans[x]+f[x][i]*power[i]%mod)%mod;
}
void dfs2(int x)
{
	if(ans[x]||x==1)
		return;
	fr(i,0,t[x].size()-1)
	{
		dfs2(t[x][i]);
		g[x]=(g[t[x][i]]+g[x])%mod;
		ans[x]=(ans[x]+g[t[x][i]]+ans[t[x][i]])%mod;
	}
}
long long poww(long long x,long long y)
{
	long long r=1;
	while(y)
	{
		if(y&1)
			r=r*x%mod;
		y>>=1;
		x=x*x%mod;
	}
	return r;
}
int main()
{
	freopen("xmasdag.out","w",stdout);
	freopen("xmasdag.in","r",stdin);
	n=read();
	m=read();
	k=read();
	fr(i,1,m)
	{
		int u=read(),v=read();
		t[v].push_back(u);
	}
	if(k>1)
	{
		f[1][0]=1;
		fr(i,1,n)
			power[i]=poww(i,k);
		fr(i,1,n)
		{
			dfs(i);
			printf("%lld\n",ans[i]);
		}
	}
	else
	{
		g[1]=1;
		fr(i,1,n)
		{
			dfs2(i);
			printf("%lld\n",ans[i]);
		}
	}
	return 0;
}