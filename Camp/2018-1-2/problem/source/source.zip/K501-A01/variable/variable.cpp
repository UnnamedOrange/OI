#include<stdio.h>
#include<algorithm>
#include<limits.h>
#include<stdlib.h>
using namespace std;
#define Maxp 1009
#define Maxn 509
#define rep(i, a, b) for(register int i = (a), i##_end_ = (b); i <= i##_end_; ++i) 
typedef long long LL;
int n, W, p, q;
int x[Maxp],y[Maxp],z[Maxp],a[Maxp],b[Maxp],c[Maxp],d[Maxp],e[Maxp],f[Maxp];
int vis[Maxn], tmp[Maxn];
LL ans = LLONG_MAX;
struct condition{
	int x1, y1, z1;
}g[Maxp];
int check() {
	rep(i, 1, n) tmp[i] = vis[i] * W;
	rep(i, 1, p)
		if(vis[g[i].x1] * vis[g[i].y1]){
			if(g[i].z1 == 0) 
				if(!(tmp[g[i].x1] <= tmp[g[i].y1])) return 0;
			if(g[i].z1 == 1)
				if(!(tmp[g[i].x1] == tmp[g[i].y1])) return 0;
			if(g[i].z1 == 2)
				if(!(tmp[g[i].x1] < tmp[g[i].y1])) return 0;
		}
	return 1;
}
LL calc() {
	LL tmp1 = 0;
	rep(i, 1, n) tmp1 += W * vis[i];
	rep(i, 1, n) {
		tmp1 += a[i] * abs(W * vis[x[i]] - W * vis[y[i]]);
		tmp1 += b[i] * abs(W * vis[y[i]] - W * vis[z[i]]);
		tmp1 += c[i] * abs(W * vis[z[i]] - W * vis[x[i]]);
		tmp1 += d[i] * (W * vis[x[i]] - W * vis[y[i]]);
		tmp1 += e[i] * (W * vis[y[i]] - W * vis[z[i]]);
		tmp1 += f[i] * (W * vis[z[i]] - W * vis[x[i]]);
	}
	return tmp1;
}
void dfs(int a) {
	if(!check()) return;
	if(a == n + 1){ 
		ans = min(ans, calc());
		return ;
	}
	vis[a] = 1;
	dfs(a + 1);
	vis[a] = 0;
	vis[a] = -1;
	dfs(a + 1);
	vis[a] = 0;
}
int main(){
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--) {
		scanf("%d %d %d %d", &n, &W, &p, &q);
		rep(i, 1, p) {
			scanf("%d",&x[i]);
			scanf("%d",&y[i]);
			scanf("%d",&z[i]);
			scanf("%d",&a[i]); scanf("%d",&b[i]); scanf("%d",&c[i]);
			scanf("%d",&d[i]); scanf("%d",&e[i]); scanf("%d",&f[i]);
		}
		rep(i, 1, q)
			scanf("%d %d %d", &g[i].x1, &g[i].y1, &g[i].z1);
		dfs(1);
		printf("%lld\n", ans);
	}
	return 0;
}
