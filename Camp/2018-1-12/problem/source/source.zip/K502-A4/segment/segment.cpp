#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int N=(int)1e5,mod=998244353;

int Pow(int x,int y){
	int res=1;
	for(;y;y>>=1,x=(ll)x*x%mod)
		if(y&1)res=(ll)res*x%mod;
	return res;
}
void add_mod(int &a,int b){if((a+=b)>=mod)a-=mod;}
int n,m,K;
struct P_0{
	int ans,a[10],sum[10];
	void dfs(int t,int l,int r){
		if(n<t){
			for(int i=1;i<=m;++i){
				a[i]=a[i-1]+sum[i];
				add_mod(ans,Pow(a[i],K));
			}
			return ;
		}
		for(;l<=m;++l)
			for(int i=max(l,r);i<=m;++i)
				{
					++sum[l],--sum[i];
					dfs(t+1,l+1,i+1);
					--sum[l],++sum[i];
				}
	}
	void work(){
		dfs(1,1,1);
		ptn(ans);
	}
}P0;
int dp[2][45][45],cnt[2][45][45];
struct P_1{
	void work(){
		int ans=0;
		if(n<=m){
			int cur=0,l,r,ll,rr;
			cnt[cur][0][0]=1;
			rep(t,0,n){
				int nxt=cur^1;
				for(l=t;l<=m;++l)
					for(r=l;r<=m;++r)
					if(cnt[cur][l][r]){
						for(ll=l+1;ll<=m;++ll)
							for(rr=max(ll,r+1);rr<=m;++rr){
								add_mod(cnt[nxt][ll][rr],cnt[cur][l][r]);
								dp[nxt][ll][rr]=(dp[nxt][ll][rr]+(long long)dp[cur][l][r]+(long long)cnt[cur][l][r]*(rr-ll))%mod;
							}
						cnt[cur][l][r]=dp[cur][l][r]=0;
					}
				cur=nxt;
			}
			for(l=n;l<=m;++l)for(r=l;r<=m;++r)
				add_mod(ans,dp[cur][l][r]);
		}
		ptn(ans);
	}
}P1;
struct P_2{
	void work(){
		int ans=0;
		rep(i,1,m+1){
			ans=(ans+(ll)(m-i)*i)%mod;
		}
		ptn(ans);
	}
}P2;
int Sum(int l,int r){
	return (ll)(l+r)*(r-l+1)/2;
}
struct P_3{
	void work(){
		int ans=0,sum=0,cnt=0,sum_cnt=0;
		rep(i,1,m){//divide
			sum=(sum+Sum(0,i-1))%mod;
			sum_cnt=(sum_cnt+i)%mod;
			ans=(ans+(ll)Sum(0,m-i)*(sum_cnt-1)%mod)%mod;
			ans=(ans+(ll)sum*(m-i+1))%mod;
		}
		if(ans<0)ans+=mod;
		rep(i,2,m-1){
			per(j,1,i){
				rep(k,j+1,i+1){
					cnt=(cnt+(ll)(m-i-1)*(i-k+1))%mod;
					ans=(ans+Sum(0,m-i-1))%mod;
					ans=(ans+(ll)(k-j)*(m-i-1))%mod;
				}
			}
		}
		ans=(ans+(ll)cnt*Pow(2,K))%mod;
		ptn(ans);
	}
}P3;
struct P_4{
	int calc(int n){
		return (ll)n*(n+1)*(2*n+1)/6%mod;
	}
	void work(){
		int ans=0,sum=0,cnt=0,sum_cnt=0;
		rep(i,1,m){//divide
			sum=(sum+Sum(0,i-1))%mod;
			sum_cnt=(sum_cnt+i)%mod;
			ans=(ans+(ll)Sum(0,m-i)*(sum_cnt-1)%mod)%mod;
			ans=(ans+(ll)sum*(m-i+1))%mod;
		}
		if(ans<0)ans+=mod;
		sum=0,sum_cnt=0;
		rep(i,2,m-1){
			int p=m-i-1;
			sum_cnt=(sum_cnt+i-1)%mod;
			sum=(sum+sum_cnt)%mod;
			cnt=(cnt+sum*(ll)p)%mod;
			ans=(ans+Sum(0,i-1)*(ll)Sum(0,p))%mod;
			ans=(ans-p*(ll)sum)%mod;
			ans=(ans+(ll)calc(i-1)*p)%mod;
			ans=(ans+(ll)Sum(0,i-1)*p)%mod;
		}
		ans=(ans+(ll)cnt*Pow(2,K))%mod;
		if(ans<0)ans+=mod;
		ptn(ans);
	}
}P4;
struct P_5{
	void work(){
		int ans=0;
		if(n<=m){
			int cur=0,l,r,ll,rr;
			cnt[cur][0][0]=1;
			rep(t,0,n){
				int nxt=cur^1;
				for(l=t;l<=m;++l)
					for(r=l;r<=m;++r)
					if(cnt[cur][l][r]){
						for(ll=l+1;ll<=m;++ll)
							for(rr=max(ll,r+1);rr<=m;++rr){
								add_mod(cnt[nxt][ll][rr],cnt[cur][l][r]);
								dp[nxt][ll][rr]=(dp[nxt][ll][rr]+(long long)dp[cur][l][r]+(long long)cnt[cur][l][r]*(rr-max(ll,r)))%mod;
							}
						cnt[cur][l][r]=dp[cur][l][r]=0;
					}
				cur=nxt;
			}
			for(l=n;l<=m;++l)for(r=l;r<=m;++r)
				add_mod(ans,dp[cur][l][r]);
		}
		ptn(ans);
	}
}P5;
int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	rd(n),rd(m),rd(K);
	if(0);
	else if(m<=6)P0.work();
	else if(K==1&&m<=40)P1.work();
	else if(n==1)P2.work();
	else if(m<=340&&n==2)P3.work();
	else if(n==2)P4.work();
	else if(K==998244352&&m<=40)P5.work();
	return 0;
}
