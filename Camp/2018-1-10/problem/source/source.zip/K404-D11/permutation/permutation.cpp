#include<cstdio>
#include<cstring>
#define LL long long
using namespace std;

const int maxn = 100005;
int bas[maxn], ini[maxn];
bool vis[maxn] = {false}, flag[maxn];
LL n, p, ans;

inline void check()
{
	for(int i = 1; i <= n; ++i)
	{
		printf("%d ", bas[i]);
	}
	printf("\n");
	int cnt; 
	memset(flag, false, sizeof(flag));
	for(int i = 1; i <= n; ++i)
	{
		if(flag[i] == false)	
		{
			flag[i] = true; p = i; cnt = 1;
			for(;;)
			{
				if(flag[bas[p]] == true)
				{
					if(cnt % 2 != 0) return;
					break;
				}
				p = bas[p]; cnt++; flag[p] = true;
			}
		}
	}
	ans++;
}

void dfs(int t)
{
	//printf("t == %d\n", t);
	if(t == n + 1)	
	{
		check(); return;
	}
	if(ini[t] != 0)	
	{
		dfs(t + 1);
		return;
	}
	for(int i = 1; i <= n; ++i)
	{
		if(vis[i] == false)
		{
			vis[i] = true; bas[t] = i;
			dfs(t + 1);
			vis[i] = false;
		}
	}
}

int main()
{
	freopen("subsequence.in", "r", stdin);
	freopen("subsequence.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i)
	{
		scanf("%d", &ini[i]);
		if(ini[i] != 0)	bas[i] = ini[i], vis[i] = true;
	}	
	dfs(1);
	printf("%lld", ans);
	return 0;
}
