#include <bits/stdc++.h>
 
using std::pair;
using std::vector;
using std::string;

typedef long long ll;
typedef pair<int, int> pii;
 
#define fst first
#define snd second
#define pb(a) push_back(a)
#define mp(a, b) std::make_pair(a, b)
#define debug(...) fprintf(stderr, __VA_ARGS__)
 
template <typename T> bool chkmax(T& a, T b) { return a < b ? a = b, 1 : 0; }
template <typename T> bool chkmin(T& a, T b) { return a > b ? a = b, 1 : 0; }
 
const int oo = 0x3f3f3f3f;
 
template<typename T> T read(T& x) {
    int f = 1; x = 0;
    char ch = getchar();
    for(;!isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
    for(; isdigit(ch); ch = getchar()) x = x * 10 + ch - 48; 
    return x *= f;
}

const int N = 4000;

int n, m, k;
int a[N + 5], b[N + 5];
int nxta[N + 5][N + 5];
int nxtb[N + 5][N + 5];

int dp[N + 5][N + 5];

int main() {
    freopen("subsequence.in", "r", stdin);
    freopen("subsequence.out", "w", stdout);

    read(n), read(m), read(k);
    for(int i = 1; i <= n; ++i) read(a[i]);
    for(int i = 1; i <= m; ++i) read(b[i]);

    for(int i = 1; i <= k; ++i) nxta[n][i] = n + 1;
    for(int i = n-1; i >= 0; --i) {
        for(int j = 1; j <= k; ++j) nxta[i][j] = nxta[i+1][j]; 
        nxta[i][a[i+1]] = i+1;
    }

    for(int i = 1; i <= k; ++i) nxtb[m][i] = m + 1;
    for(int i = m-1; i >= 0; --i) {
        for(int j = 1; j <= k; ++j) nxtb[i][j] = nxtb[i+1][j];
        nxtb[i][b[i+1]] = i+1;
    }

    memset(dp, oo, sizeof dp);

    dp[n+1][m+1] = 0;
    for(int i = n+1; i >= 0; --i) {
        for(int j = m+1; j >= 0; --j) {
            if(i == n+1 && j == m+1) { dp[i][j] = 0; continue; }
            for(int l = 1; l <= k; ++l) {
                chkmin(dp[i][j], dp[nxta[i][l]][nxtb[j][l]] + 1);
            }
        }
    }
    printf("%d\n", dp[0][0]);

    return 0;
}
