//%std
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
#define lovelive long long
#define lc son[x][0]
#define rc son[x][1]
#define lowbit(x) (x&(-x))
const int N=1e5+7;
void read(int &x)
{
  x=0;
  char c=getchar();
  while(c<'0'||c>'9')
    c=getchar();
  while(c>='0'&&c<='9')
  {
  	x=x*10+c-48;
  	c=getchar();
  }
}
char s[N];
int ct[26];
int main()
{
  freopen("string.in","r",stdin);
  freopen("string.out","w",stdout);
  int T,n,p,tot;
  read(T);
  while(T--)
  {
  	memset(ct,0,sizeof(ct));
  	p=tot=0;
  	read(n);
  	scanf("%s",s+1);
  	for(int i=1;i<=n;i++)
  	  if(s[i]!=s[n+1-i])
  	    {
  	      p=1;
  	      break;
		}
	if(p==1)
	{
	  cout<<"1\n";
	  continue;
	}
	for(int i=1;i<=n;i++)
	{
	  if(!ct[s[i]-'a'])
	    tot++;
	  ct[s[i]-'a']=1;
    }
    if(tot==1)
    {
      cout<<"-1\n";
      continue;
	}
	if(tot==2)
	{
	  p=0;
	  if(n&1)
	  {
	  	for(int i=2;i<=n/2;i++)
	  	  if(s[i]!=s[1])
	  	  {
	  	  	p=1;
	  	  	break;
		  }
		for(int i=2;i<=n/2;i++)
		  if(s[i]==s[i-1]||s[i]==s[i+1])
		  {
		    p=1;
			break; 	
		  }
	  }
	  if(p==1)
	  {
	  	cout<<"-1\n";
	  	continue;
	  }
	}
	cout<<"2\n";
  }
  return 0;
}
/*
2
7
abcdcba
3
xxx
*/
