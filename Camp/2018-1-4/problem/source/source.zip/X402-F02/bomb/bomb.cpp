#include<bits/stdc++.h>
using namespace std;
typedef int sign;
typedef long long ll;
#define For(i,a,b) for(register sign i=(sign)a;i<=(sign)b;++i)
#define Fordown(i,a,b) for(register sign i=(sign)a;i>=(sign)b;--i)
const int N=1e6+5;
bool cmax(sign &a,sign b){return (a<b)?a=b,1:0;}
bool cmin(sign &a,sign b){return (a>b)?a=b,1:0;}
template<typename T>T read()
{
	T ans=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch-'0'),ch=getchar();
	return ans*f;
}
void file()
{
	#ifndef ONLINE_JUDGE
		freopen("bomb.in","r",stdin);
		freopen("bomb.out","w",stdout);
	#endif
}
int n,m;
struct edge
{
	int u,v,nex;
}e[N];
int tt,head[N];
void add(int x,int y)
{
	++tt;e[tt].u=x;e[tt].v=y;e[tt].nex=head[x];head[x]=tt;
}
void input()
{
	int x,y;
	n=read<int>();m=read<int>();
	For(i,1,m)
	{
		x=read<int>();y=read<int>();
		add(x,y);
	}
}
int dp[N],in[N];
int scc[N],id,l[N];
int pre[N],low[N],sum[N];
int dfs_clock,k;
void Tarjan(int u)
{
	int v;
	pre[u]=low[u]=++dfs_clock;
	l[++l[0]]=u;
	for(register int i=head[u];i;i=e[i].nex)
	{
		v=e[i].v;
		if(!pre[v])
		{
			Tarjan(v);
			cmin(low[u],low[v]);
		}
		else if(!scc[v])
		{
			cmin(low[u],pre[v]);
		}
	}
	if(pre[u]==low[u])
	{
		++id;
		while(1)
		{
			k=l[l[0]--];
			scc[k]=id;
			sum[id]++;
			if(k==u)break;
		}
	}
}
int beg[N],nex[N],to[N],cnt;
void add_edge(int x,int y)
{
	++cnt;to[cnt]=y;nex[cnt]=beg[x];beg[x]=cnt;
}
queue<int>q;
bool vis[N];
void tope_dp(int x)
{
	int v,u;
	q.push(x);
	while(!q.empty())
	{
		u=q.front();q.pop();vis[u]=1;
		for(register int i=beg[u];i;i=nex[i])
		{
			v=to[i];
			cmax(dp[v],dp[u]+sum[v]);
			if(!--in[v])q.push(v);
		}
	}
}
void work()
{
	int u,v;
	For(i,1,n)if(!scc[i])Tarjan(i);
	//For(i,1,n)printf("%d %d\n",scc[i],sum[scc[i]]);printf("\n");
	For(i,1,tt)
	{
		u=e[i].u;v=e[i].v;
		if(scc[u]^scc[v])add_edge(scc[u],scc[v]),in[scc[v]]++;
	}
	For(i,1,id)
	{
		if(!in[i]&&!vis[i])
		{
			dp[i]=sum[i];
			tope_dp(i);
		}
	}
	int ans=0;
	For(i,1,n)cmax(ans,dp[i]);
	printf("%d\n",ans);
}
int main()
{
	file();
	input();
	work();
	return 0;
}
