#include<cstdio>
#include<algorithm>
#include<cstring>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
using namespace std;
const int maxn = 1e2 + 5, inf = 0x3f3f3f3f;
int w[maxn], n, vis[maxn], mn, pos;
double self = 0, ans = 0;

int main() {
	freopen("drink.in", "r", stdin);
	freopen("drink.out", "w", stdout);
	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &w[i]);
	For(l, 1, n) {
		For(r, l, n) {
			self = 0;
			memset(vis, 0, sizeof(vis));
			For(c, l, r){
				mn = inf;
				For(p, l, r) 
					if(!vis[p] && mn > w[p]) 
						pos = p, mn = w[p];
				vis[pos] = 1, self = (self + w[pos]) / 2.0;
			}
			ans += self;
		}
	}
	printf("%lf", ans / (n * n));
	return 0;
}
