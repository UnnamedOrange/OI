#include <iostream>
#include <cstring>
#include <cstdio>
#define MOD 998244353
using namespace std;
typedef long long ll;
inline void upd(int &x, int y)
{
	x += y; 
	if (x >= MOD)
		x -= MOD;
}
inline ll quick_pow(ll a, int n)
{
	ll res = 1;
	while (n)
	{
		if (n & 1)
			res = res * a % MOD; 
		a = a * a % MOD; 
		n >>= 1; 
	}
	return res; 
}
namespace brute
{
	int dp[45][45][45], ans[45][45][45]; 
	ll fact[45], inv[45];
	inline void init(int n)
	{
		fact[0] = inv[0] = 1; 
		for (int i = 1; i < 45; i++)
		{
			fact[i] = fact[i - 1] * i % MOD; 
			inv[i] = quick_pow(fact[i], MOD - 2); 
		}
		dp[0][0][0] = 1; 
		for (int i = 0; i < n; i++)
		{
			for (int l = 0; l < n; l++)
			{
				for (int r = l; r < n; r++)
				{
					for (int x = l; x < n; x++)
					{
						for (int y = max(x, r); y < n; y++)
							upd(dp[i + 1][x + 1][y + 1], dp[i][l][r]); 
					}
				}
			}
		}
		for (int t = 0; t <= n; t++)
		{
			for (int i = 0; i <= n; i++)
			{
				for (int j = 0; j <= n; j++)
				{
					for (int x = 0; x <= i; x++)
					{
						for (int y = 0; y <= j; y++)
							upd(ans[i][j][t], dp[t][x][y]); 
					}
				}
			}
		}
	}
	inline ll C(int n, int m)
	{
		if (n < m)
			return 0;
		return fact[n] * inv[m] % MOD * inv[n - m] % MOD;
	}
	inline void solve(int n, int m, int k)
	{
		init(n); 
		ll res = 0; 
		for (int i = 0; i < n; i++)
		{
			for (int j = 1; j <= m; j++)
			{
				ll coef = 0; 
				for (int l = 0; l <= i - j + 1; l++)
				{
					for (int r = i + j; r < n; r++)
					{
						ll sum = 0; 
						for (int x = 0; x <= m - j; x++)
							(sum += (ll)ans[l][i + 1][x]
							 * ans[n - r - 1][n - i - 1][m - j - x]) %= MOD; 
						(coef += sum * C(i - l, j - 1) % MOD * C(r - i - 1, j - 1)) %= MOD; 
					}
				}
				(res += quick_pow(j, k) * coef) %= MOD;
			}
		}
		printf("%lld\n", res); 
	}
}
namespace m1
{
	inline void solve(int n, int m, int k)
	{
		ll ans = 0; 
		for (int i = 1; i < n; i++)
			(ans += (ll)(n - i) * i) %= MOD; 
		printf("%lld\n", ans); 
	}
}
namespace m2
{
	inline ll sum(int n)
	{
		if (n <= 0)
			return 0;
		return (ll)n * (n + 1) / 2; 
	}
	inline void solve(int n, int m, int k)
	{
		ll ans = 0, pre = 0, suf = 0; 
		for (int i = 1; i <= n; i++)
			(suf += sum(n) - sum(i) % MOD + MOD) %= MOD;
		for (int i = 1; i <= n; i++)
		{
			(ans += quick_pow(2, k) * sum(i - 1) % MOD * sum(n - i - 1)) %= MOD; 
			(ans += sum(i - 1) * i % MOD * (n - i)
			- sum(n - i - 1) * i % MOD * i % MOD + MOD) %= MOD;
			(pre += sum(i - 2)) %= MOD; 
			(suf += sum(i) - sum(n) % MOD + MOD) %= MOD;
			(ans += suf * i - pre * (n - i) % MOD + MOD) %= MOD; 
		}
		printf("%lld\n", ans); 
	}
}
int main()
{
	freopen("segment.in", "r", stdin);
	freopen("segment.out", "wt", stdout); 
	int m, n, k; 
	scanf("%d%d%d", &m, &n, &k); 
	if (n <= 40)
	{
		brute::solve(n, m, k); 
		return 0; 
	}
	if (m == 1)
	{
		m1::solve(n, m, k); 
		return 0; 
	}
	if (m == 2)
	{
		m2::solve(n, m, k);
		return 0; 
	}
	puts("0"); 
	return 0; 
}

