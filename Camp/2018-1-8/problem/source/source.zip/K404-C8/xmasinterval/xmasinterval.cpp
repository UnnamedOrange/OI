#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=500005;
typedef long long ll;
const ll mod=1e9+9;
inline void MOD(int &x) {if (x>=mod) x-=mod;}

int read()
{
	int ans;char ch;
	while ((ch=getchar())<'0'||ch>'9');ans=ch-'0';
	while ((ch=getchar())>='0'&&ch<='9') ans=ans*10+ch-'0';
	return ans;
}


struct aa
{
	int l,r;
}t[N];
bool cmp(const aa &a,const aa &b) {return a.l<b.l;}
int n,m,b[N];

int lc[N*2],rc[N*2],pw[N*2],tot=1,sum[N*2];
void build(int u,int l,int r) 
{
	pw[u]=1;
	if (l==0) sum[u]=1;
	if (l==r) return;
	int mid=(l+r)>>1;
	build(lc[u]=++tot,l,mid);
	build(rc[u]=++tot,mid+1,r);
}
int ans;
void down(int u) 
{
	if (pw[u]!=1) 
	{
		pw[lc[u]]=(ll)pw[lc[u]]*pw[u]%mod;
		pw[rc[u]]=(ll)pw[rc[u]]*pw[u]%mod;
		sum[lc[u]]=(ll)sum[lc[u]]*pw[u]%mod;
		sum[rc[u]]=(ll)sum[rc[u]]*pw[u]%mod;
		pw[u]=1;
	}
}
void work(int u,int l,int r,int tl,int tr,int op) 
{
	if (l==tl&&r==tr) 
	{
		if (op==1) MOD(ans+=sum[u]);
		else MOD(pw[u]+=pw[u]),MOD(sum[u]+=sum[u]);
		return ;
	}
	down(u);
	int mid=(l+r)>>1;
	if (tr<=mid) work(lc[u],l,mid,tl,tr,op);
	else if (mid<tl) work(rc[u],mid+1,r,tl,tr,op);
	else work(lc[u],l,mid,tl,mid,op),work(rc[u],mid+1,r,mid+1,tr,op);
	MOD(sum[u]=sum[lc[u]]+sum[rc[u]]);
}
void updata(int u,int l,int r,int p) 
{
	if (l==r) {MOD(sum[u]+=ans);return ;}
	int mid=(l+r)>>1;
	down(u);
	if (p<=mid) updata(lc[u],l,mid,p);
	else updata(rc[u],mid+1,r,p);
	MOD(sum[u]=sum[lc[u]]+sum[rc[u]]);
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	
	n=read(),m=read();
	for (int i=1;i<=n;i++) t[i].l=read(),t[i].r=read();
	for (int i=1;i<=m;i++) b[i]=read();

	sort(b+1,b+m+1);
	m=unique(b+1,b+m+1)-b-1;
	
	for (int i=1;i<=n;i++)
	t[i].l=lower_bound(b+1,b+m+1,t[i].l)-b,
	t[i].r=upper_bound(b+1,b+m+1,t[i].r)-b-1;
	sort(t+1,t+n+1,cmp);
	
	build(1,0,m);
	for (int l,r,i=1;i<=n;i++) 
	{
		l=t[i].l,r=t[i].r;
		work(1,0,m,r,m,2);
		ans=0;
		work(1,0,m,l-1,r-1,1);
		updata(1,0,m,r);
	}
	ans=0;work(1,0,m,m,m,1);
	printf("%d\n",ans);
	return 0;
}
/*
4 4
3 8
1 6
3 8
2 7
8
4
6
3

5 5
1 10
1 10
1 10
1 10
1 10
1 2 3 4 5
*/
