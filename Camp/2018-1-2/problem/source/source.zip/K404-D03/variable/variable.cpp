#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=100100,inf=0X3f3f3f3f;

int n,W,p,q;
int X[N],Y[N],Z[N];
int A[N],B[N],C[N],D[N],E[N],F[N];
int U[N],V[N],opt[N];
int w[N];

namespace violence
{
	int ans;
	
	inline int get_H(int i)
	{
		return
		A[i]*abs(w[X[i]]-w[Y[i]])+B[i]*abs(w[Y[i]]-w[Z[i]])+C[i]*abs(w[Z[i]]-w[X[i]])
		+D[i]*(w[X[i]]-w[Y[i]])+E[i]*(w[Y[i]]-w[Z[i]])+F[i]*(w[Z[i]]-w[X[i]]);
	}
	
	void getans()
	{
		int res=0;
		for(int i=1;i<=n;++i)
			res+=w[i];
		for(int i=1;i<=p;++i)
			res+=get_H(i);
		ans=min(ans,res);
	}
	
	inline bool check()
	{
		for(int i=1;i<=q;++i)
			switch(opt[i])
			{
				case 0:if(w[U[i]]>w[V[i]]) return 0;break;
				case 1:if(w[U[i]]!=w[V[i]]) return 0;break;
				case 2:if(w[U[i]]>=w[V[i]]) return 0;break;
			}
		return 1;
	}
	
	void dfs(int step)
	{
		if(step>n){if(check()) getans();return ;}
		w[step]=W;
		dfs(step+1);
		w[step]=-W;
		dfs(step+1);
	}
	
	void Main()
	{
		ans=inf;
		dfs(1);
		cout<<ans<<endl;
	}
}

int main()
{
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	
	register int T=read(),i;
	while(T--)
	{
		n=read();W=read();p=read();q=read();
		for(i=1;i<=p;++i)
			X[i]=read(),Y[i]=read(),Z[i]=read(),
			A[i]=read(),B[i]=read(),C[i]=read(),
			D[i]=read(),E[i]=read(),F[i]=read();
		for(i=1;i<=q;++i)
			U[i]=read(),V[i]=read(),opt[i]=read();
		violence::Main();
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

