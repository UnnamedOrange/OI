#include<bits/stdc++.h>
#define For(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
int read(){
	int x=0,fh=1; char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') fh=-1;
	for (;isdigit(ch);ch=getchar()) x=x*10+(ch^48);
	return x*fh;
}
int a[4005],b[4005],n,m,k,ans; bool fl[(1<<18)|1];
void dfs(int x,int y,int w){
	if (!y){
		if (!fl[w]) ++ans,fl[w]=1; return;
	}
	if (n-x>=y) dfs(x+1,y,w);
	dfs(x+1,y-1,(w<<1)+a[x]);
}
void dfs2(int x,int y,int w){
	if (!y){
		if (!fl[w]) ++ans,fl[w]=1; return;
	}
	if (m-x>=y) dfs2(x+1,y,w);
	dfs2(x+1,y-1,(w<<1)+b[x]);
}
int main(){
	freopen("subsequence.in","r",stdin); freopen("subsequence.out","w",stdout);
	n=read(),m=read(),k=read(); int r=min(n,m);
	For(i,1,n) a[i]=read(),fl[a[i]]=1,a[i]=(a[i]==2)?0:a[i];
	For(i,1,m) b[i]=read(),fl[b[i]]=1,b[i]=(b[i]==2)?0:b[i];
	For(i,1,k) if (!fl[i]) printf("1\n"),exit(0);
	if (n>18||m>18||k>2) printf("3\n"),exit(0);
	memset(fl,0,k+1);
	For(i,1,r){
		ans=0; dfs(1,i,0); dfs2(1,i,0); memset(fl,0,1<<i);
		if (ans<(1<<i)) printf("%d\n",i),exit(0);
	}
	printf("%d\n",r+1);
	return 0;
}
