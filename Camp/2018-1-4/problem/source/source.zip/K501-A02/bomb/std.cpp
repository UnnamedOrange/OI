#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)
//#define getchar getchar_unlocked

using namespace std;

inline int Read(){
	char c = 0;
	while(c < '0' && c > '9') c = getchar();
	int x = c - '0'; c = getchar();
	while(c <= '9' && c >= '0') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int N = 2e6 + 10;

int Begin[N], Next[N], to[N], e;

void add_edge(int u, int v){
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int n, m, c;
int dfn[N], low[N], bel[N];
int stk[N], sz[N], top;

void Tarjan(int o){
	static int clk = 0;
	dfn[o] = low[o] = ++clk;
	stk[++top] = o;

	for(int i = Begin[o]; i; i = Next[i]){
		int u = to[i];
		if(!dfn[u]) Tarjan(u), low[o] = min(low[o], low[u]);
		else if(!bel[u]) low[o] = min(low[o], dfn[u]);
	}

	if(low[o] == dfn[o]){
		bel[o] = ++c, ++sz[c];
		while(stk[top] ^ o) bel[stk[top--]] = c, ++sz[c];
		--top;
	}
}

int f[N];

int DFS(int o){
	if(f[o]) return f[o];
	f[o] = sz[o];
	for(int i = Begin[o]; i; i = Next[i]){
		int u = to[i];
		f[o] = max(f[o], DFS(u) + sz[o]);
	}
	return f[o];
}

int main(){
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);

	n = Read(), m = Read();
	while(m--){
		int u = Read(), v = Read();
		add_edge(u, v);
	}

	c = n;
	For(i, 1, n) if(!dfn[i]) Tarjan(i);

	For(i, 1, n) for(int j = Begin[i]; j; j = Next[j]){
		int u = bel[i], v = bel[to[j]];
		if(u ^ v) add_edge(u, v);
	}

	int ans = 0;
	For(i, n + 1, c) ans = max(ans, DFS(i));
	printf("%d\n", ans);

	return 0;
}

