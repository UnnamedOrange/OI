#include<cstdio>
#include<vector>
#include<cstring>
#include<queue>
#include<algorithm>
#include<cctype>
using namespace std;

const int maxn = 1e5 + 5, INF = 0x7fffffff, mod = 998244353;
int n, m, k, now, qwe, maxd, ans;
int power[200005], num[maxn], answer[maxn];
vector<int> point[maxn], edge[maxn];
vector<int> dis[maxn];
queue<int> q;

inline int read()
{
	int x = 0, w = 0; char ch = 0;
	while(!isdigit(ch))	
	{
		w |=ch=='-'; ch = getchar(); 
	}
	while(isdigit(ch))
	{
		x = (x << 3) + (x << 1) + (ch ^ 48), ch = getchar();
	}
	return w?-x:x;
}

inline void putit()
{
	int u, v;
	//scanf("%d%d%d", &n, &m, &k);
	n = read(); m = read(); k = read();
	for(int i = 1; i <= m; ++i)
	{
		//scanf("%d%d", &u, &v);
		u = read(); v = read();
		point[u].push_back(v); edge[v].push_back(u);
		num[v]++;
	}
}

inline int mi(int a, int b)
{
	int ret = 1, temp = a;
	while(b)
	{
		if(b & 1 == 1)	ret = ret * temp % mod;
		temp = temp * temp % mod; b = b >> 1;
	}
	return ret;
}

inline void prepare()
{
	power[0] = 0;
	if(k == 1)
	{
		for(int i = 1; i <= 200002; ++i)
		power[i] = i;
		return;
	}
	for(int i = 1; i <= 200002; ++i)
		power[i] = mi(i, k);
}

inline void up_date(int a, int t)
{
	for(int i = dis[a].size() - 1; i >= 0; --i)
	{
		dis[t].push_back(dis[a][i] + 1);
		ans += power[dis[a][i] + 1]; ans %= mod;
	}
}

inline void workk()
{
	q.push(1); dis[1].push_back(0);
	while(!q.empty())
	{
		now = q.front(); q.pop(); ans = 0;
		for(int i = edge[now].size() - 1; i >= 0; --i)
		{
			qwe = edge[now][i];
			up_date(qwe, now);
		}
		answer[now] = ans;
		for(int i = point[now].size() - 1; i >= 0; --i)
		{
			qwe = point[now][i];
			num[qwe]--;
			if(num[qwe] == 0)
			{
				q.push(qwe);
			}
		}
	}
}

inline void print()
{
	for(int i = 1; i <= n; ++i)
	{
		printf("%d\n", answer[i]);
	}
}

int main()
{
	freopen("xmasdag.in", "r", stdin);
	freopen("xmasdag.out", "w", stdout);
	putit();
	prepare();
	workk();
	print();
	return 0;
}
