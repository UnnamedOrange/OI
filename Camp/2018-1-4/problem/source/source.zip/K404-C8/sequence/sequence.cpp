#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<map>
using namespace std;
typedef unsigned long long ull;

map<ull,int> mp;


int n,x[25],ans,y[25];
int f(int n) 
{
	int p,ans=0;
	for (int i=n;i>=1;i--)
	{
		for (int j=1;j<=i;j++) if (x[j]==i) {p=j;break;}
		if (p==i) continue;
		if (p!=1) ans++;
		for (int j=1;j<=p/2;j++) swap(x[j],x[p-j+1]);
		ans++;
		for (int j=1;j<=i/2;j++) swap(x[j],x[i-j+1]);
	}
	return ans;
}
int dfs(int step,int n,int last) 
{
	if (step>=ans) return 1e9;
	if (n==0) {ans=step;return 0;}
	
	ull hs=0;
	for (int i=1;i<=n;i++) hs=hs*(n+1)+y[i];
	if (mp.count(hs)) return mp[hs];
	
	int tmp=1e9;
	for (int j=1;j<=n/2;j++) swap(y[j],y[n-j+1]);
	int t=n;while (y[t]==t&&t)  t--;
	tmp=min(dfs(step+1,t,0)+1,tmp);
	for (int j=1;j<=n/2;j++) swap(y[j],y[n-j+1]);

	for (int i=2;i<n;i++) if (i!=last)  
	{
		for (int j=1;j<=i/2;j++) swap(y[j],y[i-j+1]);
		tmp=min(dfs(step+1,n,i)+1,tmp);
		for (int j=1;j<=i/2;j++) swap(y[j],y[i-j+1]);
	}

	return mp[hs]=tmp;
}

void work()
{
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d",&y[i]),x[i]=y[i];
	while (y[n]==n&&n) n--;
	ans=f(n);
	ans=min(dfs(0,n,0),ans);
	printf("%d\n",ans);
}

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) work();
	return 0;
}
/*
100
20
13 14 1 16 10 6 17 9 15 2 7 18 3 8 19 4 5 20 12 11 
*/
