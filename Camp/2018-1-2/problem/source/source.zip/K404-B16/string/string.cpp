#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

const int SN = 15;
const int N = 100010;
int n;
int f[SN][SN];
char s[N];
char ss[N];

bool check(int a, int b, int c, int d) {
	int t = 0, i, j;
	rep(i, a, b) ss[++t] = s[i];
	rep(i, c, d) ss[++t] = s[i];
	rep(i, 1, t)
	if(ss[i] != ss[t+1-i]) return 1;
	return 0;
}

void solve_small() {
	int len, i, j, ii, jj;
	rep(len, 1, n) 
		rep(i, 1, n-len+1) {
			j = i + len - 1;
			if(check(i, j, j+1, j)) f[i][j] = 1; else f[i][j] = 20;
			rep(ii, i, j) {
				rep(jj, ii+1, j) {
					if(check(i, ii-1, jj+1, j)) f[i][j] = min(f[i][j], f[ii][jj] + 1);
				}
			}
		}
	if(f[1][n] == 20) puts("-1");
	else printf("%d\n", f[1][n]);
}

void solve_luc() {
	if(check(1, n, n+1, n)) {puts("1"); return;}
	int t = n / 2, i; bool flag;
	flag = 1;
	rep(i, 1, n) if((i&1) && s[i] != s[1]) flag = 0;
	rep(i, 1, n) if(!(i&1) && s[i] != s[2]) flag = 0;
	if(flag) {puts("-1"); return;}
	flag = 1;
	rep(i, 1, t) if(s[i] != s[1]) flag = 0;
	rep(i, n-t+1, t) if(s[i] != s[1]) flag = 0;
	if(flag) {puts("-1"); return;}
	puts("2");
}

int main() {
	freopen("string.in", "r", stdin); freopen("string.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--) {
		scanf("%d", &n);
		scanf("%s", s+1);
		if(n <= 10) solve_small();
		else solve_luc();
	}
	return 0;
}
