//1--Alice
//2--Bob
//3--����
//4--����
//1&1=1
//1&2=3
//1&3=1
//1&4=4
//2&2=2 
//2&3=2
//2&4=2
//3&3=3
//3&4=3
//4&4=4
#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int com[5][5];
int Ans[5];
int n,a,b;
int judge[100010];
int x[100010];
void Dfs(int step,int now)
{
	if (step==n+1)
	{
		++Ans[now];
		return;
	}
	Dfs(step+1,com[now][judge[step+1]]);
	Dfs(step+1,now);
}

int check(int x)
{
	if (x%(a+b)>=a && x%(a+b)<b) return 1;
	if (x%(a+b)>=b && x%(a+b)<a) return 2;
	if (x%(a+b)==0) return 4;
	return 3;
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	com[1][2]=com[2][1]=com[3][4]=com[4][3]=com[3][3]=3;
	com[1][3]=com[3][1]=com[1][1]=1;
	com[1][4]=com[4][1]=com[4][4]=4;
	com[2][3]=com[3][2]=com[2][4]=com[4][2]=com[2][2]=2;
	scanf("%d%d%d",&n,&a,&b);
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&x[i]);
		judge[i]=check(x[i]);
	}
	Dfs(1,4);
	Dfs(1,judge[1]);
	printf("%d %d %d %d\n",Ans[1],Ans[2],Ans[3],Ans[4]);
	return 0;
}
