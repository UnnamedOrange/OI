#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("sequence.in","w",stdout);
	cout << 1 << endl;
	int n=22;
	cout << n << endl;
	int a[100];
	for (int i=1;i<=n;i++) a[i]=i;
	//unsigned seed = std::chrono::system_clock::now ().time_since_epoch ().count (); 
	shuffle(a+1,a+n+1,default_random_engine(time(0)));
	for (int i=1;i<=n;i++) cout << a[i] << " ";
	cout << endl;
	return 0;
}
