#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
const int maxn=1e5+10;
const int mod=1e9+7;
int sum[maxn],q[maxn];
int sum1,sum2,sum3,sum4,a,b,n;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
inline ll qpow(ll a,ll b){
	ll ans=1ll;
	while(b){
		if(b & 1)ans=ans*a%mod;
		a=a*a%mod;
		b/=2;
	}
	return ans;
}
int check(bool flag){
	int i,p=(flag==1?a:b);
	for(i=1;i<=n;i++){
		if(sum[i]>=p && q[i]){
			sum[i]-=p;
			if(!check(flag^1)){
				sum[i]+=p;
				return 1;
			}
			else sum[i]+=p;
		}
	}
	return 0;
}
void dfs(int cur,int goal){
	int i;
	if(cur>goal){
		int ans1=check(1);int ans2=!check(0);
		if(ans1==0 && ans2==0)sum2++;
		if(ans1==0 && ans2==1)sum4++;
		if(ans1==1 && ans2==0)sum3++;
		if(ans1==1 && ans2==1)sum1++;
		return;
	}
	q[cur]=1;
	dfs(cur+1,goal);
	q[cur]=0;
	dfs(cur+1,goal);
}
int main(){
	int i,j,k,m;
#ifndef ONLINE_JUDGE
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
#endif
	n=read();a=read();b=read();
	for(i=1;i<=n;i++)sum[i]=read();
	if(a==b){
		int cnt1=0,cnt2=0;
		for(i=1;i<=n;i++){
			sum[i]%=(a+b);
			if(sum[i]<a)cnt1++;
			else cnt2++;
		}
		if(cnt2==0)printf("0 0 0 %lld\n",qpow(2,n));
		else printf("0 0 %lld %lld\n",qpow(2,n-1),qpow(2,n-1));
		return 0;
	}
	dfs(1,n);
	printf("%d %d %d %d\n",sum1,sum2,sum3,sum4);
	return 0;
}
