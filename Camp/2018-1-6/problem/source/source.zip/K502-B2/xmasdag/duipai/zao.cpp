#include<cstdio>
#include<cstring>
#include<ctime>
#include<cstdlib>
#include<iostream>
#include<algorithm>
using namespace std;

int main(){
	freopen("xmasdag.in","w",stdout);
	srand(time(NULL));
	int n=2000,m=5000,K=rand()%20+rand()%10+1;
	printf("%d %d %d\n",n,m,K);
	for(int i=1;i<n;i++)printf("%d %d\n",i,i+1);
	for(int i=n,x;i<=m;i++){
		x=rand()%n+1;
		printf("%d %d\n",rand()%x+1,x);
	}
	return 0;
}
