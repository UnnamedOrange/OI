#include<iostream>
#include<cstdio>
#define maxn 1000010
#ifdef WIN32
#define PLL "%I64d"
#else 
#define PLL "%lld"
#endif
using namespace std;
int p[maxn],t[maxn],d[maxn],cnt,n,mu[maxn];
long long sum[maxn];
bool vis[maxn];
void prepare(){
	mu[1]=1;d[1]=1;
	for(int i=2;i<=1000000;i++){
		if(!vis[i]){p[++cnt]=i;d[i]=2;t[i]=1;mu[i]=-1;}
		for(int j=1;j<=cnt&&i*p[j]<=1000000;j++){
			vis[i*p[j]]=1;
			if(i%p[j]==0){
				d[i*p[j]]=d[i]/(t[i]+1)*(t[i]+2);
				t[i*p[j]]=t[i]+1;
				mu[i*p[j]]=0;
				break;
			}
			else{
				d[i*p[j]]=d[i]*2;
				t[i*p[j]]=1;
				mu[i*p[j]]=-mu[i];
			}
		}
	}
	for(int i=1;i<=1000000;i++)sum[i]=sum[i-1]+1LL*d[i]*d[i];
}
int main(){
	freopen("function.in","r",stdin);freopen("function.out","w",stdout);
//	freopen("Cola.txt","r",stdin);
	int T;scanf("%d",&T);
	if(T==0)return 0;
	prepare();
	while(T--){
		scanf("%d",&n);
		long long ans=0;
		for(int i=1;i<=n;i++){
			ans+=1LL*mu[i]*sum[n/i];
		}
		printf(PLL"\n",ans);
	}
	return 0;
}
