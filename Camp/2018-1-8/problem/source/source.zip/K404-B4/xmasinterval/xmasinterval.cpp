#include <bits/stdc++.h>
#define getchar() *(pp++)
#define MOD 1000000009
using namespace std;
char buf[25000100],*pp=buf;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')x=x*10+ch-'0',ch=getchar();
	return x;
}
int n,m,x[500010],y[500010],a[500010],t[500010];
pair<int,int> p[500010];
inline int query(int x)
{
	int ret=0;
	while(x)ret=(ret+t[x])%MOD,x-=x&-x;
	return ret;
}
inline int change(int x,int y)
{
	while(x<=n+1)t[x]=(t[x]+y)%MOD,x+=x&-x;
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	fread(buf,sizeof(char),sizeof(buf),stdin);
	n=read();
	m=read();
	for(int i=1;i<=m;i++)
	{
		x[i]=read();
		y[i]=read();
	}
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=m;i++)
	{
		p[i]=make_pair(lower_bound(a+1,a+n+1,x[i])-a,upper_bound(a+1,a+n+1,y[i])-a-1);
	}
	sort(p+1,p+m+1);
	t[1]=1;
	for(int i=1;i<=m;i++)
	{
		int temp=query(p[i].first);
		change(p[i].first,temp);
		change(p[i].second+2,MOD-temp);
	}
	cout<<query(n+1)<<endl;
}
/*
4 4
3 8
1 6
3 8
2 7
8 4 6 3
*/
