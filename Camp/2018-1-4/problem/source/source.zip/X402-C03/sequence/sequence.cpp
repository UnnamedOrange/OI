#include<bits/stdc++.h>
using namespace std;

const int maxn=23+10;
int t,n,a[maxn],ans;

inline int f(){
	int res=0;
	for(int i=1;i<=n;++i)
		if(abs(a[i+1]-a[i])!=1)
			++res;
	return res;
}
inline bool dfs(int rest){
	if(f()>rest)
		return false;
	if(!rest)
		return true;
	for(int i=n;i;--i){
		reverse(a+1,a+i+1);
		if(dfs(rest-1))
			return true;
		reverse(a+1,a+i+1);
	}
	return false;
}

int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;++i)
			scanf("%d",&a[i]);
		a[n+1]=n+1;
		for(ans=0;;++ans)
			if(dfs(ans))
				break;
		printf("%d\n",ans);
	}
	return 0;
}
