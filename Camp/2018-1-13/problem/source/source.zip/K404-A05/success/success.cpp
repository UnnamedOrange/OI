//by yjz
#include<bits/stdc++.h>
using namespace std;
#define FF first
#define SS second
#define PB push_back
#define MP make_pair
#define bged(v) (v).begin(),(v).end()
#define foreach(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)
typedef long long ll;
const int Imx=2147483647;
const ll Lbig=2e18;
const int mod=1e9+7;
ll qpow(ll x,ll k){return k==0?1:qpow(x*x%mod,k>>1)*(k&1?x:1)%mod;}
ll n,m,s,t;
const int cmx=1000111;
ll fac[cmx],ifac[cmx];
ll C(ll x,ll y){return x<y||min(x,y)<0?0:fac[x]*ifac[y]%mod*ifac[x-y]%mod;}
int tc[1011];
void upd(int &x,int v){x=x+v>=mod?x+v-mod:x+v;}
void multi(int a[],int b[],int c[])
{
	for(int i=0;i<=m;i++)
	{
		tc[i]=0;
		for(int j=0;j<=i;j++)
		{
			upd(tc[i],1ll*a[j]*b[i-j]%mod);
		}
	}
	for(int i=0;i<=m;i++)c[i]=tc[i];
}
int pw_a[1011];
void qpow(int a[],ll k,int b[])
{
	pw_a[0]=1;
	for(int i=1;i<=m;i++)pw_a[i]=0;
	while(k)
	{
		if(k&1)multi(pw_a,a,pw_a);
		k>>=1;
		multi(a,a,a);
	}
	for(int i=0;i<=m;i++)b[i]=pw_a[i];
}
int a[1011];
int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	fac[0]=1;
	for(int i=1;i<cmx;i++)fac[i]=fac[i-1]*i%mod;
	ifac[cmx-1]=qpow(fac[cmx-1],mod-2);
	for(int i=cmx-2;i>=0;i--)ifac[i]=ifac[i+1]*(i+1)%mod;
	cin>>s>>t>>n>>m;
	m-=n;
	s-=n*t;
	for(int i=0;i<=m;i++)a[i]=C(t,i+1);
	qpow(a,n,a);
	ll ans=0;
	ll prod=1;
	s%=mod;
//	cerr<<s<<" "<<t<<" "<<n<<" "<<m<<endl;
	for(int i=0;i<=m;i++)
	{
//		cerr<<"i="<<i<<" "<<prod<<" "<<a[m-i]<<endl;
		ans+=prod*ifac[i]%mod*a[m-i]%mod;
		prod=prod*(s-i+mod)%mod;
	}
	cout<<(ans%mod+mod)%mod<<endl;
	return 0;
}
