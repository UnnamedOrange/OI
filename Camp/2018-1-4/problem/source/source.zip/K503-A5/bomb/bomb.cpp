#include <bits/stdc++.h>
using namespace std;
template <typename T> void read(T &x) {
	x=0;char c=getchar();
	while (!isdigit(c)) {c=getchar();}
	while (isdigit(c)) {x=x*10+c-'0';c=getchar();}
}
int n, m;
struct Edge {
	int v;
	Edge *nxt;
} pool[2000010], *tail = pool, *g[1000010], *G[1000010];
int dfn[1000010], low[1000010], index, clr[1000010], tot, val[1000010], f[1000010];
stack<int> stk;
inline void addedge(const int &u, const int &v) {
	tail->v = v;
	tail->nxt = g[u], g[u] = tail++;
}
inline void addedge2(const int &u, const int &v) {
	tail->v = v;
	tail->nxt = G[u], G[u] = tail++;
}
void tarjan(int x) {
	dfn[x]=low[x]=++index;
	stk.push(x);
	for (Edge *p=g[x];p;p=p->nxt) {
		if (!dfn[p->v]) {
			tarjan(p->v);
			low[x]=min(low[x],low[p->v]);
		} else {
			low[x]=min(low[x],dfn[p->v]);
		}
	}
	if (dfn[x]==low[x]) {
		tot++;
		while (stk.top()!=x) {
			int tmp=stk.top();
			stk.pop();
			clr[tmp]=tot;
		} 
		clr[stk.top()]=tot;
		stk.pop();
	}
}
int dp(int x) {
	if (f[x]) return f[x];
	for (Edge *p=G[x];p;p=p->nxt) {
		f[x]=max(f[x],dp(p->v));
	}
	f[x]+=val[x];
	return f[x];
}
int main() {
	//freopen("bomb.in","r",stdin);
	//freopen("bomb.out","w",stdout);
	read(n), read(m);
	for (int i=1;i<=m;i++) {
		int u,v;
		read(u), read(v);
		addedge(u,v);
	}
	for (int i=1;i<=n;i++) {
		if (dfn[i]==0) tarjan(i);
	}
	/*for (int i=1;i<=n;i++) {
		cout << clr[i] << " ";
	}
	cout << endl;*/
	for (int i=1;i<=n;i++) {
		val[clr[i]]++;
	}
	/*for (int i=1;i<=tot;i++) {
		cout << val[i] << " ";
	}
	cout << endl;*/
	for (int i=1;i<=n;i++) 
		for (Edge *p=g[i];p;p=p->nxt) 
			if (clr[i]!=clr[p->v]) 
				addedge2(clr[i],clr[p->v]); //is it zheng ans fan the same?
	int ans=0; 
	/*for (int i=1;i<=tot;i++) {
		cout << i << ": ";
		for (Edge *p=G[i];p;p=p->nxt) {
			cout << p->v << " ";
		}
		cout << endl;
	}*/
	for (int i=1;i<=tot;i++) ans=max(ans,dp(i));
	cout << ans << endl;
	return 0;
}
