#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <stack>
using namespace std;
const int Maxn = 2000000 + 100;
int Begin[Maxn], To[Maxn * 2], Next[Maxn * 2], e;
int Vis[Maxn];
int N, M;
inline void add_edge(int x, int y)
{
	To[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e; 
}
int dfn[Maxn], low[Maxn], Index, Instack[Maxn];
int scc_cnt, color[Maxn], scc_sum[Maxn];
stack <int> S;
inline void tarjan(int x)
{
	dfn[x] = low[x] = ++Index;
	S.push(x);
	Instack[x] = 1;
	for (int i = Begin[x]; i; i = Next[i])
	{
		int y = To[i];
		if (!dfn[y])
		{
			tarjan(y);
			low[x] = min(low[x], low[y]);
		}
		else if(Instack[y])
			low[x] = min(low[x], dfn[y]);
	}
	if (low[x] == dfn[x])
	{
		++scc_cnt;
		while (1)
		{
			int a = S.top(); S.pop();
			Instack[a] = 0;
			scc_sum[scc_cnt] ++;
			color[a] = scc_cnt;
			if (x == a) break;
		}
	}
}
int Begin1[Maxn], To1[Maxn * 2], Next1[Maxn * 2], e1;
inline void add_edge1(int x, int y)
{
	To1[++e1] = y;
	Next1[e1] = Begin1[x];
	Begin1[x] = e1;
}
int Ans = 0, Dis[Maxn];
inline void dfs(int x)
{
	if (Vis[x]) return ;
	Vis[x] = 1;
	int Sum = scc_sum[x];
	for (int i = Begin1[x]; i; i = Next1[i])
	{
		int y = To1[i];
		dfs(y);
		Sum = max(Sum, Dis[y] + scc_sum[x]);
	}
	Dis[x] = Sum;
}
int main()
{
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	scanf("%d%d", &N, &M);
	for (int i = 1; i <= M; ++i)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		add_edge(x, y);
	}
	for (int i = 1; i <= N; ++i)
		if (!dfn[i])
			tarjan(i);
	for (int i = 1; i <= N; ++i)
		for (int j = Begin[i]; j; j = Next[j])
			if (color[To[j]] != color[i])
				add_edge1(color[i], color[To[j]]);
	for (int i = 1; i <= scc_cnt; ++i)
	{
		if (!Vis[i]) dfs(i);
		Ans = max(Ans, Dis[i]);
	}
	cout<<Ans<<endl;
	return 0;
}
