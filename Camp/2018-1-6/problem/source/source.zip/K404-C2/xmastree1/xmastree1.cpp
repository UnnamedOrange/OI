#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cctype>
#include<set>
#define rep(i,x,y) for(int i=x; i<=y; ++i)
#define repd(i,x,y) for(int i=x; i>=y; --i)

using namespace std;
const int N=100005;
int n,q,tp,h[N],f[N],a[N],c[N],ans,cnt,x,ql,qr,T;
struct edge{int v,n;} e[N<<1];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void addedge(int u,int v)
{
	e[cnt]=(edge){v,h[u]},h[u]=cnt++;
	e[cnt]=(edge){u,h[v]},h[v]=cnt++;
}

void dfs(int x,int fa)
{
	f[x]=fa;
	for(int i=h[x]; i!=-1; i=e[i].n)
		if(e[i].v!=fa) dfs(e[i].v,x);
}

void query(int x)
{
	if(a[x]>=ql && a[x]<=qr)
	{
		if(!c[a[x]]) ++ans;
		++c[a[x]];
	}
	for(int i=h[x]; i!=-1; i=e[i].n)
		if(e[i].v!=f[x]) query(e[i].v);
}

int main()
{
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	n=getint(),q=getint(),T=getint();
	memset(h,-1,sizeof(h));
	rep(i,1,n) a[i]=getint();
	rep(i,1,n-1) addedge(getint(),getint());
	dfs(1,0);
	while(q--)
	{
		tp=getint();
		if(tp==1)
		{
			x=getint()^(ans*T),ql=getint()^(ans*T),qr=getint()^(ans*T),ans=0;
			memset(c,0,sizeof(c)),query(x),printf("%d\n",ans);
		}
		else
			x=getint()^(ans*T),a[x]=getint()^(ans*T);
	}
	return 0;
}
