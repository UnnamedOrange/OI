《算法竞赛入门经典——训练指南》代码仓库

第二章习题代码

注意：有些题目并没有在书中出现，但是仍然有一定的启发意义，所以一并放在这里，供读者参考。

基础练习 （Basic Problems）
UVa11388 GCD LCM 刘汝佳
UVa11526 H(n) 刘汝佳
UVa11609 Teams 刘汝佳

组合计数 （Counting）
UVa10079  Pizza Cutting 陈锋
UVa10081  Tight words 陈锋
UVa10157  Expressions 陈锋
UVa10497  Sweet Child Makes Trouble 陈锋
Uva10883  Supermean 陈锋
Uva1510   Neon Sign 陈锋
UVa11137  Ingenuous Cubrency 刘汝佳（书上例子，包含时间复杂度不同的两个算法）
UVa11174  Stand in a Line 刘汝佳（书上例子）
UVa11375  Matches 刘汝佳（书上例子）

数论 （Number Theory）
UVa11718 Fantasy of a Summation 刘汝佳
UVa11440 Help Mr. Tomisu 刘汝佳

概率 （Probability）
UVa11637 Garbage Remembering Exam 刘汝佳
UVa11971 Polygon 刘汝佳
