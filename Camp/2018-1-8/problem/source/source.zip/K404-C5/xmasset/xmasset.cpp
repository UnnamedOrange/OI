#include<bits/stdc++.h>
using namespace std;
inline int rd(){
	char ch=getchar();int i=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0';ch=getchar();}
	return i*f;
}
int type,T,n,lim;
inline int encode(int x,int y){
	for(int i=0;i<=9;i++){
		int t1=(1<<i)&x,t2=(1<<i)&y;
		if(t1!=t2)return (t1?1:0)*10+i;
	}
}
inline bool decode(int q,int h){
	int t1=h/10,t2=h%10;
	return (q&(1<<t2))==(t1<<t2);
}
int main() {
    int T; type=rd(),n=rd(),T=rd();
    while (T--) {
        int x=rd(),y=rd();
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
