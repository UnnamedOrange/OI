#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string>
#include<bitset>
#include<queue>
#include<map>
#include<set>
using namespace std;

typedef long long ll;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void print(int x)
{if(x<0)putchar('-'),x=-x;if(x>=10)print(x/10);putchar(x%10+'0');}

const int N=1001000,mod=1000000007;

int fac[N],inv[N];

void initial()
{
	register int i;
	fac[0]=1;for(i=1;i<N;++i) fac[i]=1ll*fac[i-1]*i%mod;
	inv[1]=1;for(i=2;i<N;++i) inv[i]=1ll*(mod-mod/i)*inv[mod%i]%mod;
	inv[0]=1;for(i=1;i<N;++i) inv[i]=1ll*inv[i-1]*inv[i]%mod;
}

inline int C(int n,int m)
{return 1ll*fac[n]*inv[m]%mod*inv[n-m]%mod;}

ll S;
int T,n,m;

int f[N];

int main()
{
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	
	scanf("%lld%d%d%d",&S,&T,&n,&m);
	if(S<m){puts("0");return 0;}
	initial();
	S-=m;T--;
	f[0]=1;
	register int i,j,k;
	for(i=1;i<=n;++i)
		for(j=S;j;j--)
			for(k=1;k<=T&&j-k>=0;++k)
				(f[j]+=f[j-k])%=mod;
	int ans=0;
	for(i=0;i<=S;++i)
		for(j=S-i;~j;j--)
			(ans+=1ll*f[i]*C(m-n+j-1,m-n-1)%mod)%=mod;
	cout<<ans<<endl;
	return 0;
}

