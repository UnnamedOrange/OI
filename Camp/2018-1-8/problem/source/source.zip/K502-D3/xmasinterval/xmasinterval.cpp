#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#define ele int
#define ll long long
using namespace std;
#define maxn 1500010
#define MOD 1000000009
struct seg{
	ele l,r;
	inline bool operator<(seg b)const{
		return r<b.r;
	}
};
ele n,m,len,ct,x[maxn],arr[maxn],f[maxn];
vector<seg> il[maxn];
seg s[maxn];
inline ele idx(ele x){
	return lower_bound(arr,arr+len,x)-arr+1;
}
int main(){
	freopen("xmasinterval.in","r",stdin); freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	len=0;
	for (int i=0; i<n; ++i) scanf("%d%d",&s[i].l,&s[i].r),arr[len++]=s[i].l,arr[len++]=s[i].r;
	for (int i=0; i<m; ++i) scanf("%d",x+i),arr[len++]=x[i];
	sort(arr,arr+len);
	len=unique(arr,arr+len)-arr;
	sort(x,x+m);
	m=unique(x,x+m)-x;
	for (int i=0; i<m; ++i) x[i]=idx(x[i]);
	for (int i=0; i<n; ++i){
		s[i].l=idx(s[i].l),s[i].r=idx(s[i].r);
		il[s[i].l].push_back(s[i]);
	}
	for (int i=1; i<=len; ++i) sort(il[i].begin(),il[i].end());
	f[0]=1;
	for (int i=1; i<=len; ++i){
		ele ct=1;
		ele k=upper_bound(x,x+m,i)-x-1;
		if (k>=0){
			for (int j=i; j>x[k]; --j)
				for (int r=0; r<il[j].size(); ++r) (ct<<=1)%=MOD;
			f[i]=0;
			for (int j=x[k]; ~j; --j){
				if (!il[j].size()) continue;
				ele ct1=1;
				for (int r=0; r<il[j].size(); ++r,(ct1<<=1)%=MOD)
					if (il[j][r].r>=x[k]) (f[i]+=(ll)ct*ct1%MOD*f[j-1]%MOD)%=MOD;
				for (int r=0; r<il[j].size(); ++r)
					if (il[j][r].r<x[k]) ct<<=1;
			}
		}
		else{
			f[i]=1;
			for (int j=0; j<=i; ++j)
				for (int r=0; r<il[j].size(); ++r) (f[i]<<=1)%=MOD;
		}
	}
	printf("%d\n",f[len]);
	return 0;
}