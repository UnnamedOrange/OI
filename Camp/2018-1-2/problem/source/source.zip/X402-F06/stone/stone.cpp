#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
const int maxn=1e5+10,mod=1e9+7;
int a[maxn];
int ksm(int x,int y){
	int num=1;
	while(y){
		if(y&1) num=1ll*num*x%mod;
		y>>=1;
		x=1ll*x*x%mod;
	}
	return num;
}
int n,A,B;
int dp[6][6][6][6][6][2];
int p[2][2];
bool dfs(int *b,int flag){
	if(~dp[b[1]][b[2]][b[3]][b[4]][b[5]][flag]) return dp[b[1]][b[2]][b[3]][b[4]][b[5]][flag];
	if(!b[1] && !b[2] && !b[3] && !b[4] && !b[5]) return dp[0][0][0][0][0][flag]=0;
	int x=A;
	if(flag) x=B;
	REP(i,1,5){
		if(b[i]<x) continue;
		b[i]-=x;
		if(!dfs(b,flag^1)){
			b[i]+=x;
			return dp[b[1]][b[2]][b[3]][b[4]][b[5]][flag]=1;
		}
		b[i]+=x;
	}
	return dp[b[1]][b[2]][b[3]][b[4]][b[5]][flag]=0;
}
int ty[21];
int main(){
#ifndef ONLINE_JUDGE
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
#endif
	n=read(),A=read(),B=read();
	REP(i,1,n) a[i]=read();
	p[1][1]=3;
	p[1][0]=1;
	p[0][1]=2;
	p[0][0]=4;
	if(A==B){
		int n1=0,n2=0;
		REP(i,1,n) if((a[i]/A)&1) ++n1;else ++n2;
		int num=ksm(2,n-1);
		if(n1) printf("0 0 %d %d\n",num,num);
		else printf("0 0 0 %lld\n",2ll*num%mod);
		return 0;
	}
	if(n<=5){
		memset(dp,-1,sizeof(dp));
		int ans[5],b[6];
		memset(ans,0,sizeof(ans));
		REP(i,0,(1<<n)-1){
			REP(j,1,5) if(i&(1<<j-1)) b[j]=a[j];else b[j]=0;
			ans[p[dfs(b,0)][dfs(b,1)]]++;
		}
		printf("%d %d %d %d\n",ans[1],ans[2],ans[3],ans[4]);
		return 0;
	}
	return 0;
}
