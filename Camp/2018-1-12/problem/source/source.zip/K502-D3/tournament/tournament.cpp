#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#define ele int
#define ll long long
#define fi first
#define se second
using namespace std;
#define maxn 11
#define MOD 998244353
ele n,k,top,ans,stk[maxn],d[maxn];
bool flag,instack[maxn],vis[maxn],g[maxn][maxn];
vector<pair<ele,ele> > v;
void dfs1(ele i){
	if (flag) return;
	stk[top++]=i; instack[i]=true; vis[i]=true;
	for (int j=0; j<n; ++j)
		if (g[i][j]){
			if (!instack[j]) d[j]=d[i]+1,dfs1(j);
			else if (instack[j]){
				if (d[i]-d[j]==k-1) flag=true;
			}
		}
	--top; instack[i]=false;
}
void dfs(ele i){
	if (i==v.size()){
		flag=false; memset(vis,0,sizeof(vis)); memset(instack,0,sizeof(instack));
		for (int j=0; j<n; ++j){
			d[j]=0;
			dfs1(j);
		}
		if (flag) (ans+=1)%=MOD;
		return;
	}
	g[v[i].fi][v[i].se]=true;
	g[v[i].se][v[i].fi]=false;
	dfs(i+1);
	g[v[i].fi][v[i].se]=false;
	g[v[i].se][v[i].fi]=true;
	dfs(i+1);
}
inline ele pw(ele a,ele x){
	ele ans=1,tmp=a%MOD;
	for (; x; x>>=1,tmp=(ll)tmp*tmp%MOD)
		if (x&1) ans=(ll)ans*tmp%MOD;
	return ans;
}
int main(){
	freopen("tournament.in","r",stdin); freopen("tournament.out","w",stdout);
	scanf("%d%d",&n,&k);
	if (k>3){
		for (int i=0; i<n; ++i)
			for (int j=i+1; j<n; ++j) v.push_back(make_pair(i,j));
		memset(instack,0,sizeof(instack));
		ans=0;
		dfs(0);
		printf("%d\n",ans);
	}
	else{
		ele t=(ll)n*(n-1)/2%(MOD-1);
		ele t1=pw(2,t),t2=1;
		for (int i=2; i<=n; ++i) t2=(ll)t2*i%MOD;
		(t1+=MOD-t2)%=MOD;
		printf("%d\n",t1);
	}
	return 0;
}