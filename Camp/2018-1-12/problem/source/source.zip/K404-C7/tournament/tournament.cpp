#include <bits/stdc++.h>
using namespace std;

const int MOD = 998244353;
int n, k;
int route[10][10];

bool Dfs(int p, int s, int d = 0) {
	if (d == k) {
		if (p == s) {
			return true;
		} else {
			return false;
		}
	}
	for (int i = 1; i <= n; ++i) {
		if (route[p][i]) {
			if (Dfs(i, s, d + 1)) {
				return true;
			}
		}
	}
	return false;
}

int main() {
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	cin >> n >> k;
	int mask = 1 << ((n * (n - 1)) >> 1);
	int ans = 0;
	for (int i = 0; i < mask; ++i) {
		int f = i;
		for (int j = 1; j <= n; ++j) {
			for (int k = j + 1; k <= n; ++k) {
				route[j][k] = f & 1;
				f >>= 1;
				route[k][j] = !route[j][k];
			}
		}
		int ok = 0;
		for (int j = 1; j <= n; ++j) {
			if (Dfs(j, j)) {
				ok = 1;
				break;
			}
		}
		ans += ok;
	}
	cout << ans;
}
