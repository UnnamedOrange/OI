#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<iostream>
#include<ctime>
using namespace std;
const int mod=998244353;
int fpow(int a,int x){
	int rs=1;
	for(;x;x>>=1){
		if(x&1)rs=1ll*rs*a%mod;
		a=1ll*a*a%mod;
	}
	return rs;
}
int f[100010];int deg[100010],fa[100010],n;
char co[100010];
struct edge{int to;edge*next;}e[200010],*et=e,*last[100010];
void add(int u,int v){
	*++et=(edge){v,last[u]},last[u]=et;
	*++et=(edge){u,last[v]},last[v]=et;
	deg[u]++,deg[v]++;
}
double g[100010];
void dfs(int u,int fa){
	f[u]=1;g[u]=1;
	if(deg[u]==1)return;
	int p=fpow(deg[u]-(!!fa),mod-2);//double pp=1.0/(deg[u]-(!!fa));
	for(edge *it=last[u];it;it=it->next){
		if(it->to!=fa){
			dfs(it->to,u);
			int du=deg[u]-(!!fa),dv=deg[it->to];
			int v=(co[u]+co[it->to]); 
			f[u]=(f[u]+1ll*p*f[it->to])%mod;
			//g[u]=(g[u]+pp*g[it->to]);
			if(deg[it->to]>1){
				f[u]=(f[u]+1ll*fpow((1ll*du*dv)%mod,mod-2)*v)%mod;
				//g[u]=(g[u]+1.0/(1ll*du*dv)*v);
				if(!co[it->to]){
					f[u]=(f[u]+1ll*fpow((1ll*du*dv-1)%mod,mod-2)*(1ll-p+mod)%mod);
					//g[u]+=1.0/(1ll*du*dv-1)*(1-pp);	
				}
			}
		}
	}
}
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	scanf("%d",&n);scanf("%s",co+1);
	for(int i=1;i<=n;++i)co[i]-='0'; 
	for(int i=1;i<n;++i){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	dfs(1,0);
	printf("%d\n",f[1]);
	return 0;
}
