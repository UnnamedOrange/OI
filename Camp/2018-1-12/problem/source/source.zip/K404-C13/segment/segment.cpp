#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdio>
using namespace std;

const int N=100005;
const int mod=998244353;
const int M=1005;

int n,m,l,now,nxt,ans,w,way;
int dp[2][M][M],pw[N],f[2][M][M]; 

int quickpow(int x,int y){
	int s=1;
	for (;y;y>>=1,x=1ll*x*x%mod)
		if (y&1) s=1ll*s*x%mod;
	return s;
}

void add(int &x,int y){
	if (x==-1) x=0;
	(y>=mod)?y-=mod:0;
	x+=y;
	(x>=mod)?x-=mod:0;
}

int main(){
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int i,j,k,x,y,b;
	scanf("%d%d%d",&m,&n,&l);
	for (i=1;i<=m;i++) pw[i]=quickpow(i,l);
	memset(dp,-1,sizeof(dp));
	dp[0][0][0]=0; now=1; nxt=0; f[0][0][0]=1;
	for (i=0;i<n;i++){
		now^=1; nxt^=1;
		for (j=0;j<=m;j++)
			for (k=0;k<=m;k++){
				if (dp[now][j][k]==-1) continue;
				way= f[now][j][k];
				w=(dp[now][j][k]+1ll*way*pw[k]%mod)%mod;
				add(dp[nxt][j][k],w);
				add( f[nxt][j][k],way);
				add(dp[nxt][j][k+1],w);
				add( f[nxt][j][k+1],way);
				if (k){
					add(dp[nxt][j+1][k],w);
					add( f[nxt][j+1][k],way);
					add(dp[nxt][j+1][k-1],w);
					add( f[nxt][j+1][k-1],way);
				}
				else{
					add(dp[nxt][j+1][k],w);
					add( f[nxt][j+1][k],way);
				}
			}
		for (j=0;j<=m;j++)
			for (k=0;k<=m;k++){
				dp[now][j][k]=-1;
				 f[now][j][k]=0;
			}
	}
	printf("%d\n",dp[nxt][m][0]);
	return 0;
}
