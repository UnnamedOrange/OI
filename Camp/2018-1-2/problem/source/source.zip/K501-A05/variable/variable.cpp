#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for(int i = (a), i##_end_ = (b); i < i##_end_; ++i)
#define DEBUG(...) printf(__VA_ARGS__), fflush(stdout)
#define mp make_pair
#define fst first
#define snd second
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<typename T> inline T read()
{
	register T sum(0), fg(1);
	register char ch(getchar());
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') fg = -1;
	for(;  isdigit(ch); ch = getchar()) sum = sum * 10 + ch - '0';
	return sum * fg;
}

typedef long long LL;
typedef pair<int, int> pii;

const int maxn = 20;

int n, W, p, q;

struct equ
{
	int x, y, z, a, b, c, d, e, f;
}a[maxn + 5];

struct neq
{
	int x, y, r;
}b[maxn + 5];

inline void input()
{
	n = read<int>(), W = read<int>(), p = read<int>(), q = read<int>();
	REP(i, 0, p)
	{
		a[i].x = read<int>() - 1, a[i].y = read<int>() - 1, a[i].z = read<int>() - 1;
		a[i].a = read<int>(), a[i].b = read<int>(), a[i].c = read<int>();
		a[i].d = read<int>(), a[i].e = read<int>(), a[i].f = read<int>();
	}
	REP(i, 0, q) b[i].x = read<int>() - 1, b[i].y = read<int>() - 1, b[i].r = read<int>();
}

int val[maxn + 5];

inline bool check()
{
	REP(i, 0, q)
	{
		if(b[i].r == 0 && val[b[i].x] > val[b[i].y]) return 0;
		if(b[i].r == 1 && val[b[i].x] != val[b[i].y]) return 0;
		if(b[i].r == 2 && val[b[i].x] >= val[b[i].y]) return 0;
	}

	return 1;
}

inline LL calc()
{
	LL sum = 0;
	REP(i, 0, n) sum += val[i];
	REP(i, 0, p)
	{
		sum += LL(a[i].a) * abs(val[a[i].x] - val[a[i].y]);
		sum += LL(a[i].b) * abs(val[a[i].y] - val[a[i].z]);
		sum += LL(a[i].c) * abs(val[a[i].z] - val[a[i].x]);

		sum += LL(a[i].d) * (val[a[i].x] - val[a[i].y]);
		sum += LL(a[i].e) * (val[a[i].y] - val[a[i].z]);
		sum += LL(a[i].f) * (val[a[i].z] - val[a[i].x]);
	}

	return sum;
}

LL ans;

inline void dfs(int x)
{
	if(x == n)
	{
		if(check()) chkmin(ans, calc());
		return;
	}

	val[x] = W, dfs(x + 1);
	val[x] = -W, dfs(x + 1);
}

inline void solve()
{
	ans = LLONG_MAX, dfs(0);
	printf("%lld\n", ans);
}

int main()
{
#ifdef fatesky
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
#endif

	int T = read<int>();
	while(T--)
	{
		input();
		solve();
	}

	return 0;
}

