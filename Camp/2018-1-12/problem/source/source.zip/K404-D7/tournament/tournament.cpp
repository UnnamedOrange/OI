#include <bits/stdc++.h>
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v = -v ;
}
using namespace std;
int n, k;
int ans;
int ma[55][55];
bool pd;
inline void dfs1(int x, int s, int step) {
	if(pd) return;
	if(step == k) {
		if(x == s)
		pd = 1;
		return;
	}
	for(int i = 1; i <= n; ++i) {
		if(ma[x][i]) {
			dfs1(i, s, step + 1);
		}
	}
}
inline bool check() {
	pd = 0;
	for(int i = 1; i <= n && pd == 0; ++i) {
		dfs1(i, i, 0);
	}
	return pd;
}
inline void dfs(int x, int y) {
	
	if(x == n && y == n) {
		ans += check();
		return;
	}
	if(y == n) {
		ma[x][y] = 1, ma[y][x] = 0;
		dfs(x + 1, min(n, x + 2));
		ma[x][y] = 0, ma[y][x] = 1;
		dfs(x + 1, min(n, x + 2));
	} else {
		ma[x][y] = 1, ma[y][x] = 0;
		dfs(x, y + 1);
		ma[x][y] = 0, ma[y][x] = 1;
		dfs(x, y + 1);
	}
}
int main() {
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	R(n), R(k);
	dfs(1, min(2, n));
	printf("%d\n", ans);
}

