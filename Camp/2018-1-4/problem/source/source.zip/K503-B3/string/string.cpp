#include <bits/stdc++.h>
using namespace std;

const int Maxn = 11, Maxm = 555;

int n, m;
string s[Maxn];

int main() {
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) {
		cin >> s[i];
	}
	int ans = 0;
	for (int S = 0; S < 1<<m; ++S) {
		string st = "";
		for (int i = 0; i < m; ++i) {
			st += char(48+(S>>i&1));
		}
		for (int i = m-1; i >= 0; --i) {
			st += char(48+((S>>i&1)^1));
		}
		bool ok = true;
		for (int i = 1; i <= n; ++i) {
			ok &= (st.find(s[i]) != string::npos);
		}
		ans += ok;
	}
	cout << ans << endl;
	return 0;
}
