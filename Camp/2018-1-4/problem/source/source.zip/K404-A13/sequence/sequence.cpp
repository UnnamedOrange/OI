#include<cstdio>
#include<queue>
#include<algorithm>
using namespace std;
const int maxn = 15;
int num[maxn];
struct node {
	int num[maxn], step;
} st;
int n, t, ans;
bool fin(const node &nd) {
	for(register int i = 1; i < n; ++i)
		if(nd.num[i] > nd.num[i + 1]) return 0;
	return 1;
}
node opr(node nd, int l) {
	node nxt = nd;
	for(register int i = 1; i <= l / 2; ++i)
		swap(nxt.num[i], nxt.num[l - i + 1]);
	nxt.step = nd.step + 1;
	return nxt;
}
void opr(int l) {
	for(register int i = 1; i <= l / 2; ++i)
		swap(num[i], num[l - i + 1]);
}
node bfs(node st) {
	queue<node > q;
	q.push(st);
	while(!q.empty()) {
		node now = q.front();
		q.pop();
		if(fin(now)) return now;
		for(register int i = 2; i <= n; ++i)
			q.push(opr(now, i));
	}
	return st;
}
int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		if(n <= 9) {
			for(register int i = 1; i <= n; ++i) scanf("%d", &st.num[i]);
			st.step = 0;
			st = bfs(st);
			printf("%d\n", st.step);
		} else {
			ans = 0;
			for(register int i = 1; i <= n; ++i) scanf("%d", &num[i]);
			for(register int i = n; i >= 1; --i) {
				if(num[i] != i) {
					if(num[1] == i) opr(i), ++ans;
					else 
					for(register int j = 2; j < i; ++j)
						if(num[j] == i) {
						 	opr(j), opr(i), ans += 2; break;
						}
				}
			}
			printf("%d\n", ans);
		}
	}
	return 0;
}
