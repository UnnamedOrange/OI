#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)
#define Forr(i, j, k) for(int i = j; i >= k; i--)

using namespace std;

const int N = 55, K = 16;
const int Mod = 998244353;

int Begin[N], Next[N << 1], to[N << 1], e;

void add(int u, int v){
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int n, k;

int fa[N];
bool del[N];
bool vis[N];

struct Info{
	int f[K];
};

Info DFS(int o){
	
	int q[N], l = 1, r = 0;

	For(i, 1, n) vis[i] = false;
	q[++r] = o, vis[o] = true;
	while(l <= r){
		int u = q[l++];
		for(int i = Begin[u]; i; i = Next[i])
			if(!vis[to[i]] && !del[to[i]]) vis[to[i]] = true, q[++r] = to[i];
	}

	Info ans;
	For(j, 0, k) ans.f[j] = 0;

	For(i, 1, r){
		int u = q[i];
		del[u] = true;

		Info ret;
		For(j, 0, k) ret.f[j] = 1;

		for(int j = Begin[u]; j; j = Next[j]){
			int v = to[j];
			if(del[v]) continue;
			Info t = DFS(v);
			For(c, 0, k)
				ret.f[c] = 1ll * ret.f[c] * t.f[c] % Mod;
		}

		Forr(j, k, 1) ret.f[j] = ret.f[j - 1];
		ret.f[0] = 0;
		For(j, 1, k) (ret.f[j] += ret.f[j - 1]) %= Mod;
		For(j, 1, k) (ans.f[j] += ret.f[j]) %= Mod;

		del[u] = false;
	}

	return ans;
}

int main(){

	freopen("xmastree3.in", "r", stdin);
	freopen("xmastree3.out", "w", stdout);

	scanf("%d%d", &n, &k);
	For(i, 2, n){
		int u, v;
		scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}

	printf("%d\n", DFS(1).f[k]);

	return 0;
}
