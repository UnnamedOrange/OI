#include<bits/stdc++.h>
using namespace std;
const int kcz=998244353;
struct node{
	int r,next;}side[1000000];
int tot,n,sidetot,now[1000000];
bool boo[1000000];
int f[1000000],dp[1000000],ans[1000000];
void add(int i,int j){
	sidetot++;
	side[sidetot].r=j;
	side[sidetot].next=now[i];
	now[i]=sidetot;
}
void dfs(int i){
	boo[i]=1;
	tot++;
	for (int p=now[i];(p);p=side[p].next)
	if (!boo[side[p].r])
	{
		dfs(side[p].r);
		return ;
	}
}
int fastmi(int i,int j){
	int ans=1;
	long long now=i;
	while (j){
		if (j&1) ans=ans*now%kcz;
		now=now*now%kcz;
		j>>=1;
	}
	return ans;
}
int main(){
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	scanf("%d",&n);
	f[1]=0;
	dp[2]=1;
	f[2]=0;
	for (int i=3;i<=(n+1)/2;i++)
	{
		dp[i]=(2*dp[i-1]-dp[i-2]+kcz)%kcz;
		f[i]=((2*f[i-1]-f[i-2]-2)%kcz+kcz)%kcz;
	}
	for (int i=n;i>(n+1)/2;i--)
	{
		dp[i]=dp[n-i+1];
		f[i]=f[n-i+1];
	}
	int k=(n+1)/2;
	int x=((f[k+1]+f[k-1]-2*f[k]+2)%kcz+kcz)%kcz*fastmi(dp[k]*2-dp[k-1]-dp[k+1],kcz-2)%kcz;
	for (int i=1;i<=n;i++)
		ans[i]=((long long)dp[i]*x%kcz+f[i]+kcz)%kcz;
	for (int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	dfs(1);
	cout<<ans[tot]+1;
}
	
	
