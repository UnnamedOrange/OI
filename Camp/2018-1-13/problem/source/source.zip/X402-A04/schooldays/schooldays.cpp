#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int mod=1e9+7;
const int inf=0x3f3f3f3f;
const int N=1000050;
pii non=pii(-inf,inf);
inline pii operator + (pii a,pii b)
{
	if(a==non||b==non) return non;
	if(a>b) swap(a,b);
	if(a.se<b.fi) return non;
	if(b.se<=a.se) return b;
	return pii(b.fi,a.se);
}
int n,f[N],g[N],mx[N];
pii p[N];


void wj()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read();
	for(i=1;i<=n;++i) p[i].fi=read(),p[i].se=read();
	memset(f,-inf,sizeof(f));
	f[n+1]=0; g[n+1]=1;
	for(i=n;i;--i)
	{
		pii now=pii(0,n);
		for(j=i;j<=n;++j)
		{
			now=now+p[j];
			if(now==non) break;
			if(j-i+1>now.se) break;
			if(mx[j+1]+1<f[i]) break;
			if(now.fi<=j-i+1)
			{
				if(f[j+1]+1>f[i])
				{
					f[i]=f[j+1]+1;
					g[i]=g[j+1];
				}
				else if(f[j+1]+1==f[i]) g[i]=(g[i]+g[j+1])%mod;
			}
		}
		mx[i]=max(f[i],mx[i+1]);
	}
	//for(i=1;i<=n;++i) cerr<<f[i]<<' ';
	if(f[1]<0) {puts("-1");return 0;}
	printf("%d %d\n",f[1],g[1]);
	return 0;
}
