#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[5000],b[5000],lasa[5000][5000],lasb[5000][5000],f[5000][5000];
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++) scanf("%d",a+i);
	for (int i=1;i<=m;i++) scanf("%d",b+i);
	for (int i=1;i<=n+1;i++)
	for (int j=1;j<=k;j++)
	if (a[i-1]==j) lasa[i][j]=i-1;else lasa[i][j]=lasa[i-1][j];
	for (int i=1;i<=m+1;i++)
	for (int j=1;j<=k;j++)
	if (b[i-1]==j) lasb[i][j]=i-1;else lasb[i][j]=lasb[i-1][j];
	memset(f,0x3f,sizeof(f));
	f[n+1][m+1]=0;
	for (int i=n+1;i>=0;i--)
	for (int j=m+1;j>=0;j--)
	if ((!i||!j||(a[i]==b[j]))&&(f[i][j]<5000)){
		for (int c=1;c<=k;c++){
			f[lasa[i][c]][lasb[j][c]]=min(f[lasa[i][c]][lasb[j][c]],f[i][j]+1);
		}
	}
	printf("%d\n",f[0][0]);
	return 0;
}
