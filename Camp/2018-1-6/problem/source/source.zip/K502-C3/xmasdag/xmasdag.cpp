#include<iostream>
#include<cstring>
#include<cstdio>
#define MINN 2200
#define NN 100000+2000
#define MM 200000+2000
#define mod 998244353
using namespace std;
int dp[MINN][MINN]={0};
int far[NN]={0};
int near[NN]={0};
int p[NN]={0};
int q[NN]={0},h=0,t=0;
int deg[NN]={0};
long long ksm[NN]={0};
int n,m;
struct node{
	int to,xt;
}e[MM]={0};
void ADD(int a,int b,int num){
	e[num].to=b;
	e[num].xt=p[a];
	p[a]=num;
	++deg[b];
}
void construct(){
	int a,b;
	for(int i=1;i<=m;++i){
		scanf("%d%d",&a,&b);
		ADD(a,b,i);
	}
}
void brute_dp(){
	memset(near,1,sizeof near);
	h=0,t=0;
	q[t++]=1;
	dp[1][0]=1;
	far[1]=0;
	near[1]=0;
	while(h!=t){
		int tp=q[h++];
		for(int i=p[tp];i;i=e[i].xt){
			int now=e[i].to;
			for(int j=near[tp];j<=far[tp];++j){
				(dp[now][j+1]+=dp[tp][j])%=mod;
				near[now]=min(near[now],near[tp]+1);
				far[now]=max(far[now],far[tp]+1);
			}
			--deg[now];
			if(!deg[now]){
				q[t++]=now;
			}
		}
	}
	for(int i=1;i<=n;++i){
		long long ans=0;
		for(int j=near[i];j<=far[i];++j){
			(ans+=(ksm[j]*dp[i][j])%mod)%=mod;
		}
		printf("%lld\n",ans);
	}
}
int ndp[NN][2]={0};
int cnt[NN]={0};
void nice_dp(){
	memset(near,1,sizeof near);
	h=0,t=0;
	q[t++]=1;
	ndp[1][0]=0;
	ndp[1][1]=1;
	while(h!=t){
		int tp=q[h++];
		for(int i=p[tp];i;i=e[i].xt){
			int now=e[i].to;
			(ndp[now][1]+=ndp[tp][1])%=mod;
			(ndp[now][0]+=ndp[tp][1])%=mod;
			(ndp[now][0]+=ndp[tp][0])%=mod;
			--deg[now];
			if(!deg[now]){
				q[t++]=now;
			}
		}
	}
	for(int i=1;i<=n;++i){
		printf("%d\n",ndp[i][0]);
	}
}
long long fastpow(long long a,int b){
	long long op=1;
	while(b){
		if(b&1){
			(op*=a)%=mod;
		}
		b>>=1;
		(a*=a)%=mod;
	}
	return op;
}
int main(){
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	int k;
	scanf("%d%d%d",&n,&m,&k);
	construct();
	for(int i=1;i<=n;++i){
		ksm[i]=fastpow(i,k);
	}
	
	if(k==1){
		nice_dp();
		return 0;
	}
	if(n<=2100&&m<=5100){
		brute_dp();
	}
	return 0;
}
