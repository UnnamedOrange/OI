#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cassert>
#include<cmath>

using namespace std;

#define fi first
#define se second
#define rep(i,s,t) for(int i=(s),_t=(t);i<_t;++i)
#define per(i,s,t) for(int i=(t)-1,_s=(s);i>=_s;--i)
#define bug(x) cerr<<#x<<" = "<<(x)<<" "
#define debug(x) cerr<<#x<<" = "<<(x)<<"\n"

typedef long long ll;
typedef double db;
typedef pair<int,int> pii;

template<class T>void rd(T &x){
	static int f;static char c;
	f=1;x=0;
	while(c=getchar(),c<48)if(c=='-')f=-1;
	do x=x*10+(c&15);
	while(c=getchar(),c>47);
	x*=f;
}
template<class T>void prin(T x){
	if(x<0)x=-x,putchar('-');
	else if(!x){putchar('0');return ;}
	static int stk[100],tp;
	while(x)stk[tp++]=x%10,x/=10;
	while(tp)putchar(stk[--tp]^48);
}
template<class T>void ptk(T x){prin(x);putchar(' ');}
template<class T>void ptn(T x){prin(x);putchar('\n');}
template<class T>void Min(T &a,T b){if(b<a)a=b;}
template<class T>void Max(T &a,T b){if(a<b)a=b;}

const int mod=1000000007;
void add_mod(int &a,int b){if((a+=b)>=mod)a-=mod;}
int Pow(int x,int y){
	int res=1;
	for(;y;y>>=1,x=(ll)x*x%mod)
		if(y&1)res=(ll)res*x%mod;
	return res;
}
ll n,m,s,t;
struct P_0{
	int dp[2][105];
	void work(){
		int cur=0;
		dp[cur][0]=1;
		rep(i,1,m+1){
			int sum=0;
			rep(j,0,s+1){
				dp[!cur][j]=sum;
				add_mod(sum,dp[cur][j]);
				if(j>=t&&i<=n)add_mod(sum,mod-dp[cur][j-t]);
			}
			cur^=1;
		}
		int ans=0;
		rep(i,m,s+1)add_mod(ans,dp[cur][i]);
		ptn(ans);
	}
}P0;
const int N=(int)1e6+5;
struct P_1{
	int fac[N],ifac[N];
	int C(int n,int m){
		return (ll)fac[n]*ifac[m]%mod*ifac[n-m]%mod;
	}
	void work(){
		{
			fac[0]=1;
			rep(i,1,s+1)fac[i]=(ll)fac[i-1]*i%mod;
			ifac[s]=Pow(fac[s],mod-2);
			per(i,1,s+1)ifac[i-1]=(ll)ifac[i]*i%mod;
		}
//		static int C_n[N],C_n_1[N];
//		rep(i,0,n+1)C_n[i]=C(n,i);
//		rep(i,n-1,s+1)C_n_1[i]=C(i,n-1);
		int ans=0;
		rep(j,0,n+1){
			if(s-j*t<m)break;
			if(j&1)ans=(ans-C(n,j)*(ll)C(s-j*t,m))%mod;
			else ans=(ans+C(n,j)*(ll)C(s-j*t,m))%mod;
		}
//		rep(i,n,s-m+n+1){
//			int res=0;
//			for(int l=i-1,j=0;j<=n&&n-1<=l;l-=t,++j){
//				if(j&1)res=(res-(ll)C_n[j]*C_n_1[l])%mod;
//				else res=(res+(ll)C_n[j]*C_n_1[l])%mod;
//			}
//			ans=(ans+(ll)res*C(s-i,m-n))%mod;
//		}
		if(ans<0)ans+=mod;
		ptn(ans);
	}
}P1;
int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	rd(s),rd(t),rd(n),rd(m);
	if(s<m)ptn(0);
	else if(s<=100&&t<=100&&n<=100&&m<=100)P0.work();
	else if(m<=(int)1e6&&s<=(int)1e6)P1.work();
	else P1.work();
	return 0;
}
