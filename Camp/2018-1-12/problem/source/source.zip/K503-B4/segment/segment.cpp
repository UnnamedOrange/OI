#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
const int maxn=1e5+5;
const int mod=998244353;
int n,m,k,ai[maxn];
ll dp[maxn][4][4],f[maxn][4][4];
ll DP[2][355][355],F[2][355][355];
ll poww(int x,int y)
{
	ll res=1,t=x;
	while(y>0)
	{
		if(y&1)
			(res*=x)%=mod;
		(x*=x)%=mod;
		y>>=1;
	}
	return res;
}
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(n>=m)
	{
		puts("0");
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	for(int i=1;i<=m;i++)
		ai[i]=poww(i,k);
	if(n<=3)
	{
		f[0][0][0]=1;
		for(int i=1;i<=m;i++)
			for(int v=0;v<=n;v++)
				for(int e=0;e<=v;e++)
				{
					if(v&&e)
					{
						(f[i][v][e]+=f[i-1][v-1][e])%=mod;
						(dp[i][v][e]+=dp[i-1][v-1][e]+(f[i-1][v-1][e]*ai[e])%mod)%=mod;
					}
					if(e<m&&v)
					{
						(f[i][v][e]+=f[i-1][v][e+1])%=mod;
						(dp[i][v][e]+=dp[i-1][v][e+1]+(f[i-1][v][e+1]*ai[e])%mod)%=mod;
					}
					if(v&&e)
					{
						(f[i][v][e]+=f[i-1][v-1][e-1])%=mod;
						(dp[i][v][e]+=dp[i-1][v-1][e-1]+(f[i-1][v-1][e-1]*ai[e])%mod)%=mod;
					}
					if(e==0)
					{
						(f[i][v][e]+=f[i-1][v-1][e])%=mod;
						(dp[i][v][e]+=dp[i-1][v-1][e])%=mod;
					}
					(f[i][v][e]+=f[i-1][v][e])%=mod;
					(dp[i][v][e]+=dp[i-1][v][e]+(f[i-1][v][e]*ai[e])%mod)%=mod;
				}
		ll ans=(dp[m-1][n][0]+dp[m-1][n-1][0]+dp[m-1][n][1])%mod;
		printf("%lld\n",ans);
	}
	else if(n<=350&&m<=350)
	{
		F[0][0][0]=1;
		bool last=0,now=1;
		for(int i=1;i<m;i++)
		{
			memset(DP[now],0,sizeof(DP[now]));
			memset(F[now],0,sizeof(F[now]));
			for(int v=0,lit=std::min(i,n);v<=lit;v++)
				for(int e=0;e<=v;e++)
				{
					if(v&&e)
					{
						(F[now][v][e]+=F[last][v-1][e])%=mod;
						(DP[now][v][e]+=DP[last][v-1][e]+(F[last][v-1][e]*ai[e])%mod)%=mod;
					}
					if(e<m&&v)
					{
						(F[now][v][e]+=F[last][v][e+1])%=mod;
						(DP[now][v][e]+=DP[last][v][e+1]+(F[last][v][e+1]*ai[e])%mod)%=mod;
					}
					if(v&&e)
					{
						(F[now][v][e]+=F[last][v-1][e-1])%=mod;
						(DP[now][v][e]+=DP[last][v-1][e-1]+(F[last][v-1][e-1]*ai[e])%mod)%=mod;
					}
					if(e==0)
					{
						(F[now][v][e]+=F[last][v-1][e])%=mod;
						(DP[now][v][e]+=DP[last][v-1][e])%=mod;
					}
					(F[now][v][e]+=F[last][v][e])%=mod;
					(DP[now][v][e]+=DP[last][v][e]+(F[last][v][e]*ai[e])%mod)%=mod;
				}
			now^=1;
			last^=1;
		}
		ll ans=(DP[last][n][0]+DP[last][n-1][0]+DP[last][n][1])%mod;
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
