#include <map>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

#define ret return

const int mod = 998244353;

int n, m;
long long an = 0;
char s[10][100], s1[100];
string ans, null;
string str[10];

inline void open()
{
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);
	ret;
}

inline void close()
{
	fclose(stdin);
	fclose(stdout);
	ret;
}

inline void init()
{
	for(int i = 1;i <= n;++i)
		cin >> str[i];
}

inline void dfs(int x)
{
	if(x == m)
	{
		ans = null;
		for(int i = 0;i < 2 * m;++i)
			ans = ans + s1[i];
		cout << ans << endl;
		for(int i = 1;i <= n;++i)
		{
			cout << ans.find(str[i]) << " " << str[i] << endl;
			int t = ans.find(str[i]);
			if(t > 2 * m || t < 0)
				ret;
		}
		++an;
		ret;
	}
	s1[x] = '1', s1[2 * m - x - 1] = '0';
	dfs(x + 1);
	s1[x] = '0', s1[2 * m - x - 1] = '1';
	dfs(x + 1);
}

inline void solve()
{
	printf("%d\n", 0);
}

int main()
{
	open();
	scanf("%d%d", &n, &m);
	if(m <= 15)
	{
		init();
		dfs(0);
		printf("%lld\n", an);
	}
	else
		solve();
	close();
	ret 0;
}
