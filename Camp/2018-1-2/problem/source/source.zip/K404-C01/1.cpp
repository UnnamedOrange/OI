//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<queue>
#include<cmath>
const int N=2e5+7;
typedef long long LL;
using namespace std;
int T,nn,n,rad[N],dp[N];
char ss[N],s[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') f=-1,ch=getchar(); 
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

void manacher() {
	for(int i=0,j=0,k;i<=n;) {
		while(s[i-j-1]==s[i+j+1]) j++;
		rad[i]=j;
		for(k=1;k<=j&&rad[i-k]!=rad[i]-k;k++) 
			rad[i+k]=min(rad[i]-k,rad[i-k]);
		j=max(0,j-k);
		i+=k;
	}
}

void solve() {
	dp[0]=0;
	for(int i=1;i<n-1;i++) {
		if(s[i]<'a'||s[i]>'z') continue;
		for(int j=1;j<=i-2;j++) if(s[j]>='a'&&s[j]<='z'&&(j==1||dp[j-2]!=-1)){
			if((i+j)/2+rad[(i+j)/2]<i) {
				if(j==1) dp[i]=1;
				else if(dp[i]==-1||dp[i]>dp[j-2]+1)
					dp[i]=dp[j-2]+1; 
			}
		}
	}
	printf("%d\n",dp[n-2]);
}

int main() {
#ifdef DEBUG
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
#endif
	read(T);
	while(T--) {
		memset(rad,0,sizeof(rad));
		memset(dp,-1,sizeof(dp));
		read(nn); n=0;
		scanf("%s",ss);
		s[n]='*';
		for(int i=0;i<nn;i++) {
			s[++n]=ss[i];
			s[++n]='#';
		}
		s[++n]='&';
		manacher();
		solve();
	}
	return 0;
}
