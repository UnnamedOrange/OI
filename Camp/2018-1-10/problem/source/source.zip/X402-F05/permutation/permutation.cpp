#include <bits/stdc++.h>

#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

const int N = 10;

int A[N], fa[N], sz[N], n, ans;

int find(int x){
	return x == fa[x] ? x : fa[x] = find(fa[x]);
}

bool vis[N];

void DFS(int x){
	if(x > n){
		For(i, 1, n) fa[i] = i, sz[i] = 1;
		For(i, 1, n){
			int u = find(i), v = find(A[i]);
			if(u ^ v) sz[v] += sz[u], fa[u] = v;
		}
		For(i, 1, n) if(i == fa[i] && sz[i] % 2) return;
		++ans;
		return;
	}
	if(A[x]){
		DFS(x + 1);
		return;
	}
	For(i, 1, n) if(!vis[i]){
		A[x] = i, vis[i] = true;
		DFS(x + 1);
		vis[i] = false;
		A[x] = 0;
	}

}

int main(){
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);

	scanf("%d", &n);
	For(i, 1, n) scanf("%d", &A[i]), vis[A[i]] = true;
	DFS(1);

	printf("%d\n", ans);

	return 0;
}
