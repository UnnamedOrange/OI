#include<bits/stdc++.h>
#define FE "success"
using namespace std;
#define int long long
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c))(c=='-'?p=-1:0),c=getchar();
	while(isdigit(c))x=(x<<3)+(x<<1)+(c^'0'),c=getchar();
	return x*p;
}
inline void putint(int x){
	static int buf[20];
	int tot=0;
	x<0?putchar('-'),x=-x:0;
	do{
		buf[tot++]=x%10;
		x/=10;
	}while(x);
	while(tot)putchar(buf[--tot]+'0');
}
const int MOD = 1000000007, LEN = 3000000;
long long fac[LEN+5],invfac[LEN+5];
inline long long ksm(long long a,long long b,long long c){
	long long ans=1;
	while(b){
		if(b&1)ans=ans*a%c;
		b>>=1,a=a*a%c;
	}
	return ans;
}
inline void pre(){
	fac[0]=1;
	for(int i=1;i<=LEN;++i){
		fac[i]=fac[i-1]*i%MOD;
	}
	invfac[LEN]=ksm(fac[LEN],MOD-2,MOD);
	for(int i=LEN-1;i>=0;--i){
		invfac[i]=invfac[i+1]*(i+1)%MOD;
	}
}
inline long long c(int a,int b){
	if(b<0||b>a)return 0;
	else return fac[a]*invfac[b]%MOD*invfac[a-b]%MOD;
}
#undef int
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	pre();
	long long s=getint(),t=getint(),n=getint(),m=getint(),ans=0;
	for(int i=0;i<=n;i+=2){
		ans+=c(s-i*t,m)*c(n,i)%MOD;
		ans%=MOD;
	}
	for(int i=1;i<=n;i+=2){
		ans-=c(s-i*t,m)*c(n,i)%MOD;
		ans%=MOD;
	}
	cout<<(ans+MOD)%MOD;
	return 0;
}
