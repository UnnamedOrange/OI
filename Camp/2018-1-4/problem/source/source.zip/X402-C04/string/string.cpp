#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int md=998244353;
const int M=1009;
const int N=109;
const int K=9;

int n,m,m2,ans;
char s[K][N];
int val[M],len[K];

inline bool check()
{
	for(int i=1;i<=m;i++)
		val[m2-i+1]=val[i]^1;
	
/*	for(int i=1;i<=m2;i++)
		printf("%d",val[i]);
	puts("");*/
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j+len[i]-1<=m2;j++)
		{
			for(int k=1;k<=len[i];k++)
				if(s[i][k]!=val[j+k-1])
					goto nxt;
			goto suc;
			nxt:;
		}
		return false;
		suc:;
	}
	return true;
}

inline void dfs(int pos)
{
	if(pos==m+1)
	{
		if(check())
		{
			ans++;
			if(ans>=md)
				ans-=md;
		}
		return;
	}

	val[pos]=0;
	dfs(pos+1);
	val[pos]=1;
	dfs(pos+1);
}

int main()
{
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);

	scanf("%d%d",&n,&m);
	m2=m*2;
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s[i]+1);
		len[i]=strlen(s[i]+1);
		for(int j=1;j<=len[i];j++)
			s[i][j]-='0';
	}

	dfs(1);
	printf("%d\n",ans);
	return 0;
}
