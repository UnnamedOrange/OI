#include <bits/stdc++.h>

const int mod = 1e9, LEN = 5e3;

int main()
{
	freopen("xmasinterval.in", "w", stdout);
	srand(time(NULL));
	int n = 5e3, m = 5e3;
	printf("%d %d\n", n, m);
	for(int i = 1; i <= n; ++i){
		int r = rand() % LEN + 1;
		int l = rand() % r;
		printf("%d %d\n", l+mod, r+mod);
	}
	for(int i = 1; i <= m; ++i) printf("%d\n", rand() % LEN + mod);
	return 0;
}
