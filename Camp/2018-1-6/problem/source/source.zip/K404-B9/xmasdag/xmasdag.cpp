#include<bits/stdc++.h>
#define maxn 998244353
using namespace std;

int n,m,k,vis[101000],c[2010][5010];
long long sum[101000],num[101000];
vector <int> b[101000];
void dfs(int x)
{
	vis[x]=1;
	for (int i=b[x].size()-1;i>=0;i--)
	  {
	  	if (!vis[b[x][i]]) dfs(b[x][i]);
		num[x]+=num[b[x][i]],sum[x]+=sum[b[x][i]];
		if (sum[x]>maxn) sum[x]=sum[x]%maxn;
		if (num[x]>maxn) num[x]=num[x]%maxn;
	  }
	sum[x]+=num[x];
	if (sum[x]>maxn) sum[x]=sum[x]%maxn; 
}

void dfss(int x)
{
	vis[x]=1;
	for (int i=b[x].size()-1;i>=0;i--)
	  {
	  	int emm=b[x][i];
	  	if (!vis[emm]) dfss(emm);
	  	for (int j=0;j<=5001;j++) c[x][j+1]+=c[emm][j];
	  }
}

int main()
{
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=m;i++)
	  {
	  	int u,v;
	  	scanf("%d%d",&u,&v);
	  	b[v].push_back(u);
	  }
	vis[1]=1,num[1]=1,sum[1]=0,c[1][0]=1;
	if (k==1)
	  {
	  	for (int i=1;i<=n;i++)
	  	  {
	  	  	if (!vis[i]) dfs(i);
		  }
		for (int i=1;i<=n;i++) printf("%lld\n",sum[i]); 
		return 0;  
	  }
	if (n<=10000&&m<=10000)
	  {
	  	long long hh[5010];
	  	for (int i=1;i<=m+1;i++)
	  	  {
	  	  	hh[i]=i;
	  	  	for (int j=2;j<=k;j++)
	  	  	  {
	  	  	  	hh[i]=hh[i]*i;
	  	  	  	if (hh[i]>maxn) hh[i]=hh[i]%maxn;
			  }
		  }
	  	for (int i=2;i<=n;i++)
	  	  if (!vis[i]) dfss(i);
	  	for (int i=1;i<=n;i++)
		  {
		  	for (int j=1;j<=m+1;j++)
		  	  {
		  	  	sum[i]=sum[i]+c[i][j]*hh[j];
		  	  	if (sum[i]>maxn) sum[i]=sum[i]%maxn;
			  }
		  }
	  	for (int i=1;i<=n;i++) printf("%lld\n",sum[i]); 
		return 0;   
	  }     
}
