#include<iostream>
#include<cstdio>
#include<cstring>
#include<ctime>
#include<algorithm>
using namespace std;
struct lxy{
	int to,next;
}b[2000005];
int head[1000005];
int n,m,ans,cnt;
int vis[1000005];
bool col[1000005];

int readit()
{
	char x;
	int a=0;
	x=getchar();
	while(x<'0'||x>'9')x=getchar();
	while(x>='0'&&x<='9')
	{
		a=a*10+x-'0';
		x=getchar();
	}
	return a;
}

void add(int op,int ed)
{
	cnt++;
	b[cnt].next=head[op];
	b[cnt].to=ed;
	head[op]=cnt;
}

void dfs(int u)
{
	for(int i=1;i<=ans;i++)col[i]=0;
	for(int i=head[u];i!=-1;i=b[i].next)
	  if(vis[b[i].to]!=0)
		col[vis[b[i].to]]=1;
	int p=1;
	while(col[p]==1)p++;
	vis[u]=p;
	ans=max(ans,p);
	for(int i=head[u];i!=-1;i=b[i].next)
	  if(vis[b[i].to]==0)
	    dfs(b[i].to);
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(head,-1,sizeof(head));
	int x,y;
	for(int i=1;i<=m;i++)
	{
		x=readit();y=readit();
		add(x,y);
		add(y,x);
	}
	for(int i=1;i<=n;i++)
	  if(vis[i]==0)
	    dfs(i);
	printf("%d",ans);
}
