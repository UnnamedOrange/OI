#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int t,n;

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		printf("%d",n);
	}
	return 0;
}
