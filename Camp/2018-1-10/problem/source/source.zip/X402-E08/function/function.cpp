/*
Author: CNYALI_LK
LANG: C++
PROG: function.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll p[1024242],f[1024242],pri[1024242],ps=0,low[1024242],k[1024242],n,sum[1024242];
void init_f(){
	sum[1]=f[1]=1;
	p[1]=1;
	for(ll i=2;i<=n;++i){
		if(!p[i]){
			low[i]=pri[++ps]=i;
			k[i]=1;
			f[i]=3;
		}
		for(ll j=1;j<=ps&&i*pri[j]<=n;++j){
			p[i*pri[j]]=1;
			if(i%pri[j]){
				f[i*pri[j]]=f[i]*3;
				low[i*pri[j]]=pri[j];
				k[i*pri[j]]=1;
			}
			else{
				k[i*pri[j]]=k[i]+1;
				low[i*pri[j]]=low[i]*pri[j];
				f[i*pri[j]]=f[i/low[i]]*((k[i]<<1)+3);
				break;
			}
		}
		sum[i]=f[i]+sum[i-1];
	}
}

#ifndef cnyali_lk
#define cnyali_lk
#endif

int main(){
#ifdef cnyali_lk
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
#endif
	ll t;
	t=read();
	n=1000000;
	init_f();
	while(t){
		--t;
		n=read();
		write(sum[n],'\n');
	}
	return 0;
}

