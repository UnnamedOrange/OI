#include<cmath>
#include<bitset>
#include<cstdio>
#include<algorithm> 
using namespace std;
int n,q,o;
namespace work1{
	#define N 100005
	#define rep(i,j,k) for(i=j;i<=k;++i)
	struct E{
		int to,nxt;
	}ed[N<<1];
	int i,j,k,t,u,v,top,x,y,z,ans;
	int col[N],head[N],fa[N],cnt[N];
	void add(int u,int v){
		top++; ed[top].to=v; ed[top].nxt=head[u]; head[u]=top;
	}
	void dfs(int x){
		int i;
		for(i=head[x];i;i=ed[i].nxt)
		if(fa[x]!=ed[i].to){
			fa[ed[i].to]=x;
			dfs(ed[i].to);
		}
	}
	void work(int x,int val){
		int i;
		if((!cnt[col[x]])&&(y<=col[x])&&(col[x]<=z)) ans++;
		cnt[col[x]]+=val;
		if((!cnt[col[x]])&&(y<=col[x])&&(col[x]<=z)) ans--;
		for(i=head[x];i;i=ed[i].nxt)
		if(ed[i].to!=fa[x]){
			work(ed[i].to,val); 
		}
	} 
	void init(){
		scanf("%d%d%d",&n,&q,&o);
		rep(i,1,n){
			scanf("%d",&col[i]);
		}
		rep(i,1,n-1){
			scanf("%d%d",&u,&v);
			add(u,v); add(v,u);
		}
		dfs(1);
		while(q--){
			scanf("%d",&t);
			if(t==1){
				scanf("%d%d%d",&x,&y,&z);
				if(o==1){x^=ans; y^=ans; z^=ans;}
				work(x,1);
				printf("%d\n",ans);
				work(x,-1);
			}else{
				scanf("%d%d",&x,&y);
				if(o==1){x^=ans; y^=ans;}
				col[x]=y;
			}
		}
	} 
}

namespace work2{
	#define N 100005
	#define mid ((l+r)>>1)
	#define rep(i,j,k) for(i=j;i<=k;++i)
	struct E{
		int to,nxt;
	}ed[N<<1];
	int i,j,k,u,v,top,timing,w,t,ans;
	int col[N],head[N],L[N],R[N];
	bitset<50005> sta[200005],pw[50005],sum;
	void read(int &p){
		p=0; char x=getchar();
		while(x<'0' || x>'9') x=getchar();
		while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
	}
	void add(int u,int v){
		top++; ed[top].to=v; ed[top].nxt=head[u]; head[u]=top;
	}
	void update(int rt,int l,int r,int pos,int val){
		if(l==r){
			sta[rt][val]=sta[rt][val]^1;
			return ;
		}
		if(pos<=mid) update(rt<<1,l,mid,pos,val);
		else update(rt<<1|1,mid+1,r,pos,val);
		sta[rt]=(sta[rt<<1]|sta[rt<<1|1]);
	}
	void query(int rt,int l,int r,int x,int y){
		if((l>=x)&&(r<=y)){
			sum=sum|sta[rt];
			return ;
		}
		if(x<=mid) query(rt<<1,l,mid,x,y);
		if(y>mid) query(rt<<1|1,mid+1,r,x,y);
	}
	void dfs(int x,int fa){
		int i;
		timing++; L[x]=timing;  
		update(1,1,n,timing,col[x]);
		for(i=head[x];i;i=ed[i].nxt)
		if(ed[i].to!=fa) dfs(ed[i].to,x);
		R[x]=timing;
	}
	void init(){
		pw[0].set(0);
		rep(i,1,n) read(col[i]),pw[i]=pw[i-1],pw[i].set(i);
		rep(i,1,n-1){
			read(u); read(v);
			add(u,v); add(v,u);
		}
		dfs(1,0);
		while(q--){
			read(t);
			if(t==1){
				read(u); read(v); read(w);
				if(o==1){u^=ans; v^=ans; w^=ans;}
				sum.reset();
				query(1,1,n,L[u],R[u]);
				sum=sum&pw[w];
				ans=sum.count();
				sum=sum&pw[v-1];
				ans-=sum.count();
				printf("%d\n",ans);
			}else{
				read(u); read(v);
				if(o==1){u^=ans; v^=ans;}
				update(1,1,n,L[u],col[u]);
				col[u]=v;
				update(1,1,n,L[u],col[u]);
			}
		}
	}
}
namespace work3{
	#define N 100005
	#define rep(i,j,k) for(i=j;i<=k;++i)
	struct E{
		int to,nxt;
	}ed[N<<1];
	struct node{
		int l,r,bl,br,t,colx,coly,id;
		bool operator < (const node &b) const{
			if(bl==b.bl){
				if(br==b.br) return t<b.t;
				else return br<b.br;
			}
			return bl<b.bl;
		}
	}que[N];
	int i,j,k,u,v,top,timing,w,t,ans,size;
	int head[N],L[N],R[N],col[N],pp[N][2],lans[N],cpy[N];
	void read(int &p){
		p=0; char x=getchar();
		while(x<'0' || x>'9') x=getchar();
		while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
	}
	void add(int u,int v){
		top++; ed[top].to=v; ed[top].nxt=head[u]; head[u]=top;
	}
	void dfs(int x,int fa){
		int i;
		timing++; L[x]=timing; 
		for(i=head[x];i;i=ed[i].nxt)
		if(ed[i].to!=fa) dfs(ed[i].to,x);
		R[x]=timing;
	}
	int belong(int x){
		return ((x-1)/size)+1;
	}
	void init(){
		rep(i,1,n) read(col[i]),cpy[i]=col[i];
		rep(i,1,n-1){
			read(u); read(v);
			add(u,v); add(v,u);
		}
		dfs(1,0);
		size=pow(n,2.0/3.0);
		top=timing=0;
		rep(i,1,q){
			read(t); read(u); read(v); 
			if(t==1){
				read(w); 
				top++;
				que[top].l=L[u]; que[top].r=R[u]; que[top].colx=v; que[top].coly=w;
				que[top].t=timing; que[top].bl=belong(L[u]); que[top].br=belong(R[u]);
				que[top].id=top; 
			}else{
				timing++;
				pp[timing][0]=u; pp[timing][1]=v;
			}
		}
		sort(que+1,que+1+top);
		int now=0;
		rep(i,1,top){
			if(now>que[i].t){
				rep(j,1,n) col[j]=cpy[j];
				rep(j,1,que[i].t) col[pp[j][0]]=pp[j][1];
				now=que[i].t;
			}
		}
		rep(i,1,top) printf("%d\n",lans[i]);
	}
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	scanf("%d%d%d",&n,&q,&o);
	if(n<=5000){
		using work1::init;
	}else
	if(n<=50000){
		using work2::init;
	}else
	if(o==0){
		using work3::init;
	}
	return 0;
}
