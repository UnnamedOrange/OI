#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define lid node<<1
#define rid node<<1|1
#define lch lid,l,mid
#define rch rid,mid+1,r
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
typedef long double ld;
const ld eps=1e-8;
const int N=1010000,lim=60;
int a[N],b[N],cnt;//,kk[N];
ld dp[N];ld p[N];
ld la[N<<2],lm[N<<2],seg[N<<2];int len[N<<2];
int Log[N],st[N][20];
ld ans;
int n;

bool cmp(int x,int y){return a[x]<a[y];}

inline void add(int node,ld w){la[node]+=w;seg[node]+=w*len[node];}
inline void mul(int node,ld w){lm[node]*=w;la[node]*=w;seg[node]*=w;}

void update(int node){seg[node]=seg[lid]+seg[rid];}

void pushdown(int node){
	if(fabs(lm[node]-1.)>eps){mul(lid,lm[node]);mul(rid,lm[node]);lm[node]=1.0;}
	if(fabs(la[node])>eps){add(lid,la[node]);add(rid,la[node]);la[node]=0.0;}
}

void mul(int node,int l,int r,int fl,int fr){
	if(l>fr||r<fl)	return;
	if(fl<=l&&r<=fr){
		mul(node,0.5);return;
	}
	pushdown(node);
	int mid=l+r>>1;
	mul(lch,fl,fr);mul(rch,fl,fr);
	update(node);
}

void add(int node,int l,int r,int fl,int fr,ld w){
	if(l>fr||r<fl)	return;
	if(fl<=l&&r<=fr){
		add(node,w);return;
	}
	pushdown(node);
	int mid=l+r>>1;
	add(lch,fl,fr,w);add(rch,fl,fr,w);
	update(node);
}

void build(int node,int l,int r){
	lm[node]=1.0;la[node]=0.0;len[node]=r-l+1;
	if(l==r)	return;
	int mid=l+r>>1;
	build(lch);build(rch);
}

int rmq(int l,int r){
	int k=Log[r-l+1];
	return max(st[l][k],st[r-(1<<k)+1][k]);
}

int find(int x,int w){
	int l,r,mid;int ret=0;
	l=1;r=x+1;
	while(l<r){
		mid=l+r>>1;
		if(rmq(mid,x)>=w){ret=mid;l=mid+1;}
		else r=mid;
	}
	return ret;
}

int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	register int i,j,k;ld tmp;int last,x;
	scanf("%d",&n);
	rep(i,1,n)	scanf("%d",&a[i]);
	rep(i,2,n)	Log[i]=Log[i>>1]+1;
	rep(i,1,n)	st[i][0]=a[i];
	rep(j,1,18)	rep(i,1,n-(1<<j)+1)	st[i][j]=max(st[i][j-1],st[i+(1<<j-1)][j-1]);
	p[0]=1.0;
	rep(i,1,lim+1)	p[i]=p[i-1]*0.5;
	build(1,1,n);
	rep(i,1,n){
		last=i;tmp=0;
		rep(j,1,lim){
			x=find(last-1,a[i]);	
			mul(1,1,n,x+1,last);
			add(1,1,n,x+1,last,tmp*0.5+(ld)a[i]*p[j]);
			if(x){
				b[j]=a[x];
				for(k=j-1;k;k--)	if(b[k]<b[k+1])	swap(b[k],b[k+1]);
				tmp=0;
				for(k=j;k;k--)	tmp=(tmp+b[k])*0.5;
				last=x;
			}
			else break;
		}
		ans+=seg[1];
	}
	ans=ans/(ld)n/(ld)n;
	printf("%.8f",(double)ans);
}
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
