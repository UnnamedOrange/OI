#include<bits/stdc++.h>
using namespace std;
#define pb push_back
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=100010,maxm=200010,maxk=510,mo=998244353;
int n,m,k,ind[maxn];
int head[maxn],nxt[maxm],to[maxm],e;
void ae(int x,int y){
    to[++e]=y; nxt[e]=head[x]; head[x]=e;
}
void Add(int& x,int y){
    x+=y; if(x>=mo) x-=mo;
}
int f[maxn][maxk],t[maxk],ans[maxn],C[maxk][maxk];
void init(){
    C[0][0]=1;
    for(int i=1;i<=500;i++){
        C[i][0]=1;
        for(int j=1;j<=i;j++) C[i][j]=(C[i-1][j]+C[i-1][j-1])%mo;
    }
}
int main(){
    freopen("xmasdag.in","r",stdin);
    freopen("xmasdag.out","w",stdout);
    read(n); read(m); read(k);
    init();
    for(int i=1;i<=m;i++){
        int u,v;
        read(u); read(v);
        ae(u,v); ++ind[v];
    }
    queue<int> q;
    q.push(1); f[1][0]=1;
    while(!q.empty()){
        int u=q.front(); q.pop();
        memset(t,0,sizeof t);
        for(int i=0;i<=k;i++)
            for(int j=0;j<=i;j++) Add(t[i],1ll*C[i][j]*f[u][j]%mo);
        for(int i=head[u];i;i=nxt[i]){
            int v=to[i];
            for(int j=0;j<=k;j++) Add(f[v][j],t[j]);
            if(!--ind[v]) q.push(v);
        }
    }
    for(int i=1;i<=n;i++) printf("%d\n",f[i][k]);
    return 0;
}
