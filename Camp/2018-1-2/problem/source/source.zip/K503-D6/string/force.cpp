#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

using namespace std;

const int S=1e5+10,N=110,inf=0x3f3f3f3f;
int tc,n,ans,f[N][N],mx[N][N];
bool flag[N][N];
char str[S],a[S*2];

bool check(int l,int r,int x,int y)
{
    int d=mx[l][y];
    if (l+d<=r && y-d>=x)
        return 0;
    if (l+d>r && y-d<x)
        return 1;
    return r-l>y-x? flag[l+d][r]:flag[l][r-d];
}

void work()
{
    scanf("%d%s",&n,str+1);
    memset(f,63,sizeof(f));
    memset(flag,0,sizeof(flag));
    memset(mx,128,sizeof(mx));
    rep(i,1,n)
    {
        flag[i][i]=1,flag[i][i+1]=str[i]==str[i+1];
        mx[i][i]=1,flag[i][i+1]? mx[i][i+1]=2:0;
        flag[i][i+1]? 0:f[i][i+1]=1;
    }
    rep(k,3,n)
        rep(i,1,n-k+1)
        {
            int j=i+k-1;
            flag[i][j]=flag[i+1][j-1] && str[i]==str[j];
            mx[i][j]=flag[i][j]? j-i+1:mx[i+1][j-1]+1;
            if (!flag[i][j])
            {
                f[i][j]=1;
                continue;
            }
            rep(l,i+2,j-1)
                if (!flag[i][l-1])
                    f[i][j]=min(f[i][j],1+f[l][j]);
            rep(r,i+1,j-2)
                if (!flag[r+1][j])
                    f[i][j]=min(f[i][j],1+f[i][r]);
            rep(l,i+1,j-1)
                rep(r,l+1,j-1)
                    if (!check(i,l-1,r+1,j))
                        f[i][j]=min(f[i][j],1+f[l][r]);
        }
    printf("%d\n",ans=f[1][n]<inf? f[1][n]:-1);
    if (ans>2)
        throw 1;
}

int main()
{
    freopen("string.in","r",stdin);
    freopen("force.out","w",stdout);
    for (scanf("%d",&tc); tc--; work());
    return 0;
}
