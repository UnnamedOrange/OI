#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define N 510
#define P 1010
#define Q 1010
using namespace std;
int t,n,W,p,q;
int w[N],p1[Q],p2[Q],id[Q];
int x[P],y[P],z[P],a[P],b[P],c[P],d[P],e[P],f[P];
long long ans,sum;
void cal()
{
    sum=0;
    for(int i=1; i<=n; i++)
        sum+=w[i];
    for(int i=1; i<=p; i++)
    {
        sum+=a[i]*abs(w[x[i]]-w[y[i]]);
        sum+=b[i]*abs(w[y[i]]-w[z[i]]);
        sum+=c[i]*abs(w[z[i]]-w[x[i]]);
        sum+=d[i]*(w[x[i]]-w[y[i]]);
        sum+=e[i]*(w[y[i]]-w[z[i]]);
        sum+=f[i]*(w[z[i]]-w[x[i]]);
    }
    ans=min(ans,sum);
}
bool check()
{
    for(int i=1; i<=q; i++)
        if(id[i]==0)
        {
            if(w[p1[i]]>w[p2[i]])
                return false;
        }
        else if(id[i]==1)
        {
            if(w[p1[i]]!=w[p2[i]])
                return false;
        }
        else if(w[p1[i]]>=w[p2[i]])
            return false;
    return true;
}
void dfs(int step)
{
    if(step==n+1)
    {
        if(check())
            cal();
    }
    else
    {
        w[step]=W;
        dfs(step+1);
        w[step]=-W;
        dfs(step+1);
    }
}
int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
int main()
{
    freopen("variable.in","r",stdin);
    freopen("variable.out","w",stdout);
    t=read();
    while(t--)
    {
        ans=1e18;
        n=read(),W=read(),p=read(),q=read();
        for(int i=1; i<=p; i++)
            x[i]=read(),y[i]=read(),z[i]=read(),a[i]=read(),b[i]=read(),c[i]=read(),d[i]=read(),e[i]=read(),f[i]=read();
        for(int i=1; i<=q; i++)
            p1[i]=read(),p2[i]=read(),id[i]=read();
        dfs(1);
        printf("%lld\n",ans);
    }
    return 0;
}
