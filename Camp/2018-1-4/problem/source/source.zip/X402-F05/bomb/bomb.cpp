#include <bits/stdc++.h>

#define getchar getchar_unlocked
#define For(i, j, k) for(int i = j; i <= k; i++)

using namespace std;

int Read(){
	char c = getchar();
	while(c > '9' || c < '0') c = getchar();
	int x = c - '0'; c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

const int N = 2e6 + 10;

int Begin[N], Next[N], to[N], e;

void add(int u, int v){
	to[++e] = v, Next[e] = Begin[u], Begin[u] = e;
}

int pre[N], low[N], stk[N], bel[N], sz[N], top, c;
int n, m;

void Tarjan(int o){
	static int dfs_clock = 0;
	low[o] = pre[o] = ++dfs_clock;
	stk[++top] = o;
	for(int i = Begin[o]; i; i = Next[i]){
		int u = to[i];
		if(!pre[u]) Tarjan(u), low[o] = min(low[o], low[u]);
		else if(!bel[u]) low[o] = min(low[o], pre[u]);
	}
	if(low[o] == pre[o]){
		bel[o] = ++c, sz[c + n] = 1;
		while(stk[top] != o) bel[stk[top--]] = c, ++sz[c + n];
		--top;
	}
}

int dp[N], ans;

void DFS(int o){
	dp[o] = sz[o];
	for(int i = Begin[o]; i; i = Next[i]){
		int u = to[i];
		if(!dp[u]) DFS(u);
		dp[o] = max(dp[o], dp[u] + sz[o]);
	}
	ans = max(ans, dp[o]);
}

int main(){

	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);

	n = Read(), m = Read();
	For(i, 1, m){
		int u = Read(), v = Read();
		add(u, v);
	}

	For(i, 1, n) if(!pre[i]) Tarjan(i);

	For(o, 1, n)
		for(int i = Begin[o]; i; i = Next[i]){
			int u = bel[o], v = bel[to[i]];
			if(u == v) continue;
			add(u + n, v + n);
		}

	For(o, n + 1, n + c) if(!dp[o]) DFS(o);
	printf("%d\n", ans);

	return 0;
}
