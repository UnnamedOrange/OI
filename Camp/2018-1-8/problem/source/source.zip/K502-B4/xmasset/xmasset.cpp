#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int type,n,T;
int main()
{
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	scanf("%d%d%d",&type,&n,&T);
	while(T--)
	{
		int x,y;
		scanf("%d%d",&x,&y); 
		if(type==1)
		{
			printf("%d\n",x);
		}
		else
		{
			if(x==y) printf("yes\n");
			else printf("no\n");
		}
	}
	return 0;
}

