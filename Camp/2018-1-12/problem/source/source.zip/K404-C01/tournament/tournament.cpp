//Achen
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
const int N=1e5+7;
const int mod=998244353;
typedef long long LL;
using namespace std;
LL ans,power[N];
int n,k,a[100][100],vis[N];

template<typename T>void read(T &x) {
	char ch=getchar(); x=0; T f=1;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') ch=getchar(),f=-1;
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0'; x*=f;
}

int DFS(int x,int d,int top) {
	vis[x]=1;
	for(int i=1;i<=n;i++) if(a[x][i]) {
		if(!vis[i]) {
			if(DFS(i,d+1,top)) return 1;
		}
		else if(i==top&&d+1==k) return 1;
	}
	return 0;
}

int check() {
	for(int i=1;i<=n;i++) {
		memset(vis,0,sizeof(vis));
		if(DFS(i,0,i)) return 1;
	}
	return 0;
}

void dfs(int x,int y) {
	if(x==n&&y==n+1) {
		ans+=check();
		return ;
	}
	if(y==n+1) { dfs(x+1,x+2); return ;}
	for(int i=0;i<2;i++) {
		a[x][y]=i;
		a[y][x]=i^1;
		dfs(x,y+1);
	}
}

#define DEBUG
int main() {
#ifdef DEBUG
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
#endif
	read(n); read(k);
	power[0]=1;
	for(int i=1;i<=1e5;i++) 
		power[i]=power[i-1]*2%mod;
	/*if(k==n) {
		ans=1; int ed=0;
		for(int i=1;i<n;i++) {
			ed+=i;
			(ans*=i)%=mod;
		}
		(ans*=power[ed-n])%=mod;
		printf("%lld\n",ans);
	}
	else {*/
		dfs(1,2);
		printf("%d\n",ans);
	//}
	return 0;
}
