//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const int maxn=100+7,INF=0x3f3f3f3f;
const ll mod=1e9+7;
int n,m,s,t;
ll dp[maxn][maxn];

int aa;char cc;
int read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

void mo(ll &x) {if(x>=mod) x-=mod;}

ll solve() {
	if(s<m||(!t)) return 0;
	t=min(t,s);
	dp[0][0]=1;int x;
	for(int i=1;i<=m;++i) {
		x=s; if(i<=n) x=t;
		for(int j=1;j<=s;++j) for(int k=1;k<=j&&k<=x;++k) {
			dp[i][j]+=dp[i-1][j-k];
			mo(dp[i][j]);
		}
	}
	ll rs=0;
	for(int i=m;i<=s;++i) {
		rs+=dp[m][i];
		mo(rs);
	}
	return rs;
}

int main() {
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	s=read(); t=read(); n=read(); m=read();
	printf("%lld",solve());
	fclose(stdin);fclose(stdout);
	return 0;
}
