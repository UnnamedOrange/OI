//2018-1-6
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define N (100000+5)

vector<int> G[N];
int col[N], fa[N];

void Dfs(int now, int F){
	fa[now] = F;
	For(i, 0, G[now].size()-1)
		if(G[now][i] != F) Dfs(G[now][i], now);
}

int ans;
bool vis[N];

void Dfs2(int now){
	vis[col[now]] = true;
	For(i, 0, G[now].size()-1)
		if(G[now][i] != fa[now]) Dfs2(G[now][i]);
}

void Query(int u, int L, int R){
	For(i, L, R) vis[i] = false;
	Dfs2(u);
	
	ans = 0;
	For(i, L, R) ans += vis[i];
	printf("%d\n", ans);
}

int main(){
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	
	int n, q, t, u, v;
	
	scanf("%d%d%d", &n, &q, &t);
	For(i, 1, n) scanf("%d", &col[i]);

	For(i, 1, n-1){
		scanf("%d%d", &u, &v);
		G[u].pb(v); G[v].pb(u);
	}
	Dfs(1, 0);

	int op, l, r, uc;

	while(q--){
		scanf("%d", &op);

		if(op == 1){
			scanf("%d%d%d", &u, &l, &r);
			if(t) u^=ans, l^=ans, r^=ans;
			Query(u, l, r);
		}else{
			scanf("%d%d", &u, &uc);
			if(t) u^=ans, uc^=ans;
			col[u] = uc;
		}
	}

	return 0;
}
