#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int mod = 1e9 + 7;
const int N = 100000 + 1000;

#define LL long long

int n, a, b;
int xi[N];
LL fac[N], inv[N], Tm[N], ans = 0, one = 0, zero = 0;
LL A[N], B[N], AB[N], f1 = 0, f2 = 0, f3 = 0, f4 = 0;

inline void open()
{
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
}

inline void close()
{
	fclose(stdin);
	fclose(stdout);
}

inline int read()
{
	int a = 0;
	char ch;
	int f = 1;
	while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
	if(ch == '-')
		f = -1;
	else
	{
		a = a * 10;
		a += ch - '0';
	}
	while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
	{
		a = a * 10;
		a += ch - '0';
	}
	return a * f;
}

inline void input()
{
	n = read(), a = read(), b = read();
	for(int i = 1;i <= n;++i)
		xi[i] = read();
}

inline LL ksm(LL x, int y)
{
	LL base = x, ret = 1;
	while(y > 0)
	{
		if(y & 1)
			ret = ret * base % mod;
		base = base * base % mod;
		y >>= 1;
	}
	return ret;
}

inline void init()
{
	fac[0] = inv[0] = Tm[0] = 1;
	for(int i = 1;i <= n + 10;++i)
	{
		Tm[i] = Tm[i - 1] * 2 % mod;
		fac[i] = fac[i - 1] * i % mod;
		inv[i] = ksm(fac[i], mod - 2);
	}
}

inline LL C(int x, int y)
{
	return fac[x] * inv[y] % mod * inv[x - y] % mod;
}

inline void work()
{
	init();
	for(int i = 1;i <= n;++i)
	{
		xi[i] = (xi[i] / a);
		xi[i] = (xi[i] & 1);
		if(xi[i])
			++one;
		else
			++zero;
	}
	for(int i = 1;i <= one;i += 2)
		ans = (ans + C(one, i) * Tm[zero] % mod) % mod;
	printf("0 0 %lld %lld\n", ans, ((Tm[n] - ans + mod) % mod));
}

inline void dfs(int o, int na, int nb, int nab)
{
	if(o == n + 1)
	{
		if(nab == 0)
		{
			if(na > nb)
				++f1;
			if(nb > na)
				++f2;
			if(na == nb)
			{
				if(na & 1 == 1)
					++f3;
				else
					++f4;
			}
		}
		else
		{
			int num = nab * (a + b);
			int nua = num / a, nub = num / b;
			if(na - nua > nb - nub)
				++f1;
			if(na - nua < nb - nub)
				++f2;
			if(na - nua == nb - nub)
			{
				if((na - nua) & 1)
					++f3;
				else
					++f4;
			}
		}
		return;
	}
	dfs(o + 1, na + A[o], nb + B[o], nab + AB[o]);
	dfs(o + 1, na, nb, nab);
}

inline void brute()
{
	for(int i = 1;i <= n;++i)
	{
		A[i] = xi[i] / a;
		B[i] = xi[i] / b;
		AB[i] = xi[i] / (a + b);
	}
	dfs(1, 0, 0, 0);
	printf("%lld %lld %lld %lld\n", f1, f2, f3, f4);
}

inline void gue()
{
	init();
	printf("%d 0 0 1\n", (Tm[n] - 1 + mod) % mod);
}

inline void check()
{
	if(a == b)
		work();
	else if(n <= 20)
		brute();
	else if(a == 1)
		gue();
	else
	{
		init();
		LL ni = ksm(4, mod - 2), nii = ksm(2, mod - 2);
		if(a < b)
			printf("%d 0 %d %d", Tm[n] * nii % mod, Tm[n] * ni % mod, Tm[n] * ni % mod);
		else
			printf("0 %d %d %d", Tm[n] * nii % mod, Tm[n] * ni % mod, Tm[n] * ni % mod);
	}
}

int main()
{
	open();
	input();
	check();
	close();
	return 0;
}
