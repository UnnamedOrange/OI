#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,a,b) for(i=a;i<=b;i++)
using namespace std;
const int N=2000010,maxn=2000000;
const int mod=1e9+7;
int cj[N],inv[N];int c[N];
int s,t,n,m;int ans;

int power(int x,int y){
	int ret=1;
	for(;y;y>>=1,x=1ll*x*x%mod){
		if(y&1)	ret=1ll*ret*x%mod;
	}
	return ret;
}

int C(int n,int m){return 1ll*cj[n]*inv[m]%mod*inv[n-m]%mod;}

int main(){
	freopen("success.in","r",stdin);
	freopen("success.out","w",stdout);
	int i,x;
	scanf("%d%d%d%d",&s,&t,&n,&m);
	cj[0]=1;rep(i,1,maxn)	cj[i]=1ll*cj[i-1]*i%mod;
	inv[maxn]=power(cj[maxn],mod-2);inv[0]=1;
	for(i=maxn-1;i;i--)	inv[i]=1ll*inv[i+1]*(i+1)%mod;
	if(s<m){printf("0\n");return 0;}
	if(m<=maxn&&s<=maxn){
		s-=m;
		rep(i,0,n)	if(s>=i*t){
			x=(i&1)?-1:1;
			c[s-i*t]=x*C(n,i);
			//ans=(ans+1ll*x*C(n,i)*C(s-i*t+m-1,m-1))%mod;
		}
		for(i=s;i>=0;i--){
			c[i]=(c[i]+c[i+1])%mod;
			ans=(ans+1ll*c[i]*C(i+m-1,m-1));
		}
		ans=(ans+mod)%mod;
		printf("%d\n",ans);
		return 0;
	}
}
			
