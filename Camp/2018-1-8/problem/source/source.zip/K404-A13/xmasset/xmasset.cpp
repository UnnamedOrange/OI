#include <bits/stdc++.h>

int type, N, bit, acmlt, spc;

void init() {
    
}

int encode(int x, int y) {
	bit = 0, acmlt = 1, spc;
    while(x || y) {
    	if(((x & acmlt) != 0) ^ ((y & acmlt) != 0)) {
			spc = (x & acmlt) ? 1 : 0;
			break;
		}
		++bit, acmlt <<= 1;
	}
	return (bit << 1) + spc;
}

bool decode(int q, int h) {
	int spc = h & 1, bit = h >> 1;
	if(!(((q & (1 << bit)) != 0) ^ (spc != 0))) return true;
	return false;
}

int main() {
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
