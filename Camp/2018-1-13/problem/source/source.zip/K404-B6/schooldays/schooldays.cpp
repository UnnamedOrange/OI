#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 2001
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
const int mod=1000000007;
int n,c[N],d[N],f[N],g[N];
int main()
{
	open(schooldays);
	re(n);
	for(int i=1;i<=n;++i)
		re(c[i]),re(d[i]);
	f[0]=1;
	for(int i=1;i<=n;++i)
		for(int j=i-1,l=c[i],r=d[i];j>=0;--j)
		{
			if(i-j>=l && i-j<=r)
			{
				if(g[j]==g[i]-1)
					f[i]=(f[i]+f[j])%mod;
				else if(g[j]>=g[i])
					g[i]=g[j]+1,f[i]=f[j];
			}
			l=max(l,c[j]);
			r=min(r,d[j]);
		}
	if(f[n])printf("%d %d\n",g[n],f[n]);
	else puts("-1");
}
