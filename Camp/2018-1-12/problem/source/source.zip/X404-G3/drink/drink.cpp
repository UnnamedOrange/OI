#include<bits/stdc++.h>
using namespace std;

#define rep(i,l,r) for(int i=l;i<=r;++i)
const int N=1e6+5;
int n;
int w[N];
int q[N];
bool w_da(int x,int y)
{
	return w[x]>w[y];
}

const int T=N*4;
struct SEG
{
#define cl (k*2)
#define cr (cl+1)
#define mid (l+r>>1)
double s[T],cnt[T];
void up(int k)
{
	s[k]=s[cl]+cnt[cl]*s[cr];
	cnt[k]=cnt[cl]*cnt[cr];
}
double get(int x)
{
	double ans=0;
	int k=1,l=1,r=n;
	while(l!=r)
	{
		if(x<=mid)
		{
			k=cl;r=mid;
		}
		else
		{
			k=cr;l=mid+1;	
		}
	}	
	s[k]+=x;cnt[k]*=0.5;
	double w=1;
	while(k>1)
	{
		if(!(k&1))
		{
			ans+=s[k+1]/2*w;
			w*=cnt[k+1];
		}
		up(k>>=1);
	}
	ans+=-x+(n+1)*w;
	return ans;
}
void init()
{
	rep(i,1,n*4)cnt[i]=1;
}
};
SEG segl,segr;
int main()
{
	freopen("drink.in","r",stdin);freopen("drink.out","w",stdout);
	cin>>n;
	rep(i,1,n) scanf("%d",w+i);
	rep(i,1,n) q[i]=i;
	sort(q+1,q+n+1,w_da);
	segl.init();segr.init();
	double ans=0;
	rep(i,1,n)
	{
		int x=q[i];
		double l=segl.get(n-x+1),r=segr.get(x);
		ans+=w[x]*l*r/2;
	}
	printf("%lf\n",ans/n/n);
}
