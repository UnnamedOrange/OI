#include <cstdio>
#include <algorithm>
#include <set>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

const int N = 100010;
const int M = 5000010;

struct edge{int to, next;} e[N << 1];
int n, q, cnt, t, tot, opt, x, y, l, r, xc, lstans;
int head[N], c[N], dfn[N], size[N], dep[N], wh[N], fa[N][21];
set <int> Ma[N];
set <int> :: iterator W;

struct SBT
{
	int rt[N << 2], left[M], right[M], size[M], key[M], tot;
	
	void left_rotate(int&x)
	{
		int y = right[x];
		right[x] = left[y];
		left[y] = x;
		size[y] = size[x];
		size[x] = size[left[x]] + size[right[x]] + 1;
		x = y;
	}
	
	void right_rotate(int&x)
	{
		int y = left[x];
		left[x] =right[y];
		right[y] = x;
		size[y] = size[x];
		size[x] = size[left[x]] + size[right[x]] + 1;
		x = y;
	}
	
	void maintain(int&x, bool fl)
	{
		if (!fl)
		{
			if (size[left[left[x]]] > size[right[x]]) right_rotate(x); else
			if (size[right[left[x]]] > size[right[x]]) 
			{
				left_rotate(left[x]);
				right_rotate(x);
			}
			else return;
		}
		else
		{
			if (size[right[right[x]]] > size[left[x]]) left_rotate(x); else
			if (size[left[right[x]]] > size[left[x]])
			{
				right_rotate(right[x]);
				left_rotate(x);
			}
			else return;
		}
		maintain(left[x], 0);
		maintain(right[x], 1);
		maintain(x, 1);
		maintain(x, 0);
	}
	
	void ins(int&x, int y)
	{
		if (!x)
		{
			x = ++tot;
			left[x] = right[x] = 0;
			size[x] = 1; key[x] = y;
		}
		else
		{
			++size[x];
			if (y < key[x]) ins(left[x], y); else ins(right[x], y);
			maintain(x, y >= key[x]);
		}
	}
	
	int find(int x, int y)
	{
		if (!x) return 0;
		if (key[x] <= y) return size[left[x]] + 1 + find(right[x], y);
			else return find(left[x], y);
	}
} T1, T2;

void ins(int x, int y)
{
	e[++cnt].to = y; e[cnt].next = head[x]; head[x] = cnt;
}

void dfs(int x, int y)
{
	dfn[x] = ++tot; size[x] = 1; wh[dfn[x]] = x;
	for(int i = 0; fa[x][i]; ++i) fa[x][i + 1] = fa[fa[x][i]][i];
	for(int i = head[x]; i; i = e[i].next)
		if (e[i].to != y)
		{
			dep[e[i].to] = dep[x] + 1;
			fa[e[i].to][0] = x;
			dfs(e[i].to, x);
			size[x] += size[e[i].to];
		}
}

int lca(int x, int y)
{
	if (!x) return 0;
	if (dep[x] < dep[y]) swap(x, y); int d = dep[x] - dep[y];
	for(int i = 20; ~i; --i) if (d & (1 << i)) x = fa[x][i];
	for(int i = 20; ~i; --i) if (fa[x][i] != fa[y][i]) x = fa[x][i], y = fa[y][i];
	return x == y ? x : fa[x][0];
}

void change(int h, int l, int r, int x, int c1, int c2)
{
	//printf("%d %d %d %d\n", l, r, c1, c2);
	T1.ins(T1.rt[h], c1); T2.ins(T2.rt[h], c2);
	if (l == r) return; int mid = (l + r) >> 1;
	if (x <= mid) change(h << 1, l, mid, x, c1, c2); else change(h << 1 | 1, mid + 1, r, x, c1, c2);
}

int find(int h, int l, int r, int ll, int rr, int x)
{
	if (l == ll && r == rr)
		return T1.find(T1.rt[h], dfn[x] + size[x] - 1) - T1.find(T1.rt[h], dfn[x] - 1) - T2.find(T2.rt[h], dfn[x] + size[x] - 1) + T2.find(T2.rt[h], dfn[x] - 1);
	int mid = (l + r) >> 1;
	if (rr <= mid) return find(h << 1, l, mid, ll, rr, x); else
	if (ll > mid) return find(h << 1 | 1, mid + 1, r, ll, rr, x); else
		return find(h << 1, l, mid, ll, mid, x) + find(h << 1 | 1, mid + 1, r, mid + 1, rr, x);
}

void ins(int x, int y, int C)
{
	if (C == 1) Ma[x].insert(dfn[y]); else Ma[x].erase(dfn[y]);
	W = Ma[x].upper_bound(dfn[y]);
	if (W != Ma[x].end())
	{
		if (*W <= dfn[y] + size[y] - 1) return;
	}
	
	int X1, X2, Z1, Z2, Z;
	
	W = Ma[x].lower_bound(dfn[y]);
	if (W == Ma[x].begin()) X1 = 0;
	else
	{
		--W;
		X1 = wh[*W];
	}
	
	W = Ma[x].lower_bound(dfn[y] + size[y]);
	if (W == Ma[x].end()) X2 = 0;
	else X2 = wh[*W];
	
	Z1 = lca(X1, y); Z2 = lca(X2, y);
	Z = dfn[Z1] < dfn[Z2] ? Z2 : Z1;
	if (C == -1) swap(y, Z);
	//if (C == 1 && x == 4) printf("%d %d %d\n", X1, X2, y);
	change(1, 1, n, x, dfn[y], dfn[Z]);
}

int main()
{
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &t);
	FOR(i, 1, n) scanf("%d", &c[i]);
	FOR(i, 2, n)
	{
		scanf("%d%d", &x, &y);
		ins(x, y); ins(y, x);
	}
	dfs(1, 0);
	FOR(i, 1, n) ins(c[i], i, 1);
	
	FOR(i, 1, q)
	{
		scanf("%d%d", &opt, &x);
		if (t) x ^= lstans;
		if (opt == 1)
		{
			scanf("%d%d", &l, &r);
			if (t) l ^= lstans, r ^= lstans;
			lstans = find(1, 1, n, l, r, x);
			printf("%d\n", lstans);
		}
		else
		{
			scanf("%d", &xc);
			if (t) xc ^= lstans;
			ins(c[x], x, -1); c[x] = xc;
			ins(c[x], x, 1);
		}
	}
	
	return 0;
}
