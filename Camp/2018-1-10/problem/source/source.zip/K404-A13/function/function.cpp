#include<cstdio>
#include<cmath>
#include<queue>
using namespace std;
const int maxn = 1e6 + 5;
int pri[maxn], miu[maxn], rho[maxn], vis[maxn], n, now, sq, ans, t;
queue<int > q;

int gcd(int a, int b) {
	return b ? gcd(b, a % b) : a;
}

void Prime(int N) {
	vis[1] = miu[1] = rho[1] = 1;
	for(register int i = 2; i <= N; ++i) {
		if(!vis[i]) pri[++pri[0]] = i, miu[i] = -1, rho[i] = 2;
		for(register int j = 1; i * pri[j] <= N && j <= pri[0]; ++j) {
			vis[i * pri[j]] = 1;
			if(i % pri[j] == 0) miu[i * pri[j]] = 0, q.push(i * pri[j]);
			else {
				miu[i * pri[j]] = miu[i] * miu[pri[j]];
				rho[i * pri[j]] = rho[i] * rho[pri[j]];
			}
		}
	}
}

int main() {
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		Prime(n);
		while(!q.empty()) {
			now = q.front(), sq = (int)sqrt(now), ans = 0, q.pop();
			for(register int i = 1; i <= sq; ++i)
				if(now % i == 0) ans += 2;
			if(sq * sq == now) --ans;
			rho[now] = ans;
		}
		ans = 0;
		for(register int i = 1; i <= n; ++i) {
			sq = (int)sqrt(i);
			for(register int j = 1; j <= sq + 2; ++j)
				if(i % j == 0) 
					ans += miu[j] * rho[i / j] * rho[i / j];
		}
		printf("%d\n", ans);
	}
	return 0;
}
