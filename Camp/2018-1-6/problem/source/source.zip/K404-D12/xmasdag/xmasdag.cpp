#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <set>

using namespace std;
#define MAXN 100000
#define MOD 998244353
#define G 3
#define ll long long
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int first[MAXN+5], in[MAXN+5], Gw[20], n, m, k, tot;
inline int fastpow(int s, int n){int a = 1; for(; n; n&1 ? a = 1ll*a*s%MOD : 0, s = 1ll*s*s%MOD, n >>= 1); return a;}
struct Edge{int to,nex; Edge(){} Edge(int _to, int _nex){to=_to,nex=_nex;}}e[(MAXN<<1)+5];
inline void Add(int a, int b){e[tot] = Edge(b,first[a]), first[a] = tot++, ++in[b];} inline void Inc(int &x, int v){x += v, x<MOD?:x-=MOD;}
namespace Brute
{
int F[2005][2005], Ans[2005];
void Topo()
{
	static int q[MAXN+5], head, tail; head = tail = 0, F[1][0] = 1;
	for(rint i = 1; i <= n; in[i]?:q[++tail] = i, i++);
	for(rint p, u, v, j; head<tail; )
		for(p = q[++head], u = first[p]; ~u; u = e[u].nex)
			for(!--in[v=e[u].to] ? q[++tail] = v : 0, j = 0; j < n; Inc(F[v][j+1],F[p][j]), j++);
	for(rint j = 1, i, t; j <= n; j++)
		for(t = fastpow(j,k), i = 1; i <= n; Inc(Ans[i],1ll*F[i][j]*t%MOD), i++);
}
}
namespace k_1
{
int f[MAXN+5], Ans[MAXN+5];
void Topo()
{
	static int q[MAXN+5], head, tail; head = tail = 0, f[1] = 1;
	for(rint i = 1; i <= n; in[i]?:q[++tail] = i, i++);
	for(rint p, u, v; head<tail; )
		for(p = q[++head], u = first[p]; ~u; u = e[u].nex)
			!--in[v=e[u].to] ? q[++tail] = v : 0, Inc(f[v],f[p]), Inc(Ans[v],Ans[p]), Inc(Ans[v],f[p]);
}
}
namespace DP
{
int f[MAXN+5][35], C[35][35], A[35];
void Pre(int f0[])
{
	for(rint i = 0, j; i <= k; i++)
		for(A[i] = 0, j = 0; j <= i; Inc(A[i],1ll*C[i][j]*f0[j]%MOD), j++);
}
inline void Trans(int f1[]){for(rint i = 0, j; i <= k; Inc(f1[i],A[i]), i++);}
void Topo()
{
	for(rint i = 0, j; i <= k; i++) for(C[i][0] = 1, j = 1; j <= i; C[i][j] = C[i-1][j]+C[i-1][j-1], C[i][j]<MOD?:C[i][j]-=MOD, j++);
	static int q[MAXN+5], head, tail; head = tail = 0, f[1][0] = 1;
	for(rint i = 1; i <= n; in[i]?:q[++tail] = i, i++);
	for(rint p, u, v; head<tail; )
		for(p = q[++head], Pre(f[p]), u = first[p]; ~u; u = e[u].nex)
			!--in[v=e[u].to] ? q[++tail] = v : 0, Trans(f[v]);
	for(rint i = 1; i <= n; Out(f[i++][k]), Outc('\n')); _END;
}
}
namespace NTT
{
int f[MAXN+5][512+5], fac[1024+5], efac[1024+5], Rv[MAXN+5], LOG[1024+5], A[1024+5], B[1024+5], L;
void RV(int n){for(rint i = 0, l = ~-LOG[n]; i < n; Rv[i] = Rv[i>>1]>>1|(i&1)<<l, i++);}
void NTT(int R[], int n, int tag)
{
	int root, per, t; for(rint i = 0; i < n; i<Rv[i] ? R[i]^=R[Rv[i]]^=R[i]^=R[Rv[i]] : 0, i++);
	for(rint d = 0, i, j, m; (m=1<<d) < n; d++)
		for(per = Gw[d], i = 0; i < n; i += m<<1)
			for(root = 1, j = 0; j < m; t = 1ll*R[i+j+m]*root%MOD, R[i+j+m] = (MOD+R[i+j]-t)%MOD, R[i+j] = (R[i+j]+t)%MOD, root = 1ll*root*per%MOD, j++);
	if(tag<0){reverse(R+1,R+n), t = fastpow(n,MOD-2); for(rint i = 0; i < n; R[i] = 1ll*R[i]*t%MOD, i++);}
}
void Pre(int f0[])
{
	for(rint i = 0; i < L; A[i] = i<=k?1ll*f0[i]*efac[i]%MOD:0, i++); NTT(A,L,1);
	for(rint i = 0; i < L; A[i] = 1ll*A[i]*B[i]%MOD, i++); NTT(A,L,-1);
	for(rint i = 0; i < L; A[i] = 1ll*fac[i]*A[i]%MOD, i++);
}
void Trans(int f1[]){for(rint i = 0; i <= k; Inc(f1[i],A[i]), i++);}
void Topo()
{
	for(rint i = 0; i <= 15; Gw[i] = fastpow(G,~-MOD/((1<<i)<<1)), i++);
	for(L = 1; L <= k; L <<= 1); L <<= 1; for(rint i = 2; i <= L; LOG[i] = -~LOG[i>>1], i++); RV(L);
	fac[0] = 1; for(rint i = 1; i <= L; fac[i] = 1ll*i*fac[i-1]%MOD, i++);
	efac[L] = fastpow(fac[L],MOD-2); for(rint i = L; i; efac[i-1] = 1ll*i*efac[i]%MOD, i--);
	for(rint i = 0; i < L; B[i] = i<=k?efac[i]:0, i++); NTT(B,L,1);
	static int q[MAXN+5], head, tail; head = tail = 0, f[1][0] = 1;
	for(rint i = 1; i <= n; in[i]?:q[++tail] = i, i++);
	for(rint p, u, v; head<tail; )
		for(p = q[++head], Pre(f[p]), u = first[p]; ~u; u = e[u].nex)
			!--in[v=e[u].to] ? q[++tail] = v : 0, Trans(f[v]);
	for(rint i = 1; i <= n; Out(f[i++][k]), Outc('\n')); _END;
}
}
int main()
{
	freopen("xmasdag.in","r",stdin), freopen("xmasdag.out","w",stdout);
	n = read(), m = read(), k = read(), memset(first+1,-1,n<<2); for(rint i = 1, u, v; i <= m; u = read(), v = read(), Add(u,v), i++);
	if(n <= 2000 && m <= 5000) Brute::Topo(); else if(k == 1) k_1::Topo(); else if(k <= 30) DP::Topo(); else NTT::Topo(); return 0;
}
