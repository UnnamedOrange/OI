#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
using namespace std;

struct equ
{
	int x;
	int y;
	int z;
	int a;
	int b;
	int c;
	int d;
	int e;
	int f;
};

struct cons
{
	int x;
	int y;
	int r;
};

const int MAXN = 600;
long long ans = 1e18;
int n, W, p, q;
int visit[MAXN];
equ e[MAXN];
cons c[MAXN];

namespace Force
{
	void check(int v)
	{		
		for (int i = 0; i < q; ++i)
		{
			if (c[i].r == 0 && visit[c[i].x] > visit[c[i].y])
				return;
			else if (c[i].r == 1 && visit[c[i].x] != visit[c[i].y])
				return;
			else if (c[i].r == 2 && visit[c[i].x] >= visit[c[i].y])
				return;
		}
		long long sum = v * W;
		for (int i = 0; i < p; ++i)
		{
			long long t = e[i].a * abs(visit[e[i].x] - visit[e[i].y]) +
 						  e[i].b * abs(visit[e[i].y] - visit[e[i].z]) + 
 						  e[i].c * abs(visit[e[i].z] - visit[e[i].x]) +
 						  e[i].d * (visit[e[i].x] - visit[e[i].y]) + 
 						  e[i].e * (visit[e[i].y] - visit[e[i].z]) +
 						  e[i].f * (visit[e[i].z] - visit[e[i].x]);
		 	sum += t * W;
		}
		ans = min(sum, ans);
	}
	void dfs(int p, int v)
	{
		if (p == n + 1)
			check(v);
		else if (p < n + 1)
		{
			visit[p] = -1;
			dfs(p + 1, v - 1);
			visit[p] = 1;
			dfs(p + 1, v + 1);
			visit[p] = 0;
		}
	}
	void main()
	{
		dfs(1, 0);
		printf("%lld\n", ans);
	}
}

int read()
{
	int x;
	scanf("%d", &x);
	return x;
}

int main()
{
	freopen("variable.in", "r", stdin);
	freopen("variable.out", "w", stdout);
	int T = read();
	while (T--)
	{
		n = read();
		W = read();
		p = read();
		q = read();
		for (int i = 0; i < p; ++i)
		{
			e[i].x = read();
			e[i].y = read();
			e[i].z = read();
			e[i].a = read();
			e[i].b = read();
			e[i].c = read();
			e[i].d = read();
			e[i].e = read();
			e[i].f = read();
		}
		for (int i = 0; i < q; ++i)
		{
			c[i].x = read();
			c[i].y = read();
			c[i].r = read();
		}
		Force::main();
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
