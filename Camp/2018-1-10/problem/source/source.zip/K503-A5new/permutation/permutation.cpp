#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[100100];
int b[100100];
bool visited[100100];
bool dfs(int x, int dep) {
	if (visited[x]) {
		if (dep%2!=0) return true;
		return false;
	}
	visited[x]=true;
	return dfs(b[x],dep+1);
}
int tmp[100100];
void work(int x) {
	int cur=1;
	x=x-2;
	for (int i=3;x;i+=2,x-=2) {
		cur=(ll)cur*i%998244353;
	}
	cout << (ll)cur*cur%998244353 << endl;
	return ;
}
int main() {
	freopen("permutation.in","r",stdin);
	freopen("premutation.out","w",stdout);
	ios::sync_with_stdio(false);
	int n;
	cin >> n;
	if (n%2==1) {
		cout << 0 << endl;
		return 0;
	}
	bool tag=true;
	for (int i=1;i<=n;i++) {
		cin >> a[i];
		if (a[i]!=0) tag=false;
		b[i]=i;
	}
	if (tag) {
		work(n);
		return 0;
	}
	int ans=0;
	do {
		bool flag=true;
		for (int i=1;i<=n;i++) {
			if (a[i]==0 || b[i]==a[i]) continue;
			else {
				flag=false;
				break;
			}
		}
		if (flag) {
//			for (int i=1;i<=n;i++) {
//				cout << b[i] << " ";
//			}
//			cout << endl;
			memset(visited,0,sizeof(visited));
			bool flag2=true;
			for (int i=1;i<=n;i++) {
				if (!visited[i]) {
					if (!dfs(i,1)) {
						flag2=false;
						break;
					}
				}
			}
			if (flag2==true) ans++;
		}
	}while (next_permutation(b+1,b+n+1));
	cout << ans << endl;
	return 0;
}

