#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
const int N=1000005;
bool in_st[N];
int n,m,cnt,ans,u,v,tcnt,h[N],th[N];
int dfn[N],low[N],lim,f[N];
int cty,tot[N],st[N],C[N],maxn,d[N];
struct edge{int v,n;} e[N],te[N];

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

void addedge(int u,int v)
{
	e[cnt]=(edge){v,h[u]},h[u]=cnt++;
}

void addedge_(int u,int v)
{
	te[tcnt]=(edge){v,th[u]},th[u]=tcnt++;
}

void tarjan(int x)
{
	dfn[x]=low[x]=++lim;
	in_st[st[++*st]=x]=1;
	for(int i=h[x]; i!=-1; i=e[i].n)
		if(!dfn[e[i].v]) tarjan(e[i].v),low[x]=min(low[x],low[e[i].v]);
		else if(in_st[e[i].v]) low[x]=min(low[x],dfn[e[i].v]);
	if(dfn[x]==low[x])
	{
		++cty;
		while(st[*st]!=x) ++tot[cty],C[st[*st]]=cty,in_st[st[(*st)--]]=0;
		++tot[cty],C[st[*st]]=cty,in_st[st[(*st)--]]=0;
	}
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);	
	n=getint(),m=getint();
	memset(h,-1,sizeof(h));
	memset(th,-1,sizeof(th));
	rep(i,1,m) u=getint(),v=getint(),addedge(u,v);
	rep(i,1,n) if(!dfn[i]) tarjan(i);
	rep(x,1,n)
	{
		for(int i=h[x]; i!=-1; i=e[i].n)
			if(C[x]!=C[e[i].v])
				addedge_(C[x],C[e[i].v]),++d[C[e[i].v]];
	}
	rep(i,1,cty)
	{
		maxn=0;
		for(int j=th[i]; j!=-1; j=te[j].n)
			maxn=max(maxn,f[te[j].v]);
		f[i]=maxn+tot[i];
	}
	rep(i,1,cty) if(!d[i]) ans=max(ans,f[i]);
	printf("%d\n",ans);
	return 0;
}
