#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int INF=1e9;
const long double eps=1e-9;
inline int read(){
	int x=0,flag=1;
	char ch=getchar();
	while(!isdigit(ch) && ch!='-')ch=getchar();
	if(ch=='-')flag=-1,ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	return x*flag;
}
int main(){
	int i,n,opt,T;
	opt=read();
	n=read();T=read();
	while(T--){
		if(opt==1){
			int x,y;
			x=read();y=read();
			for(i=1;i<=10;i++)
				if((x & (1<<(i-1)))==0 && (y & (1<<(i-1)))!=0){
					printf("%d\n",i);
					break;
				}
			if(i==11)printf("%d\n",10+__builtin_popcount(x));
		}
		else{
			int q,h;
			q=read();h=read();
			if(h<=10){
				if((q & (1<<(h-1)))==0)puts("yes");
				else puts("no");
			}
			else{
				if(h-10==__builtin_popcount(q))puts("yes");
				else puts("no");
			}
		}
	}
	return 0;
}

