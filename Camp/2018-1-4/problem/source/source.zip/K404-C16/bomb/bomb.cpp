#include<bits/stdc++.h>
using namespace std;
int re(){
	int ret=0;char ch=getchar();
	while(ch<'0'||'9'<ch)ch=getchar();
	while('0'<=ch&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret;
}
#define N 1000010
struct edge{int v,nex;}e[N];
int c[N];
int col[N],dfn[N],low[N];
int sta[N],top,tim;
int siz[N];
void tarjan(int pos){
	dfn[pos]=low[pos]=tim++;
	sta[++top]=pos;
	for(int i=c[pos];i;i=e[i].nex){
		int tar=e[i].v;
		if(!col[tar]){
			if(!dfn[tar])
				tarjan(tar);
			low[pos]=min(low[pos],low[tar]);
		}
	}
	if(low[pos]==dfn[pos]){
		while(sta[top]!=pos){
			col[sta[top]]=pos;
			top--;
			siz[pos]++;
		}
		top--;
		siz[pos]++;
		col[pos]=pos;
	}
	return;
}
int f[N];
int r(int x){
	if(f[x])
		return f[x];
	for(int i=c[x];i;i=e[i].nex){
		int tar=col[e[i].v];
		if(tar!=x){
			f[x]=max(f[x],r(tar));
		}
	}
	f[x]+=siz[x];
	return f[x];
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	int n,m;
	n=re();m=re();
	int a,b;
	for(int i=1;i<=m;i++){
		a=re();b=re();
		e[i]=(edge){b,c[a]};
		c[a]=i;
	}
	memset(dfn,0,sizeof(dfn));
	memset(low,0,sizeof(low));
	memset(col,0,sizeof(col));
	top=0;tim=1;
	for(int i=1;i<=n;i++)
		if(!col[i])
			tarjan(i);
	for(int i=1;i<=n;i++){
		if(col[i]!=i){
			int j=c[i];
			while(j){
				int k=e[j].nex;
				e[j].nex=c[col[i]];
				c[col[i]]=j;
				j=k;
			}
		}
	}
	int ans=0;
	memset(f,0,sizeof(f));
	for(int i=1;i<=n;i++)
		if(col[i]==i)
			ans=max(ans,r(i));
	cout<<ans<<endl;
	return 0;
}
