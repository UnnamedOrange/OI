#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
const int IND = 0x3f3f3f3f;
int t;
int n, W, p, q;
int x[1010], y[1010], z[1010], A[1010], B[1010], C[1010], D[1010], E[1010], F[1010];
int X[1010], Y[1010], R[1010];
int w[1010];
long long ans = 1ll << 60;
inline void dfs (int step, long long sum) {
	if (step > n) {
		for (int i = 1; i <= p; i++) sum += A[i] * abs (w[x[i]] - w[y[i]]) + B[i] * abs (w[y[i]] - w[z[i]]) + C[i] * abs (w[z[i]] - w[x[i]]) + D[i] * (w[x[i]] - w[y[i]]) + E[i] * (w[y[i]] - w[z[i]]) + F[i] * (w[z[i]] - w[x[i]]);
		bool b = true;
		for (int i = 1; i <= q; i++) {
			if (R[i] == 0 && w[X[i]] > w[Y[i]]) b = false;
			if (R[i] == 1 && w[X[i]] != w[Y[i]]) b = false;
			if (R[i] == 2 && w[X[i]] >= w[Y[i]]) b = false;
		}
		if (b) ans = min (ans, sum);
		return;
	}
	w[step] = W;
	dfs (step + 1, sum + W);
	w[step] = -W;
	dfs (step + 1, sum - W);
}
inline void solve () {
	scanf ("%d%d%d%d", &n, &W, &p, &q);
	for (int i = 1; i <= p; i++) scanf ("%d%d%d%d%d%d%d%d%d", &x[i], &y[i], &z[i], &A[i], &B[i], &C[i], &D[i], &E[i], &F[i]);
	for (int i = 1; i <= q; i++) scanf ("%d%d%d", &X[i], &Y[i], &R[i]);
	dfs (1, 0);
	printf ("%lld\n", ans);
}
int main () {
	freopen ("variable.in", "r", stdin);
	freopen ("variable.out", "w", stdout);
	scanf ("%d", &t);
	while (t--) solve ();
	return 0;
}
