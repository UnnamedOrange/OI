#include <cstdio>
#include <queue>
#include <cstring>
using namespace std;
#define INF 2139062143
#define N 30
int b[4000000],a[N],c[N],n,i,j,k;
bool d[N];
queue<int> q;
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int t;scanf("%d",&t);
	while (t--){
		scanf("%d",&n);
		for (i=1;i<=n;i++) scanf("%d",&a[i]);
		int x=0,szx=1;
		for (i=1;i<=n;i++){int gh=0;
			for (j=1;j<=i;j++) if (a[j]<a[i]) gh++;
			x+=gh*szx;szx*=i;
		}memset(b,0x7f,sizeof(b));b[x]=0;
		q.push(x);
		while (!q.empty()){
			int psz=q.front(),pszz=psz;q.pop();
			int fdc=1;memset(d,true,sizeof(d));
			for (i=1;i<=n;i++) fdc*=i;
			for (i=n;i>=1;i--){
				fdc/=i;int gh=psz/fdc;psz-=gh*fdc;
				gh++;for (j=1;j<=n;j++) if (d[j]){
					if (--gh==0){
						a[i]=j;
						d[j]=false;
						break;
					}
				}
			}
			for (j=2;j<=n;j++){
				for (k=1;k<=j;k++) c[k]=a[j+1-k];
				for (k=j+1;k<=n;k++) c[k]=a[k];
				x=0;szx=1;
				for (i=1;i<=n;i++){int gh=0;
					for (k=1;k<=i;k++) if (c[k]<c[i]) gh++;
					x+=gh*szx;szx*=i;
				}
				if (b[x]==INF) b[x]=b[pszz]+1,q.push(x);
			}
		}
		for (i=1;i<=n;i++) a[i]=i;
		x=0;szx=1;
		for (i=1;i<=n;i++){int gh=0;
			for (j=1;j<=i;j++) if (a[j]<a[i]) gh++;
			x+=gh*szx;szx*=i;
		}
		printf("%d\n",b[x]);
	}
	return 0;
}
