#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <sstream>
#include <cctype>
#include <cmath>
#include <algorithm>
#define THE_BRST_PONY "Rainbow Dash"

using namespace std;
const int N=110,INF=~0u>>2;

int T,n;
int pa[N][N],dp[N][N];
char str[N];

int main() {
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d",&T);
	while(T--) {
		memset(pa,false,sizeof(pa));
		memset(dp,0,sizeof(dp));
		scanf("%d%s",&n,str);
		for(int i=0;i<n;i++) {
			for(int j=0;i-j>=0&&i+j<n;j++) {
				if(str[i+j]==str[i-j])
					pa[i-j][i+j]=true;
				else break;
			}
		}
		for(int i=1;i<=n;i++) {
			for(int j=0;j+i-1<n;j++) {
				if(!pa[j][j+i-1]) dp[j][j+i-1]=1;
				else {
					dp[j][j+i-1]=INF;
					for(int k=1;k<i;k++)
						dp[j][i+j-1]=min(dp[j][i+j-1],dp[j][j+k-1]+dp[j+k][j+i-1]);
				}
			}
		}
		if(dp[0][n-1]>=INF) printf("-1\n");
		else printf("%d\n",dp[0][n-1]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

