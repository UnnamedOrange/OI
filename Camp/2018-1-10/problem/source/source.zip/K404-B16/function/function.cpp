#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)

using namespace std;

typedef long long LL;
const int N = 1000010;
int n; LL ans;
bool h[N];
int p[N], cnt, mu[N], num[N], d[N], sum[N];

void shaker() {
	int i, j;
	mu[1] = 1; num[1] = 1;
	rep(i, 2, 1000000) {
		if(!h[i]) {
			p[++cnt] = i;
			mu[i] = -1;
			num[i] = 2; d[i] = 1;
		}
		for(j = 1; j <= cnt && i * p[j] <= 1000000; ++j) {
			h[i*p[j]] = 1;
			if(i % p[j] == 0) {
				mu[i*p[j]] = 0;
				num[i*p[j]] = num[i] / (d[i]+1) * (d[i]+2);
				d[i*p[j]] = d[i] + 1;
				break;
			} else {
				mu[i*p[j]] = -mu[i];
				num[i*p[j]] = num[i] * 2;
				d[i*p[j]] = 1;
			}
		}
	}
	rep(i, 1, 1000000) sum[i] = sum[i-1] + mu[i];
}

int main() {
	freopen("function.in", "r", stdin); freopen("function.out", "w", stdout);
	int i, T;
	shaker();
	scanf("%d", &T);
	while(T--) {
		ans = 0;
		scanf("%d", &n);
		rep(i, 1, n) ans += (LL)num[i] * num[i] * sum[n/i];
		printf("%lld\n", ans);
	}
	return 0;
}
