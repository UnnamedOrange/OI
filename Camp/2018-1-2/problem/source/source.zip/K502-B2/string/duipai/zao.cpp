#include<cstdio>
#include<cstring>
#include<ctime>
#include<cstdlib>
#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	freopen("string.in","w",stdout);
	srand(time(NULL));
	int n=rand()%6+5;
	int a[15];
	for(int i=1;i<=n/2+1;i++)a[i]=rand()%3+'a';
	for(int l=1,r=n;l<r;l++,r--)a[r]=a[l];
	puts("2");
	printf("%d\n",n);
	for(int i=1;i<=n;i++)printf("%c",a[i]);putchar('\n');
	n=rand()%6+5;
	for(int i=1;i<=n/2+1;i++)a[i]=rand()%3+'a';
	for(int l=1,r=n;l<r;l++,r--)a[r]=a[l];
	printf("%d\n",n);
	for(int i=1;i<=n;i++)printf("%c",a[i]);putchar('\n');
	return 0;
}
