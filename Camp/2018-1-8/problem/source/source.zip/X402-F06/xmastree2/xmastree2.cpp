#include<bits/stdc++.h>
using namespace std;
#define REP(i,st,ed) for(register int i=st,i##end=ed;i<=i##end;++i)
#define DREP(i,st,ed) for(register int i=st,i##end=ed;i>=i##end;--i)
typedef long long ll;
inline int read(){
	int x;
	char c;
	int f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1)+(x<<3)+(c^'0');
	return x*f;
}
inline ll readll(){
	ll x;
	char c;
	ll f=1;
	while((c=getchar())!='-' && (c<'0' || c>'9'));
	if(c=='-') c=getchar(),f=-1;
	x=c^'0';
	while((c=getchar())>='0' && c<='9') x=(x<<1ll)+(x<<3ll)+(c^'0');
	return x*f;
}
#define begin Begin
#define next Next
const int maxn=30000+10;
inline bool chkmax(int &x,int y){return (y>x)?(x=y,1):0;}
inline bool chkmin(int &x,int y){return (y<x)?(x=y,1):0;}
int rt[maxn],tmp;
int n,a[maxn],p[maxn];
int pos[maxn];
int begin[maxn],next[maxn<<1],to[maxn<<1],e;
inline void add_edge(int x,int y){
	to[++e]=y;
	next[e]=begin[x];
	begin[x]=e;
}
bool dfs(int x,int ff){
	for(int i=begin[x];i;i=next[i]){
		if(to[i]==ff) continue;
		if(pos[to[i]]<pos[x]) return 0;
		if(!dfs(to[i],x)) return 0;
	}
	return 1;
}
bool pd(){
	REP(i,1,n) pos[p[i]]=i;
	REP(i,1,tmp) if(dfs(rt[i],0)) return 1;
	return 0;
}
int main(){
#ifndef ONLINE_JUDGE
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
#endif
	n=read();
	REP(i,1,n-1){
		int x=read(),y=read();
		add_edge(x,y),add_edge(y,x);
	}
	REP(i,1,n){
		a[i]=read();
		int ty=read();
		if(ty==1) rt[++tmp]=1; 
	}
	int Pw=1;
	REP(i,1,n) Pw*=i;
	REP(i,1,n) p[i]=i;
	int ans=0;
	REP(i,1,Pw){
		if(pd()){
			int num=0;
			REP(j,1,n) num+=a[p[j]]*j;
			chkmax(ans,num);
		}
		next_permutation(p+1,p+n+1);
	}
	printf("%d\n",ans);
	return 0;
}
