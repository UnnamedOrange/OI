#include <iostream>
#include <cstdio>
#include <cstring>
#define N 100005
using namespace std;
struct edge{
	int k,next;
}e[N<<1];
int n,m,TT,a[N],home[N],cnt=-1,D,vis[N],ans;
void add(int x,int y){
	cnt++;
	e[cnt].k=y;
	e[cnt].next=home[x];
	home[x]=cnt;
}
int fa[N],L,R;
void dfs(int k,int F){
	fa[k]=F;
	if(vis[a[k]]!=D&&a[k]>=L&&a[k]<=R) vis[a[k]]=D,ans++;
	for(int i=home[k];~i;i=e[i].next){
		if(e[i].k!=F){
			dfs(e[i].k,k);
		}
	}
}
int main(){
	freopen("xmastree1.in","r",stdin);
	freopen("xmastree1.out","w",stdout);
	memset(home,-1,sizeof(home));
	scanf("%d%d%d",&n,&m,&TT);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1,x,y;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	dfs(1,0);
	for(int i=1,op,x,l,r,lst=0;i<=m;i++){
		scanf("%d%d%d",&op,&x,&l);
		if(TT) x^=lst,l^=lst;
		if(op==1){
			scanf("%d",&r);
			if(TT) r^=lst;
			L=l;R=r;
			D++;ans=0;
			dfs(x,fa[x]);
			printf("%d\n",ans);
			lst=ans;
		}
		else{
			a[x]=l;
		}
	}
	return 0;
}
