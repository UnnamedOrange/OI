#include <bits/stdc++.h>

namespace {

inline char read() {
	static const int IN_LEN = 1 << 18 | 1;
	static char buf[IN_LEN], *s, *t;
	return (s == t) && (t = (s = buf) + fread(buf, 1, IN_LEN, stdin)), 
			(s == t) ? -1 : *s++;
}

template <typename T>
inline void read(T &x) {
	static char c;
	static bool iosig;
	for (c = read(), iosig = false; !isdigit(c); c = read()) {
		if (c == -1) return;
		iosig |= c == '-';
	}
	for (x = 0; isdigit(c); c = read()) x = x * 10 + (c ^ '0');
	iosig && (x = -x);
}

inline void read(char &c) {
	while (c = read(), isspace(c) && c != -1)
		;
}

inline int read(char *buf) {
	register int s = 0;
	register char c;
	while (c = read(), isspace(c) && c != -1)
		;
	if (c == -1) {
		*buf = 0;
		return -1;
	}
	do
		buf[s++] = c;
	while (c = read(), !isspace(c) && c != -1);
	buf[s] = 0;
	return s;
}

const int OUT_LEN = 1 << 18 | 1;

char obuf[OUT_LEN], *oh = obuf;

inline void print(char c) {
	(oh == obuf + OUT_LEN) && (fwrite(obuf, 1, OUT_LEN, stdout), oh = obuf);
	*oh++ = c;
}

template <typename T>
inline void print(T x) {
	static int buf[21], cnt;
	if (x != 0) {
		(x < 0) && (print('-'), x = -x);
		for (cnt = 0; x; x /= 10) buf[++cnt] = x % 10 | 48;
		while (cnt) print((char)buf[cnt--]);
	} else {
		print('0');
	}
}

inline void print(const char *s) {
	for (; *s; s++) print(*s);
}

struct InputOutputStream {
	~InputOutputStream() {
		fwrite(obuf, 1, oh - obuf, stdout);
	}

	template <typename T>
	inline InputOutputStream &operator>>(T &x) {
		read(x);
		return *this;
	}
	
	template <typename T>
	inline InputOutputStream &operator<<(const T &x) {
		print(x);
		return *this;
	}
} io;

const int MAXN = 500 + 9;

int n, W, p, q;

namespace Force {

const int MAXF = 15 + 2;

int x[MAXF], y[MAXF], z[MAXF], a[MAXF], b[MAXF];
int c[MAXF], d[MAXF], e[MAXF], f[MAXF], w[MAXF];

struct Limit {
    int x, y, r;
} l[23];

int ans;

void dfs(int i) {
    if (i > n) {
        for (register int i = 1; i <= q; i++) {
            switch (l[i].r) {
                case 0: {
                    if (w[l[i].x] > w[l[i].y]) return;
                    break;
                }
                case 1: {
                    if (w[l[i].x] != w[l[i].y]) return;
                    break;
                }
                case 2: {
                    if (w[l[i].x] >= w[l[i].y]) return;
                    break;
                }
            }
        }
        register int tmp = 0;
        for (register int i = 1; i <= n; i++) {
            tmp += w[i] + a[i] * std::abs(w[x[i]] - w[y[i]]) 
                        + b[i] * std::abs(w[y[i]] - w[z[i]])
                        + c[i] * std::abs(w[z[i]] - w[x[i]])
                        + d[i] * (w[x[i]] - w[y[i]])
                        + e[i] * (w[y[i]] - w[z[i]])
                        + f[i] * (w[z[i]] - w[x[i]]);
        }
        ans = std::min(ans, tmp);
        return;
    }
    w[i] = W;
    dfs(i + 1);
    w[i] = -W;
    dfs(i + 1);
}

inline void solve() {
    for (register int i = 1; i <= p; i++) {
        io >> x[i] >> y[i] >> z[i] >> a[i] >> b[i] 
           >> c[i] >> d[i] >> e[i] >> f[i];
    }
    for (register int i = 1; i <= q; i++)
        io >> l[i].x >> l[i].y >> l[i].r;
    ans = INT_MAX;
    dfs(1);
    io << ans << '\n';
}
}

const long long INF = 0x3f3f3f3f;

struct Node {
	int v;
    long long f;
    int index;

	Node(int v, long long f, int index) : v(v), f(f), index(index) {}
};

std::vector<Node> edge[MAXN]; 

inline void addEdge(const int u, const int v, const long long f) {
	edge[u].push_back(Node(v, f, edge[v].size()));
	edge[v].push_back(Node(u, 0, edge[u].size() - 1));
}

int h[MAXN], gap[MAXN];

inline long long sap(int v, long long flow, int s, int t, int n) {
	if (v == t) return flow;
	static int iter[MAXN];
	register long long rec = 0;
	for (register int &i = iter[v]; i < (int)edge[v].size(); i++) {
		Node *p = &edge[v][i];
		if (p->f > 0 && h[v] == h[p->v] + 1) {
			register long long ret = sap(p->v, std::min(flow - rec, p->f), s, t, n);
			p->f -= ret;
			edge[p->v][p->index].f += ret;
			if ((rec += ret) == flow || h[s] >= n) return iter[v] = 0, rec;
		}
	}
	if (--gap[h[v]] == 0) h[s] = n;
	gap[++h[v]]++;
	iter[v] = 0;
	return rec;
}

inline long long sap(int s, int t, int n) {
    register long long ret = 0;
	memset(gap, 0, sizeof(int) * n);
	memset(h, 0, sizeof(int) * n);
	for (gap[0] = n; h[s] < n;) ret += sap(s, INF, s, t, n);
	return ret;
}

long long ex[MAXN];

inline void solveCase() {
	io >> n >> W >> p >> q;
    if (n <= 15) {
        Force::solve();
        return;
    }
    const int S = 0, T = n + 1;
	for (register int i = S; i <= T; i++) edge[i].clear();
    for (register int i = 1; i <= n; i++) ex[i] = 2;
	for (register int i = S, x, y, z, a, b, c, d, e, f; i < p; i++) {
        io >> x >> y >> z >> a >> b >> c >> d >> e >> f;
        ex[x] += (d - f) * 2;
        ex[y] += (e - d) * 2;
        ex[z] += (f - e) * 2;
        addEdge(x, y, a * 2);
        addEdge(y, x, a * 2);
        addEdge(y, z, b * 2);
        addEdge(z, y, b * 2);
        addEdge(x, z, c * 2);
        addEdge(z, x, c * 2);
    }
    static int w[MAXN];
    for (register int i = 0, x, y, r; i < q; i++) {
        io >> x >> y >> r;
        switch (r) {
            case 0: {
                addEdge(x, y, INF);
                break;
            }
            case 1: {
                addEdge(x, y, INF);
                addEdge(y, x, INF);
                break;
            }
            case 2: {
                w[x] = 1, w[y] = -1;
                break;
            }
        }
    }
    register long long ans = -n * INF - n;
    for (register int i = 1; i <= n; i++) {
        if (w[i] != 1) addEdge(S, i, INF + ex[i]);
        if (w[i] != -1) addEdge(i, T, INF);
        if (w[i] == 1) ans += INF + ex[i];
        if (w[i] == -1) ans += INF;
    }
    io << ans + sap(S, T, T + 1) * W << '\n';
}

inline void solve() {
	register int T;
	io >> T;
	while (T--) {
		solveCase();
	}
}
}

int main() {
    freopen("variable.in", "r", stdin);
    freopen("variable.out", "w", stdout);
	solve();
	return 0;
}