#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	int n;
	scanf("%d",&n);
	return 0;
}
