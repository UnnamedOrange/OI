#include<iostream>
#include<cstdio>
#include<cstring>
#include<stack>
using namespace std;

int n,m,k=0,ans=0,head[1000100]={0},d[1000100]={0},rd[1000100]={0};
int cnt=0,ltcnt=0,dfn[1000100],low[1000100],lt[1000100]={0},lt_size[1000100]={0};
bool f,vis[1000100]={0};
stack<int>a;

inline void read(int &x){
	x=0;
	char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'||c<='9')x=x*10+c-48,c=getchar();
}

struct edge{
	int u,v,next;
}e[2000100];
inline void add(int u,int v){
	e[++k]=(edge){u,v,head[u]};
	head[u]=k;
}

bool dfs_judge(int u){
	if(vis[u])return 1;
	vis[u]=1;
	for(int i=head[u];i;i=e[i].next)
	  if(dfs_judge(e[i].v))
	    return 1;
	return 0;
}

int dfs_tree(int u){
	int ret=d[u];
	for(int i=head[u];i;i=e[i].next)
	  if(!d[e[i].v])
	    d[e[i].v]=d[u]+1,ret=max(ret,dfs_tree(e[i].v));
	return ret;
}

int dfs(int u){
	dfn[u]=low[u]=++cnt;
	a.push(u);
	for(int i=head[u];i;i=e[i].next){
		if(lt[e[i].v])continue;
		if(!dfn[e[i].v])low[u]=min(low[u],dfs(e[i].v));
		else low[u]=min(low[u],dfn[e[i].v]);
	}
	if(dfn[u]==low[u]){
		int v=a.top();ltcnt++;
		while(v!=u){
			v=a.top();a.pop();
			lt[v]=ltcnt;lt_size[ltcnt]++;
		}
	}
	return low[u];
}

int main()
{
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v;
	for(register int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		add(u,v);rd[v]++;
	}
	for(int i=1;i<=n;i++)
	  if(!vis[i])
	  {
	  	f=dfs_judge(i);
	  	if(f)break;
	  }
	if(!f)
	{
		for(int i=1;i<=n;i++)
	      if(!rd[i])
	        d[i]=1,ans=max(ans,dfs_tree(i));
	}
	  
	else{
		for(int i=1;i<=m;i++)add(e[i].v,e[i].u);
		for(int i=1;i<=n;i++)
		  if(!dfn[i])
		    dfs(i);
		for(int i=1;i<=ltcnt;i++)ans=max(ans,lt_size[i]);
	}
	printf("%d",ans);
	return 0;
}
