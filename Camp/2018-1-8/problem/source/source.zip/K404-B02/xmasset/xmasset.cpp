#include <bits/stdc++.h>
using namespace std;
int type, N;

void init()
{
    
}

int encode(int x, int y)
{
	for(int i=0;i<=10;i++)
	{
		if(((1<<i)&x)!=((1<<i)&y))
		{
			//cout<<i<<" ";
			return i+1+(((1<<i)&x)?10:0);
		}
	}
}

bool decode(int q, int h)
{
	int t=0,last;
	if(h>10) t=1,h-=10;
	h--;
	bool ac=((1<<h)&q);
    if(ac==t) return 1;
    return 0;
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
/*
2
5 6
1 11
4 1
2 11
3 12
5 1
2 11
*/
