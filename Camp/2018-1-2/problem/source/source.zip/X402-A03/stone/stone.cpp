#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
#define fr(i,a,b) for(int i=(a),_end_=(b);i<=_end_;i++)
#define fd(i,a,b) for(int i=(a),_end_=(b);i>=_end_;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=(r<<3)+(r<<1)+(c^48);
		c=getchar();
	}
	return r*t;
}
#define mod 1000000007
long long power(long long x,long long y)
{
	long long r=1;
	while(y)
	{
		if(y&1)r=r*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return r;
}
#define N 100010
int n,a,b,m[N];
int main()
{
	freopen("stone.out","w",stdout);
	freopen("stone.in","r",stdin);
	n=read();
	a=read();
	b=read();
	fr(i,1,n)
		m[i]=read();
	if(a==b)
	{
		int num1=0,num2=0;
		fr(i,1,n)
		{
			m[i]/=a;
			if(m[i]&1)
				num1++;
			else
				num2++;
		}
		num2=power(2,num2);
//		printf("%d %d\n",num1,num2);
		long long ans1=0,ans2=0,c=1;
		fr(i,1,num1)
		{
			c=c*(num1-i+1)%mod;
			c=c*power(i,mod-2)%mod;
			if(i&1)
			{
				ans1=(ans1+c)%mod;
				ans2=(ans2+c)%mod;
			}
		}
		ans1=ans1*num2%mod;
		ans2=ans2*num2%mod;
		printf("0 0 %d %d\n",ans1,ans2);
		return 0;
	}
	if(a==1)
	{
		return 0;
	}
	return 0;
}