#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long

using namespace std;

const int P = 998244353;

int n, k;

int Pow(int x, ll k) {
	int rs = 1;
	while (k) {
		if (k & 1) rs = (ll) rs * x % P;
		x = (ll) x * x % P;
		k >>= 1;
	}
	return rs;
}

namespace Subtask1 {
	
	void solve() {
		int ans = Pow(2, (ll) n * (n - 1) / 2);
		int fac = 1;
		for (int i = 1; i <= n; i++) fac = (ll) fac * i % P;
		ans -= fac;
		if (ans < 0) ans += P;
		printf("%d\n", ans);
	}
	
}

namespace Subtask2 {
	
	const int N = 5005;
	
	int f[2][N][N];
	
	inline void Add(int &a, int b) {
		a += b;
		if (a >= P) a -= P;
	}
	
	void solve() {
		f[1][1][0] = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 0; j <= n; j++) {
				for (int op = 0; op < 2; op++) {
					if (!f[op][i][j]) continue;
					Add(f[op][i + 1][j + 1], f[op][i][j]);
					if (op) {
						Add(f[0][i + 1][j], (ll) f[op][i][j] * (i - j) % P);
					} else {
						Add(f[0][i + 1][j], (ll) f[op][i][j] * (i - j - 1) % P);
						Add(f[1][i + 1][j], f[op][i][j]);
					}
					if (j) Add(f[0][i + 1][j - 1], (ll) f[op][i][j] * j % P);
				}
			}
		}
		int dv = f[0][n - 1][0];
//		static int Per[10005];
//		int crs = 0;
//		for (int i = 1; i <= n; i++) Per[i] = i;
//		do {
//			bool flag = true;
//			for (int j = 1; j < n; j++)
//				if (Per[j] == Per[j + 1] + 1) flag = false;
//			if (Per[n] == Per[1] + 1) flag = false;
//			if (Per[2] == n) flag = false;
//			if (flag) crs++;
//			if (flag) for (int j = 1; j <= n; j++)
//				printf("%d%c", Per[j], " \n"[j == n]);
//		} while (next_permutation(Per + 2, Per + n + 1));
//		printf("crs = %d\n", crs);
		{
			memset(f, 0, sizeof(f));
			f[1][1][0] = 1;
			for (int i = 1; i <= n; i++) {
				for (int j = 0; j <= n; j++) {
					for (int op = 0; op < 2; op++) {
						if (!f[op][i][j]) continue;
						Add(f[op][i + 1][j + 1], f[op][i][j]);
						if (op) {
							if (i - j > 1) Add(f[0][i + 1][j], (ll) f[op][i][j] * (i - j - 1) % P);
						} else {
							if (i - j > 2) Add(f[0][i + 1][j], (ll) f[op][i][j] * (i - j - 1 - 1) % P);
							Add(f[1][i + 1][j], f[op][i][j]);
						}
						if (j) Add(f[0][i + 1][j - 1], (ll) f[op][i][j] * j % P);
					}
				}
			}
		}
//		printf("f[0][n - 2][0] = %d\n", f[0][n - 2][0]);
		Add(dv, P - f[0][n - 1][0]);
//		for (int i = 0; i <= n; i++) {
//			printf("i = %d f = %d\n", i, f[n][i]);
//			if (i & 1) Add(dv, P - f[n][i]);
//			else Add(dv, f[n][i]);
//		}
//		printf("dv = %d\n", dv);
		int rs = Pow(2, (ll) n * (n - 1) / 2 - n);
		for (int i = 1; i < n; i++) rs = (ll) rs * i % P;
		rs = (ll) rs * Pow(dv, P - 2) % P;
		printf("%d\n", rs);
	}
	
}

int main() {
	freopen("tournament.in", "r", stdin);
	freopen("tournament.out", "w", stdout);
	scanf("%d %d", &n, &k);
	if (k == 3) Subtask1::solve();
	else if (k == n) Subtask2::solve();
	return 0;
}
