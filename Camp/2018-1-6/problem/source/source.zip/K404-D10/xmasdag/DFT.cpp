#include<bits/stdc++.h>
using namespace std;

#define Rg register
#define Re return
#define In inline
#define St static
#define Op operator
#define Ct continue
#define inc(l, i, r) for(Rg int i=l; i<r; ++i)
#define dec(l, i, r) for(Rg int i=r; i>l; --i)
typedef long long ll;
typedef double db;

const int tot=8, p=998244353;

int ome[1<<10];

In int dP(int a, int b)
{
    Rg int r=1;
    for(; b; a=(ll)a*a%p, b>>=1)
        b&1? r=(ll)r*a%p: 0;
    Re r;
}

In void setOme(int ome1)
{
    inc(ome[0]=1, i, tot)
        ome[i]=(ll)ome[i-1]*ome1%p;
}

In void DFT(int* x)
{
    St int a1[1<<10], a2[1<<10];
    Rg int *f=a1, *g=a2;
    inc(0, i, tot) f[i]=x[i];
    for(Rg int k=1; k<tot; k<<=1, swap(f, g))
        for(Rg int i=0; i<tot>>1; i+=k)
        {
            Rg int *g1=g+(i<<1), *g2=g+(i<<1|k), *f1=f+i, *f2=f+(tot>>1|i);
//            Rg ll ome0=ome[tot/];
            inc(0, j, k)
                g1[j]=((ll)f1[j]+(ll)ome[tot/k/2*j]*f2[j])%p,
                g2[j]=((ll)f1[j]-(ll)ome[tot/k/2*j]*f2[j])%p;
        }
    inc(0, i, tot) x[i]=f[i];
}

int a[8]={1,2,3,1}, b[8]={-1, 1, 2, -3};

int main()
{
    Rg int ome1=dP(3, (p-1)>>3);
    setOme(ome1);
    DFT(a), DFT(b);
    inc(0, i, tot)
        a[i]=(ll)a[i]*b[i]%p;
    setOme(ome[tot-1]);
    DFT(a);
    inc(0, i, tot)
        printf("%d ", a[i]);
    Re 0;
}
