#include <bits/stdc++.h>
#include <windows.h>

namespace {

typedef unsigned int uint;

uint x;

inline uint nextUint() {
    return x ^= x << 13, x ^= x >> 17, x ^= x << 5, x;
}
}

const int MAXN = 2000;
const int MAXM = 1000000;

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);
    char *t = new char;
    x = GetTickCount() * (long long)t ^ time(0);
    delete t;
    register int n = nextUint() % 12 + 1, m = nextUint() % 12 + 1;
    std::cout << n << ' ' << m << '\n';
    for (register int i = 0; i < n; i++) {
        register int l = nextUint() % (10) + 1;
        register int r = nextUint() % (20) + 1;
        if (l > r) std::swap(l, r);
        std::cout << l << ' ' << r << '\n'; 
    }
    for (register int i = 0; i < m; i++) {
        std::cout << 5 + nextUint() % 10 + 1 << '\n';
    }
}
