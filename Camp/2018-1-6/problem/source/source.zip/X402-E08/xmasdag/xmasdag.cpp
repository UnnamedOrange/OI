/*
Author: CNYALI_LK
LANG: C++
PROG: xmasdag.cpp
Mail: cnyalilk@vip.qq.com
*/
#include<bits/stdc++.h>
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define DEBUG printf("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define Debug debug("Passing [%s] in LINE %lld\n",__FUNCTION__,__LINE__)
#define all(x) x.begin(),x.end()
using namespace std;
const double eps=1e-8;
const double pi=acos(-1.0);
typedef long long ll;
typedef pair<ll,ll> pii;
template<class T>ll chkmin(T &a,T b){return a>b?a=b,1:0;}
template<class T>ll chkmax(T &a,T b){return a<b?a=b,1:0;}
template<class T>T sqr(T a){return a*a;}
template<class T>T mmin(T a,T b){return a<b?a:b;}
template<class T>T mmax(T a,T b){return a>b?a:b;}
template<class T>T aabs(T a){return a<0?-a:a;}
#define min mmin
#define max mmax
#define abs aabs
ll read(){
	ll s=0,base=1;
	char c;
	while(!isdigit(c=getchar()))if(c=='-')base=-base;
	while(isdigit(c)){s=s*10+(c^48);c=getchar();}
	return s*base;
}
char WritellBuffer[1024];
const ll p=998244353;
template<class T>void write(T a,char end){
	ll cnt=0,fu=1;
	if(a<0){putchar('-');fu=-1;}
	do{WritellBuffer[++cnt]=fu*(a%10)+'0';a/=10;}while(a);
	while(cnt){putchar(WritellBuffer[cnt]);--cnt;}
	putchar(end);
}
ll to[233333],lst[233333],beg[122222],e;
ll rd[122222];
void add(ll u,ll v){
	to[++e]=v;
	lst[e]=beg[u];
	beg[u]=e;
	++rd[v];
}
ll fpm(ll a,ll b){
	ll c=1;
	while(b){
		if(b&1)c=(c*a)%p;
		a=(a*a)%p;
		b>>=1;
	}
	return c;
}
namespace Cheat1{
	ll f[2123][2123];
	ll cf[2123],n,m,k;
	void Top(ll x){
		for(ll i=beg[x];i;i=lst[i]){
			for(ll j=n;j;--j){
				f[to[i]][j]+=f[x][j-1];
				if(f[to[i]][j]>=p)f[to[i]][j]-=p;
			}
			if(!(--rd[to[i]]))Top(to[i]);
		}
	}
	void main(ll a,ll b,ll c){
		n=a;m=b;k=c;
		for(ll i=1;i<=n;++i){
			cf[i]=fpm(i,k);
		}	
		f[1][0]=1;
		Top(1);
		for(ll i=1;i<=n;++i){
			ll ans=0;
			for(ll j=1;j<=n;++j)ans=(ans+cf[j]*f[i][j])%p;
			printf("%lld\n",ans);
		}
	}
}
namespace Cheat2{
	ll f[101010][505];
	ll n,m,k,c[505][505];
	void Top(ll x){
		for(ll i=k;i;--i)for(ll j=0;j<i;++j)f[x][i]+=f[x][j]*c[i][j];
		for(ll i=beg[x];i;i=lst[i]){
			for(ll j=k;~j;--j){
				f[to[i]][j]+=f[x][j];
				if(f[to[i]][j]>=p)f[to[i]][j]-=p;
			}
			if(!(--rd[to[i]]))Top(to[i]);
		}
	}
	void main(ll a,ll b,ll C){
		n=a;m=b;k=C;
		for(ll i=0;i<=k;++i){
			c[i][0]=c[i][i]=1;
			for(ll j=1;j<i;++j)c[i][j]=(c[i-1][j]+c[i-1][j-1])%p;
		}
		for(ll i=beg[1];i;i=lst[i]){
			++f[to[i]][0];
			if(!--rd[to[i]])Top(to[i]);
		}
		for(ll i=1;i<=n;++i)printf("%lld\n",f[i][k]);
	}
}
int main(){
#ifdef cnyali_lk
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
#endif
	ll n,m,k,u,v;
	n=read();
	m=read();
	k=read();
	for(ll i=1;i<=m;++i){
		u=read();v=read();
		add(u,v);
	}
	if(n<=2000&&m<=5000)Cheat1::main(n,m,k);
	else Cheat2::main(n,m,k);
	return 0;
}

