#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int M=100050;
const int mod=998244353;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int f[55][55][55],n,m,k,a[M],sum=0;

void dfs(int roun,int l,int r)
{
	if(roun==n+1) 
	{
		for(int i=1;i<=m;++i) sum=(sum+qpow(a[i],k))%mod;
		return ;
	}
	for(int l1=l+1;l1<=m;l1++) for(int r1=r+1;r1<=m;r1++)
	{
		for(int i=l1;i<r1;++i) a[i]++;
		dfs(roun+1,l1,r1);
		for(int i=l1;i<r1;++i) a[i]--;
	}
}


void wj()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	n=read(); m=read(); k=read();
	if(n>=m&&m>6) {puts("0");return 0;}
	if(m<=6)
	{
		dfs(1,0,0);
		printf("%d\n",sum);
		return 0;
	}
	else if(k==1)
	{
		//memset(f,-1,sizeof(f));
		for(int l=1;l<=m;++l) for(int r=l;r<=m;++r) f[n+1][l][r]=0;
		int ans=0;
		for(i=n;i;--i) for(int l=0;l<=m;++l) for(int r=l;r<=m-(n-i+1);++r)
		{
			for(int l1=l+1;l1<=m;++l1) for(int r1=max(r+1,l1);r1<=m-(n-i);++r1)
			{
				//if(f[i+1][l1][r1]==-1) continue;
				//if(f[i][l][r]==-1) f[i][l][r]=0;
				f[i][l][r]=((ll)f[i][l][r]+f[i+1][l1][r1]+r1-l1)%mod;
			}
			//if(i==1) ans=(ans+f[i][l][r])%mod;
		}
		printf("%d\n",f[1][0][0]);
		return 0;
	}
	else if(k==mod-1)
	{
		for(int l=1;l<=m;++l) for(int r=l;r<=m;++r) f[n+1][l][r]=0;
		int ans=0;
		for(i=n;i;--i) for(int l=0;l<=m;++l) for(int r=l;r<=m;++r)
		{
			for(int l1=l+1;l1<=m;++l1) for(int r1=r+1;r1<=m;++r1) 
				f[i][l][r]=((ll)f[i][l][r]+f[i+1][l1][r1]+r1-max(r-1,l1))%mod;
			//if(i==1) ans=(ans+f[i][l][r])%mod;
		}
		printf("%d\n",f[1][0][0]);
		return 0;
	}
	else if(n==1)
	{
		int ans=0;
		for(int l=1;l<=m;++l) 
			ans=((ll)ans+(ll)(l+1+m)*(m-l)/2-1ll*(m-l)*l)%mod;
		printf("%d\n",ans);
		return 0;
	}
	return 0;
}
