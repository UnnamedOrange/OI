#include<cstdio>
#include<algorithm>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
int n,m,i,j,k,K,ans;
int str[2][1000];
void read(int &p){
	p=0; char x=getchar();
	while(x<'0' || x>'9') x=getchar();
	while(x>='0'&&x<='9'){p=p*10+x-'0'; x=getchar();}
}
bool check(int s,int k){
	int i,j,r=0;
	bool flag=false;
	rep(i,1,k){
		while((r+1<=n)&&(str[0][r+1]!=(1&(k>>(i-1))))) r++; 
		if(str[0][r+1]!=(1&(k>>(i-1)))) flag=true;
	}
	if(!flag) return false;
	flag=false; r=0;
	rep(i,1,k){
		while((r+1<=n)&&(str[1][r+1]!=(1&(k>>(i-1))))) r++; 
		if(str[1][r+1]!=(1&(k>>(i-1)))) flag=true;
	}
	if(!flag) return false;
	return true;
}
int main(){
	freopen("subsequence.in","r",stdin);
	freopen("subsequence.out","w",stdout);
	read(n); read(m); read(k);
	rep(i,1,n) {
		read(str[0][i]);
		str[0][i]--;
	}
	rep(i,1,m){
		read(str[1][i]);
		str[1][i]--;
	}
	ans=K=max(n,m);
	rep(i,0,(1<<K)-1){
		rep(j,1,ans-1)
		if(check(i,j)){
			ans=ans;
		}
	}
	printf("%d\n",ans);
	return 0;
}
