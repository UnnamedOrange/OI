#include<bits/stdc++.h>
using namespace std;
int m,n,x,y,num=0;
struct Info{
	int nu,ne;
}a[1000010],na[1000010];
struct Onfo{
	int x,y,nx,ny;
}pp[1000010];
bool s[1000010],ss[1000010];
int b[1000010]={0},nb[1000010],dfn[1000010],low[1000010],st[1000010],nst=0,f[1000010],xb=0,qu[1000010],bi[1000010],ansn=0;
void inline read(int &x){
	x=0;
	char ch=getchar();
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
}
void jb(int x,int y){
	a[++num].nu=y;a[num].ne=b[x];b[x]=num;
}
void jnb(int x,int y){
	na[++num].nu=y;na[num].ne=nb[x];nb[x]=num;
}
void tarjan(int x){
	dfn[x]=low[x]=++num;s[x]=ss[x]=false;
	st[++nst]=x;
	for (int y=b[x];y;y=a[y].ne){
		if (s[a[y].nu]){
			tarjan(a[y].nu);
			low[x]=min(low[x],low[a[y].nu]);
		}else{
			low[x]=min(low[x],dfn[a[y].nu]);
		}
	}
	if (dfn[x]==low[x]){
		xb++;
		while (st[nst+1]!=x){
			qu[xb]++;
			bi[st[nst]]=xb;
			nst--;
		}
	}
}
void dfs(int x){
	f[x]=qu[x];
	for (int y=nb[x];y;y=na[y].ne){
		if (f[na[y].nu]==0) dfs(na[y].nu);
		f[x]+=f[na[y].nu];
	}
}
bool comp(const Onfo &a,const Onfo &b){
	if (a.nx!=b.nx)return a.nx<b.nx;
	return a.ny<b.ny;
}
int main(){
	freopen("bomb.in","r",stdin);
	freopen("bomb.out","w",stdout);
	read(n);read(m);
	for (int i=1;i<=m;i++){
		read(pp[i].x);read(pp[i].y);
		jb(pp[i].x,pp[i].y);
	}
	for (int i=1;i<=n;i++){s[i]=1;ss[i]=1;}
	num=0;
	for (int i=1;i<=n;i++)if (s[i]) tarjan(i);
	for (int i=1;i<=m;i++){
		pp[i].nx=bi[pp[i].x];
		pp[i].ny=bi[pp[i].y];
	}
	sort(pp+1,pp+m+1,comp);
	num=0;
	for (int i=1;i<=m;i++){
		if (pp[i].nx!=pp[i].ny&&(pp[i].nx!=pp[i-1].nx||pp[i].ny!=pp[i-1].ny)) jnb(pp[i].nx,pp[i].ny);
	}
	for (int i=1;i<=xb;i++){
		if (f[i]==0) dfs(i);
		ansn=max(ansn,f[i]);
	}
	cout<<ansn<<endl;
}
