#include<bits/stdc++.h>
using namespace std;
template<class T> inline bool chkmax(T& a,T b){ return a<b?a=b,1:0; }
template<class T> inline bool chkmin(T& a,T b){ return a>b?a=b,1:0; }
template<typename T> inline T& read(T& x){
    static char c; bool flag=0;
    while(!isdigit(c=getchar())) if(c=='-') flag=1;
    for(x=c-'0';isdigit(c=getchar());(x*=10)+=c-'0');
    if(flag) x=-x;
    return x;
}
const int maxn=10010;
int n,a[maxn];
double ans;
int main(){
    freopen("drink.in","r",stdin);
    freopen("drink.out","w",stdout);
    read(n);
    for(int i=1;i<=n;i++) read(a[i]);
    for(int i=1;i<=n;i++){
        double sum1=0,sum2=0,base=1;
        for(int j=i;j;j--){
            if(a[j]>a[i]) base/=2;
            sum1+=base;
        }
        base=2;
        for(int j=i;j<=n;j++){
            if(a[j]>=a[i]) base/=2;
            sum2+=base;
        }
        ans+=sum1*sum2*a[i]/n/n;
    }
    printf("%.10lf\n",ans/2);
    return 0;
}
