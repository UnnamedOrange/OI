#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#define P puts("lala")
#define cp cerr<<"lala"<<endl
#define ln putchar('\n')
#define pb push_back
#define fi first
#define se second 
#define mkp make_pair
using namespace std;
inline int read()
{
    char ch=getchar();int g=1,re=0;
    while(ch<'0'||ch>'9') {if(ch=='-')g=-1;ch=getchar();}
    while(ch<='9'&&ch>='0') re=(re<<1)+(re<<3)+(ch^48),ch=getchar();
    return re*g;
}
typedef long long ll;
typedef pair<int,int> pii;

const int N=100050;
const int mod=998244353;
ll qpow(ll a,int n)
{
	ll ans=1;
	for(;n;n>>=1,a=a*a%mod) if(n&1) ans=ans*a%mod;
	return ans;
}
int head[N],cnt=0;
struct node
{
	int to,next;
}e[N<<1];
inline void add(int x,int y)
{
	e[++cnt]=(node){y,head[x]};head[x]=cnt;
	e[++cnt]=(node){x,head[y]};head[y]=cnt;
}

int n,id[11][1<<6],tot=0;
pii is[12*(1<<6)];
char col[N];
int mat[401][401],deg[N];

void gauss()
{
	for(int i=1;i<=tot;++i)
	{
		for(int j=i+1;j<=tot;++j)
		{
			while(mat[j][i])
			{
				int r=mat[i][i]/mat[j][i];
				for(int k=i;k<=tot+1;++k)
				{
					mat[i][k]=(mat[i][k]-1ll*mat[j][k]*r%mod+mod)%mod;
					swap(mat[j][k],mat[i][k]);
				}
			}
		}
	}
	for(int i=tot;i;--i) 
	{
		for(int j=tot;j>i;--j)
			mat[i][tot+1]=(mat[i][tot+1]-1ll*mat[i][j]*mat[j][tot+1]%mod)%mod;
		mat[i][tot+1]=1ll*mat[i][tot+1]*qpow(mat[i][i],mod-2)%mod;
	}
}

void wj()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
}
int main()
{
	wj();
	int i,j,opt,T;
	if(n>6) {puts("0");return 0;}
	n=read(); scanf("%s",col+1);
	for(i=1;i<n;++i)
	{
		int x=read(),y=read();
		add(x,y);
		deg[x]++; deg[y]++;
	}
	int all=1<<n;
	for(i=1;i<=n;++i) for(j=0;j<all;++j) id[i][j]=++tot,is[tot]=pii(i,j);
	for(int u=1;u<=n;++u) for(int s=0;s<all;++s) if(s&(1<<u-1))
	{
		mat[id[u][s]][id[u][s]]=mod-1;
		for(i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			int s1=s|(1<<v-1),val=0;
			if(!(s&(1<<v-1))) val=1;
			if(col[v]=='1') val=1;
			mat[id[u][s]][id[v][s1]]=qpow(deg[u],mod-2);
			mat[id[u][s]][tot+1]=(mat[id[u][s]][tot+1]+qpow(deg[u],mod-2)*val%mod)%mod;
		}
	}
	gauss();
	printf("%d\n",(mat[id[1][1]][tot+1]+1)%mod);
	return 0;
}
