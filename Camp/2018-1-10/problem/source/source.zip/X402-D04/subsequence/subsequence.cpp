#include<bits/stdc++.h>
using namespace std;

typedef pair<int,int> pii;

const int maxn=4010;
const int inf=0x3f3f3f3f;
void read(int& x){
	x=0; char c=getchar();
	while(c<'0'|| c>'9') c=getchar();
	while(c>='0' && c<='9'){ x=x*10+c-'0'; c=getchar(); }
}
int n,m,K,a[maxn],b[maxn];
int dp[maxn][maxn];
int A[maxn][maxn],B[maxn][maxn];

int main(){
	freopen("subsequence.in","r",stdin),freopen("subsequence.out","w",stdout);

	read(n),read(m),read(K);
	for(int i=1;i<=n;i++) read(a[i]);
	for(int i=1;i<=m;i++) read(b[i]);
	for(int i=1;i<=K;i++) A[n][i]=n+1;
	for(int i=n-1;i>=0;i--){
		memcpy(A[i],A[i+1],sizeof(A[i]));
		A[i][a[i+1]]=i+1;
	}
	for(int i=1;i<=K;i++) B[m][i]=m+1;
	for(int i=m-1;i>=0;i--){
		memcpy(B[i],B[i+1],sizeof(B[i]));
		B[i][b[i+1]]=i+1;
	}
	queue<pii>q;
	q.push(pii(0,0));
	dp[0][0]=1;
	while(!q.empty()){
		pii now=q.front();q.pop();
		int x=now.first, y=now.second;
		for(int i=1;i<=K;i++){
			int nx=A[x][i],ny=B[y][i];
			if(!dp[nx][ny]){
				dp[nx][ny]=dp[x][y]+1;
				q.push(pii(nx,ny));
				if(nx==n+1 && ny==m+1){
					printf("%d\n",dp[nx][ny]-1);
					return 0;
				}
			}
		}
	}
	return 0;
}
