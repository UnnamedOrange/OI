#include <cstdio>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
const int N=1e5+5,mod=1e9+7;
int n,a,b,i,j,stone[N],f[N][2];
void score_10()
{
	rep(i,1,n) stone[i]/=a;
	f[0][0]=1;
	rep(i,1,n)
	if (stone[i]%2)
	{
	  f[i][0]=(f[i-1][0]+f[i-1][1])%mod;
	  f[i][1]=(f[i-1][0]+f[i-1][1])%mod;
    }
    else {
      f[i][0]=(f[i-1][0]+f[i-1][0])%mod;
      f[i][1]=(f[i-1][1]+f[i-1][1])%mod;
	}
	printf("%d %d %d %d\n",0,0,f[n][1],f[n][0]);
}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d%d%d",&n,&a,&b);
	rep(i,1,n) scanf("%d",&stone[i]);
	if (a==b) score_10();
	return 0;
}
