#include <cctype>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=(y); ++i)
#define repd(i,x,y) for (int i=x; i>=(y); --i)
#define repe(i,x) for (edge *i=fst[x]; i; i=i->nxt)
#define mid ((l+r)>>1)
#define lson t->lc,l,mid
#define rson t->rc,mid+1,r

using namespace std;

int get()
{
    char c;
    while (!isdigit(c=getchar()));
    int k=c-'0';
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return k;
}

const int N=1e5+10;
struct edge
{
	int v;
	edge *nxt;
} poole[N*2],*tpe=poole,*fst[N];
int n,m,lim,type,ans,clr[N],idx,id[N],size[N],top;
struct data
{
	int x,c;
} stk[N],*lst[N];
struct node
{
	int s,t;
	node *lc,*rc;
} pool[N*20],*tp=pool,*root[N];
struct arr
{
	bool flag[N];
	int stk[N],top,k[N];
	int& operator[](int x)
	{
		return k[x];
	}
	void modify(int x,int c)
	{
		flag[x]=1,stk[++top]=x,k[x]=c;
	}
	void clear()
	{
		for (int *i=stk+1; i<=stk+top; flag[*i++]=0);
		top=0;
	}
} cnt;

void dfs0(int x,int fa=0)
{
	id[x]=++idx,size[x]=1;
	repe(i,x)
		if (i->v!=fa)
			dfs0(i->v,x),size[x]+=size[i->v];
}

bool intree(int x,int t)
{
	return id[t]<=id[x] && id[x]<id[t]+size[t];
}

void insert(int c,node *&t,int l=1,int r=n)
{
	t=tp++,t->s=1;
	if (l<r)
		c<=mid? insert(c,lson):insert(c,rson);
	else
		t->t=1;
}

void merge(node *x,node *&t,int l=1,int r=n)
{
	if (!x || !t)
	{
		t=t? t:x;
		return;
	}
	*tp=*t,t=tp++;
	if (l==r)
	{
		t->t+=x->t,t->s=1;
		return;
	}
	merge(x->lc,lson);
	merge(x->rc,rson);
	t->s=(t->lc? t->lc->s:0)+(t->rc? t->rc->s:0);
}

int query(int ql,int qr,node *t,int l=1,int r=n)
{
	if (!t)
		return 0;
	if (ql<=l && r<=qr)
		return t->s;
	int ret=0;
	if (ql<=mid)
		ret+=query(ql,qr,lson);
	if (mid<qr)
		ret+=query(ql,qr,rson);
	return ret;
}

int query(int p,node *t,int l=1,int r=n)
{
	while (l<r && t)
		p<=mid? (t=t->lc,r=mid):(t=t->rc,l=mid+1);
	return t? t->t:0;
}

void build(int x,int fa=0)
{
	insert(clr[x],root[x]);
	repe(i,x)
		if (i->v!=fa)
			build(i->v,x),merge(root[i->v],root[x]);
}

int main()
{
    freopen("xmastree1.in","r",stdin);
    freopen("xmastree1.out","w",stdout);
    n=get(),m=get(),type=get(),lim=400;
    rep(i,1,n)
    	clr[i]=get();
    rep(i,2,n)
    {
    	int u=get(),v=get();
    	*tpe=(edge){v,fst[u]},fst[u]=tpe++;
    	*tpe=(edge){u,fst[v]},fst[v]=tpe++;
    }
    dfs0(1);
    build(1);
    for (int op,u,l,r,c; m--;)
    	if (op=get(),u=get()^ans*type,op==1)
    	{
    		l=get()^ans*type,r=get()^ans*type;
    		ans=query(l,r,root[u]),cnt.clear();
    		for (data *i=stk+1; i<=stk+top; ++i)
    			if (lst[i->x]==i && intree(i->x,u))
    			{
    				if (l<=i->c && i->c<=r)
    				{
    					if (!cnt.flag[i->c])
    						cnt.modify(i->c,query(i->c,root[u]));
    					ans+=!cnt[i->c]++;
    				}
    				int c0=clr[i->x];
    				if (l<=c0 && c0<=r)
    				{
    					if (!cnt.flag[c0])
    						cnt.modify(c0,query(c0,root[u]));
    					ans-=!--cnt[c0];
    				}
    			}
    		printf("%d\n",ans);
    	}
    	else
    	{
			c=get()^ans*type;
			if (c==clr[u])
				lst[u]=0;
			else
				stk[++top]=(data){u,c},lst[u]=stk+top;
			if (top>lim)
			{
				tp=pool,memset(root,0,sizeof(root));
				rep(i,1,top)
					clr[stk[i].x]=stk[i].c;
				build(1),top=0;
			}
		}
    return 0;
}
