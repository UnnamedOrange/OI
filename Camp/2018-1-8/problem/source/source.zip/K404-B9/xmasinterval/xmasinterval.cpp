#include<bits/stdc++.h>
using namespace std;
long long a[1100],anss,ans;
int n,m,l[1100],r[1100],b[1100];

void dfs(int x,int y)
{
	if (x==n+1)
	  {
	  	if (y==anss) ans++;
	  	return;
	  }
	dfs(x+1,y);
	dfs(x+1,y|a[x]);  
}

int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++) scanf("%d%d",&l[i],&r[i]);
	for (int i=1;i<=m;i++)
	  {
	  	int x;
	  	scanf("%d",&x);
	  	for (int j=1;j<=n;j++) 
		  if (l[j]<=x&&x<=r[j]) 
		    a[j]=a[j]|(1<<i);
	  	anss=anss+(1<<i);
	  }
	dfs(1,0);  
	printf("%d",ans);
	return 0;
}
