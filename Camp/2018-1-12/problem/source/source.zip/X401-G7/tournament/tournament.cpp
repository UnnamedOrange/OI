#include<cstdio>
#define LL long long
#define P 998244353
using namespace std;
int n,k,ans;
int jie[100050];

int mi(int x,LL num)
{
  if(!num) return 1;
  int t=mi(x,num/2);
  if(num&1) t=(LL)t*t%P*x%P;
  else t=(LL)t*t%P;
  return t;
}

int main()
{
   int i;
   freopen("tournament.in","r",stdin);
   freopen("tournament.out","w",stdout);
   scanf("%d%d",&n,&k);
   for(i=1,jie[0]=1;i<=n;i++) jie[i]=(LL)jie[i-1]*i%P;
   if(n<=2) printf("0\n"); 
   else if(k==3)
     {
	   ans=((mi(2,(LL)n*(n-1)/2)-jie[n])%P+P)%P;
	 }
   else
     {
	   ans=(LL)jie[n-1]*mi(2,(LL)n*(n-1)/2-n)%P;
	 }
   printf("%d\n",ans);
}
