#include<bits/stdc++.h>
using namespace std;

template <typename T> void chmax(T &x,const T &y)
{
	if(x<y)x=y;
}
typedef long long ll;
#define rep(i,l,r) for(int i=l;i<=r;++i)
#define per(i,r,l) for(int i=r;i>=l;--i)

const int N=4000+5;
int n,m,k;
int a[N],b[N];
int qa[2][N],*f=qa[0],*f0=qa[1],mx[N];
int pre[N],ap[N],pren[N];
int nex[N][N];

int main()
{
	freopen("subsequence.in","r",stdin);freopen("subsequence.out","w",stdout);
	cin>>n>>m>>k;
	rep(i,1,n)scanf("%d",a+i);
	rep(i,1,m)scanf("%d",b+i);
//	rep(i,1,k)ap[i]=1;	
	rep(i,1,n)
	{
		pre[i]=ap[a[i]];
		ap[a[i]]=i;
	}
	rep(i,1,k)pren[i]=ap[i];
	rep(i,m+1,m+2)
	rep(j,1,k)nex[i][j]=m+1;
	rep(j,1,k)nex[0][j]=-1;
	per(i,m,1)
	{
		rep(j,1,k)nex[i][j]=nex[i+1][j];
		nex[i][b[i]]=i;
	}
	
	rep(i,1,n+1)f[i]=-1;
	for(int len=1;;++len)
	{
		swap(f,f0);
		mx[n+1]=n+1;
		per(i,n,0)
		{
			mx[i]=mx[i+1];
			if(f0[i]>f0[mx[i]])mx[i]=i;
		}
		rep(i,1,n)
		{
			int j=mx[pre[i]];
			if(j>=i)f[i]=-1;
			else f[i]=nex[f0[j]+1][a[i]];	
		}
		
		int j0=f0[n+1];
		f[n+1]=j0;
		rep(c,1,k)chmax(f[n+1],nex[j0+1][c]);
		rep(c,1,k)
		{
			int j=pren[c];
			chmax(f[n+1],nex[f0[mx[j]]+1][c]);
		}

		if(f[n+1]>=m+1){cout<<len;exit(0);}
	}
}
