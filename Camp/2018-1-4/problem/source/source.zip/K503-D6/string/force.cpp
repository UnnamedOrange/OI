#include <cstdio>
#include <cstring>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)

using namespace std;

int n,m,mx,len[6],a[6],b[6],rev[1<<20],ans;

int main()
{
    freopen("string.in","r",stdin);
    freopen("force.out","w",stdout);
    scanf("%d%d",&n,&m);
    rep(i,0,n-1)
    {
        static char s[110];
        scanf("%s",s+1),len[i]=strlen(s+1);
        rep(j,1,len[i])
            a[i]=a[i]<<1|(s[j]>'0');
        repd(j,len[i],1)
            b[i]=b[i]<<1|(s[j]<'1');
    }
    mx=1<<m;
    rep(i,0,mx-1)
    {
        rev[i]=(rev[i>>1]>>1)|(!(i&1))*(mx>>1);
        int x=i<<m|rev[i];
        bool can=1;
        rep(j,0,n-1)
        {
            bool flag=0;
            rep(k,0,m*2-len[j])
                if (((x>>k)&a[j])==a[j] || ((x>>k)&b[j])==b[j])
                {
                    flag=1;
                    break;
                }
            if (!flag)
            {
                can=0;
                break;
            }
        }
        ans+=can;
    }
    printf("%d",ans);
    return 0;
}
