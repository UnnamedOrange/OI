//bao ling le 
#include<iostream>
#include<cstdio>
#include<cstring>

namespace pianfen
{
	typedef long long ll;
	const int N=55,M=1<<18,K=16,MOD=998244353;
	int f[N][K],g[N][K];
	int t[M][K],dt[M][K];

	int begin[N],next[N*2],to[N*2];
	int n,m,e;
	void add(int x,int y,bool k=1)
	{
		to[++e]=y;
		next[e]=begin[x];
		begin[x]=e;
		if(k)add(y,x,0);
	}
	void dfs(int p,int h=0)
	{
		static int son[N];
		int cnt=0;

		for(int i=1;i<=m;i++)f[p][i]=1;

		memset(g[p],0,sizeof(g[p]));
		for(int i=begin[p],q;i;i=next[i])
			if((q=to[i])!=h)
			{
				dfs(q,p),son[++cnt]=q;
				for(int j=1;j<=m;j++)
					f[p][j]=(ll)f[p][j]*(f[q][j+1]+g[q][j+1])%MOD;
			}

		if(cnt>18){printf(">_<\n");return;}

		int S=1<<cnt;
		for(int i=0;i<S;i++)
			for(int j=0;j<=m;j++)
				dt[i][j]=1,t[i][j]=0;
		for(int j=1;j<=m;j++)
			dt[0][j]=t[0][j]=m-j+1;
		for(int k=1;k<S;k++)
		{
			for(int i=1;i<=cnt;i++)
			{
				if(!(k&(1<<(i-1))))continue;
				int q=son[i];
				for(int j=1;j<=m;j++)
				{
					t[k][j]=(t[k][j]
							+(ll)(t[k^(1<<(i-1))][j+1]+dt[k^(1<<(i-1))][j+1]) * (f[q][j]-f[q][j+1]))%MOD;

					if(dt[k][j]==1)
						dt[k][j]=((ll)dt[k^(1<<(i-1))][j+1]*(f[q][j+1]+g[q][j+1]))%MOD;
				}
			}
			for(int j=m;j;j--)
			{
				t[k][j-1]=(t[k][j-1]+t[k][j])%MOD;
				dt[k][j-1]=(dt[k][j-1]+dt[k][j])%MOD;
			}
		}
		if(cnt)
		{
			for(int i=1;i<=m;i++)
			{
//				g[p][i]=t[S-1][i]-t[S-1][i+1];;
				for(int j=1;j<=cnt;j++)
				{
					int q=son[j];
					g[p][i]=(g[p][i]+t[(S-1)^(1<<(j-1))][i+1]*(ll)(f[q][i]-f[q][i+1]))%MOD;
				}
			}
		}

//		printf("%d :\n",p);
//		for(int i=1;i<=m;i++)printf("%d ",f[p][i]);printf("\n");
//		for(int i=1;i<=m;i++)printf("%d ",g[p][i]);printf("\n");
//		printf("--------------\n");

		for(int i=m;i;i--)f[p][i-1]=(f[p][i-1]+f[p][i])%MOD;
		for(int i=m;i;i--)g[p][i-1]=(g[p][i-1]+g[p][i])%MOD;
	}

	void solve()
	{
		scanf("%d%d",&n,&m);
		for(int i=1,u,v;i<n;i++)
			scanf("%d%d",&u,&v),add(u,v);
		int ans=0;
		for(int i=1;i<=n;i++)
		{
			dfs(i);
			ans=(ans+f[i][1])%MOD;
		}
		printf("%d\n",(ans%MOD+MOD)%MOD);
	}
}

int main()
{
	freopen("xmastree3.in","r",stdin);
	freopen("xmastree3.out","w",stdout);
	pianfen::solve();
	return 0;
}
