#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

const int MAXN = 1e6 + 10;
int T;
int n;
long long t[MAXN];
long long m[MAXN];
inline long long read()
{
	long long x = 0, w = 1; char ch = 0;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			w = -1;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * w;
}

void open()
{
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
}

void close()
{
	fclose(stdin);
	fclose(stdout);
}

long long mul(int x)
{
	int num = 0;
	if(x == 1) 
		return 1;
	for(int i = 2; i <= sqrt(x); i++) {
		if(x == 1) {
			break;
		}
		if(x % i ==  0) {
			num++;
			x = x / i;
		}
		if(x % i == 0) {
			return 0;
		}
	}
	if(x != 1) {
		num++;
	}
	if(num % 2 == 1) {
		return -1;
	}
	return 1;
}

long long theta (int x)
{
	int num;
	if(x == 1) 
		return 1;
	long long sum = 0;
	for(int i = 2; i <= sqrt(x); i++) {
		if(x == 1) {
			break;
		}
		if(x % i ==  0) {
			num++;
			x = x / i;
		}
		if(x % i == 0) {
			return 0;
		}
	}
	if(x != 1) {
		sum *= 2;
	}
	if(num % 2 == 1) {
		return -1;
	}
	return 1;
}
int main()
{
	open();
	T = read();
	while(T--) {
		n = read();
		for(int i = 1; i <= n; i++) {
			cout<<mul(i)<<endl;
		}
	}
	close();
	return 0;
}
