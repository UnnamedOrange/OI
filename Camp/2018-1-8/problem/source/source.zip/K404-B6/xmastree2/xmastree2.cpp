#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define N 233
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
int n,ans,w[N],r[N],a[N],fa[11];
bool vis[11];
int cnt,head[N],to[N],nxt[N];
void dfs(int u)
{
	for(int i=head[u],v;i;i=nxt[i])
		if((v=to[i]) != fa[u])
		{
			fa[v]=u;
			dfs(v);
		}
}
int main()
{
	open(xmastree2);
	re(n);
	for(int i=1,u,v;i<n;++i)
	{
		re(u),re(v);
		add_edge(u,v);
		add_edge(v,u);
	}
	for(int i=1;i<=n;++i)
		re(w[i]),re(r[i]);
	int t=1;
	for(int i=1;i<=n;++i)
		t*=i,a[i]=i;
	while(t--)
	{
		if(!r[a[1]])
		{
			next_permutation(a+1,a+n+1);
			continue;
		}
				memset(fa,0,sizeof fa);
				dfs(a[1]);
				memset(vis,0,sizeof vis);
				vis[a[1]]=1;
				fa[a[1]]=a[1];
				int now=0;
				bool ok=1;
				for(int i=1;i<=n;++i)
					if(vis[fa[a[i]]])
					{
						now+=i*w[a[i]];
						vis[a[i]]=1;
					}
					else ok=0;
				
				if(!ok)
				{
					next_permutation(a+1,a+n+1);
					continue;
				}
				ans=max(ans,now);
		next_permutation(a+1,a+n+1);
	}
	printf("%d\n",ans);
}
