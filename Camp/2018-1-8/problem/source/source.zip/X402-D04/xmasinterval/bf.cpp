#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second

typedef pair<int,int> pii;
const int maxn=1000010;
int n,m;
pii a[maxn];
int c[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int ans, vis[maxn];
int main(){
	freopen("xmasinterval.in","r",stdin),freopen("xmasinterval.out","w",stdout);

	read(n), read(m);
	//printf("n = %d\n", n);
	for(int i=1;i<=n;i++) read(a[i].fi), read(a[i].se);
	for(int i=1;i<=m;i++) read(c[i]);
	for(int i=1;i<(1<<n);i++){
		for(int j=1;j<=m;j++) vis[j]=0;
		for(int j=1;j<=n;j++)if(i & (1<<(j-1))){
			for(int k=1;k<=m;k++){ 
				if(c[k]>=a[j].fi && c[k]<=a[j].se) vis[k]=1;
			}
		}
		int flag=1;
		for(int j=1;j<=m;j++) if(!vis[j]){ flag=0; break; }
		if(flag) ans++;
		// printf("ans = %d\n", ans);
	}
	printf("%d\n", ans);
	return 0;
}
