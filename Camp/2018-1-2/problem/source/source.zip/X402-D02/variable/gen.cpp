#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>

const int N=10010;
struct dus
{
	int q[N];
	void init(int n){for(int i=1;i<=n;i++)q[i]=i;}
	int ask(int p){return q[p]==p?p:q[p]=ask(q[p]);}
	bool uni(int u,int v){return ask(u)==ask(v);}
	void link(int u,int v){q[ask(u)]=ask(v);}
}d;

FILE* seed,in;

int rd(){return rand()%1000;}

void work()
{
	int n=15,w=2333,m0=1000,m1=3;
	d.init(n);

	printf("%d %d %d %d\n",n,w,m0,m1);
	while(m0--)
	{
		int x=rand()%n+1,y=rand()%n+1,z=rand()%n+1;
		printf("%d %d %d %d %d %d %d %d %d\n",x,y,z,rd(),rd(),rd(),rd(),rd(),rd());
	}
	bool flag=0;
	while(m1--)
	{
		int x=rand()%n+1,y=rand()%n+1,z=rand()%3;
		if(z==2 && flag)z=rand()%2;
		if(z==2)flag=1;
		while(d.uni(x,y))x=rand()%n+1,y=rand()%n+1;
		printf("%d %d %d\n",x,y,z);
		d.link(x,y);
	}

}

int main()
{
	seed=fopen("seed","r");
	int tmp;fscanf(seed,"%d",&tmp);
	srand(tmp);

	freopen("variable.in","w",stdout);//look at here

	int T=10;
	printf("%d\n",T);
	while(T--)work();

	fclose(stdout);

	fclose(seed);
	seed=fopen("seed","w");
	fprintf(seed,"%d\n",rand());
	return 0;
}
