#include <stdio.h>
#define maxn 1000010
#define modn 1000000007
int f[maxn]={1},ans[maxn]={0},a[maxn][2],n,i,j,max,min;
int main()
{
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	scanf("%d",&n);
	for (i=1;i<=n;i++)
		scanf("%d%d",&a[i][0],&a[i][1]);
	for (i=1;i<=n;i++)
		ans[i]=-1;
	for (i=0;i<n;i++)
	{
		max=0;
		min=n;
		if (ans[i]>=0)
			for (j=i+1;j<=n;j++)
			{
				if (a[j][0]>max) max=a[j][0];
				if (a[j][1]<min) min=a[j][1];
				if ((j-i>=max) && (j-i<=min))
					if (ans[i]+1>ans[j])
					{
						ans[j]=ans[i]+1;
						f[j]=f[i];
					}
					else if (ans[i]+1==ans[j]) f[j]=(f[j]+f[i])%modn;
			}
	}
	if (ans[n]>0) printf("%d %d",ans[n],f[n]);
		else printf("-1");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
