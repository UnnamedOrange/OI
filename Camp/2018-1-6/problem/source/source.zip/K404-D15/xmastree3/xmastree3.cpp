#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define maxn 105
const int mod=998244353;

int n,k,cnt,all,ans,pps,root;
int f[maxn][maxn];
bool vis[maxn];

inline int read(){
	int x=0,f=1; char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) if (ch=='-') f=-1;
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x*f;
}

struct graph{
	int tot,now[maxn],pre[maxn*2],son[maxn*2];
	void clear(){tot=0,memset(now,0,sizeof(int)*(n+1));}
	void add(int a,int b){son[++tot]=b,pre[tot]=now[a],now[a]=tot;}
	void link(int a,int b){add(a,b),add(b,a);}
	void dp(int x,int fa){
		bool flag=0;
		for (int p=now[x];p;p=pre[p])
			if (son[p]!=fa){
				flag=1,dp(son[p],x);
				for (int i=k;i;i--) f[x][i]=(f[x][i+1]+f[son[p]][i+1])%mod;
			}
		if (!flag) for (int i=k;i;i--) f[x][i]=f[x][i+1]+1;
	}
}ot,nt;

struct edge{int x,y; edge(){} edge(int _x,int _y){x=_x,y=_y;}}e[maxn];

void calc_ans(){
	nt.clear();
	for (int i=1;i<=cnt;i++) nt.link(e[i].x,e[i].y);
	for (int i=1;i<=cnt;i++) printf("%d %d\n",e[i].x,e[i].y); puts("");
	for (int i=1;i<=n;i++)
		for (int j=1;j<=k;j++)
			f[i][j]=0;
	nt.dp(pps,0);
	ans=(ans+f[pps][1])%mod;
}

bool 

void solve(int x){
	
	for (int 
}

int main(){
	n=read(),k=read();
	for (int i=1,x,y;i<n;i++) x=read(),y=read(),ot.link(x,y);
	for (int i=1;i<=n;i++) solve(root=i);
	return 0;
}
