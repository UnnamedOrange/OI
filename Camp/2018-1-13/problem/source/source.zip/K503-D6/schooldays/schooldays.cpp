#include <cmath>
#include <cctype>
#include <cstdio>
#include <vector>
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <functional>
#define rep(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)
#define mid ((l+r)>>1)
#define lson l,mid,t<<1
#define rson mid+1,r,t<<1|1

int get()
{
    char c;
    while (!isdigit(c=getchar()) && c!='-');
    int s=c=='-'? -1:1,k=~s? c-'0':0;
    for (; isdigit(c=getchar()); k=k*10+c-'0');
    return s*k;
}

using namespace std;
typedef long long ll;
const int p=1e9+7,N=1e6+10;
int n,c[N],d[N],f[N],mx[N];

void inc(int &x,int y)
{
    (x+=y)<p? 0:x-=p;
}

int main()
{
    freopen("schooldays.in","r",stdin);
    freopen("schooldays.out","w",stdout);
    n=get(),f[0]=1;
    memset(mx,-1,sizeof(mx)),mx[0]=0;
    rep(i,1,n)
    {
        c[i]=get(),d[i]=get();
        int l=i-d[i]+1,r=i-c[i]+1;
        for (int j=i,t; j; --j,l=max(l,i-d[j]+1),r=min(r,i-c[j]+1))
            if (j<l || r<j || !~mx[j-1] || (t=mx[j-1]+1)<mx[i])
                continue;
            else if (t>mx[i])
                mx[i]=t,f[i]=f[j-1];
            else
                inc(f[i],f[j-1]);
        printf("%d\n",mx[i]);
    }
    if (~mx[n])
        printf("%d %d\n",mx[n],f[n]);
    else
        puts("-1");
    return 0;
}
