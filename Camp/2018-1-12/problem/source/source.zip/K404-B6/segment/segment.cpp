#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<complex>
#include<iostream>
#include<algorithm>
#define LL long long
#define add_edge(u,v) nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v
#define open(x) freopen(#x".in","r",stdin),freopen(#x".out","w",stdout)
char ch;bool fs;void re(int& x)
{
	while(ch=getchar(),ch<33);
	if(ch=='-')fs=1,x=0;else fs=0,x=ch-48;
	while(ch=getchar(),ch>33)x=x*10+ch-48;
	if(fs)x=-x;	
}
using namespace std;
int n,m,k,ans;
const int mod=998244353;
namespace task1
{
	void main()
	{
		for(int i=1;i<=m;++i)
			ans=(ans+1ll*(m-i+1)*(m-i+2)/2)%mod;
	}
}
namespace task2
{
	void main()
	{
		
	}
}
namespace task3
{
	void main()
	{
		
	}
}
int main()
{
	open(segment);
	re(n),re(m),re(k);
	--m;
	if(n==1)task1::main();
	else if(n==2)task2::main();
	else if(n==3)task3::main();
	printf("%d\n",ans);
}
