#include<cmath>
#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iomanip>
#include<iostream>
#include<algorithm>
#define N 500010
#define ll long long
#define mod 1000000009
using namespace std;
char xB[1<<15],*xS=xB,*xT=xB;
#define getchar() (xS==xT&&(xT=(xS=xB)+fread(xB,1,1<<15,stdin),xS==xT)?0:*xS++)
inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
struct zgz
{
	int l,r;
}a[N];
inline bool operator< (const zgz &a,const zgz &b)
{return a.r<b.r;}
int n,m;
int x[N];
int sum[N<<2],mul[N<<2];
inline void Add(int&x,int y)
{(x+y>mod)?(x=x+y-mod):(x=x+y);}
inline void pushdown(int x)
{
	int l=x<<1,r=x<<1|1;
	if(mul[x]!=1)
	{
		mul[l]=(ll)mul[l]*mul[x]%mod,sum[l]=(ll)sum[l]*mul[x]%mod;
		mul[r]=(ll)mul[r]*mul[x]%mod,sum[r]=(ll)sum[r]*mul[x]%mod;
		mul[x]=1;
	}
}
inline void update(int x,int l,int r,int pos,int val)
{
	if(l==r)
	{
		Add(sum[x],val);
		return ;
	}
	int mid=(l+r)>>1;
	pushdown(x);
	if(pos<=mid)update(x<<1,l,mid,pos,val);
	else update(x<<1|1,mid+1,r,pos,val);
	Add(sum[x]=sum[x<<1],sum[x<<1|1]);
}
inline void Mul(int x,int l,int r,int L,int R)
{
	if(L<=l&&r<=R)
	{
		Add(sum[x],sum[x]),
		Add(mul[x],mul[x]);
		return;
	}
	int mid=(l+r)>>1;
	pushdown(x);
	if(L<=mid)Mul(x<<1,l,mid,L,R);
	if(R>mid) Mul(x<<1|1,mid+1,r,L,R);
	Add(sum[x]=sum[x<<1],sum[x<<1|1]);
}
inline int ask(int x,int l,int r,int L,int R)
{
	if(L<=l&&r<=R)return sum[x];
	int mid=(l+r)>>1,ret=0;
	pushdown(x);
	if(L<=mid)Add(ret,ask(x<<1,l,mid,L,R));
	if(R>mid) Add(ret,ask(x<<1|1,mid+1,r,L,R));
	return ret;
}
void init()
{
	n=read(),m=read();
	for(int i=1;i<=n;i++)a[i].l=read(),a[i].r=read();
	for(int i=1;i<=m;i++)x[i]=read();
	sort(x+1,x+m+1);
}
int main()
{
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	init();
	for(int i=1;i<=n;i++)
	a[i].l=lower_bound(x+1,x+m+1,a[i].l)-x,a[i].r=upper_bound(x+1,x+m+1,a[i].r)-(x+1);
	sort(a+1,a+n+1);
	for(int i=1;i<=m<<2;i++)mul[i]=1;
	update(1,0,m,0,1);
	for(int i=1;i<=n;i++)
	{
		int tmp=ask(1,0,m,a[i].l-1,a[i].r);
		update(1,0,m,a[i].r,tmp);
		if(a[i].l>1)Mul(1,0,m,0,a[i].l-2);
	}
	printf("%d\n",ask(1,0,m,m,m));
	cerr<<clock()<<endl;
	return 0;
}