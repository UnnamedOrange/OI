#include <cstdio>
#include <cstring>

inline int read(){
	char ch=getchar(); int x=0;
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9')
		x=x*2+ch-'0',ch=getchar();
	return x;
}

char s[10][1000];
int ans;

bool check(int n, int m){
	for (int i=1;i<=m;i++){
		bool mark1=false;
		for (int j=1;j+strlen(s[i]+1)-1<=n*2;j++){
			bool mark2=true;
			for (int k=1;k<=strlen(s[i]+1);k++)
				if (s[0][j+k-1]!=s[i][k]){
					mark2=false; break;
				}
			mark1|=mark2; if (mark2) break;
		}
		if (!mark1) return false;
	}
	return true;
}

void dfs(int x, int n, int m){
	if (x>n){ans+=check(n,m); return;}
	s[0][x]='0'; s[0][n*2-x+1]='1'; dfs(x+1,n,m);
	s[0][x]='1'; s[0][n*2-x+1]='0'; dfs(x+1,n,m);
}

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int n,m; scanf("%d%d",&n,&m);
	if (m<=25){
		for (int i=1;i<=n;i++)
			scanf("%s",&s[i][1]);
		ans=0; dfs(1,m,n);
		printf("%d",ans);
	}
	else printf("0");
	fclose(stdin);
	fclose(stdout);
	return 0;
}

