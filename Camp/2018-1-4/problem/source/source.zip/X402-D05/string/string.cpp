#include<bits/stdc++.h>
using namespace std;
string procstatus(){
	ifstream t("/proc/self/status");
	return string(istreambuf_iterator<char>(t),istreambuf_iterator<char>());
}
const int md=998244353;
void Mod(int &x){
	x=x>=md?x-md:x;
}
struct node{
	int id,l;
	void print(){
		printf("id=%d l=%d\n",id,l);
	}
}trans[12][110][2];
bool operator > (const node &A,const node &B){
	return A.l==B.l?A.id<B.id:A.l>B.l;
}
void chkmax(node &A,const node &B){
	A=A>B?A:B;
}
int val[12][110];
char str[10010];
int len[12];
bool w[12][110];
int dp[510][1<<6][12][110];
node getnex(bool *a,int L,int n){
	node st=(node){0,0};
	bool bo;
	for(int i=0;i<n*2;i++){
		for(int j=1;j<=len[i]&&j<=L;j++){
			bo=1;
			for(int k=j;k>=1;k--){
				if(w[i][k]!=a[L-(j-k)]){
					bo=0;
					break;
				}
			}
			if(bo)
				chkmax(st,(node){i,j});
		}
	}
	return st;
}
int findval(bool *a,int n,int L){
	bool bo;
	int res=0;
	for(int i=0;i<n*2;i++){
		bo=0;
		for(int j=0;j<=L-len[i];j++){
			bo=1;
			for(int k=1;k<=len[i];k++){
				if(w[i][k]!=a[j+k]){
					bo=0;
					break;
				}
			}
			if(bo) break;
		}
		if(bo) res|=1<<(i<n?i:i-n);
	}
	return res;
}
void initval(int n){
	static bool a[10010];
	for(int i=0;i<n*2;i++){
		for(int j=1;j<=len[i];j++){
			a[j]=w[i][j];
			val[i][j]=findval(a,n,j);
		}
	}
}
void init(int n){
	static bool a[10010];
	node st;
	for(int i=0;i<n*2;i++){
		for(int j=0;j<len[i];j++){
			a[j+1]=w[i][j+1]^1;
			st=getnex(a,j+1,n);
			trans[i][j][w[i][j+1]^1]=st;
			trans[i][j][w[i][j+1]]=(node){i,j+1};
			a[j+1]=w[i][j+1];
		}
		a[len[i]+1]=0;
		st=getnex(a,len[i]+1,n);
		trans[i][len[i]][0]=st;

		a[len[i]+1]=1;
		st=getnex(a,len[i]+1,n);
		trans[i][len[i]][1]=st;
	}
	initval(n);
}
void solve(int n,int m){
	dp[0][0][0][0]=1;
	int id,nl;
	for(int i=0;i<m;i++){
		for(int j=0;j<(1<<n);j++){
			for(int k=0;k<n*2;k++){
				for(int l=0;l<=len[k];l++){
					id=trans[k][l][0].id,nl=trans[k][l][0].l;
					Mod(dp[i+1][j|val[id][nl]][id][nl]+=dp[i][j][k][l]);

					id=trans[k][l][1].id,nl=trans[k][l][1].l;
					Mod(dp[i+1][j|val[id][nl]][id][nl]+=dp[i][j][k][l]);
				}
			}
		}
	}

	static bool a[10010];
	int v;
	int ans=0;
	for(int i=0;i<n*2;i++){
		for(int j=0;j<=len[i];j++){
			for(int s=1;s<=j;s++) a[s]=w[i][s];
			for(int s=j+1;s<=j*2;s++) a[s]=a[j*2-s+1]^1;
			v=findval(a,n,j*2);
			for(int s=0;s<(1<<n);s++){
				if((s|v)<(1<<n)-1) continue;
				Mod(ans+=dp[m][s][i][j]);
			}
		}
	}
	printf("%d\n",ans);
}
int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++){
		scanf("%s",str+1);
		len[i]=strlen(str+1);
		for(int j=1;j<=len[i];j++)
			w[i][j]=str[j]-'0';
		for(int j=1;j<=len[i];j++)
			w[i+n][j]=w[i][len[i]-j+1]^1;
		len[i+n]=len[i];
	}
	init(n);
	solve(n,m);
	return 0;
}
