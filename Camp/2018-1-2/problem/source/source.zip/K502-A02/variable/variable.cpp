#include<cstdio>
#include<cstdlib>
#include<iostream>
#define maxn 21
#define inf 0x3f3f3f3f
using namespace std;
struct node{
	int x,y,z,a,b,c,d,e,f;
}g[maxn];
struct rule{
	int x,y,k;
}r[maxn];
int w[maxn];
int n,W,p,q,ans;
void check(){
	int sum=0;
	for (int i=1;i<=q;i++){
		int x=r[i].x,y=r[i].y,k=r[i].k;
		if (k==0){
			if (w[x]>w[y]) return;
		}
		if (k==1){
			if (w[x]!=w[y]) return;
		}
		if (k==2){
			if (w[x]>=w[y]) return;
		}
	}
	for (int i=1;i<=p;i++){
		int x=g[i].x,y=g[i].y,z=g[i].z,a=g[i].a,b=g[i].b,c=g[i].c,d=g[i].d,e=g[i].e,f=g[i].f;
		sum+=a*abs(w[x]-w[y])+b*abs(w[y]-w[z])+c*abs(w[z]-w[x])+a*(w[x]-w[y])+b*(w[y]-w[z])+c*(w[z]-w[x]);
	}
	for (int i=1;i<=n;i++){
		sum+=w[i];
	}
	ans=min(ans,sum);
}
void dfs(int x){
	if (x>n){
		check();
		return;
	}
	w[x]=-W; dfs(x+1);
	w[x]=W; dfs(x+1);
}
int main(){
	freopen("variable.in","r",stdin);
	freopen("variable.out","w",stdout);
	int T;
	cin>>T;
	while (T--){
		scanf("%d%d%d%d",&n,&W,&p,&q);
		for (int i=1;i<=p;i++){
			scanf("%d%d%d%d%d%d%d%d%d",&g[i].x,&g[i].y,&g[i].z,&g[i].a,&g[i].b,&g[i].c,&g[i].d,&g[i].e,&g[i].f);
		}
		for (int i=1;i<=q;i++){
			scanf("%d%d%d",&r[i].x,&r[i].y,&r[i].k);
		}
		ans=inf; dfs(1);
		printf("%d\n",ans);
	}
	return 0;
}
