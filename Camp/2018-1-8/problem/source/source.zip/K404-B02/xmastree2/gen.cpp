#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#include<ctime>
#define ll long long
using namespace std;
int read()
{
	char ch=getchar();int x=0,f=1;
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int main()
{
	freopen("xmastree2.in","w",stdout);
	srand(time(NULL));
	int n=10;
	cout<<n<<endl;
	for(int i=2;i<=n;i++)
	cout<<i<<" "<<rand()%(i-1)+1<<endl;
	for(int i=1;i<=n;i++)
	{
		cout<<rand()%10+1<<" "<<1<<endl;
	}
}
