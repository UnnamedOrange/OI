#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
int read()
{
	char ch=getchar();int f=0,x=1;
	while(ch<'0'||ch>'9'){if(ch=='-') x=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){f=(f<<1)+(f<<3)+ch-'0';ch=getchar();}
	return f*x;
}
const int mod=998244353;
int main()
{
	freopen("segment.in","r",stdin);
	freopen("segment.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	ll ans=0;
	for(int i=1;i<m;i++)
	{
		ans+=1LL*(i)*(m-i);
		ans%=mod;
	}
	cout<<ans;
	return 0;
}

