#include <cstdio>
#include <algorithm>
#define FOR(i, l, r) for(int i = l; i <= r; ++i)

using namespace std;

const int N = 2000010;
struct edge{int to, next;} e[N], E[N];
int du[N], head[N], dfn[N], low[N], st[N], inst[N], h[N], be[N], size[N], dp[N], hd[N];
int n, m, cnt, tt, x, y, ans, top, l, r, cnt1, tot;

int read()
{
	int x = 0; char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9') {x = x * 10 + c - '0'; c = getchar();}
	return x;
}

void ins(int x, int y)
{
	e[++cnt].to = y; e[cnt].next = head[x]; head[x] = cnt;
}

void ins2(int x, int y)
{
	E[++cnt1].to = y; E[cnt1].next = hd[x]; hd[x] = cnt1;
}

void tarjan(int x)
{
	dfn[x] = low[x] = ++tot;
	st[++top] = x; inst[x] = 1;
	for(int i = head[x]; i; i = e[i].next)
	{
		if (!dfn[e[i].to])
		{
			tarjan(e[i].to);
			low[x] = min(low[x], low[e[i].to]);
		}
		else if (inst[e[i].to]) low[x] = min(low[x], dfn[e[i].to]);
	}
	if (dfn[x] == low[x])
	{
		++tt;
		while (st[top] != x)
		{
			be[st[top]] = tt;
			inst[st[top]] = 0;
			++size[tt]; --top;
		}
		be[x] = tt; ++size[tt]; --top; inst[x] = 0;
	}
}

int main()
{
	freopen("bomb.in", "r", stdin);
	freopen("bomb.out", "w", stdout);
	n = read(); m = read();
	FOR(i, 1, m)
	{
		x = read(); y = read();
		ins(x, y);
	}
	FOR(i, 1, n) if (!be[i]) tarjan(i);
	FOR(i, 1, n)
		for(int j = head[i]; j; j = e[j].next)
			if (be[i] != be[e[j].to])
			{
				ins2(be[i], be[e[j].to]);
				++du[be[e[j].to]];
			}
	int l = 0;
	FOR(i, 1, tt) if (!du[i]) h[++r] = i;
	while (l < r)
	{
		x = h[++l]; dp[x] += size[x];
		ans = max(ans, dp[x]);
		for(int i = hd[x]; i; i = E[i].next)
		{
			dp[E[i].to] = max(dp[E[i].to], dp[x]);
			--du[E[i].to];
			if (!du[E[i].to]) h[++r] = E[i].to;
		}
	}
	printf("%d\n", ans);
	return 0;
}
