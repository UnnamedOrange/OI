#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define N 33
#define swp(a,b) t=a,a=b,b=t;
using namespace std;
int T,n,a[N],ans,t;
bool ch()
{
	for(int i=1;i<=n;i++)
	if(a[i]!=i)return 0;
	return 1; 
}
bool check()
{
	for(int i=a[1];i;i--)
	if(a[i]!=a[1]-i+1)return 0;
	for(int i=a[1]+1;i<=n;i++)
	if(a[i]!=i)return 0;
	return 1;
}
int res[N],d[N];
int cut(int x)
{
	int cnt=0;
	for(int i=2;i<n;i++)
	if((a[i]<a[i-1])!=(a[i+1]<a[i]))++cnt; 
	return cnt;
}
bool hh(int x,int lim)
{
	int num=-1;
	for(int i=1;i<=n;i++)
	if(a[i-1]!=a[i]-1&&a[i+1]!=a[i]-1)++num;
	if(x+num>lim+1)return 1;
	return 0;
}
bool dfs(int x,int lim,int lst)
{
	if(hh(x,lim))return 0;
	if(x==lim){
		res[x]=a[1];
		if(check())return 1;
		return 0;
	}
	else{
		int be=n;
		while(be&&a[be]==be)--be;
	//	if((lim+1-x)*2<cut(x))return 0;
		for(int i=be;i;i--)
		if(i!=lst)
		{
			res[x]=i;
			for(int j=1;j<=i/2;j++)swp(a[j],a[i-j+1]);
			if(dfs(x+1,lim,i))return 1;
			for(int j=1;j<=i/2;j++)swp(a[j],a[i-j+1]);
		}
	}
	return 0;
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{	
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		if(ch()){puts("0");continue;}
		ans=n+1;
		for(int i=1;i<=n;i++)
		if(dfs(1,i,0)){
			ans=i;
			break;
		}
		printf("%d\n",ans);	
	}
	return 0;
}