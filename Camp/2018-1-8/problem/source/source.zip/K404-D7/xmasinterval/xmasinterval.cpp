#include <bits/stdc++.h>
using namespace std;
inline void R (int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch == '-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch^'0');
		ch = getchar();
	}
	if(p) v=-v;
}
struct qujian {
	int l, r, ma, mi;
} qu[500005];
int n, m;
int x[500005];
inline bool cmp(const qujian &a, const qujian &b) {
	return a.l < b.l || ((a.l == b.l) && (a.r  < b.r));
}
struct tree {
	int sum;
} tr[4000005];
const int mod = 1000000009;
inline void updata(int x) {
	tr[x].sum = (tr[x << 1].sum + tr[x << 1 | 1].sum) % mod;
}

inline void add(int x, int l, int r, int pos, int v) {
	if(l == r) {
		tr[x].sum = (tr[x].sum + v) % mod;
		return;
	}
	int mid = l + r >> 1;
	if(pos <= mid) add(x << 1, l, mid, pos, v);
	else add(x << 1 | 1, mid + 1, r ,pos, v);
	updata(x);
}
inline int query(int x, int l, int r, int ql, int qr) {
	if(l >= ql && r <= qr) {
		return tr[x].sum;
	}
	int mid = l + r >> 1;
	int ret = 0;
	if(ql <= mid)  ret = (ret + query(x << 1, l, mid, ql, qr )) % mod;
	if(qr > mid) ret = (ret + query(x << 1 | 1, mid + 1, r, ql, qr)) % mod;
	return ret;
}
int mix1, max1, mix2, max2;
int main() {
	freopen("xmasinterval.in", "r", stdin);
	freopen("xmasinterval.out", "w", stdout);
	R(n), R(m);
	for(int i = 1; i <= n; ++i) {
		R(qu[i].l), R(qu[i].r);
	}
	mix1 = 0x3f3f3f3f;
	max1 =  0;
	mix2 = 0x3f3f3f3f;
	max2 =  0;
	for(int i = 1; i <= m; ++i) {
		R(x[i]);
		mix1 = min(mix1, x[i]);
		max1 = max(max1, x[i]);
	}
	sort(qu + 1, qu + n + 1, cmp);
	sort(x + 1, x + m + 1);
	for(int i = 1; i <= n; ++i) {
		qu[i].mi = lower_bound(x + 1, x + m + 1, qu[i].l) - x;
		mix2 = min(mix2, qu[i].l);
		qu[i].ma = upper_bound(x + 1, x + m + 1, qu[i].r) - x - 1;
		max2 = max(max2, qu[i].r);
	}
	int now = 0;
	add(1, 0, m, 0, 1);
//	dp[0][0] = 1;
	int ma, mi;
	for(int i = 1; i <= n; ++i) {
		ma = qu[i].ma, mi = qu[i].mi;
	//printf("he = %d \n", query(1, 0, m, mi - 1, ma));
		add(1, 0, m, ma, query(1, 0, m, mi - 1, ma));
//		printf("sum = %d\n",query(1, 0, m, ma, ma));
	}
	printf("%d\n", query(1, 0, m, m, m));
}
