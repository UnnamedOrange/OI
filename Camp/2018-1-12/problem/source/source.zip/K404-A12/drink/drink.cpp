#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;
int n;
double a[1005],s[1005];
int main(){
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%lf",&a[i]);
	double ans=0;
	for(int i=1;i<=n;i++){
		for(int p=i,tot=0;p<=n;p++){
			s[++tot]=a[p];
			sort(s+1,s+tot+1);
			double now=0;
			for(int j=1;j<=tot;j++){
				now=(now+s[j])*0.5;
			}
			ans+=now;
		}
	}
	printf("%.8lf",ans/n/n);
	return 0;
}
