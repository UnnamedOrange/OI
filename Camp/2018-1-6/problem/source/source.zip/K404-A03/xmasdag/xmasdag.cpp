//Serene
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
#define ll long long
const ll maxn=1e5+10,maxm=2e5+10,mod=998244353;
ll n,m,k,w;

ll aa;char cc;
ll read() {
	aa=0;cc=getchar();
	while(cc<'0'||cc>'9') cc=getchar();
	while(cc>='0'&&cc<='9') aa=aa*10+cc-'0',cc=getchar();
	return aa;
}

int fir[maxn],nxt[maxm],to[maxm],ind[maxn],e=0;
void add(int x,int y) {
	to[++e]=y;nxt[e]=fir[x];fir[x]=e;++ind[y];
}

ll qp(ll x,ll k) {
	ll rs=1;
	while(k) {
		if(k&1) rs=rs*x%mod;
		k>>=1; x=x*x%mod;
	}
	return rs;
}

ll tot[2][maxn],ans[maxn];
int zz[maxn];
void get_tp() {
	tot[0][1]=1;
	int s=1,t=0,x,y,z;
	for(int i=1;i<=n;++i) if(!ind[i]) zz[++t]=i;
	while(s<=t) {
		x=zz[s++];
		if(x!=1) (tot[1][x]+=tot[0][x])%=mod;
		ans[x]=tot[1][x];
		for(y=fir[x];y;y=nxt[y]) {
			z=to[y];
			(tot[0][z]+=tot[0][x])%=mod;
			(tot[1][z]+=tot[1][x])%=mod;
			if(!(--ind[z])) zz[++t]=z;
		}
	}
}

int main() {
	freopen("xmasdag.in","r",stdin);
	freopen("xmasdag.out","w",stdout);
	n=read(); m=read(); k=read();
	int x,y,o=0;
	for(int i=1;i<=m;++i) {
		x=read(); y=read();
		add(x,y);
	}
	if(k!=1) {
		tot[0][1]=1; w=1;
		for(int i=1;i<=n;++i) {
			o^=1; w=qp(i,k);
			memset(tot[o],0,sizeof(tot[o]));
			for(int j=1;j<=n;++j) {
				for(int y=fir[j];y;y=nxt[y]) 
					(tot[o][to[y]]+=tot[o^1][j])%=mod;
			}
			for(int j=1;j<=n;++j) (ans[j]+=tot[o][j]*w%mod)%=mod;
		}
	}
	else get_tp();
	for(int i=1;i<=n;++i) printf("%d\n",ans[i]);
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
6 8 500
1 2
1 3
1 5
2 4
3 2
3 4
3 6
4 6
*/
