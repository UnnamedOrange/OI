#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define ll long long
#define mod 998244353
using namespace std;
int n,k,st,ans,tot;
bool flag;
bool lk[10][10],vis[10];
int power(int x,int y)
{
    int ret=1;
    while(y)
    {
        if(y&1)
            ret=(ll)ret*x%mod;
        x=(ll)x*x%mod;
        y>>=1;
    }
    return ret;
}
void check(int x,int step)
{
    if(flag)
        return;
    if(x==st&&step-1==k)
    {
        flag=true;
        return;
    }
    if(vis[x])
        return;
    vis[x]=true;
    for(int i=1; i<=n; i++)
        if(lk[x][i])
            check(i,step+1);
    vis[x]=false;
}
void dfs(int x,int y)
{
    if(x==n)
    {
        flag=false;
        for(st=1; st<=n&&!flag; st++)
            check(st,1);
        if(flag)
            ans++;
    }
    else if(y==n+1)
        dfs(x+1,x+2);
    else
    {
        lk[x][y]=1,lk[y][x]=0;
        dfs(x,y+1);
        lk[x][y]=0,lk[y][x]=1;
        dfs(x,y+1);
    }
}
int main()
{
    freopen("tournament.in","r",stdin);
    freopen("tournament.out","w",stdout);
    cin>>n>>k;
    if(k==3)
    {
        int fac=1;
        for(int i=2; i<=n; i++)
            fac=(ll)fac*i%mod;
        cout<<(power(2,n*(n-1)/2)-fac+mod)%mod;
        return 0;
    }
    dfs(1,2);
    cout<<ans;
    return 0;
}
