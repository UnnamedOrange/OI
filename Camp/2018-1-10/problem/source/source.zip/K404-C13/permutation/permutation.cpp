#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;

const int N=100005;
const int M=15;
const int mod=998244353;

int n,ans,now;
int p[M],vis[M],tag[M],f[M],dp[N];

void dfs(int step){
	int i,k; bool flag;
	if (step>n){
		flag=1; now=0;
		memset(tag,0,sizeof(tag));
		for (i=1;i<=n;i++){
			memset(f,0,sizeof(f));
			k=i;
			while (k){
				if (tag[k]) break;
				if (f[k]){
					flag&=(now-f[k])&1;
					break;
				}
				f[k]=++now; k=p[k];
			}
			k=i;
			while (k){
				if (tag[k]) break;
				tag[k]=1; k=p[k];
			}
		}
		ans+=flag;
		return;
	}
	if (p[step]){
		dfs(step+1);
		return;
	}
	for (i=1;i<=n;i++)
		if (!vis[i]){
			vis[i]=1; p[step]=i;
			dfs(step+1);
			vis[i]=0; p[step]=0;
		}
}

int main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int i;
	scanf("%d",&n);
	for (i=1;i<=n;i++) scanf("%d",&p[i]);
	if (n<=8){
		for (i=1;i<=n;i++) vis[p[i]]=1;
		dfs(1);
		printf("%d\n",ans);
		return 0;
	}
	dp[2]=1;
	for (i=4;i<=n;i+=2) dp[i]=1ll*dp[i-2]*(i-1)%mod*(i-1)%mod;
	printf("%d\n",dp[n]);
	return 0;
}
