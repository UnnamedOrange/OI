#include <bits/stdc++.h>

int type, N;

void init()
{
    
}

int encode(int x, int y)
{
	for (int i = 0; i <= 9; ++i)
		if ((x & (1 << i)) ^ (y & (1 << i)))
			return  (i * 2) + ((x & (1 << i)) > 0);
}

bool decode(int q, int h)
{
	int x = h & 1;
	h >>= 1;
	if (((q & (1 << h)) > 0) == x) return 1;
	return 0;
}

int main()
{
    int T;
    scanf("%d%d%d", &type, &N, &T);
    init();
    while (T--) {
        int x, y;
        scanf("%d%d", &x, &y);
        if (type == 1)
            printf("%d\n", encode(x, y));
        else
            puts(decode(x, y) ? "yes" : "no");
    }
}
