/*#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <bitset>
#define pb push_back

using namespace std;

const int MaxN = 100010;

struct item {
	int id, dfn, color, pre, maxdfn;
} a[MaxN];

int n, q, t, tree[MaxN], dfs_cnt, la_color[MaxN];

vector<int> e[MaxN];

void dfs(int u, int fa) {
	a[u].dfn = a[u].maxdfn = ++dfs_cnt; tree[dfs_cnt] = u;
	a[u].pre = la_color[a[u].color];
	la_color[a[u].color] = a[u].dfn;
	for(int it = 0, siz = e[u].size(); it < siz; ++it)
		if(e[u][it] != fa) {
			dfs(e[u][it], u);
			a[u].maxdfn = max(a[u].maxdfn, a[e[u][it]].maxdfn);
		}
}

const int MaxB = 340;

struct block {
	int c[MaxN];
	int co[MaxB+10], n, l, r;
	void init() {
		 for(int i = 1; i <= n; ++i
			 c[co[i]]++;
	}
	void modify(int p, int v) {
		c[co[p]]--, co[p] = v, c[co[p]]++;
	}
} b[MaxN/MaxB+10];

int in[MaxN];

void modify(int x, int v) {
	int fg = 0, cv = a[x].color;
	for(int i = 1; i <= b[in[x]].n; ++i) {
		if(b[in[x]].co[i] == cv && i-1+b[in[x]].l > x) {
			fg = 1;
			a[i-1+b[in[x]].l].pre = a[x].pre;
			break;
		}
	}
	if(!fg) {
		for(int i = in[x]+1; i <= in[n]; ++i) {
			if(b[i].c[cv]) {
				for(int j = b[i].l; j <= b[i].r; ++j)
					if(a[j].color == cv) {
						a[j].pre = a[x].pre;
						goto end1;
					}
			}
		}
		end1:;
	}
	a[x].color = v;
	b[in[x]].modify(x-b[in[x]].l+1, v);
	fg = 0;
	for(int i = b[in[x]].n; i > 0; --i)
		if(b[in[x]].co[i] == v && i-1+b[in[x]].l < x) {
			fg = 1;
			a[x].pre = a[i-1+b[in[x]].l].dfn;
			break;
		}
	if(!fg) {
		for(int i = in[x]-1; i > 0; --i) 
			if(b[i].c[v]) {
				for(int j = b[i].r; j >= b[i].l; --j)
					if(a[j].color == v) {
						a[x].pre = j;
						goto end2;
					}
			}
		end2:;
	}
	for(int i = 1; i <= b[in[x]].n; ++i) {
		if(b[in[x]].co[i] == v && i-1+b[in[x]].l > x) {
			fg = 1;
			a[i-1+b[in[x]].l].pre = x;
			break;
		}
	}
	if(!fg) {
		for(int i = in[x]+1; i <= in[n]; ++i) {
			if(b[i].c[v]) {
				for(int j = b[i].l; j <= b[i].r; ++j)
					if(a[j].color == v) {
						a[j].pre = x;
						goto end3;
					}
			}
		}
		end3:;
	}
}

void query(int s) {
for(;x;x=(x-1)&s)
	for(int y=x;y;y=(y-1)&x)
		inc(f[s^x], f[(s^y)]);
}



int main() {
	
	
}*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <bitset>
#define all(x) (x).begin(), (x).end()
#define pb push_back

using namespace std;

const int MaxN = 100010;

struct item {
	int id, dfn, color, pre, nxt, maxdfn;
} a[MaxN];

int n, q, t, tree[MaxN], dfs_cnt, la_color[MaxN];

vector<int> e[MaxN];

void dfs(int u, int fa) {
	a[u].dfn = a[u].maxdfn = ++dfs_cnt; tree[dfs_cnt] = u;
	a[u].pre = la_color[a[u].color];
	la_color[a[u].color] = u;
	a[a[u].pre].nxt = u;
	for(int it = 0, siz = e[u].size(); it < siz; ++it)
		if(e[u][it] != fa) {
			dfs(e[u][it], u);
			a[u].maxdfn = max(a[u].maxdfn, a[e[u][it]].maxdfn);
		}
}

int main() {
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &t);
	for(int i = 1; i <= n; ++i) scanf("%d", &a[i].color);
	for(int i = 1; i < n; ++i) {
		int u, v;
		scanf("%d%d", &u, &v);
		e[u].pb(v); e[v].pb(u);
	}
	dfs(1, 0);
	//for(int i = 1; i <= n; ++i)
	//	cerr << "u : " << i << " pre : " << a[i].pre << endl;
	int lastans = 0;
	while(q--) {
		int op, u, l, r, c;
		scanf("%d", &op);
		if(op == 1) scanf("%d%d%d", &u, &l, &r);
		else scanf("%d%d", &u, &c);
		if(t) u ^= lastans, l ^= lastans, r ^= lastans, c ^= lastans;
		if(op == 1) {
			lastans = 0;
			for(int i = 1; i <= n; ++i)
				if(a[a[i].pre].dfn < a[u].dfn && a[u].dfn <= a[i].dfn && a[i].dfn <= a[u].maxdfn && l <= a[u].color && a[u].color <= r)
					++lastans;
			printf("%d\n", lastans);
		} else {
			memset(la_color, 0, sizeof la_color);
			a[u].color = c;
			dfs_cnt = 0;
			dfs(1, 0);
		}
	}
	
}
