#include<bits/stdc++.h>
#include<tr1/unordered_map>
using namespace std;
using namespace tr1;

typedef long long ll;
const int maxn=6,maxm=100+10,mod=998244353;
int n,m,ans,len[maxn],fail[maxn][maxm],frev[maxn][maxm];
char s[maxn][maxm],rev[maxn][maxm],t[maxm];
ll hshx[maxn],hshy[maxn];

inline int chk(int a){
	return a>=mod?a-mod:a;
}
struct node{
	int x[maxn],y[maxn];
	inline node(){for(int i=0;i<n;++i)x[i]=y[i]=0;}
	inline ll hsh(){
		ll res=0;
		for(int i=0;i<n;++i)
			res+=x[i]*hshx[i]+y[i]*hshy[i];
		return res;
	}
	inline node next(char c){
		node res=*this;
		for(int i=0;i<n;++i){
			if(res.x[i]==-1)continue;
			while(res.x[i]>0&&s[i][res.x[i]]!=c)
				res.x[i]=fail[i][res.x[i]];
			if(s[i][res.x[i]]==c)
				++res.x[i];
			while(res.y[i]>0&&rev[i][res.y[i]]!=c)
				res.y[i]=frev[i][res.y[i]];
			if(rev[i][res.y[i]]==c)
				++res.y[i];
			if(res.x[i]==len[i]||res.y[i]==len[i])
				res.x[i]=res.y[i]=-1;
		}
		return res;
	}
	inline bool finish(){
		for(int i=0;i<n;++i)
			if(x[i]!=-1||y[i]!=-1)
				return false;
		return true;
	}
};

inline ll qpow(ll a,ll n){
	ll res=1;
	while(n){
		if(n&1ll)
			res=res*a%mod;
		a=a*a%mod;
		n>>=1;
	}
	return res;
}
inline void kmp(char*s,int len,int*fail){
	fail[0]=0;
	for(int i=1;i<len;++i){
		int pos=fail[i];
		while(pos>0&&s[pos]!=s[i])
			pos=fail[pos];
		if(s[pos]==s[i])
			fail[i+1]=pos+1;
	}
}
namespace trie{
	const int size=maxn*maxm*maxm;
	int cnt=1,ch[size][2],tag[size];
	inline void insert(int id){
		int pos=1;
		for(int i=0;t[i];++i){
			if(!ch[pos][t[i]-'0'])
				ch[pos][t[i]-'0']=++cnt;
			pos=ch[pos][t[i]-'0'];
		}
		tag[pos]|=1<<id;
	}
	unordered_map<ll,int> mp;
	inline void init(){
		ll res=0;
		for(int i=0;i<n;++i)
			res-=hshx[i]+hshy[i];
		for(int i=0;i<m;++i)
			mp[res*m+i]=qpow(2,i);
	}
	int dfss(int len,node now){
		if(mp.count(now.hsh()*m+len))
			return mp[now.hsh()*m+len];
		if(!len)
			return 0;
		return mp[now.hsh()*m+len]=chk(dfss(len-1,now.next('0'))+dfss(len-1,now.next('1')));
	}
	int dfs(int pos,int len,node now){
		if(tag[pos])
			for(int i=0;i<n;++i)
				if((tag[pos]>>i)&1)
					now.x[i]=now.y[i]=-1;
		if(now.finish())
			return qpow(2,len);
		if(!len)
			return 0;
		int tmp;
		if(ch[pos][0])
			tmp=dfs(ch[pos][0],len-1,now.next('0'));
		else
			tmp=dfss(len-1,now.next('0'));
		if(ch[pos][1])
			return chk(tmp+dfs(ch[pos][1],len-1,now.next('1')));
		else
			return chk(tmp+dfss(len-1,now.next('1')));
	}
}

int main(){
	freopen("string.in","r",stdin);
	freopen("string.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;++i)
		hshx[i]=rand()/2+1,hshy[i]=rand()/2+1;
	for(int i=0;i<n;++i){
		scanf("%s",s[i]);
		len[i]=strlen(s[i]);
		for(int j=1;j<len[i];++j){
			if(j>m||len[i]-j>m)continue;
			int x=j-1,y=j;
			while(x>=0&&y<len[i])
				if(s[i][x]==s[i][y])
					goto wrong;
				else
					--x,++y;
			if(x<0)
				strcpy(t,s[i]+j);
			else{
				for(int k=0;k<j;++k)
					t[k]=s[i][j-1-k]^1;
				t[j]=0;
			}
			trie::insert(i);
			wrong:;
		}
		strcpy(rev[i],s[i]);
		reverse(rev[i],rev[i]+len[i]);
		for(int j=0;j<len[i];++j)
			rev[i][j]^=1;
		kmp(s[i],len[i],fail[i]);
		kmp(rev[i],len[i],frev[i]);
	}
	trie::init();
	ans=trie::dfs(1,m,node());
	printf("%d\n",ans);
	return 0;
}
