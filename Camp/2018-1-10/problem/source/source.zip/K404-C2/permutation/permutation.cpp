#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdio>
#define rep(i,x,y) for(int i=x; i<=y; ++i)

using namespace std;
typedef long long LL;
const int N=100005,mod=998244353;
bool vis[N],met[N];
int n,a[N],ans;

int getint()
{
	char ch;
	while(!isdigit(ch=getchar()));
	int x=ch-48;
	while(isdigit(ch=getchar())) x=x*10+ch-48;
	return x;
}

bool query()
{
	rep(i,1,n) met[i]=0;
	rep(i,1,n)
	{
		if(met[i]) continue;
		int len=0,x;
		for(x=i; a[x]!=i; x=a[x],++len)
			met[x]=1;
		if(!(len&1)) return 0;
	}
	return 1;
}

void dfs(int x)
{
	if(x>n)
	{
		if(query()) ++ans;
		return;
	}
	if(a[x]) dfs(x+1);
	else
	{
		rep(i,1,n)
			if(!vis[i] && i!=x)
				a[x]=i,vis[i]=1,dfs(x+1),vis[i]=0,a[x]=0;
	}
}

void task1()
{
	rep(i,1,n) vis[a[i]]=1;
	dfs(1);
	printf("%d\n",ans);
}

void task2()
{
	if(n&1) puts("0");
	else
	{
		ans=1,n>>=1;
		rep(i,1,n)
			ans=(LL)ans*(i*2-1)%mod*(i*2-1)%mod;
		printf("%d\n",ans);
	}
}

int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	n=getint();
	rep(i,1,n) a[i]=getint();
	if(n<=8) task1();
	else task2();
	return 0;
}
