#include<bits/stdc++.h>

#define ll long long
#define mm(a, b) memset(a, b, sizeof(a))
#define inf 999999999

#define For(i, a, b) for(int i = (a);i <= (b); ++i)
#define rep(i, a, b) for(int i = (a);i >= (b); --i)

#define gnn cerr << "GNN睡着了" << endl;

using namespace std;

int read(){
	int sum = 0, fg = 1;
	char c = getchar();

	while(c < '0' || c > '9'){if(c == '-')fg = -1;c = getchar();}
	while(c >='0' && c <='9')sum = (sum << 1) + (sum << 3) + c-'0', c= getchar();

	return sum * fg;
}

const int maxn = 100010;

const int maxm = 5010;

int n, q, type, color[maxn], Begin[maxn], to[maxn], e, Next[maxn], Size[maxn], dfn[maxn], dfs_clock, pos[maxn];

void add(int x,int y){
	to[++e] = y;
	Next[e] = Begin[x];
	Begin[x] = e;
}

void Get(){
	n = read(), q = read(), type = read();
	For(i, 1, n) color[i] = read();
	For(i, 1, n-1){
		int x = read(), y = read();
		add(x, y), add(y, x);
	}
}

void dfs(int h,int father){
	Size[h] = 1;
	dfn[++ dfs_clock] = h;
	pos[h] = dfs_clock;

	for(int i = Begin[h];i ;i = Next[i]){
		int v = to[i];
		if(v == father) continue;

		dfs(v, h);
		Size[h] += Size[v];
	}
}

void pre_work(){
	dfs(1, -1);
}

int lsans = 0, vis[maxn];

void solve_bf(){
	For(i, 1, q){
		int ype = read();
		if(ype == 1){
			int u = read(), l = read(), r = read();
			if(type) u ^= lsans, l ^= lsans, r ^= lsans;

			For(j, pos[u], pos[u] + Size[u] - 1){
				int nowc = color[dfn[j]];
				if(nowc >= l && nowc <= r) vis[nowc] = 1;
			}

			int Ans = 0;
			For(j, l, r) if(vis[j]){ ++ Ans; vis[j] = 0;}
			printf("%d\n", (lsans = Ans));
		}
		else{
			int u = read(), c = read();
			if(type) u ^= lsans, c ^= lsans;
			color[u] = c;
		}
	}
}

int main(){
	
	freopen("xmastree1.in", "r", stdin);
	freopen("xmastree1.out", "w", stdout);

	Get();
	pre_work();
	solve_bf();

	return 0;
}
