#include <cstdio>
#include <cstdlib>
#include <process.h>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

int rand(int x)
{
	return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
	return rand(r-l+1)+l;
}

void rands(int n,int mx=2)
{
	rep(i,1,n)
		putchar('0'+rand(mx));
	puts("");
}

int main()
{
	srand(_getpid()^(unsigned long long)new char);
	freopen("xmasdag.in","w",stdout);
//	int n=rand(1,6),m=rand(n,10),k=rand(0,2);
	int n=100000,m=200000,k=30;
	printf("%d %d %d\n",n,m,k);
	rep(i,1,m)
	{
		int u=rand(1,n-1),v=rand(u+1,n);
		printf("%d %d\n",u,v);
	}
	return 0;
}
