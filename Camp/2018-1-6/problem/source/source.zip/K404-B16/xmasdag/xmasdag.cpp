#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)
#define dep(i, s, t) for(i = s; i >= t; --i)

using namespace std;

typedef long long LL;
const int N = 100010, M = 200010, K = 510;
const int P = 998244353;
int n, m, k;
struct edge{int ed, ne;} e[M<<1]; int he[N], in[N], en;
LL fac[K], inv[K], f[N][K];
queue<int> q;

LL g[2010][2010];

void ins(int a, int b) {
	e[++en].ed = b; e[en].ne = he[a]; he[a] = en; ++in[b];
}

LL lp(LL a, LL b) {
	LL c = 1;
	for(; b; b >>= 1, a = a * a % P)
		if(b & 1) c = c * a % P;
	return c;
}

void solvek() {
	int i, j, l, u, v;
	fac[0] = 1; rep(i, 1, k) fac[i] = fac[i-1] * i % P;
	inv[k] = lp(fac[k], P-2); dep(i, k, 1) inv[i-1] = inv[i] * i % P;
	
	f[1][0] = 1;
	q.push(1);
	for(; !q.empty(); q.pop()) {
		u = q.front();
		for(i = he[u]; i; i = e[i].ne) {
			v = e[i].ed;
			rep(j, 0, k)
				rep(l, 0, j) 
					f[v][j] = (f[v][j] + fac[j] * inv[l] % P * inv[j-l] % P * f[u][l] % P) % P;
			if(!--in[v]) q.push(v);
		}
	}
	rep(i, 1, n) printf("%lld\n", f[i][k]);
}

void solves() {
	int i, j, l, u, v; LL ans;
	g[1][0] = 1;
	q.push(1);
	for(; !q.empty(); q.pop()) {
		u = q.front();
		for(i = he[u]; i; i = e[i].ne) {
			v = e[i].ed;
			rep(j, 1, n) g[v][j] = (g[v][j] + g[u][j-1]) % P;
			if(!--in[v]) q.push(v);
		}
	}
	rep(i, 1, n) {
		ans = 0;
		rep(j, 1, n) ans = (ans + lp(j, k) * g[i][j] % P) % P;
		printf("%lld\n", ans);
	}
}

int main() {
	freopen("xmasdag.in", "r", stdin); freopen("xmasdag.out", "w", stdout);
	int i, x, y;
	scanf("%d %d %d", &n, &m, &k);
	rep(i, 1, m) {
		scanf("%d %d", &x, &y);
		ins(x, y);
	}
	if(n <= 2000) solves(); else
		solvek();
	return 0;
}
