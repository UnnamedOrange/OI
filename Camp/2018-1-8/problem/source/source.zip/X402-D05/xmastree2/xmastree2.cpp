#include<bits/stdc++.h>
using namespace std;
const long long INF=1e16;
const int maxn=100100;
int beg[maxn],tto[maxn<<1],nex[maxn<<1],e;
void putin(int s,int t){
	tto[++e]=t;
	nex[e]=beg[s];
	beg[s]=e;
}
int w[maxn],r[maxn];
int a[1010][1010],f[1010][1010];
long long dp[1010][1010];
int siz[maxn];
int stk[maxn];
void dfs(int u,int fa){
	siz[u]=0;
	long long v;
	int x,y;
	for(int i=beg[u];i;i=nex[i]){
		if(tto[i]==fa) continue;
		dfs(tto[i],u);
		for(int j=0;j<=siz[u];j++)
			for(int k=0;k<=siz[tto[i]];k++)
				dp[j][k]=-INF;
		dp[0][0]=0;
		for(int j=0;j<=siz[u];j++)
			for(int k=0;k<=siz[tto[i]];k++){
				if(j<siz[u]){
					v=dp[j][k]+w[a[u][j+1]]*(long long)(j+k+1);
					if(v>dp[j+1][k]){
						f[j+1][k]=0;
						dp[j+1][k]=v;
					}
				}
				if(k<siz[tto[i]]){
					v=dp[j][k]+w[a[tto[i]][k+1]]*(long long)(j+k+1);
					if(v>dp[j][k+1]){
						f[j][k+1]=1;
						dp[j][k+1]=v;
					}
				}
			}
		int top=0;
		x=siz[u],y=siz[tto[i]];
		for(int j=1;j<=siz[u];j++)
			stk[++top]=a[u][j];
		siz[u]=0;
		while(x||y){
			if(f[x][y]==0)
				a[u][++siz[u]]=stk[x],x--;
			else
				a[u][++siz[u]]=a[tto[i]][y],y--;
		}
		for(int j=1;j*2<=siz[u];j++)
			swap(a[u][j],a[u][siz[u]-j+1]);
	}
	long long res=0;
	for(int i=1;i<=siz[u];i++)
		res=res+w[a[u][i]]*(long long)i;
	for(int i=siz[u];i>=1;i--)
		a[u][i+1]=a[u][i];
	a[u][1]=u;
	siz[u]++;
}
long long solve(int rt){
	dfs(rt,-1);
	long long res=0;
	for(int i=1;i<=siz[rt];i++)
		res=res+w[a[rt][i]]*(long long)i;
	return res;
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	int n;
	scanf("%d",&n);
	int s,t;
	for(int i=1;i<n;i++){
		scanf("%d%d",&s,&t);
		putin(s,t);
		putin(t,s);
	}
	for(int i=1;i<=n;i++)
		scanf("%d%d",&w[i],&r[i]);
	long long ans=0,v;
	for(int i=1;i<=n;i++){
		if(!r[i]) continue;
		v=solve(i);
		if(v>ans) ans=v;
	}
	printf("%lld\n",ans);
	return 0;
}
