#include <cstdio>
#include <cstdlib>
#include <process.h>
#include <algorithm>
#define rep(i,x,y) for (int i=x; i<=y; ++i)

using namespace std;

int rand(int x)
{
    return (rand()<<15|rand())%x;
}

int rand(int l,int r)
{
    return rand(r-l+1)+l;
}

void rands(int n,int mx=2)
{
    rep(i,1,n)
        putchar('a'+rand(mx));
    puts("");
}

int main()
{
    srand(_getpid()^(unsigned long long)new char);
    freopen("xmastree2.in","w",stdout);
    int n=rand(1,5),mx=rand(1,100);
    printf("%d\n",n);
    rep(i,2,n)
        printf("%d %d\n",rand(1,i-1),i);
    rep(i,1,n)
        printf("%d %d\n",rand(mx),rand(2));
    return 0;
}
