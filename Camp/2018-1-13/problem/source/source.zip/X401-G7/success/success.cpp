#include<cstdio>
#include<cstring>
#include<algorithm>
#define LL long long
#define P 1000000007
using namespace std;
LL s,t,n,m,ans;
LL b[2][1000600];
LL C[2000600];

LL mi(LL x,LL num)
{
  if(!num) return 1;
  LL t=mi(x,num/2);
  if(num&1) t=t*t%P*x%P;
  else t=t*t%P;
  return t;
}

void getC()
{
  LL i,t1=1,t2=1,x=s+m-n,y=m-n;
  for(i=x;i>=x-y+1;i--) t1=t1*i%P;
  for(i=1;i<=y;i++) t2=t2*i%P;
  C[x]=t1*mi(t2,P-2)%P;
  t1=x,t2=s;
  for(i=s;i>=1;i--)
    {
	  C[t1-1]=C[t1]*t2%P*mi(t1,P-2)%P;
	  t1--,t2--;
	}
}

int main()
{
  LL now,last,i,j,k;
  freopen("success.in","r",stdin);
  freopen("success.out","w",stdout);
  scanf("%lld%lld%lld%lld",&s,&t,&n,&m),s-=m,t--;
  if(s<0 || t<0) printf("0\n");
  b[0][0]=1,now=1,last=0;
  for(i=1;i<=n;i++)
    {
	  for(j=t;j>=0;j--)
	    for(k=j;k<=s;k++) 
		 {
		  //if(!b[last][k-j]) break;
		  b[now][k]=(b[now][k]+b[last][k-j])%P;
		 }
	  memset(b[last],0,sizeof(b[last]));
	  swap(now,last);
	}
  getC();
  for(i=0;i<=s;i++)
    ans+=b[last][s-i]*C[i+m-n]%P,ans%=P;
  printf("%lld\n",ans);
}
