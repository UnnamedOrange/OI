#include<cstdio>
#include<algorithm>
#include<cstring>
#define rep(i, s, t) for(i = s; i <= t; ++i)
#define isd(a) ((a) >= '0' && (a) <= '9')

using namespace std;

typedef long long LL;
const int MAXS = 128 * 1024 * 1024;
const int N = 500010;
const int P = 1e9+7;
int n, m;
struct D{int l, r;} a[N]; int b[N];
int fir[N], las[N];
LL tr[N<<2], tag[N<<2];
LL f[N];
char buf[MAXS], *p = buf;

inline int re() {
	int x = 0; char c = *p++;
	for(; !isd(c); c = *p++);
	for(; isd(c); c = *p++) x = (x<<3) + (x<<1) + c - '0';
	return x;
}

bool cmp(D a, D b) {return a.l == b.l? a.r < b.r: a.l < b.l;}

#define lc (u<<1)
#define rc (u<<1|1)

void down(int u) {
	if(tag[u]) {
		if(!tag[lc]) tag[lc] = tag[u]; else tag[lc] = tag[lc] * tag[u] % P;
		if(!tag[rc]) tag[rc] = tag[u]; else tag[rc] = tag[rc] * tag[u] % P;
		tr[lc] = tr[lc] * tag[u] % P;
		tr[rc] = tr[rc] * tag[u] % P;
		tag[u] = 0;
	}
}

void ins(int u, int L, int R, int p, LL v) {
	if(L == R) {tr[u] = (tr[u] + v) % P; return;}
	else {
		down(u);
		int mid = L + R >> 1;
		if(p <= mid) ins(lc, L, mid, p, v);
		else ins(rc, mid+1, R, p, v);
		tr[u] = (tr[lc] + tr[rc]) % P;
	}
}

void dou(int u, int L, int R, int l, int r) {
	if(l > r) return;
	if(l <= L && r >= R) {
		if(!tag[u]) tag[u] = 2; else tag[u] = tag[u] * 2ll % P;
		tr[u] = tr[u] * 2ll % P;
		return;
	} else {
		down(u);
		int mid = L + R >> 1;
		if(l <= mid) dou(lc, L, mid, l, r);
		if(r > mid) dou(rc, mid+1, R, l, r);
		tr[u] = (tr[lc] + tr[rc]) % P;
	}
}

LL ask(int u, int L, int R, int l, int r) {
	if(l > r) return 0;
	if(l <= L && r >= R) return tr[u];
	else {
		down(u);
		int mid = L + R >> 1; LL t = 0;
		if(l <= mid) t = (t + ask(lc, L, mid, l, r)) % P;
		if(r > mid) t = (t + ask(rc, mid+1, R, l, r)) %P;
		return t;
	}
}

int main() {
	freopen("xmasinterval.in", "r", stdin); freopen("xmasinterval.out", "w", stdout);
	int i, l, r, t, mid;
	fread(buf, 1, MAXS, stdin);
	n = re(); m = re();
	rep(i, 1, n) a[i].l = re(), a[i].r = re();
	sort(a + 1, a + n + 1, cmp);
	rep(i, 1, m) b[i] = re();
	sort(b + 1, b + m + 1);
	rep(i, 1, n) {
		l = 1; r = m; t = m+1;
		while(l <= r) {
			mid = l + r >> 1;
			if(a[i].l <= b[mid]) r = (t = mid) - 1; else l = mid + 1;
		}
		fir[i] = t;
		
		l = 1; r = m; t = 0;
		while(l <= r) {
			mid = l + r >> 1;
			if(a[i].r >= b[mid]) l = (t = mid) + 1; else r = mid - 1;
		}
		las[i] = t;
	}
	//rep(i, 1, n) printf("%d %d\n", fir[i], las[i]);
	ins(1, 0, m, 0, 1);
	rep(i, 1, n) {
		dou(1, 0, m, las[i]+1, m);
		f[i] = ask(1, 0, m, fir[i]-1, las[i]);
		//printf("%lld\n", f[i]);
		ins(1, 0, m, las[i], f[i]);
	}
	printf("%lld\n", ask(1, 0, m, m, m));
	return 0;
}
