/*+lmake
 * DEFINE += MDEBUG
 */
#include <bits/stdc++.h>
using namespace std;
#define MODP 998244353
#define MOD(x) ((x)%MODP)
typedef long long LL;
#define MAXN 100000
bool a[MAXN+10];
struct Edge
{
	int to,next;
}e[2*MAXN+10];
int head[MAXN+10];
void addEdge(int a,int b)
{
	static int c=0;
	e[++c]=(Edge){b,head[a]};
	head[a]=c;
	e[++c]=(Edge){a,head[b]};
	head[b]=c;
}
int du[MAXN+10];
LL qpow(LL x,LL n)
{
    if (n==1) return x;
    LL t=qpow(x,n/2);
    t=MOD(t*t);
    if (n%2!=0) t=MOD(t*x);
    return t;
}
namespace black_list
{
int dfs(int now,int fa)
{
	for(int i=head[now]; i!=0; i=e[i].next)
	{
		if (e[i].to!=fa) return dfs(e[i].to,now)+1;
	}
	return 1;
}
LL main()
{
	int a,b;
	a=dfs(e[head[1]].to,1);
	b=dfs(e[e[head[1]].next].to,1);
	cerr<<a<<' '<<b<<endl;
	LL n=a,m=b;
	LL ans=0;
	ans=n+m;
	LL ans2=MOD(2*MOD(n*m)-MOD(m*(n-1))-MOD(n*(m-1))+MODP*2);
	cerr<<ans<<' '<<ans2<<endl;
	ans=MOD(ans*qpow(ans2,MODP-2));
	return ans;
}
}
int main()
{
	freopen("sad.in","r",stdin);
#ifndef MDEBUG
	freopen("sad.out","w",stdout);
#endif
	bool flag_list=true,flag_black=true,flag_white=true;
	int n;
	scanf("%d",&n);
	for(int i=1; i<=n; ++i)
	{
		char t;
		do t=getchar(); while(t!='0' && t!='1');
		a[i]=t=='0';
		if (a[i]) flag_black=false;
		else flag_white=false;
	}
	for(int i=1; i<n; ++i)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		addEdge(a,b);
		++du[a];
		++du[b];
	}
	int cnt=0;
	for(int i=1; i<=n; ++i)
	{
		if (du[i]>2) 
		{
			flag_list=false;
			break;
		}
		if (du[i]==1) ++cnt;
	}
	LL ans=0;
	ans=black_list::main();
	cout<<ans<<endl;
    return 0;
}
