#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
bool fl[11]={0};
int step[362880];
struct node{
	int a[11];
}A;
int cantor(node A,int n){
	int ans=0;
	memset(fl,0,sizeof fl);
	int multi=1;
	fl[A.a[1]]=1;
	for(int i=2;i<=n;++i){
		multi*=(i-1);
		int tp=0;
		fl[A.a[i]]=1;
		for(int j=1;j<A.a[i];++j){
			if(fl[j])++tp;
		}
		ans+=tp*multi;
	}
	return ans;
}
node q[362890]={0};
int h=0,t=0;
node rev(node x,int l,int r){
	for(int i=l;i<(l+r+1)/2;++i){
		swap(x.a[i],x.a[l+r-i]);
	}
	return x;
}
int brute_solve(int n){
	if(h==0&&t==0){
		for(int i=1;i<=n;++i)A.a[i]=i;
		q[t++]=A;
		step[cantor(A,n)]=1;
	}
	for(int i=1;i<=n;++i){
		scanf("%d",&A.a[i]);
	}
	int fin=cantor(A,n);
	if(step[fin]){
		return step[fin];
	}
	bool ans_fl=0;
	node tp;
	int temp;
	while(h!=t){
		tp=q[h];
		temp=cantor(tp,n);
		if(temp==fin)return step[temp];
		else{
			temp=step[temp];
			++h;
		}
		for(int i=2;i<=n;++i){
			q[t]=rev(tp,1,i);
			int c=cantor(q[t],n);
			if(!step[c]){
				step[c]=temp+1;
				t++;
			}
		}
	}
}
int s[30]={0};
void rotate(int s[],int r){
	for(int i=1;i<(r+2)/2;++i){
		swap(s[i],s[1+r-i]);
	}
}
int get_(int x,int n){
	for(int i=1;i<=n;++i){
		if(s[i]==x){
			return i;
		}
	}
}
int greedy(int n){
	for(int i=1;i<=n;++i){
		scanf("%d",&s[i]);
	}
	int ans=0;
	for(int i=n;i>=1;--i){
		if(s[i]!=i){
			int tp=get_(i,n);
			if(tp!=1){
				rotate(s,tp);
				++ans;
			}
			rotate(s,i);
			++ans;
		}
	}
	return ans;
}
				
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int TI;
	scanf("%d",&TI);
	while(TI--){
		int n;
		scanf("%d",&n);
		if(n<=9)printf("%d\n",brute_solve(n)-1);
		else{
			cout<<greedy(n)<<endl;
		}
	}
	
}
