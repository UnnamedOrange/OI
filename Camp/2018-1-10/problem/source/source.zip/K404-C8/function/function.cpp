#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
const int N=1000005;
typedef long long ll;

int nn;

int p[N],num,o[N],u[N],pk[N];bool b[N];

ll f1[N],f2[N],g1[N],g2[N],o1[N],o2[N],u1[N],u2[N],uu1[N],uu2[N];


void init()
{
	u[1]=o[1]=f1[1]=o1[1]=u1[1]=uu1[1]=1;
	for (int i=2;i<N;i++) 
	{
		if (!b[i]) 
		{
			p[++num]=i;
			u[i]=-1;
			o[i]=2;
			pk[i]=2;
		}
		for (int j=1;j<=num&&p[j]*i<N;j++) 
		{
			b[i*p[j]]=true;
			if (i%p[j]==0)		
			{
				u[i*p[j]]=0;
				pk[i*p[j]]=pk[i]+1;
				o[i*p[j]]=o[i]/pk[i]*(pk[i]+1);
				break;
			}else u[i*p[j]]=-u[i],o[i*p[j]]=o[i]*2,pk[i*p[j]]=2;
		}
		f1[i]=f1[i-1]+o[i];
		o1[i]=o1[i-1]+(ll)o[i]*o[i];
		u1[i]=u1[i-1]+u[i];
		uu1[i]=uu1[i-1]+u[i]*u[i];
	}
	for (int i=1;i<N;i++) 
	{
		for (int j=i;j<N;j+=i) g1[j]+=f1[j/i]-f1[j/i-1];
		g1[i]+=g1[i-1];
	}
}


ll workf(int n) 
{
	if (n<N) return f1[n];
	if (f2[nn/n]!=-1e18) return f2[nn/n];
	ll ans=0;
	for (int r,l=1;l<=n;l=r+1) 
	{
		r=n/(n/l);
		ans+=(ll)(r-l+1)*(n/l);
	}
	return f2[nn/n]=ans;
}

ll workg(int n) 
{
	if (n<N) return g1[n];
	if (g2[nn/n]!=-1e18) return g2[nn/n];
	ll ans=0;
	for (int r,l=1;l<=n;l=r+1) 
	{
		r=n/(n/l);
		ans+=(ll)(r-l+1)*workf(n/l);
	}
	return g2[nn/n]=ans;
}

ll workuu(int n) 
{
	if (n<N) return uu1[n];
	if (uu2[nn/n]!=-1e18) return uu2[nn/n];
	ll ans=0;
	for (int i=1;i*i<=n;i++) ans+=u[i]*(n/(i*i));
	return uu2[nn/n]=ans;
}

ll worko(int n) 
{
	if (n<N) return o1[n];
	if (o2[nn/n]!=-1e18) return o2[nn/n];
	ll ans=0;
	for (int r,l=1;l<=n;l=r+1) 
	{
		r=n/(n/l);
		ans+=(workuu(r)-workuu(l-1))*workg(n/l);
	}
	return o2[nn/n]=ans;
}

ll worku(int n) 
{
	if (n<N) return u1[n];
	if (u2[nn/n]!=-1e18) return u2[nn/n];
	ll ans=1;
	for (int r,l=2;l<=n;l=r+1) 
	{
		r=n/(n/l);
		ans-=(ll)(r-l+1)*worku(n/l);
	}
	return u2[nn/n]=ans;
}

void work()
{
	scanf("%d",&nn);
	for (int i=1;i*i<=nn;i++) g2[i]=f2[i]=u2[i]=uu2[i]=o2[i]=-1e18;
	
	ll ans=0;
	for (int r,l=1;l<=nn;l=r+1) 
	{
		r=nn/(nn/l);
		ans+=(worko(r)-worko(l-1))*worku(nn/l);
	}
	printf("%lld\n",ans);
}

int main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	init();
	int T;
	scanf("%d",&T);
	while (T--) work();
	//printf("\n%.5lf\n",(double)clock()/(double)CLOCKS_PER_SEC);
	return 0;
}

