#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;
#define MOD 998244353
#define MAXN 100000
#define rint register int
#define gc() getchar()
inline int read(rint ans = 0, rint sgn = ' ', rint ch = gc())
{
	for(; ch < '0' || ch > '9'; sgn = ch, ch = gc());
	for(; ch >='0' && ch <='9';(ans*=10)+=ch-'0', ch = gc());
	return sgn-'-'?ans:-ans;
}
#define BUF_SIZE 1000000
#define _END fwrite(_Ob,1,_O-_Ob,stdout), _O = _Ob
#define Outc(a) (*_O++ = a)
char _Ob[BUF_SIZE+5], *_O = _Ob, _Os[25], *_Ot;
template <typename T> inline void Out(T x)
{
	if(!x){Outc('0'); return;} if(x < 0) Outc('-'), x = -x;
	for(_Ot = _Os; x; *_Ot++ = x%10+'0', x /= 10);
	for(; _Ot != _Os; Outc(*--_Ot)); if(_O-_Ob >= BUF_SIZE-50) _END;
}
int n, k, fac[MAXN+5], g[15][15], ans[15], dep[15], cir, c;
inline int fastpow(int s, int n){int a = 1; for(; n; n&1 ? a = 1ll*a*s%MOD : 0, s = 1ll*s*s%MOD, n >>= 1); return a;}
void Robot(int p){for(rint i = 1; i <= n; i++) if(!dep[i] && g[p][i]) dep[i] = dep[p]+1, Robot(i), dep[i] = 0; else if(g[p][i]) cir = max(cir,dep[p]+1-dep[i]);}
int Check(){cir = 1; for(rint i = 1; i <= n; dep[i] = 1, Robot(i), dep[i] = 0, i++); return cir;}
void DFS(int i, int j){if(i == j) j = 1, ++i; if(i > n){++ans[Check()]; return;} g[i][j] = 0, g[j][i] = 1, DFS(i,j+1), g[i][j] = 1, g[j][i] = 0, DFS(i,j+1);}
int main()
{
	freopen("tournament.in","r",stdin), freopen("tournament.out","w",stdout);
	n = read(), k = read();
	fac[0] = 1; for(rint i = 1; i <= n; fac[i] = 1ll*i*fac[i-1]%MOD, i++);
	if(k == 3) return printf("%d\n",(fastpow(2,(1ll*n*~-n>>1)%~-MOD)-fac[n]+MOD)%MOD),0;
	else if(n <= 7){DFS(1,1); for(rint i = n; i >= 3; ans[i] += ans[i+1], i--); printf("%d\n",ans[k]);}
	else if(k == n){cout << (fastpow(2,n*~-n>>1)-2ll*n*fastpow(2,(n*~-n>>1)-(n-1))+n*(n-1ll)*fastpow(2,(n*~-n>>1)-(2*n-3)))%MOD << endl;} return 0;
}
