#include<bits/stdc++.h>
using namespace std;
const int maxn=110;
int a[maxn];
int ans,n;
int test(){
	int res=0;
	for(int i=1;i<=n;i++)
		res+=(a[i]!=a[i+1]+1&&a[i]!=a[i+1]-1);
	return res;
}
bool ok(){
	for(int i=1;i<=n;i++)
		if(a[i]!=i) return 0;
	return 1;
}
bool dfs(int ti){
	int v=test();
	if(ti+v>ans) return 0;
	if(ok()&&ti<=ans) return 1;
	for(int i=2;i<=n;i++){
		for(int j=1;j<=i/2;j++)
			swap(a[j],a[i-j+1]);
		if(dfs(ti+1)) return 1;
		for(int j=1;j<=i/2;j++)
			swap(a[j],a[i-j+1]);
	}
	return 0;
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		a[n+1]=n+1;
		for(ans=0;ans<=n*4;ans++){
			if(dfs(0)){
				printf("%d\n",ans);
				break;
			}
		}
	}
	return 0;
}
