//2018-1-4
//miaomiao
//
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define For(i, a, b) for(int i = (a); i <= (int)(b); ++i)

#define M 7
#define N (600+5)

const int P = 998244353;

int n, m, slen[M];
char s[M][N], a[N];

bool Ok(int p, int o){
	For(i, 1, slen[o])
		if(s[o][i] != a[p+i-1]) return false;
	return true;
}

bool Check(){
	int tmp = 0;
	For(i, 1, m<<1){
		For(j, 1, n)
			if(Ok(i, j)) tmp |= 1 << (j-1);
	}
	return tmp == ((1<<n)-1);
}

void Bf(){
	int ans = 0;
	For(ci, 0, (1<<m)-1){
		For(i, 1, m) a[i] =(ci&(1<<(i-1)))? '1': '0', a[(m<<1)-i+1] = '0'+'1'-a[i];
		if(Check()) ++ans;
	}
	printf("%d\n", ans);
}

struct AC{
	int hn, ch[N][2], f[N], fa[N], lst[N];
	vector<int> iss[N];

	void Insert(char *ns, int id){
		int len = strlen(ns+1), o = 0, nc;
		For(i, 1, len){
			nc = ns[i] - '0';
			if(!ch[o][nc]) ch[o][nc] = ++hn, fa[hn] = o;
			o = ch[o][nc];
		}
		iss[o].pb(id);
	}

	void Bfs(){
		queue<int> q;
		For(i, 0, 1) if(ch[0][i]) q.push(ch[0][i]);
		int now;

		while(!q.empty()){
			now = q.front(); q.pop();
			
			For(i, 0, 1){
				int nxt = ch[now][i], fs = ch[f[now]][i];
				if(!nxt) ch[now][i] = fs;
				else{
					f[nxt] = fs;
					lst[nxt] = iss[fs].size()>0? fs: lst[fs];
					q.push(nxt);
				}
			}
		}

	//	For(i, 1, hn) printf("f[%d] = %d lst = %d\n", i, f[i], lst[i]);
	//	puts("-----------------------");
	}

	void Getk(int o, int &k){
		if(iss[o].size() == 0) return;
		For(i, 0, iss[o].size()-1) k |= 1 << (iss[o][i]-1);
		Getk(lst[o], k);
	}

	void Nxt(int &o, int u, int &k){
		while(o && !ch[o][u]) o = f[o];
		o = ch[o][u]; Getk(o, k);
	}
}ac1, ac2;

struct node{
	int p2, v;
}f[N][N][1<<(M-1)];

char ts[N];

void Get(int &me, int ad){
	me += ad;
	if(me >= P) me -= P;
}

void Walk(int p1, int p2, int &k){
	int pre, nc;

	while(p2){
		pre = ac2.fa[p2];
		nc = ac2.ch[pre][1] == p2;
		ac1.Nxt(p1, nc, k);
		p2 = pre;
	}
}

void Solve(){
	For(i, 1, n){
		ac1.Insert(s[i], i);
		For(j, 1, slen[i]) ts[j] = s[i][slen[i]-j+1];
		ac2.Insert(ts, i);
	}
	ac1.Bfs(); ac2.Bfs();

	int me, p1, p2, nk, ed = (1<<n)-1;

	f[0][0][0] = (node){0, 1};
	For(i, 0, m-1) For(j, 0, ac1.hn) For(k, 0, ed) if(f[i][j][k].v){
		me = f[i][j][k].v;
	//	printf("i = %d p1 = %d p2 = %d k = %d v = %d\n", i, j, f[i][j][k].p2, k, f[i][j][k].v);

		For(u, 0, 1){
			p1 = j; p2 = f[i][j][k].p2; nk = k;
			
			ac1.Nxt(p1, u, nk); ac2.Nxt(p2, u^1, nk);
	//		if(j==4 && f[i][j][k].p2==4 && u == 0) printf("p1 = %d p2 = %d nk = %d\n", p1, p2, nk);

		//	if(f[i+1][p1][nk].p2 && f[i+1][p1][nk].p2 != p2) puts("NONONO");
			f[i+1][p1][nk].p2 = p2;
			Get(f[i+1][p1][nk].v, me);
		}
	}

	int ans = 0, tj, tmp;
	For(j, 0, ac1.hn){
		Get(ans, f[m][j][ed].v);
		For(k, 0, ed-1){
			tmp = k;
		//	if(tmp == 3 && j == 5) printf("p1 = %d p2 = %d v = %d\n", j, f[m][j][k].p2, f[m][j][k].v);
			
			tj = j;
			while(true){
				Walk(tj, f[m][j][k].p2, tmp);
				if(!tj) break;
				tj = ac1.f[tj];
			}
			if(tmp == ed) Get(ans, f[m][j][k].v);
		}
	}
	printf("%d\n", ans);
}

int main(){
	freopen("string.in", "r", stdin);
	freopen("string.out", "w", stdout);

	scanf("%d%d", &n, &m);
	For(i, 1, n) scanf("%s", s[i]+1), slen[i] = strlen(s[i]+1);
	
	if(m <= 15){Bf(); return 0;}
//	Bf(); puts("----------------------");
	Solve();

	return 0;
}
