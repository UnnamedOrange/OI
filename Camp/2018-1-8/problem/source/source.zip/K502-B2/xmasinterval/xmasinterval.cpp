#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int M=(int)5e5+5,P=1000000009;
void Rd(int &res){
	res=0;static char p;
	while(p=getchar(),p<'0');
	do{
		res=(res*10)+(p^48);
	}while(p=getchar(),p>='0');
}
void Add(int &x,int y){
	x+=y;
	if(x>=P)x-=P;
}
int n,m;
int pl[M*3],psz;
struct W{
	int l,r;
	bool operator <(const W &a)const{
		return l<a.l;
	}
}A[M];
int r[M],sum[M*3];
struct SHUI{
	int dp[10005];
	int RRR[10005],rsz;
	void solve(){
		dp[0]=1;
		RRR[rsz++]=0;
		for(int i=1;i<=n;i++)RRR[rsz++]=A[i].r;
		sort(RRR,RRR+rsz),rsz=unique(RRR,RRR+rsz)-RRR;
		for(int i=1;i<=n;i++){
			int rrr=upper_bound(RRR,RRR+rsz,A[i].r)-RRR;
			for(int j=rsz;j>=0;j--)
				if(dp[j]){
					if(RRR[j-1]<A[i].l&&(sum[A[i].l-1]-sum[RRR[j-1]]>0));
					else Add(dp[max(j,rrr)],dp[j]);
				}
		}
		int ans=0;
		for(int i=1;i<=rsz;i++)if(sum[psz]-sum[RRR[i-1]]==0){
			Add(ans,dp[i]);
			printf("%d %d\n",i,dp[i]);
		}
		printf("%d\n",ans);
	}
}P40;
struct IHSU{
	struct SEGMENT{
		int val[M*4],tg[M*4];
		SEGMENT(){
			for(int i=M*4-1;i>=0;i--)tg[i]=1;
		}
		void up(int p){
			Add(val[p]=val[p<<1],val[p<<1|1]);
		}
		void down(int p){
			if(tg[p]!=1){
				tg[p<<1]=(long long)tg[p<<1]*tg[p]%P;
				val[p<<1]=(long long)val[p<<1]*tg[p]%P;
				tg[p<<1|1]=(long long)tg[p<<1|1]*tg[p]%P;
				val[p<<1|1]=(long long)val[p<<1|1]*tg[p]%P;
				tg[p]=1;
			}
		}
		void update(int L,int R,int p,int x,int v){
			Add(val[p],v);
			if(L==R)return;
			down(p);
			int mid=(L+R)>>1;
			if(mid>=x)update(L,mid,p<<1,x,v);
			else update(mid+1,R,p<<1|1,x,v);
		}
		void cupdate(int L,int R,int p,int l,int r){
			if(L==l&&R==r){
				val[p]=2LL*val[p]%P;
				tg[p]=2LL*tg[p]%P;
				return;
			}down(p);
			int mid=(L+R)>>1;
			if(mid>=r)cupdate(L,mid,p<<1,l,r);
			else if(mid<l)cupdate(mid+1,R,p<<1|1,l,r);
			else cupdate(L,mid,p<<1,l,mid),cupdate(mid+1,R,p<<1|1,mid+1,r);
			up(p);
		}
		int query(int L,int R,int p,int l,int r){
			if(L==l&&R==r)return val[p];
			down(p);
			int mid=(L+R)>>1;
			if(mid>=r)return query(L,mid,p<<1,l,r);
			else if(mid<l)return query(mid+1,R,p<<1|1,l,r);
			else return (query(L,mid,p<<1,l,mid)+query(mid+1,R,p<<1|1,mid+1,r))%P;
		}
	}T;
	int RRR[M],rsz;
	void solve(){
		RRR[rsz++]=0;
		for(int i=1;i<=n;i++)RRR[rsz++]=A[i].r;
		sort(RRR,RRR+rsz),rsz=unique(RRR,RRR+rsz)-RRR;
		T.update(0,rsz,1,0,1);
		for(int i=1,LL,RR,mid,tmp;i<=n;i++){
			int rrr=upper_bound(RRR,RRR+rsz,A[i].r)-RRR;
			LL=1,RR=rrr,tmp=rrr;
			if(sum[A[i].l-1]==0)tmp=0;
			else {
				while(LL<=RR){
					mid=(LL+RR)>>1;
					if(RRR[mid-1]>=A[i].l||sum[A[i].l-1]==sum[RRR[mid-1]])RR=mid-1,tmp=mid;
					else LL=mid+1;
				}
			}
			T.update(0,rsz,1,rrr,T.query(0,rsz,1,tmp,rrr));
			if(rrr<rsz)T.cupdate(0,rsz,1,rrr+1,rsz);
		}
		int ans=0;
		for(int i=1;i<=rsz;i++)if(sum[psz]-sum[RRR[i-1]]==0)Add(ans,T.query(0,rsz,1,i,i));
		printf("%d\n",ans);
	}
}PPP;
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
//	freopen("1.out","w",stdout);
	Rd(n),Rd(m);
	for(int i=1;i<=n;i++)Rd(A[i].l),Rd(A[i].r),pl[psz++]=A[i].l,pl[psz++]=A[i].r;
	for(int i=1;i<=m;i++)Rd(r[i]),pl[psz++]=r[i];
	sort(pl,pl+psz),psz=unique(pl,pl+psz)-pl;
	for(int i=1;i<=n;i++){
		A[i].l=lower_bound(pl,pl+psz,A[i].l)-pl+1;
		A[i].r=lower_bound(pl,pl+psz,A[i].r)-pl+1;
	}
	sort(A+1,A+n+1);
	for(int i=1;i<=m;i++)r[i]=lower_bound(pl,pl+psz,r[i])-pl+1,sum[r[i]]++;
	for(int i=1;i<=psz;i++)sum[i]+=sum[i-1];
//	if(0);
	if(n<=10000&&m<=10000)P40.solve();
	else PPP.solve();
	return 0;
}
