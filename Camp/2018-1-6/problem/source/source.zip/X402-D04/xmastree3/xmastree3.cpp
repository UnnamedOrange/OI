#include<bits/stdc++.h>
using namespace std;

const int maxn=5;
int n,k;
int a[maxn][maxn], b[maxn][maxn];
int fa[maxn], l[maxn];
vector<int> g[maxn];

int ans;
void dfs(int s,int f,int x){
	// printf("s = %d\n", s);
	// printf("x = %d\n", x);
	int flag=0;
	int t[maxn][maxn]={0};
	memcpy(t,a,sizeof(a));
	for(int i=1;i<=n;i++)if(a[s][i]){
		// printf("i = %d f = %d\n", i, f);
		flag=1;
		int u=i; fa[u]=f; l[u]=x;
		for(int v=1;v<=n;v++)if(a[u][v]){
			 a[u][v]=a[v][u]=0;
			// a[u][v]=0;
			int t1[maxn][maxn]={0};
			memcpy(t1,a,sizeof(a));
			for(int j=1;x+j<=k;j++){
				memcpy(a,t1,sizeof(a));
				dfs(v,u,x+j);
			}
		}
		memcpy(a,t,sizeof(a));
	}
	if(!flag){ 
		// for(int i=1;i<=n;i++) printf("%d ", fa[i]); puts("");
		// for(int i=1;i<=n;i++) printf("%d ", l[i]); puts(""); puts("");
		ans++; }
}

int main(){
	freopen("xmastree3.in","r",stdin),freopen("xmastree3.out","w",stdout);

	scanf("%d%d", &n, &k);
	int u, v;
	for(int i=1;i<n;i++){
		scanf("%d%d", &u, &v); a[u][v]=a[v][u]=1;
		g[u].push_back(v); g[v].push_back(u);
	}
	memcpy(b,a,sizeof(a));
	for(int i=1;i<=n;i++) for(int j=1;j<=k;j++){
		memcpy(a,b,sizeof(a));
		dfs(i, 0, j);
	}
	printf("%d\n", ans);
	return 0;
}
