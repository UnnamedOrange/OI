#include<bits/stdc++.h>
using namespace std;

const int MAXN = 110;

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch); ch = getchar()) x = (x*10)+(ch^48);
	return x * f;
}

int n, m, ans;
bool g[MAXN][MAXN];

void dfs(int res, int s) {
	//printf("%d %d\n", res, s);
	if(res >= ans) return;
	if(s == 0) {
		ans = res;
		return;
	}
	int ns, i, j;
	for(ns = s; ns; ns = (ns-1)&s) {
		for(i = 1; i <= n; i++) {
			if(!((ns>>(i-1))&1)) continue;
			for(j = 1; j <= n; j++) {
				if(!((ns>>(j-1))&1)) continue;
				if(i == j) continue;
				if(g[i][j]) break;
			}
			if(j <= n) break;
		}
		if(i <= n) continue;
		dfs(res+1, s ^ ns);
	}
}

int main() {
	freopen("bomb.in", "r", stdin);
	freopen("bf.out", "w", stdout);

	int i, j, k;
	n = read(), m = read();

	for(i = 1; i <= m; i++) {
		int u = read(), v = read();
		g[u][v] = true;
	}
	for(k = 1; k <= n; k++) 
		for(i = 1; i <= n; i++) 
			for(j = 1; j <= n; j++) 
				g[i][j] |= g[i][k]&g[k][j];

	ans = n;
	dfs(0, (1<<n)-1);
	printf("%d\n", ans);
	return 0;
}
