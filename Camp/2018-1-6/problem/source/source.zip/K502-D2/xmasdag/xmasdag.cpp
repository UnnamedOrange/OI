#include <ctime>
#include <queue>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int mod = 998244353;
const int N = 100000 + 1000;
const int M = 200000 + 2000;

int n, m, k;
int F[N], v[N << 1], nex[N << 1], EID = 1;
int In[N];
long long f[2010][5010], f1[N][2], f0[N], Fa[N];
bool vis[N];

namespace file{
	inline void open()
	{
		freopen("xmasdag.in", "r", stdin);
		freopen("xmasdag.out", "w", stdout);
	}
	
	inline void close()
	{
		fclose(stdin);
		fclose(stdout);
	}
}

namespace input{
	inline int read()
	{
		int a = 0;
		char ch;
		int f = 1;
		while(!((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-')));
		if(ch == '-')
			f = -1;
		else
		{
			a = a * 10;
			a += ch - '0';
		}
		while((((ch = getchar()) >= '0') && (ch <= '9')) || (ch == '-'))
		{
			a = a * 10;
			a += ch - '0';
		}
		return a * f;
	}
	
	inline void add(int f, int t)
	{
		nex[EID] = F[f];
		v[EID] = t;
		F[f] = EID++;
	}
	
	inline void Get()
	{
		n = read(), m = read(), k = read();
		for(int i = 1;i <= m;++i)
		{
			int f = read(), t = read();
			add(f, t);
			++In[t];
		}
	}
}

namespace math{
	inline long long ksm(long long a, int b)
	{
		long long base = a, ret = 1;
		while(b > 0)
		{
			if(b & 1)
				ret = ret * base % mod;
			base = base * base % mod;
			b >>= 1;
		}
		return ret;
	}
}

namespace topo{
	inline void solve()
	{
		queue<int> q;
		q.push(1);
		f[1][0] = 1, f[1][5001] = 0, f[1][5002] = 0;
		while(q.size() > 0)
		{
			int fr = q.front();q.pop();
			for(int i = F[fr];i;i = nex[i])
			{
				int t = v[i];
				for(int j = f[fr][5002];j <= f[fr][5001];++j)
					f[t][j + 1] = (f[t][j + 1] + f[fr][j]) % mod;
				f[t][5001] = max(f[t][5001], f[fr][5001] + 1);
				if(f[t][5002] == 0 || f[t][5002] > f[fr][5002] + 1)
					f[t][5002] = f[fr][5002] + 1;
				--In[t];
				if(!In[t])
					q.push(t);
			}
		}
		for(int i = 1;i <= n;++i)
		{
			long long ans = 0;
			for(int j = f[i][5002];j <= f[i][5001];++j)
				ans = (ans + f[i][j] * math::ksm((long long)(j), k) % mod) % mod;
			if(i == 1 && k == 0)
				++ans;
			printf("%lld\n", ans);
		}
	}
}

namespace cnt{
	inline void solve()
	{
		queue<int> q;
		q.push(1);
		f1[1][0] = 0, f1[1][1] = 1;
		while(q.size() > 0)
		{
			int fr = q.front();q.pop();
			for(int i = F[fr];i;i = nex[i])
			{
				int t = v[i];
				f1[t][0] = (f1[t][0] + f1[fr][0] + f1[fr][1]) % mod;
				f1[t][1] = (f1[t][1] + f1[fr][1]) % mod;
				--In[t];
				if(!In[t])
					q.push(t);
			}
		}
		for(int i = 1;i <= n;++i)
			printf("%lld\n", f1[i][0]);
	}
}

namespace Kz{
	inline void solve()
	{
		queue<int> q;
		q.push(1);
		f0[1] = 1;
		while(q.size() > 0)
		{
			int fr = q.front();q.pop();
			for(int i = F[fr];i;i = nex[i])
			{
				int t = v[i];
				f0[t] = (f0[t] + f0[fr]) % mod;
				--In[t];
				if(!In[t])
					q.push(t);
			}
		}
		for(int i = 1;i <= n;++i)
			printf("%lld\n", f0[i]);
	}
}

namespace method{
	inline void solve()
	{
		printf("%d\n", rand());
	}
}

namespace check{
	inline void deter()
	{
		srand(19260817);
		if(n <= 2000)
			topo::solve();
		else if(k == 1)
			cnt::solve();
		else if(k == 0)
			Kz::solve();
		else
			method::solve();
	}
}

int main()
{
	file::open();
	input::Get();
	check::deter();
	file::close();
}
/*
6 8 2
1 2
1 3
1 5
2 4
3 2
3 4
3 6
4 6
*/
