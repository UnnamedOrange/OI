#include<bits/stdc++.h>
using namespace std;
inline int rd(){
	char ch=getchar(); int i=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1; ch=getchar();}
	while(isdigit(ch)){i=(i<<1)+(i<<3)+ch-'0'; ch=getchar();}
	return i*f;
}
const int N=3e4+50;
int n,g[N],v[N*2],nt[N*2],ec;
int w[N],r[N],fa[N];
inline void add(int x,int y){nt[++ec]=g[x];g[x]=ec;v[ec]=y;}
namespace Task1{
	const int LIM=(1<<10)+20;
	int dp[LIM],ans;
	inline void dfs(int x,int f){
		fa[x]=f;
		for(int e=g[x];e;e=nt[e])
			(v[e]!=f) && (dfs(v[e],x),0);
	}
	inline int getans(int rt){
		dfs(rt,0); int lim=(1<<n)-1;
		memset(dp,0xc0,sizeof(dp));
		dp[0]=0;
		for(int i=1;i<=lim;i++){
			int cnt=0,tp=i;
			while(tp) ++cnt,tp-=(tp&(-tp));
			for(int j=1;j<=n;j++)
				if((i&(1<<(j-1))) && ( (!fa[j]) || (i&(1<<(fa[j]-1))) ))
					dp[i]=max(dp[i],dp[i^(1<<(j-1))]+w[j]*cnt);
		}
		return dp[lim];
	}
	inline void solve(){
		for(int i=1;i<=n;i++)
			if(r[i]) ans=max(ans,getans(i)); 
		printf("%d\n",ans);
	}
}
namespace Task2{
	#define MP make_pair
 	typedef pair<long long,int> pii;
	priority_queue < pii,vector<pii>,greater<pii> > q;
	vector <int> son[N];
	long long ans,sum[N];
	inline void dfs(int x,int f){
		son[x].clear(); sum[x]=w[x];
		for(int e=g[x];e;e=nt[e]){
			if(v[e]==f)continue;
			son[x].push_back(v[e]);
			dfs(v[e],x);
			sum[x]+=w[v[e]];
		}
	}
	inline long long getans(int rt){
		dfs(rt,0); q.push(MP(sum[rt],rt));
		int cnt=0;long long rs=0;
		while(!q.empty()){
			pii u=q.top(); q.pop();
			int s=u.second; rs+=1ll*w[s]*(++cnt);
			for(int v=son[s].size()-1;v>=0;v--)
				q.push(MP(sum[son[s][v]],son[s][v]));
		}
		return rs;
	}
	inline void solve(){
		for(int i=1;i<=n;i++)
			if(r[i]) ans=max(ans,getans(i));
		printf("%lld\n",ans);
	}
}
int main(){
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		int x=rd(),y=rd();
		add(x,y); add(y,x);
	}
	for(int i=1;i<=n;i++) w[i]=rd(),r[i]=rd();
	if(n<=10)Task1::solve();
	else Task2::solve();
} 
