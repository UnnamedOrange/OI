#include<bits/stdc++.h>
using namespace std;
#define N 100010
struct Edge {
	int u,v,nxt;
}e[N];
int head[N],cnt;
void add(int u,int v) {
	e[++cnt].u=u;e[cnt].v=v;e[cnt].nxt=head[u];head[u]=cnt;
}
vector<int> g;
int w[N],vis[N],fa[N];
int ans=0,n;
void dfs1(int po,int ff) {
	for(int i=head[po];i!=-1;i=e[i].nxt) {
		if(e[i].v==ff) continue;
		fa[e[i].v]=po;
		dfs1(e[i].v,po);
	}
}
void dfs2(int po,int num) {
	if(po==n) {
		ans=max(ans,num);
		return;
	}
	for(int i=1;i<=n;i++) {
		if(vis[i]) continue;
		if(!vis[fa[i]]) continue;
		vis[i]=1;
		dfs2(po+1,num+w[i]*(po+1));
		vis[i]=0;
	}
}
void work(int gen) {
	dfs1(gen,gen);
	fa[gen]=0;
	w[0]=1;vis[0]=1;
	dfs2(0,0);
}
int is[N];
struct Node {
	int w,id;
	Node(int w=0,int id=0) : w(w),id(id) {}
	bool operator < (const Node &A) const {
		return w<A.w;
	}
};
priority_queue<Node> s;
void work2(int gen) {
	memset(vis,0,sizeof(vis));
	dfs1(gen,gen);
	s.push(Node(w[gen],gen));
	int tmp2=0;
	for(int i=1;i<=n;i++) {
		Node tmp=s.top();
		tmp2+=tmp.w*i;
		s.pop();
		for(int i=head[tmp.id];i!=-1;i=e[i].nxt) {
			if(!vis[e[i].v]) s.push(Node(w[e[i].v],e[i].v)),vis[e[i].v]=1;
		}
	}
	ans=max(ans,tmp2);
}
void dfs3(int po,int dep,int fa) {
	if(dep==0) return;
	is[po]=1;
	for(int i=head[po];i!=-1;i=e[i].nxt) {
		if(e[i].v!=fa) dfs3(e[i].v,dep-1,po);
	}
}
int main() {
	freopen("xmastree2.in","r",stdin);
	freopen("xmastree2.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d",&n);
	for(int i=1;i<n;i++) {
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	for(int i=1;i<=n;i++) {
		int r;
		scanf("%d%d",&w[i],&r);
		if(r) g.push_back(i);
	}
	if(n<=10) {
		for(int i=0;i<g.size();i++) work(g[i]);
		printf("%d",ans);
	} else {
		for(int i=0;i<g.size();i++) {
			dfs1(g[i],g[i]);
			dfs3(g[i],3,g[i]);
		}
		for(int i=1;i<=n;i++) if(is[i]) work2(i);
		printf("%d",ans);
	}
}
