#include<bits/stdc++.h>
#include<tr1/unordered_map>
typedef unsigned long long ull;
const ull base=31;
using namespace std;
typedef tr1::unordered_map<ull,int> MP;
MP *S;
int n,A[12],B[12];
ull pw[12],tar;
struct node{
	int a[12];
	ull val;
	int st;
	node(int *b){
		val=0;
		for(int i=1;i<=n;i++){
			a[i]=b[i];
			val+=pw[i]*a[i];
		}
	}
};
inline void solve(){
	S=new MP;queue<node>q;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&A[i]);
	for(int i=1;i<=n;i++)B[i]=i;
	node tp(A);tar=tp.val;
	tp=node(B);
	if(tp.val==tar){puts("0");return;}
	q.push(tp);tp.st=0;
	S->operator[](tp.val)=0;
	int tmp[12];
	while(!q.empty()){
		tp=q.front();q.pop();int st=tp.st;
		memcpy(tmp,tp.a,sizeof(tmp));
		for(int i=2;i<=n;i++){
			reverse(tmp+1,tmp+i+1);
			tp=node(tmp);
			if(S->find(tp.val)==S->end()){
				if(tp.val==tar){
					printf("%d\n",st+1);
					return;
				}
				S->operator[](tp.val)=st+1;
				tp.st=st+1;
				q.push(tp);
			}
			reverse(tmp+1,tmp+i+1);
		}
	}
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	pw[0]=1;
	for(int i=1;i<=10;i++)pw[i]=pw[i-1]*base;
	int t;scanf("%d",&t);
	while(t--)solve();
}
