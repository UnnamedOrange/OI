#include <cstdio>
using namespace std;
int main()
{
	freopen("sad.in","r",stdin);
	freopen("sad.out","w",stdout);
	puts("2");
	return 0;
}
