#include<bits/stdc++.h>
using namespace std;
int main()
{
	int T=100;
	while(T--)
	{
		system("./data >xmastree1.in");
		system("./xmastree1");
		system("./baoni");
		if(system("diff xmastree1.out xmastree1.outt"))break;
		puts("AC");
	}
	return 0;
}
