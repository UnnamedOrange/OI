#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
const int maxm=maxn*300;
int n, q, t;
int c[maxn];
vector<int> g[maxn];

void read(int& x){
	x=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
}

int st[maxn], ed[maxn], dfn, fa[maxn];
void dfs(int x){
	st[x]=++dfn;
	for(int i=0;i<g[x].size();i++){
		int v=g[x][i]; if(v==fa[x]) continue;
		fa[v]=x; dfs(v);
	}
	ed[x]=dfn;
}

int sum[maxm], num[maxm];
void Modify(int& o,int l,int r,int col,int val){
	if(!o) o=++e;
	if(l==r){ num[o]+=val; sum[o]=(bool)num[o]; return; }
	int mid=(l+r)>>1; 
	if(col<=mid) Modify(ls[o],l,mid,col,val); else Modify(rs[o],mid+1,r,col,val);
	sum[o]=sum[ls[o]]+sum[rs[o]];
}
void modify(int o,int l,int r,int pos,int col,int val){
	Modify(root[o],1,n,col,val);
	if(l==r) return;
	int mid=(l+r)>>1;
	if(pos<=mid) modify(o<<1,l,mid,pos,col,val); else modify(o<<1|1,mid+1,r,pos,col,val);
}

int query(int o,int l,int r,int ql,int qr,int x,int y){
	if(ql<=l && qr>=r) return Query(root[o],1,1,n,x,y);
	int mid=(l+r)>>1;
}

int lstans;
int main(){
	freopen("xmastree1.in","r",stdin),freopen("xmastree1.out","w",stdout);

	read(n), read(q), read(t);
	for(int i=1;i<=n;i++) read(c[i]);
	int u, v, l, r, x;
	for(int i=1;i<n;i++){
		read(u), read(v);
		g[u].push_back(v), g[v].push_back(u);
	}
	dfs(1);
	for(int i=1;i<=n;i++){
		modify(1,1,n,st[i],c[i]);
	}
	while(q--){
		read(op);
		if(op==1){
			read(u), read(l), read(r);
			if(t) u^=lstans, l^=lstans, r^=lstans;
			printf("%d\n", query(1,1,n,st[u],ed[u],l,r));
		}else{
			read(u), read(x);
			if(t) u^=lstans, x^=lstans;
			modify(1,1,n,st[u],c[u],-1);
			modify(1,1,n,st[u],x,1); c[u]=x;
		}
	}
	return 0;
}
