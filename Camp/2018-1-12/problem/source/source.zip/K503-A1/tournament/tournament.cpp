#include<bits/stdc++.h>
using namespace std;
const int p=998244353;
typedef long long ll;
int n,k,a[10][10],ans;
bool h[100];
bool dfs(int x,int dep,int t){
	if (dep>k) return x==t;
	if (h[x]) return false;
	h[x]=1;
	for (int i=1;i<=n;i++)
	if ((a[x][i]==1)&&(dfs(i,dep+1,t))) {h[x]=0;return true;}
	h[x]=0;
	return false;
}
void check(){
	for (int i=1;i<=n;i++)
	if (dfs(i,1,i)){ans++;return;}
}
void work(int x,int y){
	if (x>n) check();
	else if (x==y) work(x+1,1);
	else {
		a[x][y]=1;a[y][x]=-1;
		work(x,y+1);
		a[x][y]=-1;a[y][x]=1;
		work(x,y+1);
	}
}
int po(int x,ll k){
	int t=1;
	for (;k;k>>=1){
		if (k&1) t=(ll)t*x%p;
		x=(ll)x*x%p;
	}
	return t;
}
int fact(int x){
	int t=1;
	for (int i=2;i<=n;i++)
	t=(ll)t*i%p;
	return t;
}
int main(){
	freopen("tournament.in","r",stdin);
	freopen("tournament.out","w",stdout);
	scanf("%d %d",&n,&k);
	ans=0;
	if (k==3) ans=(po(2,n*(n-1)/2)-fact(n)+p)%p;
	else work(1,1);
	printf("%d\n",ans);
	return 0;
}
