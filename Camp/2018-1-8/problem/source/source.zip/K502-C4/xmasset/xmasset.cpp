#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

int t,n,T,x,y,q,h;

int main()
{
	freopen("xmasset.in","r",stdin);
	freopen("xmasset.out","w",stdout);
	scanf("%d%d%d",&t,&n,&T);
	if(t==1)
	{
		while(T--)
		{
			scanf("%d%d",&x,&y);
			printf("%d\n",y);
		}
	}
	else if(t==2)
	{
		while(T--)
		{
			scanf("%d%d",&q,&h);
			if(h==q) printf("no\n");
			else printf("yes\n");
		}
	}
	return 0;
}
