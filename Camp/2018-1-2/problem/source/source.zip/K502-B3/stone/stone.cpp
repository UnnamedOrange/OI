#include <stdio.h>

const int maxn=1e9+7;
long long int x[100001];
long long int n,a,b; 
 
inline long long int read()
{
    char ch;
    bool flag = false;
    long long int a=0;
    while(!((((ch=getchar())>='0')&&(ch<='9'))||(ch=='-')));
    if(ch!='-')
	{
        a*=10;
        a+=ch-'0';
    }
    else
	{
        flag=true;
    }
    while(((ch=getchar())>='0')&&(ch<='9'))
	{
        a*=10;
        a+=ch-'0';
    }
    if(flag)
	{
        a=-a;
    }
    return a; 
}

int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n=read(),a=read(),b=read();
	long long int i;
	for(i=1;i<=n;i++)
		x[i]=read();
	n--;
	long long int temp=1,fa=2;
	while(n)
	{
		if(n%2==1)
			temp=(temp*fa)%maxn;
		fa=(fa*fa)%maxn;
		n=n/2;
	}
	if(a>b)
		printf("0 %lld %lld %lld",temp,temp/2,temp/2);
	if(a==b)
		printf("0 0 %lld %lld",temp,temp);
	if(a<b)
		printf("%lld 0 %lld %lld",temp,temp/2,temp/2);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
