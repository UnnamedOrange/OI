#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,g=0;
	char ch=getchar();
	for (;!isdigit(ch);ch=getchar()) if (ch=='-') f=-1;
	for (;isdigit(ch);ch=getchar()) g=g*10+ch-'0';
	return f*g;
}
const int p=1000000007;
int n,c[1200000],d[1200000],g[1200000],f[1200000],s[1200000];
bool h[1200000];
void update(int i,int j){
	h[i]|=h[j];
	if (f[j]+1>f[i]){f[i]=f[j]+1;s[i]=s[j];}
	else if (f[j]+1==f[i]) s[i]=(s[i]+s[j])%p;
}
int main(){
	freopen("schooldays.in","r",stdin);
	freopen("schooldays.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++){
		c[i]=read();d[i]=read();
	}
	f[0]=0;s[0]=1;h[0]=1;
	for (int i=1;i<=n;i++){
		int maxc=c[i],mind=d[i];
		for (int j=i-1;j>=0;j--){
			if ((i-j>=maxc)&&(i-j<=mind)) update(i,j);
			maxc=max(maxc,c[j]);
			mind=min(mind,d[j]);
		}
	}
	if (!h[n]) puts("-1");
	else printf("%d %d\n",f[n],s[n]);
	return 0;
}
