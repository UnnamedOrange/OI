#include<bits/stdc++.h>
using namespace std;
const int maxn=500100;
const int md=1000000009;
#define mid ((l+r)>>1)
struct node{
	int l,r;
}a[maxn];
bool cmp(const node &A,const node &B){
	return A.l<B.l;
}
void Mod(int &x){
	x=x>=md?x-md:x;
}
int b[maxn];
int n,m;
void readl(int &x){
	x=0;
	char ch=getchar(); 
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)){
		x=x*10+ch-'0';
		ch=getchar();
	}
}
int tr[maxn<<2],tg[maxn<<2];
void push_down(int h){
	if(tg[h]==1) return;
	tg[h<<1]=tg[h<<1]*(long long)tg[h]%md;
	tg[h<<1|1]=tg[h<<1|1]*(long long)tg[h]%md;
	tr[h<<1]=tr[h<<1]*(long long)tg[h]%md;
	tr[h<<1|1]=tr[h<<1|1]*(long long)tg[h]%md;
	tg[h]=1;
}
void push_up(int h){
	tr[h]=tr[h<<1]+tr[h<<1|1];
	Mod(tr[h]);
}
void Add(int h,int l,int r,int p,int v){
	if(l==r){
		Mod(tr[h]+=v);
		return;
	}
	push_down(h);
	if(p<=mid) Add(h<<1,l,mid,p,v);
	else Add(h<<1|1,mid+1,r,p,v);
	push_up(h);
}
void mult(int h,int l,int r,int s,int t,int v){
	if(t<s) return;
	if(s<=l&&r<=t){
		Mod(tg[h]*=v);
		Mod(tr[h]*=v);
		return;
	}
	push_down(h);
	if(t<=mid)
		mult(h<<1,l,mid,s,t,v);
	else if(s>mid)
		mult(h<<1|1,mid+1,r,s,t,v);
	else{
		mult(h<<1,l,mid,s,mid,v);
		mult(h<<1|1,mid+1,r,mid+1,t,v);
	}
	push_up(h);
}
int Ask(int h,int l,int r,int s,int t){
	if(t<s) return 0;
	if(s<=l&&r<=t) return tr[h];
	push_down(h);
	if(t<=mid)
		return Ask(h<<1,l,mid,s,t);
	else if(s>mid)
		return Ask(h<<1|1,mid+1,r,s,t);
	else{
		int res=Ask(h<<1,l,mid,s,t)+Ask(h<<1|1,mid+1,r,mid+1,t);
		Mod(res);
		return res;
	}
}
int main(){
	freopen("xmasinterval.in","r",stdin);
	freopen("xmasinterval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		readl(a[i].l),readl(a[i].r);
	for(int i=1;i<=m;i++)
		readl(b[i]);
	sort(b+1,b+m+1);
	int ans=1;
	int num=0;
	for(int i=1;i<=n;i++){
		a[i].l=lower_bound(b+1,b+m+1,a[i].l)-b;
		a[i].r=upper_bound(b+1,b+m+1,a[i].r)-b-1;
		if(a[i].r<a[i].l) ans=ans*2%md;
		else a[++num]=a[i];
	}
	n=num;
	sort(a+1,a+n+1,cmp);
	int v;
	Add(1,0,m,0,1);
	for(int i=1;i<=n;i++){
		v=Ask(1,0,m,a[i].l-1,a[i].r);
		Add(1,0,m,a[i].r,v);
		mult(1,0,m,a[i].r+1,m,2);
	}
	v=Ask(1,0,m,m,m);
	ans=ans*(long long)v%md;
	printf("%d\n",ans);
	return 0;
}
