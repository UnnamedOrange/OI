#include<bits/stdc++.h>
#define maxn 100000
#define N 1000000
#define ll long long
using namespace std;
ll f[N + 1], sum[N + 1];
int tot_prime, prime[maxn], from[N + 1];
int main()
{
	freopen("function.in", "r", stdin);
	freopen("function.out", "w", stdout);
	f[1] = 1;
	for (int i = 2; i <= N; i++)
	{
		if (f[i] == 0)
		{
			prime[++tot_prime] = i;
			from[i] = i;
			f[i] = 3;
		}
		for (int j = 1; j <= tot_prime; j++)
		{
			if (i * prime[j] > N) break;
			if (i % prime[j] == 0)
			{
				from[i * prime[j]] = from[i] * prime[j];
				int q = i / from[i];
				f[i * prime[j]] = f[i] + 2 * f[q];
				break;
			}
			from[i * prime[j]] = prime[j];
			f[i * prime[j]] = f[i] * f[prime[j]];
		}
	}
	for (int i = 1; i <= N; i++)
		sum[i] = sum[i - 1] + f[i];
	int T;
	scanf("%d", &T);
	while (T--)
	{
		int n;
		scanf("%d", &n);
		printf("%lld\n", sum[n]);
	}
	return 0;
}
