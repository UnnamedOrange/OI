#include <stdio.h>
#define maxn 1000010
int a[maxn],n,m,i,j;
double ans=0,p,s1,s2;
int main()
{
	freopen("drink.in","r",stdin);
	freopen("drink.out","w",stdout);
	scanf("%d",&n);
	for (i=0;i<n;i++)
		scanf("%d",&a[i]);
	for (i=0;i<n;i++)
	{
		s1=0;
		p=1;
		for (j=i;j>=0;j--)
		{
			if (a[j]>=a[i]) p/=2;
			s1+=p;
		}
		s2=0;
		p=1;
		for (j=i;j<n;j++)
		{
			if (a[j]>a[i]) p/=2;
			s2+=p;
		}
		ans+=s1/n/n*s2*a[i];
	}
	printf("%.12lf",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
